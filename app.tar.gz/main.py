"""Punto de entrada de Focus10 dentro de un navegador.

Lo genera herramientas/preparar_web.py; no se edita a mano.
"""

from focus10.interfaz.app import ejecutar

ejecutar()
