"""Cómo fue un día, juntando lo que ya se apuntó en cada apartado.

LO PIDIÓ EL USUARIO: "que funcione como un calendario mensual visual, donde
pueda ver de forma rápida un resumen de cómo fue cada día, juntando toda la
información registrada durante ese día".

NO SE CALCULA NADA NUEVO AQUÍ. Cada apartado ya sabe responder por su cuenta —el
cumplimiento de la comida, las rachas de los hábitos, los totales por jornada del
dinero— y esto solo junta esas respuestas en una ficha. Si alguna cuenta cambia,
cambia en su sitio y esto la sigue.

ES UNA PIEZA SIN BASE DE DATOS: recibe lo que otros ya han leído. Así se puede
probar un mes entero sin abrir un archivo, y así el mes se lee de la base en seis
consultas y no en treinta.

LO QUE NO HAY NO SE INVENTA. Un día sin entreno no es un entreno de cero kilos,
y un día sin comida apuntada no es un día de cero calorías: son huecos, y en el
calendario se ven como huecos.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

from .cumplimiento import Cumplimiento
from .rutina import texto_peso


@dataclass(frozen=True)
class DiaResumido:
    """Una casilla del calendario del mes."""

    jornada: date

    comida: Cumplimiento = Cumplimiento.SIN_OBJETIVO
    """Cómo salió la alimentación. Sale tal cual del apartado de Alimentación."""

    entreno: bool = False
    entreno_nombre: str = ""
    """Cómo se llamaba el entreno: "Pecho y tríceps".

    LO PIDIÓ EL USUARIO ASÍ —"el ejercicio que hiciste, tipo, ese día hice
    pecho"—. Sale del nombre del día de la rutina, que es donde él ya lo
    escribió; no se adivina de los ejercicios.
    """

    ejercicios: tuple[str, ...] = field(default_factory=tuple)
    """Los ejercicios en los que de verdad se marcó alguna serie."""

    mejor_peso: int = 0
    """El peso más alto que se movió ese día, en centésimas de kilo.

    ES EL DATO CORTO QUE PIDIÓ EL USUARIO ("+80 kg"). Se elige el máximo y no el
    volumen total porque cabe en cuatro caracteres y se entiende sin explicar;
    el volumen ya está en el apartado de Gimnasio para quien lo quiera.
    """

    habitos: tuple[tuple[str, bool], ...] = field(default_factory=tuple)
    """Los habitos que TOCABAN ese dia, con si se cumplieron o no.

    SE GUARDAN LOS NOMBRES Y NO SOLO LA CUENTA porque el usuario pidio ver
    "que habitos cumpli y cuales no", y "3/5" no dice cuales. La cuenta sale
    de aqui, asi que no puede discrepar del detalle.

    LOS QUE NO TOCABAN NO ESTAN. Un habito de los lunes no se falla un martes.
    """

    tareas: tuple[str, ...] = field(default_factory=tuple)
    """Lo que diste por hecho ese día."""

    gasto: int = 0
    """En unidades mínimas de la moneda principal."""

    nota: str = ""
    """La reflexión que escribiste al cerrar el día."""

    valoracion: int | None = None
    """Del 1 al 10, si cerraste el día."""

    @property
    def habitos_programados(self) -> int:
        return len(self.habitos)

    @property
    def habitos_cumplidos(self) -> int:
        return sum(1 for _, hecho in self.habitos if hecho)

    @property
    def hubo_habitos(self) -> bool:
        return bool(self.habitos)

    @property
    def hay_algo(self) -> bool:
        """Si ese día se registró ALGO.

        SIRVE PARA NO PINTAR RUIDO: un día completamente vacío se deja en
        blanco en vez de llenarlo de cruces rojas, que dirían que fallaste
        cuando lo que pasa es que ese día no existió para la aplicación.
        """
        return bool(
            self.entreno
            or self.hubo_habitos
            or self.tareas
            or self.gasto
            or self.nota
            or self.comida is not Cumplimiento.SIN_OBJETIVO
        )

    def texto_habitos(self) -> str:
        """"4/5", o vacío si ese día no tocaba ninguno."""
        if not self.hubo_habitos:
            return ""
        return f"{self.habitos_cumplidos}/{self.habitos_programados}"

    def texto_peso(self) -> str:
        """"80 kg", o vacío si no se movió peso.

        VACÍO Y NO "0 kg": hay entrenos sin peso —una carrera, movilidad— y
        escribir un cero diría que levantaste nada, que no es lo mismo.
        """
        if not self.mejor_peso:
            return ""
        return texto_peso(self.mejor_peso)

    def titulo_entreno(self) -> str:
        """"Pecho y tríceps", o "Entreno" si ese día no llevaba nombre.

        NO SE INVENTA UN NOMBRE A PARTIR DE LOS EJERCICIOS: un entreno suelto de
        dos ejercicios no es "día de pecho" solo porque toque pecho, y ponerlo
        sería contarle al usuario algo que él no escribió.
        """
        return self.entreno_nombre or "Entreno"
