"""Cómo vas con tus hábitos en un período: el día, la semana, el mes o el año.

UN SOLO CÁLCULO PARA DOS PANTALLAS. La tarjeta compacta del Dashboard y la
pestaña «Estadísticas» de Hábitos leen de aquí, y es a propósito: lo pidió el
usuario («mismos datos reales, no estadísticas independientes»). Si cada
pantalla contara a su manera, el Dashboard diría 85 % y Hábitos 82 %, y ninguna
de las dos sería de fiar.

QUÉ SE CUENTA, decidido con el usuario: CADA HÁBITO DE CADA DÍA. Con cinco
hábitos diarios, un mes son unas 150 marcas. «Completados» son las que
cumpliste; «restantes», las que te quedan hasta el final del período.

EL PORCENTAJE SALE DE LO QUE YA PASÓ, con la misma regla que las rachas: HOY NO
CUENTA EN CONTRA. Si hoy tocan tres hábitos y todavía no hiciste ninguno, el
porcentaje no baja a media mañana: hoy entra solo con lo que ya cumpliste. Lo
que falta de hoy va a «restantes», que es donde está.

AQUÍ NO HAY BASE DE DATOS: entran los hábitos y lo marcado, y sale el resumen.
Así se prueba sin disco (ver datos/estadisticas_habitos.py, que es quien lee).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from enum import StrEnum

from .habito import Habito
from .rachas import CumplimientoDelDia, Rachas, cumplimiento_de_varios


class Periodo(StrEnum):
    DIA = "día"
    SEMANA = "semana"
    MES = "mes"
    ANO = "año"


def rango(periodo: Periodo, hoy: date) -> tuple[date, date]:
    """El primer y el último día del período que contiene a `hoy`.

    LA SEMANA EMPIEZA EN LUNES, como el resto de la aplicación (Horario,
    Hábitos).
    """
    if periodo is Periodo.DIA:
        return hoy, hoy
    if periodo is Periodo.SEMANA:
        lunes = hoy - timedelta(days=hoy.weekday())
        return lunes, lunes + timedelta(days=6)
    if periodo is Periodo.MES:
        primero = hoy.replace(day=1)
        siguiente = (primero + timedelta(days=32)).replace(day=1)
        return primero, siguiente - timedelta(days=1)
    return date(hoy.year, 1, 1), date(hoy.year, 12, 31)


def dias(desde: date, hasta: date) -> list[date]:
    return [desde + timedelta(days=n) for n in range((hasta - desde).days + 1)]


class Estado(StrEnum):
    """Cómo quedó un hábito un día, para pintar el mapa de calor."""

    CUMPLIDO = "cumplido"
    FALLADO = "fallado"
    PENDIENTE = "pendiente"
    """Hoy, todavía sin cumplir: no es un fallo, el día no terminó."""
    NO_TOCABA = "no tocaba"
    FUTURO = "futuro"


@dataclass(frozen=True)
class Cuenta:
    """Lo contado de un período, de todos los hábitos o de uno solo."""

    cumplidos: int = 0
    base: int = 0
    """Lo que ya se podía haber cumplido: días pasados, más lo cumplido HOY."""
    restantes: int = 0

    @property
    def porcentaje(self) -> int | None:
        """De 0 a 100. None si todavía no había nada que cumplir.

        NONE Y NO CERO: «0 %» diría que fallaste todo, y lo que pasó es que no
        había nada programado. Son dos cosas distintas y se enseñan distinto.
        """
        if not self.base:
            return None
        return round(self.cumplidos * 100 / self.base)


@dataclass(frozen=True)
class DeUnHabito:
    habito: Habito
    cuenta: Cuenta
    rachas: Rachas
    estados: dict[date, Estado] = field(default_factory=dict)


@dataclass(frozen=True)
class Resumen:
    periodo: Periodo
    desde: date
    hasta: date
    hoy: date
    total: Cuenta
    por_dia: list[CumplimientoDelDia]
    """Un valor por día del período, para la curva. Los días que no llegaron
    todavía también están, y la curva los deja sin dibujar."""
    habitos: list[DeUnHabito]

    @property
    def dia_actual(self) -> int:
        """Qué día del período es hoy: el 28 de «día 28 de 30»."""
        return min(max((self.hoy - self.desde).days + 1, 0), self.dias_totales)

    @property
    def dias_totales(self) -> int:
        return (self.hasta - self.desde).days + 1

    def mejores_y_peores(self) -> tuple[list[DeUnHabito], list[DeUnHabito]]:
        """Los que estás MANTENIENDO (80 % o más) y los que estás FALLANDO (menos
        de 50 %). Los del medio no se nombran: ni felicitar ni regañar por un 65 %.

        LOS QUE NO TUVIERON NADA QUE CUMPLIR NO ENTRAN EN NINGUNO: un hábito de
        los sábados, un martes, no está ni bien ni mal.
        """
        con_dato = [h for h in self.habitos if h.cuenta.porcentaje is not None]
        bien = sorted(
            (h for h in con_dato if h.cuenta.porcentaje >= MANTENIENDO),
            key=lambda h: -h.cuenta.porcentaje,
        )
        mal = sorted(
            (h for h in con_dato if h.cuenta.porcentaje < FALLANDO),
            key=lambda h: h.cuenta.porcentaje,
        )
        return bien, mal


MANTENIENDO = 80
FALLANDO = 50


def _contar(habito: Habito, cantidades: dict, dias_del_periodo: list[date], hoy: date) -> tuple[Cuenta, dict[date, Estado]]:
    cumplidos = base = restantes = 0
    estados: dict[date, Estado] = {}
    for dia in dias_del_periodo:
        if not habito.toca_en(dia):
            estados[dia] = Estado.NO_TOCABA
            continue
        hecho = habito.cumplido_con(cantidades.get((habito.id, dia), 0))
        if dia > hoy:
            estados[dia] = Estado.FUTURO
            restantes += 1
        elif dia == hoy:
            # HOY NO CUENTA EN CONTRA: si ya lo hiciste suma; si no, queda
            # pendiente y va a «restantes», no a la base del porcentaje.
            if hecho:
                estados[dia] = Estado.CUMPLIDO
                cumplidos += 1
                base += 1
            else:
                estados[dia] = Estado.PENDIENTE
                restantes += 1
        else:
            base += 1
            if hecho:
                cumplidos += 1
                estados[dia] = Estado.CUMPLIDO
            else:
                estados[dia] = Estado.FALLADO
    return Cuenta(cumplidos, base, restantes), estados


def resumir(
    periodo: Periodo,
    hoy: date,
    habitos: list[Habito],
    cantidades: dict[tuple[int, date], int],
    rachas: dict[int, Rachas],
) -> Resumen:
    """El resumen del período que contiene a `hoy`.

    `cantidades` trae lo marcado en el período, indexado por (hábito, día): lo
    que da `repositorio_habitos.cantidades_de_todos`. `rachas` va aparte porque
    una racha mira toda la historia, no solo el período.
    """
    desde, hasta = rango(periodo, hoy)
    todos_los_dias = dias(desde, hasta)

    por_habito = []
    cumplidos = base = restantes = 0
    for habito in habitos:
        cuenta, estados = _contar(habito, cantidades, todos_los_dias, hoy)
        por_habito.append(
            DeUnHabito(habito, cuenta, rachas.get(habito.id, Rachas(0, 0)), estados)
        )
        cumplidos += cuenta.cumplidos
        base += cuenta.base
        restantes += cuenta.restantes

    return Resumen(
        periodo=periodo,
        desde=desde,
        hasta=hasta,
        hoy=hoy,
        total=Cuenta(cumplidos, base, restantes),
        por_dia=cumplimiento_de_varios(habitos, cantidades, todos_los_dias),
        habitos=por_habito,
    )


def por_meses(uno: DeUnHabito, ano: int) -> list[int | None]:
    """El porcentaje de cada mes del año para un hábito: doce valores.

    PARA LA VISTA DEL AÑO: 365 cuadraditos por hábito no caben en un móvil sin
    deslizar, y doce barras sí, y se leen de un vistazo. Con la misma regla
    que todo lo demás: lo que no tocaba no cuenta, lo futuro tampoco, y un mes
    sin nada que cumplir es None, no 0.
    """
    salida: list[int | None] = []
    for mes in range(1, 13):
        cumplidos = base = 0
        for dia, estado in uno.estados.items():
            if dia.year != ano or dia.month != mes:
                continue
            if estado is Estado.CUMPLIDO:
                cumplidos += 1
                base += 1
            elif estado is Estado.FALLADO:
                base += 1
        salida.append(round(cumplidos * 100 / base) if base else None)
    return salida
