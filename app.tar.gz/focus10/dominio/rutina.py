"""La rutina: EL PLAN. Qué toca cada día de la semana y con qué series objetivo.

ESTO NO ES LA SESIÓN. La rutina dice "los lunes hago press de banca, 4 series de
8 a 60 kg". La sesión dice "el 17 de agosto hice 4 series y en la última solo
saqué 6". Son dos cosas y viven en dos tablas.

POR QUÉ IMPORTA TANTO, con las palabras del usuario: si la sesión editara la
rutina, cambiar el peso un mal día te reescribiría el plan para siempre; y si
fueran lo mismo, no habría forma de saber nunca si cumpliste.

LA RUTINA ES LA ROTACIÓN: se repite cada semana hasta que se cambie. No hay una
rutina por semana ni una por mes: hay SIETE días, y el 17 de agosto usa el día
que le toque por ser domingo.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import date

from .descanso import DESCANSO_MAXIMO, DESCANSO_MINIMO, DURACION_MAXIMA
from .habito import DIAS_SEMANA

LARGO_MAXIMO_NOMBRE = 40

SERIES_MAXIMAS = 20
REPETICIONES_MAXIMAS = 500
PESO_MAXIMO = 100_000
"""En centésimas de kilo: 1.000 kg. Tope de cordura, no de fuerza."""

CENTESIMAS_POR_KILO = 100
"""El peso va en centésimas de kilo enteras: 62,5 kg son 6250.

Enteros y no decimales por lo mismo que el dinero: sumar el volumen de treinta
series en coma flotante acumula un error que luego no cuadra. Centésimas y no
décimas porque existen los discos de 0,25 kg.
"""


@dataclass(frozen=True)
class EjercicioPlaneado:
    """Un ejercicio dentro de un día de la rutina, con lo que pretendo hacer."""

    ejercicio_id: int
    nombre: str
    """Copiado de la biblioteca. Se guarda aquí también para que el plan se siga
    leyendo si el ejercicio se borra de la biblioteca."""

    orden: int = 0
    series_objetivo: int = 3
    repeticiones_objetivo: int = 10
    peso_objetivo: int = 0
    """En centésimas de kilo. Cero es válido: peso corporal, o todavía no lo sé."""

    segundos_objetivo: int | None = None
    """Cuánto dura cada serie, para los ejercicios que se miden en TIEMPO.

    LA PLANCHA Y EL CARDIO no tienen repeticiones ni peso: tienen minutos. Sin
    este campo, el plan de una caminata en cinta enseñaba casillas de peso y de
    repeticiones que no querían decir nada.

    None quiere decir que ahí no se dijo nada, igual que en el descanso. En los
    ejercicios que se miden en peso × repeticiones se queda a None siempre: es
    que no aplica.
    """

    descanso: int | None = None
    """Segundos de descanso entre series de ESTE ejercicio en ESTE día.

    LO ELIGE LA PERSONA, no la ficha del ejercicio. Lo pidió así el usuario: "en
    este ejercicio quiero descansar treinta segundos, en este un minuto y
    medio". La ficha solo aporta el valor de partida al añadirlo al día.

    None quiere decir "aquí no se dijo nada", y eso NO es lo mismo que cero: un
    cero es un descanso de cero segundos elegido a propósito (el cardio), y un
    None es un hueco que se rellena con el de la ficha. Confundirlos dejaría los
    ejercicios viejos sin cronómetro.
    """

    id: int | None = None

    def __post_init__(self) -> None:
        _exigir_entero("ejercicio_id", self.ejercicio_id)
        if self.ejercicio_id <= 0:
            raise ValueError("ejercicio_id tiene que ser mayor que cero")

        if not isinstance(self.nombre, str) or not self.nombre.strip():
            raise ValueError("el nombre del ejercicio no puede estar vacío")
        object.__setattr__(self, "nombre", self.nombre.strip())

        _exigir_entero("series_objetivo", self.series_objetivo)
        if not 1 <= self.series_objetivo <= SERIES_MAXIMAS:
            raise ValueError(f"las series van de 1 a {SERIES_MAXIMAS}")

        _exigir_entero("repeticiones_objetivo", self.repeticiones_objetivo)
        if not 0 <= self.repeticiones_objetivo <= REPETICIONES_MAXIMAS:
            raise ValueError(f"las repeticiones van de 0 a {REPETICIONES_MAXIMAS}")

        _exigir_entero("peso_objetivo", self.peso_objetivo)
        if not 0 <= self.peso_objetivo <= PESO_MAXIMO:
            raise ValueError("ese peso no es razonable")

        _exigir_entero("orden", self.orden)
        if self.orden < 0:
            raise ValueError("orden no puede ser negativo")

        if self.descanso is not None:
            _exigir_entero("descanso", self.descanso)
            if not DESCANSO_MINIMO <= self.descanso <= DESCANSO_MAXIMO:
                raise ValueError(
                    f"el descanso va de {DESCANSO_MINIMO} a {DESCANSO_MAXIMO} "
                    "segundos"
                )

        if self.segundos_objetivo is not None:
            _exigir_entero("segundos_objetivo", self.segundos_objetivo)
            if not 0 <= self.segundos_objetivo <= DURACION_MAXIMA:
                raise ValueError(
                    f"la duración va de 0 a {DURACION_MAXIMA} segundos"
                )

    def texto_objetivo(self) -> str:
        """"4 × 8 a 60 kg", o "3 × 0:45" si el ejercicio se mide en tiempo.

        LOS DE TIEMPO SE LEEN DISTINTO porque son otra cosa: "3 × 10" en una
        cinta de correr no quiere decir nada. Se mira `segundos_objetivo`, que
        solo está puesto en los ejercicios de tiempo.
        """
        if self.segundos_objetivo is not None:
            from .descanso import texto_duracion

            duracion = texto_duracion(self.segundos_objetivo)
            if self.series_objetivo <= 1:
                return duracion
            return f"{self.series_objetivo} × {duracion}"

        base = f"{self.series_objetivo} × {self.repeticiones_objetivo}"
        if not self.peso_objetivo:
            return base
        return f"{base} a {texto_peso(self.peso_objetivo)}"


@dataclass(frozen=True)
class DiaDeRutina:
    """Lo que toca un día de la semana. Siempre existen los siete."""

    dia: int
    """Lunes 0 ... domingo 6, como en los hábitos."""

    nombre: str = ""
    color: str = "azul"
    es_descanso: bool = False
    ejercicios: tuple[EjercicioPlaneado, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        _exigir_entero("dia", self.dia)
        if not 0 <= self.dia <= 6:
            raise ValueError("el día va de 0 (lunes) a 6 (domingo)")

        if not isinstance(self.nombre, str):
            raise TypeError("el nombre tiene que ser texto")
        if len(self.nombre.strip()) > LARGO_MAXIMO_NOMBRE:
            raise ValueError(
                f"el nombre no puede pasar de {LARGO_MAXIMO_NOMBRE} caracteres"
            )
        object.__setattr__(self, "nombre", self.nombre.strip())

        from .habito import COLORES

        if self.color not in COLORES:
            raise ValueError(f"color desconocido: {self.color!r}")

        if not isinstance(self.es_descanso, bool):
            raise TypeError("es_descanso tiene que ser True o False")

        if not isinstance(self.ejercicios, tuple):
            raise TypeError("los ejercicios tienen que venir en una tupla")
        if self.es_descanso and self.ejercicios:
            # Un día de descanso con ejercicios dentro es un día que no se sabe
            # si es descanso o no, y el calendario tendría que elegir por su
            # cuenta qué pintar.
            raise ValueError("un día de descanso no lleva ejercicios")

    @property
    def letra(self) -> str:
        return DIAS_SEMANA[self.dia][1]

    @property
    def nombre_del_dia(self) -> str:
        return DIAS_SEMANA[self.dia][2]

    @property
    def hay_entreno(self) -> bool:
        """Si ese día toca ir. Un día sin ejercicios no cuenta como entreno
        aunque no esté marcado como descanso: no habría nada que hacer."""
        return not self.es_descanso and bool(self.ejercicios)

    def titulo(self) -> str:
        if self.es_descanso:
            return self.nombre or "Descanso"
        return self.nombre or "Sin asignar"


def dia_de(fecha: date, rutina: dict[int, DiaDeRutina]) -> DiaDeRutina:
    """Qué toca esa fecha, según el día de la semana que sea.

    Es lo que hace de la rutina una ROTACIÓN: el mismo lunes se repite cada
    semana hasta que se cambie el plan.
    """
    numero = fecha.weekday()
    return rutina.get(numero) or DiaDeRutina(dia=numero)


def mover(
    ejercicios: tuple[EjercicioPlaneado, ...], indice: int, hacia_arriba: bool
) -> tuple[EjercicioPlaneado, ...]:
    """Sube o baja un ejercicio dentro del día, y renumera el orden.

    CON FLECHAS Y NO CON ARRASTRE, y lo eligió el usuario con estas palabras:
    "prefiero flechas que funcionen a un arrastre que falle". Flet 0.86 tiene
    arrastre, pero dentro de una lista que se repinta entera con cada cambio es
    frágil de un modo que no compensa.

    Devuelve la lista tal cual si el movimiento no cabe: subir el primero no es
    un error, es que ya está arriba.
    """
    lista = list(ejercicios)
    if not 0 <= indice < len(lista):
        raise IndexError(f"no hay ningún ejercicio en la posición {indice}")

    destino = indice - 1 if hacia_arriba else indice + 1
    if not 0 <= destino < len(lista):
        return ejercicios

    lista[indice], lista[destino] = lista[destino], lista[indice]
    return renumerar(tuple(lista))


def renumerar(ejercicios: tuple[EjercicioPlaneado, ...]) -> tuple[EjercicioPlaneado, ...]:
    """Deja el orden como 0, 1, 2... según la posición en la lista.

    Sin esto, borrar el de en medio dejaría huecos (0, 2, 3) y el siguiente
    reordenado saldría con dos ejercicios compartiendo número.
    """
    return tuple(
        replace(uno, orden=numero) for numero, uno in enumerate(ejercicios)
    )


def texto_peso(centesimas: int) -> str:
    """6250 -> "62,5 kg". Sin decimal cuando es redondo: "60 kg", no "60,00 kg"."""
    if isinstance(centesimas, bool) or not isinstance(centesimas, int):
        raise TypeError("el peso tiene que ser un entero de centésimas de kilo")
    signo = "-" if centesimas < 0 else ""
    kilos, resto = divmod(abs(centesimas), CENTESIMAS_POR_KILO)
    if not resto:
        return f"{signo}{kilos} kg"
    decimales = f"{resto:02d}".rstrip("0")
    return f"{signo}{kilos},{decimales} kg"


def parsear_peso(texto: str) -> int | None:
    """"62,5" -> 6250. None si no se entiende, para poder avisar sin adivinar."""
    if not isinstance(texto, str):
        return None
    limpio = texto.strip().lower().replace("kg", "").replace(" ", "")
    if not limpio:
        return 0
    limpio = limpio.replace(",", ".")
    if limpio.count(".") > 1 or not limpio.replace(".", "").isdigit():
        return None
    if "." not in limpio:
        return int(limpio) * CENTESIMAS_POR_KILO
    enteros, decimales = limpio.split(".")
    if len(decimales) > 2:
        return None
    return int(enteros or 0) * CENTESIMAS_POR_KILO + int(decimales.ljust(2, "0"))


def _exigir_entero(nombre: str, valor) -> None:
    if isinstance(valor, bool) or not isinstance(valor, int):
        raise TypeError(f"{nombre} tiene que ser un entero")
