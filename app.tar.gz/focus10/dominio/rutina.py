"""La rutina: EL PLAN. Qué toca cada día de la semana y con qué series objetivo.

ESTO NO ES LA SESIÓN. La rutina dice "los lunes hago press de banca, 4 series de
8 a 60 kg". La sesión dice "el 17 de agosto hice 4 series y en la última solo
saqué 6". Son dos cosas y viven en dos tablas.

POR QUÉ IMPORTA TANTO, con las palabras del usuario: si la sesión editara la
rutina, cambiar el peso un mal día te reescribiría el plan para siempre; y si
fueran lo mismo, no habría forma de saber nunca si cumpliste.

LA RUTINA ES LA ROTACIÓN: se repite cada semana hasta que se cambie. No hay una
rutina por semana ni una por mes: hay SIETE días, y el 17 de agosto usa el día
que le toque por ser domingo.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import date

from .descanso import DESCANSO_MAXIMO, DESCANSO_MINIMO, DURACION_MAXIMA
from .habito import exigir_color
from .semana import DIAS, LETRAS
from .validar import exigir_entero

LARGO_MAXIMO_NOMBRE = 40

SERIES_MAXIMAS = 20
REPETICIONES_MAXIMAS = 500
PESO_MAXIMO = 100_000
"""En centésimas de kilo: 1.000 kg. Tope de cordura, no de fuerza."""

BLOQUES_MAXIMOS = 10
"""Tope de cordura: diez entrenamientos distintos en un mismo dia ya no es un
dia, es una lista de la compra."""

NOMBRE_BLOQUE_POR_DEFECTO = "Entrenamiento"
"""Como se llama un bloque al que no se le puso nombre, y como se llamo el unico
bloque que se creo al convertir las rutinas que ya existian."""

CENTESIMAS_POR_KILO = 100
"""El peso va en centésimas de kilo enteras: 62,5 kg son 6250.

Enteros y no decimales por lo mismo que el dinero: sumar el volumen de treinta
series en coma flotante acumula un error que luego no cuadra. Centésimas y no
décimas porque existen los discos de 0,25 kg.
"""


@dataclass(frozen=True)
class SeriePlaneada:
    """UNA serie del plan, con su propio peso y sus propias repeticiones.

    POR QUE EXISTE, con las palabras del usuario: "las series pueden ser
    distintas entre si". Antes el plan decia "3 x 10 a 60 kg" y punto, asi que
    una piramide —60x10, 65x8, 70x6— no se podia escribir: habia que apuntar la
    del medio y acordarse de las otras dos.

    LA NUMERACION EMPIEZA EN 1 porque es lo que se ve en pantalla: "Serie 1",
    no "Serie 0". Quien las guarda las renumera; aqui solo se comprueba.
    """

    numero: int
    repeticiones: int = 10
    peso: int = 0
    """En centesimas de kilo. Cero vale: peso corporal, o todavia no lo se."""

    segundos: int | None = None
    """Para los ejercicios que se miden en TIEMPO. None es "aqui no aplica"."""

    id: int | None = None

    def __post_init__(self) -> None:
        exigir_entero("numero", self.numero)
        if self.numero < 1:
            raise ValueError("las series se numeran desde 1")

        exigir_entero("repeticiones", self.repeticiones)
        if not 0 <= self.repeticiones <= REPETICIONES_MAXIMAS:
            raise ValueError(f"las repeticiones van de 0 a {REPETICIONES_MAXIMAS}")

        exigir_entero("peso", self.peso)
        if not 0 <= self.peso <= PESO_MAXIMO:
            raise ValueError("ese peso no es razonable")

        if self.segundos is not None:
            exigir_entero("segundos", self.segundos)
            if not 0 <= self.segundos <= DURACION_MAXIMA:
                raise ValueError(
                    f"la duracion va de 0 a {DURACION_MAXIMA} segundos"
                )

    def texto(self) -> str:
        """Lo que se lee en la fila de la serie: "10 x 60 kg", o "0:45"."""
        if self.segundos is not None:
            from .descanso import texto_duracion

            return texto_duracion(self.segundos)
        if not self.peso:
            return f"{self.repeticiones} reps"
        return f"{self.repeticiones} × {texto_peso(self.peso)}"


@dataclass(frozen=True)
class EjercicioPlaneado:
    """Un ejercicio dentro de un día de la rutina, con lo que pretendo hacer."""

    ejercicio_id: int
    nombre: str
    """Copiado de la biblioteca. Se guarda aquí también para que el plan se siga
    leyendo si el ejercicio se borra de la biblioteca."""

    orden: int = 0
    series_objetivo: int = 3
    repeticiones_objetivo: int = 10
    peso_objetivo: int = 0
    """En centésimas de kilo. Cero es válido: peso corporal, o todavía no lo sé."""

    segundos_objetivo: int | None = None
    """Cuánto dura cada serie, para los ejercicios que se miden en TIEMPO.

    LA PLANCHA Y EL CARDIO no tienen repeticiones ni peso: tienen minutos. Sin
    este campo, el plan de una caminata en cinta enseñaba casillas de peso y de
    repeticiones que no querían decir nada.

    None quiere decir que ahí no se dijo nada, igual que en el descanso. En los
    ejercicios que se miden en peso × repeticiones se queda a None siempre: es
    que no aplica.
    """

    descanso: int | None = None
    """Segundos de descanso entre series de ESTE ejercicio en ESTE día.

    LO ELIGE LA PERSONA, no la ficha del ejercicio. Lo pidió así el usuario: "en
    este ejercicio quiero descansar treinta segundos, en este un minuto y
    medio". La ficha solo aporta el valor de partida al añadirlo al día.

    None quiere decir "aquí no se dijo nada", y eso NO es lo mismo que cero: un
    cero es un descanso de cero segundos elegido a propósito (el cardio), y un
    None es un hueco que se rellena con el de la ficha. Confundirlos dejaría los
    ejercicios viejos sin cronómetro.
    """

    series: tuple[SeriePlaneada, ...] = ()
    """CADA SERIE CON SU PESO Y SUS REPETICIONES. Es la lista de verdad.

    LOS TRES CAMPOS DE ARRIBA (series_objetivo, repeticiones_objetivo,
    peso_objetivo) SON UN ATAJO, no otra fuente de datos: si no se pasan series,
    se construyen aqui N series iguales a partir de ellos; y si se pasan, esos
    tres se recalculan desde la primera serie. Nunca pueden contradecirse porque
    nunca se guardan por separado.

    SE MANTIENE EL ATAJO a proposito. La mitad del programa —el resumen del
    dia, el tablero, empezar una sesion— solo quiere saber "cuantas series y de
    cuanto", y obligar a todo eso a recorrer la lista para preguntarlo habria
    sido cambiar cincuenta sitios para no ganar nada.
    """

    id: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.series, tuple):
            raise TypeError("las series tienen que venir en una tupla")

        # ESTO VA LO PRIMERO A PROPOSITO. Si se pasaron series, mandan ellas, y
        # lo que traigan los tres campos del atajo no significa nada: hay que
        # recalcularlos ANTES de comprobarlos, o se estaria rechazando un
        # ejercicio perfecto por un atajo que se iba a tirar de todas formas.
        if self.series:
            if len(self.series) > SERIES_MAXIMAS:
                raise ValueError(f"las series van de 1 a {SERIES_MAXIMAS}")
            # Se renumeran 1, 2, 3... para que borrar la del medio no deje un
            # hueco que luego se lea como "serie 3" habiendo dos.
            series = tuple(
                replace(una, numero=cual)
                for cual, una in enumerate(self.series, start=1)
            )
            object.__setattr__(self, "series", series)
            object.__setattr__(self, "series_objetivo", len(series))
            object.__setattr__(self, "repeticiones_objetivo", series[0].repeticiones)
            object.__setattr__(self, "peso_objetivo", series[0].peso)
            object.__setattr__(self, "segundos_objetivo", series[0].segundos)

        exigir_entero("ejercicio_id", self.ejercicio_id)
        if self.ejercicio_id <= 0:
            raise ValueError("ejercicio_id tiene que ser mayor que cero")

        if not isinstance(self.nombre, str) or not self.nombre.strip():
            raise ValueError("el nombre del ejercicio no puede estar vacío")
        object.__setattr__(self, "nombre", self.nombre.strip())

        exigir_entero("series_objetivo", self.series_objetivo)
        if not 1 <= self.series_objetivo <= SERIES_MAXIMAS:
            raise ValueError(f"las series van de 1 a {SERIES_MAXIMAS}")

        exigir_entero("repeticiones_objetivo", self.repeticiones_objetivo)
        if not 0 <= self.repeticiones_objetivo <= REPETICIONES_MAXIMAS:
            raise ValueError(f"las repeticiones van de 0 a {REPETICIONES_MAXIMAS}")

        exigir_entero("peso_objetivo", self.peso_objetivo)
        if not 0 <= self.peso_objetivo <= PESO_MAXIMO:
            raise ValueError("ese peso no es razonable")

        exigir_entero("orden", self.orden)
        if self.orden < 0:
            raise ValueError("orden no puede ser negativo")

        if self.descanso is not None:
            exigir_entero("descanso", self.descanso)
            if not DESCANSO_MINIMO <= self.descanso <= DESCANSO_MAXIMO:
                raise ValueError(
                    f"el descanso va de {DESCANSO_MINIMO} a {DESCANSO_MAXIMO} "
                    "segundos"
                )

        if self.segundos_objetivo is not None:
            exigir_entero("segundos_objetivo", self.segundos_objetivo)
            if not 0 <= self.segundos_objetivo <= DURACION_MAXIMA:
                raise ValueError(
                    f"la duración va de 0 a {DURACION_MAXIMA} segundos"
                )

        if not self.series:
            # NO SE PASARON SERIES: se construyen N iguales desde el atajo. Es
            # como entran los ejercicios recien anadidos y los que se leyeron de
            # una base de antes de que las series existieran.
            object.__setattr__(
                self,
                "series",
                tuple(
                    SeriePlaneada(
                        numero=cual,
                        repeticiones=self.repeticiones_objetivo,
                        peso=self.peso_objetivo,
                        segundos=self.segundos_objetivo,
                    )
                    for cual in range(1, self.series_objetivo + 1)
                ),
            )

    @property
    def series_variadas(self) -> bool:
        """Si las series NO son todas iguales. Lo mira quien tiene que decidir
        si le vale con "3 x 10" o tiene que ensenarlas una a una."""
        if len(self.series) <= 1:
            return False
        primera = self.series[0]
        return any(
            una.repeticiones != primera.repeticiones
            or una.peso != primera.peso
            or una.segundos != primera.segundos
            for una in self.series[1:]
        )

    def texto_objetivo(self) -> str:
        """"4 × 8 a 60 kg", o "3 × 0:45" si el ejercicio se mide en tiempo.

        LOS DE TIEMPO SE LEEN DISTINTO porque son otra cosa: "3 × 10" en una
        cinta de correr no quiere decir nada. Se mira `segundos_objetivo`, que
        solo está puesto en los ejercicios de tiempo.
        """
        if self.series_variadas:
            # UNA PIRAMIDE NO SE PUEDE RESUMIR EN "3 x 10": mentiria. Se da el
            # rango, que es lo unico honesto que cabe en una linea; las series
            # de verdad se ven una a una al abrir el ejercicio.
            return self._texto_variado()

        if self.segundos_objetivo is not None:
            from .descanso import texto_duracion

            duracion = texto_duracion(self.segundos_objetivo)
            if self.series_objetivo <= 1:
                return duracion
            return f"{self.series_objetivo} × {duracion}"

        base = f"{self.series_objetivo} × {self.repeticiones_objetivo}"
        if not self.peso_objetivo:
            return base
        return f"{base} a {texto_peso(self.peso_objetivo)}"

    def _texto_variado(self) -> str:
        """"3 series · 6-10 reps · 60-70 kg" cuando cada serie es distinta."""
        cuantas = f"{len(self.series)} series"
        if self.segundos_objetivo is not None:
            from .descanso import texto_duracion

            tiempos = [una.segundos or 0 for una in self.series]
            return (
                f"{cuantas} · {texto_duracion(min(tiempos))}"
                f"-{texto_duracion(max(tiempos))}"
            )

        repes = [una.repeticiones for una in self.series]
        trozos = [cuantas]
        if min(repes) == max(repes):
            trozos.append(f"{min(repes)} reps")
        else:
            trozos.append(f"{min(repes)}-{max(repes)} reps")

        pesos = [una.peso for una in self.series]
        if any(pesos):
            if min(pesos) == max(pesos):
                trozos.append(texto_peso(min(pesos)))
            else:
                # "60-70 kg", no "60 kg-70 kg": la unidad una sola vez.
                sin_unidad = texto_peso(min(pesos)).replace(" kg", "")
                trozos.append(f"{sin_unidad}-{texto_peso(max(pesos))}")
        return " · ".join(trozos)


@dataclass(frozen=True)
class BloqueDeRutina:
    """Un entrenamiento dentro de un dia. El lunes puede tener varios.

    POR QUE EXISTE, con las palabras del usuario: "el lunes es un apartado, no
    es SOLO un entrenamiento; dentro de Lunes debo poder poner diferentes
    entrenamientos tipo GYM, Movilidad...". Antes un dia era una sola lista de
    ejercicios, asi que hacer pesas por la manana y movilidad por la noche
    obligaba a mezclarlo todo en una fila detras de otra.

    EL NOMBRE LO PONE LA PERSONA, libre, y lo eligio asi el usuario. No es una
    lista cerrada como los grupos musculares porque un bloque es un rotulo tuyo
    —"GYM", "Movilidad", "Cardio suave"—, no un dato que luego haya que agrupar
    en ninguna estadistica.
    """

    nombre: str = NOMBRE_BLOQUE_POR_DEFECTO
    orden: int = 0
    ejercicios: tuple[EjercicioPlaneado, ...] = field(default_factory=tuple)
    id: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.nombre, str):
            raise TypeError("el nombre del bloque tiene que ser texto")
        limpio = self.nombre.strip()
        if len(limpio) > LARGO_MAXIMO_NOMBRE:
            raise ValueError(
                f"el nombre no puede pasar de {LARGO_MAXIMO_NOMBRE} caracteres"
            )
        # UN BLOQUE SIN NOMBRE NO SE PUEDE SENALAR. Si el dia tiene dos y uno no
        # se llama de ninguna forma, no hay manera de decir en cual estas.
        object.__setattr__(self, "nombre", limpio or NOMBRE_BLOQUE_POR_DEFECTO)

        exigir_entero("orden", self.orden)
        if self.orden < 0:
            raise ValueError("orden no puede ser negativo")

        if not isinstance(self.ejercicios, tuple):
            raise TypeError("los ejercicios tienen que venir en una tupla")


@dataclass(frozen=True)
class DiaDeRutina:
    """Lo que toca un día de la semana. Siempre existen los siete."""

    dia: int
    """Lunes 0 ... domingo 6, como en los hábitos."""

    nombre: str = ""
    color: str = "azul"
    es_descanso: bool = False
    bloques: tuple[BloqueDeRutina, ...] = field(default_factory=tuple)
    """Los entrenamientos del dia. Es la lista de verdad."""

    ejercicios: tuple[EjercicioPlaneado, ...] = field(default_factory=tuple)
    """TODOS los ejercicios del dia seguidos, sin importar de que bloque sean.

    ES UN ATAJO DE LECTURA, igual que las series: se calcula desde los bloques y
    no se guarda aparte. Lo usan el tablero, el resumen del dia y empezar una
    sesion, a los que solo les importa "que toca hoy" y no en que bloque estaba.

    TAMBIEN SE PUEDE PASAR AL CREARLO, y entonces se mete todo en un unico
    bloque. Es como se leen las rutinas de antes de que los bloques existieran, y
    lo que hace que la mitad del programa no se entere del cambio.
    """

    def __post_init__(self) -> None:
        exigir_entero("dia", self.dia)
        if not 0 <= self.dia <= 6:
            raise ValueError("el día va de 0 (lunes) a 6 (domingo)")

        if not isinstance(self.nombre, str):
            raise TypeError("el nombre tiene que ser texto")
        if len(self.nombre.strip()) > LARGO_MAXIMO_NOMBRE:
            raise ValueError(
                f"el nombre no puede pasar de {LARGO_MAXIMO_NOMBRE} caracteres"
            )
        object.__setattr__(self, "nombre", self.nombre.strip())

        exigir_color(self.color)

        if not isinstance(self.es_descanso, bool):
            raise TypeError("es_descanso tiene que ser True o False")

        if not isinstance(self.ejercicios, tuple):
            raise TypeError("los ejercicios tienen que venir en una tupla")
        if not isinstance(self.bloques, tuple):
            raise TypeError("los bloques tienen que venir en una tupla")
        if len(self.bloques) > BLOQUES_MAXIMOS:
            raise ValueError(f"un dia no lleva mas de {BLOQUES_MAXIMOS} bloques")

        if self.bloques:
            # SI SE PASAN LAS DOS COSAS Y NO DICEN LO MISMO, SE PARA AQUI.
            #
            # ESTO SALTO DE VERDAD Y POR ESO ESTA ESCRITO: la pantalla de la
            # rutina cambiaba un ejercicio con
            # `replace(dia, ejercicios=nuevos)`, y `replace` arrastra los
            # bloques de antes sin que se vea. Como mandan los bloques, el
            # cambio se tiraba a la basura EN SILENCIO: el usuario escribia un
            # descanso, la pantalla se repintaba igual que estaba y no habia
            # ningun error en ninguna parte.
            #
            # Fallar aqui a gritos es lo unico que convierte eso en algo que se
            # nota el mismo dia que se escribe.
            aplanado = tuple(
                uno for bloque in self.bloques for uno in bloque.ejercicios
            )
            if self.ejercicios and self.ejercicios != aplanado:
                raise ValueError(
                    "no se puede cambiar 'ejercicios' de un dia que ya tiene "
                    "bloques: hay que cambiar el bloque que los lleva"
                )

            # MANDAN LOS BLOQUES. Se renumeran por su posicion, por lo mismo que
            # las series: borrar el de en medio no puede dejar dos con el mismo
            # numero.
            bloques = tuple(
                replace(uno, orden=numero)
                for numero, uno in enumerate(self.bloques)
            )
            object.__setattr__(self, "bloques", bloques)
            object.__setattr__(
                self,
                "ejercicios",
                tuple(uno for bloque in bloques for uno in bloque.ejercicios),
            )
        elif self.ejercicios:
            # SIN BLOQUES PERO CON EJERCICIOS: es una rutina de las de antes, o
            # alguien que solo queria una lista. Va todo a un bloque.
            object.__setattr__(
                self,
                "bloques",
                (BloqueDeRutina(ejercicios=self.ejercicios),),
            )

        if self.es_descanso and self.ejercicios:
            # Un día de descanso con ejercicios dentro es un día que no se sabe
            # si es descanso o no, y el calendario tendría que elegir por su
            # cuenta qué pintar.
            raise ValueError("un día de descanso no lleva ejercicios")

    def bloque(self, orden: int) -> BloqueDeRutina | None:
        """El bloque que esta en esa posicion, o None si no hay tantos."""
        for uno in self.bloques:
            if uno.orden == orden:
                return uno
        return None

    @property
    def letra(self) -> str:
        return LETRAS[self.dia]

    @property
    def nombre_del_dia(self) -> str:
        return DIAS[self.dia]

    @property
    def hay_entreno(self) -> bool:
        """Si ese día toca ir. Un día sin ejercicios no cuenta como entreno
        aunque no esté marcado como descanso: no habría nada que hacer."""
        return not self.es_descanso and bool(self.ejercicios)

    def titulo(self) -> str:
        if self.es_descanso:
            return self.nombre or "Descanso"
        return self.nombre or "Sin asignar"


def con_bloques(
    dia: DiaDeRutina, bloques: tuple[BloqueDeRutina, ...]
) -> DiaDeRutina:
    """El mismo dia con otros bloques. USAR ESTO Y NO `replace` A PELO.

    POR QUE EXISTE: `replace(dia, bloques=nuevos)` arrastra tambien la lista
    plana de `ejercicios` que tenia el dia antes, y entonces el dia se construye
    con dos listas que no dicen lo mismo. El dominio lo detecta y avisa, pero el
    aviso salta en tiempo de ejecucion y en medio de un clic del usuario. Con
    esta funcion no puede pasar: la lista plana se limpia siempre, y se vuelve a
    calcular desde los bloques.
    """
    return replace(dia, bloques=bloques, ejercicios=())


def con_bloque(
    dia: DiaDeRutina, bloque: BloqueDeRutina, nuevo: BloqueDeRutina
) -> DiaDeRutina:
    """Cambia UN bloque del dia y deja los demas como estaban."""
    return con_bloques(
        dia,
        tuple(nuevo if uno.orden == bloque.orden else uno for uno in dia.bloques),
    )


def con_ejercicios(
    bloque: BloqueDeRutina, ejercicios: tuple[EjercicioPlaneado, ...]
) -> BloqueDeRutina:
    """El mismo bloque con otros ejercicios, renumerados."""
    return replace(bloque, ejercicios=renumerar(ejercicios))


def dia_de(fecha: date, rutina: dict[int, DiaDeRutina]) -> DiaDeRutina:
    """Qué toca esa fecha, según el día de la semana que sea.

    Es lo que hace de la rutina una ROTACIÓN: el mismo lunes se repite cada
    semana hasta que se cambie el plan.
    """
    numero = fecha.weekday()
    return rutina.get(numero) or DiaDeRutina(dia=numero)


def mover(
    ejercicios: tuple[EjercicioPlaneado, ...], indice: int, hacia_arriba: bool
) -> tuple[EjercicioPlaneado, ...]:
    """Sube o baja un ejercicio dentro del día, y renumera el orden.

    CON FLECHAS Y NO CON ARRASTRE, y lo eligió el usuario con estas palabras:
    "prefiero flechas que funcionen a un arrastre que falle". Flet 0.86 tiene
    arrastre, pero dentro de una lista que se repinta entera con cada cambio es
    frágil de un modo que no compensa.

    Devuelve la lista tal cual si el movimiento no cabe: subir el primero no es
    un error, es que ya está arriba.
    """
    lista = list(ejercicios)
    if not 0 <= indice < len(lista):
        raise IndexError(f"no hay ningún ejercicio en la posición {indice}")

    destino = indice - 1 if hacia_arriba else indice + 1
    if not 0 <= destino < len(lista):
        return ejercicios

    lista[indice], lista[destino] = lista[destino], lista[indice]
    return renumerar(tuple(lista))


def renumerar(ejercicios: tuple[EjercicioPlaneado, ...]) -> tuple[EjercicioPlaneado, ...]:
    """Deja el orden como 0, 1, 2... según la posición en la lista.

    Sin esto, borrar el de en medio dejaría huecos (0, 2, 3) y el siguiente
    reordenado saldría con dos ejercicios compartiendo número.
    """
    return tuple(
        replace(uno, orden=numero) for numero, uno in enumerate(ejercicios)
    )


def texto_peso(centesimas: int) -> str:
    """6250 -> "62,5 kg". Sin decimal cuando es redondo: "60 kg", no "60,00 kg"."""
    if isinstance(centesimas, bool) or not isinstance(centesimas, int):
        raise TypeError("el peso tiene que ser un entero de centésimas de kilo")
    signo = "-" if centesimas < 0 else ""
    kilos, resto = divmod(abs(centesimas), CENTESIMAS_POR_KILO)
    if not resto:
        return f"{signo}{kilos} kg"
    decimales = f"{resto:02d}".rstrip("0")
    return f"{signo}{kilos},{decimales} kg"


def parsear_peso(texto: str) -> int | None:
    """"62,5" -> 6250. None si no se entiende, para poder avisar sin adivinar."""
    if not isinstance(texto, str):
        return None
    limpio = texto.strip().lower().replace("kg", "").replace(" ", "")
    if not limpio:
        return 0
    limpio = limpio.replace(",", ".")
    if limpio.count(".") > 1 or not limpio.replace(".", "").isdigit():
        return None
    if "." not in limpio:
        return int(limpio) * CENTESIMAS_POR_KILO
    enteros, decimales = limpio.split(".")
    if len(decimales) > 2:
        return None
    return int(enteros or 0) * CENTESIMAS_POR_KILO + int(decimales.ljust(2, "0"))

