"""Lo que comparten todas las anotaciones de dinero.

QUÉ COMPARTEN: un movimiento (un gasto) y un saldo (cuánto llevas ahorrado) son
cosas distintas —uno es dinero que se mueve, el otro una foto de lo que hay— pero
las dos se anotan en un momento, pertenecen a una jornada, van en una moneda y
pueden quedarse pendientes de convertir. Esas cuatro reglas viven aquí.

POR QUÉ FUNCIONES SUELTAS Y NO UNA CLASE MADRE DE LA QUE HEREDEN: heredar diría
que un saldo "es un tipo de movimiento", y no lo es. Compartir las comprobaciones
sin emparentar los conceptos deja claro qué tienen en común (las reglas del
dinero) y qué no (lo que significan).
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from .cambio import TASA_UNO, convertir
from .moneda import Moneda


def exigir_momento(momento: datetime) -> None:
    """El momento va en hora local, sin zona horaria y con precisión de segundo."""
    if not isinstance(momento, datetime):
        raise TypeError(f"momento tiene que ser un datetime, no {type(momento).__name__}")
    if momento.tzinfo is not None:
        raise ValueError("el momento va en hora local, sin zona horaria")
    if momento.microsecond:
        # Se guarda como "2025-08-19 03:00:00". Admitir microsegundos sería
        # perderlos al guardar sin avisar, y entonces lo que hay en memoria y lo
        # leído de la base de datos dejarían de ser iguales.
        raise ValueError(
            "el momento se guarda al segundo; quita los microsegundos "
            f"(llegaron {momento.microsecond})"
        )


def exigir_jornada(jornada: date) -> None:
    """La jornada es un día sin hora."""
    # datetime hereda de date, así que hay que descartarlo expresamente: una
    # jornada con hora dentro sería un dato distinto del que se espera.
    if not isinstance(jornada, date) or isinstance(jornada, datetime):
        raise TypeError("jornada tiene que ser un date, no un datetime")


def exigir_conversion(tasa: Decimal | None, importe_principal: int | None) -> None:
    """La tasa y el importe convertido van juntos, o no va ninguno.

    Un apunte con tasa pero sin importe convertido (o al revés) sería un dato
    imposible que rompería cualquier total.
    """
    if (tasa is None) != (importe_principal is None):
        raise ValueError(
            "tasa e importe_principal van juntos: o los dos puestos "
            "(convertido) o los dos a None (pendiente de cambio)"
        )
    if tasa is None:
        return

    if isinstance(tasa, float) or not isinstance(tasa, Decimal):
        raise TypeError("la tasa tiene que ser Decimal")
    if not tasa.is_finite() or tasa <= 0:
        raise ValueError(f"tasa inválida: {tasa}")
    if isinstance(importe_principal, bool) or not isinstance(importe_principal, int):
        raise TypeError("importe_principal tiene que ser int")
    if importe_principal < 0:
        # Puede ser 0 (un importe minúsculo que al convertir se queda en nada),
        # pero nunca negativo.
        raise ValueError("importe_principal no puede ser negativo")


def resolver_conversion(
    importe: int, moneda: Moneda, principal: Moneda, tasa: Decimal | None
) -> tuple[Decimal | None, int | None]:
    """Decide la tasa y el importe convertido de un apunte recién creado.

    - Si la moneda ES la principal, la tasa es 1 y no hace falta internet.
    - Si es otra y se pasa una tasa, se convierte.
    - Si es otra y no hay tasa, queda pendiente: se devuelven los dos a None.
    """
    if moneda == principal:
        if tasa is not None and tasa != TASA_UNO:
            raise ValueError(
                f"un apunte en {moneda.codigo}, que es la moneda principal, "
                f"no lleva tasa: llegó {tasa}"
            )
        return TASA_UNO, importe

    if tasa is not None:
        return tasa, convertir(importe, moneda, principal, tasa)

    return None, None
