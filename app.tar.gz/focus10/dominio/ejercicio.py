"""La biblioteca de ejercicios: la DEFINICIÓN de cada movimiento.

TRES COSAS QUE NO SON LO MISMO, y este archivo es la primera de las tres:

  EJERCICIO  la definición. "Press de banca con barra". Existe una vez.
  RUTINA     el plan. "Los lunes, estos cinco con estas series objetivo".
  SESIÓN     lo que hice de verdad el 17 de agosto.

Están en tres archivos y en tres tablas a propósito, desde el primer día. Lo
avisó el usuario y tiene toda la razón: si la sesión editara la rutina, cambiar
el peso un mal día te reescribiría el plan para siempre; y si fueran lo mismo,
no habría forma de saber nunca si cumpliste.

BORRAR UN EJERCICIO NO BORRA EL HISTORIAL. Las sesiones guardan el NOMBRE además
de la referencia, así que un entreno de hace dos años se sigue leyendo aunque
hoy limpies la biblioteca. Perder dos años de registro por ordenar una lista
sería mucho peor que tener un nombre repetido en dos sitios.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

LARGO_MAXIMO_NOMBRE = 80
LARGO_MAXIMO_NOTAS = 1000

DESCANSO_MINIMO = 0
DESCANSO_MAXIMO = 30 * 60
"""Media hora. Más que eso no es un descanso entre series, es otro entreno."""

DESCANSO_POR_OMISION = 90


class Grupo(StrEnum):
    """Los grupos en los que se reparte todo lo que se puede entrenar.

    CERRADOS A PROPÓSITO, como los colores: una lista abierta acaba con
    "piernas", "pierna" y "Pierna" como tres grupos distintos, y entonces la
    pantalla de "qué estoy descuidando" deja de significar nada.

    ERAN OCHO Y AHORA SON DIEZ. El usuario echó en falta el antebrazo y los
    estiramientos, y tenía razón: no había dónde meterlos.

    MOVILIDAD NO ES UN MÚSCULO, y se sabe. Es una forma de entrenar, no una
    parte del cuerpo. Pero meterla aquí es lo que hace que un estiramiento
    tenga dónde vivir, y que un día de rutina pueda ser de movilidad sin
    inventar otra clasificación en paralelo. Si algún día estorba, se separa.
    """

    PECHO = "pecho"
    ESPALDA = "espalda"
    PIERNA = "pierna"
    HOMBRO = "hombro"
    BICEPS = "bíceps"
    TRICEPS = "tríceps"
    ANTEBRAZO = "antebrazo"
    CORE = "core"
    CARDIO = "cardio"
    MOVILIDAD = "movilidad"


class Material(StrEnum):
    BARRA = "barra"
    MANCUERNAS = "mancuernas"
    MAQUINA = "máquina"
    POLEA = "polea"
    PESO_CORPORAL = "peso corporal"


class Medida(StrEnum):
    """Cómo se mide este ejercicio. Decide qué columnas tiene su tabla."""

    PESO_REPETICIONES = "peso × repeticiones"
    TIEMPO = "tiempo"
    """La plancha y el cardio: no tiene sentido preguntar cuántas repeticiones
    de correr has hecho."""

    @property
    def es_de_tiempo(self) -> bool:
        return self is Medida.TIEMPO


@dataclass(frozen=True)
class Ejercicio:
    nombre: str
    grupo: Grupo
    material: Material = Material.BARRA
    secundarios: frozenset[Grupo] = field(default_factory=frozenset)
    """Grupos que también trabaja. Opcional."""

    descanso: int = DESCANSO_POR_OMISION
    """Segundos. Es lo que carga el cronómetro al marcar una serie."""

    notas: str = ""
    """Mías: técnica, altura del asiento, lo que sea."""

    medida: Medida = Medida.PESO_REPETICIONES
    id: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.nombre, str):
            raise TypeError("el nombre tiene que ser texto")
        limpio = self.nombre.strip()
        if not limpio:
            raise ValueError("el nombre no puede estar vacío")
        if len(limpio) > LARGO_MAXIMO_NOMBRE:
            raise ValueError(
                f"el nombre no puede pasar de {LARGO_MAXIMO_NOMBRE} caracteres"
            )
        object.__setattr__(self, "nombre", limpio)

        if not isinstance(self.notas, str):
            raise TypeError("las notas tienen que ser texto")
        if len(self.notas.strip()) > LARGO_MAXIMO_NOTAS:
            raise ValueError(
                f"las notas no pueden pasar de {LARGO_MAXIMO_NOTAS} caracteres"
            )
        object.__setattr__(self, "notas", self.notas.strip())

        if not isinstance(self.grupo, Grupo):
            raise TypeError("el grupo tiene que ser un Grupo")
        if not isinstance(self.material, Material):
            raise TypeError("el material tiene que ser un Material")
        if not isinstance(self.medida, Medida):
            raise TypeError("la medida tiene que ser una Medida")

        if not isinstance(self.secundarios, frozenset):
            raise TypeError("los secundarios tienen que ser un frozenset de Grupo")
        if any(not isinstance(uno, Grupo) for uno in self.secundarios):
            raise TypeError("los secundarios tienen que ser Grupo")
        if self.grupo in self.secundarios:
            # Contarlo dos veces inflaría ese grupo en la vista de "qué estoy
            # descuidando", que es justo para lo que sirve el reparto.
            raise ValueError(
                f"«{self.grupo.value}» ya es el grupo principal: no puede estar "
                "además en los secundarios"
            )

        if isinstance(self.descanso, bool) or not isinstance(self.descanso, int):
            raise TypeError("el descanso tiene que ser un entero de segundos")
        if not DESCANSO_MINIMO <= self.descanso <= DESCANSO_MAXIMO:
            raise ValueError(
                f"el descanso va de {DESCANSO_MINIMO} a {DESCANSO_MAXIMO} segundos"
            )

        if self.id is not None:
            if isinstance(self.id, bool) or not isinstance(self.id, int):
                raise TypeError("el id tiene que ser int o None")
            if self.id <= 0:
                raise ValueError("id tiene que ser mayor que cero")

    @property
    def todos_los_grupos(self) -> frozenset[Grupo]:
        return frozenset({self.grupo}) | self.secundarios

    def texto_descanso(self) -> str:
        """"90 s", "2 min", "2 min 30 s"."""
        if self.descanso < 60:
            return f"{self.descanso} s"
        minutos, segundos = divmod(self.descanso, 60)
        return f"{minutos} min {segundos} s" if segundos else f"{minutos} min"

    def resumen(self) -> str:
        return f"{self.grupo.value} · {self.material.value}"


def normalizar_para_buscar(texto: str) -> str:
    """Deja el texto listo para comparar: sin mayúsculas y sin acentos.

    SIN ACENTOS a propósito: nadie escribe "tríceps" con tilde cuando está
    buscando de pie en el gimnasio, y un buscador que no encuentra "triceps" es
    un buscador roto.
    """
    import unicodedata

    if not isinstance(texto, str):
        return ""
    sin_tildes = unicodedata.normalize("NFD", texto.strip().lower())
    return "".join(letra for letra in sin_tildes if unicodedata.category(letra) != "Mn")


def filtrar(
    ejercicios: list[Ejercicio],
    *,
    texto: str = "",
    grupo: Grupo | None = None,
) -> list[Ejercicio]:
    """Los que encajan con lo buscado. Sin texto ni grupo, todos.

    El texto busca DENTRO del nombre, no solo al principio: buscando "banca"
    tiene que salir "Press de banca", que es como lo busca cualquiera.
    """
    buscado = normalizar_para_buscar(texto)
    return [
        uno
        for uno in ejercicios
        if (not buscado or buscado in normalizar_para_buscar(uno.nombre))
        and (grupo is None or grupo is uno.grupo)
    ]


def ordenar(ejercicios: list[Ejercicio]) -> list[Ejercicio]:
    """Por grupo y luego por nombre, para que la lista no baile entre aperturas."""
    orden_de_grupo = {grupo: numero for numero, grupo in enumerate(Grupo)}
    return sorted(
        ejercicios,
        key=lambda uno: (
            orden_de_grupo[uno.grupo],
            normalizar_para_buscar(uno.nombre),
        ),
    )
