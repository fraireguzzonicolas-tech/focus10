"""Lo que un usuario quiere contarte: un fallo, una idea, una queja.

LO PIDIÓ EL USUARIO: una zona en Configuración donde "los diferentes clientes
que tengamos puedan poner: che, esto funciona mal, che, recomendaría esto".

SOLO VIAJA EL TEXTO Y LA VERSIÓN. Lo eligió él y es lo mínimo que sirve: qué te
dicen y de qué versión viene, que es lo que hace falta para poder arreglarlo. Ni
el nombre, ni la comida, ni el dinero, ni nada de la base de datos. Que un
comentario arrastre datos personales sin avisar es la forma más rápida de que
alguien deje de escribir comentarios.

AQUÍ NO SE ENVÍA NADA: esto solo dice si el mensaje vale y lo deja listo. El
envío vive en sistema/comentarios.py, que es el único que toca la red.
"""

from __future__ import annotations

from dataclasses import dataclass

from .validar import exigir_texto

LARGO_MINIMO = 10
"""Menos de esto no es un comentario.

NO ES UN CAPRICHO: un "hola" o un "asdf" enviado sin querer llega igual que uno
de verdad, y cuando llegan veinte no se lee ninguno. Diez letras es la frontera
más baja que deja fuera el ruido sin estorbar a quien tiene algo que decir.
"""

LARGO_MAXIMO = 2000


@dataclass(frozen=True)
class Comentario:
    texto: str
    version: str

    def __post_init__(self) -> None:
        # SIN obligatorio=True A PROPOSITO: el minimo de letras de abajo ya
        # rechaza el vacio, y con un mensaje mejor. Pedirlo dos veces era codigo
        # que no cambiaba nada, y lo destapo romperlo y ver que ningun test se
        # enteraba.
        exigir_texto("el comentario", self.texto, LARGO_MAXIMO)
        limpio = self.texto.strip()
        if len(limpio) < LARGO_MINIMO:
            raise ValueError(
                f"cuéntame un poco más: hacen falta al menos {LARGO_MINIMO} letras"
            )
        object.__setattr__(self, "texto", limpio)

        exigir_texto("la versión", self.version, 20, obligatorio=True)
        object.__setattr__(self, "version", self.version.strip())

    def como_json(self) -> dict:
        """Lo que se manda por la red. Estos dos campos y ni uno más."""
        return {"texto": self.texto, "version": self.version}
