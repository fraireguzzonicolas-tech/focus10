"""Lo que un usuario quiere contarte: un fallo, una idea, una queja.

LO PIDIÓ EL USUARIO: una zona en Configuración donde "los diferentes clientes
que tengamos puedan poner: che, esto funciona mal, che, recomendaría esto".

VIAJAN TRES COSAS: el texto, la versión y TU CORREO. Las dos primeras son lo
mínimo para poder arreglar lo que te pasa; el correo se añadió después, cuando
él pidió poder RESPONDER a los comentarios. Un comentario al que no se puede
contestar deja a quien escribió hablando solo.

Y NADA MÁS: ni el nombre, ni la comida, ni el dinero, ni nada de la base de
datos. Que un comentario arrastre datos personales sin avisar es la forma más
rápida de que alguien deje de escribir comentarios. Por eso los tres campos se
dicen EN PANTALLA antes de escribir.

AQUÍ NO SE ENVÍA NADA: esto solo dice si el mensaje vale y lo deja listo. El
envío vive en sistema/comentarios.py, que es el único que toca la red.
"""

from __future__ import annotations

from dataclasses import dataclass

from .cuenta import CorreoInvalido, exigir_correo
from .validar import exigir_texto

LARGO_MINIMO = 10
"""Menos de esto no es un comentario.

NO ES UN CAPRICHO: un "hola" o un "asdf" enviado sin querer llega igual que uno
de verdad, y cuando llegan veinte no se lee ninguno. Diez letras es la frontera
más baja que deja fuera el ruido sin estorbar a quien tiene algo que decir.
"""

LARGO_MAXIMO = 2000


@dataclass(frozen=True)
class Comentario:
    texto: str
    version: str
    correo: str = ""
    """El de quien escribe, para poder contestarle.

    VACÍO SE ACEPTA a propósito: hubo versiones sin cuentas, y las habrá si
    algún día se compila una sin servicio. Un comentario sin remite sigue
    sirviendo para arreglar el fallo; solo se queda sin respuesta.

    UN CORREO MAL ESCRITO NO TIRA EL COMENTARIO: se manda sin remite. Perder lo
    que alguien acaba de escribir por una arroba mal puesta sería absurdo.
    """

    def __post_init__(self) -> None:
        # SIN obligatorio=True A PROPOSITO: el minimo de letras de abajo ya
        # rechaza el vacio, y con un mensaje mejor. Pedirlo dos veces era codigo
        # que no cambiaba nada, y lo destapo romperlo y ver que ningun test se
        # enteraba.
        exigir_texto("el comentario", self.texto, LARGO_MAXIMO)
        limpio = self.texto.strip()
        if len(limpio) < LARGO_MINIMO:
            raise ValueError(
                f"cuéntame un poco más: hacen falta al menos {LARGO_MINIMO} letras"
            )
        object.__setattr__(self, "texto", limpio)

        exigir_texto("la versión", self.version, 20, obligatorio=True)
        object.__setattr__(self, "version", self.version.strip())

        try:
            object.__setattr__(self, "correo", exigir_correo(self.correo))
        except CorreoInvalido:
            object.__setattr__(self, "correo", "")

    def como_json(self) -> dict:
        """Lo que se manda por la red. Estos campos y ni uno más."""
        cuerpo = {"texto": self.texto, "version": self.version}
        # EL CORREO SOLO VIAJA SI LO HAY. Mandar una cadena vacía obligaría al
        # servidor a distinguir "sin cuenta" de "correo vacío", que es la misma
        # cosa contada de dos formas.
        if self.correo:
            cuerpo["correo"] = self.correo
        return cuerpo
