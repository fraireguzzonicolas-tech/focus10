"""Cuánto llevas ahorrado y cuánto mandado a invertir.

LO PIDIÓ EL USUARIO: "cuando yo pongo uno en ahorro, que el apartado de ahorro
crezca, que los cuente, que los agregue. Lo mismo el de inversión: si pongo que
invertí 500 €, que aparezca en inversión; tenía 700, ahora la sumatoria".

ES UN SALDO, NO UN TOTAL. Sube con lo que metes y baja con lo que sacas. Un
número que solo pudiera crecer seguiría diciendo que tienes 2.000 € guardados el
día que gastas 300 de ellos, y eso es peor que no tener el número.

NO SE GUARDA EN NINGUNA PARTE: se calcula siempre sumando los movimientos, igual
que las posiciones de la cartera. Si se guardara habría dos versiones de la
verdad y el día que no cuadren no habría forma de saber cuál está bien.

LO QUE NO SE PUEDE CONVERTIR NO SE CUENTA. Un ahorro en dólares sin tasa no se
suma a un saldo en euros: se aparta y se dice cuántos hay, igual que en los
totales. Un saldo que se inventara la conversión sería un número creíble y falso.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field

from .moneda import EUR, Moneda
from .movimiento import (
    AHORRO,
    INVERSION,
    Guardado,
    Movimiento,
    signo_en_caja,
    signo_en_el_saldo,
)


@dataclass(frozen=True)
class Saldo:
    """Lo que llevas guardado de una cosa, y lo que no se pudo contar."""

    principal: Moneda = EUR
    total: int = 0
    """En unidades mínimas de la moneda principal. PUEDE SER NEGATIVO.

    Y NO SE RECORTA A CERO A PROPÓSITO: si sacas más de lo que metiste, el
    número en rojo es exactamente la información que hace falta —te has
    equivocado apuntando algo— y taparlo con un cero la escondería.
    """

    metido: int = 0
    """Todo lo que ha entrado, sin restar las retiradas."""

    sacado: int = 0
    """Todo lo que ha salido."""

    cuantos: int = 0
    """Cuántos movimientos se contaron."""

    pendientes: tuple[Movimiento, ...] = field(default_factory=tuple)
    """Los que no se pudieron convertir a la moneda principal."""

    @property
    def hay_pendientes(self) -> bool:
        return bool(self.pendientes)


def _convertido(movimiento: Movimiento, principal: Moneda) -> int | None:
    """El importe en la moneda principal, o None si no se sabe.

    SE PREGUNTA CON LA MISMA REGLA QUE LOS TOTALES, y esto empezó siendo una
    copia suya escrita a mano hasta que me di cuenta de que no decían lo mismo:
    la mía daba por bueno un movimiento en euros sin conversión guardada, y
    cuenta_en() no. Con dos reglas, un mismo movimiento entraba en el ahorro y
    se quedaba fuera de los gastos, y no habría forma de saber cuál de las dos
    pantallas mentía.

    UNA SOLA REGLA, LA DE Movimiento.cuenta_en. Si algún día hay que cambiarla,
    se cambia en un sitio y las dos pantallas cambian con ella.
    """
    if not movimiento.cuenta_en(principal):
        return None
    return movimiento.importe_principal


def saldo_de(
    movimientos: Iterable[Movimiento],
    guardado: Guardado,
    *,
    principal: Moneda = EUR,
) -> Saldo:
    """El saldo de una de las dos cosas guardadas.

    El guardado es AHORRO o INVERSION.
    """
    metido = 0
    sacado = 0
    cuantos = 0
    pendientes: list[Movimiento] = []

    for movimiento in movimientos:
        signo = signo_en_el_saldo(movimiento.tipo, guardado)
        if not signo:
            continue
        importe = _convertido(movimiento, principal)
        if importe is None:
            pendientes.append(movimiento)
            continue
        if signo > 0:
            metido += importe
        else:
            sacado += importe
        cuantos += 1

    return Saldo(
        principal=principal,
        total=metido - sacado,
        metido=metido,
        sacado=sacado,
        cuantos=cuantos,
        pendientes=tuple(pendientes),
    )


def ahorrado(
    movimientos: Iterable[Movimiento], *, principal: Moneda = EUR
) -> Saldo:
    return saldo_de(movimientos, AHORRO, principal=principal)


def invertido(
    movimientos: Iterable[Movimiento], *, principal: Moneda = EUR
) -> Saldo:
    """El dinero MANDADO a invertir, que no es lo que vale tu cartera.

    SON DOS PREGUNTAS DISTINTAS y lo eligió así el usuario: esto es cuánto has
    sacado de la cuenta para invertir, y el apartado de Inversiones lleva qué
    compraste con ello y cuánto vale hoy. Pueden no cuadrar —mandas 500 y
    compras por 480— y eso no es un fallo.
    """
    return saldo_de(movimientos, INVERSION, principal=principal)


def disponible(
    movimientos: Iterable[Movimiento], *, principal: Moneda = EUR
) -> Saldo:
    """El dinero que TE QUEDA PARA GASTAR. Ingresos menos todo lo que salió.

    LO PIDIÓ EL USUARIO Y TENÍA RAZÓN: "recibí 1.757, pero este mes puse 200 en
    ahorro y 500 en inversión; ese balance me tiene que restar eso, porque es
    plata que tengo pero que no puedo usar".

    NO ES "INGRESOS MENOS GASTOS", que es lo que ponía antes. Es todo lo que
    entró menos todo lo que salió de la cuenta corriente, y ahorrar e invertir
    salen de la cuenta corriente aunque el dinero siga siendo tuyo. Un balance
    que no los reste dice que te quedan 1.757 € para el mes cuando en realidad
    te quedan 1.057, y con ese número se toman decisiones de compra.

    LO QUE SALIÓ Y LO QUE ENTRÓ SE GUARDAN APARTE, en sacado y en metido, para
    que la pantalla pueda explicar el número sin volver a recorrer la lista.
    """
    metido = 0
    sacado = 0
    cuantos = 0
    pendientes: list[Movimiento] = []

    for movimiento in movimientos:
        signo = signo_en_caja(movimiento.tipo)
        if signo == 0:
            # LOS AJUSTES NO SE MIRAN SIQUIERA, ni como entrada ni como salida.
            # SIN ESTE CORTE caian en el "si no sube, es que baja", y un ajuste
            # de 3.000 restaba 3.000 del balance: exactamente el problema que
            # venia a arreglar. Lo pillaron los tests en cuanto se escribieron.
            continue
        importe = _convertido(movimiento, principal)
        if importe is None:
            pendientes.append(movimiento)
            continue
        if signo > 0:
            metido += importe
        else:
            sacado += importe
        cuantos += 1

    return Saldo(
        principal=principal,
        total=metido - sacado,
        metido=metido,
        sacado=sacado,
        cuantos=cuantos,
        pendientes=tuple(pendientes),
    )
