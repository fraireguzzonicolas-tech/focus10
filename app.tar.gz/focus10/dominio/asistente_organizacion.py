"""El asistente y la organización: marcar hábitos y los recordatorios.

«Marqué como completado el hábito de estudiar francés», «agregá una tarea para
mañana: llamar al propietario», «ya llamé al propietario».

LA HORA VA DELANTE DEL TÍTULO («10:00 Llamar al propietario»): los
recordatorios de Focus no tienen hora: así la hora no se pierde.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, time, timedelta

from .asistente_habitos import buscar_habito
from .asistente_tipos import Decir, Hacer
from .habito import Habito
from .palabras import normalizar
from .tarea import Tarea


@dataclass(frozen=True)
class MarcarHabito:
    habito: Habito
    jornada: date
    cantidad: int

    def frase(self) -> str:
        if self.cantidad >= self.habito.objetivo:
            return f"marqué «{self.habito.nombre}» como hecho"
        return f"marqué «{self.habito.nombre}»: {self.cantidad} de {self.habito.texto_objetivo()}"


@dataclass(frozen=True)
class CrearRecordatorio:
    tarea: Tarea
    dia_dicho: str

    def frase(self) -> str:
        return f"te lo recuerdo {self.dia_dicho}: «{self.tarea.titulo}»"


@dataclass(frozen=True)
class CompletarRecordatorio:
    tarea: Tarea
    jornada: date

    def frase(self) -> str:
        return f"di por hecho «{self.tarea.titulo}»"


def decidir_marcar(datos: dict, habitos: list[Habito], jornada: date) -> Decir | Hacer:
    """Sin cantidad (0), lo da por cumplido entero; con cantidad, deja esa."""
    nombre = str(datos.get("habito") or "")
    encontrado = buscar_habito(nombre, habitos)
    if encontrado is None:
        return Decir(f"No tengo ningún hábito «{nombre}».")
    if isinstance(encontrado, list):
        nombres = ", ".join(f"«{uno.nombre}»" for uno in encontrado[:4])
        return Decir(f"¿Cuál? Tenés {nombres}.")
    cantidad = datos.get("cantidad")
    if not isinstance(cantidad, int) or isinstance(cantidad, bool) or cantidad <= 0:
        cantidad = encontrado.objetivo
    return Hacer(MarcarHabito(encontrado, jornada, cantidad))


def _dia(texto: str, hoy: date) -> tuple[date, str] | None:
    """«» / «hoy», «mañana», «pasado mañana» o AAAA-MM-DD, con cómo decirlo."""
    texto = normalizar(texto).strip()
    if texto in ("", "hoy"):
        return hoy, "hoy"
    if texto == "manana":
        return hoy + timedelta(days=1), "mañana"
    if texto == "pasado manana":
        return hoy + timedelta(days=2), "pasado mañana"
    try:
        dia = date.fromisoformat(texto)
    except ValueError:
        return None
    return dia, f"el {dia.day:02d}/{dia.month:02d}"


def decidir_recordatorio(datos: dict, hoy: date) -> Decir | Hacer:
    titulo = str(datos.get("titulo") or "").strip()
    if not titulo:
        return Decir("¿Qué te recuerdo?")
    dia = _dia(str(datos.get("dia") or ""), hoy)
    if dia is None:
        return Decir(f"¿Para qué día es «{titulo}»?")
    hora = str(datos.get("hora") or "").strip()
    if hora:
        try:
            horas, _, minutos = hora.partition(":")
            titulo = f"{time(int(horas), int(minutos or 0)).strftime('%H:%M')} {titulo}"
        except ValueError:
            return Decir(f"No entendí la hora de «{titulo}».")
    try:
        tarea = Tarea(titulo=titulo, jornada=dia[0])
    except (TypeError, ValueError) as fallo:
        return Decir(f"No pude crear ese recordatorio: {fallo}.")
    return Hacer(CrearRecordatorio(tarea, dia[1]))


def decidir_completar(datos: dict, pendientes: list[Tarea], jornada: date) -> Decir | Hacer:
    """El recordatorio pendiente que se llama así. Si hay varios, se pregunta."""
    buscado = normalizar(str(datos.get("titulo") or "")).strip()
    if not buscado:
        return Decir("¿Cuál recordatorio?")
    exactos = [t for t in pendientes if normalizar(t.titulo).strip() == buscado]
    parecidos = exactos or [t for t in pendientes if buscado in normalizar(t.titulo)]
    if not parecidos:
        return Decir(f"No tengo ningún recordatorio pendiente «{datos.get('titulo')}».")
    if len(parecidos) > 1:
        nombres = ", ".join(f"«{t.titulo}»" for t in parecidos[:4])
        return Decir(f"¿Cuál? Tenés {nombres}.")
    return Hacer(CompletarRecordatorio(parecidos[0], jornada))
