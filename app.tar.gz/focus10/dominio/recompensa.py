"""Las recompensas de la semana: un extra pequeño encima de los hábitos.

LO PIDIÓ EL USUARIO Y PIDIÓ ALGO MÁS: "que sea muy simple y secundaria; no
quiero que esto se convierta en una funcionalidad principal ni que complique la
aplicación". Por eso aquí no hay puntos, ni monedas, ni niveles de usuario: hay
un porcentaje, un umbral y una lista de hasta cinco cosas.

NO SE REINVENTA EL CÁLCULO DE HÁBITOS. El porcentaje sale de la misma pieza que
pinta el calendario y las rachas: `cumplimiento_de_varios`. Este archivo solo lo
resume en un número y decide si toca premio.

SIN NADA PROGRAMADO NO HAY PORCENTAJE. Una semana en la que no tocaba ningún
hábito no es una semana del 0% ni del 100%: es una semana sobre la que no se
puede decir nada, y premiarla o suspenderla sería inventar.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import date, timedelta

MAXIMO_RECOMPENSAS = 5
"""Cuántas puede tener guardadas. Lo pidió el usuario: entre 0 y 5."""

LARGO_MAXIMO_NOMBRE = 60

MINIMO_PARA_PREMIO = 70
NIVELES = (70, 80, 90, 100)
"""Los escalones. El porcentaje decide el más alto que se alcanza."""

MENSAJES = {
    70: ("🎉 ¡Llegaste al 70%!", "¡Tienes derecho a una recompensa!"),
    80: ("🎉 ¡Llegaste al 80%!", "¡Tienes derecho a una recompensa!"),
    90: ("🔥 ¡Llegaste al 90%!", "¡Excelente semana! Elige tu recompensa."),
    100: ("🏆 ¡100%!", "¡Completaste todos tus hábitos! Elige tu recompensa."),
}


@dataclass(frozen=True)
class Recompensa:
    """Una de las cosas que te has puesto como premio.

    UN SOLO CAMPO DE TEXTO, y con el emoji dentro ("🍔 Ir a comer algo rico").
    Separar el emoji en su propia columna obligaría a un selector de emojis y a
    decidir qué pasa cuando falta; escribirlo delante del nombre lo resuelve sin
    nada de eso, y es como los escribió el usuario en su ejemplo.
    """

    nombre: str
    orden: int = 0
    id: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.nombre, str):
            raise TypeError("el nombre tiene que ser texto")
        limpio = self.nombre.strip()
        if not limpio:
            raise ValueError("la recompensa necesita un nombre")
        if len(limpio) > LARGO_MAXIMO_NOMBRE:
            raise ValueError(
                f"el nombre no puede pasar de {LARGO_MAXIMO_NOMBRE} letras"
            )
        object.__setattr__(self, "nombre", limpio)

        if isinstance(self.orden, bool) or not isinstance(self.orden, int):
            raise TypeError("el orden tiene que ser un entero")
        if self.orden < 0:
            raise ValueError("el orden no puede ser negativo")


def semana_de(jornada: date) -> tuple[date, date]:
    """El lunes y el domingo de la semana en que cae esa fecha.

    ES LA MISMA SEMANA QUE PINTA LA SECCIÓN DE HÁBITOS —de lunes a domingo— para
    que el porcentaje del premio y el que ves en pantalla no puedan discrepar.
    """
    lunes = jornada - timedelta(days=jornada.weekday())
    return lunes, lunes + timedelta(days=6)


def semana_anterior(jornada: date) -> tuple[date, date]:
    """La última semana COMPLETA antes de la de esa fecha.

    LA SEMANA TERMINA EL DOMINGO, lo dijo el usuario, y el premio no se enseña
    hasta que ha terminado. Estando en cualquier día de esta semana, la última
    cerrada es la anterior entera.
    """
    lunes, _ = semana_de(jornada)
    return semana_de(lunes - timedelta(days=1))


def porcentaje_de(cumplimientos: Iterable) -> int | None:
    """Qué parte de lo que tocaba se cumplió, de 0 a 100. None si no tocaba nada.

    SE SUMAN LOS DÍAS ENTEROS y no se promedian sus proporciones: una semana con
    un día de un hábito cumplido y otro de cinco fallados no es un 50%. Lo que
    cuenta es cuántas cosas tocaban y cuántas hiciste.
    """
    cumplidos = 0
    programados = 0
    for dia in cumplimientos:
        cumplidos += dia.cumplidos
        programados += dia.programados
    if not programados:
        return None
    return round(100 * cumplidos / programados)


def nivel_de(porcentaje: int | None) -> int | None:
    """El escalón alcanzado, o None si no llega al mínimo.

    None ES LA RESPUESTA NORMAL, no un fallo: por debajo del 70% no pasa nada y
    no se enseña ninguna ventana.
    """
    if porcentaje is None or porcentaje < MINIMO_PARA_PREMIO:
        return None
    return max(uno for uno in NIVELES if porcentaje >= uno)


def mensaje_de(nivel: int) -> tuple[str, str]:
    """El título y la frase de ese escalón."""
    if nivel not in MENSAJES:
        raise KeyError(f"no hay mensaje para el nivel {nivel}")
    return MENSAJES[nivel]
