"""Una tarea: algo puntual que hay que hacer un día concreto.

QUÉ NO ES UNA TAREA: algo que se repite. "Ir al gimnasio los lunes" es un hábito
y vive en dominio/habito.py, con su cuadrícula del año, su racha y su porcentaje.
Decidido así con el usuario: si las tareas también pudieran repetirse acabaríamos
con dos sistemas de hábitos, el segundo más pobre, y nunca sabrías dónde apuntaste
cada cosa.

LAS DOS FECHAS Y POR QUÉ SON DOS:

  jornada   el día PARA EL QUE se apuntó. No cambia nunca.
  hecha_en  el día en que se hizo de verdad, o None si sigue pendiente.

Tenerlas separadas es lo que permite las dos cosas que pidió el usuario a la vez:
que una tarea sin hacer siga apareciendo hoy (porque sigue pendiente) y que el
día para el que era quede registrado como no cumplido (porque su jornada no se
mueve). Si al arrastrarla se le cambiara la fecha, el jueves parecería que nunca
tuvo nada que hacer.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime

LARGO_MAXIMO_TITULO = 120
LARGO_MAXIMO_NOTA = 500

DIAS_LARGOS = (
    "lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo",
)
DIAS_CON_NOMBRE = 7
"""Menos de una semana de atraso se dice el día ("del jueves"); a partir de ahí,
los días que han pasado.

EL LÍMITE ES SEIS DÍAS Y NO SIETE, aunque "una semana" suene a siete: a los siete
días exactos el día de la semana vuelve a ser el mismo que hoy, y "del lunes" un
lunes no sitúa a nadie. Y "del jueves" hace tres semanas, menos todavía."""


@dataclass(frozen=True)
class Tarea:
    titulo: str
    jornada: date
    """El día para el que se apuntó. No se mueve aunque la tarea se arrastre."""

    hecha_en: date | None = None
    """El día en que se hizo. None mientras siga pendiente."""

    nota: str = ""
    orden: int = 0
    id: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.titulo, str):
            raise TypeError("el título tiene que ser texto")
        limpio = self.titulo.strip()
        if not limpio:
            raise ValueError("el título no puede estar vacío")
        if len(limpio) > LARGO_MAXIMO_TITULO:
            raise ValueError(
                f"el título no puede pasar de {LARGO_MAXIMO_TITULO} caracteres "
                f"(llegaron {len(limpio)})"
            )
        object.__setattr__(self, "titulo", limpio)

        if not isinstance(self.nota, str):
            raise TypeError("la nota tiene que ser texto")
        if len(self.nota.strip()) > LARGO_MAXIMO_NOTA:
            raise ValueError(
                f"la nota no puede pasar de {LARGO_MAXIMO_NOTA} caracteres"
            )
        object.__setattr__(self, "nota", self.nota.strip())

        _exigir_dia("jornada", self.jornada)
        if self.hecha_en is not None:
            _exigir_dia("hecha_en", self.hecha_en)

        if isinstance(self.orden, bool) or not isinstance(self.orden, int):
            raise TypeError("orden tiene que ser int")
        if self.orden < 0:
            raise ValueError(f"orden no puede ser negativo, y llegó {self.orden}")

        if self.id is not None:
            if isinstance(self.id, bool) or not isinstance(self.id, int):
                raise TypeError("el id tiene que ser int o None")
            if self.id <= 0:
                raise ValueError(f"id tiene que ser mayor que cero, y llegó {self.id}")

    # ----------------------------------------------------------------------

    @property
    def hecha(self) -> bool:
        return self.hecha_en is not None

    def dias_de_atraso(self, hoy: date) -> int:
        """Cuántos días lleva pendiente desde el día para el que era.

        Cero si es de hoy, si es de más adelante, o si ya está hecha: una tarea
        hecha no está atrasada por muy tarde que se hiciera. Lo que interesa del
        atraso es que actúes, y sobre lo hecho ya no hay nada que hacer.

        EL ">=" PODRÍA SER ">" Y NADIE SE ENTERARÍA: con una tarea de hoy, la
        resta de abajo da cero de todas formas, así que ningún test puede
        distinguir las dos versiones. Lo comprobé rompiéndolo a propósito. Se
        deja el ">=" porque dice lo que se quiere decir —"de hoy en adelante no
        hay atraso"— en vez de dejarlo al azar de que una resta salga cero.
        """
        _exigir_dia("hoy", hoy)
        if self.hecha or self.jornada >= hoy:
            return 0
        return (hoy - self.jornada).days

    def texto_de_atraso(self, hoy: date) -> str:
        """"de ayer", "del jueves", "de hace 12 días". Vacío si no está atrasada."""
        atraso = self.dias_de_atraso(hoy)
        if atraso == 0:
            return ""
        if atraso == 1:
            return "de ayer"
        if atraso < DIAS_CON_NOMBRE:
            return f"del {DIAS_LARGOS[self.jornada.weekday()]}"
        return f"de hace {atraso} días"

    def estaba_hecha_el(self, dia: date) -> bool:
        """Si a esa altura la tarea ya estaba hecha.

        Sirve para mirar atrás sin mentir: una tarea del jueves que se hizo el
        viernes NO estaba hecha el jueves, y ese jueves tiene que seguir
        contando como no cumplido aunque hoy la tarea aparezca con su marca.
        """
        _exigir_dia("dia", dia)
        return self.hecha_en is not None and self.hecha_en <= dia

    def toca_en(self, dia: date) -> bool:
        """Si la tarea debe aparecer en la lista de ese día.

        Aparece el día para el que se apuntó y todos los siguientes mientras siga
        pendiente. Una vez hecha, deja de arrastrarse: se queda en su jornada y
        en el día en que se hizo.
        """
        _exigir_dia("dia", dia)
        if self.jornada == dia:
            return True
        if self.jornada > dia:
            return False
        # Ya pasó su día: solo sigue apareciendo si no se ha hecho, o si se hizo
        # justo en el día que se está mirando.
        return not self.hecha or self.hecha_en == dia


def ordenar(tareas: list[Tarea], hoy: date) -> list[Tarea]:
    """Las tareas en el orden en que se enseñan.

    Primero las pendientes y después las hechas: una lista donde lo hecho estorba
    para encontrar lo que falta deja de servir para lo que sirve. Dentro de las
    pendientes, las más atrasadas arriba, porque son las que se están escapando.
    """
    return sorted(
        tareas,
        key=lambda una: (
            una.hecha,
            -una.dias_de_atraso(hoy),
            una.orden,
            una.titulo.lower(),
        ),
    )


def _exigir_dia(nombre: str, valor: object) -> None:
    # datetime hereda de date, así que hay que descartarlo expresamente: una
    # tarea pertenece a una jornada entera, no a un instante.
    if not isinstance(valor, date) or isinstance(valor, datetime):
        raise TypeError(f"{nombre} tiene que ser un date, no un datetime")
