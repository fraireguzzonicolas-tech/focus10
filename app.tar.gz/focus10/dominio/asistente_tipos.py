"""Las piezas que comparten todas las acciones del asistente.

LO QUE LLEGA: una Respuesta del servidor, con texto, una Accion o las dos.
LO QUE DECIDE FOCUS con ella, siempre una de tres cosas:
- Decir: solo contestar (una pregunta, un dato, que algo no se pudo).
- Hacer: ejecutar una orden ya comprobada.
- Confirmar: preguntar antes, y hacerla solo si dice que sí.

Cada orden (apuntar un gasto, crear un hábito…) sabe decir en una frase qué
va a hacer y qué hizo: así la confirmación por voz suena igual en todo.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Accion:
    """Lo que Claude eligió hacer, tal cual llega: el nombre y sus datos."""

    id: str
    nombre: str
    datos: dict


@dataclass(frozen=True)
class Respuesta:
    """Lo que devolvió el servidor."""

    texto: str
    accion: Accion | None
    contenido: list = field(default_factory=list)
    """Los bloques tal cual, para guardarlos en la conversación: la próxima
    vez Claude tiene que ver que pidió esa acción."""

    @classmethod
    def de_json(cls, datos: dict) -> Respuesta:
        if not isinstance(datos, dict) or not isinstance(datos.get("contenido"), list):
            raise ValueError("el asistente contestó algo que no entiendo")
        cruda = datos.get("accion")
        accion = None
        if cruda is not None:
            if not isinstance(cruda, dict) or not isinstance(cruda.get("datos"), dict):
                raise ValueError("el asistente pidió una acción sin forma")
            accion = Accion(str(cruda.get("id") or ""), str(cruda.get("nombre") or ""), cruda["datos"])
        return cls(str(datos.get("texto") or "").strip(), accion, datos["contenido"])


@dataclass(frozen=True)
class Decir:
    texto: str


@dataclass(frozen=True)
class Hacer:
    orden: object
    """Una de las órdenes de asistente_finanzas o asistente_habitos."""


@dataclass(frozen=True)
class Confirmar:
    orden: object
    pregunta: str
