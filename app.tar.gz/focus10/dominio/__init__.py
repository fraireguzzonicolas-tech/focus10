"""Reglas de negocio puras: no tocan disco, ni red, ni ventanas."""
