"""Qué dominios se pueden bloquear y cuáles NO, pase lo que pase.

POR QUÉ EXISTE ESTA LISTA: el bloqueo escribe en el archivo hosts de Windows.
Bloquearte por error el sitio desde el que pedirías ayuda, el traductor que
necesitas para trabajar, o los dominios de Microsoft de los que depende el propio
Windows, no es una molestia: es dejarte encerrado sin la llave. Por eso la lista
está EN EL CÓDIGO y no en la base de datos: para que no se pueda quitar
escribiéndolo a mano ni abriendo el archivo de datos con otro programa.

LA MISMA LISTA VIVE EN DOS SITIOS INDEPENDIENTES, aquí y en el guardián elevado
(ver focus10/sistema/guardian.py). No es duplicar por descuido: es que el
guardián es quien de verdad toca el archivo, y tiene que poder negarse aunque lo
que le llegue venga corrompido, manipulado, o de una versión de la aplicación
distinta de la suya. Un solo sitio significaría que quien se salte ese sitio se
lo salta todo. El test test_dominios.py comprueba que las dos listas coinciden.

CÓMO SE COMPARA: por sufijo de etiqueta, no por "contiene". "google.com" protege
"www.google.com" y "docs.google.com", pero NO protege "nogoogle.com" ni
"google.com.trampa.net", que son dominios de otra persona.
"""

from __future__ import annotations

import re

#: Los dominios que nunca se bloquean. Los subdominios heredan la protección.
PROTEGIDOS: tuple[str, ...] = (
    # Por dónde se pide ayuda cuando algo va mal.
    "claude.ai",
    "anthropic.com",
    "claude.com",
    # Buscar y traducir es trabajo, no distracción.
    "google.com",
    "translate.google.com",
    "deepl.com",
    "wordreference.com",
    "wikipedia.org",
    "wikimedia.org",
    "rae.es",
    "dle.rae.es",
    # La propia máquina. Bloquear esto rompe programas que ni sospecharías.
    "localhost",
    "localhost.localdomain",
    # Windows depende de estos para actualizarse, activarse y validar la hora.
    "microsoft.com",
    "windows.com",
    "windowsupdate.com",
    "microsoftonline.com",
    "live.com",
    "msftconnecttest.com",
    "msftncsi.com",
)

LARGO_MAXIMO = 253
"""El máximo de un nombre de dominio. Más largo no es un dominio."""

# Una etiqueta: letras, números y guiones, sin empezar ni acabar en guion.
_ETIQUETA = r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?"
_DOMINIO = re.compile(rf"^{_ETIQUETA}(?:\.{_ETIQUETA})*$")


class DominioProtegido(ValueError):
    """Se intentó bloquear algo de la lista protegida."""


class DominioInvalido(ValueError):
    """Lo que se escribió no es un nombre de dominio."""


def normalizar(texto: str) -> str:
    """Deja el dominio en su forma canónica, o avisa si no es un dominio.

    Quita lo que la gente pega sin darse cuenta —el "https://", la barra final,
    el puerto, el punto del final— y lo pasa a minúsculas. Esto NO es cosmética:
    es la mitad de la seguridad. Si "GOOGLE.COM" o "https://google.com/" no se
    redujeran a "google.com", pasarían por la lista de protegidos sin que salte,
    y se bloquearía Google.

    Los acentos y demás letras no ASCII se rechazan en vez de convertirse: un
    dominio que parece "gοogle.com" con una omicron griega en medio es un dominio
    distinto, y aceptarlo sería exactamente el agujero que esto evita.
    """
    if not isinstance(texto, str):
        raise DominioInvalido(f"esto no es texto: {type(texto).__name__}")

    limpio = texto.strip().lower()
    # El esquema, si lo hay.
    limpio = re.sub(r"^[a-z][a-z0-9+.-]*://", "", limpio)
    # Las barras del principio. Hace falta APARTE de quitar el esquema, porque
    # "//google.com" es una dirección válida que se pega tal cual (sin http:) y
    # sin esto se quedaba en nada y se colaba como "no protegida".
    limpio = limpio.lstrip("/")
    # Usuario y contraseña en la URL ("user@host"), que esconden el host real.
    limpio = limpio.rsplit("@", 1)[-1]
    # Ruta, consulta y ancla.
    limpio = re.split(r"[/?#]", limpio, maxsplit=1)[0]
    # Puerto.
    limpio = re.sub(r":\d*$", "", limpio)
    # El punto final del dominio absoluto ("google.com.").
    limpio = limpio.rstrip(".")

    if not limpio:
        raise DominioInvalido("el dominio no puede estar vacío")
    if len(limpio) > LARGO_MAXIMO:
        raise DominioInvalido(
            f"un dominio no pasa de {LARGO_MAXIMO} caracteres (llegaron {len(limpio)})"
        )
    if not _DOMINIO.match(limpio):
        raise DominioInvalido(
            f"«{texto.strip()}» no es un nombre de dominio válido. "
            "Se escribe como «youtube.com», sin https:// ni barras."
        )
    return limpio


def esta_protegido(dominio: str) -> bool:
    """Si ese dominio, o alguno de sus padres, está en la lista protegida.

    Se compara etiqueta a etiqueta: "docs.google.com" está protegido porque
    termina en ".google.com"; "nogoogle.com" NO lo está, porque termina en
    "ogoogle.com" y eso es otro dominio de otra persona.
    """
    try:
        limpio = normalizar(dominio)
    except DominioInvalido:
        # Lo que no es un dominio no se puede bloquear igualmente: que lo
        # rechace quien valida, no esta función diciendo "no protegido".
        return False
    return any(
        limpio == protegido or limpio.endswith("." + protegido)
        for protegido in PROTEGIDOS
    )


def exigir_bloqueable(texto: str) -> str:
    """Devuelve el dominio listo para guardar, o explica por qué no se puede.

    Es la ÚNICA puerta de entrada de un dominio al bloqueo. Todo lo que quiera
    acabar en el archivo hosts pasa por aquí, y aquí se normaliza antes de
    comparar, que es el orden que importa.
    """
    limpio = normalizar(texto)
    if esta_protegido(limpio):
        raise DominioProtegido(
            f"«{limpio}» no se puede bloquear: está protegido a propósito. "
            "Es de los sitios desde los que pedirías ayuda, traducirías algo o "
            "de los que depende Windows."
        )
    return limpio


def variantes_para_hosts(dominio: str) -> tuple[str, ...]:
    """Las líneas que hay que escribir en el hosts para bloquear ese dominio.

    Son dos: el dominio y su "www.". El archivo hosts NO entiende comodines —no
    existe "*.youtube.com"—, así que cada nombre va escrito entero. Sin la
    variante con www, escribir "youtube.com" dejaba pasar "www.youtube.com" y el
    bloqueo parecía roto.
    """
    limpio = normalizar(dominio)
    if limpio.startswith("www."):
        return (limpio,)
    return (limpio, f"www.{limpio}")
