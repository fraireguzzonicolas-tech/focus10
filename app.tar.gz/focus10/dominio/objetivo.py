"""Los objetivos: a dónde vas, con o sin dinero de por medio.

DOS TIPOS Y UNA TRAMPA. Los objetivos de dinero tienen un importe y su avance
sale de sumar aportaciones. Los libres —"sacarme el B2 de alemán"— no tienen
importe y su avance lo pone el usuario a mano, de diez en diez.

La trampa la avisó él mismo: si el importe fuera obligatorio y mayor que cero,
los objetivos libres no se podrían guardar. Por eso el importe admite CERO, aquí
y en la base de datos, y lo que decide si hay meta de dinero es el TIPO, no el
número.

EL "POR QUÉ LO QUIERO" NO ES DECORACIÓN. Es lo que se lee en el Dashboard cada
mañana, y es la razón de que un objetivo siga vivo tres meses después. Por eso es
texto libre y largo: "ahorrar 6000" no mueve a nadie; "para irme dos meses a
Japón sin pedir permiso a nadie", sí.

CUMPLIDO Y VENCIDO NO SON LO MISMO, y se distinguen a propósito. Cumplido es que
llegaste al 100 %. Vencido es que se pasó la fecha sin llegar. Los dos salen del
Dashboard y bajan a la lista de abajo, como pidió el usuario, pero llamar
"cumplido" a algo que no se consiguió sería la clase de mentira que esta
aplicación no cuenta en ningún otro sitio.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import date, datetime
from enum import StrEnum

LARGO_MAXIMO_NOMBRE = 60
LARGO_MAXIMO_PORQUE = 500
IMPORTE_MAXIMO = 10**11
"""Mil millones de euros. Tope de cordura, no de ambición."""

PASO_DE_AVANCE = 10
"""Los objetivos libres se mueven de diez en diez por ciento, como se pidió.

De uno en uno obligaría a decidir si vas por el 37 % o por el 38 %, que es una
precisión que nadie tiene sobre "aprender alemán" y que solo sirve para dudar.
"""


class TipoObjetivo(StrEnum):
    DINERO = "dinero"
    LIBRE = "libre"


class Estado(StrEnum):
    ABIERTO = "abierto"
    CUMPLIDO = "cumplido"
    VENCIDO = "vencido"
    """Se pasó la fecha sin llegar. No es un fracaso, pero tampoco un logro."""


@dataclass(frozen=True)
class Objetivo:
    nombre: str
    color: str
    tipo: TipoObjetivo
    porque: str = ""
    """Por qué lo quiero. Lo que se lee cada mañana."""

    importe_objetivo: int = 0
    """En céntimos. CERO es válido y es lo normal en los objetivos libres: si
    esto fuera "mayor que cero", los libres no se podrían guardar."""

    avance_manual: int = 0
    """De 0 a 100, de diez en diez. Solo lo usan los objetivos libres."""

    fecha_limite: date | None = None
    cumplido_en: date | None = None
    """El día que se dio por conseguido. None mientras siga abierto."""

    orden: int = 0
    id: int | None = None

    def __post_init__(self) -> None:
        _exigir_texto("nombre", self.nombre, LARGO_MAXIMO_NOMBRE, obligatorio=True)
        _exigir_texto("porque", self.porque, LARGO_MAXIMO_PORQUE)
        for campo in ("nombre", "porque"):
            object.__setattr__(self, campo, getattr(self, campo).strip())

        from .habito import COLORES

        if self.color not in COLORES:
            raise ValueError(
                f"color desconocido: {self.color!r}. Los que hay: {', '.join(COLORES)}"
            )

        if not isinstance(self.tipo, TipoObjetivo):
            raise TypeError("el tipo tiene que ser un TipoObjetivo")

        _exigir_entero("importe_objetivo", self.importe_objetivo)
        if self.importe_objetivo < 0:
            raise ValueError("el importe no puede ser negativo")
        if self.importe_objetivo > IMPORTE_MAXIMO:
            raise ValueError("ese importe es demasiado grande")
        if self.tipo is TipoObjetivo.LIBRE and self.importe_objetivo:
            raise ValueError(
                "un objetivo libre no lleva importe: su avance lo pones tú a mano"
            )

        _exigir_entero("avance_manual", self.avance_manual)
        if not 0 <= self.avance_manual <= 100:
            raise ValueError("el avance va de 0 a 100")
        if self.avance_manual % PASO_DE_AVANCE:
            raise ValueError(f"el avance va de {PASO_DE_AVANCE} en {PASO_DE_AVANCE}")
        if self.tipo is TipoObjetivo.DINERO and self.avance_manual:
            raise ValueError(
                "un objetivo de dinero no lleva avance a mano: sale de las "
                "aportaciones"
            )

        for campo in ("fecha_limite", "cumplido_en"):
            valor = getattr(self, campo)
            if valor is None:
                continue
            if not isinstance(valor, date) or isinstance(valor, datetime):
                raise TypeError(f"{campo} tiene que ser un date, no un datetime")

        _exigir_entero("orden", self.orden)
        if self.orden < 0:
            raise ValueError("orden no puede ser negativo")
        if self.id is not None:
            _exigir_entero("id", self.id)
            if self.id <= 0:
                raise ValueError("id tiene que ser mayor que cero")

    @property
    def es_de_dinero(self) -> bool:
        return self.tipo is TipoObjetivo.DINERO


@dataclass(frozen=True)
class Aportacion:
    """Dinero apartado para un objetivo.

    NO ES UN GASTO. Lo decidió el usuario: apuntar 200 € al objetivo "viaje" no
    crea ningún movimiento en Finanzas, porque ese dinero no ha salido de su
    bolsillo. Si además se apuntara como gasto, los gastos del mes dirían que
    gastó 200 € que no gastó.
    """

    objetivo_id: int
    importe: int
    fecha: date
    nota: str = ""
    id: int | None = None

    def __post_init__(self) -> None:
        _exigir_entero("objetivo_id", self.objetivo_id)
        if self.objetivo_id <= 0:
            raise ValueError("objetivo_id tiene que ser mayor que cero")

        _exigir_entero("importe", self.importe)
        if self.importe == 0:
            raise ValueError("una aportación de cero no es una aportación")
        if abs(self.importe) > IMPORTE_MAXIMO:
            raise ValueError("ese importe es demasiado grande")

        if not isinstance(self.fecha, date) or isinstance(self.fecha, datetime):
            raise TypeError("la fecha tiene que ser un date, no un datetime")
        _exigir_texto("nota", self.nota, 200)
        object.__setattr__(self, "nota", self.nota.strip())

        if self.id is not None:
            _exigir_entero("id", self.id)
            if self.id <= 0:
                raise ValueError("id tiene que ser mayor que cero")


@dataclass(frozen=True)
class Avance:
    """Cómo va un objetivo. Todo calculado, nada guardado."""

    objetivo: Objetivo
    ahorrado: int
    """Suma de las aportaciones, en céntimos. Cero en los libres."""

    fraccion: float
    """De 0 a 1."""

    estado: Estado

    @property
    def porcentaje(self) -> int:
        return round(100 * self.fraccion)

    @property
    def falta(self) -> int | None:
        """Lo que queda por ahorrar. None en los libres: no hay dinero que falte."""
        if not self.objetivo.es_de_dinero:
            return None
        return max(0, self.objetivo.importe_objetivo - self.ahorrado)

    def dias_hasta(self, hoy: date) -> int | None:
        """Cuántos días quedan para la fecha límite. Negativo si ya pasó."""
        if self.objetivo.fecha_limite is None:
            return None
        return (self.objetivo.fecha_limite - hoy).days


def avance(
    objetivo: Objetivo, aportaciones: Iterable[Aportacion], hoy: date
) -> Avance:
    """Cómo va el objetivo, según su tipo.

    Los de DINERO suman sus aportaciones; los LIBRES usan el porcentaje que puso
    el usuario. Son dos cuentas distintas a propósito: mezclarlas obligaría a
    inventarse un importe para los libres, y ese importe no significaría nada.
    """
    if not isinstance(objetivo, Objetivo):
        raise TypeError("hace falta un Objetivo")

    ahorrado = 0
    if objetivo.es_de_dinero:
        ahorrado = sumar_aportaciones(aportaciones)
        meta = objetivo.importe_objetivo
        fraccion = min(1.0, max(0.0, ahorrado / meta)) if meta else 0.0
    else:
        fraccion = objetivo.avance_manual / 100

    return Avance(
        objetivo=objetivo,
        ahorrado=ahorrado,
        fraccion=fraccion,
        estado=_estado(objetivo, fraccion, hoy),
    )


def _estado(objetivo: Objetivo, fraccion: float, hoy: date) -> Estado:
    """Abierto, cumplido o vencido.

    Cumplido manda sobre vencido: si llegaste al 100 % el mismo día en que se te
    pasaba la fecha, lo conseguiste. Y el cumplido_en guardado manda sobre todo,
    porque es el día en que se dio por hecho y eso no se recalcula.
    """
    if objetivo.cumplido_en is not None:
        return Estado.CUMPLIDO
    if fraccion >= 1.0:
        return Estado.CUMPLIDO
    if objetivo.fecha_limite is not None and objetivo.fecha_limite < hoy:
        return Estado.VENCIDO
    return Estado.ABIERTO


def sumar_aportaciones(aportaciones: Iterable[Aportacion]) -> int:
    suma = 0
    for una in aportaciones:
        if not isinstance(una, Aportacion):
            raise TypeError(f"esto no es una Aportacion: {una!r}")
        suma += una.importe
    return suma


def acumulado(aportaciones: Iterable[Aportacion]) -> list[tuple[date, int]]:
    """El ahorro acumulado día a día, para el gráfico.

    Devuelve un punto por fecha con aportaciones, no uno por día: dibujar 365
    puntos iguales entre dos aportaciones no añade nada y hace la línea lenta de
    calcular. Las de un mismo día se juntan en un punto.
    """
    por_fecha: dict[date, int] = {}
    for una in aportaciones:
        if not isinstance(una, Aportacion):
            raise TypeError(f"esto no es una Aportacion: {una!r}")
        por_fecha[una.fecha] = por_fecha.get(una.fecha, 0) + una.importe

    total = 0
    puntos: list[tuple[date, int]] = []
    for fecha in sorted(por_fecha):
        total += por_fecha[fecha]
        puntos.append((fecha, total))
    return puntos


def siguiente_avance(actual: int, hacia_arriba: bool) -> int:
    """El avance manual, un escalón arriba o abajo, sin salirse de 0 a 100."""
    _exigir_entero("actual", actual)
    paso = PASO_DE_AVANCE if hacia_arriba else -PASO_DE_AVANCE
    return min(100, max(0, actual + paso))


def ordenar(avances: list[Avance]) -> list[Avance]:
    """Primero los abiertos, y los cumplidos y vencidos al final.

    Lo pidió el usuario: lo cumplido baja pero no se borra. Dentro de cada grupo
    manda el orden elegido y luego el nombre, para que la lista no baile entre
    dos aperturas.
    """
    peso = {Estado.ABIERTO: 0, Estado.VENCIDO: 1, Estado.CUMPLIDO: 2}
    return sorted(
        avances,
        key=lambda uno: (
            peso[uno.estado],
            uno.objetivo.orden,
            uno.objetivo.nombre.lower(),
        ),
    )


def _exigir_texto(nombre: str, valor, largo: int, *, obligatorio: bool = False) -> None:
    if not isinstance(valor, str):
        raise TypeError(f"{nombre} tiene que ser texto")
    limpio = valor.strip()
    if obligatorio and not limpio:
        raise ValueError(f"{nombre} no puede estar vacío")
    if len(limpio) > largo:
        raise ValueError(f"{nombre} no puede pasar de {largo} caracteres")


def _exigir_entero(nombre: str, valor) -> None:
    if isinstance(valor, bool) or not isinstance(valor, int):
        raise TypeError(f"{nombre} tiene que ser un entero")
