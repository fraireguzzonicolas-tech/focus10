"""El asistente y los hábitos: crear, cambiar y borrar.

LAS MISMAS REGLAS QUE LA VENTANA DE HÁBITOS: el hábito se construye con la
clase Habito, que es la que exige nombre, al menos un día y una hora con
sentido. Si Claude manda algo que no vale, se pregunta; no se crea a medias.

LO QUE NO DIJISTE LO ELIGE CLAUDE, de lo que tiene Focus: un ícono de la lista
y uno de los ocho colores. Si manda uno que no existe, se usa el de siempre en
vez de fallar: no vale la pena repreguntar por un dibujo.

BORRAR PREGUNTA SIEMPRE (lo eligió el usuario), y dice qué va a pasar: si el
hábito ya tiene marcas no se borra, se archiva, igual que en su pantalla.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import time

from .asistente_tipos import Confirmar, Decir, Hacer
from .habito import COLORES, TODOS_LOS_DIAS, Habito
from .palabras import normalizar

NOMBRES_DE_DIAS = ("lunes", "martes", "miércoles", "jueves", "viernes", "sábados", "domingos")
ICONO_POR_OMISION = "estrella"
COLOR_POR_OMISION = "azul"
UNIDAD_POR_OMISION = "vez"


# --------------------------------------------------------------------------
# Cómo se dice
# --------------------------------------------------------------------------


def texto_dias(dias: frozenset[int]) -> str:
    """«todos los días», «de lunes a viernes», «los lunes y miércoles»."""
    if dias == TODOS_LOS_DIAS:
        return "todos los días"
    if dias == frozenset(range(5)):
        return "de lunes a viernes"
    if dias == frozenset({5, 6}):
        return "los fines de semana"
    nombres = [NOMBRES_DE_DIAS[dia] for dia in sorted(dias)]
    if len(nombres) == 1:
        return f"los {nombres[0]}"
    return "los " + ", ".join(nombres[:-1]) + " y " + nombres[-1]


def texto_cuando(habito: Habito) -> str:
    hora = f" a las {habito.hora.strftime('%H:%M')}" if habito.hora else ""
    return texto_dias(habito.dias) + hora


# --------------------------------------------------------------------------
# Las órdenes
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class CrearHabito:
    habito: Habito

    def frase(self) -> str:
        return f"creé «{self.habito.nombre}», {texto_cuando(self.habito)}"


@dataclass(frozen=True)
class CambiarHabito:
    antes: Habito
    despues: Habito

    def frase(self) -> str:
        return f"cambié «{self.despues.nombre}»: ahora {texto_cuando(self.despues)}"


@dataclass(frozen=True)
class BorrarHabito:
    habito: Habito
    archivar: bool
    """Si tiene marcas no se borra: se archiva y su historial se conserva."""

    def frase(self) -> str:
        if self.archivar:
            return f"archivé «{self.habito.nombre}»; su historial se conserva"
        return f"borré «{self.habito.nombre}»"


# --------------------------------------------------------------------------
# Leer lo que manda Claude
# --------------------------------------------------------------------------


def _dias(crudos) -> frozenset[int] | None:
    if not isinstance(crudos, list):
        return None
    dias = frozenset(d for d in crudos if isinstance(d, int) and not isinstance(d, bool))
    return dias if dias and dias <= TODOS_LOS_DIAS else None


def _hora(texto: str) -> time | None:
    """«14:00» -> 14:00. Lanza ValueError si no se entiende."""
    horas, _, minutos = texto.strip().partition(":")
    return time(hour=int(horas), minute=int(minutos or 0))


def buscar_habito(nombre: str, habitos: list[Habito]) -> Habito | list[Habito] | None:
    """El hábito con ese nombre. Si hay varios parecidos, la lista de ellos.

    PRIMERO EL NOMBRE EXACTO (sin mayúsculas ni tildes); si no, los que lo
    contienen («gym» no, pero «gimnasio» encuentra «Gimnasio 2x»). Si quedan
    varios, se pregunta cuál: cambiar el que no era es peor que preguntar.
    """
    buscado = normalizar(nombre).strip()
    if not buscado:
        return None
    exacto = [uno for uno in habitos if normalizar(uno.nombre).strip() == buscado]
    parecidos = exacto or [uno for uno in habitos if buscado in normalizar(uno.nombre)]
    if len(parecidos) == 1:
        return parecidos[0]
    return parecidos or None


def _icono(clave: str, iconos: tuple[str, ...]) -> str:
    return clave if clave in iconos else ICONO_POR_OMISION


def _color(nombre: str) -> str:
    return nombre if nombre in COLORES else COLOR_POR_OMISION


def decidir_crear(datos: dict, iconos: tuple[str, ...]) -> Decir | Hacer:
    nombre = str(datos.get("nombre") or "").strip()
    if not nombre:
        return Decir("¿Cómo se llama el hábito?")
    dias = _dias(datos.get("dias"))
    if dias is None:
        return Decir(f"¿Qué días toca «{nombre}»?")
    try:
        hora = _hora(datos["hora"]) if str(datos.get("hora") or "").strip() else None
    except (ValueError, KeyError):
        return Decir(f"No entendí la hora de «{nombre}». ¿A qué hora?")
    objetivo = datos.get("objetivo")
    if not isinstance(objetivo, int) or isinstance(objetivo, bool) or objetivo < 1:
        objetivo = 1
    try:
        habito = Habito(
            nombre=nombre,
            icono=_icono(str(datos.get("icono") or ""), iconos),
            color=_color(str(datos.get("color") or "")),
            objetivo=objetivo,
            unidad=str(datos.get("unidad") or "").strip() or UNIDAD_POR_OMISION,
            dias=dias,
            hora=hora,
        )
    except (TypeError, ValueError) as fallo:
        return Decir(f"No pude crear ese hábito: {fallo}.")
    return Hacer(CrearHabito(habito))


def _cual(nombre: str, habitos: list[Habito]) -> Habito | Decir:
    encontrado = buscar_habito(nombre, habitos)
    if encontrado is None:
        return Decir(f"No tengo ningún hábito «{nombre}».")
    if isinstance(encontrado, list):
        nombres = ", ".join(f"«{uno.nombre}»" for uno in encontrado[:4])
        return Decir(f"¿Cuál? Tenés {nombres}.")
    return encontrado


def decidir_cambiar(datos: dict, habitos: list[Habito], iconos: tuple[str, ...]) -> Decir | Hacer:
    antes = _cual(str(datos.get("habito") or ""), habitos)
    if isinstance(antes, Decir):
        return antes
    cambios: dict = {}
    if str(datos.get("nombre") or "").strip():
        cambios["nombre"] = str(datos["nombre"]).strip()
    if isinstance(datos.get("dias"), list) and datos["dias"]:
        dias = _dias(datos["dias"])
        if dias is None:
            return Decir(f"¿Qué días toca «{antes.nombre}»?")
        cambios["dias"] = dias
    hora = str(datos.get("hora") or "").strip()
    if normalizar(hora) == "sin hora":
        cambios["hora"] = None
    elif hora:
        try:
            cambios["hora"] = _hora(hora)
        except ValueError:
            return Decir(f"No entendí la hora nueva de «{antes.nombre}».")
    objetivo = datos.get("objetivo")
    if isinstance(objetivo, int) and not isinstance(objetivo, bool) and objetivo > 0:
        cambios["objetivo"] = objetivo
    if str(datos.get("unidad") or "").strip():
        cambios["unidad"] = str(datos["unidad"]).strip()
    if str(datos.get("icono") or "") in iconos:
        cambios["icono"] = datos["icono"]
    if str(datos.get("color") or "") in COLORES:
        cambios["color"] = datos["color"]
    if not cambios:
        return Decir(f"¿Qué querés cambiar de «{antes.nombre}»?")
    try:
        despues = replace(antes, **cambios)
    except (TypeError, ValueError) as fallo:
        return Decir(f"No pude cambiarlo: {fallo}.")
    return Hacer(CambiarHabito(antes, despues))


def decidir_borrar(datos: dict, habitos: list[Habito], con_historial: frozenset[int]) -> Decir | Confirmar:
    habito = _cual(str(datos.get("habito") or ""), habitos)
    if isinstance(habito, Decir):
        return habito
    archivar = habito.id in con_historial
    pregunta = (
        f"«{habito.nombre}» ya tiene marcas, así que no se borra: se archiva y su "
        "historial se conserva. ¿Lo archivo?"
        if archivar
        else f"¿Borro el hábito «{habito.nombre}»?"
    )
    return Confirmar(BorrarHabito(habito, archivar), pregunta)
