"""Un hábito: algo que quieres hacer, y con qué frecuencia.

QUÉ ES UN HÁBITO AQUÍ: un nombre, un emoji, un color, un objetivo diario con su
unidad ("8 vasos", "30 minutos", "1 vez"), los días de la semana en que toca, y
opcionalmente una hora. "Levantarse temprano" tiene hora; "beber agua" no.

POR QUÉ EL COLOR ES UN NOMBRE Y NO UN COLOR: el dominio no sabe de colores, esa
es la regla de las capas. Aquí se guarda "azul", y la interfaz decide qué azul
(ver interfaz/estilo.py). Así el dominio se puede probar sin abrir una ventana, y
cambiar la paleta no toca ni un dato guardado.

POR QUÉ LOS DÍAS SON LOS DE LA JORNADA Y NO LOS DEL RELOJ: marcar un hábito a las
3 de la madrugada cuenta para la jornada que empezó ayer. Es la misma regla que
el dinero, y para quien trabaja de noche es la diferencia entre una racha real y
una racha rota cada madrugada.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, time
from enum import StrEnum

from .semana import LETRAS
from .validar import exigir_texto

LARGO_MAXIMO_NOMBRE = 40
LARGO_MAXIMO_UNIDAD = 20
LARGO_MAXIMO_EMOJI = 4
OBJETIVO_MAXIMO = 999

# Los ocho colores elegibles. Son nombres, no colores: lo que cada uno significa
# lo decide la interfaz. Cerrados a propósito, como el acento: se elige uno de
# los ocho, no un color libre.
COLORES = ("azul", "verde", "ambar", "rosa", "violeta", "cian", "naranja", "rojo")

TODOS_LOS_DIAS = frozenset(range(7))


def exigir_color(color: str) -> None:
    """Revienta si el color no es uno de los ocho.

    LO USAN LOS HÁBITOS, LOS OBJETIVOS Y LA RUTINA: los tres tenían escrita la
    misma comprobación con el mismo mensaje, que es como acaban dando errores
    distintos para el mismo fallo.
    """
    if color not in COLORES:
        raise ValueError(
            f"color desconocido: {color!r}. Los que hay: {', '.join(COLORES)}"
        )

class Franja(StrEnum):
    """El momento del día en que toca un hábito.

    Los cortes son los del reloj de siempre (6, 12 y 20), decididos con el
    usuario: son los que entiende cualquiera de un vistazo, aunque su turno de
    trabajo vaya de 18:00 a 10:00.
    """

    MANANA = "mañana"
    TARDE = "tarde"
    NOCHE = "noche"
from datetime import datetime


HORA_MANANA = time(6, 0)
HORA_TARDE = time(12, 0)
HORA_NOCHE = time(20, 0)

def franja_de(hora: time) -> Franja:
    """A qué franja pertenece una hora del reloj."""
    if HORA_MANANA <= hora < HORA_TARDE:
        return Franja.MANANA
    if HORA_TARDE <= hora < HORA_NOCHE:
        return Franja.TARDE
    # De 20:00 a 05:59, cruzando la medianoche.
    return Franja.NOCHE


@dataclass(frozen=True)
class Habito:
    nombre: str
    emoji: str
    color: str
    objetivo: int
    """Cuántas unidades hay que hacer al día. Uno o más."""

    unidad: str
    """Cómo se llama cada unidad: "vez", "vasos", "minutos"."""

    dias: frozenset[int]
    """Los días de la semana en que toca, con lunes 0 y domingo 6."""

    hora: time | None = None
    """Opcional. Sirve para ordenar la lista y para las franjas del día."""

    activo: bool = True
    orden: int = 0
    id: int | None = None

    def __post_init__(self) -> None:
        exigir_texto("nombre", self.nombre, LARGO_MAXIMO_NOMBRE, obligatorio=True)
        exigir_texto("emoji", self.emoji, LARGO_MAXIMO_EMOJI, obligatorio=True)
        exigir_texto("unidad", self.unidad, LARGO_MAXIMO_UNIDAD, obligatorio=True)
        # El dataclass es frozen, así que normalizar exige saltarse la
        # inmutabilidad aquí dentro.
        for campo in ("nombre", "emoji", "unidad"):
            object.__setattr__(self, campo, getattr(self, campo).strip())

        exigir_color(self.color)

        if isinstance(self.objetivo, bool) or not isinstance(self.objetivo, int):
            raise TypeError("el objetivo tiene que ser int")
        if not 1 <= self.objetivo <= OBJETIVO_MAXIMO:
            raise ValueError(
                f"el objetivo va de 1 a {OBJETIVO_MAXIMO}, y llegó {self.objetivo}"
            )

        if not isinstance(self.dias, frozenset):
            raise TypeError("dias tiene que ser un frozenset de números de día")
        if not self.dias:
            # Un hábito que no toca ningún día no se puede cumplir nunca, así que
            # tampoco tendría sentido su racha.
            raise ValueError("el hábito tiene que tocar al menos un día")
        if not self.dias <= TODOS_LOS_DIAS:
            raise ValueError(f"días fuera de rango: {sorted(self.dias - TODOS_LOS_DIAS)}")

        if self.hora is not None:
            if not isinstance(self.hora, time):
                raise TypeError("la hora tiene que ser datetime.time o None")
            if self.hora.tzinfo is not None:
                raise ValueError("la hora no lleva zona horaria")
            # Se guarda como "HH:MM": admitir segundos sería perderlos al guardar.
            if self.hora.second or self.hora.microsecond:
                raise ValueError(f"la hora solo admite horas y minutos: {self.hora}")

        if not isinstance(self.activo, bool):
            raise TypeError("activo tiene que ser True o False")
        if isinstance(self.orden, bool) or not isinstance(self.orden, int):
            raise TypeError("orden tiene que ser int")
        if self.orden < 0:
            raise ValueError(f"orden no puede ser negativo, y llegó {self.orden}")
        if self.id is not None:
            if isinstance(self.id, bool) or not isinstance(self.id, int):
                raise TypeError("el id tiene que ser int o None")
            if self.id <= 0:
                raise ValueError(f"id tiene que ser mayor que cero, y llegó {self.id}")

    # ----------------------------------------------------------------------

    @property
    def franja(self) -> Franja | None:
        """La franja del día, o None si el hábito no tiene hora.

        None no es "ninguna franja": es "cualquiera". Un hábito sin hora aparece
        en todas las pestañas, porque vale para cualquier momento.
        """
        return None if self.hora is None else franja_de(self.hora)

    def esta_en_franja(self, franja: Franja) -> bool:
        """Si el hábito debe aparecer en esa pestaña."""
        return self.franja is None or self.franja is franja

    def toca_en(self, jornada: date) -> bool:
        """Si el hábito estaba programado para esa jornada."""
        if not isinstance(jornada, date):
            raise TypeError("la jornada tiene que ser un date")
        return jornada.weekday() in self.dias

    def cumplido_con(self, cantidad: int) -> bool:
        """Si esa cantidad alcanza el objetivo.

        5 vasos de 8 NO cumple, por decisión del usuario: el objetivo es el
        objetivo, y si valiera cualquier avance la racha dejaría de significar
        "lo cumplí" para significar "me acordé".
        """
        return cantidad >= self.objetivo

    def se_apaga_al_pulsar(self, cantidad: int) -> bool:
        """True si pulsar el círculo debe APAGAR el hábito en vez de sumar.

        Solo pasa en los hábitos de una vez —el gimnasio, meditar—: una vez
        hechos, volver a pulsar los deshace, como un interruptor. Sin esto el
        gimnasio acababa en "3/1", que no significa nada.

        En los que se cuentan, cada pulsación suma, y pasarse del objetivo es
        legítimo: si te bebiste nueve vasos, fueron nueve.
        """
        return self.objetivo == 1 and self.cumplido_con(cantidad)

    def texto_avance(self, cantidad: int) -> tuple[str, str]:
        """El contador de la fila, partido en dos: "3/3" y el sobrante "+4".

        POR QUÉ NO SE ENSEÑA "7/3": no significa nada. El objetivo era tres y se
        cumplió; que además hicieras cuatro más es otra cosa, y mezclarlas en una
        fracción hace que el número se lea como un descontrol.

        POR QUÉ NO SE RECORTA A TRES A SECAS: el dato guardado sigue siendo siete,
        porque siete fue lo que hiciste. La app no borra lo que pasó para que la
        pantalla quede limpia; lo enseña aparte, en pequeño.

        Devuelve el sobrante vacío cuando no hay: así quien dibuja no tiene que
        decidir nada, solo pintar lo que le den.
        """
        hechas = min(cantidad, self.objetivo)
        sobran = max(0, cantidad - self.objetivo)
        return f"{hechas}/{self.objetivo}", f"+{sobran}" if sobran else ""

    def texto_objetivo(self) -> str:
        """El objetivo escrito: "8 vasos", "1 vez"."""
        return f"{self.objetivo} {self.unidad}"

    def texto_dias(self) -> str:
        """Los días escritos: "Todos los días", "L M X J V" o "S D"."""
        if self.dias == TODOS_LOS_DIAS:
            return "Todos los días"
        return " ".join(
            letra for numero, letra in enumerate(LETRAS) if numero in self.dias
        )


@dataclass(frozen=True)
class Marca:
    """Cuánto se hizo de un hábito en una jornada.

    Es una cantidad y no un sí/no porque los objetivos se cuentan: al pulsar el
    círculo se suma uno, y el hábito se da por cumplido cuando llega al objetivo.

    Cero es un dato válido y distinto de "no hay marca": significa que se marcó y
    luego se deshizo. A efectos de racha dan lo mismo, pero para entender el
    historial no es igual.
    """

    habito_id: int
    jornada: date
    cantidad: int
    id: int | None = None

    def __post_init__(self) -> None:
        if isinstance(self.habito_id, bool) or not isinstance(self.habito_id, int):
            raise TypeError("habito_id tiene que ser int")
        if self.habito_id <= 0:
            raise ValueError("habito_id tiene que ser mayor que cero")


        # datetime hereda de date, así que hay que descartarlo expresamente.
        if not isinstance(self.jornada, date) or isinstance(self.jornada, datetime):
            raise TypeError("jornada tiene que ser un date, no un datetime")

        if isinstance(self.cantidad, bool) or not isinstance(self.cantidad, int):
            raise TypeError("la cantidad tiene que ser int")
        if self.cantidad < 0:
            raise ValueError(f"la cantidad no puede ser negativa, y llegó {self.cantidad}")

def ordenar(habitos: list[Habito]) -> list[Habito]:
    """Los hábitos en el orden en que se enseñan: por hora, y los sin hora al final.

    POR QUÉ LOS SIN HORA VAN AL FINAL: la lista se lee como el día, de la primera
    cosa a la última. Un hábito sin hora no pertenece a ningún momento, así que
    ponerlo en medio rompería esa lectura. Entre iguales manda el orden que haya
    elegido el usuario, y por último el nombre, para que la lista no baile.
    """
    return sorted(
        habitos,
        key=lambda uno: (
            uno.hora is None,
            uno.hora or time(0, 0),
            uno.orden,
            uno.nombre.lower(),
        ),
    )
