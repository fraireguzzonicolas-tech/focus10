"""Qué programas se pueden cerrar y cuáles NO, pase lo que pase.

LO QUE COSTÓ DESCUBRIR ESTA LISTA: en una versión anterior se desactivó la
protección para "comprobar que servía" y se dejó correr el test. El test cerró
explorer.exe de verdad y se cayeron la barra de tareas y los iconos del
escritorio de la máquina.

De ahí sale la regla que gobierna los tests de este archivo: UNA PRUEBA DE
SEGURIDAD NO PUEDE PROVOCAR EL DESASTRE DEL QUE PROTEGE. La protección se
comprueba llamando a la función pura y mirando qué contesta —nunca cerrando
nada—, y el cierre de verdad se prueba con una copia renombrada de un programa
inofensivo del sistema, que si se muere no se lleva nada por delante.

POR QUÉ ESTÁ EN EL CÓDIGO Y NO EN LA BASE DE DATOS: para que no se pueda quitar
escribiéndolo a mano ni abriendo el archivo de datos con otro programa.

SE COMPRUEBA DOS VECES, al guardar la regla y otra vez justo antes de cerrar.
La segunda no sobra: entre que se guarda una regla y se ejecuta pueden pasar
semanas, y en medio puede haber una actualización, una restauración de la base
de datos o un archivo tocado a mano.
"""

from __future__ import annotations

import re

#: Nada de esta lista se cierra jamás. Sin la extensión: se compara el nombre.
PROTEGIDOS: frozenset[str] = frozenset(
    {
        # El núcleo de Windows. Cerrar cualquiera de estos va de "se cae el
        # escritorio" a "pantalla azul en el acto".
        "system",
        "smss",
        "csrss",
        "wininit",
        "winlogon",
        "services",
        "lsass",
        "lsaiso",
        "svchost",
        "explorer",
        "dwm",
        "fontdrvhost",
        "sihost",
        "ctfmon",
        "shellexperiencehost",
        "startmenuexperiencehost",
        "searchhost",
        "runtimebroker",
        "taskhostw",
        "userinit",
        "logonui",
        "conhost",
        "dllhost",
        "wudfhost",
        "audiodg",
        "spoolsv",
        "registry",
        "memory compression",
        "idle",
        # La propia aplicación. Cerrarse a sí misma dejaría el bloqueo de webs
        # puesto y sin nadie que lo quite.
        "focus10",
        "python",
        "pythonw",
        "flet",
        # Antivirus y seguridad. Además de dejarte desprotegido, muchos no se
        # dejan cerrar y el intento acaba en un error raro y sin explicación.
        "msmpeng",
        "mssense",
        "securityhealthservice",
        "securityhealthsystray",
        "windowsdefender",
        "smartscreen",
        "avp",
        "avastsvc",
        "avgsvc",
        "bdagent",
        "mbamservice",
        "nortonsecurity",
        "ekrn",
        "sophosui",
        "sedservice",
    }
)

LARGO_MAXIMO = 260


class ProcesoProtegido(ValueError):
    """Se intentó cerrar algo de la lista protegida."""


class ProcesoInvalido(ValueError):
    """Lo que se escribió no es un nombre de proceso utilizable."""


# Un nombre de archivo de Windows, sin carpetas ni comodines.
_NOMBRE = re.compile(r"^[a-z0-9 ._+-]+$")


def normalizar(texto: str) -> str:
    """Deja el nombre del proceso en su forma canónica, o avisa si no vale.

    Quita la ruta, la extensión .exe y las mayúsculas. Esto es la mitad de la
    seguridad: si "C:\\Windows\\explorer.EXE" no se redujera a "explorer",
    pasaría por la lista de protegidos sin que salte, y se cerraría el
    escritorio.

    SIN COMODINES, por decisión del usuario: un "*" aquí significa "cierra todo
    lo que empiece por", y basta un despiste para llevarse por delante media
    máquina. Nombre exacto o nada.
    """
    if not isinstance(texto, str):
        raise ProcesoInvalido(f"esto no es texto: {type(texto).__name__}")

    limpio = texto.strip().strip('"').strip().lower()
    if len(limpio) > LARGO_MAXIMO:
        raise ProcesoInvalido("ese nombre es demasiado largo para ser un programa")

    # La ruta, venga con barras de Windows o de las otras.
    limpio = limpio.replace("\\", "/").rsplit("/", 1)[-1]
    # La extensión.
    for extension in (".exe", ".com", ".bat", ".cmd", ".scr"):
        if limpio.endswith(extension):
            limpio = limpio[: -len(extension)]
            break
    limpio = limpio.strip()

    if not limpio:
        raise ProcesoInvalido("el nombre del programa no puede estar vacío")
    if "*" in limpio or "?" in limpio:
        raise ProcesoInvalido(
            "no se admiten comodines: escribe el nombre exacto del programa, "
            "como «discord» o «spotify»."
        )
    if not _NOMBRE.match(limpio):
        raise ProcesoInvalido(
            f"«{texto.strip()}» no parece el nombre de un programa. "
            "Se escribe como «discord.exe» o «discord»."
        )
    return limpio


def esta_protegido(nombre: str) -> bool:
    """Si ese programa es de los que no se cierran nunca.

    ESTA ES LA FUNCIÓN QUE SE PRUEBA para comprobar la protección. Es pura: se
    le pregunta y contesta, sin tocar ni un proceso. Comprobarlo cerrando cosas
    de verdad es lo que tiró el escritorio aquella vez.
    """
    try:
        return normalizar(nombre) in PROTEGIDOS
    except ProcesoInvalido:
        # Lo que no es un nombre válido no se cierra igualmente, pero decir aquí
        # "no protegido" invitaría a que quien llame lo intente. Se trata como
        # protegido: ante la duda, no se cierra nada.
        return True


def exigir_cerrable(texto: str) -> str:
    """Devuelve el nombre listo para guardar, o explica por qué no se puede.

    Es la ÚNICA puerta de entrada de un programa a la lista de cerrables, y la
    que se llama LAS DOS VECES: al guardar la regla y otra vez justo antes de
    cerrar nada.
    """
    limpio = normalizar(texto)
    if limpio in PROTEGIDOS:
        raise ProcesoProtegido(
            f"«{limpio}» no se puede cerrar: es parte de Windows, de esta "
            "aplicación o de tu antivirus. Cerrarlo rompería el sistema."
        )
    return limpio


def filtrar_cerrables(nombres: list[str]) -> tuple[list[str], list[str]]:
    """Parte una lista en (los que se pueden cerrar, los que no).

    Se usa justo antes de cerrar: si por lo que sea se ha colado un protegido en
    la base de datos, aquí se queda fuera y se puede avisar de cuál era.
    """
    cerrables: list[str] = []
    rechazados: list[str] = []
    for nombre in nombres:
        try:
            cerrables.append(exigir_cerrable(nombre))
        except (ProcesoProtegido, ProcesoInvalido):
            rechazados.append(nombre)
    return cerrables, rechazados
