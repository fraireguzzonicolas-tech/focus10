"""Convertir un importe de una moneda a otra.

QUÉ ES UNA TASA AQUÍ: cuántas unidades grandes de la moneda DESTINO vale una
unidad grande de la moneda ORIGEN. Si un dólar vale 0,92 euros, la tasa de
USD a EUR es 0,92.

POR QUÉ LA TASA ES UN Decimal Y SE GUARDA COMO TEXTO: un tipo de cambio no es
dinero, pero comparte su problema. Si se guardara como float, 0,92 no sería
exactamente 0,92 y el importe convertido podría bailar un céntimo entre dos
ejecuciones. Guardado como texto ("0.92") y leído a Decimal, el resultado es
siempre el mismo.

POR QUÉ CADA MOVIMIENTO GUARDA SU PROPIA TASA (decidido con el usuario): la del
día en que se apuntó, no la de hoy. Si se convirtiera al vuelo con la tasa
actual, el resumen de marzo cambiaría solo cada mañana, y eso es justo lo que no
se quiere de una aplicación de finanzas.
"""

from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from .moneda import Moneda

TASA_UNO = Decimal(1)


class TasaInvalida(ValueError):
    """El tipo de cambio no sirve: cero, negativo, infinito o mal escrito."""


def convertir(unidades: int, origen: Moneda, destino: Moneda, tasa: Decimal) -> int:
    """Pasa un importe en unidades mínimas de `origen` a unidades de `destino`.

    Redondea con el criterio comercial (el 5 sube), igual que el resto del
    dinero de la aplicación.
    """
    if isinstance(unidades, bool) or not isinstance(unidades, int):
        raise TypeError(f"las unidades tienen que ser int, no {type(unidades).__name__}")
    for nombre, moneda in (("origen", origen), ("destino", destino)):
        if not isinstance(moneda, Moneda):
            raise TypeError(f"{nombre} tiene que ser una Moneda")
    _exigir_tasa(tasa)

    if origen == destino and tasa != TASA_UNO:
        # Convertir euros a euros con una tasa distinta de 1 solo puede ser un
        # error de programación, y falsearía el importe en silencio.
        raise TasaInvalida(
            f"convertir {origen.codigo} a sí misma exige tasa 1, y llegó {tasa}"
        )

    cantidad_origen = Decimal(unidades) / origen.unidades_por_entero
    resultado = cantidad_origen * tasa * destino.unidades_por_entero
    return int(resultado.quantize(Decimal(1), rounding=ROUND_HALF_UP))


def tasa_desde_texto(texto: str) -> Decimal:
    """Lee la tasa guardada en la base de datos (columna de texto)."""
    if not isinstance(texto, str):
        raise TasaInvalida(f"la tasa se guarda como texto, no {type(texto).__name__}")
    try:
        tasa = Decimal(texto.strip())
    except InvalidOperation as error:
        raise TasaInvalida(f"tasa mal escrita: {texto!r}") from error
    _exigir_tasa(tasa)
    return tasa


def tasa_a_texto(tasa: Decimal) -> str:
    """Escribe la tasa para guardarla, sin perder ni un dígito."""
    _exigir_tasa(tasa)
    return format(tasa, "f")


def _exigir_tasa(tasa: Decimal) -> None:
    if isinstance(tasa, float):
        raise TasaInvalida(
            "la tasa no puede ser float porque pierde precisión; "
            "usa Decimal('0.92')"
        )
    if not isinstance(tasa, Decimal):
        raise TasaInvalida(f"la tasa tiene que ser Decimal, no {type(tasa).__name__}")
    if not tasa.is_finite():
        raise TasaInvalida(f"tasa no finita: {tasa}")
    if tasa <= 0:
        # Una tasa de cero convertiría cualquier gasto en cero euros, y una
        # negativa cambiaría un gasto por un ingreso.
        raise TasaInvalida(f"la tasa tiene que ser mayor que cero, y llegó {tasa}")
