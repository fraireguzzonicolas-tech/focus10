"""Sacar números aproximados de lo que se escribe, si son cosas normales.

"2 huevos con tostadas", "una taza de arroz", "200 g de pollo", "media pizza".

LA REGLA QUE MANDA AQUÍ, y existe por un fallo de verdad: una versión muy
anterior analizaba el texto y le puso 29 kcal a 300 gramos de fideos. Por eso
esta pieza tiene tres frenos:

  1. SI UNA SOLA PARTE NO SE ENTIENDE, NO SE ESTIMA NADA. "napolitana con
     berenjena" no da la berenjena sola y se calla lo otro: no da nada, y lo
     escribe el usuario. Una estimación a medias parece completa y no lo es.
  2. SOLO SE USAN LOS ALIMENTOS DE LA LISTA (alimentos_comunes.py), que tiene un
     test que revisa que cada fila cuadre consigo misma.
  3. NUNCA SE GUARDA SOLA. Se ofrece con "≈", enseñando los gramos que se
     supusieron, y el usuario la toca, la mira y decide.

LO QUE ESCRIBES MANDA: "200 g de pollo" son 200 gramos, digan lo que digan las
porciones de la lista. La porción solo se usa cuando no pones cantidad.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from .alimento import DECIMAS_MAXIMAS, KCAL_MAXIMAS
from .alimentos_comunes import FILAS
from .palabras import normalizar, palabras, singular

GRAMOS_MAXIMOS = 5000
"""Por parte. Más de cinco kilos de algo es un dedo torpe, no una comida."""

_UNO = "uno"
_PORCION = "porcion"

NUMEROS = {
    "un": 1, "una": 1, "uno": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5,
    "seis": 6, "siete": 7, "ocho": 8, "nueve": 9, "diez": 10, "doce": 12,
    "medio": 0.5, "media": 0.5, "cuarto": 0.25,
}

UNIDADES = {
    "g": 1, "gr": 1, "grs": 1, "gramo": 1, "kg": 1000, "kilo": 1000,
    "ml": 1, "cc": 1, "l": 1000, "litro": 1000,
    "taza": 200, "vaso": 250, "copa": 150, "lata": 350, "botella": 500,
    "cucharada": 15, "cda": 15, "cucharadita": 5, "cdta": 5,
    "punado": 30, "plato": 300, "bol": 300,
    "porcion": _PORCION,
    "rebanada": _UNO, "feta": _UNO, "rodaja": _UNO, "unidad": _UNO,
    "pieza": _UNO, "trozo": _UNO,
}
"""Lo que pesa cada medida casera, en gramos. Los mililitros cuentan como
gramos: para lo que se bebe, la diferencia no llega a cambiar el número."""

RELLENO = frozenset({"de", "del", "al", "a", "la", "el", "los", "las"})
"""Palabras que no cambian qué alimento es: "taza de arroz" es arroz."""

PREPARACIONES = frozenset({
    "revuelto", "revuelta", "duro", "hervido", "hervida", "cocido", "cocida", "poche",
    "plancha", "horno", "natural", "casero", "casera",
})
"""Cómo se hizo, cuando casi no cambia los números: "huevos revueltos" son
huevos. Solo se quitan si el nombre entero no está en la lista ("papas fritas"
sí está, y por eso "frito" NO va aquí: freír cambia la grasa de verdad)."""

_AL_EMPEZAR = re.compile(
    r"^(?:(?:comi|me|hoy|yo|almorce|cene|desayune|merende|tome|bebi)\s+)+"
)
_SEPARADOR = re.compile(r"\s*(,(?!\d)|\+|\bcon\b|\by\b|\bmas\b)\s*")
_NUMERO = re.compile(r"^\d+(?:[.,]\d+)?$")
_FRACCION = re.compile(r"^(\d+)/(\d+)$")


@dataclass(frozen=True)
class Alimento:
    nombre: str
    kcal: int
    proteinas: float
    carbohidratos: float
    grasas: float
    uno: int
    porcion: int


@dataclass(frozen=True)
class Parte:
    """Una cosa de la frase, ya convertida. Los macros en décimas de gramo."""

    nombre: str
    gramos: int
    kcal: int
    proteinas: int
    carbohidratos: int
    grasas: int


@dataclass(frozen=True)
class Estimacion:
    partes: tuple[Parte, ...]

    @property
    def kcal(self) -> int:
        return sum(p.kcal for p in self.partes)

    @property
    def proteinas(self) -> int:
        return sum(p.proteinas for p in self.partes)

    @property
    def carbohidratos(self) -> int:
        return sum(p.carbohidratos for p in self.partes)

    @property
    def grasas(self) -> int:
        return sum(p.grasas for p in self.partes)

    def detalle(self) -> str:
        """"huevo 100 g + tostada 50 g": lo que se supuso, para poder corregirlo."""
        return " + ".join(f"{p.nombre} {p.gramos} g" for p in self.partes)


def _clave(fichas) -> tuple[str, ...]:
    return tuple(singular(f) for f in fichas if f not in RELLENO)


def _indice() -> dict[tuple[str, ...], Alimento]:
    indice = {}
    for fila in FILAS:
        nombres, kcal, prot, hidr, gras, uno = fila[:6]
        porcion = fila[6] if len(fila) > 6 else uno
        todos = nombres.split("|")
        alimento = Alimento(todos[0], kcal, prot, hidr, gras, uno, porcion)
        for nombre in todos:
            indice[_clave(palabras(nombre))] = alimento
    return indice


_INDICE = _indice()


def _numero(ficha: str) -> float | None:
    if _NUMERO.match(ficha):
        return float(ficha.replace(",", "."))
    if fraccion := _FRACCION.match(ficha):
        abajo = int(fraccion.group(2))
        return int(fraccion.group(1)) / abajo if abajo else None
    return NUMEROS.get(ficha)


def _parte(fichas: list[str]) -> Parte | None:
    fichas = list(fichas)
    cantidad = _numero(fichas[0]) if fichas else None
    if cantidad is not None:
        fichas.pop(0)
        # "un par de huevos"
        if fichas and fichas[0] == "par":
            cantidad *= 2
            fichas.pop(0)

    unidad = None
    while fichas and fichas[0] in RELLENO:
        fichas.pop(0)
    if fichas and singular(fichas[0]) in UNIDADES:
        unidad = UNIDADES[singular(fichas[0])]
        fichas.pop(0)
    elif fichas and fichas[0] in UNIDADES:
        unidad = UNIDADES[fichas[0]]
        fichas.pop(0)

    alimento = _INDICE.get(_clave(fichas)) or _INDICE.get(
        tuple(f for f in _clave(fichas) if f not in PREPARACIONES)
    )
    if alimento is None:
        return None

    if unidad is None and cantidad is None:
        en_plural = any(f != singular(f) for f in fichas)
        # "HUEVOS CON TOSTADAS" SIN NÚMERO SON MÁS DE UNA TOSTADA: quien escribe
        # el plural de algo pequeño está diciendo "unas cuantas". Con lo grande
        # ("papas fritas") el plural es solo cómo se llama, y es una porción.
        if en_plural and alimento.uno <= 60:
            gramos = max(2 * alimento.uno, 30)
        else:
            gramos = alimento.uno
    else:
        if unidad is None or unidad == _UNO:
            base = alimento.uno
        elif unidad == _PORCION:
            base = alimento.porcion
        else:
            base = unidad
        gramos = round((1 if cantidad is None else cantidad) * base)

    if gramos <= 0 or gramos > GRAMOS_MAXIMOS:
        return None
    return Parte(
        nombre=alimento.nombre,
        gramos=gramos,
        kcal=round(alimento.kcal * gramos / 100),
        # por 100 g -> décimas de gramo: x gramos/100 x 10
        proteinas=round(alimento.proteinas * gramos / 10),
        carbohidratos=round(alimento.carbohidratos * gramos / 10),
        grasas=round(alimento.grasas * gramos / 10),
    )


def estimar(texto: str) -> Estimacion | None:
    """La estimación de la frase entera, o None si algo no se entiende.

    SE PRUEBAN PRIMERO LOS TROZOS MÁS LARGOS: "café con leche" está en la lista
    como una cosa, y partirlo en "café" + "leche" daría otro número. Solo si el
    trozo largo no existe se parte por "con", "y", "+" o la coma.
    """
    limpio = _AL_EMPEZAR.sub("", normalizar(texto).strip())
    trozos = _SEPARADOR.split(limpio)
    textos, separadores = trozos[0::2], trozos[1::2]
    cuantos = len(textos)
    recordado: dict[int, tuple[Parte, ...] | None] = {}

    def desde(inicio: int) -> tuple[Parte, ...] | None:
        if inicio == cuantos:
            return ()
        if inicio in recordado:
            return recordado[inicio]
        recordado[inicio] = None
        for fin in range(cuantos, inicio, -1):
            junto = textos[inicio]
            for k in range(inicio, fin - 1):
                junto += f" {separadores[k]} {textos[k + 1]}"
            parte = _parte(palabras(junto))
            if parte is None:
                continue
            resto = desde(fin)
            if resto is not None:
                recordado[inicio] = (parte, *resto)
                break
        return recordado[inicio]

    partes = desde(0)
    if not partes:
        return None
    estimacion = Estimacion(partes)
    if estimacion.kcal > KCAL_MAXIMAS or max(
        estimacion.proteinas, estimacion.carbohidratos, estimacion.grasas
    ) > DECIMAS_MAXIMAS:
        return None
    return estimacion
