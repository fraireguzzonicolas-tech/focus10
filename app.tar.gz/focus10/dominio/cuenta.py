"""La cuenta del usuario: un correo, una contraseña y una sesión abierta.

LO PIDIÓ EL USUARIO: "una cuenta de usuario típica, donde te piden un mail y una
contraseña, nada más". Y el motivo de fondo: "si yo pongo que tomé un litro y
medio de agua en el celular debe aparecer en la web".

ESTO SOLO SABE DE REGLAS, NO DE RED NI DE PANTALLAS. Aquí se decide qué correo
vale, qué contraseña vale y cuándo una sesión está viva. Hablar con el servidor
es cosa de sistema/cuentas.py, y eso permite probar todo esto sin internet.

LA CONTRASEÑA NO SE GUARDA NUNCA, ni aquí ni en ningún sitio de la aplicación.
Se escribe, se manda al servicio de cuentas y se olvida. Lo que se guarda es el
testigo que devuelve ese servicio, que caduca solo y no sirve para entrar en
ninguna otra parte.

TENER CUENTA ES OPCIONAL, y esa es una decisión de diseño: la aplicación entera
funciona sin registrarse, igual que hasta ahora. La cuenta solo añade que tus
datos te sigan de un aparato a otro.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timedelta

LARGO_MINIMO_CONTRASENA = 8
"""Ocho letras.

EL SERVICIO ACEPTA SEIS, y aun así se piden ocho: la diferencia para ti es dos
teclas y para quien quiera adivinarla son varios órdenes de magnitud. Es de las
pocas veces que ser más estricto no le cuesta nada a nadie.
"""

LARGO_MAXIMO_CONTRASENA = 72
"""El tope de bcrypt, que es lo que usan por debajo casi todos estos servicios.

MÁS LARGO NO SE RECHAZA POR CAPRICHO: bcrypt IGNORA lo que pase de 72 bytes sin
avisar. Alguien con una contraseña de cien letras creería que las cien cuentan.
"""

# Un correo tiene algo, una arroba, algo, un punto y algo. Comprobar más que eso
# es inventarse reglas que dejan fuera correos que existen: quien decide si un
# correo es de verdad es el propio correo de confirmación, no una expresión.
_CORREO = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

MARGEN_DE_CADUCIDAD = timedelta(minutes=5)
"""Cuánto antes se considera caducado un testigo.

SE ADELANTA A PROPÓSITO: si se diera por bueno hasta el último segundo, una
sincronización que empieza justo antes de caducar fallaría a la mitad. Cinco
minutos de margen hacen que eso no pase nunca.
"""


LARGO_CODIGO = 6
"""Las cifras del código que llega por correo.

SEIS PORQUE ES LO QUE MANDA SUPABASE, no una elección nuestra. Se escribe aquí
para que el aviso al escribir cinco salga al instante y no después de un viaje
a Irlanda.
"""


class CodigoInvalido(ValueError):
    """El código escrito no tiene la forma de un código."""


class CorreoInvalido(ValueError):
    """Lo escrito no parece un correo."""


class ContrasenaInvalida(ValueError):
    """La contraseña no cumple lo mínimo."""


def exigir_correo(correo: str) -> str:
    """Devuelve el correo limpio, o revienta diciendo qué pasa."""
    if not isinstance(correo, str):
        raise CorreoInvalido("el correo tiene que ser texto")
    limpio = correo.strip().lower()
    if not limpio:
        raise CorreoInvalido("hace falta un correo")
    if not _CORREO.match(limpio):
        raise CorreoInvalido("eso no parece un correo")
    return limpio


def exigir_contrasena(contrasena: str) -> str:
    """Comprueba la contraseña y la devuelve TAL CUAL.

    NO SE RECORTAN LOS ESPACIOS, al revés que en el correo: un espacio al final
    de una contraseña es parte de la contraseña. Recortarlo dejaría fuera a
    quien lo puso a propósito, y encima solo al volver a entrar.
    """
    if not isinstance(contrasena, str):
        raise ContrasenaInvalida("la contraseña tiene que ser texto")
    if len(contrasena) < LARGO_MINIMO_CONTRASENA:
        raise ContrasenaInvalida(
            f"la contraseña necesita al menos {LARGO_MINIMO_CONTRASENA} letras"
        )
    if len(contrasena.encode("utf-8")) > LARGO_MAXIMO_CONTRASENA:
        raise ContrasenaInvalida(
            f"la contraseña no puede pasar de {LARGO_MAXIMO_CONTRASENA} letras"
        )
    return contrasena


def exigir_codigo(codigo: str) -> str:
    """Devuelve el código limpio de espacios, o revienta diciendo qué pasa.

    SE QUITAN LOS ESPACIOS Y LOS GUIONES antes de mirar nada. Un código copiado
    del correo viene la mitad de las veces con un espacio detrás, y rechazarlo
    por eso es hacerle perder el tiempo a alguien que lo ha escrito bien.
    """
    if not isinstance(codigo, str):
        raise CodigoInvalido("el código tiene que ser texto")
    limpio = codigo.strip().replace(" ", "").replace("-", "")
    if not limpio:
        raise CodigoInvalido("hace falta el código que te ha llegado por correo")
    if not limpio.isdigit() or len(limpio) != LARGO_CODIGO:
        raise CodigoInvalido(f"el código son {LARGO_CODIGO} cifras")
    return limpio


@dataclass(frozen=True)
class Sesion:
    """Una sesión abierta: quién eres y hasta cuándo vale el testigo."""

    correo: str
    testigo: str
    """El que se manda en cada petición. Caduca en una hora, más o menos."""

    refresco: str
    """El que sirve para pedir un testigo nuevo sin volver a escribir nada."""

    caduca_en: datetime

    def __post_init__(self) -> None:
        object.__setattr__(self, "correo", exigir_correo(self.correo))
        for campo in ("testigo", "refresco"):
            valor = getattr(self, campo)
            if not isinstance(valor, str) or not valor.strip():
                raise ValueError(f"falta {campo} en la sesión")
        if not isinstance(self.caduca_en, datetime):
            raise TypeError("caduca_en tiene que ser un datetime")

    def esta_viva(self, ahora: datetime) -> bool:
        """Si el testigo todavía sirve, con margen para no pillarse los dedos."""
        return ahora + MARGEN_DE_CADUCIDAD < self.caduca_en


def caducidad(ahora: datetime, segundos: int) -> datetime:
    """Cuándo caduca un testigo que dura `segundos` desde ahora."""
    if not isinstance(segundos, int) or isinstance(segundos, bool):
        raise TypeError("los segundos tienen que ser un entero")
    if segundos <= 0:
        raise ValueError("un testigo que ya nace caducado no sirve de nada")
    return ahora + timedelta(seconds=segundos)
