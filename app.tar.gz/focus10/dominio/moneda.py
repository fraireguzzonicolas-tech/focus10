"""Las monedas que Focus10 sabe manejar.

POR QUÉ EL CATÁLOGO ESTÁ EN EL CÓDIGO Y NO EN UNA TABLA: una moneda no es un
dato que el usuario invente, es un hecho del mundo. El euro tiene dos decimales
y el yen ninguno, y eso no se configura. Si estuviera en una tabla se podría
guardar una moneda a medias (un símbolo sin decimales, un código de cuatro
letras) y los importes empezarían a salir mal sin que nadie supiera por qué.
Añadir una moneda nueva es una línea aquí y un test; es más barato que mantener
una pantalla de administración que casi nunca se usa.

POR QUÉ "unidades mínimas" y no "céntimos": el dinero se guarda como entero de
la unidad más pequeña de SU moneda. En euros son céntimos (1/100), en yenes es
el yen entero (no hay fracción), y en dinares son milésimas (1/1000). Llamarlo
"céntimos" cuando puede haber dólares delante sería mentir en el nombre.
"""

from __future__ import annotations

from dataclasses import dataclass


class MonedaDesconocida(KeyError):
    """Se ha pedido una moneda que no está en el catálogo."""


@dataclass(frozen=True)
class Moneda:
    codigo: str
    """Código ISO de tres letras en mayúsculas: EUR, USD. Es lo que se guarda
    en la base de datos, porque no cambia nunca; el símbolo sí podría cambiar."""

    nombre: str
    simbolo: str

    decimales: int
    """Cuántos decimales tiene: 2 para el euro y el dólar, 0 para el yen."""

    simbolo_delante: bool
    """Dónde va el símbolo al escribir el importe. En español el euro va detrás
    ("8,50 €") y el dólar delante ("US$ 8,50")."""

    def __post_init__(self) -> None:
        if len(self.codigo) != 3 or not self.codigo.isalpha() or not self.codigo.isupper():
            raise ValueError(f"el código tiene que ser tres letras mayúsculas: {self.codigo!r}")
        if not self.simbolo:
            raise ValueError(f"la moneda {self.codigo} necesita un símbolo")
        # Cuatro decimales es el máximo que existe en la realidad; más allá es
        # con seguridad un error de configuración.
        if not isinstance(self.decimales, int) or not 0 <= self.decimales <= 4:
            raise ValueError(f"decimales fuera de rango en {self.codigo}: {self.decimales!r}")

    @property
    def unidades_por_entero(self) -> int:
        """Cuántas unidades mínimas hay en una unidad "grande": 100 en el euro."""
        return 10**self.decimales


EUR = Moneda(codigo="EUR", nombre="euro", simbolo="€", decimales=2, simbolo_delante=False)
USD = Moneda(
    codigo="USD",
    nombre="dólar estadounidense",
    simbolo="US$",
    decimales=2,
    simbolo_delante=True,
)

# EL CATÁLOGO ENTERO. Se pone en una lista y no como constantes sueltas porque
# son muchas y ninguna se usa por su nombre desde el código: se piden por código
# con por_codigo(). El euro y el dólar sí tienen nombre propio ahí arriba porque
# hay código que los nombra —los tests, el valor de partida— y una constante se
# lee mejor que una búsqueda en un diccionario.
#
# QUÉ HACE FALTA PARA AÑADIR UNA: una línea aquí. Nada más. No hay tabla que
# migrar ni pantalla de administración: una moneda no es un dato que el usuario
# invente, es un hecho del mundo.
#
# LOS DECIMALES SON LOS DE LA NORMA ISO 4217 y no una preferencia de nadie. El
# yen no tiene fracción, el peso chileno tampoco, y el dinar kuwaití tiene TRES.
# Poner dos a todas por comodidad haría que un importe en yenes se guardara cien
# veces más grande de lo que es, y eso no daría ningún error: solo un número mal.
# NINGÚN SÍMBOLO SE REPITE, y hay un test que lo vigila. Las cuatro coronas
# nórdicas usan "kr" en la vida real y el córdoba nicaragüense usa "C$" igual que
# el dólar canadiense; aquí no pueden, porque en una pantalla donde solo se ve el
# importe, "1.200 kr" no dice si son suecas o danesas. En esos casos se usa el
# código: es más feo y es cierto, que en dinero es el orden correcto.
TODAS: tuple[Moneda, ...] = (
    EUR,
    USD,
    Moneda(codigo="GBP", nombre="libra esterlina", simbolo="£", decimales=2, simbolo_delante=True),
    Moneda(codigo="CHF", nombre="franco suizo", simbolo="CHF", decimales=2, simbolo_delante=False),
    Moneda(codigo="SEK", nombre="corona sueca", simbolo="SEK", decimales=2, simbolo_delante=False),
    Moneda(codigo="NOK", nombre="corona noruega", simbolo="NOK", decimales=2, simbolo_delante=False),
    Moneda(codigo="DKK", nombre="corona danesa", simbolo="DKK", decimales=2, simbolo_delante=False),
    Moneda(codigo="ISK", nombre="corona islandesa", simbolo="ISK", decimales=0, simbolo_delante=False),
    Moneda(codigo="PLN", nombre="esloti polaco", simbolo="zł", decimales=2, simbolo_delante=False),
    Moneda(codigo="CZK", nombre="corona checa", simbolo="Kč", decimales=2, simbolo_delante=False),
    Moneda(codigo="HUF", nombre="florín húngaro", simbolo="Ft", decimales=0, simbolo_delante=False),
    Moneda(codigo="RON", nombre="leu rumano", simbolo="lei", decimales=2, simbolo_delante=False),
    Moneda(codigo="BGN", nombre="lev búlgaro", simbolo="лв", decimales=2, simbolo_delante=False),
    Moneda(codigo="RSD", nombre="dinar serbio", simbolo="din", decimales=2, simbolo_delante=False),
    Moneda(codigo="TRY", nombre="lira turca", simbolo="₺", decimales=2, simbolo_delante=True),
    Moneda(codigo="UAH", nombre="grivna ucraniana", simbolo="₴", decimales=2, simbolo_delante=False),
    Moneda(codigo="RUB", nombre="rublo ruso", simbolo="₽", decimales=2, simbolo_delante=False),
    Moneda(codigo="CAD", nombre="dólar canadiense", simbolo="CA$", decimales=2, simbolo_delante=True),
    Moneda(codigo="MXN", nombre="peso mexicano", simbolo="MX$", decimales=2, simbolo_delante=True),
    Moneda(codigo="ARS", nombre="peso argentino", simbolo="AR$", decimales=2, simbolo_delante=True),
    Moneda(codigo="BRL", nombre="real brasileño", simbolo="R$", decimales=2, simbolo_delante=True),
    Moneda(codigo="CLP", nombre="peso chileno", simbolo="CL$", decimales=0, simbolo_delante=True),
    Moneda(codigo="COP", nombre="peso colombiano", simbolo="CO$", decimales=2, simbolo_delante=True),
    Moneda(codigo="PEN", nombre="sol peruano", simbolo="S/", decimales=2, simbolo_delante=True),
    Moneda(codigo="UYU", nombre="peso uruguayo", simbolo="$U", decimales=2, simbolo_delante=True),
    Moneda(codigo="BOB", nombre="boliviano", simbolo="Bs", decimales=2, simbolo_delante=True),
    Moneda(codigo="PYG", nombre="guaraní paraguayo", simbolo="₲", decimales=0, simbolo_delante=True),
    Moneda(codigo="VES", nombre="bolívar venezolano", simbolo="Bs.S", decimales=2, simbolo_delante=True),
    Moneda(codigo="CRC", nombre="colón costarricense", simbolo="₡", decimales=2, simbolo_delante=True),
    Moneda(codigo="GTQ", nombre="quetzal guatemalteco", simbolo="Q", decimales=2, simbolo_delante=True),
    Moneda(codigo="DOP", nombre="peso dominicano", simbolo="RD$", decimales=2, simbolo_delante=True),
    Moneda(codigo="CUP", nombre="peso cubano", simbolo="CUP$", decimales=2, simbolo_delante=True),
    Moneda(codigo="PAB", nombre="balboa panameño", simbolo="B/.", decimales=2, simbolo_delante=True),
    Moneda(codigo="HNL", nombre="lempira hondureño", simbolo="L", decimales=2, simbolo_delante=True),
    Moneda(codigo="NIO", nombre="córdoba nicaragüense", simbolo="C$", decimales=2, simbolo_delante=True),
    Moneda(codigo="JPY", nombre="yen japonés", simbolo="¥", decimales=0, simbolo_delante=True),
    Moneda(codigo="CNY", nombre="yuan chino", simbolo="CN¥", decimales=2, simbolo_delante=True),
    Moneda(codigo="KRW", nombre="won surcoreano", simbolo="₩", decimales=0, simbolo_delante=True),
    Moneda(codigo="INR", nombre="rupia india", simbolo="₹", decimales=2, simbolo_delante=True),
    Moneda(codigo="SGD", nombre="dólar de Singapur", simbolo="S$", decimales=2, simbolo_delante=True),
    Moneda(codigo="HKD", nombre="dólar de Hong Kong", simbolo="HK$", decimales=2, simbolo_delante=True),
    Moneda(codigo="TWD", nombre="dólar taiwanés", simbolo="NT$", decimales=2, simbolo_delante=True),
    Moneda(codigo="THB", nombre="baht tailandés", simbolo="฿", decimales=2, simbolo_delante=True),
    Moneda(codigo="MYR", nombre="ringgit malasio", simbolo="RM", decimales=2, simbolo_delante=True),
    Moneda(codigo="IDR", nombre="rupia indonesia", simbolo="Rp", decimales=2, simbolo_delante=True),
    Moneda(codigo="PHP", nombre="peso filipino", simbolo="₱", decimales=2, simbolo_delante=True),
    Moneda(codigo="VND", nombre="dong vietnamita", simbolo="₫", decimales=0, simbolo_delante=False),
    Moneda(codigo="AUD", nombre="dólar australiano", simbolo="A$", decimales=2, simbolo_delante=True),
    Moneda(codigo="NZD", nombre="dólar neozelandés", simbolo="NZ$", decimales=2, simbolo_delante=True),
    Moneda(codigo="ILS", nombre="nuevo shéquel israelí", simbolo="₪", decimales=2, simbolo_delante=True),
    Moneda(codigo="AED", nombre="dirham de Emiratos", simbolo="AED", decimales=2, simbolo_delante=False),
    Moneda(codigo="SAR", nombre="riyal saudí", simbolo="SAR", decimales=2, simbolo_delante=False),
    Moneda(codigo="QAR", nombre="riyal catarí", simbolo="QAR", decimales=2, simbolo_delante=False),
    Moneda(codigo="KWD", nombre="dinar kuwaití", simbolo="KWD", decimales=3, simbolo_delante=False),
    Moneda(codigo="BHD", nombre="dinar bahreiní", simbolo="BHD", decimales=3, simbolo_delante=False),
    Moneda(codigo="OMR", nombre="rial omaní", simbolo="OMR", decimales=3, simbolo_delante=False),
    Moneda(codigo="JOD", nombre="dinar jordano", simbolo="JOD", decimales=3, simbolo_delante=False),
    Moneda(codigo="TND", nombre="dinar tunecino", simbolo="DT", decimales=3, simbolo_delante=False),
    Moneda(codigo="MAD", nombre="dirham marroquí", simbolo="DH", decimales=2, simbolo_delante=False),
    Moneda(codigo="EGP", nombre="libra egipcia", simbolo="E£", decimales=2, simbolo_delante=True),
    Moneda(codigo="ZAR", nombre="rand sudafricano", simbolo="R", decimales=2, simbolo_delante=True),
    Moneda(codigo="NGN", nombre="naira nigeriana", simbolo="₦", decimales=2, simbolo_delante=True),
    Moneda(codigo="KES", nombre="chelín keniano", simbolo="KSh", decimales=2, simbolo_delante=True),
)

CATALOGO: dict[str, Moneda] = {moneda.codigo: moneda for moneda in TODAS}

# La moneda en la que se enseñan los totales, decidida con el usuario. Vive aquí
# como punto de partida; el ajuste guardado en la base de datos manda sobre esto.
PRINCIPAL_POR_OMISION = EUR


def por_codigo(codigo: str) -> Moneda:
    """Busca una moneda por su código ISO. Falla si no la conoce.

    Falla a propósito en vez de devolver algo por omisión: si en la base de
    datos hubiera un movimiento en una moneda que el programa ya no conoce,
    enseñarlo como si fueran euros falsearía el importe.
    """
    if not isinstance(codigo, str):
        raise MonedaDesconocida(f"código de moneda no textual: {codigo!r}")
    moneda = CATALOGO.get(codigo.strip().upper())
    if moneda is None:
        # NO SE LISTAN LAS 63. Cuando el catálogo eran dos monedas, decirlas
        # enteras ayudaba; ahora sería un muro de texto en el que no se
        # encuentra nada. Se dice cuántas hay y dónde están, que es lo que
        # necesita quien lea esto para arreglarlo.
        raise MonedaDesconocida(
            f"moneda desconocida: {codigo!r}. Focus10 conoce {len(CATALOGO)} "
            "monedas por su código ISO de tres letras (EUR, USD, GBP...). "
            "Para añadir una, edita dominio/moneda.py."
        )
    return moneda
