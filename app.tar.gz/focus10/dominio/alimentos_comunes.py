"""La lista de cosas normales que se comen, con sus valores por 100 gramos.

DE DÓNDE SALEN LOS NÚMEROS: son valores de tabla habituales (del estilo de las
tablas de composición de alimentos), redondeados. Lo cocinado va COCINADO: el
arroz y los fideos, hervidos, porque así se pesan en el plato. Nadie pesa el
arroz crudo después de comérselo.

POR QUÉ HAY UN TEST QUE REVISA ESTA LISTA: cada fila tiene que cuadrar consigo
misma, es decir, que las calorías se parezcan a 4 por gramo de proteína y de
hidrato y 9 por gramo de grasa. Un dedo que escribe 1550 en vez de 155 en los
huevos lo pilla ese test, no el usuario comiéndose un número falso. De ahí vino
esta aplicación: de otra que dio 29 kcal a 300 gramos de fideos.

CADA FILA: (nombres, kcal, proteínas, hidratos, grasas, gramos de uno, porción)

  - nombres: separados por "|". El primero es el que se enseña.
  - gramos de uno: lo que pesa "un huevo", "una banana", "una pizza".
  - porción: lo que pesa "una porción" si no es lo mismo que uno (la pizza).
    Si no se pone, es igual a uno.
"""

from __future__ import annotations

FILAS: tuple[tuple, ...] = (
    # --- huevos y lácteos
    ("huevo", 155, 12.6, 1.1, 10.6, 50),
    ("clara|clara de huevo", 52, 10.9, 0.7, 0.2, 33),
    ("leche|leche entera", 61, 3.2, 4.8, 3.3, 250),
    ("leche descremada", 35, 3.4, 5.0, 0.1, 250),
    ("yogur|yogurt", 61, 3.5, 4.7, 3.3, 190),
    ("yogur griego|yogurt griego", 97, 9.0, 4.0, 5.0, 170),
    ("queso", 350, 25.0, 1.5, 27.0, 30),
    ("queso cremoso", 300, 20.0, 2.0, 24.0, 30),
    ("queso rallado|parmesano", 420, 35.0, 3.0, 29.0, 10),
    ("queso crema", 342, 6.0, 4.0, 34.0, 30),
    ("ricota", 174, 11.3, 3.0, 13.0, 50),
    ("manteca|mantequilla", 717, 0.9, 0.1, 81.0, 10),
    ("crema|nata", 340, 2.0, 3.0, 36.0, 15),
    ("dulce de leche", 315, 7.0, 55.0, 7.5, 20),
    # --- pan y cereales
    ("pan|pan blanco|pan frances", 265, 9.0, 49.0, 3.2, 60),
    ("pan integral", 247, 13.0, 41.0, 3.4, 40),
    ("tostada", 290, 9.0, 54.0, 4.0, 25),
    ("pan lactal|pan de molde|rebanada de pan", 265, 8.0, 49.0, 3.5, 25),
    ("medialuna|croissant", 406, 8.0, 45.0, 21.0, 40),
    ("factura", 400, 6.0, 50.0, 20.0, 50),
    ("galletita|galleta", 450, 7.0, 70.0, 15.0, 8),
    ("avena", 389, 17.0, 66.0, 7.0, 40),
    ("granola", 471, 10.0, 64.0, 20.0, 40),
    ("cereal|copos de maiz", 357, 8.0, 84.0, 0.4, 30),
    ("arroz", 130, 2.7, 28.0, 0.3, 180),
    ("arroz integral", 112, 2.6, 23.0, 0.9, 180),
    ("fideos|pasta|spaghetti|tallarines", 158, 5.8, 31.0, 0.9, 200),
    ("noquis", 150, 3.5, 32.0, 0.6, 250),
    ("ravioles", 175, 8.0, 25.0, 5.0, 250),
    ("polenta", 70, 1.6, 15.0, 0.3, 200),
    ("quinoa", 120, 4.4, 21.0, 1.9, 180),
    ("cuscus", 112, 3.8, 23.0, 0.2, 180),
    ("tortilla de trigo|wrap", 310, 8.0, 52.0, 8.0, 40),
    ("pizza", 266, 11.0, 33.0, 10.0, 800, 110),
    ("empanada", 290, 10.0, 30.0, 14.0, 80),
    ("tarta|pascualina|quiche", 260, 8.0, 22.0, 15.0, 150),
    ("sandwich de jamon y queso|sandwich con jamon y queso|tostado|sandwich",
     260, 13.0, 28.0, 11.0, 130),
    ("hamburguesa", 254, 17.0, 0.0, 20.0, 100),
    ("pan de hamburguesa", 270, 9.0, 50.0, 4.0, 60),
    ("salchicha", 290, 11.0, 2.0, 26.0, 50),
    ("pancho|hot dog", 280, 10.0, 25.0, 15.0, 100),
    ("choclo|maiz", 96, 3.4, 21.0, 1.5, 150),
    # --- carnes y pescados (cocinados)
    ("milanesa|milanesa de carne", 260, 20.0, 12.0, 14.0, 150),
    ("milanesa de pollo", 230, 22.0, 11.0, 11.0, 150),
    ("pollo|pechuga|pechuga de pollo", 165, 31.0, 0.0, 3.6, 150),
    ("pollo al horno", 190, 27.0, 0.0, 9.0, 200),
    ("muslo de pollo|pata muslo", 210, 26.0, 0.0, 11.0, 150),
    ("carne|carne vacuna|bife|churrasco", 250, 26.0, 0.0, 16.0, 200),
    ("carne picada", 270, 25.0, 0.0, 18.0, 100),
    ("asado|costilla", 330, 24.0, 0.0, 26.0, 250),
    ("vacio", 300, 24.0, 0.0, 23.0, 250),
    ("lomo", 180, 28.0, 0.0, 7.0, 200),
    ("cerdo|bondiola|carre", 240, 27.0, 0.0, 14.0, 200),
    ("chorizo", 330, 17.0, 2.0, 28.0, 100),
    ("morcilla", 380, 15.0, 1.0, 35.0, 100),
    ("jamon|jamon cocido", 145, 18.0, 1.5, 7.0, 20),
    ("jamon crudo", 250, 26.0, 0.0, 16.0, 15),
    ("salame", 425, 22.0, 2.0, 37.0, 10),
    ("atun|atun al natural", 116, 26.0, 0.0, 1.0, 120),
    ("atun en aceite", 198, 29.0, 0.0, 8.0, 120),
    ("salmon", 208, 20.0, 0.0, 13.0, 150),
    ("merluza|pescado", 90, 18.0, 0.0, 1.5, 150),
    ("camarones|langostinos", 99, 24.0, 0.2, 0.3, 100),
    ("sardinas", 208, 25.0, 0.0, 11.0, 90),
    # --- legumbres
    ("lentejas", 116, 9.0, 20.0, 0.4, 200),
    ("garbanzos", 164, 8.9, 27.0, 2.6, 200),
    ("porotos|frijoles|alubias", 127, 8.7, 23.0, 0.5, 200),
    ("hummus", 166, 8.0, 14.0, 10.0, 30),
    ("tofu", 76, 8.0, 2.0, 4.8, 100),
    # --- verduras
    ("papa|patata", 87, 1.9, 20.0, 0.1, 150),
    ("papas fritas|patatas fritas", 312, 3.4, 41.0, 15.0, 150),
    ("papas al horno", 130, 2.5, 21.0, 4.0, 150),
    ("pure|pure de papa", 110, 2.0, 15.0, 4.5, 200),
    ("batata|boniato", 76, 1.4, 18.0, 0.1, 150),
    ("tomate", 18, 0.9, 3.9, 0.2, 120),
    ("lechuga", 15, 1.4, 2.9, 0.2, 50),
    ("ensalada", 20, 1.2, 3.5, 0.2, 150),
    ("zanahoria", 41, 0.9, 10.0, 0.2, 70),
    ("cebolla", 40, 1.1, 9.3, 0.1, 100),
    ("morron|pimiento", 31, 1.0, 6.0, 0.3, 120),
    ("zapallo|calabaza", 26, 1.0, 6.5, 0.1, 150),
    ("zapallito|calabacin|zucchini", 17, 1.2, 3.1, 0.3, 150),
    ("berenjena", 25, 1.0, 6.0, 0.2, 200),
    ("brocoli", 34, 2.8, 7.0, 0.4, 100),
    ("espinaca", 23, 2.9, 3.6, 0.4, 100),
    ("champinones|hongos", 22, 3.1, 3.3, 0.3, 80),
    ("palta|aguacate", 160, 2.0, 8.5, 14.7, 150),
    ("pepino", 15, 0.7, 3.6, 0.1, 150),
    ("remolacha", 43, 1.6, 10.0, 0.2, 100),
    ("verduras", 30, 1.5, 6.0, 0.2, 150),
    # --- frutas
    ("banana|platano", 89, 1.1, 23.0, 0.3, 120),
    ("manzana", 52, 0.3, 14.0, 0.2, 180),
    ("naranja", 47, 0.9, 12.0, 0.1, 180),
    ("mandarina", 53, 0.8, 13.0, 0.3, 90),
    ("pera", 57, 0.4, 15.0, 0.1, 180),
    ("frutilla|fresa", 32, 0.7, 7.7, 0.3, 12),
    ("uva", 69, 0.7, 18.0, 0.2, 5),
    ("durazno|melocoton", 39, 0.9, 9.5, 0.3, 150),
    ("kiwi", 61, 1.1, 15.0, 0.5, 75),
    ("anana|pina", 50, 0.5, 13.0, 0.1, 150),
    ("sandia", 30, 0.6, 7.6, 0.2, 300),
    ("melon", 34, 0.8, 8.0, 0.2, 300),
    ("mango", 60, 0.8, 15.0, 0.4, 200),
    ("arandanos", 57, 0.7, 14.0, 0.3, 1),
    ("ciruela", 46, 0.7, 11.0, 0.3, 65),
    ("fruta", 55, 0.6, 14.0, 0.2, 150),
    # --- frutos secos
    ("nuez", 654, 15.0, 14.0, 65.0, 5),
    ("almendras", 579, 21.0, 22.0, 50.0, 1),
    ("mani|cacahuate", 567, 26.0, 16.0, 49.0, 1),
    ("mantequilla de mani|pasta de mani", 588, 25.0, 20.0, 50.0, 15),
    ("chia|semillas de chia", 486, 17.0, 42.0, 31.0, 10),
    ("pasas|pasas de uva", 299, 3.0, 79.0, 0.5, 1),
    # --- grasas, salsas y dulce
    ("aceite|aceite de oliva", 884, 0.0, 0.0, 100.0, 13),
    ("mayonesa", 680, 1.0, 0.6, 75.0, 15),
    ("ketchup", 112, 1.0, 26.0, 0.1, 15),
    ("salsa de tomate|tuco", 50, 1.5, 8.0, 1.5, 100),
    ("azucar", 387, 0.0, 100.0, 0.0, 5),
    ("miel", 304, 0.3, 82.0, 0.0, 20),
    ("mermelada", 250, 0.4, 63.0, 0.1, 20),
    ("chocolate", 546, 5.0, 60.0, 31.0, 10),
    ("nutella", 539, 6.0, 58.0, 31.0, 15),
    ("alfajor", 420, 5.0, 62.0, 17.0, 50),
    ("helado", 207, 3.5, 24.0, 11.0, 100),
    ("torta|bizcochuelo", 350, 5.0, 50.0, 15.0, 100),
    ("flan", 130, 4.0, 20.0, 3.5, 120),
    ("barrita de cereal|barra de cereal", 400, 6.0, 70.0, 10.0, 25),
    ("brownie", 466, 6.0, 50.0, 29.0, 60),
    # --- bebidas (por 100 ml; se cuentan como gramos)
    ("cafe", 2, 0.1, 0.0, 0.0, 200),
    ("cafe con leche", 30, 1.6, 2.4, 1.6, 250),
    ("te", 1, 0.0, 0.2, 0.0, 250),
    ("mate", 2, 0.1, 0.3, 0.0, 500),
    ("gaseosa|coca|coca cola", 42, 0.0, 10.6, 0.0, 350),
    ("jugo|jugo de naranja", 45, 0.7, 10.0, 0.2, 250),
    ("cerveza", 43, 0.5, 3.6, 0.0, 330),
    ("vino", 83, 0.1, 2.6, 0.0, 150),
    ("agua", 0, 0.0, 0.0, 0.0, 250),
    ("chocolatada|leche chocolatada", 83, 3.2, 12.0, 2.3, 250),
    ("licuado", 75, 2.5, 12.0, 2.0, 300),
    ("proteina|whey|batido de proteina|proteina en polvo|batido proteico", 380, 78.0, 8.0, 5.0, 30),
    # --- platos
    ("tortilla de papa|tortilla espanola", 180, 6.0, 15.0, 11.0, 150),
    ("guiso|estofado", 110, 7.0, 10.0, 4.5, 300),
    ("sopa", 40, 2.0, 6.0, 1.0, 300),
    ("lasana|lasagna", 160, 9.0, 14.0, 7.5, 300),
    ("canelones", 150, 8.0, 14.0, 7.0, 250),
    ("sushi|roll", 150, 6.0, 25.0, 3.0, 30),
    ("choripan", 300, 12.0, 25.0, 17.0, 200),
    ("lomito", 230, 15.0, 20.0, 10.0, 300),
    ("arroz con pollo", 150, 10.0, 18.0, 4.0, 300),
    ("fideos con tuco", 130, 4.5, 24.0, 2.0, 300),
    ("sandwich de milanesa|milanesa al pan", 250, 14.0, 22.0, 11.0, 300),
)

ALCOHOL = frozenset({"cerveza", "vino"})
"""Las que no cuadran con 4-4-9 y está bien que no: el alcohol aporta 7 kcal por
gramo y no es ni proteína, ni hidrato, ni grasa. El test las deja pasar."""
