"""El agua del día: cada trago, uno a uno.

POR QUÉ CADA TRAGO ES UNA FILA Y NO UN TOTAL QUE SE VA SUMANDO. Lo pidió el
usuario y es la decisión que hace que todo lo demás funcione:

  - DESHACER ES EXACTO. Se borra la última fila, sea de 250 o de 33 ml. Con un
    total acumulado habría que restar "lo último", que nadie recuerda, o una
    cantidad fija, que sería mentira.
  - EL TOTAL NO PUEDE QUEDARSE EN NEGATIVO. No se resta nunca: se quita una fila
    y se vuelve a sumar lo que queda. Pulsar deshacer de más simplemente deja la
    lista vacía.
  - EL HISTORIAL NO MIENTE. Se puede ver a qué hora bebiste, no solo cuánto.

LO QUE SE ESCRIBE SE SUMA, NO SUSTITUYE. Escribir 250 cuando llevas 500 te deja
en 750. Es lo natural cuando acabas de beberte un vaso, y lo contrario —que el
número escrito pase a ser el total— haría que apuntar un vaso pequeño borrara la
mañana entera.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import date, datetime

ML_MAXIMOS_POR_TRAGO = 5_000
"""Cinco litros de un trago. No es una recomendación: es un tope para que un
dedo torpe no meta 25000 y descuadre el vaso del día entero."""

ML_MAXIMOS_OBJETIVO = 20_000

_NUMERO = re.compile(r"^\d{1,5}$")


@dataclass(frozen=True)
class Trago:
    """Un trago de agua. Ni se edita ni se parte: se apunta o se borra."""

    ml: int
    jornada: date
    momento: datetime
    id: int | None = None

    def __post_init__(self) -> None:
        if isinstance(self.ml, bool) or not isinstance(self.ml, int):
            raise TypeError("los mililitros tienen que ser un entero")
        if self.ml == 0:
            # Cero no es un trago ni es quitar nada: es no haber hecho nada.
            # Guardarlo ensuciaría el historial con filas que no dicen nada y
            # haría que deshacer pareciera no funcionar.
            raise ValueError("un trago no puede ser de cero mililitros")
        if abs(self.ml) > ML_MAXIMOS_POR_TRAGO:
            # UN NEGATIVO ES QUITAR AGUA, y lo pidió el usuario: "agregar un
            # apartado para sacar, tipo sacar mililitros". El tope vale igual
            # para los dos lados: quitar diez litros de golpe es un error de
            # tecleo, no una intención.
            raise ValueError(
                f"un trago no puede pasar de {ML_MAXIMOS_POR_TRAGO} ml"
            )

        if not isinstance(self.jornada, date) or isinstance(self.jornada, datetime):
            raise TypeError("la jornada tiene que ser un date, no un datetime")
        if not isinstance(self.momento, datetime):
            raise TypeError("el momento tiene que ser un datetime")

        if self.id is not None:
            if isinstance(self.id, bool) or not isinstance(self.id, int):
                raise TypeError("el id tiene que ser int o None")
            if self.id <= 0:
                raise ValueError("id tiene que ser mayor que cero")


@dataclass(frozen=True)
class Vaso:
    """Cómo va el día. Es lo que dibuja el vaso de la pantalla."""

    bebido: int
    objetivo: int | None

    @property
    def fraccion(self) -> float:
        """De 0 a 1: hasta dónde llega el agua en el dibujo.

        Sin objetivo devuelve 0: el vaso se queda vacío y al lado se enseña
        cuánto llevas en números. No se inventa un objetivo para poder dibujar
        algo bonito.
        """
        if not self.objetivo:
            return 0.0
        return min(1.0, self.bebido / self.objetivo)

    @property
    def cumplido(self) -> bool:
        return self.objetivo is not None and self.bebido >= self.objetivo

    @property
    def falta(self) -> int | None:
        if self.objetivo is None:
            return None
        return max(0, self.objetivo - self.bebido)

    def texto(self) -> str:
        """"1,2 L de 2 L", o "1,2 L" si no hay objetivo."""
        if self.objetivo is None:
            return texto_litros(self.bebido)
        return f"{texto_litros(self.bebido)} de {texto_litros(self.objetivo)}"


def total(tragos: Iterable[Trago]) -> int:
    """Lo bebido. Se suma lo que hay; nunca se resta de un acumulado."""
    suma = 0
    for trago in tragos:
        if not isinstance(trago, Trago):
            raise TypeError(f"esto no es un Trago: {trago!r}")
        suma += trago.ml
    return suma


def ultimo(tragos: Iterable[Trago]) -> Trago | None:
    """El trago más reciente, que es el que borra deshacer.

    Se decide por el momento y, a igualdad, por el id: dos tragos apuntados en el
    mismo segundo son posibles —pulsar dos veces seguidas— y sin el id, cuál se
    borra dependería del orden en que llegaran las filas.
    """
    candidatos = list(tragos)
    if not candidatos:
        return None
    return max(candidatos, key=lambda uno: (uno.momento, uno.id or 0))


def parsear_ml(texto: str, *, tope: int = ML_MAXIMOS_POR_TRAGO) -> int:
    """Los mililitros escritos. Solo un número entero, sin adornos."""
    if not isinstance(texto, str):
        raise TypeError("los mililitros tienen que venir como texto")
    limpio = texto.strip().replace(" ", "").replace("ml", "")
    if not limpio:
        raise ValueError("escribe cuántos mililitros, por ejemplo 250")
    if not _NUMERO.match(limpio):
        raise ValueError(f"no entiendo «{texto.strip()}». Escribe un número, como 250")
    valor = int(limpio)
    if valor <= 0:
        raise ValueError("tiene que ser más de cero")
    if valor > tope:
        raise ValueError(f"como mucho {tope} ml")
    return valor


def texto_litros(ml: int) -> str:
    """"350 ml" hasta el litro, y "1,2 L" a partir de ahí.

    Cambia de unidad porque "1750 ml" cuesta de leer de un vistazo y "1,75 L" no.
    """
    if not isinstance(ml, int) or isinstance(ml, bool):
        raise TypeError("los mililitros tienen que ser un entero")
    if ml < 1000:
        return f"{ml} ml"
    litros, resto = divmod(ml, 1000)
    decimas = resto // 100
    return f"{litros},{decimas} L" if decimas else f"{litros} L"
