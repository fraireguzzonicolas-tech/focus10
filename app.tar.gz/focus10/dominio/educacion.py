"""Educación: materias, temas, metas y lo que pasa en el calendario.

LA CADENA QUE PIDIÓ EL USUARIO, y de la que sale toda la forma de esto:

    MATERIA -> TEMAS -> METAS -> PLANIFICACIÓN -> SESIÓN -> RESULTADO -> PROGRESO

DE DÓNDE SALE EL PROGRESO, que es la decisión que más se piensa y la que más
fácil es equivocar: de un DOMINIO que pone el usuario en cada tema, de 25 en 25
(nada, flojo, bien, dominado). NO de las horas estudiadas. Lo eligió él y tiene
razón: pasar tres horas mirando una hoja no es entenderla, y una aplicación que
diga que sí está mintiendo con un número que parece objetivo.

DE 25 EN 25 Y NO DE 1 EN 1 por lo mismo que los objetivos libres van de diez en
diez: nadie sabe si domina las derivadas al 62 % o al 63 %, y pedir esa
precisión solo sirve para dudar. Cuatro escalones se eligen sin pensar.

UNA SESIÓN PLANIFICADA Y UNA SESIÓN HECHA SON LA MISMA COSA en dos momentos.
Por eso aquí solo hay `Evento`: lo que lo convierte en "hecho" es tener
`hecho_en`, no cambiar de tipo ni mudarse a otra lista.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from enum import StrEnum

from .validar import exigir_entero, exigir_texto

LARGO_NOMBRE = 60
LARGO_TEXTO = 500
LARGO_TITULO = 80

PASO_DE_DOMINIO = 25
"""Los cuatro escalones: 0, 25, 50, 75 y 100."""

MINUTOS_MAXIMOS = 1440
"""Un día entero. Tope de cordura para un dedo torpe, no de ambición."""

DIAS_DE_LA_SEMANA_QUE_VIENE = 7
"""Cuánto mira hacia delante el Dashboard: lo de esta semana y lo de ya."""


PALABRAS_DE_DOMINIO = {
    0: "Sin empezar",
    25: "Flojo",
    50: "A medias",
    75: "Bien",
    100: "Dominado",
}
"""Los cinco escalones en palabras. UN NÚMERO SOLO NO SE ELIGE: "¿75 o 50?" se
piensa; "¿bien o a medias?" se contesta."""


def palabra_de_dominio(dominio: int) -> str:
    exigir_entero("dominio", dominio)
    return PALABRAS_DE_DOMINIO.get(dominio, "")


class EstadoTema(StrEnum):
    PENDIENTE = "pendiente"
    EN_PROGRESO = "en_progreso"
    COMPLETADO = "completado"


class Prioridad(StrEnum):
    ALTA = "alta"
    MEDIA = "media"
    BAJA = "baja"


class TipoEvento(StrEnum):
    SESION = "sesion"
    TAREA = "tarea"
    EXAMEN = "examen"
    TRABAJO = "trabajo"
    IMPORTANTE = "importante"
    OTRO = "otro"


class Dificultad(StrEnum):
    """Cómo te fue. Lo pidió el usuario con esas tres palabras."""

    FACIL = "facil"
    NORMAL = "normal"
    DIFICIL = "dificil"


def estado_de(dominio: int) -> EstadoTema:
    """El estado de un tema SALE DE SU DOMINIO, no se guarda aparte.

    Guardar las dos cosas permitiría un tema "completado" con dominio 0, y
    entonces ninguna de las dos significaría nada.
    """
    exigir_entero("dominio", dominio)
    if dominio >= 100:
        return EstadoTema.COMPLETADO
    if dominio > 0:
        return EstadoTema.EN_PROGRESO
    return EstadoTema.PENDIENTE


def siguiente_dominio(actual: int, hacia_arriba: bool) -> int:
    """Un escalón arriba o abajo, sin salirse de 0 a 100."""
    exigir_entero("actual", actual)
    paso = PASO_DE_DOMINIO if hacia_arriba else -PASO_DE_DOMINIO
    return min(100, max(0, actual + paso))


@dataclass(frozen=True)
class Materia:
    nombre: str
    color: str
    orden: int = 0
    id: int | None = None

    def __post_init__(self) -> None:
        exigir_texto("nombre", self.nombre, LARGO_NOMBRE, obligatorio=True)
        object.__setattr__(self, "nombre", self.nombre.strip())
        exigir_texto("color", self.color, 20, obligatorio=True)
        exigir_entero("orden", self.orden)
        if self.orden < 0:
            raise ValueError("orden no puede ser negativo")
        _exigir_id(self.id)


@dataclass(frozen=True)
class Tema:
    materia_id: int
    nombre: str
    descripcion: str = ""
    dominio: int = 0
    notas: str = ""
    creado_en: date | None = None
    id: int | None = None

    def __post_init__(self) -> None:
        exigir_entero("materia_id", self.materia_id)
        if self.materia_id <= 0:
            raise ValueError("materia_id tiene que ser mayor que cero")
        exigir_texto("nombre", self.nombre, LARGO_NOMBRE, obligatorio=True)
        exigir_texto("descripcion", self.descripcion, LARGO_TEXTO)
        exigir_texto("notas", self.notas, LARGO_TEXTO)
        for campo in ("nombre", "descripcion", "notas"):
            object.__setattr__(self, campo, getattr(self, campo).strip())

        exigir_entero("dominio", self.dominio)
        if not 0 <= self.dominio <= 100:
            raise ValueError("el dominio va de 0 a 100")
        if self.dominio % PASO_DE_DOMINIO:
            raise ValueError(
                f"el dominio va de {PASO_DE_DOMINIO} en {PASO_DE_DOMINIO}"
            )
        _exigir_dia("creado_en", self.creado_en)
        _exigir_id(self.id)

    @property
    def estado(self) -> EstadoTema:
        return estado_de(self.dominio)


@dataclass(frozen=True)
class Meta:
    """Un objetivo de estudio: "aprobar Matemáticas", "llegar a B2".

    NO ES UN OBJETIVO DE LOS DE LA SECCIÓN OBJETIVOS, y lo decidió el usuario:
    aquellos son de dinero o libres, y estos cuelgan de una materia y de unos
    temas. Mezclarlos habría complicado una pantalla que ya funciona.
    """

    nombre: str
    descripcion: str = ""
    materia_id: int | None = None
    fecha_limite: date | None = None
    prioridad: Prioridad = Prioridad.MEDIA
    cumplida_en: date | None = None
    orden: int = 0
    id: int | None = None

    def __post_init__(self) -> None:
        exigir_texto("nombre", self.nombre, LARGO_NOMBRE, obligatorio=True)
        exigir_texto("descripcion", self.descripcion, LARGO_TEXTO)
        for campo in ("nombre", "descripcion"):
            object.__setattr__(self, campo, getattr(self, campo).strip())
        if self.materia_id is not None:
            exigir_entero("materia_id", self.materia_id)
            if self.materia_id <= 0:
                raise ValueError("materia_id tiene que ser mayor que cero")
        if not isinstance(self.prioridad, Prioridad):
            raise TypeError("la prioridad tiene que ser una Prioridad")
        _exigir_dia("fecha_limite", self.fecha_limite)
        _exigir_dia("cumplida_en", self.cumplida_en)
        exigir_entero("orden", self.orden)
        if self.orden < 0:
            raise ValueError("orden no puede ser negativo")
        _exigir_id(self.id)

    @property
    def cumplida(self) -> bool:
        return self.cumplida_en is not None

    def dias_hasta(self, hoy: date) -> int | None:
        if self.fecha_limite is None:
            return None
        return (self.fecha_limite - hoy).days


@dataclass(frozen=True)
class Evento:
    """Todo lo que va al calendario de Educación, incluidas las sesiones."""

    tipo: TipoEvento
    fecha: date
    titulo: str = ""
    hora: str = ""
    """"18:00", o vacío si da igual la hora."""

    minutos: int | None = None
    """Lo que piensas dedicarle. None si no lo decidiste."""

    materia_id: int | None = None
    tema_id: int | None = None
    notas: str = ""
    prioridad: Prioridad = Prioridad.MEDIA
    hecho_en: date | None = None
    minutos_reales: int | None = None
    dificultad: Dificultad | None = None
    id: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.tipo, TipoEvento):
            raise TypeError("el tipo tiene que ser un TipoEvento")
        if not isinstance(self.prioridad, Prioridad):
            raise TypeError("la prioridad tiene que ser una Prioridad")
        if not isinstance(self.fecha, date) or isinstance(self.fecha, datetime):
            raise TypeError("la fecha tiene que ser un date, no un datetime")

        exigir_texto("titulo", self.titulo, LARGO_TITULO)
        exigir_texto("notas", self.notas, LARGO_TEXTO)
        for campo in ("titulo", "notas", "hora"):
            object.__setattr__(self, campo, getattr(self, campo).strip())
        if self.hora:
            _exigir_hora(self.hora)

        for campo in ("materia_id", "tema_id"):
            valor = getattr(self, campo)
            if valor is None:
                continue
            exigir_entero(campo, valor)
            if valor <= 0:
                raise ValueError(f"{campo} tiene que ser mayor que cero")

        for campo in ("minutos", "minutos_reales"):
            valor = getattr(self, campo)
            if valor is None:
                continue
            exigir_entero(campo, valor)
            if not 0 < valor <= MINUTOS_MAXIMOS:
                raise ValueError(f"{campo} va de 1 a {MINUTOS_MAXIMOS}")

        _exigir_dia("hecho_en", self.hecho_en)
        if self.dificultad is not None and not isinstance(self.dificultad, Dificultad):
            raise TypeError("la dificultad tiene que ser una Dificultad")

        # UNA SESIÓN SIN MATERIA NI TÍTULO NO DICE NADA: "estudié 45 minutos"
        # no se puede sumar a ninguna materia ni contar en ningún progreso.
        #
        # SE ADMITE EL TÍTULO A SECAS porque una sesión de hace meses sobrevive
        # a que borres la materia: el repositorio le deja escrito el nombre
        # antes de borrarla. Exigir la materia habría obligado a elegir entre
        # tirar tu historial o dejar filas que no se pueden ni leer.
        if self.tipo is TipoEvento.SESION and self.materia_id is None:
            if not self.titulo:
                raise ValueError("una sesión de estudio necesita su materia")
        # LO QUE NO ES UNA SESIÓN NECESITA TÍTULO: "examen" a secas, dentro de
        # una lista de cinco cosas del mismo día, no se distingue de nada.
        if self.tipo is not TipoEvento.SESION and not self.titulo:
            raise ValueError("hace falta un título")
        if self.minutos_reales is not None and self.hecho_en is None:
            raise ValueError("los minutos reales son de algo ya hecho")
        if self.dificultad is not None and self.hecho_en is None:
            raise ValueError("cómo te fue es de algo ya hecho")
        _exigir_id(self.id)

    @property
    def hecho(self) -> bool:
        return self.hecho_en is not None

    @property
    def minutos_contados(self) -> int:
        """Los minutos que cuentan para el progreso: los reales si los hay.

        SI NO PUSISTE LOS REALES, VALEN LOS PLANEADOS, y si tampoco hay, cero.
        Cero y no "una media": una sesión sin minutos es una sesión de la que no
        sabemos cuánto duró, y eso no se rellena solo.
        """
        if not self.hecho:
            return 0
        return self.minutos_reales or self.minutos or 0


# ---------------------------------------------------------------------------
# Progreso: todo calculado, nada guardado
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ProgresoMateria:
    materia: Materia
    temas: int
    completados: int
    dominio_medio: int
    """De 0 a 100. El promedio del dominio de sus temas."""

    minutos: int
    """Lo estudiado en el tramo que se esté mirando."""

    @property
    def fraccion(self) -> float:
        return self.dominio_medio / 100


def progreso_de(
    materia: Materia, temas: Iterable[Tema], eventos: Iterable[Evento] = ()
) -> ProgresoMateria:
    """Cómo va una materia: el promedio del dominio de sus temas.

    SIN TEMAS, CERO Y NO "SIN DATOS": una materia recién creada está al 0 %, que
    es la verdad. Inventar un 100 % porque no hay nada que contar sería el fallo
    clásico de dividir por el total sin mirar si el total es cero.
    """
    suyos = [uno for uno in temas if uno.materia_id == materia.id]
    dominio = round(sum(uno.dominio for uno in suyos) / len(suyos)) if suyos else 0
    minutos = sum(
        uno.minutos_contados
        for uno in eventos
        if uno.materia_id == materia.id and uno.hecho
    )
    return ProgresoMateria(
        materia=materia,
        temas=len(suyos),
        completados=sum(1 for uno in suyos if uno.estado is EstadoTema.COMPLETADO),
        dominio_medio=dominio,
        minutos=minutos,
    )


def progreso_de_meta(meta: Meta, temas: Iterable[Tema]) -> int:
    """Lo que lleva una meta, de 0 a 100: el promedio de sus temas.

    UNA META SIN TEMAS NO ESTÁ AL 0 % PARA SIEMPRE: si la marcaste cumplida, va
    al 100. Es lo único que puede decirse de "terminar el curso" cuando no se
    ha partido en temas.
    """
    suyos = list(temas)
    if meta.cumplida:
        return 100
    if not suyos:
        return 0
    return round(sum(uno.dominio for uno in suyos) / len(suyos))


def minutos_estudiados(eventos: Iterable[Evento]) -> int:
    return sum(uno.minutos_contados for uno in eventos if uno.hecho)


def texto_de_minutos(minutos: int) -> str:
    """90 -> "1h 30min". Cero -> "0min", que también es un dato."""
    exigir_entero("minutos", minutos)
    horas, resto = divmod(max(0, minutos), 60)
    if horas and resto:
        return f"{horas}h {resto}min"
    if horas:
        return f"{horas}h"
    return f"{resto}min"


# ---------------------------------------------------------------------------
# Qué toca ahora: lo que el Dashboard y la pantalla preguntan
# ---------------------------------------------------------------------------


def lo_de_hoy(eventos: Iterable[Evento], hoy: date) -> list[Evento]:
    """Lo de hoy sin hacer, y lo de días pasados que quedó pendiente.

    LO ATRASADO SE ARRASTRA A PROPÓSITO: una tarea del martes que no hiciste
    sigue siendo tuya el miércoles, y desaparecer del día siguiente es
    exactamente cómo se olvidan las cosas.
    """
    pendientes = [uno for uno in eventos if not uno.hecho and uno.fecha <= hoy]
    return ordenar(pendientes)


def de_la_semana(
    eventos: Iterable[Evento], hoy: date, dias: int = DIAS_DE_LA_SEMANA_QUE_VIENE
) -> list[Evento]:
    """Lo que viene en los próximos días, sin contar hoy ni lo ya hecho."""
    hasta = hoy + timedelta(days=dias)
    return ordenar(
        [uno for uno in eventos if not uno.hecho and hoy < uno.fecha <= hasta]
    )


PESO_DE_TIPO = {
    TipoEvento.EXAMEN: 0,
    TipoEvento.TRABAJO: 1,
    TipoEvento.TAREA: 2,
    TipoEvento.IMPORTANTE: 3,
    TipoEvento.SESION: 4,
    TipoEvento.OTRO: 5,
}
"""Con qué se empieza cuando dos cosas caen el mismo día y con la misma prisa.

UN EXAMEN MANDA SOBRE UNA SESIÓN DE ESTUDIO: la sesión se puede mover, el
examen no.
"""

PESO_DE_PRIORIDAD = {Prioridad.ALTA: 0, Prioridad.MEDIA: 1, Prioridad.BAJA: 2}


def ordenar(eventos: Iterable[Evento]) -> list[Evento]:
    """Por fecha, luego prioridad, luego tipo, y a igualdad por hora."""
    return sorted(
        eventos,
        key=lambda uno: (
            uno.fecha,
            PESO_DE_PRIORIDAD[uno.prioridad],
            PESO_DE_TIPO[uno.tipo],
            uno.hora or "99:99",
            uno.titulo.lower(),
        ),
    )


def repetir(fecha: date, veces: int, cada_dias: int = 7) -> list[date]:
    """Las fechas de algo que se repite: hoy, y las siguientes.

    SE CREAN FILAS DE VERDAD, UNA POR DÍA, en vez de guardar "se repite los
    lunes": así puedes mover o borrar la del jueves que viene sin tocar las
    demás, que es lo que pasa en la vida real con las clases.
    """
    exigir_entero("veces", veces)
    exigir_entero("cada_dias", cada_dias)
    if veces < 1:
        raise ValueError("repetir menos de una vez no es repetir")
    if not 1 <= cada_dias <= 365:
        raise ValueError("cada cuántos días va de 1 a 365")
    return [fecha + timedelta(days=cada_dias * numero) for numero in range(veces)]


# ---------------------------------------------------------------------------


def _exigir_id(valor) -> None:
    if valor is None:
        return
    exigir_entero("id", valor)
    if valor <= 0:
        raise ValueError("id tiene que ser mayor que cero")


def _exigir_dia(nombre: str, valor) -> None:
    if valor is None:
        return
    if not isinstance(valor, date) or isinstance(valor, datetime):
        raise TypeError(f"{nombre} tiene que ser un date, no un datetime")


def _exigir_hora(texto: str) -> None:
    """"18:00". Se valida aquí y no solo en la base: el error tiene que salir
    al escribirlo, no al guardar."""
    partes = texto.split(":")
    if len(partes) != 2 or not all(p.isdigit() and len(p) == 2 for p in partes):
        raise ValueError(f"no entiendo la hora «{texto}»: se escribe 18:00")
    horas, minutos = int(partes[0]), int(partes[1])
    if horas > 23 or minutos > 59:
        raise ValueError(f"esa hora no existe: «{texto}»")
