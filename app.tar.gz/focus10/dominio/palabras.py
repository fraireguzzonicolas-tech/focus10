"""Comparar nombres de comida como los compara una persona.

POR QUÉ HACE FALTA: la búsqueda vieja era literal. "mila" encontraba
"Milanesa", pero "milanesas" no encontraba "Milanesa", y "pure" no encontraba
"Puré". Una persona no escribe igual dos veces, y si la aplicación no la
reconoce, tampoco puede ofrecerle lo que ya apuntó.

TRES COSAS SE IGNORAN: mayúsculas, acentos y plurales. Nada más. No se buscan
sinónimos ni se adivina: "pollo" no encuentra "pechuga", porque eso ya es decidir
qué quisiste decir.
"""

from __future__ import annotations

import re
import unicodedata

_PALABRA = re.compile(r"[a-z0-9]+(?:[.,/][0-9]+)?")


def normalizar(texto: str) -> str:
    """Minúsculas y sin acentos: "Puré" -> "pure".

    LA Ñ TAMBIÉN PIERDE SU RABITO ("puñado" -> "punado"). No confunde nada en
    comidas y así da igual si el teclado del móvil la puso o no.
    """
    sin_marcas = unicodedata.normalize("NFD", texto or "")
    sin_marcas = "".join(c for c in sin_marcas if unicodedata.category(c) != "Mn")
    return sin_marcas.lower()


def palabras(texto: str) -> list[str]:
    """Las palabras de un texto ya normalizado, con "200g" partido en "200 g".

    SE PARTE EL NÚMERO PEGADO porque en el móvil casi nadie pone el espacio, y
    "200g" tiene que entenderse igual que "200 g".
    """
    separado = re.sub(r"(\d)([a-z])", r"\1 \2", normalizar(texto))
    return _PALABRA.findall(separado)


def singular(palabra: str) -> str:
    """Una forma común para singular y plural: "panes" y "pan" dan lo mismo.

    NO ES GRAMÁTICA DE VERDAD y no tiene que serlo: lo único que importa es que
    las dos formas de una misma palabra acaben igual, porque se aplica a los dos
    lados de cada comparación. "nueces" -> "nuez", "limones" -> "limon",
    "tostadas" -> "tostada".
    """
    if len(palabra) > 4 and palabra.endswith("ces"):
        return palabra[:-3] + "z"
    if len(palabra) > 4 and palabra.endswith("es") and palabra[-3] in "lnrdj":
        return palabra[:-2]
    if len(palabra) > 3 and palabra.endswith("s"):
        return palabra[:-1]
    return palabra


def encaja(escrito: str, nombre: str) -> bool:
    """Si lo que se está escribiendo puede ser ese nombre.

    CADA PALABRA ESCRITA TIENE QUE ESTAR, entera o empezada, en alguna palabra
    del nombre: "mila pure" encaja con "2 milanesas con puré"; "mila pollo" no.
    Con que bastara una, escribir más afinaría menos, que es al revés de lo que
    uno espera.
    """
    buscadas = palabras(escrito)
    if not buscadas:
        return False
    del_nombre = palabras(nombre)
    return all(
        any(
            otra.startswith(una) or singular(otra) == singular(una)
            for otra in del_nombre
        )
        for una in buscadas
    )


def mismo_nombre(uno: str, otro: str) -> bool:
    """Si dos nombres son la misma comida escrita de dos maneras."""
    return [singular(p) for p in palabras(uno)] == [singular(p) for p in palabras(otro)]
