"""Los totales del día contra los objetivos.

LO ÚNICO QUE SE HACE CON LOS NÚMEROS DEL USUARIO ES SUMARLOS. Sumar no es
inventar: el resultado es exactamente lo que él escribió, junto. Aquí no hay
estimaciones, ni recomendaciones, ni "te falta proteína".

SIN OBJETIVO NO HAY BARRA, y lo decidió el usuario. Una barra necesita un
contra-qué; sin objetivo, cualquier barra es un porcentaje inventado. Por eso
`fraccion` devuelve None en vez de cero: None significa "no hay contra qué
medir", y cero significaría "vas por el 0 %", que es otra cosa.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass

from .alimento import Registro

NUTRIENTES = ("kcal", "proteinas", "carbohidratos", "grasas")

NOMBRES = {
    "kcal": "Calorías",
    "proteinas": "Proteínas",
    "carbohidratos": "Carbohidratos",
    "grasas": "Grasas",
}


@dataclass(frozen=True)
class Objetivos:
    """Lo que el usuario quiere al día. None es "no me importa este"."""

    kcal: int | None = None
    proteinas: int | None = None
    """En décimas de gramo, igual que los registros."""

    carbohidratos: int | None = None
    grasas: int | None = None

    def __post_init__(self) -> None:
        for campo in NUTRIENTES:
            valor = getattr(self, campo)
            if valor is None:
                continue
            if isinstance(valor, bool) or not isinstance(valor, int):
                raise TypeError(f"el objetivo de {campo} tiene que ser int o None")
            if valor <= 0:
                # Cero no es un objetivo, es no tener objetivo. Se guarda como
                # None para que no haya dos formas de decir lo mismo.
                raise ValueError(
                    f"el objetivo de {campo} tiene que ser mayor que cero, o "
                    "estar vacío si no quieres ponerlo"
                )

    def de(self, nutriente: str) -> int | None:
        _exigir_nutriente(nutriente)
        return getattr(self, nutriente)

    @property
    def hay_alguno(self) -> bool:
        return any(getattr(self, campo) is not None for campo in NUTRIENTES)


@dataclass(frozen=True)
class Avance:
    """Cómo va un nutriente del día."""

    nutriente: str
    total: int
    objetivo: int | None

    @property
    def fraccion(self) -> float | None:
        """De 0 a 1, o None si no hay objetivo con el que comparar.

        Se recorta a 1 para que la barra no se salga, pero `pasado` sigue
        diciendo que te has pasado: el dato no se pierde, solo la barra se para.
        """
        if not self.objetivo:
            return None
        return min(1.0, self.total / self.objetivo)

    @property
    def pasado(self) -> bool:
        return self.objetivo is not None and self.total > self.objetivo

    @property
    def falta(self) -> int | None:
        """Lo que queda para el objetivo. None si no hay objetivo; 0 si se pasó."""
        if self.objetivo is None:
            return None
        return max(0, self.objetivo - self.total)


@dataclass(frozen=True)
class Totales:
    kcal: int = 0
    proteinas: int = 0
    carbohidratos: int = 0
    grasas: int = 0

    def de(self, nutriente: str) -> int:
        _exigir_nutriente(nutriente)
        return getattr(self, nutriente)

    def avance(self, objetivos: Objetivos) -> list[Avance]:
        """Los cuatro nutrientes, siempre en el mismo orden.

        Salen los cuatro aunque no tengan objetivo: el total se enseña igual, sin
        barra. Esconder un nutriente por no tener objetivo sería esconder un dato
        que el usuario escribió.
        """
        return [
            Avance(nutriente=uno, total=self.de(uno), objetivo=objetivos.de(uno))
            for uno in NUTRIENTES
        ]


def sumar(registros: Iterable[Registro]) -> Totales:
    """Suma los registros. Nada más: ni pondera, ni estima, ni corrige."""
    totales = dict.fromkeys(NUTRIENTES, 0)
    for registro in registros:
        if not isinstance(registro, Registro):
            raise TypeError(f"esto no es un Registro: {registro!r}")
        for nutriente in NUTRIENTES:
            totales[nutriente] += getattr(registro, nutriente)
    return Totales(**totales)


def _exigir_nutriente(nutriente: str) -> None:
    if nutriente not in NUTRIENTES:
        raise ValueError(
            f"«{nutriente}» no es un nutriente. Los que hay: {', '.join(NUTRIENTES)}"
        )
