"""La cuadrícula del año: un cuadrito por día, como el calendario de HelloHabit.

QUÉ ES: para un hábito y un año, el estado de cada uno de sus 365 (o 366) días,
más el porcentaje de cumplimiento. La interfaz solo pinta lo que sale de aquí.

POR QUÉ CINCO ESTADOS Y NO UN SÍ/NO: un cuadrito apagado puede significar tres
cosas muy distintas —fallé, no tocaba, o todavía no ha llegado— y meterlas en el
mismo saco haría que el año pareciera peor de lo que fue. El porcentaje solo
cuenta los días que de verdad tocaban y ya pasaron.

EL DÍA EN QUE EMPIEZA A CONTAR: no guardamos la fecha en que se creó un hábito,
así que uno creado en junio arrastraría cinco meses de "fallado" que nunca
existieron. Por eso se pasa `desde`: quien llama decide el primer día que cuenta
(en la app, el primer día con marca, que es el único dato real que hay). Los días
anteriores quedan como ANTES: se ven vacíos y no entran en la cuenta.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date, timedelta
from enum import StrEnum

from .habito import Habito

UN_DIA = timedelta(days=1)
DIAS_DE_LA_SEMANA = 7


class EstadoDia(StrEnum):
    CUMPLIDO = "cumplido"
    """Tocaba y se llegó al objetivo."""

    FALLADO = "fallado"
    """Tocaba, ya pasó, y no se llegó."""

    NO_PROGRAMADO = "no_programado"
    """Ese día no tocaba. No es un fallo."""

    ANTES = "antes"
    """Anterior al primer día que cuenta para este hábito."""

    FUTURO = "futuro"
    """Aún no ha llegado. Ni cumplido ni fallado: todavía nada."""


#: Los estados que entran en el porcentaje. Los otros tres no son días fallados.
CUENTAN = (EstadoDia.CUMPLIDO, EstadoDia.FALLADO)


@dataclass(frozen=True)
class Casilla:
    jornada: date
    estado: EstadoDia
    cantidad: int
    """Lo que se hizo ese día. Sirve para la ayuda emergente del cuadrito."""


@dataclass(frozen=True)
class Anuario:
    """El año entero de un hábito."""

    ano: int
    casillas: tuple[Casilla, ...]
    cumplidos: int
    programados: int
    """Días que tocaban y ya pasaron. Es el divisor del porcentaje."""

    @property
    def porcentaje(self) -> int:
        """De 0 a 100, redondeado. Es lo que se enseña a la derecha del nombre."""
        if not self.programados:
            return 0
        return round(100 * self.cumplidos / self.programados)

    @property
    def hay_algo_que_contar(self) -> bool:
        """False cuando el hábito aún no tenía ningún día que tocara en ese año.

        Se distingue del 0 % a propósito: "0 %" dice que fallaste todo, y "aún no
        hay nada" dice que no había nada que fallar. Enseñar lo primero cuando es
        lo segundo sería mentir.
        """
        return self.programados > 0


def rejilla_del_ano(
    habito: Habito,
    cantidades: Mapping[date, int],
    *,
    ano: int,
    hoy: date,
    desde: date | None = None,
) -> Anuario:
    """El estado de cada día del año para ese hábito.

    `cantidades` es lo hecho cada jornada; los días que no estén valen cero.
    `hoy` se pasa a mano y no se pregunta al reloj para que los tests puedan
    situarse en cualquier fecha, y porque el "hoy" de esta app es la jornada del
    usuario, que puede haber empezado ayer.
    """
    if not isinstance(ano, int) or isinstance(ano, bool):
        raise TypeError("el año tiene que ser un número entero")
    if not isinstance(hoy, date):
        raise TypeError("hoy tiene que ser un date")
    if desde is not None and not isinstance(desde, date):
        raise TypeError("desde tiene que ser un date o None")

    casillas: list[Casilla] = []
    cumplidos = 0
    programados = 0

    dia = date(ano, 1, 1)
    fin = date(ano, 12, 31)
    while dia <= fin:
        cantidad = cantidades.get(dia, 0)
        estado = _estado(habito, dia, cantidad, hoy=hoy, desde=desde)
        if estado in CUENTAN:
            programados += 1
            if estado is EstadoDia.CUMPLIDO:
                cumplidos += 1
        casillas.append(Casilla(jornada=dia, estado=estado, cantidad=cantidad))
        dia += UN_DIA

    return Anuario(
        ano=ano,
        casillas=tuple(casillas),
        cumplidos=cumplidos,
        programados=programados,
    )


def _estado(
    habito: Habito,
    dia: date,
    cantidad: int,
    *,
    hoy: date,
    desde: date | None,
) -> EstadoDia:
    # El orden de las preguntas importa. Lo primero es si el día existe para este
    # hábito: un día futuro cumplido no tiene sentido, pero un día ANTERIOR a que
    # el hábito existiera sí puede tener marca si el usuario rellenó hacia atrás,
    # y entonces sí se enseña.
    if dia > hoy:
        return EstadoDia.FUTURO
    if not habito.toca_en(dia):
        return EstadoDia.NO_PROGRAMADO
    if habito.cumplido_con(cantidad):
        # Cumplido manda sobre "antes": si hay marca es que ese día se hizo, y
        # esconderlo sería tirar un dato real.
        return EstadoDia.CUMPLIDO
    if desde is not None and dia < desde:
        return EstadoDia.ANTES
    # HOY NO CUENTA COMO FALLADO: el día no ha terminado. Es la misma regla que
    # la de las rachas; ver dominio/rachas.py.
    if dia == hoy:
        return EstadoDia.FUTURO
    return EstadoDia.FALLADO


def por_semanas(anuario: Anuario) -> list[list[Casilla | None]]:
    """Las casillas repartidas en columnas de semana, para dibujar la cuadrícula.

    Cada columna son siete casillas, de lunes a domingo. La primera y la última
    semana del año casi nunca están completas, y esos huecos van como None: si se
    rellenaran con días de otro año, el cuadrito estaría mintiendo sobre qué día
    representa.

    POR QUÉ EMPIEZA EN LUNES: es como se lee un calendario aquí, y es la misma
    numeración que usan los días del hábito (lunes 0).
    """
    semanas: list[list[Casilla | None]] = []
    columna: list[Casilla | None] = []

    for casilla in anuario.casillas:
        if not columna:
            # Huecos hasta el día de la semana en que cae el 1 de enero.
            columna = [None] * casilla.jornada.weekday()
        columna.append(casilla)
        if len(columna) == DIAS_DE_LA_SEMANA:
            semanas.append(columna)
            columna = []

    if columna:
        columna.extend([None] * (DIAS_DE_LA_SEMANA - len(columna)))
        semanas.append(columna)

    return semanas
