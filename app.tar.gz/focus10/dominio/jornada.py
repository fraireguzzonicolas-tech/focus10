"""La jornada de trabajo: un horario editable y a qué día pertenece cada hora.

EL PROBLEMA: quien trabaja de noche no tiene el día que marca el calendario.
Con un turno de 18:00 a 10:00, lo que pasa a las 03:00 del martes pertenece a
la noche que empezó el lunes. Si se etiquetara por la fecha del reloj, media
jornada caería en un día y media en el siguiente, y ningún resumen cuadraría.

LA REGLA, decidida con el usuario:

  1. El corte lo marca SOLO la hora de inicio. Cada jornada dura 24 horas y va
     de un inicio al siguiente: con inicio a las 18:00, la jornada del lunes 18
     cubre del lunes 18:00 al martes 17:59.
  2. La jornada se etiqueta con la fecha en que EMPEZÓ. La noche del lunes es
     "jornada del 18", aunque termine el martes.
  3. La hora de fin no clasifica nada: sirve para saber cuánto dura el turno y
     para responder si un momento cayó dentro de él o fuera.

POR QUÉ el corte lo marca solo el inicio: un horario de 18:00 a 10:00 cubre 16
de las 24 horas. Si la clasificación dependiera también del fin, todo lo que
pasa entre las 10:00 y las 18:00 se quedaría sin jornada, y las sumas por
jornada no darían el mismo total que la suma de todo. Con esta regla ningún
registro se queda huérfano.

POR QUÉ el cruce de medianoche se detecta solo, sin ningún ajuste que marcar:
si la hora de fin es menor o igual que la de inicio (10:00 <= 18:00), el turno
tiene que terminar al día siguiente. No hay otra posibilidad, así que
preguntarlo sería pedirle al usuario un dato que ya está en los otros dos.

POR QUÉ fechas y horas "ingenuas" (sin zona horaria): es una aplicación local
de un solo usuario, y todo lo que registra ocurre en la hora de su reloj.
Guardar UTC obligaría a convertir de ida y vuelta en cada cálculo de jornada
para acabar en el mismo sitio. El único efecto secundario es que las dos noches
del año en que cambia la hora una jornada dura 23 o 25 horas; para etiquetar
registros eso no cambia nada.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time, timedelta

UN_DIA = timedelta(days=1)


@dataclass(frozen=True)
class Horario:
    """El horario de trabajo vigente: a qué hora empieza y a qué hora acaba.

    Es inmutable (frozen) a propósito: se lee una vez de los ajustes y se pasa
    a las funciones de cálculo. Si alguien pudiera cambiarle la hora de inicio
    a medio cálculo, dos registros de la misma noche podrían acabar en jornadas
    distintas.
    """

    inicio: time
    fin: time

    def __post_init__(self) -> None:
        for nombre, valor in (("inicio", self.inicio), ("fin", self.fin)):
            if not isinstance(valor, time):
                raise TypeError(f"{nombre} tiene que ser datetime.time")
            if valor.tzinfo is not None:
                raise ValueError(f"{nombre} no lleva zona horaria (ver módulo)")
            # Se guarda como texto "HH:MM": admitir segundos sería perderlos
            # silenciosamente al guardar, y eso es peor que rechazarlos.
            if valor.second or valor.microsecond:
                raise ValueError(f"{nombre} solo admite horas y minutos: {valor}")

    @property
    def cruza_medianoche(self) -> bool:
        """True si el turno termina al día siguiente de empezar."""
        return self.fin <= self.inicio

    @property
    def duracion(self) -> timedelta:
        """Cuánto dura el turno. Si inicio y fin coinciden, son 24 horas
        (alguien de guardia permanente); no es un caso que se prohíba."""
        inicio = timedelta(hours=self.inicio.hour, minutes=self.inicio.minute)
        fin = timedelta(hours=self.fin.hour, minutes=self.fin.minute)
        return fin - inicio + UN_DIA if self.cruza_medianoche else fin - inicio

    @classmethod
    def desde_texto(cls, inicio: str, fin: str) -> Horario:
        """Construye el horario desde el "HH:MM" que se guarda en los ajustes."""
        return cls(inicio=_hora_desde_texto(inicio), fin=_hora_desde_texto(fin))

    def a_texto(self) -> tuple[str, str]:
        """Devuelve ("18:00", "10:00") para guardarlo en los ajustes."""
        return self.inicio.strftime("%H:%M"), self.fin.strftime("%H:%M")


def jornada_de(momento: datetime, horario: Horario) -> date:
    """A qué jornada pertenece un momento concreto. Es LA función del módulo:
    todo lo que se registre en la aplicación se fecha con esto, nunca con
    date.today().
    """
    _exigir_datetime_ingenuo(momento)
    if momento.time() >= horario.inicio:
        return momento.date()
    # Antes de la hora de inicio todavía se está en la jornada que arrancó ayer.
    return momento.date() - UN_DIA


def dentro_del_turno(momento: datetime, horario: Horario) -> bool:
    """True si ese momento cae dentro de las horas de trabajo de verdad.

    Ojo con la diferencia: un momento SIEMPRE tiene jornada (jornada_de nunca
    devuelve None), pero puede estar fuera del turno. Con horario 18:00-10:00,
    el martes a las 13:00 pertenece a la jornada del lunes y está fuera del
    turno.
    """
    _exigir_datetime_ingenuo(momento)
    hora = momento.time()
    if horario.cruza_medianoche:
        # El turno está partido por la medianoche: o va después del inicio, o
        # va antes del fin.
        return hora >= horario.inicio or hora < horario.fin
    return horario.inicio <= hora < horario.fin


def limites_de_jornada(jornada: date, horario: Horario) -> tuple[datetime, datetime]:
    """Los dos extremos de las 24 horas de una jornada: [desde, hasta).

    "hasta" no está incluido: es el instante exacto en que empieza la jornada
    siguiente. Se devuelve así para poder filtrar en SQL con
    "momento >= desde AND momento < hasta" sin dejar ni duplicar un segundo.
    """
    desde = datetime.combine(jornada, horario.inicio)
    return desde, desde + UN_DIA


def limites_del_turno(jornada: date, horario: Horario) -> tuple[datetime, datetime]:
    """Las horas de trabajo reales de una jornada: [entrada, salida)."""
    entrada = datetime.combine(jornada, horario.inicio)
    dia_de_salida = jornada + UN_DIA if horario.cruza_medianoche else jornada
    return entrada, datetime.combine(dia_de_salida, horario.fin)


def jornada_actual(horario: Horario, ahora: datetime | None = None) -> date:
    """La jornada en curso. El parámetro "ahora" existe para que los tests
    puedan fijar el momento sin tocar el reloj del sistema."""
    return jornada_de(ahora if ahora is not None else datetime.now(), horario)


def _hora_desde_texto(texto: str) -> time:
    """Lee "18:00" o "18:30". Estricto a propósito: este texto viene de la base
    de datos, y si está corrupto conviene enterarse con un mensaje claro."""
    if not isinstance(texto, str):
        raise TypeError(f"la hora tiene que ser texto, no {type(texto).__name__}")
    partes = texto.strip().split(":")
    if len(partes) != 2 or not all(parte.isdigit() for parte in partes):
        raise ValueError(f"hora mal escrita, se esperaba HH:MM: {texto!r}")
    horas, minutos = int(partes[0]), int(partes[1])
    if not (0 <= horas <= 23 and 0 <= minutos <= 59):
        raise ValueError(f"hora fuera de rango: {texto!r}")
    return time(hour=horas, minute=minutos)


def _exigir_datetime_ingenuo(momento: datetime) -> None:
    if not isinstance(momento, datetime):
        raise TypeError(
            f"se esperaba un datetime, no {type(momento).__name__}"
            " (un date suelto no sirve: sin hora no se sabe la jornada)"
        )
    if momento.tzinfo is not None:
        raise ValueError(
            "aquí se trabaja con horas locales sin zona horaria; "
            "convierte el momento antes de pasarlo"
        )
