"""Quién puede avisarte de WhatsApp e Instagram, y en qué horario.

ESTO SOLO ORDENA Y COMPRUEBA LO QUE ESCRIBES. Quién suena de verdad lo decide
la pieza de Java del móvil (extensiones/focus10_avisos, Filtro.java), porque
corre con la aplicación cerrada. Aquí se garantiza que lo que le llega está
limpio: horas bien escritas, sin nombres repetidos y con un tope.

LA COMPARACIÓN DE NOMBRES VIVE EN JAVA Y SOLO ALLÍ. Tenerla también aquí sería
tener dos reglas que un día dirían cosas distintas.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, replace

MAXIMO_NOMBRES = 50
LARGO_MAXIMO_NOMBRE = 60

TODO_EL_DIA = "00:00"
"""Desde y hasta iguales es todo el día. De partida no se inventa un horario."""

_HORA = re.compile(r"^(\d{1,2})(?::(\d{2}))?$")


@dataclass(frozen=True)
class FiltroAvisos:
    activo: bool = False
    desde: str = TODO_EL_DIA
    hasta: str = TODO_EL_DIA
    nombres: tuple[str, ...] = ()


def leer_hora(texto: str) -> str:
    """"22", "22:00", "7:30" o "7.30" -> "HH:MM". Si no es una hora, ValueError.

    SE ACEPTA EL PUNTO porque el teclado numérico del móvil no siempre trae los
    dos puntos, y escribir una hora no puede costar cambiar de teclado.
    """
    encontrado = _HORA.match((texto or "").strip().replace(".", ":"))
    if encontrado is None:
        raise ValueError(f"«{texto}» no es una hora. Escríbela así: 22:00.")
    horas, minutos = int(encontrado.group(1)), int(encontrado.group(2) or 0)
    if horas > 23 or minutos > 59:
        raise ValueError(f"«{texto}» no es una hora. Va de 00:00 a 23:59.")
    return f"{horas:02d}:{minutos:02d}"


def con_horario(filtro: FiltroAvisos, desde: str, hasta: str) -> FiltroAvisos:
    return replace(filtro, desde=leer_hora(desde), hasta=leer_hora(hasta))


def con_nombre(filtro: FiltroAvisos, nombre: str) -> FiltroAvisos:
    """Añade un nombre o número a la lista.

    SE GUARDA TAL CUAL LO ESCRIBES, solo sin espacios de más: el aviso de la
    pantalla pide que sea exactamente el de WhatsApp, y aquí no se le toca ni
    una letra.
    """
    limpio = " ".join((nombre or "").split())
    if not limpio:
        raise ValueError("Escribe un nombre o un número.")
    if len(limpio) > LARGO_MAXIMO_NOMBRE:
        raise ValueError(f"Como mucho {LARGO_MAXIMO_NOMBRE} letras.")
    if limpio.casefold() in {uno.casefold() for uno in filtro.nombres}:
        raise ValueError(f"«{limpio}» ya está en la lista.")
    if len(filtro.nombres) >= MAXIMO_NOMBRES:
        raise ValueError(f"La lista admite {MAXIMO_NOMBRES} nombres como mucho.")
    return replace(filtro, nombres=(*filtro.nombres, limpio))


def sin_nombre(filtro: FiltroAvisos, nombre: str) -> FiltroAvisos:
    return replace(filtro, nombres=tuple(uno for uno in filtro.nombres if uno != nombre))


def a_texto(filtro: FiltroAvisos) -> str:
    """Lo que se guarda en el móvil y lee Java."""
    return json.dumps(
        {
            "activo": filtro.activo,
            "desde": filtro.desde,
            "hasta": filtro.hasta,
            "nombres": list(filtro.nombres),
        },
        ensure_ascii=False,
    )


def desde_texto(texto: str) -> FiltroAvisos:
    """Lee lo guardado en el móvil.

    VACÍO O ROTO DEVUELVE EL FILTRO APAGADO, y lo que se pueda salvar se salva
    pasando por las mismas comprobaciones que al escribirlo: un nombre raro no
    puede tirar la lista entera ni colarse sin revisar.
    """
    try:
        datos = json.loads(texto or "")
    except ValueError:
        return FiltroAvisos()
    if not isinstance(datos, dict):
        return FiltroAvisos()

    filtro = FiltroAvisos(activo=datos.get("activo") is True)
    try:
        filtro = con_horario(
            filtro,
            str(datos.get("desde", TODO_EL_DIA)),
            str(datos.get("hasta", TODO_EL_DIA)),
        )
    except ValueError:
        pass
    nombres = datos.get("nombres")
    for nombre in nombres if isinstance(nombres, list) else []:
        try:
            filtro = con_nombre(filtro, str(nombre))
        except ValueError:
            pass
    return filtro
