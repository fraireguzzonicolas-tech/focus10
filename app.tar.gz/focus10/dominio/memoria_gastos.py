"""La memoria de gastos: qué se recuerda y cuándo un gasto nuevo se parece a otro.

DE DÓNDE SALE LA MEMORIA: de los gastos de las categorías marcadas «Sí,
recordar cada gasto» (ver Memoria en categoria.py). No hay una copia aparte:
se leen del historial cada vez, así que activar la memoria de una categoría
incluye lo de meses atrás, y apagarla lo saca.

EL AVISO DE REPETIDO LO DA FOCUS, NO LA IA, y es a propósito. Comparar «Jorge»
con «Jorge» es una regla fija que no puede equivocarse ni inventar: si lo
decidiera el modelo, un día diría que ya pagaste a alguien a quien no pagaste.
La IA entiende lo que dijiste; la cuenta de lo que ya hay la lleva la app.

SOLO AVISA, NUNCA FRENA. Pagarle dos veces a Jorge puede ser justo lo que
querías; la app pregunta y, si dices que sí, se apunta como cualquier otro.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from . import dinero
from .moneda import Moneda
from .palabras import palabras, singular

LARGO_MINIMO = 3
"""Palabras más cortas no cuentan para parecerse: «de», «a», «el» estarían en
todas las notas y todo se parecería a todo."""

VACIAS = frozenset(
    {
        "para", "por", "con", "sin", "del", "los", "las", "una", "uno", "unos",
        "unas", "que", "mas", "pago", "pague", "gasto", "gaste", "compra",
        "compre", "euro", "dolar", "peso", "otro", "otra", "este", "esta",
        "mes", "dia", "hoy", "ayer",
    }
)
"""Palabras que salen en cualquier nota de gasto y no dicen DE QUÉ es.

Van ya en singular y sin tildes, como quedan después de normalizar: «euros» y
«pagué» llegan aquí como «euro» y «pague». Sin esta lista, «pago a Jorge» y
«pago del dominio» se parecerían por la palabra «pago».
"""


@dataclass(frozen=True)
class Recordado:
    """Un gasto de la memoria: lo justo para avisar y para contárselo a la IA."""

    importe: int
    moneda: Moneda
    descripcion: str
    categoria: str
    jornada: date


def claves(texto: str) -> frozenset[str]:
    """Las palabras que dicen de qué es un gasto: «Pagué a Jorge» -> {jorge}."""
    return frozenset(
        forma
        for palabra in palabras(texto)
        if len(forma := singular(palabra)) >= LARGO_MINIMO
        and forma not in VACIAS
        and not forma.isdigit()
    )


def parecidos(descripcion: str, memoria: list[Recordado]) -> list[Recordado]:
    """Los gastos recordados que comparten alguna palabra con el nuevo.

    UNA PALABRA EN COMÚN BASTA: «Jorge» y «Diseño web para Jorge» son el mismo
    Jorge. Preferible avisar de más (el usuario dice «sí» y listo) que callarse
    un pago repetido de verdad.

    SIN NOTA NO HAY NADA QUE COMPARAR: un gasto que no dice de qué es no se
    puede parecer a nada, y avisar por el importe solo sería ruido.
    """
    nuevas = claves(descripcion)
    if not nuevas:
        return []
    return [uno for uno in memoria if nuevas & claves(uno.descripcion)]


def aviso(importe: int, moneda: Moneda, parecidos_: list[Recordado]) -> str | None:
    """La pregunta antes de apuntar, o None si no hay nada parecido.

    «Ya registraste 100 € para Jorge. ¿Seguro que querés agregar otros 400 €?»
    Es la frase del usuario, palabra por palabra.

    CON VARIOS, LA SUMA SOLO SI SON DE LA MISMA MONEDA: sumar euros con dólares
    sin convertir daría un número que no existe. Si se mezclan, se dice cuántos
    hay, que es verdad, en vez de un total inventado.
    """
    if not parecidos_:
        return None
    nuevo = dinero.formatear(importe, moneda)
    if len(parecidos_) == 1:
        uno = parecidos_[0]
        ya = f"Ya registraste {dinero.formatear(uno.importe, uno.moneda)} para {uno.descripcion}."
    else:
        de_que = parecidos_[0].descripcion
        monedas = {uno.moneda for uno in parecidos_}
        if len(monedas) == 1:
            total = dinero.formatear(sum(uno.importe for uno in parecidos_), monedas.pop())
            ya = f"Ya registraste {len(parecidos_)} gastos para {de_que} ({total} en total)."
        else:
            ya = f"Ya registraste {len(parecidos_)} gastos para {de_que}."
    return f"{ya} ¿Seguro que querés agregar otros {nuevo}?"
