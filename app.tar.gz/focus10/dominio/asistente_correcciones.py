"""Corregir lo último: «en realidad fueron 250 g de arroz», «eran para el ahorro».

LO PIDIÓ EL USUARIO: «las correcciones deben actualizar el registro original
cuando sea posible, en lugar de duplicarlo». Por eso se CAMBIA el apunte, con
su mismo id, y no se suma otro.

¿CUÁL ES «EL ORIGINAL»?
- Una comida: el apunte MÁS RECIENTE DE HOY con ese nombre. «Arroz» corrige el
  arroz de hoy, no el de la semana pasada.
- Dinero: el ÚLTIMO MOVIMIENTO DEL DÍA. Es lo que se acaba de apuntar; si no
  hay ninguno hoy, se dice en vez de corregir uno viejo a ciegas.
"""

from __future__ import annotations

from dataclasses import dataclass, replace

from . import dinero
from .alimento import Registro
from .asistente_comidas import numeros_de, texto_de
from .asistente_finanzas import TIPOS, VERBOS, buscar_categoria
from .asistente_tipos import Decir, Hacer
from .categoria import Categoria
from .moneda import Moneda
from .movimiento import Movimiento
from .palabras import mismo_nombre


@dataclass(frozen=True)
class CorregirComida:
    antes: Registro
    despues: Registro

    def frase(self) -> str:
        signo = "≈ " if self.despues.nota.startswith("≈") else ""
        return f"corregí: {texto_de(self.despues)}, {signo}{self.despues.kcal} kcal"


@dataclass(frozen=True)
class CorregirMovimiento:
    antes: Movimiento
    despues: Movimiento
    categoria: Categoria

    def frase(self) -> str:
        cuanto = dinero.formatear(self.despues.importe, self.despues.moneda)
        return f"corregí el último movimiento: ahora {VERBOS[self.despues.tipo]} {cuanto} en {self.categoria.nombre}"


def decidir_comida(datos: dict, de_hoy: list[Registro], conocidas: list[Registro]) -> Decir | Hacer:
    alimento = str(datos.get("alimento") or "").strip()
    cantidad = str(datos.get("cantidad") or "").strip()
    unidad = str(datos.get("unidad") or "").strip()
    if not alimento or not cantidad:
        return Decir("¿Qué comida corrijo y cuánto era?")
    candidatos = [r for r in de_hoy if mismo_nombre(r.nombre, alimento)]
    if not candidatos:
        return Decir(f"Hoy no tengo apuntado «{alimento}».")
    antes = max(candidatos, key=lambda r: (r.momento, r.id or 0))
    hallado = numeros_de(alimento, cantidad, unidad, conocidas)
    if hallado is None:
        return Decir(f"No tengo los valores de «{alimento}» en esa cantidad; no cambié nada.")
    (kcal, prot, carb, gras), nota = hallado
    try:
        despues = replace(antes, cantidad=cantidad, unidad=unidad, kcal=kcal, proteinas=prot,
                          carbohidratos=carb, grasas=gras, nota=nota or antes.nota)
    except (TypeError, ValueError) as fallo:
        return Decir(f"No pude corregirlo: {fallo}.")
    return Hacer(CorregirComida(antes, despues))


def decidir_movimiento(
    datos: dict, ultimo: Movimiento | None, categorias: list[Categoria], principal: Moneda
) -> Decir | Hacer:
    """Lo que no cambia va vacío. Si cambia el tipo («era para el ahorro»), la
    categoría también: la del tipo nuevo (la que dijo, o la única que haya)."""
    if ultimo is None:
        return Decir("Hoy no apuntaste ningún movimiento para corregir.")
    cambios: dict = {}
    importe_dicho = str(datos.get("importe") or "").strip()
    if importe_dicho:
        importe = dinero.parsear_importe(importe_dicho, ultimo.moneda)
        if importe is None or importe <= 0:
            return Decir("No entendí el importe nuevo.")
        cambios["importe"] = importe
    tipo = ultimo.tipo
    tipo_dicho = str(datos.get("tipo") or "").strip()
    if tipo_dicho:
        if tipo_dicho not in TIPOS:
            return Decir("¿Es un gasto, un ingreso o algo para el ahorro?")
        tipo = TIPOS[tipo_dicho]
    de_ese_tipo = [c for c in categorias if c.tipo is tipo]
    nombrada = str(datos.get("categoria") or "").strip()
    categoria = buscar_categoria(nombrada, de_ese_tipo) if nombrada else next(
        (c for c in de_ese_tipo if c.id == ultimo.categoria_id), None)
    if categoria is None and not nombrada and len(de_ese_tipo) == 1:
        categoria = de_ese_tipo[0]
    if categoria is None:
        nombres = ", ".join(c.nombre for c in de_ese_tipo[:6])
        return Decir(f"¿En qué categoría? Por ejemplo: {nombres}.")
    descripcion = str(datos.get("descripcion") or "").strip()
    if not cambios and tipo is ultimo.tipo and categoria.id == ultimo.categoria_id and not descripcion:
        return Decir("¿Qué cambio del último movimiento?")
    try:
        despues = replace(
            Movimiento.nuevo(
                tipo=tipo, importe=cambios.get("importe", ultimo.importe),
                categoria_id=categoria.id, momento=ultimo.momento, jornada=ultimo.jornada,
                # IGUAL QUE AL APUNTAR (repositorio_movimientos.apuntar_ahora):
                # la corrección se calcula exactamente como el apunte original.
                principal=principal, moneda=ultimo.moneda, descripcion=descripcion or ultimo.descripcion,
            ),
            id=ultimo.id,
        )
    except (TypeError, ValueError) as fallo:
        return Decir(f"No pude corregirlo: {fallo}.")
    return Hacer(CorregirMovimiento(ultimo, despues, categoria))
