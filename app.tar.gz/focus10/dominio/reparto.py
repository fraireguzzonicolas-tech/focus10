"""El reparto de un gasto entre categorías: lo que enseña el círculo del Dashboard.

POR QUÉ ES UNA PIEZA APARTE Y NO PARTE DE resumen.py: resumen.py contesta "cuánto",
y esto contesta "en qué". Son dos preguntas, y la segunda necesita las categorías,
que la primera no mira para nada.

LO QUE NO SE PUEDE CONVERTIR NO SE INVENTA: un gasto en dólares sin tasa no entra
en ninguna porción, se aparta y se cuenta aparte, igual que en los totales. Un
círculo que se repartiera el 100 % escondiendo que falta un gasto estaría
mintiendo con una forma bonita.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass

from .moneda import EUR, Moneda
from .movimiento import Movimiento, Tipo

SIN_CATEGORIA = "Sin categoría"


@dataclass(frozen=True)
class Porcion:
    categoria: str
    importe: int
    """En unidades mínimas de la moneda principal."""

    fraccion: float
    """De 0 a 1, sobre el total repartido."""


@dataclass(frozen=True)
class Reparto:
    principal: Moneda
    porciones: tuple[Porcion, ...]
    total: int
    pendientes: tuple[Movimiento, ...]
    """Los que no se pudieron convertir, y por eso no están en ninguna porción."""

    @property
    def hay_algo(self) -> bool:
        """False cuando no hay nada que repartir.

        Se distingue de "todo a cero" a propósito: un día sin gastos no es un día
        con gastos de cero euros, y el círculo tiene que decir "no hay nada" en
        vez de dibujar una rueda vacía que parece un fallo.
        """
        return self.total > 0

    @property
    def hay_pendientes(self) -> bool:
        return bool(self.pendientes)


def por_categoria(
    movimientos: Iterable[Movimiento],
    nombres: Mapping[int, str],
    *,
    tipo: Tipo = Tipo.GASTO,
    principal: Moneda = EUR,
) -> Reparto:
    """Reparte los movimientos de ese tipo entre sus categorías, de mayor a menor.

    `nombres` traduce el id de categoría a su nombre. Un id que no esté se
    enseña como "Sin categoría" en vez de romper: la pantalla tiene que poder
    dibujarse aunque alguien haya borrado una categoría por debajo.
    """
    if not isinstance(tipo, Tipo):
        raise TypeError(f"tipo tiene que ser un Tipo, no {type(tipo).__name__}")

    sumas: dict[str, int] = {}
    pendientes: list[Movimiento] = []

    for movimiento in movimientos:
        if not isinstance(movimiento, Movimiento):
            raise TypeError(f"esto no es un Movimiento: {movimiento!r}")
        if movimiento.tipo is not tipo:
            continue
        if movimiento.pendiente_de_cambio:
            pendientes.append(movimiento)
            continue
        nombre = nombres.get(movimiento.categoria_id, SIN_CATEGORIA)
        sumas[nombre] = sumas.get(nombre, 0) + movimiento.importe_principal

    total = sum(sumas.values())
    # De mayor a menor, y a igual importe por nombre: sin el segundo criterio, dos
    # categorías empatadas se intercambiarían de sitio entre dos aperturas.
    ordenadas = sorted(sumas.items(), key=lambda par: (-par[1], par[0].lower()))

    porciones = tuple(
        Porcion(
            categoria=nombre,
            importe=importe,
            fraccion=importe / total if total else 0.0,
        )
        for nombre, importe in ordenadas
    )

    return Reparto(
        principal=principal,
        porciones=porciones,
        total=total,
        pendientes=tuple(pendientes),
    )
