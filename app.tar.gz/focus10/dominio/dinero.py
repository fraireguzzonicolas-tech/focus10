"""El dinero de Focus10, siempre en unidades mínimas enteras.

POR QUÉ ENTEROS Y NUNCA UN FLOAT: un float no puede representar 0,10 de forma
exacta, porque guarda los números en binario y 1/10 no tiene representación
binaria finita (por eso 0.1 + 0.2 != 0.3 en Python, en Java y en cualquier otro
lenguaje). Sumando cientos de importes ese error se acumula y los totales dejan
de cuadrar con la realidad. Un entero es exacto, se suma sin sorpresas y SQLite
lo guarda tal cual en una columna INTEGER.

POR QUÉ Decimal en la frontera: cuando hay que hablar en unidades "grandes"
(euros, dólares) se usa Decimal, que es decimal de verdad, como BigDecimal en
Java. El float no entra en este módulo ni de paso: a_unidades_minimas() lo
rechaza a propósito.

POR QUÉ "unidades mínimas" y ya no "céntimos": desde que hay dólares de por
medio, llamar céntimos a todo sería mentir en el nombre. Cada moneda dice
cuántos decimales tiene (ver dominio/moneda.py). Todas las funciones usan el
euro si no se dice otra cosa, porque es la moneda principal del usuario.
"""

from __future__ import annotations

import re
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from .moneda import CATALOGO, EUR, Moneda

# Tope de una columna INTEGER de SQLite (entero de 64 bits con signo). Por
# encima de esto el importe no se podría guardar, así que se rechaza al leerlo
# en vez de fallar más tarde al escribir en la base de datos.
LIMITE_UNIDADES = 2**63 - 1

# Espacios "raros" que aparecen al copiar importes de webs y hojas de calculo:
# espacio duro, espacio duro fino, espacio fino y tabulador. Se escriben con
# su codigo en vez del caracter suelto porque a simple vista son identicos a
# un espacio normal y nadie podria revisar esta linea.
_ESPACIOS_RAROS = ("\u00a0", "\u202f", "\u2009", "\t")

_SOLO_NUMERO_Y_SEPARADORES = re.compile(r"[0-9.,]+")

# Símbolos y códigos que se ignoran al leer un importe escrito a mano, sea cual
# sea la moneda del campo. Se quitan todos porque el campo YA sabe en qué moneda
# estás apuntando: si escribes "8,50 €" teniendo el dólar seleccionado, el
# despiste está en el símbolo, no en el importe, y rechazarlo solo molestaría.
_RUIDO_DE_MONEDA = re.compile(
    "(?i)"
    + "|".join(
        [re.escape(moneda.simbolo) for moneda in CATALOGO.values()]
        + [re.escape(codigo) for codigo in CATALOGO]
        + [re.escape("$")]
    )
)


def a_unidades_minimas(cantidad: Decimal | int | str, moneda: Moneda = EUR) -> int:
    """Convierte una cantidad ("8.50" euros) a unidades mínimas (850 céntimos).

    Acepta Decimal, int o str. Rechaza float a propósito: si se permitiera, un
    8.7 mal redondeado entraría en la base de datos y ya no habría forma de
    saber que el dato está mal.

    Si llegan más decimales de los que tiene la moneda (por ejemplo al dividir
    una cuenta entre tres) se redondea con el criterio comercial de toda la
    vida: el 5 sube.
    """
    if isinstance(cantidad, float):
        raise TypeError(
            "a_unidades_minimas no acepta float porque pierde precisión; "
            "usa Decimal('8.50'), un int o la cadena '8.50'"
        )
    if isinstance(cantidad, Decimal):
        valor = cantidad
    elif isinstance(cantidad, int):
        valor = Decimal(cantidad)
    elif isinstance(cantidad, str):
        try:
            valor = Decimal(cantidad.strip())
        except InvalidOperation as error:
            raise ValueError(f"no es una cantidad válida: {cantidad!r}") from error
    else:
        raise TypeError(f"tipo no admitido: {type(cantidad).__name__}")

    if not valor.is_finite():
        raise ValueError(f"cantidad no finita: {cantidad!r}")

    unidades = (valor * moneda.unidades_por_entero).quantize(
        Decimal(1), rounding=ROUND_HALF_UP
    )
    return int(unidades)


def a_cantidad(unidades: int, moneda: Moneda = EUR) -> Decimal:
    """Convierte unidades mínimas (850) a la cantidad grande (8,50) como Decimal."""
    _exigir_entero(unidades)
    if moneda.decimales == 0:
        return Decimal(unidades)
    return (Decimal(unidades) / moneda.unidades_por_entero).quantize(
        Decimal(1).scaleb(-moneda.decimales)
    )


def formatear(unidades: int, moneda: Moneda = EUR, *, con_simbolo: bool = True) -> str:
    """Escribe el importe como se escribe aquí: 1.234,56 € o US$ 1.234,56.

    POR QUÉ a mano y no con el módulo locale: locale.setlocale() cambia estado
    global de todo el proceso y en Windows depende de que exista el idioma
    "Spanish_Spain.1252" en el sistema. Formatear cuatro caracteres a mano es
    más aburrido, pero funciona igual en cualquier máquina.
    """
    _exigir_entero(unidades)
    signo = "-" if unidades < 0 else ""
    if moneda.decimales == 0:
        parte_entera, parte_decimal = abs(unidades), None
    else:
        parte_entera, parte_decimal = divmod(abs(unidades), moneda.unidades_por_entero)

    # f"{n:,}" agrupa de tres en tres con comas; aquí las comas pasan a ser
    # puntos de millar y el decimal se pega con coma.
    numero = f"{parte_entera:,}".replace(",", ".")
    if parte_decimal is not None:
        numero = f"{numero},{parte_decimal:0{moneda.decimales}d}"

    if not con_simbolo:
        return f"{signo}{numero}"
    # El signo va delante de todo, también del símbolo: "-US$ 8,50".
    if moneda.simbolo_delante:
        return f"{signo}{moneda.simbolo} {numero}"
    return f"{signo}{numero} {moneda.simbolo}"


def parsear_importe(texto: str, moneda: Moneda = EUR) -> int | None:
    """Interpreta lo que el usuario escribe en un campo y devuelve unidades.

    Devuelve None cuando no lo entiende, en vez de adivinar: es mejor un aviso
    de "no te entiendo" que guardar un importe equivocado.

    Reglas, decididas con el usuario (ejemplos en euros):
      - "8,50", "8.50", "8.5"  -> 850
      - "1234"                 -> 123400
      - "1.234", "1,234"       -> 123400  (separador de miles: exactamente
                                           tres cifras detrás y grupo inicial
                                           válido, sin ceros a la izquierda)
      - "1.234,56", "1,234.56" -> 123456  (el ÚLTIMO separador es el decimal)
      - "8.5 €", " 8,50€ "     -> 850     (símbolo y espacios se ignoran)
      - "-8,50"                -> -850
      - "0,500", "1,2345", "8,", "ocho" -> None
    """
    if not isinstance(texto, str):
        return None

    limpio = texto.strip()
    for espacio in _ESPACIOS_RAROS:
        limpio = limpio.replace(espacio, "")
    limpio = limpio.replace(" ", "")
    limpio = _RUIDO_DE_MONEDA.sub("", limpio)

    negativo = False
    if limpio.startswith("-"):
        negativo = True
        limpio = limpio[1:]
    elif limpio.startswith("+"):
        limpio = limpio[1:]

    if not limpio or not _SOLO_NUMERO_Y_SEPARADORES.fullmatch(limpio):
        return None
    if not any(caracter.isdigit() for caracter in limpio):
        return None

    corte = max(limpio.rfind("."), limpio.rfind(","))

    if corte == -1:
        # Solo cifras: son unidades grandes enteras.
        if not limpio.isdigit():
            return None
        unidades = int(limpio) * moneda.unidades_por_entero
    else:
        unidades = None

        # Lectura 1: el último separador es el decimal, con tantas cifras
        # detrás como decimales tenga la moneda.
        # Ojo: esto ya descarta solo a las monedas SIN decimales, porque
        # "1 <= algo <= 0" no se cumple nunca. Había aquí una comprobación
        # extra de moneda.decimales > 0 y se quitó al descubrir, rompiéndola a
        # propósito, que ningún test podía notar su ausencia: no decidía nada.
        decimales = limpio[corte + 1 :]
        if 1 <= len(decimales) <= moneda.decimales and decimales.isdigit():
            entero = _parte_entera(limpio[:corte])
            if entero is not None:
                # "8,5" son 50 céntimos, no 5: se rellena a la derecha.
                unidades = entero * moneda.unidades_por_entero + int(
                    decimales.ljust(moneda.decimales, "0")
                )

        # Lectura 2: todos los separadores son de miles y no hay decimales.
        # Se prueba después, así "8.50" gana como 8,50 € y "1.500" como 1500 €.
        if unidades is None:
            entero = _parte_entera(limpio)
            if entero is not None:
                unidades = entero * moneda.unidades_por_entero

        if unidades is None:
            return None

    if negativo:
        unidades = -unidades
    if abs(unidades) > LIMITE_UNIDADES:
        return None
    return unidades


def _parte_entera(texto: str) -> int | None:
    """Lee la parte entera, con separadores de miles o sin ellos.

    Devuelve None si los separadores no forman grupos creíbles. Ese "None" es
    lo que hace que "1,2345" o "0,500" se rechacen en vez de convertirse en
    algo que el usuario no ha escrito.
    """
    if texto == "":
        # Caso ",50": la parte entera vacía se lee como cero.
        return 0
    if "." not in texto and "," not in texto:
        return int(texto) if texto.isdigit() else None

    separadores = {caracter for caracter in texto if caracter in ".,"}
    if len(separadores) != 1:
        # Mezclar los dos separadores dentro de la parte entera no es nada
        # que alguien escriba a propósito.
        return None

    grupos = texto.split(separadores.pop())
    primero, resto = grupos[0], grupos[1:]

    if not primero.isdigit() or not 1 <= len(primero) <= 3:
        return None
    if primero.startswith("0"):
        # Un número con separador de miles nunca empieza por cero: eso delata
        # que el separador era en realidad un decimal ("0,500").
        return None
    for grupo in resto:
        if len(grupo) != 3 or not grupo.isdigit():
            return None

    return int(primero + "".join(resto))


def _exigir_entero(unidades: int) -> None:
    """Las unidades mínimas son enteras. Un float aquí significa que alguien se
    ha saltado la frontera del módulo, y conviene saberlo cuanto antes."""
    if isinstance(unidades, bool) or not isinstance(unidades, int):
        raise TypeError(f"las unidades tienen que ser int, no {type(unidades).__name__}")
