"""Una categoría de gasto o de ingreso.

POR QUÉ LAS CATEGORÍAS SÍ SON UNA TABLA Y LAS MONEDAS NO: que el euro tenga dos
decimales es un hecho del mundo; que exista una categoría llamada "Boludeo" es
una decisión del usuario, que además puede cambiar de idea. Todo lo que el
usuario crea, renombra o esconde tiene que vivir en la base de datos.

POR QUÉ SE DESACTIVAN EN VEZ DE BORRARSE: si se borrara una categoría con gastos
apuntados, esos gastos se quedarían señalando a algo que ya no existe y dejaría
de poderse responder "cuánto gasté en transporte el año pasado". Desactivada
deja de aparecer al apuntar, pero el historial sigue entendiéndose.
"""

from __future__ import annotations

from dataclasses import dataclass

from .movimiento import Tipo

LARGO_MAXIMO_NOMBRE = 40


@dataclass(frozen=True)
class Categoria:
    nombre: str
    tipo: Tipo
    """De qué sirve: una categoría de gasto no debe aparecer al apuntar un
    ingreso. "Sueldo" y "Alimentación" no compiten por el mismo desplegable."""

    id: int | None = None
    """None mientras no se haya guardado en la base de datos."""

    activa: bool = True
    orden: int = 0
    """Para poder poner arriba las que más se usan, en vez de por orden
    alfabético o de creación."""

    def __post_init__(self) -> None:
        if not isinstance(self.nombre, str):
            raise TypeError(f"el nombre tiene que ser texto, no {type(self.nombre).__name__}")
        limpio = self.nombre.strip()
        if not limpio:
            raise ValueError("la categoría necesita un nombre")
        if len(limpio) > LARGO_MAXIMO_NOMBRE:
            raise ValueError(
                f"el nombre no puede pasar de {LARGO_MAXIMO_NOMBRE} caracteres "
                f"(llegaron {len(limpio)})"
            )
        # El dataclass es frozen, así que normalizar exige saltarse la
        # inmutabilidad aquí dentro. Sin esto, "Ocio " y "Ocio" serían dos
        # categorías distintas para el usuario y una sola a la vista.
        object.__setattr__(self, "nombre", limpio)

        if not isinstance(self.tipo, Tipo):
            raise TypeError(f"tipo tiene que ser Tipo, no {type(self.tipo).__name__}")
        if not isinstance(self.activa, bool):
            raise TypeError("activa tiene que ser True o False")
        if isinstance(self.orden, bool) or not isinstance(self.orden, int):
            raise TypeError("orden tiene que ser int")
        if self.orden < 0:
            raise ValueError(f"orden no puede ser negativo, y llegó {self.orden}")
        if self.id is not None:
            if isinstance(self.id, bool) or not isinstance(self.id, int):
                raise TypeError("el id tiene que ser int o None")
            if self.id <= 0:
                raise ValueError(f"id tiene que ser mayor que cero, y llegó {self.id}")
