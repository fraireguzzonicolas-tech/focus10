"""Los logros: las medallas de racha y las tarjetas para compartir FUERA.

VIENE DE LA COMUNIDAD VIEJA (la red social), que se borró el 8 nov 2026 al
pasar a ser un ranking. De ella quedan dos cosas, por decisión del usuario:

  - LAS MEDALLAS DE CADA HÁBITO (7 días, 1 mes y cada mes después). No eran
    sociales: son tuyas, y la app te las anuncia (dialogo_medalla.py).
  - LA IMAGEN PARA COMPARTIR un entreno, el día o una medalla por Instagram o
    WhatsApp (imagen_logro.py). «Se queda»: no publica nada dentro de Focus.

AQUÍ NO HAY RED NI BASE DE DATOS: solo reglas y textos.
"""

from __future__ import annotations

from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Las medallas
# ---------------------------------------------------------------------------

PRIMERA_MEDALLA = 7
UN_MES = 30


def hitos_hasta(dias: int) -> list[int]:
    """Los hitos de racha alcanzados con esa racha: 7, 30, 60, 90...

    LO PIDIÓ EL USUARIO ASÍ: «a los 7 días una medallita, lo mismo a los 30, al
    primer mes, dos meses, tres meses, y así constantemente». No hay tope: un
    año de racha es la medalla de los 12 meses, y a los 13 le sigue otra.

    LOS DÍAS SON DÍAS DE RACHA, es decir, días en que el hábito TOCABA y lo
    cumpliste (ver dominio/rachas.py). Un hábito de lunes, miércoles y viernes
    tarda más en llegar a 30, y está bien: son 30 veces cumplidas de verdad.
    """
    if isinstance(dias, bool) or not isinstance(dias, int):
        raise TypeError("los días tienen que ser un entero")
    hitos = [PRIMERA_MEDALLA] if dias >= PRIMERA_MEDALLA else []
    hitos += list(range(UN_MES, dias + 1, UN_MES))
    return hitos


def nombre_del_hito(dias: int) -> str:
    """Cómo se dice el hito: «7 días», «1 mes», «2 meses», «1 año»."""
    if dias < UN_MES:
        return f"{dias} días"
    meses = dias // UN_MES
    if meses % 12 == 0:
        anos = meses // 12
        return "1 año" if anos == 1 else f"{anos} años"
    return "1 mes" if meses == 1 else f"{meses} meses"


# LOS METALES. Suben con la racha para que se note de lejos cuál costó más.
# Sus COLORES viven en interfaz/estilo.py (METALES), como todos los colores de
# la aplicación: aquí solo se decide qué metal le toca a cada racha.
NIVELES: tuple[tuple[int, str], ...] = (
    (PRIMERA_MEDALLA, "bronce"),
    (UN_MES, "plata"),
    (3 * UN_MES, "oro"),
    (6 * UN_MES, "platino"),
    (12 * UN_MES, "diamante"),
)


def nivel_del_hito(dias: int) -> str:
    """El metal de una medalla de tantos días: bronce, plata, oro..."""
    elegido = NIVELES[0][1]
    for desde, metal in NIVELES:
        if dias >= desde:
            elegido = metal
    return elegido


@dataclass(frozen=True)
class Medalla:
    """Una medalla ganada: de qué hábito y de cuántos días."""

    habito_uid: str
    habito: str
    dias: int

    @property
    def clave(self) -> str:
        """Lo que la hace única. Subirla dos veces no la duplica."""
        return f"racha:{self.habito_uid}:{self.dias}"

    @property
    def titulo(self) -> str:
        return f"{nombre_del_hito(self.dias)} · {self.habito}"


def medallas_de(habito_uid: str, habito: str, mejor_racha: int) -> list[Medalla]:
    """Todas las medallas que ya ganó un hábito.

    SE MIRA LA MEJOR RACHA Y NO LA ACTUAL: una medalla ganada no se pierde
    porque la racha se corte después. Lo logrado, logrado está.
    """
    return [Medalla(habito_uid, habito, dias) for dias in hitos_hasta(mejor_racha)]


# ---------------------------------------------------------------------------
# Las tarjetas que se comparten
# ---------------------------------------------------------------------------
#
# CADA TARJETA ES LO QUE LLEVA LA IMAGEN: solo lo que eliges mostrar de ese
# logro, sacado de tus datos reales en el momento de compartir.


def tarjeta_entreno(
    nombre: str,
    segundos: int,
    series: int,
    volumen_centesimas: int,
    ejercicios: list[str],
    grupos: list[str],
) -> dict:
    """Un entreno terminado: qué trabajaste, cuánto y con qué."""
    return {
        "nombre": nombre or "Entreno",
        "segundos": int(segundos),
        "series": int(series),
        "volumen": int(volumen_centesimas),
        "ejercicios": list(ejercicios)[:12],
        "grupos": sorted(set(grupos)),
    }


def tarjeta_medalla(medalla: Medalla) -> dict:
    return {"habito": medalla.habito, "dias": medalla.dias}


def tarjeta_dia(numero: int, valoracion: int, reflexion: str, cumplidos: int, programados: int) -> dict:
    """El día cerrado: su número, cómo te fue, y lo que escribiste.

    LA REFLEXIÓN VA TAL CUAL: es lo que escribiste al cerrar el día. Si la
    dejas vacía, la tarjeta sale igual con el resto.
    """
    return {
        "numero": int(numero),
        "valoracion": int(valoracion),
        "reflexion": (reflexion or "").strip(),
        "cumplidos": int(cumplidos),
        "programados": int(programados),
    }


def _duracion(segundos: int) -> str:
    if segundos <= 0:
        return ""
    horas, resto = divmod(segundos // 60, 60)
    return f"{horas} h {resto:02d} min" if horas else f"{resto} min"


def _kilos(centesimas: int) -> str:
    kilos = centesimas / 100
    return f"{kilos:,.0f} kg".replace(",", ".")


def _enumerar(cosas: list[str]) -> str:
    """«pecho», «pecho y tríceps», «pecho, hombro y tríceps»: como se dice."""
    cosas = [str(una) for una in cosas]
    if len(cosas) <= 1:
        return "".join(cosas)
    return ", ".join(cosas[:-1]) + " y " + cosas[-1]


def lectura(tipo: str, datos: dict) -> tuple[str, list[str]]:
    """(título, renglones) para enseñar una tarjeta. Nunca lanza.

    NUNCA LANZA: una tarjeta rara se enseña a medias antes que dejar sin
    imagen al que la quiere compartir.
    """
    try:
        if tipo == "entreno":
            renglones = []
            if datos.get("grupos"):
                renglones.append("Trabajé " + _enumerar(datos["grupos"]))
            cifras = [
                _duracion(int(datos.get("segundos") or 0)),
                f"{int(datos.get('series') or 0)} series",
                _kilos(int(datos.get("volumen") or 0)) if datos.get("volumen") else "",
            ]
            renglones.append(" · ".join(uno for uno in cifras if uno))
            if datos.get("ejercicios"):
                renglones.append(", ".join(datos["ejercicios"]))
            return f"🏋️ {datos.get('nombre') or 'Entreno'}", renglones
        if tipo == "medalla":
            dias = int(datos.get("dias") or 0)
            return (
                f"🏅 Medalla de {nombre_del_hito(dias)}",
                [f"{dias} días seguidos de «{datos.get('habito', '')}»"],
            )
        if tipo == "dia":
            renglones = []
            if datos.get("programados"):
                renglones.append(
                    f"Cumplí {datos.get('cumplidos', 0)} de {datos['programados']} hábitos"
                )
            if datos.get("valoracion"):
                # DEL 1 AL 10, como se pide al cerrar el día (dialogo_cierre).
                renglones.append(f"Cómo me fue: {int(datos['valoracion'])}/10")
            if datos.get("reflexion"):
                renglones.append(str(datos["reflexion"]))
            return f"📓 Día {datos.get('numero', '')}", renglones
    except (KeyError, ValueError, TypeError, IndexError):
        pass
    return "Logro", []
