"""Cómo fue la semana y cómo fue el mes en Alimentación.

QUÉ RESUELVE: la pantalla de Alimentación enseña HOY. Eso vale para apuntar,
pero no para saber si estás comiendo lo que querías. Un día suelto no dice nada;
una semana sí.

UN DÍA SIN APUNTAR CUENTA COMO CERO, y lo decidió el usuario a sabiendas. Yo le
propuse dejar un hueco —un día sin apuntar no es un día de ayuno, y meterlo como
cero hunde los promedios— y me dijo esto:

    "contá lo que hice; si ese día no anoté sería como que no comí, 0.
     Justamente esa es la idea del gráfico mensual."

Y tiene su lógica: el gráfico no solo mide lo que comes, mide también si estás
siendo constante apuntando. Un mes lleno de ceros es un mes en el que no llevaste
la cuenta, y eso es justo lo que quiere ver.

AUN ASÍ SE GUARDA SI HUBO APUNTE O NO (`apuntado`), porque es un dato distinto de
"comí cero" y no cuesta nada tenerlo. La pantalla lo usa para poder decir cuántos
días de la semana llegaste a apuntar algo.

EL MES SE AGRUPA POR SEMANAS, no por días: treinta barras en un móvil de 375
puntos son diez puntos por barra, y de un mes lo que se quiere ver es si vas
subiendo o bajando, no el martes 14.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta

from .nutricion import NUTRIENTES, Totales, sumar

UN_DIA = timedelta(days=1)


@dataclass(frozen=True)
class DiaDeComida:
    """Lo comido en una jornada, y si llegaste a apuntar algo."""

    jornada: date
    totales: Totales = field(default_factory=Totales)

    apuntado: bool = False
    """Si ese día hubo al menos un registro.

    NO ES LO MISMO QUE "comió cero": son dos afirmaciones distintas y por eso se
    guardan aparte. El gráfico dibuja cero en los dos casos —así lo pidió el
    usuario— pero el resumen puede decir "apuntaste 4 de 7 días", que es una
    información útil que se perdería si solo se guardara el total.
    """

    def de(self, nutriente: str) -> int:
        return self.totales.de(nutriente)


@dataclass(frozen=True)
class SemanaDeComida:
    """El promedio de una semana, y de qué días se saca."""

    desde: date
    hasta: date
    promedios: Totales = field(default_factory=Totales)
    dias_apuntados: int = 0
    dias: int = 0

    numero: int = 1
    """La que es dentro del tramo: la primera del mes es la 1."""

    def de(self, nutriente: str) -> int:
        return self.promedios.de(nutriente)

    def etiqueta(self) -> str:
        """Cómo se llama esta semana debajo de su barra.

        SON DOS LINEAS: "S2" arriba y "3-9" abajo. Lo pidió el usuario, y con
        razón: antes ponía solo el día en que empezaba ("3 ago") y eso no dice ni
        qué semana es ni hasta cuándo llega. Con el número y el tramo se sabe las
        dos cosas de un vistazo.

        DOS LINEAS Y NO UNA porque en un móvil cada barra tiene unos 55 puntos de
        ancho, y "S2 3-9" de una tirada no cabe.

        UNA SEMANA DE UN SOLO DIA pone solo ese día ("1"), no "1-1", que se lee
        raro y no aporta nada.
        """
        if self.desde == self.hasta:
            tramo = str(self.desde.day)
        else:
            tramo = f"{self.desde.day}-{self.hasta.day}"
        return f"S{self.numero}\n{tramo}"


def dias_entre(desde: date, hasta: date) -> list[date]:
    """Todas las jornadas del tramo, las dos puntas incluidas.

    SALEN TODAS, tenga o no registros: el gráfico necesita una barra por día
    aunque valga cero, o los días se moverían de sitio según lo que hubieras
    apuntado y no se podría comparar una semana con otra.
    """
    if hasta < desde:
        raise ValueError(f"el tramo va al revés: de {desde} a {hasta}")
    cuantos = (hasta - desde).days + 1
    return [desde + UN_DIA * numero for numero in range(cuantos)]


def por_dia(registros, desde: date, hasta: date) -> list[DiaDeComida]:
    """Lo comido cada día del tramo, en orden."""
    agrupados: dict[date, list] = {}
    for registro in registros:
        agrupados.setdefault(registro.jornada, []).append(registro)

    dias = []
    for jornada in dias_entre(desde, hasta):
        del_dia = agrupados.get(jornada, [])
        dias.append(
            DiaDeComida(
                jornada=jornada,
                totales=sumar(del_dia),
                apuntado=bool(del_dia),
            )
        )
    return dias


def por_semana(dias: list[DiaDeComida]) -> list[SemanaDeComida]:
    """Los días agrupados en semanas, con el promedio de cada una.

    LAS SEMANAS EMPIEZAN EN LUNES, como en el resto de la aplicación. La primera
    y la última pueden salir cortas —el mes no empieza en lunes— y eso está bien:
    el promedio se hace sobre los días que tenga, no sobre siete siempre.

    EL PROMEDIO INCLUYE LOS DÍAS SIN APUNTAR como ceros, que es lo que pidió el
    usuario. Si una semana tiene tres días apuntados y cuatro en blanco, el
    promedio sale bajo a propósito.
    """
    if not dias:
        return []

    grupos: dict[date, list[DiaDeComida]] = {}
    for uno in dias:
        # El lunes de esa semana identifica al grupo.
        lunes = uno.jornada - UN_DIA * uno.jornada.weekday()
        grupos.setdefault(lunes, []).append(uno)

    semanas = []
    for numero, lunes in enumerate(sorted(grupos), start=1):
        del_grupo = grupos[lunes]
        cuantos = len(del_grupo)
        promedios = Totales(
            **{
                nutriente: sum(uno.de(nutriente) for uno in del_grupo) // cuantos
                for nutriente in NUTRIENTES
            }
        )
        semanas.append(
            SemanaDeComida(
                desde=del_grupo[0].jornada,
                hasta=del_grupo[-1].jornada,
                promedios=promedios,
                dias_apuntados=sum(1 for uno in del_grupo if uno.apuntado),
                dias=cuantos,
                numero=numero,
            )
        )
    return semanas


def promedio(dias: list[DiaDeComida]) -> Totales:
    """El promedio del tramo entero. Con los días en blanco contando como cero."""
    if not dias:
        return Totales()
    return Totales(
        **{
            nutriente: sum(uno.de(nutriente) for uno in dias) // len(dias)
            for nutriente in NUTRIENTES
        }
    )


def semana_de(jornada: date) -> tuple[date, date]:
    """El lunes y el domingo de la semana en que cae esa jornada."""
    lunes = jornada - UN_DIA * jornada.weekday()
    return lunes, lunes + UN_DIA * 6


def mes_de(jornada: date) -> tuple[date, date]:
    """El primer y el último día del mes en que cae esa jornada."""
    primero = jornada.replace(day=1)
    if primero.month == 12:
        siguiente = primero.replace(year=primero.year + 1, month=1)
    else:
        siguiente = primero.replace(month=primero.month + 1)
    return primero, siguiente - UN_DIA
