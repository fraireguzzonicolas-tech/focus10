"""La sesión: LO QUE HICE DE VERDAD un día concreto, serie a serie.

LA SESIÓN NACE DE LA RUTINA Y SE INDEPENDIZA EN EL ACTO. `desde_rutina` COPIA los
valores del plan como sugerencia; a partir de ahí, todo lo que se toque en la
sesión se queda en la sesión. Cambiar el peso un mal día no reescribe el plan.

Es la decisión que pidió el usuario antes de escribir una línea, y la que hace
que la aplicación sirva para algo: con el plan y lo ejecutado separados se puede
saber si cumpliste; mezclados, no hay contra qué comparar.

EL VOLUMEN SOLO CUENTA LAS SERIES HECHAS. Una serie escrita y no marcada es una
intención, y sumarla diría que levantaste un peso que no levantaste.

NADA DE ESTIMACIONES. No hay 1RM teórico, ni "deberías levantar", ni progresión
sugerida. Lo pidió expresamente y además es la regla de toda la aplicación: se
enseña lo que se hizo.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field, replace
from datetime import date, datetime

from .descanso import DESCANSO_MAXIMO, DESCANSO_MINIMO
from .rutina import (
    PESO_MAXIMO,
    REPETICIONES_MAXIMAS,
    SERIES_MAXIMAS,
    DiaDeRutina,
    texto_peso,
)
from .validar import exigir_entero

RPE_MINIMO = 1
RPE_MAXIMO = 10
SEGUNDOS_MAXIMOS = 4 * 60 * 60


@dataclass(frozen=True)
class Serie:
    """Una serie. Una fila de la pantalla que se usa de pie."""

    numero: int
    """1, 2, 3... Se enseña tal cual."""

    peso: int = 0
    """En centésimas de kilo."""

    repeticiones: int = 0
    hecha: bool = False
    """Sin marcar, la serie NO cuenta para el volumen."""

    rpe: int | None = None
    """Del 1 al 10, opcional."""

    al_fallo: bool = False
    segundos: int = 0
    """Para los ejercicios de tiempo: plancha, cardio."""

    id: int | None = None

    def __post_init__(self) -> None:
        exigir_entero("numero", self.numero)
        if not 1 <= self.numero <= SERIES_MAXIMAS:
            raise ValueError(f"el número de serie va de 1 a {SERIES_MAXIMAS}")

        exigir_entero("peso", self.peso)
        if not 0 <= self.peso <= PESO_MAXIMO:
            raise ValueError("ese peso no es razonable")

        exigir_entero("repeticiones", self.repeticiones)
        if not 0 <= self.repeticiones <= REPETICIONES_MAXIMAS:
            raise ValueError(f"las repeticiones van de 0 a {REPETICIONES_MAXIMAS}")

        exigir_entero("segundos", self.segundos)
        if not 0 <= self.segundos <= SEGUNDOS_MAXIMOS:
            raise ValueError("esos segundos no son razonables")

        if not isinstance(self.hecha, bool):
            raise TypeError("hecha tiene que ser True o False")
        if not isinstance(self.al_fallo, bool):
            raise TypeError("al_fallo tiene que ser True o False")

        if self.rpe is not None:
            exigir_entero("rpe", self.rpe)
            if not RPE_MINIMO <= self.rpe <= RPE_MAXIMO:
                raise ValueError(f"el RPE va de {RPE_MINIMO} a {RPE_MAXIMO}")

    @property
    def volumen(self) -> int:
        """Peso × repeticiones, en centésimas de kilo. Cero si no está hecha."""
        return self.peso * self.repeticiones if self.hecha else 0

    def texto(self) -> str:
        """"65 kg × 8". Lo que se enseña como "la última vez"."""
        if self.segundos:
            return f"{self.segundos} s"
        return f"{texto_peso(self.peso)} × {self.repeticiones}"


@dataclass(frozen=True)
class EjercicioDeSesion:
    """Un ejercicio dentro de un entreno, con sus series."""

    ejercicio_id: int | None
    """None si el ejercicio se borró de la biblioteca. El nombre sigue estando."""

    nombre: str
    """SE GUARDA AQUÍ, no solo la referencia. Es lo que permite leer un entreno de
    hace dos años aunque hoy se limpie la biblioteca."""

    orden: int = 0
    series: tuple[Serie, ...] = field(default_factory=tuple)

    descanso: int | None = None
    """Segundos de descanso, COPIADOS del plan al empezar el entreno.

    SE COPIA Y NO SE CONSULTA, igual que el peso y las repeticiones. Si se fuera
    a buscar al plan cada vez, cambiar la rutina en noviembre cambiaria tambien
    el descanso de un entreno de agosto; y un entreno suelto, que no tiene plan
    detras, se quedaria sin ningun descanso que consultar.

    None quiere decir que ahi no se dijo nada, y quien lo use cae al de la ficha
    del ejercicio.
    """

    id: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.nombre, str) or not self.nombre.strip():
            raise ValueError("el nombre del ejercicio no puede estar vacío")
        object.__setattr__(self, "nombre", self.nombre.strip())
        if self.ejercicio_id is not None:
            exigir_entero("ejercicio_id", self.ejercicio_id)
        exigir_entero("orden", self.orden)
        if not isinstance(self.series, tuple):
            raise TypeError("las series tienen que venir en una tupla")
        if self.descanso is not None:
            exigir_entero("descanso", self.descanso)
            if not DESCANSO_MINIMO <= self.descanso <= DESCANSO_MAXIMO:
                raise ValueError(
                    f"el descanso va de {DESCANSO_MINIMO} a {DESCANSO_MAXIMO} "
                    "segundos"
                )

    @property
    def volumen(self) -> int:
        return sum(una.volumen for una in self.series)

    @property
    def hechas(self) -> int:
        return sum(1 for una in self.series if una.hecha)

    @property
    def esta_completo(self) -> bool:
        return bool(self.series) and all(una.hecha for una in self.series)

    def serie(self, numero: int) -> Serie | None:
        return next((una for una in self.series if una.numero == numero), None)


@dataclass(frozen=True)
class Sesion:
    """Un entreno de un día concreto."""

    fecha: date
    nombre: str = ""
    color: str = "azul"
    ejercicios: tuple[EjercicioDeSesion, ...] = field(default_factory=tuple)
    id: int | None = None

    empezada_en: datetime | None = None
    """Cuando se pulso "Empezar". None en los entrenos de antes del cronometro.

    SE GUARDA LA HORA Y NO UN CONTADOR: un contador solo avanza mientras la
    aplicacion esta abierta, y un entreno se hace con el movil en el bolsillo.
    Asi el tiempo se calcula al mirarlo y cerrar la aplicacion no pierde nada.
    """

    segundos: int = 0
    """Lo que duro, congelado al terminar. Cero mientras sigue en marcha.

    HACE FALTA ADEMAS DE LA HORA DE INICIO: sin esto, el tiempo de un entreno de
    hace un mes seguiria creciendo cada vez que lo abrieras.
    """

    def __post_init__(self) -> None:
        if not isinstance(self.fecha, date):
            raise TypeError("la fecha tiene que ser un date")
        if not isinstance(self.nombre, str):
            raise TypeError("el nombre tiene que ser texto")
        object.__setattr__(self, "nombre", self.nombre.strip())
        if not isinstance(self.ejercicios, tuple):
            raise TypeError("los ejercicios tienen que venir en una tupla")
        if self.empezada_en is not None:
            if not isinstance(self.empezada_en, datetime):
                raise TypeError("empezada_en tiene que ser un datetime")
            # SE REDONDEA AL SEGUNDO AQUI Y NO EN QUIEN LLAMA. La base guarda
            # las horas al segundo, y `datetime.now()` trae microsegundos: sin
            # esto, empezar un entreno reventaba al guardarlo. Puesto en el
            # dominio, vale para todos los sitios que creen una sesion, incluidos
            # los que se escriban manana.
            object.__setattr__(
                self, "empezada_en", self.empezada_en.replace(microsecond=0)
            )
        if not isinstance(self.segundos, int) or isinstance(self.segundos, bool):
            raise TypeError("los segundos tienen que ser un entero")
        if self.segundos < 0:
            raise ValueError("un entreno no puede durar menos de nada")

    @property
    def en_marcha(self) -> bool:
        """Si el cronometro sigue corriendo."""
        return self.empezada_en is not None and self.segundos == 0

    def duracion(self, ahora: datetime) -> int:
        """Cuantos segundos lleva o cuanto duro. Cero si no se sabe.

        CERO ES "no se sabe" Y SE ENSENA COMO UN HUECO, no como "0 minutos": los
        entrenos de antes de que existiera el cronometro no tienen hora de
        inicio, y ponerles un cero seria inventarse que duraron nada.

        NUNCA DEVUELVE UN NUMERO NEGATIVO. Si el reloj del aparato se atrasa a
        mitad del entreno —cambio de hora, ajuste automatico—, el calculo daria
        negativo y se veria "llevas -47 minutos". Se corta en cero.
        """
        if self.segundos:
            return self.segundos
        if self.empezada_en is None:
            return 0
        return max(0, int((ahora - self.empezada_en).total_seconds()))

    @property
    def volumen(self) -> int:
        """Suma del peso × repeticiones de las series HECHAS. En centésimas."""
        return sum(uno.volumen for uno in self.ejercicios)

    @property
    def series_hechas(self) -> int:
        return sum(uno.hechas for uno in self.ejercicios)

    @property
    def mejor_peso(self) -> int:
        """El peso más alto que se movió, en centésimas. Cero si no se movió.

        SOLO CUENTAN LAS SERIES HECHAS: el plan de levantar 100 kg no es
        haberlos levantado.
        """
        pesos = [
            una.peso
            for uno in self.ejercicios
            for una in uno.series
            if una.hecha
        ]
        return max(pesos) if pesos else 0

    @property
    def entrenado(self) -> bool:
        """Si cuenta como "fui". Con al menos una serie marcada.

        Abrir el entreno y no hacer nada NO cuenta: si contara, el calendario se
        llenaría de checks de días que solo se miraron.
        """
        return self.series_hechas > 0

    def titulo(self) -> str:
        return self.nombre or "Entreno"


def desde_rutina(dia: DiaDeRutina, fecha: date) -> Sesion:
    """Crea la sesión de un día COPIANDO los valores de la rutina.

    ES UNA COPIA, no una referencia. Lo que se toque luego en la sesión no llega
    a la rutina: es la separación que pidió el usuario y la razón de que esta
    función exista en vez de que la pantalla lea la rutina directamente.

    Las series vienen con el peso y las repeticiones del plan ya puestos, pero
    SIN MARCAR. Marcarlas de antemano diría que las hiciste antes de empezar.
    """
    if not isinstance(dia, DiaDeRutina):
        raise TypeError("hace falta un DiaDeRutina")
    if not isinstance(fecha, date):
        raise TypeError("la fecha tiene que ser un date")

    ejercicios = tuple(
        EjercicioDeSesion(
            ejercicio_id=planeado.ejercicio_id,
            nombre=planeado.nombre,
            orden=numero,
            descanso=planeado.descanso,
            series=tuple(
                Serie(
                    numero=cual,
                    peso=planeado.peso_objetivo,
                    repeticiones=planeado.repeticiones_objetivo,
                    # LA DURACION TAMBIEN SE COPIA, como todo lo demas. Sin
                    # esto, empezar el entreno de una caminata dejaba las series
                    # a cero segundos y habia que reescribir el tiempo cada dia.
                    segundos=planeado.segundos_objetivo or 0,
                    hecha=False,
                )
                for cual in range(1, planeado.series_objetivo + 1)
            ),
        )
        for numero, planeado in enumerate(
            sorted(dia.ejercicios, key=lambda uno: uno.orden)
        )
    )
    return Sesion(
        fecha=fecha, nombre=dia.titulo(), color=dia.color, ejercicios=ejercicios
    )


# ---------------------------------------------------------------------------
# Progreso: lo que se hizo, y nada más
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Marca:
    """La mejor serie de un ejercicio, y cuándo fue."""

    peso: int
    repeticiones: int
    fecha: date

    def texto(self) -> str:
        return f"{texto_peso(self.peso)} × {self.repeticiones}"


def mejor_marca(historial: Iterable[tuple[date, EjercicioDeSesion]]) -> Marca | None:
    """La mejor serie hecha de ese ejercicio en todo el historial.

    MEJOR ES MÁS PESO, y a igual peso, más repeticiones. No se calcula ningún
    "1RM teórico" para comparar: lo pidió expresamente el usuario, y además esa
    fórmula es una estimación, o sea justo lo que esta aplicación no enseña.

    Solo cuentan las series HECHAS: una escrita y no marcada no es una marca.
    """
    mejor: Marca | None = None
    for fecha, ejercicio in historial:
        for serie in ejercicio.series:
            if not serie.hecha or not serie.peso:
                continue
            candidata = Marca(
                peso=serie.peso, repeticiones=serie.repeticiones, fecha=fecha
            )
            if mejor is None or (candidata.peso, candidata.repeticiones) > (
                mejor.peso,
                mejor.repeticiones,
            ):
                mejor = candidata
    return mejor


def peso_maximo_por_mes(
    historial: Iterable[tuple[date, EjercicioDeSesion]],
) -> list[tuple[date, int]]:
    """El peso más alto de cada mes, para la gráfica de progreso.

    Por mes y no por día porque la gráfica de un año con un punto por sesión es
    ilegible, y porque lo que se mira es la tendencia, no el martes concreto.
    """
    por_mes: dict[date, int] = {}
    for fecha, ejercicio in historial:
        primero = fecha.replace(day=1)
        for serie in ejercicio.series:
            if serie.hecha and serie.peso:
                por_mes[primero] = max(por_mes.get(primero, 0), serie.peso)
    return [(mes, por_mes[mes]) for mes in sorted(por_mes)]


def volumen_por_semana(sesiones: Iterable[Sesion]) -> list[tuple[date, int]]:
    """El volumen de cada semana, con la fecha del lunes. Para la vista general."""
    from datetime import timedelta

    por_semana: dict[date, int] = {}
    for sesion in sesiones:
        lunes = sesion.fecha - timedelta(days=sesion.fecha.weekday())
        por_semana[lunes] = por_semana.get(lunes, 0) + sesion.volumen
    return [(lunes, por_semana[lunes]) for lunes in sorted(por_semana)]


def series_por_grupo(
    sesiones: Iterable[Sesion], grupos: dict[int, str]
) -> dict[str, int]:
    """Cuántas series hechas por grupo muscular. Para ver qué se descuida.

    Se cuentan SERIES y no sesiones: entrenar espalda una vez con nueve series no
    es lo mismo que tocarla de pasada con una, y contando sesiones las dos cosas
    valdrían igual.

    Los ejercicios borrados de la biblioteca no tienen grupo, así que no se
    cuentan. Se dice aparte en la pantalla en vez de repartirlos a ojo.
    """
    cuenta: dict[str, int] = {}
    for sesion in sesiones:
        for ejercicio in sesion.ejercicios:
            grupo = grupos.get(ejercicio.ejercicio_id) if ejercicio.ejercicio_id else None
            if grupo is None:
                continue
            cuenta[grupo] = cuenta.get(grupo, 0) + ejercicio.hechas
    return cuenta


def texto_volumen(centesimas: int) -> str:
    """"12.450 kg". El volumen se lee en kilos enteros: los decimales aquí no
    dicen nada y estorban para comparar semanas de un vistazo."""
    from .rutina import CENTESIMAS_POR_KILO

    kilos = centesimas // CENTESIMAS_POR_KILO
    return f"{kilos:,}".replace(",", ".") + " kg"


def con_serie(
    ejercicio: EjercicioDeSesion, numero: int, **cambios
) -> EjercicioDeSesion:
    """Devuelve el ejercicio con una serie cambiada. No toca el original."""
    series = tuple(
        replace(una, **cambios) if una.numero == numero else una
        for una in ejercicio.series
    )
    return replace(ejercicio, series=series)


def anadir_serie(ejercicio: EjercicioDeSesion) -> EjercicioDeSesion:
    """Una serie extra, copiando el peso y las repeticiones de la última.

    Se copia porque una serie extra casi siempre es "otra igual", y empezar con
    ceros obligaría a reescribirlo todo de pie en el gimnasio.
    """
    if len(ejercicio.series) >= SERIES_MAXIMAS:
        return ejercicio
    ultima = ejercicio.series[-1] if ejercicio.series else None
    nueva = Serie(
        numero=len(ejercicio.series) + 1,
        peso=ultima.peso if ultima else 0,
        repeticiones=ultima.repeticiones if ultima else 0,
        hecha=False,
    )
    return replace(ejercicio, series=(*ejercicio.series, nueva))


def quitar_serie(ejercicio: EjercicioDeSesion, numero: int) -> EjercicioDeSesion:
    """Quita una serie y renumera las que quedan.

    Renumerar hace falta: sin ello, quitar la 2 de tres series dejaría la 1 y la
    3, y "la última vez" compararía la serie 3 de hoy con la 3 de otro día que
    fue la segunda de verdad.
    """
    quedan = [una for una in ejercicio.series if una.numero != numero]
    renumeradas = tuple(
        replace(una, numero=indice) for indice, una in enumerate(quedan, start=1)
    )
    return replace(ejercicio, series=renumeradas)

