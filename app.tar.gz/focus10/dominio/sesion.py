"""La sesión: LO QUE HICE DE VERDAD un día concreto, serie a serie.

LA SESIÓN NACE DE LA RUTINA Y SE INDEPENDIZA EN EL ACTO. `desde_rutina` COPIA los
valores del plan como sugerencia; a partir de ahí, todo lo que se toque en la
sesión se queda en la sesión. Cambiar el peso un mal día no reescribe el plan.

Es la decisión que pidió el usuario antes de escribir una línea, y la que hace
que la aplicación sirva para algo: con el plan y lo ejecutado separados se puede
saber si cumpliste; mezclados, no hay contra qué comparar.

EL VOLUMEN SOLO CUENTA LAS SERIES HECHAS. Una serie escrita y no marcada es una
intención, y sumarla diría que levantaste un peso que no levantaste.

NADA DE ESTIMACIONES. No hay 1RM teórico, ni "deberías levantar", ni progresión
sugerida. Lo pidió expresamente y además es la regla de toda la aplicación: se
enseña lo que se hizo.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field, replace
from datetime import date, datetime
from enum import Enum

from .descanso import DESCANSO_MAXIMO, DESCANSO_MINIMO
from .ejercicio import Unidad
from .rutina import (
    BloqueDeRutina,
    PESO_MAXIMO,
    REPETICIONES_MAXIMAS,
    SERIES_MAXIMAS,
    DiaDeRutina,
    texto_peso,
)
from .validar import exigir_entero

class TipoSerie(Enum):
    """Qué clase de serie es. Se elige tocando su número (un menú, en este orden).

    LO PIDIÓ EL USUARIO: «al tocar el número de la serie se debe poder cambiar
    a fallo, recuperación, drop set, calentamiento, todas con una letra
    representativa y un color». Primero daba la vuelta tocando; después pidió
    un menú como el de otra aplicación (30 oct 2026).

    EL CALENTAMIENTO NO CUENTA para el volumen ni para las marcas: es una serie
    liviana para preparar, y sumarla diría que entrenaste más de lo que entrenaste.
    """

    NORMAL = "normal"
    FALLO = "fallo"
    RECUPERACION = "recuperacion"
    DROP = "drop"
    CALENTAMIENTO = "calentamiento"

    @property
    def letra(self) -> str:
        return _LETRAS[self]

    @property
    def nombre(self) -> str:
        return _NOMBRES[self]


_LETRAS = {
    TipoSerie.NORMAL: "", TipoSerie.FALLO: "F", TipoSerie.RECUPERACION: "R",
    TipoSerie.DROP: "D", TipoSerie.CALENTAMIENTO: "C",
}
_NOMBRES = {
    TipoSerie.NORMAL: "Normal", TipoSerie.FALLO: "Al fallo",
    TipoSerie.RECUPERACION: "Recuperación", TipoSerie.DROP: "Drop set",
    TipoSerie.CALENTAMIENTO: "Calentamiento",
}

NOTA_MAXIMA = 300
"""Letras de la nota de un ejercicio: para un recordatorio, no para un diario."""

RPE_MINIMO = 1
RPE_MAXIMO = 10
SEGUNDOS_MAXIMOS = 4 * 60 * 60
METROS_MAXIMOS = 100_000
"""Cien kilómetros: el mismo tope que pone la base (migración 40)."""


@dataclass(frozen=True)
class Serie:
    """Una serie. Una fila de la pantalla que se usa de pie."""

    numero: int
    """1, 2, 3... Se enseña tal cual."""

    peso: int = 0
    """En centésimas de kilo."""

    repeticiones: int = 0
    hecha: bool = False
    """Sin marcar, la serie NO cuenta para el volumen."""

    rpe: int | None = None
    """Del 1 al 10, opcional."""

    tipo: TipoSerie = TipoSerie.NORMAL
    segundos: int = 0
    """Para los ejercicios de tiempo (plancha, cardio) y los de peso que cuentan
    segundos en vez de repeticiones (ver `Unidad`)."""

    id: int | None = None

    metros: int = 0
    """Para los de peso que cuentan metros: el paseo del granjero."""

    def __post_init__(self) -> None:
        exigir_entero("numero", self.numero)
        if not 1 <= self.numero <= SERIES_MAXIMAS:
            raise ValueError(f"el número de serie va de 1 a {SERIES_MAXIMAS}")

        exigir_entero("peso", self.peso)
        if not 0 <= self.peso <= PESO_MAXIMO:
            raise ValueError("ese peso no es razonable")

        exigir_entero("repeticiones", self.repeticiones)
        if not 0 <= self.repeticiones <= REPETICIONES_MAXIMAS:
            raise ValueError(f"las repeticiones van de 0 a {REPETICIONES_MAXIMAS}")

        exigir_entero("segundos", self.segundos)
        if not 0 <= self.segundos <= SEGUNDOS_MAXIMOS:
            raise ValueError("esos segundos no son razonables")

        exigir_entero("metros", self.metros)
        if not 0 <= self.metros <= METROS_MAXIMOS:
            raise ValueError("esos metros no son razonables")

        if not isinstance(self.hecha, bool):
            raise TypeError("hecha tiene que ser True o False")
        if not isinstance(self.tipo, TipoSerie):
            raise TypeError("el tipo tiene que ser un TipoSerie")

        if self.rpe is not None:
            exigir_entero("rpe", self.rpe)
            if not RPE_MINIMO <= self.rpe <= RPE_MAXIMO:
                raise ValueError(f"el RPE va de {RPE_MINIMO} a {RPE_MAXIMO}")

    @property
    def cuenta(self) -> bool:
        """Si cuenta como entrenada: hecha, y no de calentamiento."""
        return self.hecha and self.tipo is not TipoSerie.CALENTAMIENTO

    @property
    def volumen(self) -> int:
        """Peso × repeticiones, en centésimas de kilo. Cero si no cuenta."""
        return self.peso * self.repeticiones if self.cuenta else 0

    @property
    def unidad(self) -> Unidad:
        """En qué se contó, SEGÚN LO GUARDADO y no según la ficha: una serie de
        hace un mes sigue en repeticiones aunque hoy el ejercicio cuente metros."""
        if self.metros:
            return Unidad.METROS
        if self.segundos:
            return Unidad.SEGUNDOS
        return Unidad.REPS

    @property
    def cantidad(self) -> int:
        """Las repeticiones, los segundos o los metros: lo que va con los kilos."""
        return {Unidad.METROS: self.metros, Unidad.SEGUNDOS: self.segundos}.get(
            self.unidad, self.repeticiones
        )

    def texto(self) -> str:
        """"65 kg × 8", "30 kg × 40 m", "45 s". Lo que se enseña como "la última vez"."""
        return texto_de_serie(self.peso, self.unidad, self.cantidad)


def texto_cantidad(unidad: Unidad, cantidad: int) -> str:
    """«10», «40 m», «45 s»: lo que va con los kilos, con su unidad si no son reps."""
    if unidad is Unidad.METROS:
        return f"{cantidad} m"
    if unidad is Unidad.SEGUNDOS:
        return f"{cantidad} s"
    return str(cantidad)


def texto_de_serie(peso: int, unidad: Unidad, cantidad: int) -> str:
    """Una serie en palabras. Junto para la serie y para la marca, que se leen igual."""
    detras = texto_cantidad(unidad, cantidad)
    # SIN KILOS NO SE ESCRIBEN: «0 kg × 0:45» de una plancha no dice nada.
    if not peso and unidad is not Unidad.REPS:
        return detras
    return f"{texto_peso(peso)} × {detras}"


@dataclass(frozen=True)
class EjercicioDeSesion:
    """Un ejercicio dentro de un entreno, con sus series."""

    ejercicio_id: int | None
    """None si el ejercicio se borró de la biblioteca. El nombre sigue estando."""

    nombre: str
    """SE GUARDA AQUÍ, no solo la referencia. Es lo que permite leer un entreno de
    hace dos años aunque hoy se limpie la biblioteca."""

    orden: int = 0
    series: tuple[Serie, ...] = field(default_factory=tuple)

    descanso: int | None = None
    """Segundos de descanso, COPIADOS del plan al empezar el entreno.

    SE COPIA Y NO SE CONSULTA, igual que el peso y las repeticiones. Si se fuera
    a buscar al plan cada vez, cambiar la rutina en noviembre cambiaria tambien
    el descanso de un entreno de agosto; y un entreno suelto, que no tiene plan
    detras, se quedaria sin ningun descanso que consultar.

    None quiere decir que ahi no se dijo nada, y quien lo use cae al de la ficha
    del ejercicio.
    """

    nota: str = ""
    """«Usar banco 3», «agarre más cerrado». LO PIDIÓ EL USUARIO, y que «se vea
    la próxima vez»: al empezar, se copia la última nota de ese ejercicio."""

    id: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.nombre, str) or not self.nombre.strip():
            raise ValueError("el nombre del ejercicio no puede estar vacío")
        if not isinstance(self.nota, str) or len(self.nota) > NOTA_MAXIMA:
            raise ValueError(f"la nota va hasta {NOTA_MAXIMA} letras")
        object.__setattr__(self, "nota", self.nota.strip())
        object.__setattr__(self, "nombre", self.nombre.strip())
        if self.ejercicio_id is not None:
            exigir_entero("ejercicio_id", self.ejercicio_id)
        exigir_entero("orden", self.orden)
        if not isinstance(self.series, tuple):
            raise TypeError("las series tienen que venir en una tupla")
        if self.descanso is not None:
            exigir_entero("descanso", self.descanso)
            if not DESCANSO_MINIMO <= self.descanso <= DESCANSO_MAXIMO:
                raise ValueError(
                    f"el descanso va de {DESCANSO_MINIMO} a {DESCANSO_MAXIMO} "
                    "segundos"
                )

    @property
    def volumen(self) -> int:
        return sum(una.volumen for una in self.series)

    @property
    def hechas(self) -> int:
        return sum(1 for una in self.series if una.hecha)

    @property
    def esta_completo(self) -> bool:
        return bool(self.series) and all(una.hecha for una in self.series)

    def serie(self, numero: int) -> Serie | None:
        return next((una for una in self.series if una.numero == numero), None)


@dataclass(frozen=True)
class Sesion:
    """Un entreno de un día concreto."""

    fecha: date
    nombre: str = ""
    color: str = "azul"
    ejercicios: tuple[EjercicioDeSesion, ...] = field(default_factory=tuple)
    id: int | None = None

    bloque: str = ""
    """De qué bloque de la rutina es («GYM», «Movilidad»). LO PIDIÓ EL USUARIO:
    si un día tiene dos, se empieza uno y después el otro, cada uno con su
    reloj y su resumen. Vacío en los entrenos de antes (eran el día entero)."""

    empezada_en: datetime | None = None
    """Cuando se pulso "Empezar". None en los entrenos de antes del cronometro.

    SE GUARDA LA HORA Y NO UN CONTADOR: un contador solo avanza mientras la
    aplicacion esta abierta, y un entreno se hace con el movil en el bolsillo.
    Asi el tiempo se calcula al mirarlo y cerrar la aplicacion no pierde nada.
    """

    segundos: int = 0
    """Lo que duro, congelado al terminar. Cero mientras sigue en marcha.

    HACE FALTA ADEMAS DE LA HORA DE INICIO: sin esto, el tiempo de un entreno de
    hace un mes seguiria creciendo cada vez que lo abrieras.
    """

    def __post_init__(self) -> None:
        if not isinstance(self.fecha, date):
            raise TypeError("la fecha tiene que ser un date")
        if not isinstance(self.nombre, str):
            raise TypeError("el nombre tiene que ser texto")
        object.__setattr__(self, "nombre", self.nombre.strip())
        if not isinstance(self.bloque, str) or len(self.bloque.strip()) > 40:
            raise ValueError("el bloque va hasta 40 letras")
        object.__setattr__(self, "bloque", self.bloque.strip())
        if not isinstance(self.ejercicios, tuple):
            raise TypeError("los ejercicios tienen que venir en una tupla")
        if self.empezada_en is not None:
            if not isinstance(self.empezada_en, datetime):
                raise TypeError("empezada_en tiene que ser un datetime")
            # SE REDONDEA AL SEGUNDO AQUI Y NO EN QUIEN LLAMA. La base guarda
            # las horas al segundo, y `datetime.now()` trae microsegundos: sin
            # esto, empezar un entreno reventaba al guardarlo. Puesto en el
            # dominio, vale para todos los sitios que creen una sesion, incluidos
            # los que se escriban manana.
            object.__setattr__(
                self, "empezada_en", self.empezada_en.replace(microsecond=0)
            )
        if not isinstance(self.segundos, int) or isinstance(self.segundos, bool):
            raise TypeError("los segundos tienen que ser un entero")
        if self.segundos < 0:
            raise ValueError("un entreno no puede durar menos de nada")

    @property
    def en_marcha(self) -> bool:
        """Si el cronometro sigue corriendo."""
        return self.empezada_en is not None and self.segundos == 0

    def duracion(self, ahora: datetime) -> int:
        """Cuantos segundos lleva o cuanto duro. Cero si no se sabe.

        CERO ES "no se sabe" Y SE ENSENA COMO UN HUECO, no como "0 minutos": los
        entrenos de antes de que existiera el cronometro no tienen hora de
        inicio, y ponerles un cero seria inventarse que duraron nada.

        NUNCA DEVUELVE UN NUMERO NEGATIVO. Si el reloj del aparato se atrasa a
        mitad del entreno —cambio de hora, ajuste automatico—, el calculo daria
        negativo y se veria "llevas -47 minutos". Se corta en cero.
        """
        if self.segundos:
            return self.segundos
        if self.empezada_en is None:
            return 0
        return max(0, int((ahora - self.empezada_en).total_seconds()))

    @property
    def volumen(self) -> int:
        """Suma del peso × repeticiones de las series HECHAS. En centésimas."""
        return sum(uno.volumen for uno in self.ejercicios)

    @property
    def series_hechas(self) -> int:
        return sum(uno.hechas for uno in self.ejercicios)

    @property
    def mejor_peso(self) -> int:
        """El peso más alto que se movió, en centésimas. Cero si no se movió.

        SOLO CUENTAN LAS SERIES HECHAS: el plan de levantar 100 kg no es
        haberlos levantado.
        """
        pesos = [
            una.peso
            for uno in self.ejercicios
            for una in uno.series
            if una.cuenta
        ]
        return max(pesos) if pesos else 0

    @property
    def entrenado(self) -> bool:
        """Si cuenta como "fui". Con al menos una serie marcada.

        Abrir el entreno y no hacer nada NO cuenta: si contara, el calendario se
        llenaría de checks de días que solo se miraron.
        """
        return self.series_hechas > 0

    def titulo(self) -> str:
        """«Pecho · GYM» si es un bloque de un día con nombre; si no, lo que haya."""
        if self.bloque and self.nombre and self.nombre != self.bloque:
            return f"{self.nombre} · {self.bloque}"
        return self.bloque or self.nombre or "Entreno"


def sugerida(
    reales: tuple[Serie, ...] | None,
    numero: int,
    *,
    peso: int = 0,
    repeticiones: int = 0,
    segundos: int = 0,
) -> Serie:
    """La serie `numero` de hoy, rellena con lo último REAL de ese ejercicio.

    LO PIDIÓ EL USUARIO: «la rutina tiene que ser una referencia dinámica basada
    en mi rendimiento real, no una plantilla que vuelve a sus valores iniciales
    cada semana». Semana 1, 26 kg × 10; semana 2 aparece 26 × 10; si ese día
    hace 28 × 8, la semana 3 aparece 28 × 8.

    SERIE POR SERIE: la 1 de hoy con la 1 de la última vez, la 2 con la 2. Si
    la última vez hiciste menos series, las que faltan copian la última que
    hiciste. Sin nada real, lo del plan (los argumentos).

    `reales` SON SOLO LAS SERIES MARCADAS: una escrita y sin marcar es una
    intención, no un resultado (la misma regla que el volumen).

    SIN MARCAR, siempre: marcarla de antemano diría que ya la hiciste.
    """
    if reales:
        vieja = reales[numero - 1] if numero <= len(reales) else reales[-1]
        # EL TIPO TAMBIÉN: si la 1 fue de calentamiento, la 1 de hoy también.
        return Serie(
            numero=numero, peso=vieja.peso, repeticiones=vieja.repeticiones,
            segundos=vieja.segundos, metros=vieja.metros, tipo=vieja.tipo,
        )
    return Serie(numero=numero, peso=peso, repeticiones=repeticiones, segundos=segundos)


def desde_rutina(
    dia: DiaDeRutina,
    fecha: date,
    reales: Mapping[int, tuple[Serie, ...]] | None = None,
    bloque: BloqueDeRutina | None = None,
) -> Sesion:
    """Crea la sesión de un día con la rutina, rellena con lo último real.

    ES UNA COPIA, no una referencia. Lo que se toque luego en la sesión no llega
    a la rutina: es la separación que pidió el usuario y la razón de que esta
    función exista en vez de que la pantalla lea la rutina directamente.

    DE LA RUTINA SALEN QUÉ EJERCICIOS, CUÁNTAS SERIES Y EL DESCANSO. Los kilos
    y las repeticiones salen de `reales` (ejercicio -> sus últimas series
    marcadas, ver `sugerida`); solo si un ejercicio no tiene historial se usan
    los del plan.

    `bloque`: SOLO ESE BLOQUE del día (lo pidió el usuario: uno por vez). Sin
    él, el día entero, como antes de que hubiera bloques.
    """
    if not isinstance(dia, DiaDeRutina):
        raise TypeError("hace falta un DiaDeRutina")
    if not isinstance(fecha, date):
        raise TypeError("la fecha tiene que ser un date")
    reales = reales or {}

    ejercicios = tuple(
        EjercicioDeSesion(
            ejercicio_id=planeado.ejercicio_id,
            nombre=planeado.nombre,
            orden=numero,
            descanso=planeado.descanso,
            # SIN HISTORIAL, EL PLAN SERIE POR SERIE (12, 10, 8…) y no solo su
            # primera serie repetida: la rutina guarda cada una con lo suyo.
            series=tuple(
                sugerida(
                    reales.get(planeado.ejercicio_id),
                    cual,
                    peso=plan.peso,
                    repeticiones=plan.repeticiones,
                    # LA DURACION TAMBIEN SE COPIA, como todo lo demas. Sin
                    # esto, empezar el entreno de una caminata dejaba las series
                    # a cero segundos y habia que reescribir el tiempo cada dia.
                    segundos=plan.segundos or 0,
                )
                for cual, plan in enumerate(planeado.series, start=1)
            ),
        )
        for numero, planeado in enumerate(
            sorted(dia.ejercicios if bloque is None else bloque.ejercicios, key=lambda uno: uno.orden)
        )
    )
    return Sesion(
        fecha=fecha, nombre=dia.titulo(), color=dia.color, ejercicios=ejercicios,
        bloque="" if bloque is None else bloque.nombre,
    )


def en_unidad(serie: Serie, unidad: Unidad) -> Serie:
    """La serie con SOLO la cantidad de esa unidad; las otras dos, a cero.

    POR QUÉ HACE FALTA: lo de la última vez puede venir en otra unidad (el
    paseo del granjero hecho en reps la semana pasada y hoy en metros). Si las
    10 reps se quedaran escondidas detrás de la casilla de metros, seguirían
    sumando volumen y repeticiones que hoy no hiciste. Los kilos no se tocan.
    """
    return replace(
        serie,
        repeticiones=serie.repeticiones if unidad is Unidad.REPS else 0,
        segundos=serie.segundos if unidad is Unidad.SEGUNDOS else 0,
        metros=serie.metros if unidad is Unidad.METROS else 0,
    )


def series_para_anadir(reales: tuple[Serie, ...] | None) -> tuple[Serie, ...]:
    """Las series de un ejercicio que se añade a mitad del entreno.

    TANTAS COMO LA ÚLTIMA VEZ, con sus valores; sin historial, una vacía (no
    hay plan del que copiar: el ejercicio no estaba en la rutina).
    """
    if not reales:
        return (Serie(numero=1),)
    return tuple(sugerida(reales, numero) for numero in range(1, len(reales) + 1))


def ordenados(sesion: Sesion) -> tuple[EjercicioDeSesion, ...]:
    return tuple(sorted(sesion.ejercicios, key=lambda uno: uno.orden))


def mover(sesion: Sesion, orden: int, hacia: int) -> tuple[EjercicioDeSesion, ...]:
    """Los dos ejercicios que cambian de sitio al mover uno arriba (-1) o abajo (+1).

    SE INTERCAMBIAN LOS «orden» DE LOS DOS VECINOS y nada más: así se guardan
    dos filas, no todo el entreno. Vacío si ya está en la punta.
    """
    lista = ordenados(sesion)
    indice = next((i for i, uno in enumerate(lista) if uno.orden == orden), None)
    if indice is None or not 0 <= indice + hacia < len(lista):
        return ()
    este, vecino = lista[indice], lista[indice + hacia]
    return (replace(este, orden=vecino.orden), replace(vecino, orden=este.orden))


# ---------------------------------------------------------------------------
# Progreso: lo que se hizo, y nada más
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Marca:
    """La mejor serie de un ejercicio, y cuándo fue.

    `repeticiones` ES LO QUE VA CON LOS KILOS, en su `unidad`: repeticiones,
    segundos o metros. Se dejó el nombre viejo porque casi siempre es eso.
    """

    peso: int
    repeticiones: int
    fecha: date
    unidad: Unidad = Unidad.REPS

    def texto(self) -> str:
        return texto_de_serie(self.peso, self.unidad, self.repeticiones)


def _marca_de(serie: Serie, fecha: date) -> Marca:
    return Marca(peso=serie.peso, repeticiones=serie.cantidad, fecha=fecha, unidad=serie.unidad)


def mejor_marca(
    historial: Iterable[tuple[date, EjercicioDeSesion]], unidad: Unidad = Unidad.REPS
) -> Marca | None:
    """La mejor serie hecha de ese ejercicio en todo el historial.

    MEJOR ES MÁS PESO, y a igual peso, más repeticiones (o más metros, o más
    segundos). No se calcula ningún "1RM teórico" para comparar: lo pidió
    expresamente el usuario, y además esa fórmula es una estimación, o sea justo
    lo que esta aplicación no enseña.

    SOLO LAS SERIES DE ESA `unidad`: 40 metros no superan 10 repeticiones ni
    pierden contra ellas, son otra cosa. Si el paseo del granjero pasa de reps a
    metros, la primera vez en metros no hay medalla (como cualquier primera vez).

    Solo cuentan las series HECHAS: una escrita y no marcada no es una marca.
    """
    mejor: Marca | None = None
    for fecha, ejercicio in historial:
        for serie in ejercicio.series:
            if not serie.cuenta or not serie.peso or serie.unidad is not unidad:
                continue
            candidata = _marca_de(serie, fecha)
            if mejor is None or (candidata.peso, candidata.repeticiones) > (
                mejor.peso,
                mejor.repeticiones,
            ):
                mejor = candidata
    return mejor



def records(
    ejercicio: EjercicioDeSesion, previa: Marca | None, fecha: date
) -> dict[int, Marca]:
    """Las series de hoy que superaron la mejor marca: número -> la que superó.

    LO PIDIÓ EL USUARIO: «si paso de 12 kg × 10 a 14 kg × 10 debe haber una
    medalla». MEJOR ES LO MISMO QUE EN `mejor_marca`: más peso, y a igual peso,
    más repeticiones. Sin marca de antes NO HAY MEDALLA: la primera vez que hacés
    un ejercicio no superás nada.

    SE VA SUBIENDO EL LISTÓN en el orden de las series: si la 1 de hoy ya fue
    récord, la 2 tiene que superarla a ella. Dos medallas iguales seguidas no
    dirían nada.
    """
    if previa is None:
        return {}
    mejor, salida = previa, {}
    for serie in sorted(ejercicio.series, key=lambda una: una.numero):
        # LA MISMA UNIDAD QUE LA MARCA, por lo mismo que en `mejor_marca`.
        if not serie.cuenta or not serie.peso or serie.unidad is not previa.unidad:
            continue
        if (serie.peso, serie.cantidad) > (mejor.peso, mejor.repeticiones):
            salida[serie.numero] = mejor
            mejor = _marca_de(serie, fecha)
    return salida

def peso_maximo_por_mes(
    historial: Iterable[tuple[date, EjercicioDeSesion]],
) -> list[tuple[date, int]]:
    """El peso más alto de cada mes, para la gráfica de progreso.

    Por mes y no por día porque la gráfica de un año con un punto por sesión es
    ilegible, y porque lo que se mira es la tendencia, no el martes concreto.
    """
    por_mes: dict[date, int] = {}
    for fecha, ejercicio in historial:
        primero = fecha.replace(day=1)
        for serie in ejercicio.series:
            if serie.cuenta and serie.peso:
                por_mes[primero] = max(por_mes.get(primero, 0), serie.peso)
    return [(mes, por_mes[mes]) for mes in sorted(por_mes)]


def volumen_por_semana(sesiones: Iterable[Sesion]) -> list[tuple[date, int]]:
    """El volumen de cada semana, con la fecha del lunes. Para la vista general."""
    from datetime import timedelta

    por_semana: dict[date, int] = {}
    for sesion in sesiones:
        lunes = sesion.fecha - timedelta(days=sesion.fecha.weekday())
        por_semana[lunes] = por_semana.get(lunes, 0) + sesion.volumen
    return [(lunes, por_semana[lunes]) for lunes in sorted(por_semana)]


def series_por_grupo(
    sesiones: Iterable[Sesion], grupos: dict[int, str]
) -> dict[str, int]:
    """Cuántas series hechas por grupo muscular. Para ver qué se descuida.

    Se cuentan SERIES y no sesiones: entrenar espalda una vez con nueve series no
    es lo mismo que tocarla de pasada con una, y contando sesiones las dos cosas
    valdrían igual.

    Los ejercicios borrados de la biblioteca no tienen grupo, así que no se
    cuentan. Se dice aparte en la pantalla en vez de repartirlos a ojo.
    """
    cuenta: dict[str, int] = {}
    for sesion in sesiones:
        for ejercicio in sesion.ejercicios:
            grupo = grupos.get(ejercicio.ejercicio_id) if ejercicio.ejercicio_id else None
            if grupo is None:
                continue
            cuenta[grupo] = cuenta.get(grupo, 0) + ejercicio.hechas
    return cuenta


def texto_volumen(centesimas: int) -> str:
    """"12.450 kg". El volumen se lee en kilos enteros: los decimales aquí no
    dicen nada y estorban para comparar semanas de un vistazo."""
    from .rutina import CENTESIMAS_POR_KILO

    kilos = centesimas // CENTESIMAS_POR_KILO
    return f"{kilos:,}".replace(",", ".") + " kg"


def con_serie(
    ejercicio: EjercicioDeSesion, numero: int, **cambios
) -> EjercicioDeSesion:
    """Devuelve el ejercicio con una serie cambiada. No toca el original."""
    series = tuple(
        replace(una, **cambios) if una.numero == numero else una
        for una in ejercicio.series
    )
    return replace(ejercicio, series=series)


def sin_ejercicio(sesion: Sesion, orden: int) -> Sesion:
    """La sesión sin ese ejercicio. Lo que ya estaba marcado en él se va con él.

    SIN PREGUNTAR, Y LO PIDIÓ ASÍ EL USUARIO: «al tocarlo, el ejercicio debe
    eliminarse directamente, sin ningún mensaje ni confirmación». Entrenando,
    un «¿seguro?» es un toque más con las manos ocupadas; y si te equivocas,
    volver a añadirlo es un toque también.

    LOS DEMÁS NO SE RENUMERAN: el orden solo sirve para ordenar, y un hueco en
    medio no cambia qué va antes de qué. Renumerar movería el «orden» con el
    que la pantalla encuentra cada ejercicio mientras está dibujada.
    """
    return replace(
        sesion,
        ejercicios=tuple(uno for uno in sesion.ejercicios if uno.orden != orden),
    )

def anadir_serie(ejercicio: EjercicioDeSesion) -> EjercicioDeSesion:
    """Una serie extra, copiando el peso y las repeticiones de la última.

    Se copia porque una serie extra casi siempre es "otra igual", y empezar con
    ceros obligaría a reescribirlo todo de pie en el gimnasio.
    """
    if len(ejercicio.series) >= SERIES_MAXIMAS:
        return ejercicio
    ultima = ejercicio.series[-1] if ejercicio.series else None
    nueva = Serie(
        numero=len(ejercicio.series) + 1,
        peso=ultima.peso if ultima else 0,
        repeticiones=ultima.repeticiones if ultima else 0,
        hecha=False,
    )
    return replace(ejercicio, series=(*ejercicio.series, nueva))


def quitar_serie(ejercicio: EjercicioDeSesion, numero: int) -> EjercicioDeSesion:
    """Quita una serie y renumera las que quedan.

    Renumerar hace falta: sin ello, quitar la 2 de tres series dejaría la 1 y la
    3, y "la última vez" compararía la serie 3 de hoy con la 3 de otro día que
    fue la segunda de verdad.
    """
    quedan = [una for una in ejercicio.series if una.numero != numero]
    renumeradas = tuple(
        replace(una, numero=indice) for indice, una in enumerate(quedan, start=1)
    )
    return replace(ejercicio, series=renumeradas)

