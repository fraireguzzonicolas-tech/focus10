"""El horario semanal: una rejilla de horas × días donde escribes tú.

QUÉ ES Y QUÉ NO ES: es la hoja de papel que el usuario tenía en la pizarra,
pasada a la aplicación. Una casilla por cada hora de cada día, y dentro lo que
tú escribas. La aplicación NO propone nada, no reordena, no rellena huecos y no
avisa de que "tienes un hueco libre". Escribes tú, y punto.

POR QUÉ NO SE LLAMA `Horario`: ese nombre ya está cogido en dominio/jornada.py,
donde significa otra cosa distinta —a qué hora empieza y acaba TU jornada, la
que decide de qué día es cada registro—. Dos clases con el mismo nombre y
significados distintos es una confusión garantizada, así que aquí la rejilla es
`HorarioSemanal` y su franja de horas es `FranjaHoraria`.

POR QUÉ LA FRANJA SE PUEDE CAMBIAR: de partida va de las 7:00 a las 23:00, que
es lo que pidió el usuario, pero él trabaja de noches. Un horario que empieza a
las 21:00 y acaba a las 5:00 tiene que poder escribirse, y por eso la franja
CRUZA LA MEDIANOCHE ella sola: si la hora de fin es menor que la de inicio, no
hay ninguna otra posibilidad, así que preguntarlo sería pedir un dato que ya
está en los otros dos. Es la misma regla que usa la jornada, a propósito: dos
formas distintas de decir lo mismo en la misma aplicación se acaban
contradiciendo.

LAS CASILLAS VACÍAS NO EXISTEN: solo se guarda lo que tiene texto. Una rejilla
de 7 días × 17 horas son 119 casillas, y guardar 119 filas en blanco para que
casi todas sigan en blanco no aporta nada. Vaciar una casilla es borrarla.
"""

from __future__ import annotations

from dataclasses import dataclass

DIAS = (
    "lunes",
    "martes",
    "miércoles",
    "jueves",
    "viernes",
    "sábado",
    "domingo",
)
"""Los siete días, empezando en lunes.

EMPIEZA EN LUNES y no en domingo porque es como se lee una semana aquí, y
porque coincide con `date.weekday()` de Python, que ya devuelve 0 para el lunes.
Hacerlo al revés obligaría a sumar y restar uno en cada sitio, y ese es
justamente el tipo de cuenta que se acaba olvidando en algún sitio.
"""

HORA_DESDE_POR_OMISION = 7
HORA_HASTA_POR_OMISION = 23

COLORES = ("verde", "azul", "lila", "rosa", "melocoton", "amarillo")
"""Los seis colores que puede tener una casilla.

AQUÍ ESTÁN LOS NOMBRES, NO LOS TONOS. El dominio no sabe de qué verde se trata
—ni falta que le hace— y el tono exacto vive en interfaz/estilo.py, que es el
único sitio del proyecto donde se escriben colores. Así el mismo "verde" puede
pintarse distinto en el modo claro y en el oscuro sin que esto se entere.

SEIS Y NO DIEZ, y lo eligió el usuario: seis se distinguen de un vistazo. Con
más empiezas a dudar de si dos son el mismo, y ahí el color deja de ayudar.
"""

LARGO_MAXIMO_NOTA = 500
"""Lo que cabe en la nota de una casilla.

La nota no se ve en la rejilla —solo al abrir la casilla y al pasar el ratón por
encima—, así que puede ser más larga que el texto. Quinientos caracteres son un
párrafo largo: suficiente para un "llevar la carpeta azul y avisar a Marta", que
es para lo que sirve, y poco para que alguien escriba aquí un diario.
"""

LARGO_MAXIMO_CASILLA = 120
"""Lo que cabe en una casilla.

No es un límite técnico: es que una casilla de una rejilla con un párrafo dentro
deja de ser legible, y el horario existe para verse de un vistazo.
"""


def _exigir_hora(nombre: str, valor: object) -> int:
    if isinstance(valor, bool) or not isinstance(valor, int):
        raise TypeError(f"{nombre} tiene que ser un entero de 0 a 23")
    if not 0 <= valor <= 23:
        raise ValueError(f"{nombre} tiene que estar entre 0 y 23, no {valor}")
    return valor


@dataclass(frozen=True)
class FranjaHoraria:
    """Qué horas se ven en la rejilla, de la primera a la última.

    LAS DOS SON INCLUSIVAS: de 7 a 23 son diecisiete filas, de las 7:00 a las
    23:00, las dos puntas incluidas. Es lo que espera quien escribe "de 7 a 23"
    en un papel, y la alternativa —que la última hora no salga— es de esas cosas
    que sorprenden una vez y molestan siempre.
    """

    desde: int = HORA_DESDE_POR_OMISION
    hasta: int = HORA_HASTA_POR_OMISION

    def __post_init__(self) -> None:
        _exigir_hora("desde", self.desde)
        _exigir_hora("hasta", self.hasta)

    @property
    def cruza_medianoche(self) -> bool:
        """True si la franja termina al día siguiente de empezar.

        Se deduce, no se pregunta: si acaba a una hora ANTERIOR a la de empezar
        (5 < 21), no puede ser el mismo día.
        """
        return self.hasta < self.desde

    def horas(self) -> tuple[int, ...]:
        """Las horas de la rejilla, en el orden en que se ven.

        Con 21→5 salen (21, 22, 23, 0, 1, 2, 3, 4, 5): se sigue hacia delante y
        se da la vuelta al pasar de las 23. Ese orden es el del turno, y ver la
        madrugada DEBAJO de la noche es lo que hace que se entienda.
        """
        if not self.cruza_medianoche:
            return tuple(range(self.desde, self.hasta + 1))
        return tuple(range(self.desde, 24)) + tuple(range(0, self.hasta + 1))

    def contiene(self, hora: int) -> bool:
        """Si esa hora se ve en la rejilla."""
        return hora in self.horas()

    def __len__(self) -> int:
        return len(self.horas())


@dataclass(frozen=True)
class Casilla:
    """Lo escrito en una hora de un día."""

    dia: int
    """0 = lunes … 6 = domingo, igual que `date.weekday()`."""

    hora: int

    texto: str = ""
    """Lo que escribiste. PUEDE ESTAR VACÍO si la casilla tiene color.

    ANTES ERA OBLIGATORIO y esto es el cambio que trajo el color: el usuario
    pidió poder marcar una hora solo con un cuadrado de color, sin escribir
    nada. Una casilla pintada de verde ya dice algo, así que exigirle además un
    texto sería obligar a escribir para poder pintar.
    """

    color: str | None = None
    """Uno de COLORES, o None si la casilla no está pintada."""

    nota: str = ""
    """El detalle largo que no cabe en la rejilla.

    NO BASTA POR SÍ SOLA para que la casilla exista: una nota no se ve en la
    rejilla, así que una casilla con solo nota sería una hora que parece libre y
    no lo está. Hace falta texto o color, y la nota va encima.
    """

    def __post_init__(self) -> None:
        if isinstance(self.dia, bool) or not isinstance(self.dia, int):
            raise TypeError("dia tiene que ser un entero de 0 a 6")
        if not 0 <= self.dia <= 6:
            raise ValueError(f"dia tiene que estar entre 0 y 6, no {self.dia}")
        _exigir_hora("hora", self.hora)
        if self.color is not None:
            if not isinstance(self.color, str):
                raise TypeError("el color de una casilla tiene que ser texto")
            if self.color not in COLORES:
                raise ValueError(
                    f"«{self.color}» no es uno de los colores del horario: "
                    f"{', '.join(COLORES)}"
                )
        if not isinstance(self.nota, str):
            raise TypeError("la nota de una casilla tiene que ser texto")
        object.__setattr__(self, "nota", self.nota.strip())
        if len(self.nota) > LARGO_MAXIMO_NOTA:
            raise ValueError(
                f"la nota no puede pasar de {LARGO_MAXIMO_NOTA} caracteres"
            )
        if not isinstance(self.texto, str):
            raise TypeError("el texto de una casilla tiene que ser texto")
        limpio = self.texto.strip()
        # TEXTO O COLOR, PERO ALGO. Una casilla sin nada de lo uno ni de lo otro
        # no se ve en la rejilla, así que guardarla sería guardar una fila que
        # no significa nada. Vaciar del todo una casilla es borrarla.
        if not limpio and self.color is None:
            raise ValueError("una casilla sin texto y sin color no se guarda: se borra")
        if len(limpio) > LARGO_MAXIMO_CASILLA:
            raise ValueError(
                f"el texto de una casilla no puede pasar de "
                f"{LARGO_MAXIMO_CASILLA} caracteres"
            )
        object.__setattr__(self, "texto", limpio)


class HorarioSemanal:
    """La rejilla entera: su franja de horas y lo escrito en ella.

    NO ES INMUTABLE como casi todo el resto del dominio, y es a propósito: se
    construye una vez por pantalla a partir de lo que hay en la base, y se
    consulta muchas veces al dibujar. Guardar las casillas en un diccionario
    hace que buscar una sea inmediato; con una lista habría que recorrerla
    entera 119 veces por cada dibujado.
    """

    def __init__(self, franja: FranjaHoraria, casillas: tuple[Casilla, ...] = ()) -> None:
        if not isinstance(franja, FranjaHoraria):
            raise TypeError("franja tiene que ser una FranjaHoraria")
        self.franja = franja
        # SE GUARDA LA CASILLA ENTERA y no solo su texto, que es como estaba
        # antes de que existieran los colores. Con solo el texto no habría
        # forma de recordar de qué color está pintada una hora sin escribir
        # nada en ella.
        self._por_sitio: dict[tuple[int, int], Casilla] = {}
        for casilla in casillas:
            if not isinstance(casilla, Casilla):
                raise TypeError("las casillas tienen que ser Casilla")
            self._por_sitio[(casilla.dia, casilla.hora)] = casilla

    def casilla_de(self, dia: int, hora: int) -> Casilla | None:
        """La casilla entera, o None si esa hora está libre."""
        return self._por_sitio.get((dia, hora))

    def texto_de(self, dia: int, hora: int) -> str:
        """Lo escrito en esa casilla, o cadena vacía si no hay nada."""
        una = self._por_sitio.get((dia, hora))
        return una.texto if una else ""

    def color_de(self, dia: int, hora: int) -> str | None:
        """De qué color está pintada esa casilla, o None."""
        una = self._por_sitio.get((dia, hora))
        return una.color if una else None

    def nota_de(self, dia: int, hora: int) -> str:
        """La nota de esa casilla, o cadena vacía."""
        una = self._por_sitio.get((dia, hora))
        return una.nota if una else ""

    def columna(self, dia: int) -> list[tuple[int, str]]:
        """El día entero, hora a hora, para la tarjeta del Dashboard.

        SALEN TODAS LAS HORAS DE LA FRANJA, también las vacías. El usuario pidió
        "la columna entera de hoy", y una columna a la que le faltan las horas
        libres no es la columna: es un resumen, y engaña sobre cuánto hueco
        queda.
        """
        return [(hora, self.texto_de(dia, hora)) for hora in self.franja.horas()]

    def pintadas_de(self, dia: int) -> list[tuple[int, str | None]]:
        """Las horas de ese día con su color, para pintar la columna."""
        return [(hora, self.color_de(dia, hora)) for hora in self.franja.horas()]

    def escritas_de(self, dia: int) -> list[tuple[int, str]]:
        """Solo las horas de ese día que tienen algo escrito."""
        return [(hora, texto) for hora, texto in self.columna(dia) if texto]

    def con_algo_de(self, dia: int) -> list[Casilla]:
        """Las casillas de ese día que tienen texto O color.

        SE MIRAN LAS DOS COSAS: una hora pintada de verde sin nada escrito
        también cuenta como "tienes algo ahí", y el Dashboard tiene que
        enterarse o diría que el día está vacío teniéndolo pintado entero.
        """
        return [
            una
            for una in (self.casilla_de(dia, hora) for hora in self.franja.horas())
            if una is not None
        ]

    def cuantas_escritas(self) -> int:
        """Cuántas casillas tienen algo. Sirve para saber si está vacío."""
        return len(self._por_sitio)

    def fuera_de_franja(self) -> list[Casilla]:
        """Lo escrito en horas que la franja ya no enseña.

        POR QUÉ HACE FALTA: si escribes algo a las 6:00 y luego cambias la
        franja a 7→23, ese texto sigue en la base pero no se ve en ninguna
        parte. Callarlo sería hacerle creer al usuario que se ha borrado. La
        pantalla lo usa para avisar, no para borrar nada.
        """
        return [
            una
            for (_, hora), una in sorted(self._por_sitio.items())
            if not self.franja.contiene(hora)
        ]


def texto_hora(hora: int) -> str:
    """La hora como se enseña en la rejilla: "07:00"."""
    _exigir_hora("hora", hora)
    return f"{hora:02d}:00"
