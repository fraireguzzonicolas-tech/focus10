"""Las calorías que se estiman de un entreno. ESTIMAN, no miden.

LO PIDIÓ EL USUARIO al ver el resumen de otra aplicación, y se le dijo antes de
hacerlo lo que hay aquí abajo. Se hace porque él lo eligió sabiéndolo.

ESTO NO SABE LO QUE GASTÓ TU CUERPO, y no puede saberlo. Lo que hace es la
cuenta estándar de la literatura del ejercicio: un valor MET —cuánto multiplica
una actividad tu gasto en reposo— por lo que pesas y por el rato que has estado.
Ni mide tu corazón, ni sabe cuánto descansaste entre series, ni de qué son tus
músculos.

PARA QUÉ SIRVE ENTONCES: para comparar TUS entrenos entre ellos. Si uno da 250 y
otro 400, el segundo fue más largo o más duro. El número suelto no significa
gran cosa, y por eso en pantalla lleva un "unas" delante.

SIN PESO NO HAY NÚMERO. Si no has dicho lo que pesas, esto devuelve None y el
resumen no enseña calorías. Inventar un peso medio de setenta y cinco kilos sería
darte un número con pinta de tuyo que no lo es.
"""

from __future__ import annotations

GRAMOS_POR_KILO = 1000

MET_PESAS = 5.0
"""Cuánto multiplica el gasto en reposo una sesión de pesas.

CINCO ES EL VALOR DE "esfuerzo vigoroso" del compendio de actividades físicas,
que es donde salen estos números. El de "esfuerzo moderado" es 3,5. Se usa el
alto porque quien abre esta aplicación y marca series está entrenando, no
paseando entre máquinas.
"""

SEGUNDOS_POR_HORA = 3600


def calorias_estimadas(segundos: int, peso_en_gramos: int | None) -> int | None:
    """Las calorías de un entreno, o None si no se pueden estimar.

    LA CUENTA: MET × kilos × horas. Es la de toda la vida, y su resultado son
    kilocalorías, que es lo que la gente llama "calorías" a secas.
    """
    if not peso_en_gramos or peso_en_gramos <= 0:
        return None
    if not segundos or segundos <= 0:
        return None
    kilos = peso_en_gramos / GRAMOS_POR_KILO
    horas = segundos / SEGUNDOS_POR_HORA
    return int(round(MET_PESAS * kilos * horas))


def texto_calorias(calorias: int | None) -> str:
    """Cómo se escribe en pantalla. Con el "unas" DELANTE y no en letra pequeña.

    Si el aviso de que es una estimación va escondido, no está: quien lee "258
    cal" se lleva un dato, y quien lee "unas 258 cal" se lleva una idea.
    """
    if calorias is None:
        return ""
    return f"unas {calorias} cal"
