"""El pomodoro: fases, duraciones y en qué momento va cada cosa.

AQUÍ NO HAY RELOJ. Esta pieza no pregunta la hora ni duerme ni cuenta: recibe
cuántos segundos han pasado y dice en qué estado queda. Por eso se puede probar
un ciclo entero de ocho horas en un milisegundo, y por eso los tests no dependen
de que la máquina vaya rápida o lenta.

LAS DOS REGLAS QUE PIDIÓ EL USUARIO SOBRE CAMBIAR LAS DURACIONES:

  1. Si el reloj está PARADO, el número nuevo se aplica en el momento. Poner 50
     minutos y seguir viendo 25 es un reloj que no te hace caso.
  2. Si hay una sesión EN MARCHA, no se corta. El cambio entra en la siguiente
     fase. Cortar una sesión a la mitad por tocar un número es perder el trabajo
     hecho, y además nadie lo esperaría.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, replace
from enum import StrEnum
from .validar import exigir_entero

SEGUNDOS_MAXIMOS = 8 * 60 * 60
"""Ocho horas, el tope que puso el usuario. Vale para cualquiera de las tres
duraciones."""

SEGUNDOS_MINIMOS = 60
"""Un minuto. Por debajo, el temporizador circular no llega ni a dibujarse y la
fase termina antes de que apartes la vista."""

SESIONES_MAXIMAS = 12
SESIONES_MINIMAS = 1


class Fase(StrEnum):
    TRABAJO = "trabajo"
    DESCANSO = "descanso"
    DESCANSO_LARGO = "descanso largo"

    @property
    def es_trabajo(self) -> bool:
        """Lo que decide si hay bloqueo: se bloquea trabajando, y solo entonces.

        Los descansos son libres a propósito. Un descanso en el que tampoco
        puedes entrar a nada no es un descanso, es la misma cárcel con otro
        nombre, y acabarías apagando la aplicación entera.
        """
        return self is Fase.TRABAJO


@dataclass(frozen=True)
class Ajustes:
    """Las cuatro cifras que se cambian en la propia pantalla de Focus."""

    trabajo: int = 25 * 60
    descanso: int = 5 * 60
    descanso_largo: int = 15 * 60
    sesiones_por_ciclo: int = 4
    """Cuántos trabajos antes de un descanso largo."""

    def __post_init__(self) -> None:
        for nombre in ("trabajo", "descanso", "descanso_largo"):
            exigir_entero(nombre, getattr(self, nombre))
            valor = getattr(self, nombre)
            if not SEGUNDOS_MINIMOS <= valor <= SEGUNDOS_MAXIMOS:
                raise ValueError(
                    f"{nombre} va de {SEGUNDOS_MINIMOS} a {SEGUNDOS_MAXIMOS} "
                    f"segundos (de 1 minuto a 8 horas), y llegó {valor}"
                )
        exigir_entero("sesiones_por_ciclo", self.sesiones_por_ciclo)
        if not SESIONES_MINIMAS <= self.sesiones_por_ciclo <= SESIONES_MAXIMAS:
            raise ValueError(
                f"sesiones_por_ciclo va de {SESIONES_MINIMAS} a {SESIONES_MAXIMAS}, "
                f"y llegó {self.sesiones_por_ciclo}"
            )

    def duracion_de(self, fase: Fase) -> int:
        if not isinstance(fase, Fase):
            raise TypeError(f"fase tiene que ser una Fase, no {type(fase).__name__}")
        if fase is Fase.TRABAJO:
            return self.trabajo
        if fase is Fase.DESCANSO:
            return self.descanso
        return self.descanso_largo


@dataclass(frozen=True)
class Estado:
    """Dónde está el pomodoro ahora mismo."""

    fase: Fase = Fase.TRABAJO
    restante: int = 25 * 60
    """Segundos que faltan para que acabe la fase."""

    corriendo: bool = False
    trabajos_hechos: int = 0
    """Trabajos TERMINADOS en el ciclo actual. Vuelve a cero tras el descanso
    largo."""

    def __post_init__(self) -> None:
        if not isinstance(self.fase, Fase):
            raise TypeError("fase tiene que ser una Fase")
        exigir_entero("restante", self.restante)
        if self.restante < 0:
            raise ValueError(f"restante no puede ser negativo, y llegó {self.restante}")
        if not isinstance(self.corriendo, bool):
            raise TypeError("corriendo tiene que ser True o False")
        exigir_entero("trabajos_hechos", self.trabajos_hechos)
        if self.trabajos_hechos < 0:
            raise ValueError("trabajos_hechos no puede ser negativo")

    @property
    def terminada(self) -> bool:
        return self.restante <= 0

    def texto(self) -> str:
        """El reloj como se lee: "25:00", y "1:05:00" si pasa de la hora."""
        horas, resto = divmod(max(0, self.restante), 3600)
        minutos, segundos = divmod(resto, 60)
        if horas:
            return f"{horas}:{minutos:02d}:{segundos:02d}"
        return f"{minutos:02d}:{segundos:02d}"

    def fraccion(self, ajustes: Ajustes) -> float:
        """Lo consumido de la fase, de 0 a 1. Es lo que rellena el círculo."""
        total = ajustes.duracion_de(self.fase)
        if total <= 0:
            return 0.0
        return min(1.0, max(0.0, (total - self.restante) / total))


def texto_duracion(segundos: int) -> str:
    """La duración escrita como se dice: "25 min", "1 h 30 min", "2 h".

    En horas cuando pasa de sesenta porque nadie piensa en "120 minutos". Es lo
    que se enseña en la casilla cuando dejas de escribir.
    """
    exigir_entero("segundos", segundos)
    horas, resto = divmod(max(0, segundos), 3600)
    minutos = resto // 60
    if horas and minutos:
        return f"{horas} h {minutos} min"
    if horas:
        return f"{horas} h"
    return f"{minutos} min"


# Un número solo son minutos: "90". Con dos puntos o una hache, son horas y
# minutos: "1:30", "1h30", "1 h 30 min". Se admiten las tres formas porque cada
# uno escribe la suya, y obligar a una es una pelea con el usuario que no hace
# falta tener.
_CON_HORAS = re.compile(r"^(\d{1,2})\s*(?::|h(?:oras?)?)\s*(\d{0,2})\s*(?:m|min|minutos?)?$")
_SOLO_MINUTOS = re.compile(r"^(\d{1,4})\s*(?:m|min|minutos?)?$")


def parsear_duracion(texto: str) -> int:
    """Convierte lo que se escribe en segundos, o explica por qué no vale.

    POR QUÉ ESTO ESTÁ EN EL DOMINIO Y NO EN LA PANTALLA: es una regla —qué se
    considera una duración válida— y se puede probar entera sin abrir ninguna
    ventana. En la pantalla habría que darle a los botones para comprobar que
    "1h30" son noventa minutos.
    """
    if not isinstance(texto, str):
        raise TypeError("la duración tiene que ser texto")

    limpio = texto.strip().lower().replace(",", ".")
    if not limpio:
        raise ValueError("escribe cuánto dura, por ejemplo 25 o 1:30")

    con_horas = _CON_HORAS.match(limpio)
    if con_horas:
        horas = int(con_horas.group(1))
        minutos = int(con_horas.group(2) or 0)
        if minutos > 59:
            raise ValueError(f"los minutos van de 0 a 59, y pusiste {minutos}")
        total = horas * 3600 + minutos * 60
    else:
        solo = _SOLO_MINUTOS.match(limpio)
        if not solo:
            raise ValueError(
                f"no entiendo «{texto.strip()}». Escribe los minutos (90) o las "
                "horas y minutos (1:30)"
            )
        total = int(solo.group(1)) * 60

    if total < SEGUNDOS_MINIMOS:
        raise ValueError("lo más corto es 1 minuto")
    if total > SEGUNDOS_MAXIMOS:
        raise ValueError("lo más largo son 8 horas")
    return total


def empezar(ajustes: Ajustes) -> Estado:
    """Un pomodoro recién puesto: en trabajo, parado y entero."""
    return Estado(fase=Fase.TRABAJO, restante=ajustes.trabajo, corriendo=False)


def arrancar(estado: Estado) -> Estado:
    return replace(estado, corriendo=True)


def pausar(estado: Estado) -> Estado:
    return replace(estado, corriendo=False)


def reiniciar_fase(estado: Estado, ajustes: Ajustes) -> Estado:
    """Vuelve a poner la fase actual entera, parada. No toca el ciclo."""
    return replace(
        estado, restante=ajustes.duracion_de(estado.fase), corriendo=False
    )


def siguiente_fase(estado: Estado, ajustes: Ajustes) -> Fase:
    """Qué toca después de la fase actual.

    Después de trabajar toca descanso; largo si con este trabajo se completa el
    ciclo. Después de cualquier descanso, a trabajar.
    """
    if estado.fase is not Fase.TRABAJO:
        return Fase.TRABAJO
    hechos = estado.trabajos_hechos + 1
    return (
        Fase.DESCANSO_LARGO
        if hechos % ajustes.sesiones_por_ciclo == 0
        else Fase.DESCANSO
    )


def avanzar(estado: Estado, ajustes: Ajustes) -> Estado:
    """Pasa a la fase siguiente, entera y PARADA.

    Parada a propósito: encadenar solo significaría que te levantas al baño y
    vuelves con el descanso consumido y el trabajo empezado sin ti.
    """
    siguiente = siguiente_fase(estado, ajustes)
    hechos = estado.trabajos_hechos
    if estado.fase is Fase.TRABAJO:
        hechos += 1
    if siguiente is Fase.TRABAJO and estado.fase is Fase.DESCANSO_LARGO:
        # Ciclo cerrado: se vuelve a empezar a contar.
        hechos = 0
    return Estado(
        fase=siguiente,
        restante=ajustes.duracion_de(siguiente),
        corriendo=False,
        trabajos_hechos=hechos,
    )


def correr(estado: Estado, segundos: int, ajustes: Ajustes) -> Estado:
    """Descuenta ese tiempo. Si la fase se acaba, deja el estado en 0 y parado.

    NO SALTA SOLO A LA FASE SIGUIENTE: quien llama tiene que ver que la fase ha
    terminado para poder avisar, desbloquear las webs y esperar a que la persona
    diga "vale". Encadenar aquí escondería el final de la fase de trabajo, que es
    justo el momento en que hay que soltar el bloqueo.
    """
    exigir_entero("segundos", segundos)
    if segundos < 0:
        raise ValueError("no se puede correr hacia atrás")
    if not estado.corriendo:
        return estado
    restante = estado.restante - segundos
    if restante <= 0:
        return replace(estado, restante=0, corriendo=False)
    return replace(estado, restante=restante)


def con_ajustes(estado: Estado, viejos: Ajustes, nuevos: Ajustes) -> Estado:
    """Aplica unas duraciones nuevas al estado actual.

    Si está PARADO, la fase se pone al día en el momento con la duración nueva.
    Si está EN MARCHA, no se toca nada: la sesión sigue como estaba y el número
    nuevo entrará cuando cambie de fase. Las dos reglas las pidió el usuario.

    `viejos` se recibe para no repintar cuando la duración de la fase actual no
    ha cambiado: si cambias solo el descanso largo estando parado en trabajo, el
    reloj de trabajo se queda como lo tenías, aunque lo hubieras reiniciado.
    """
    if estado.corriendo:
        return estado
    if viejos.duracion_de(estado.fase) == nuevos.duracion_de(estado.fase):
        return estado
    return replace(estado, restante=nuevos.duracion_de(estado.fase))

