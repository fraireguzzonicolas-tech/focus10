"""El cronómetro de descanso entre series. Solo la cuenta, sin pantalla.

QUÉ HACE DISTINTO AL POMODORO, que ya existe en pomodoro.py: este arranca SOLO
al marcar una serie, dura lo que diga el ejercicio, y se puede alargar o acortar
de quince en quince mientras corre. El pomodoro lo empiezas tú y dura lo que
configuraste. Son dos cosas y viven en dos archivos.

POR QUÉ SIGUE CONTANDO AUNQUE CAMBIES DE PANTALLA: porque el descanso es del
entreno, no de la pantalla. Si el cronómetro muriera al ir a mirar otra cosa,
sería inútil justo en el minuto y medio en que uno mira el móvil. Aquí eso se
traduce en que el estado es un dato que vive en la aplicación entera, no dentro
de la pantalla del gimnasio.

AQUÍ NO SE PITA NI SE AVISA. Este archivo dice "se acabó" y nada más; quien
llama decide qué hacer con eso. Es lo mismo que hace el pomodoro al terminar una
fase, y por lo mismo: el dominio no toca Windows.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, replace

SEGUNDOS_MINIMOS = 5
"""Menos de cinco segundos no es un descanso: es un cronómetro que ya salió."""

SEGUNDOS_MAXIMOS = 30 * 60
"""Media hora, el mismo tope que el descanso de la ficha del ejercicio."""

PASO = 15
"""Lo que suma o resta cada toque de los botones ±. Quince segundos porque es lo
que se ajusta de verdad entre series; con pasos de un minuto se pasa de largo y
con pasos de cinco segundos hay que pulsar seis veces."""

SEGUNDOS_DE_CORTESIA = 10
"""Cuánto se queda la franja en pantalla después de acabar, para que dé tiempo a
verla. Sin esto, si estás en otra pantalla desaparece antes de que mires."""

AVISO_PREVIO = 10
"""A cuántos segundos del final se da el pitido corto de aviso."""


@dataclass(frozen=True)
class Descanso:
    """Un descanso en marcha. Inmutable: cada segundo devuelve uno nuevo."""

    total: int
    """Lo que dura en total. Cambia si se pulsa ±, y por eso hace falta guardarlo
    aparte: la barra de progreso necesita saber sobre qué se llena."""

    restante: int
    ejercicio: str = ""
    """El nombre, para que la franja diga de qué descanso se trata. Con dos
    ejercicios seguidos, un cronómetro sin nombre no dice de cuál es."""

    serie: int = 0
    """Qué serie se acaba de marcar. Cero si no viene de una serie."""

    corriendo: bool = True
    aviso_dado: bool = False
    """Si ya sonó el pitido de los últimos segundos. Sin esta marca sonaría una
    vez por cada tic mientras dura la cuenta atrás."""

    def __post_init__(self) -> None:
        _exigir_entero("total", self.total)
        if not SEGUNDOS_MINIMOS <= self.total <= SEGUNDOS_MAXIMOS:
            raise ValueError(
                f"el descanso va de {SEGUNDOS_MINIMOS} a {SEGUNDOS_MAXIMOS} segundos"
            )
        _exigir_entero("restante", self.restante)
        if self.restante < 0:
            raise ValueError("restante no puede ser negativo")
        if self.restante > self.total:
            raise ValueError("no puede quedar más de lo que dura")

        if not isinstance(self.ejercicio, str):
            raise TypeError("el nombre del ejercicio tiene que ser texto")
        object.__setattr__(self, "ejercicio", self.ejercicio.strip())

        _exigir_entero("serie", self.serie)
        if self.serie < 0:
            raise ValueError("el número de serie no puede ser negativo")

        if not isinstance(self.corriendo, bool):
            raise TypeError("corriendo tiene que ser True o False")
        if not isinstance(self.aviso_dado, bool):
            raise TypeError("aviso_dado tiene que ser True o False")

    @property
    def terminado(self) -> bool:
        return self.restante <= 0

    @property
    def fraccion(self) -> float:
        """Lo consumido, de 0 a 1. Es lo que llena la barra de la franja."""
        if self.total <= 0:
            return 1.0
        return min(1.0, max(0.0, (self.total - self.restante) / self.total))

    def texto(self) -> str:
        """El reloj como se lee de pie: "1:30", "0:45"."""
        minutos, segundos = divmod(max(0, self.restante), 60)
        return f"{minutos}:{segundos:02d}"

    def titulo(self) -> str:
        """"Press de banca · serie 2", o solo "Descanso" si no se sabe."""
        if not self.ejercicio:
            return "Descanso"
        if not self.serie:
            return self.ejercicio
        return f"{self.ejercicio} · serie {self.serie}"


def empezar(segundos: int, *, ejercicio: str = "", serie: int = 0) -> Descanso:
    """Arranca un descanso. Se llama al MARCAR una serie, no al pulsar un botón.

    Que arranque solo es media función: nadie se acuerda de darle a un botón con
    las manos ocupadas, y un cronómetro que hay que arrancar a mano acaba no
    usándose. Lo pidió así el usuario.

    La duración se recorta al rango válido en vez de fallar: un ejercicio con un
    descanso raro guardado no puede impedir que se marque la serie.
    """
    _exigir_entero("segundos", segundos)
    limitado = max(SEGUNDOS_MINIMOS, min(SEGUNDOS_MAXIMOS, segundos))
    return Descanso(
        total=limitado, restante=limitado, ejercicio=ejercicio, serie=serie
    )


def correr(descanso: Descanso, segundos: int) -> Descanso:
    """Descuenta ese tiempo. Al llegar a cero se queda en cero y parado.

    NO SE ENCADENA NADA AQUÍ, igual que en el pomodoro: quien llama tiene que
    poder ver que terminó para pitar y sacar el aviso. Si esto reiniciara solo,
    el final del descanso —que es el único momento que importa— quedaría
    escondido dentro de esta función.
    """
    _exigir_entero("segundos", segundos)
    if segundos < 0:
        raise ValueError("no se puede correr hacia atrás")
    if not descanso.corriendo or descanso.terminado:
        return descanso
    return replace(descanso, restante=max(0, descanso.restante - segundos))


def toca_avisar(descanso: Descanso) -> bool:
    """Si toca el pitido corto de "quedan diez segundos".

    Se pregunta en vez de hacerlo aquí porque pitar es cosa del sistema, no del
    dominio. Y se mira `aviso_dado` para que suene UNA vez: sin eso sonaría en
    cada uno de los diez tics que quedan.
    """
    return (
        descanso.corriendo
        and not descanso.aviso_dado
        and 0 < descanso.restante <= AVISO_PREVIO
    )


def con_aviso_dado(descanso: Descanso) -> Descanso:
    return replace(descanso, aviso_dado=True)


def ajustar(descanso: Descanso, segundos: int) -> Descanso:
    """Suma o resta tiempo al descanso en marcha. Es lo que hacen los botones ±.

    SE MUEVEN LOS DOS, el total y lo que queda. Si solo se moviera lo restante,
    sumar quince segundos haría que la barra saltara hacia atrás; y si solo se
    moviera el total, el número no cambiaría y parecería que el botón no hace
    nada.

    Restar por debajo de cero deja el descanso TERMINADO, que es lo que quiere
    decir "-15" cuando quedan diez: ya está, siguiente serie.
    """
    _exigir_entero("segundos", segundos)
    restante = descanso.restante + segundos
    if restante <= 0:
        return replace(descanso, restante=0, corriendo=False)

    total = max(SEGUNDOS_MINIMOS, min(SEGUNDOS_MAXIMOS, descanso.total + segundos))
    restante = min(restante, total)
    return replace(
        descanso,
        total=total,
        restante=restante,
        # Si al sumar tiempo vuelve a quedar más del aviso previo, el pitido de
        # los últimos segundos tiene que poder sonar otra vez: es un descanso
        # nuevo a efectos de lo que queda.
        aviso_dado=descanso.aviso_dado and restante <= AVISO_PREVIO,
    )


def saltar(descanso: Descanso) -> Descanso:
    """Termina el descanso ahora. Sin pitido: lo has cortado tú, ya lo sabes."""
    return replace(descanso, restante=0, corriendo=False)


def _exigir_entero(nombre: str, valor: object) -> None:
    if isinstance(valor, bool) or not isinstance(valor, int):
        raise TypeError(f"{nombre} tiene que ser un entero")


# ---------------------------------------------------------------------------
# Escribir y leer una duración
# ---------------------------------------------------------------------------
#
# EL DESCANSO LO ELIGE LA PERSONA, ejercicio por ejercicio, y lo pidió así el
# usuario: "en este ejercicio quiero descansar treinta segundos, en este un
# minuto y medio". Antes venía de la ficha del ejercicio y era el mismo siempre.
#
# SE ACEPTAN TODAS LAS FORMAS DE ESCRIBIRLO porque de pie en el gimnasio nadie
# se acuerda de un formato: 90, 1:30, 1.30, 1.3, 1m30, 30s, "1 min 30". Y SE
# DEVUELVE SIEMPRE ESCRITO IGUAL ("1:30") en cuanto sales del campo, para que un
# error se vea al momento en vez de descubrirlo cuando suena cuando no toca.


DESCANSO_MINIMO = 0
"""Cero vale: hay ejercicios (el cardio) que no llevan descanso entre series."""

DESCANSO_MAXIMO = 30 * 60
"""Media hora. Mas que eso no es un descanso entre series, es otro entreno."""

DURACION_MAXIMA = 4 * 60 * 60
"""Cuatro horas: lo que dura como mucho un ejercicio de tiempo.

Es el mismo tope que ya tenian las series en dominio/sesion.py, y coincidir con
el importa: si aqui se aceptaran cinco horas, la pantalla dejaria escribirlas y
el dominio las rechazaria despues con un error que no dice nada."""

# Hasta cinco cifras: cuatro horas son 14400 segundos, y con cuatro cifras
# escribir el tope en segundos no se entendia. Lo cazo un test que probaba justo
# el valor maximo, que es donde se rompen estas cosas.
_SOLO_NUMERO = re.compile(r"^(\d{1,5})$")
_CON_SEGUNDOS = re.compile(r"^(\d{1,5})\s*s(?:eg(?:undos?)?)?$")
_CON_MINUTOS = re.compile(r"^(\d{1,3})\s*m(?:in(?:utos?)?)?$")
_MINUTOS_Y_SEGUNDOS = re.compile(
    r"^(\d{1,3})\s*(?::|\.|,|m(?:in(?:utos?)?)?)\s*(\d{1,2})\s*"
    r"(?:s(?:eg(?:undos?)?)?)?$"
)
_CON_HORAS = re.compile(r"^(\d{1,2})\s*h(?:oras?)?$")
_HORAS_Y_MINUTOS = re.compile(
    r"^(\d{1,2})\s*h(?:oras?)?\s*(\d{1,2})\s*(?:m(?:in(?:utos?)?)?)?$"
)
_RELOJ_COMPLETO = re.compile(r"^(\d{1,2}):(\d{1,2}):(\d{1,2})$")


def parsear_descanso(texto: str) -> int | None:
    """Los segundos que quieren decir esas letras. None si no se entiende.

    SE ACEPTAN TODAS LAS FORMAS porque de pie en el gimnasio nadie se acuerda de
    un formato concreto:

        "90"        ->  90 s        un numero suelto son SEGUNDOS
        "90s"       ->  90 s
        "1:30"      ->  90 s
        "1.30"      ->  90 s
        "1,30"      ->  90 s
        "1.3"       ->  90 s        un solo digito detras son DECENAS
        "1m30"      ->  90 s
        "1 min 30"  ->  90 s
        "2m"        -> 120 s
        "0"         ->   0 s

    LO DE "1.3" LO PIDIO EL USUARIO con estas palabras: "uno punto tres quiere
    decir un minuto treinta segundos". Es como se dice en voz alta, y por eso un
    solo digito detras del separador se completa a dos: 1.3 es 1:30, no 1:03.
    Con dos digitos no hay duda: 1.03 es 1:03.

    UN NUMERO SUELTO SON SEGUNDOS Y NO MINUTOS, siempre, sin excepciones por
    tamano. Es tentador decir "si escribe 2 seguro que son dos minutos", pero eso
    es adivinar, y adivinar aqui significa un cronometro que suena cuando no
    toca. Como la pantalla vuelve a escribir lo que entendio ("0:02"), una
    equivocacion se ve al instante en vez de descubrirse en el gimnasio.

    None Y NO UNA EXCEPCION: quien llama tiene que poder avisar en pantalla sin
    montar un try. Devolver un numero por defecto seria lo peor de todo, porque
    el error quedaria escondido.
    """
    return _entre(_leer(texto), DESCANSO_MINIMO, DESCANSO_MAXIMO)


def parsear_duracion(texto: str) -> int | None:
    """Lo mismo, pero para lo que DURA un ejercicio de tiempo.

    MISMAS REGLAS DE ESCRITURA que el descanso, para no tener que aprender dos.
    Lo unico que cambia es el tope: aqui llegan hasta cuatro horas, porque una
    caminata o una sesion de bici pasan de la media hora de sobra.

    Y ADEMAS ENTIENDE HORAS: "1h", "1h30", "1:30:00". Hacian falta justo aqui y
    no en el descanso: un descanso entre series de una hora no es un descanso.

    OJO CON UN CASO, y esta escrito aqui porque es el unico que puede
    sorprender: "1:30" siguen siendo un minuto y medio, igual que en el
    descanso, NO una hora y media. Para una hora y media se escribe "1h30" o
    "90min". Se ha dejado asi a proposito para que las dos casillas se lean con
    la misma regla; y como el campo reescribe lo que entendio, "1:30" frente a
    "1:30:00" se distingue de un vistazo.
    """
    return _entre(_leer(texto), 0, DURACION_MAXIMA)


def _leer(texto: str) -> int | None:
    """Los segundos que quieren decir esas letras, sin mirar ningun tope.

    Esta separado de los dos publicos porque las formas de escribir son las
    mismas y solo cambia el rango; escrito dos veces, en tres meses una de las
    dos habria aprendido un formato que la otra no.
    """
    if not isinstance(texto, str):
        return None
    limpio = texto.strip().lower().replace("\u00a0", " ")
    if not limpio:
        return None

    encaje = _SOLO_NUMERO.match(limpio)
    if encaje:
        return int(encaje.group(1))

    encaje = _CON_SEGUNDOS.match(limpio)
    if encaje:
        return int(encaje.group(1))

    encaje = _CON_MINUTOS.match(limpio)
    if encaje:
        return int(encaje.group(1)) * 60

    encaje = _HORAS_Y_MINUTOS.match(limpio)
    if encaje:
        minutos = int(encaje.group(2))
        if minutos >= 60:
            return None
        return int(encaje.group(1)) * 3600 + minutos * 60

    encaje = _CON_HORAS.match(limpio)
    if encaje:
        return int(encaje.group(1)) * 3600

    encaje = _RELOJ_COMPLETO.match(limpio)
    if encaje:
        minutos, segundos = int(encaje.group(2)), int(encaje.group(3))
        if minutos >= 60 or segundos >= 60:
            return None
        return int(encaje.group(1)) * 3600 + minutos * 60 + segundos

    encaje = _MINUTOS_Y_SEGUNDOS.match(limpio)
    if encaje:
        minutos = int(encaje.group(1))
        crudo = encaje.group(2)
        # Un solo digito son decenas de segundos: "1.3" es 1:30.
        segundos = int(crudo) * 10 if len(crudo) == 1 else int(crudo)
        if segundos >= 60:
            # "1:75" no es un minuto y cuarto de nada: es que te has equivocado.
            # Repartirlo por nuestra cuenta seria inventarse lo que quisiste
            # decir.
            return None
        return minutos * 60 + segundos

    return None


def texto_descanso(segundos: int) -> str:
    """Los segundos escritos como se leen de un vistazo: "1:30", "0:45", "3:00".

    SIEMPRE CON LA MISMA FORMA, aunque lo hayas escrito de otra. Es lo que
    convierte el campo en una respuesta: escribes "1.3", sales, y ves "1:30". Si
    hubieras querido decir un minuto y tres segundos, lo ves ahi mismo.
    """
    if isinstance(segundos, bool) or not isinstance(segundos, int):
        raise TypeError("el descanso tiene que ser un entero de segundos")
    minutos, resto = divmod(max(0, segundos), 60)
    return f"{minutos}:{resto:02d}"


def texto_descanso_largo(segundos: int) -> str:
    """Lo mismo pero en palabras: "1 min 30 s". Para las ayudas y los avisos,
    donde "1:30" solo se entiende si ya sabes que hablas de tiempo."""
    if isinstance(segundos, bool) or not isinstance(segundos, int):
        raise TypeError("el descanso tiene que ser un entero de segundos")
    if segundos < 60:
        return f"{segundos} s"
    minutos, resto = divmod(segundos, 60)
    return f"{minutos} min {resto} s" if resto else f"{minutos} min"


def _entre(segundos: int | None, minimo: int, maximo: int) -> int | None:
    if segundos is None:
        return None
    return segundos if minimo <= segundos <= maximo else None


def texto_duracion(segundos: int) -> str:
    """Lo que dura, escrito como se lee: "0:45", "30:00", "1:30:00".

    CON HORAS SOLO CUANDO LAS HAY. "90:00" para hora y media es correcto pero
    nadie lo lee asi, y ademas se confunde con noventa segundos a primera vista.
    """
    if isinstance(segundos, bool) or not isinstance(segundos, int):
        raise TypeError("la duracion tiene que ser un entero de segundos")
    horas, resto = divmod(max(0, segundos), 3600)
    minutos, sobra = divmod(resto, 60)
    if horas:
        return f"{horas}:{minutos:02d}:{sobra:02d}"
    return f"{minutos}:{sobra:02d}"
