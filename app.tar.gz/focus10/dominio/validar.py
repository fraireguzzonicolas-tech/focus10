"""Las dos comprobaciones que hacían falta en media docena de sitios.

ESTABAN COPIADAS SEIS VECES: cada archivo del dominio se escribía su propio
`_exigir_entero` y su propio `_exigir_texto`, palabra por palabra, y ya habían
empezado a separarse —uno decía de qué tipo era el valor y los demás no—. Seis
copias de la misma regla es una regla que algún día se corrige en cinco.

POR QUÉ SE COMPRUEBA EL TIPO Y NO SE CONFÍA EN LAS ANOTACIONES: Python no las
mira. Un `objetivo="8"` llegado de un campo de texto se guardaría tal cual y
reventaría tres pantallas más allá, lejos de donde está el fallo.

`True` NO ES UN ENTERO AQUÍ, aunque para Python lo sea: un `activo=True` colado
en un campo de cantidad valdría 1 y nadie se enteraría.
"""

from __future__ import annotations


def exigir_entero(nombre: str, valor: object) -> None:
    if isinstance(valor, bool) or not isinstance(valor, int):
        raise TypeError(
            f"{nombre} tiene que ser un entero, no {type(valor).__name__}"
        )


def exigir_texto(
    nombre: str, valor: object, largo: int, *, obligatorio: bool = False
) -> None:
    """Texto, sin pasarse de largo, y no vacío si es obligatorio.

    SE MIDE LO RECORTADO y no lo escrito: tres espacios al final no son tres
    caracteres de nombre, y un nombre de solo espacios está vacío.
    """
    if not isinstance(valor, str):
        raise TypeError(f"{nombre} tiene que ser texto, no {type(valor).__name__}")
    limpio = valor.strip()
    if obligatorio and not limpio:
        raise ValueError(f"{nombre} no puede estar vacío")
    if len(limpio) > largo:
        raise ValueError(
            f"{nombre} no puede pasar de {largo} caracteres "
            f"(llegaron {len(limpio)})"
        )
