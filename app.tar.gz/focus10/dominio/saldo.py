"""Cuánto dinero llevas ahorrado, y cuánto invertido.

EN QUÉ SE DIFERENCIA DE UN MOVIMIENTO: un movimiento es dinero que se mueve (un
gasto de 8,50 €); un saldo es una FOTO de lo que hay en un momento dado ("hoy
llevo 3.200 € ahorrados"). Por eso no tiene categoría ni signo: no entra ni sale
nada, solo se anota el estado.

POR QUÉ SE GUARDA CADA ACTUALIZACIÓN Y NO UN ÚNICO NÚMERO: decidido con el
usuario. Guardando cada foto con su fecha se puede ver cómo evoluciona el ahorro
sin ningún trabajo extra. Si solo se guardara el número de ahora, ese pasado no
se podría recuperar nunca.

POR QUÉ EL IMPORTE PUEDE SER CERO (y un movimiento no): tener cero ahorrado es
un dato perfectamente válido, y de hecho es el que más conviene poder anotar.
Un gasto de cero euros, en cambio, no es nada.

POR QUÉ LOS SALDOS NO TOCAN LOS TOTALES DE FINANZAS: el balance del mes son
ingresos menos gastos. Meter ahí lo ahorrado mezclaría "lo que ha pasado este
mes" con "lo que tengo", que son dos preguntas distintas.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum

from . import apunte, dinero
from .jornada import Horario, jornada_de
from .moneda import EUR, Moneda

LARGO_MAXIMO_NOTA = 200


class Clase(StrEnum):
    """Qué se está anotando.

    StrEnum porque el valor se guarda tal cual como texto en la base de datos.
    """

    AHORRO = "ahorro"
    INVERSION = "inversion"


ETIQUETAS = {Clase.AHORRO: "Ahorrado", Clase.INVERSION: "Invertido"}


@dataclass(frozen=True)
class Saldo:
    clase: Clase
    importe: int
    """Unidades mínimas de SU moneda. Cero o más."""

    moneda: Moneda
    momento: datetime
    jornada: date
    nota: str = ""
    """Para acordarse de por qué cambió: "vendí la moto", "pagué la matrícula"."""

    tasa: Decimal | None = None
    importe_principal: int | None = None
    id: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.clase, Clase):
            raise TypeError(f"clase tiene que ser Clase, no {type(self.clase).__name__}")
        if not isinstance(self.moneda, Moneda):
            raise TypeError("moneda tiene que ser una Moneda del catálogo")
        if isinstance(self.importe, bool) or not isinstance(self.importe, int):
            raise TypeError(f"importe tiene que ser int, no {type(self.importe).__name__}")
        if self.importe < 0:
            # Deber dinero no es un saldo negativo: sería otra cosa (una deuda)
            # y merecería su propia anotación el día que haga falta.
            raise ValueError(f"el importe no puede ser negativo, y llegó {self.importe}")

        apunte.exigir_momento(self.momento)
        apunte.exigir_jornada(self.jornada)

        if not isinstance(self.nota, str):
            raise TypeError("la nota tiene que ser texto")
        if len(self.nota) > LARGO_MAXIMO_NOTA:
            raise ValueError(
                f"la nota no puede pasar de {LARGO_MAXIMO_NOTA} caracteres "
                f"(llegaron {len(self.nota)})"
            )
        # El dataclass es frozen, así que normalizar exige saltarse la
        # inmutabilidad aquí dentro.
        object.__setattr__(self, "nota", self.nota.strip())

        apunte.exigir_conversion(self.tasa, self.importe_principal)

    # ----------------------------------------------------------------------

    @classmethod
    def nuevo(
        cls,
        *,
        clase: Clase,
        importe: int,
        momento: datetime,
        horario: Horario,
        moneda: Moneda = EUR,
        nota: str = "",
        principal: Moneda = EUR,
        tasa: Decimal | None = None,
    ) -> Saldo:
        """Crea una anotación calculando su jornada y su conversión.

        Igual que con los movimientos, obliga a pasar el horario para que la
        fecha salga de jornada_de() y nunca del reloj.
        """
        # datetime.now() siempre trae microsegundos, así que se recortan aquí.
        momento = momento.replace(microsecond=0)
        tasa_final, convertido = apunte.resolver_conversion(
            importe, moneda, principal, tasa
        )
        return cls(
            clase=clase,
            importe=importe,
            moneda=moneda,
            momento=momento,
            jornada=jornada_de(momento, horario),
            nota=nota,
            tasa=tasa_final,
            importe_principal=convertido,
        )

    # ----------------------------------------------------------------------

    @property
    def pendiente_de_cambio(self) -> bool:
        return self.tasa is None

    @property
    def etiqueta(self) -> str:
        return ETIQUETAS[self.clase]

    def texto_importe(self) -> str:
        return dinero.formatear(self.importe, self.moneda)

    def texto_importe_principal(self, principal: Moneda = EUR) -> str | None:
        """El importe convertido, o None si está pendiente."""
        if self.importe_principal is None:
            return None
        return dinero.formatear(self.importe_principal, principal)

    def con_tasa(self, tasa: Decimal, principal: Moneda = EUR) -> Saldo:
        """Devuelve una copia con la tasa resuelta. No modifica el original."""
        if not self.pendiente_de_cambio:
            raise ValueError(
                f"este saldo ya tiene tasa ({self.tasa}); no se reescribe"
            )
        tasa_final, convertido = apunte.resolver_conversion(
            self.importe, self.moneda, principal, tasa
        )
        return replace(self, tasa=tasa_final, importe_principal=convertido)


def variacion(nuevo: Saldo, anterior: Saldo | None) -> int | None:
    """Cuánto ha cambiado respecto a la anotación anterior, en la moneda
    principal. None si falta algún dato para saberlo.

    Devuelve None en vez de cero cuando no se puede calcular: un cero diría
    "no ha cambiado nada", que es una afirmación distinta de "no lo sé".
    """
    if anterior is None:
        return None
    if nuevo.importe_principal is None or anterior.importe_principal is None:
        return None
    return nuevo.importe_principal - anterior.importe_principal


@dataclass(frozen=True)
class Patrimonio:
    """Lo que hay en total, y lo que no se ha podido contar.

    Mismo criterio que los totales de finanzas: se da la suma de lo que SÍ se
    sabe y, al lado, la lista de lo que falta. Un total que finge estar completo
    es peor que no dar ninguno.
    """

    total: int
    faltan: tuple[str, ...]

    @property
    def esta_completo(self) -> bool:
        return not self.faltan


def calcular_patrimonio(saldos: dict[Clase, Saldo | None]) -> Patrimonio:
    """Suma los saldos que se pueden contar y apunta los que no.

    Un saldo puede no contarse por dos motivos distintos, y conviene
    distinguirlos: o nunca se anotó, o está en otra moneda sin convertir.
    """
    total = 0
    faltan: list[str] = []

    for clase, saldo in saldos.items():
        etiqueta = ETIQUETAS[clase].lower()
        if saldo is None:
            faltan.append(f"{etiqueta}: aún no lo has anotado")
        elif saldo.importe_principal is None:
            faltan.append(f"{etiqueta}: {saldo.texto_importe()} sin convertir")
        else:
            total += saldo.importe_principal

    return Patrimonio(total=total, faltan=tuple(faltan))
