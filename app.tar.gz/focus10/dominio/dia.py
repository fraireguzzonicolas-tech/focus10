"""El día de la aplicación, que lo cierra el usuario y no el reloj.

LA REGLA, con las palabras del usuario: "un día no termina por el paso del
tiempo; un día termina únicamente cuando el usuario lo finaliza explícitamente".

QUÉ HABÍA ANTES Y POR QUÉ SE VA: la jornada se calculaba a partir de una hora
configurada ("la jornada empieza a las 22:00"), así que a esa hora cambiaba el
día solo. Para quien se acuesta a las tres de la mañana eso parte la noche en
dos: media queda en un día y media en el siguiente, y el resumen del día no se
corresponde con lo que esa persona vivió.

LA FECHA REAL Y EL DÍA DE LA APLICACIÓN SON DOS COSAS. El día 17 puede empezar
un martes y cerrarse a las 03:30 del jueves. Por eso se guardan los dos datos:
el NÚMERO del día, que va seguido y no se salta ninguno, y la FECHA Y HORA REAL
en que se cerró, que es la que dice cuándo pasó de verdad.

POR QUÉ EL DÍA SIGUE TENIENDO UNA FECHA: todo lo demás de la aplicación —una
comida, un gasto, una marca de hábito— se guarda con una fecha, y los resúmenes
por semana y por mes se apoyan en ella. Cambiar eso sería reescribir media
aplicación para no ganar nada. El día tiene su fecha, y esa fecha es la del
momento REAL en que se abrió.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from .validar import exigir_entero

VALORACION_MINIMA = 1
VALORACION_MAXIMA = 10

LARGO_MINIMO_REFLEXION = 10
"""Lo que como mínimo tiene que escribirse al cerrar el día.

NO ES UN CAPRICHO NI ES MUCHO: el usuario pidió que la reflexión fuera
obligatoria "aunque se puede permitir una longitud mínima razonable". Diez
caracteres dejan pasar un "estuvo bien" y frenan un punto suelto puesto para
salir del paso, que es lo que convierte esta pantalla en un trámite.
"""

LARGO_MAXIMO_REFLEXION = 5000


@dataclass(frozen=True)
class Dia:
    """Un día de la aplicación: abierto, o cerrado con su nota y su valoración."""

    numero: int
    """El 1, el 2, el 3... Va seguido y no se salta ninguno."""

    jornada: date
    """La fecha con la que se guarda todo lo de este día.

    ES LA FECHA REAL EN QUE SE ABRIÓ. Si pasas dos días sin cerrar, esas fechas
    se quedan sin día: no existieron dentro de la aplicación, y eso es la verdad,
    no un hueco que haya que rellenar.
    """

    abierto_en: datetime
    """El momento real en que empezó."""

    cerrado_en: datetime | None = None
    """El momento real en que lo cerraste. None mientras siga abierto."""

    valoracion: int | None = None
    """Del 1 al 10. None mientras siga abierto."""

    reflexion: str = ""
    id: int | None = None

    def __post_init__(self) -> None:
        exigir_entero("numero", self.numero)
        if self.numero < 1:
            raise ValueError("los días se numeran desde 1")

        if not isinstance(self.jornada, date) or isinstance(self.jornada, datetime):
            raise TypeError("la jornada tiene que ser un date, no un datetime")
        if not isinstance(self.abierto_en, datetime):
            raise TypeError("abierto_en tiene que ser un datetime")

        if not isinstance(self.reflexion, str):
            raise TypeError("la reflexión tiene que ser texto")
        object.__setattr__(self, "reflexion", self.reflexion.strip())
        if len(self.reflexion) > LARGO_MAXIMO_REFLEXION:
            raise ValueError(
                f"la reflexión no puede pasar de {LARGO_MAXIMO_REFLEXION} letras"
            )

        # UN DÍA ESTÁ CERRADO O NO LO ESTÁ, y las tres cosas van juntas: la hora
        # de cierre, la valoración y la reflexión. Medio cerrado —con nota pero
        # sin hora, o al revés— sería un estado que ninguna pantalla sabría
        # pintar y que nadie podría arreglar.
        if self.cerrado_en is None:
            if self.valoracion is not None or self.reflexion:
                raise ValueError(
                    "un día sin cerrar no lleva valoración ni reflexión"
                )
            return

        if not isinstance(self.cerrado_en, datetime):
            raise TypeError("cerrado_en tiene que ser un datetime o None")
        if self.cerrado_en < self.abierto_en:
            raise ValueError("un día no puede cerrarse antes de abrirse")

        exigir_entero("valoracion", self.valoracion)
        if not VALORACION_MINIMA <= self.valoracion <= VALORACION_MAXIMA:
            raise ValueError(
                f"la valoración va de {VALORACION_MINIMA} a {VALORACION_MAXIMA}"
            )
        if len(self.reflexion) < LARGO_MINIMO_REFLEXION:
            raise ValueError(
                f"escribe al menos {LARGO_MINIMO_REFLEXION} letras de reflexión"
            )

    @property
    def abierto(self) -> bool:
        return self.cerrado_en is None

    def duracion(self):
        """Cuánto duró de verdad, o None si sigue abierto."""
        if self.cerrado_en is None:
            return None
        return self.cerrado_en - self.abierto_en

    def texto_duracion(self) -> str:
        """"19 h 45 min". Vacío si sigue abierto."""
        cuanto = self.duracion()
        if cuanto is None:
            return ""
        horas, resto = divmod(int(cuanto.total_seconds()), 3600)
        return f"{horas} h {resto // 60} min"


def siguiente(anterior: Dia, ahora: datetime) -> Dia:
    """El día que empieza cuando se cierra el anterior.

    LA FECHA ES LA DEL RELOJ EN ESE MOMENTO, no la del día anterior más uno. Si
    cierras el día 17 a las 03:30 del jueves, el 18 es el jueves: así las fechas
    siguen siendo fechas de verdad y el calendario del mes y la rejilla del año
    siguen queriendo decir algo.

    SI YA HABÍA UN DÍA CON ESA FECHA —cerrar dos veces en la misma tarde— el
    siguiente se lleva el día de después. No se puede repetir la fecha: es la
    clave con la que se guarda todo lo demás, y dos días con la misma fecha
    mezclarían sus comidas y sus gastos sin dar ningún error.
    """
    if not isinstance(ahora, datetime):
        raise TypeError("ahora tiene que ser un datetime")
    if anterior.abierto:
        raise ValueError("no se puede empezar el siguiente sin cerrar el anterior")

    from datetime import timedelta

    fecha = ahora.date()
    if fecha <= anterior.jornada:
        fecha = anterior.jornada + timedelta(days=1)

    return Dia(numero=anterior.numero + 1, jornada=fecha, abierto_en=ahora)

