"""Qué parte del músculo enfatiza un ejercicio, adivinada por su nombre.

LO PIDIÓ EL USUARIO ASÍ: "habría que enfatizar en qué parte del músculo; tipo
press inclinado trabaja pecho sí, pero trabaja más pecho superior; estaría bueno
que lo pongas de un color parecido pero otro tono, para aclarar que lo trabaja
más".

ESTO ADIVINA, Y HAY QUE SABERLO. Se lo dije al usuario y lo eligió él sabiéndolo:
la otra opción era guardar la zona como un dato de verdad en la ficha de cada
ejercicio. Aquí no hay dato: hay palabras buscadas en el nombre. Un ejercicio que
te crees tú y llames a tu manera puede quedar sin marcar, y en el peor caso mal
marcado.

TRES COSAS LIMITAN EL DAÑO, y son la diferencia entre adivinar y inventar:

1. CADA PALABRA SOLO CUENTA DENTRO DE SU GRUPO. "Lateral" quiere decir una cosa
   en hombro (deltoides lateral) y otra distinta en core (oblicuos); buscarla
   suelta las mezclaría. Aquí "lateral" en un ejercicio de pierna no dice nada.

2. SI NO HAY COINCIDENCIA, NO SE MARCA NADA. El músculo se pinta entero, como
   antes de todo esto. Un hueco es un hueco: no se rellena con la zona que más
   se parezca.

3. LA ZONA SE DICE EN EL TEXTO. Al pasar el ratón pone "Pecho, sobre todo la
   parte superior", así que si alguna vez se equivoca, se ve que se equivoca en
   vez de quedarse en un color raro que nadie sabe leer.
"""

from __future__ import annotations

import re
import unicodedata

from .ejercicio import Grupo

# LAS PALABRAS, POR GRUPO. Cada una lleva la zona que enciende.
#
# SE MIRAN EN ORDEN y gana la primera: importa, porque "peso muerto rumano" y
# "peso muerto" empiezan igual y no son el mismo ejercicio. Las más específicas
# van antes.
#
# TODAS SIN TILDES Y EN MINÚSCULA: el nombre que se compara también se limpia
# antes, para que "Jalón" y "jalon" sean lo mismo.
#
# UNA ZONA A None QUIERE DECIR "AQUÍ NO SE SABE", y sirve para parar una palabra
# de más abajo que se equivocaría. Es el hueco declarado a propósito.
PISTAS: dict[Grupo, tuple[tuple[str, str | None], ...]] = {
    Grupo.PECHO: (
        # LAS FLEXIONES VAN AL REVÉS QUE LA BANCA, y esto no es un capricho:
        # en banca, inclinado es con la cabeza arriba y trabaja el pecho
        # superior; en flexiones, inclinado es con las MANOS elevadas y trabaja
        # el pecho inferior. Salió al mirar los 285 ejercicios de verdad: las
        # cuatro flexiones estaban marcadas justo al contrario.
        #
        # VAN LAS PRIMERAS porque gana la primera que coincide, y si no,
        # "inclinad" las cazaría antes de llegar aquí.
        ("flexiones inclinad", "pecho inferior"),
        ("flexiones declinad", "pecho superior"),
        ("inclinad", "pecho superior"),
        ("declinad", "pecho inferior"),
        ("fondos", "pecho inferior"),
    ),
    Grupo.ESPALDA: (
        ("encogimiento", "espalda alta"),
        ("trapecio", "espalda alta"),
        ("face pull", "espalda alta"),
        # UNA HIPEREXTENSIÓN "ENFOCADA AL GLÚTEO" no enfatiza la lumbar: lo
        # dice su propio nombre. Y el glúteo no es una zona de la espalda, así
        # que la respuesta honesta es no marcar nada.
        ("enfocadas al gluteo", None),
        ("hiperextension", "lumbar"),
        ("buenos dias", "lumbar"),
        ("lumbar", "lumbar"),
        ("jalon", "dorsal"),
        ("dominad", "dorsal"),
        ("pullover", "dorsal"),
        ("remo", "dorsal"),
    ),
    Grupo.PIERNA: (
        ("gemelo", "gemelo"),
        ("pantorrilla", "gemelo"),
        ("soleo", "gemelo"),
        ("rumano", "isquiotibiales"),
        ("femoral", "isquiotibiales"),
        ("isquio", "isquiotibiales"),
        ("hip thrust", "gluteo"),
        ("gluteo", "gluteo"),
        ("patada", "gluteo"),
        ("extension de cuadriceps", "cuadriceps"),
        ("sentadilla", "cuadriceps"),
        ("prensa", "cuadriceps"),
        ("zancada", "cuadriceps"),
        ("bulgara", "cuadriceps"),
    ),
    Grupo.HOMBRO: (
        ("pajaro", "hombro posterior"),
        ("posterior", "hombro posterior"),
        ("face pull", "hombro posterior"),
        ("lateral", "hombro lateral"),
        ("frontal", "hombro anterior"),
    ),
    Grupo.CORE: (
        ("oblicu", "oblicuos"),
        ("lateral", "oblicuos"),
        ("russian", "oblicuos"),
        ("giro", "oblicuos"),
        ("leñador", "oblicuos"),
        ("plancha", "abdomen"),
        ("crunch", "abdomen"),
        ("abdominal", "abdomen"),
        ("elevacion de piernas", "abdomen"),
    ),
}

COMO_SE_LEE = {
    "pecho superior": "sobre todo la parte superior",
    "pecho inferior": "sobre todo la parte inferior",
    "espalda alta": "sobre todo la parte alta",
    "dorsal": "sobre todo el dorsal",
    "lumbar": "sobre todo la zona lumbar",
    "cuadriceps": "sobre todo el cuádriceps",
    "isquiotibiales": "sobre todo los isquiotibiales",
    "gluteo": "sobre todo el glúteo",
    "gemelo": "sobre todo el gemelo",
    "hombro anterior": "sobre todo la parte delantera",
    "hombro lateral": "sobre todo la parte lateral",
    "hombro posterior": "sobre todo la parte trasera",
    "abdomen": "sobre todo el abdomen",
    "oblicuos": "sobre todo los oblicuos",
}


def sin_tildes(texto: str) -> str:
    """"Jalón" -> "jalon". Para que la tilde no decida si algo se marca o no."""
    descompuesto = unicodedata.normalize("NFD", texto.lower())
    return "".join(uno for uno in descompuesto if unicodedata.category(uno) != "Mn")


def zona_de(nombre: str, grupo: Grupo) -> str | None:
    """La zona que enfatiza ese ejercicio, o None si no se sabe.

    None NO ES UN FALLO: es la respuesta honesta para un press de banca plano,
    que trabaja el pecho y ya está, y para cualquier ejercicio que se llame de
    una forma que aquí no se reconoce.

    LAS PALABRAS TIENEN QUE EMPEZAR DONDE EMPIEZA UNA PALABRA, y esto salió de
    revisar los 285 ejercicios de verdad: "Press de hombro UNILATERAL" se estaba
    marcando como deltoides lateral porque "unilateral" lleva "lateral" dentro.
    Buscar el trozo suelto encontraba palabras dentro de otras palabras.

    NO SE EXIGE QUE ACABEN DONDE ACABA LA PALABRA, y también a propósito:
    "inclinad" tiene que cazar "inclinado" y "inclinadas".
    """
    limpio = sin_tildes(nombre)
    for pista, zona in PISTAS.get(grupo, ()):
        if re.search(r"\b" + re.escape(sin_tildes(pista)), limpio):
            return zona
    return None
