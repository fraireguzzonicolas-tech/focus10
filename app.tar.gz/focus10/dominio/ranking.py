"""Los puntos del ranking de la Comunidad: cómo se cuentan, sin saber de dónde salen.

LO PIDIÓ EL USUARIO (7 nov 2026): la Comunidad deja de ser una red social y
pasa a ser SOLO una competencia: quién es el número 1 en constancia. Eligió:

  - por MES CALENDARIO, más una tabla de siempre;
  - «equilibrado»: hábito cumplido 10, entreno terminado 40, día con algo
    hecho 15, y +1 por cada día de la racha más larga del mes;
  - un hábito suma una vez por día, y como mucho 12 hábitos por día (para que
    nadie gane creando cincuenta hábitos de «respirar»);
  - SOLO CUENTA LO APUNTADO A TIEMPO: ese día, con 2 días de margen por si
    estabas sin internet. Marcar de golpe todo el mes pasado no da puntos.

LA HORA QUE MANDA ES LA DEL SERVIDOR (`llegada`): cuándo llegó la fila a la
nube. La del aparato se puede cambiar tocando el reloj del teléfono; la del
servidor, no. Ver servidor/ranking.sql.

ESTE ARCHIVO LO USA EL SERVIDOR, no la aplicación: los puntos de todos se
calculan allí, con lo que cada uno ya sincroniza. Si los calculara cada
aparato, bastaría con tocar el programa para mandar «tengo 9.000».
"""

from __future__ import annotations

import calendar
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta, timezone

PUNTOS_HABITO = 10
PUNTOS_ENTRENO = 40
PUNTOS_DIA = 15
PUNTOS_RACHA = 1
"""Por cada día de la racha más larga del mes."""

HABITOS_POR_DIA = 12
ENTRENOS_POR_DIA = 2
"""Dos y no uno: hay quien hace gimnasio por la mañana y movilidad a la tarde
(los bloques de la rutina). Más de dos al día ya no es entrenar, es sumar."""

ENTRENO_MINIMO = 10 * 60
"""Un entreno de menos de diez minutos no cuenta: empezar y terminar en el
acto daría 40 puntos por tocar dos botones."""

MARGEN = timedelta(days=3)
"""Hasta cuándo puede llegar algo de un día: el día, más dos de margen.

TRES DÍAS DESDE LA MEDIANOCHE EN HORA UNIVERSAL, y no dos: el día de alguien
en Argentina termina tres horas después de la medianoche universal, y el de
alguien en Japón nueve antes. Con tres, el último minuto del segundo día de
margen entra en cualquier sitio del mundo.
"""


@dataclass(frozen=True)
class Marca:
    """Lo apuntado de un hábito un día, desde UN aparato (se suman entre sí)."""

    habito: str
    dia: date
    cantidad: int
    llegada: datetime


@dataclass(frozen=True)
class Entreno:
    dia: date
    segundos: int
    cronometrado: bool
    llegada: datetime


@dataclass(frozen=True)
class Puntaje:
    habitos: int = 0
    entrenos: int = 0
    dias: int = 0
    racha: int = 0
    puntos: int = 0
    por_dia: tuple[int, ...] = field(default_factory=tuple)
    """Los puntos ACUMULADOS al final de cada día del mes. Es lo que dibuja la
    evolución del puesto a lo largo del mes."""


def a_tiempo(dia: date, llegada: datetime) -> bool:
    """Si algo de ese día llegó a la nube dentro del margen."""
    limite = datetime.combine(dia, time(0), tzinfo=timezone.utc) + MARGEN
    return llegada < limite


def dias_del_mes(mes: date) -> list[date]:
    ultimo = calendar.monthrange(mes.year, mes.month)[1]
    return [date(mes.year, mes.month, d) for d in range(1, ultimo + 1)]


def puntaje(
    objetivos: dict[str, int],
    marcas: list[Marca],
    entrenos: list[Entreno],
    mes: date,
    hasta: date | None = None,
) -> Puntaje:
    """Los puntos de UNA persona en un mes.

    `objetivos`: el objetivo diario de cada hábito que existe (por su nombre de
    sincronización). Un hábito borrado no está, y sus marcas no cuentan.
    `hasta`: el último día que se cuenta (hoy, en el mes en curso).
    """
    # LO DE OTROS MESES NO SE FILTRA AQUÍ: abajo solo se recorren los días
    # de este, y lo demás no llega a sumarse.
    dias = [d for d in dias_del_mes(mes) if hasta is None or d <= hasta]

    sumas: dict[tuple[str, date], int] = {}
    for m in marcas:
        if m.habito in objetivos and a_tiempo(m.dia, m.llegada):
            clave = (m.habito, m.dia)
            sumas[clave] = sumas.get(clave, 0) + m.cantidad
    habitos_del_dia: dict[date, int] = {}
    for (habito, dia), cantidad in sumas.items():
        if cantidad >= objetivos[habito]:
            habitos_del_dia[dia] = habitos_del_dia.get(dia, 0) + 1

    entrenos_del_dia: dict[date, int] = {}
    for e in entrenos:
        if e.cronometrado and e.segundos >= ENTRENO_MINIMO and a_tiempo(e.dia, e.llegada):
            entrenos_del_dia[e.dia] = entrenos_del_dia.get(e.dia, 0) + 1

    total_habitos = total_entrenos = activos = racha = racha_mas_larga = 0
    acumulado = 0
    por_dia = []
    for dia in dias:
        h = min(HABITOS_POR_DIA, habitos_del_dia.get(dia, 0))
        e = min(ENTRENOS_POR_DIA, entrenos_del_dia.get(dia, 0))
        total_habitos += h
        total_entrenos += e
        activo = bool(h or e)
        racha = racha + 1 if activo else 0
        # LA RACHA SE PAGA SOLO LO QUE CRECE: así el acumulado de cada día ya
        # incluye la racha más larga hasta ese día, y el último coincide con
        # el total.
        crece = max(0, racha - racha_mas_larga)
        racha_mas_larga = max(racha_mas_larga, racha)
        activos += activo
        acumulado += (h * PUNTOS_HABITO + e * PUNTOS_ENTRENO
                      + (PUNTOS_DIA if activo else 0) + crece * PUNTOS_RACHA)
        por_dia.append(acumulado)

    return Puntaje(
        habitos=total_habitos, entrenos=total_entrenos, dias=activos,
        racha=racha_mas_larga, puntos=acumulado, por_dia=tuple(por_dia),
    )


@dataclass(frozen=True)
class Puesto:
    puesto: int
    alias: str
    puntos: int


def clasificar(puntos: dict[str, int]) -> list[Puesto]:
    """La tabla: de más a menos puntos. EMPATADOS COMPARTEN PUESTO (1, 1, 3),
    como en cualquier competencia; entre ellos, por orden alfabético."""
    orden = sorted(puntos.items(), key=lambda par: (-par[1], par[0]))
    tabla: list[Puesto] = []
    for i, (alias, pts) in enumerate(orden):
        puesto = tabla[-1].puesto if tabla and tabla[-1].puntos == pts else i + 1
        tabla.append(Puesto(puesto, alias, pts))
    return tabla


def puestos_por_dia(puntajes: dict[str, Puntaje], alias: str) -> list[int]:
    """En qué puesto estaba esa persona al terminar cada día del mes.

    UN DÍA SIN NADIE CON PUNTOS NO ES UN PUESTO: todos empatarían en el 1, y la
    línea diría que ibas primero cuando nadie había empezado. Ese día va 0.
    """
    if alias not in puntajes:
        return []
    largo = len(puntajes[alias].por_dia)
    salida = []
    for i in range(largo):
        del_dia = {a: p.por_dia[i] for a, p in puntajes.items() if i < len(p.por_dia)}
        if not any(del_dia.values()):
            salida.append(0)
            continue
        salida.append(next(x.puesto for x in clasificar(del_dia) if x.alias == alias))
    return salida
