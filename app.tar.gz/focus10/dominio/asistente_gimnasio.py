"""El asistente y el gimnasio: anotar series, corregirlas y terminar el entreno.

«Hoy hice press banca, 4 series de 10 con 60 kg», «en la última serie levanté
65 kg», «registrá 30 minutos de carrera», «completé mi entrenamiento».

SE ANOTA EN EL ENTRENO DE HOY, el mismo que ves en Gimnasio: si ya estabas
entrenando ese ejercicio, se completan sus series planeadas en orden (sin
tocar las ya hechas); si no, se suma el ejercicio. Las series van MARCADAS:
decir «hice» es decir que se hicieron.

EL EJERCICIO SE BUSCA EN TU BIBLIOTECA por sus palabras («press banca»
encuentra «Press de banca plano con barra»). Si encajan varios, gana el que
hiciste hace poco; si sigue habiendo varios, se pregunta cuál. Lo pidió el
usuario: «si no identifica claramente el ejercicio o la serie, preguntar».
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date, datetime

from .asistente_tipos import Decir, Hacer
from .descanso import texto_duracion
from .ejercicio import Ejercicio, Medida
from .palabras import palabras, singular
from .rutina import parsear_peso
from .sesion import EjercicioDeSesion, Serie, Sesion

RELLENO = frozenset({"de", "del", "con", "en", "la", "el", "a", "al"})


def _claves(texto: str) -> set[str]:
    return {singular(p) for p in palabras(texto) if p not in RELLENO}


def buscar_ejercicio(
    nombre: str, biblioteca: list[Ejercicio], recientes: set[int]
) -> Ejercicio | list[Ejercicio] | None:
    """El ejercicio de la biblioteca que se llama así. Una lista si hay dudas."""
    buscadas = _claves(nombre)
    if not buscadas:
        return None
    exactos = [uno for uno in biblioteca if _claves(uno.nombre) == buscadas]
    if len(exactos) == 1:
        return exactos[0]
    encajan = exactos or [uno for uno in biblioteca if buscadas <= _claves(uno.nombre)]
    if len(encajan) == 1:
        return encajan[0]
    hechos = [uno for uno in encajan if uno.id in recientes]
    if len(hechos) == 1:
        return hechos[0]
    return encajan or None


def _series(crudas: list, de_tiempo: bool) -> list[Serie] | str:
    """Las series dichas, o un texto con lo que no se entendió."""
    series: list[Serie] = []
    for numero, cruda in enumerate(crudas, start=1):
        cruda = cruda or {}
        try:
            if de_tiempo:
                segundos = int(cruda.get("segundos") or 0)
                if segundos <= 0:
                    return "¿Cuánto tiempo fue?"
                series.append(Serie(numero=numero, segundos=segundos, hecha=True))
            else:
                peso = parsear_peso(str(cruda.get("peso") or "0"))
                repeticiones = int(cruda.get("repeticiones") or 0)
                if peso is None:
                    return f"No entendí el peso de la serie {numero}."
                if repeticiones <= 0:
                    return f"¿Cuántas repeticiones hiciste en la serie {numero}?"
                series.append(Serie(numero=numero, peso=peso, repeticiones=repeticiones, hecha=True))
        except (TypeError, ValueError):
            return f"No entendí la serie {numero}."
    return series


def _cual(nombre: str, biblioteca: list[Ejercicio], recientes: set[int]) -> Ejercicio | Decir:
    encontrado = buscar_ejercicio(nombre, biblioteca, recientes)
    if encontrado is None:
        return Decir(f"No tengo «{nombre}» en tu biblioteca. Agregalo en Gimnasio y la próxima lo anoto.")
    if isinstance(encontrado, list):
        nombres = ", ".join(f"«{uno.nombre}»" for uno in encontrado[:4])
        return Decir(f"¿Cuál? {nombres}.")
    return encontrado


@dataclass(frozen=True)
class AnotarSeries:
    ejercicio: Ejercicio
    series: tuple[Serie, ...]
    jornada: date

    def frase(self) -> str:
        textos = [texto_duracion(s.segundos) if s.segundos else s.texto() for s in self.series]
        if len(set(textos)) == 1 and len(textos) > 1:
            return f"anoté {self.ejercicio.nombre}: {len(textos)} series de {textos[0]}"
        return f"anoté {self.ejercicio.nombre}: {', '.join(textos)}"


@dataclass(frozen=True)
class CorregirSerie:
    ejercicio: EjercicioDeSesion
    serie: Serie

    def frase(self) -> str:
        return f"corregí la serie {self.serie.numero} de {self.ejercicio.nombre}: {self.serie.texto()}"


@dataclass(frozen=True)
class TerminarEntreno:
    sesion: Sesion
    segundos: int

    def frase(self) -> str:
        return f"terminé el entreno de hoy: {self.sesion.series_hechas} series"


def decidir_anotar(
    datos: dict, biblioteca: list[Ejercicio], recientes: set[int], jornada: date
) -> Decir | Hacer:
    ejercicio = _cual(str(datos.get("ejercicio") or ""), biblioteca, recientes)
    if isinstance(ejercicio, Decir):
        return ejercicio
    crudas = datos.get("series")
    if not isinstance(crudas, list) or not crudas:
        return Decir(f"¿Cuántas series de {ejercicio.nombre} y de cuánto?")
    series = _series(crudas, ejercicio.medida is Medida.TIEMPO)
    if isinstance(series, str):
        return Decir(series)
    return Hacer(AnotarSeries(ejercicio, tuple(series), jornada))


def _ultimo_tocado(sesion: Sesion) -> EjercicioDeSesion | None:
    """El último ejercicio con algo hecho, por su orden en el entreno."""
    con_algo = [uno for uno in sesion.ejercicios if uno.hechas]
    return max(con_algo, key=lambda uno: uno.orden) if con_algo else None


def decidir_corregir(
    datos: dict, sesion: Sesion | None, biblioteca: list[Ejercicio], recientes: set[int]
) -> Decir | Hacer:
    """«Ejercicio» vacío = el último que tocaste; «serie» 0 = su última hecha."""
    if sesion is None:
        return Decir("Hoy no hay ningún entreno para corregir.")
    nombre = str(datos.get("ejercicio") or "").strip()
    if nombre:
        elegido = _cual(nombre, biblioteca, recientes)
        if isinstance(elegido, Decir):
            return elegido
        ejercicio = next((uno for uno in sesion.ejercicios if uno.ejercicio_id == elegido.id), None)
        if ejercicio is None:
            return Decir(f"Hoy no hiciste {elegido.nombre}.")
    else:
        ejercicio = _ultimo_tocado(sesion)
        if ejercicio is None:
            return Decir("¿De qué ejercicio?")
    numero = datos.get("serie")
    if not isinstance(numero, int) or isinstance(numero, bool) or numero <= 0:
        hechas = [s for s in ejercicio.series if s.hecha]
        if not hechas:
            return Decir(f"¿Qué serie de {ejercicio.nombre}?")
        numero = hechas[-1].numero
    serie = ejercicio.serie(numero)
    if serie is None:
        return Decir(f"{ejercicio.nombre} no tiene serie {numero}.")
    cambios: dict = {}
    peso_dicho = str(datos.get("peso") or "").strip()
    if peso_dicho:
        peso = parsear_peso(peso_dicho)
        if peso is None:
            return Decir("No entendí el peso.")
        cambios["peso"] = peso
    repeticiones = datos.get("repeticiones")
    if isinstance(repeticiones, int) and not isinstance(repeticiones, bool) and repeticiones > 0:
        cambios["repeticiones"] = repeticiones
    if not cambios:
        return Decir("¿Qué cambio: el peso o las repeticiones?")
    try:
        nueva = replace(serie, **cambios)
    except ValueError as fallo:
        return Decir(f"No pude corregirla: {fallo}.")
    return Hacer(CorregirSerie(ejercicio, nueva))


def decidir_terminar(sesion: Sesion | None, ahora: datetime) -> Decir | Hacer:
    if sesion is None or not sesion.series_hechas:
        return Decir("Hoy no hay ningún entreno con series hechas.")
    if sesion.segundos:
        return Decir("El entreno de hoy ya estaba terminado.")
    duracion = sesion.duracion(ahora)
    # UN SEGUNDO COMO MÍNIMO, como en la pantalla: cero es «sin terminar».
    return Hacer(TerminarEntreno(sesion, max(1, duracion) if sesion.empezada_en else 0))
