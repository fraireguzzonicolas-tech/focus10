"""El asistente y el dinero: apuntar un gasto o un ingreso.

LAS MISMAS REGLAS QUE LA VENTANITA DE «NUEVO GASTO»: la categoría tiene que
existir, el importe tiene que entenderse, y en las categorías que recuerdan se
pregunta antes si parece un pago repetido (ver memoria_gastos.py).
"""

from __future__ import annotations

from dataclasses import dataclass

from . import dinero, memoria_gastos
from .asistente_tipos import Confirmar, Decir, Hacer
from .categoria import Categoria, Memoria
from .memoria_gastos import Recordado
from .moneda import Moneda, MonedaDesconocida, por_codigo
from .movimiento import Tipo
from .palabras import normalizar

TIPOS = {
    "gasto": Tipo.GASTO,
    "ingreso": Tipo.INGRESO,
    # EL AHORRO ES APARTAR, NO INGRESAR: lo decidió el usuario. «Gané 50,
    # ponelo en el ahorro» es UN movimiento de ahorro, no un ingreso más un
    # ahorro: el ahorro sube 50 y no se cuenta un ingreso.
    "ahorro": Tipo.AHORRO,
    "sacar_ahorro": Tipo.RETIRADA_AHORRO,
}

VERBOS = {
    Tipo.GASTO: "apunté",
    Tipo.INGRESO: "apunté el ingreso de",
    Tipo.AHORRO: "aparté al ahorro",
    Tipo.RETIRADA_AHORRO: "saqué del ahorro",
}


@dataclass(frozen=True)
class Apuntar:
    """Un movimiento listo para apuntar: ya comprobado, con su categoría de verdad."""

    tipo: Tipo
    importe: int
    moneda: Moneda
    descripcion: str
    categoria: Categoria

    def frase(self) -> str:
        cuanto = dinero.formatear(self.importe, self.moneda)
        if self.tipo in (Tipo.AHORRO, Tipo.RETIRADA_AHORRO):
            return f"{VERBOS[self.tipo]} {cuanto}"
        de_que = f" para {self.descripcion}" if self.descripcion else ""
        return f"{VERBOS[self.tipo]} {cuanto}{de_que} en {self.categoria.nombre}"


def buscar_categoria(nombre: str, categorias: list[Categoria]) -> Categoria | None:
    """La categoría con ese nombre, sin mirar mayúsculas ni tildes."""
    buscado = normalizar(nombre).strip()
    return next((una for una in categorias if normalizar(una.nombre) == buscado), None)


def decidir(
    datos: dict, categorias: list[Categoria], memoria: list[Recordado], principal: Moneda
) -> Decir | Hacer | Confirmar:
    """Qué hace Focus con un «registrar_movimiento».

    NADA SE APUNTA A MEDIAS NI ADIVINADO: si falta la categoría o el importe no
    se entiende, se pregunta. Es lo mismo que hace la ventanita con un importe
    que no entiende.
    """
    tipo = TIPOS.get(str(datos.get("tipo") or ""))
    if tipo is None:
        return Decir("¿Es un gasto, un ingreso o algo para el ahorro?")

    escrita = str(datos.get("moneda") or "").strip()
    try:
        moneda = por_codigo(escrita) if escrita else principal
    except MonedaDesconocida:
        return Decir(f"No conozco la moneda «{escrita}». ¿En qué moneda fue?")

    importe = dinero.parsear_importe(str(datos.get("importe") or ""), moneda)
    if importe is None or importe <= 0:
        return Decir("No entendí el importe. ¿Cuánto fue?")

    de_ese_tipo = [una for una in categorias if una.tipo is tipo]
    categoria = buscar_categoria(str(datos.get("categoria") or ""), de_ese_tipo)
    # SI NO SE DIJO NINGUNA Y HAY UNA SOLA, ES ESA: el ahorro tiene una
    # («Ahorro») y preguntar por lo obvio sería un mensaje de más. Si se dijo
    # una que no existe, se pregunta: elegir otra en su lugar sería adivinar.
    nombrada = str(datos.get("categoria") or "").strip()
    if categoria is None and not nombrada and len(de_ese_tipo) == 1:
        categoria = de_ese_tipo[0]
    if categoria is None:
        nombres = ", ".join(una.nombre for una in de_ese_tipo[:6])
        return Decir(f"¿En qué categoría lo apunto? Por ejemplo: {nombres}.")

    descripcion = str(datos.get("descripcion") or "").strip()
    orden = Apuntar(tipo, importe, moneda, descripcion, categoria)
    # SOLO LAS CATEGORÍAS DE GASTO QUE RECUERDAN AVISAN, como en la ventanita.
    # Una en «Preguntar más adelante» cuenta como que no: no se le hace esa
    # pregunta a alguien que va manejando.
    if tipo is Tipo.GASTO and categoria.memoria is Memoria.SI:
        pregunta = memoria_gastos.aviso(
            importe, moneda, memoria_gastos.parecidos(descripcion, memoria)
        )
        if pregunta:
            return Confirmar(orden, pregunta)
    return Hacer(orden)
