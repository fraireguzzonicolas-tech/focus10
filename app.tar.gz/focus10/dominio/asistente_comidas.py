"""El asistente y las comidas: «comí 200 g de arroz, 50 g de atún y 2 huevos».

CLAUDE SEPARA, FOCUS CALCULA (lo eligió el usuario), y Claude estima solo lo
que Focus no sabe (lo eligió el 26 oct 2026: «tiene que poner un aprox de
proteína»). Los números de cada alimento salen de aquí, en este orden:

1. LO TUYO: si ya apuntaste ese alimento en esa misma cantidad, sus números
   (los que decidiste vos la última vez). Lo tuyo gana a la tabla.
2. LA TABLA DE FOCUS (estimar_comida.py), con «≈»: es una estimación.
3. LO TUYO EN OTRA CANTIDAD, en proporción («100 g» apuntados y hoy «150 g»).
   Así lo que estimó Claude una vez, Focus lo sabe la siguiente.
4. LA ESTIMACIÓN DE CLAUDE, con «≈ estimado por el asistente». Viene en la
   misma respuesta, sin otro mensaje que pagar, y se revisa antes de usarla.
5. SI AUN ASÍ NO SE SABE, se apunta lo demás y se pregunta por eso (lo eligió
   el usuario: «apunta lo que sabe y pregunta el resto»).

CADA ALIMENTO ES UN APUNTE, con su cantidad. Así «en realidad eran 250 g de
arroz» toca solo el arroz, y la app aprende cada alimento por separado.

SIN «DESAYUNO» NI «ALMUERZO»: el usuario le pidió a la app que no lo pregunte
(«yo pongo el nombre…»), y WhatsApp sigue la misma regla.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import date, datetime, timedelta

from .alimento import DECIMAS_MAXIMAS, KCAL_MAXIMAS, Registro
from .asistente_tipos import Decir, Hacer
from .estimar_comida import estimar
from .palabras import mismo_nombre, normalizar

MAXIMO_ALIMENTOS = 15
"""Por mensaje. Más que eso es un error de lectura, no una comida."""

NOTA_ESTIMADO = "≈ estimado por Focus"
NOTA_ASISTENTE = "≈ estimado por el asistente"
NOTA_PROPORCION = "≈ en proporción a lo que apuntaste"

Numeros = tuple[int, int, int, int]
"""(kcal, proteínas, carbohidratos, grasas), los macros en décimas de gramo."""


def _gramos(decimas: int) -> str:
    return f"{decimas / 10:.0f}"


def texto_de(registro: Registro) -> str:
    """«200 g de arroz», «2 huevos», «café con leche»."""
    if registro.unidad:
        return f"{registro.cantidad} {registro.unidad} de {registro.nombre}"
    if registro.cantidad:
        return f"{registro.cantidad} {registro.nombre}"
    return registro.nombre


def _lista(cosas: list[str]) -> str:
    return cosas[0] if len(cosas) == 1 else ", ".join(cosas[:-1]) + " y " + cosas[-1]


def _no_se(cuales: tuple[str, ...]) -> str:
    nombres = _lista([f"«{uno}»" for uno in cuales])
    return (
        f"No sé cuánto aporta {nombres}: decime cuánto pesó de otra forma, o "
        "apuntalo vos en Alimentación y la próxima lo sé."
    )


@dataclass(frozen=True)
class RegistrarComida:
    registros: tuple[Registro, ...]
    estimado: bool
    """Si algún número es aproximado (y no exactamente lo que apuntaste vos)."""
    faltan: tuple[str, ...] = ()
    """Lo que no se pudo calcular: no se apunta y se pregunta."""

    def frase(self) -> str:
        signo = "≈ " if self.estimado else ""
        kcal = sum(r.kcal for r in self.registros)
        prot = sum(r.proteinas for r in self.registros)
        carb = sum(r.carbohidratos for r in self.registros)
        gras = sum(r.grasas for r in self.registros)
        frase = (
            f"apunté {_lista([texto_de(r) for r in self.registros])}: {signo}{kcal} kcal, "
            f"{_gramos(prot)} g de proteína, {_gramos(carb)} g de carbohidratos y "
            f"{_gramos(gras)} g de grasa"
        )
        return f"{frase}. {_no_se(self.faltan)}" if self.faltan else frase


def _dia(texto: str, jornada: date) -> date | None:
    """«» u «hoy» -> el día abierto; «ayer»; o una fecha AAAA-MM-DD."""
    texto = normalizar(texto).strip()
    if texto in ("", "hoy"):
        return jornada
    if texto == "ayer":
        return jornada - timedelta(days=1)
    try:
        return date.fromisoformat(texto)
    except ValueError:
        return None


def _cantidad(texto: str) -> float | None:
    """«150», «1,5», «1/2» -> el número; None si no lo es o no es positivo."""
    arriba, barra, abajo = texto.replace(",", ".").partition("/")
    try:
        valor = float(arriba) / float(abajo) if barra else float(arriba)
    except (ValueError, ZeroDivisionError):
        return None
    return valor if valor > 0 else None


def de_claude(crudo: dict) -> Numeros | None:
    """La estimación que mandó Claude para ESA cantidad, o None si no sirve.

    SE REVISA ANTES DE CREERLA: un número de un modelo puede salir mal. Las
    kcal tienen que ser positivas y los macros no pueden aportar más energía
    que las kcal (4 por gramo de proteína o hidrato, 9 de grasa). Al revés sí
    puede pasar —el alcohol aporta kcal sin macros—, así que solo se mira ese
    lado. Lo que no pasa, no se usa: se pregunta.
    """
    numeros = [crudo.get(clave) for clave in ("kcal", "proteina", "carbohidratos", "grasa")]
    if any(
        isinstance(n, bool) or not isinstance(n, (int, float)) or not math.isfinite(n)
        for n in numeros
    ):
        # isfinite: un NaN pasa todas las comparaciones de abajo como si nada.
        return None
    kcal, prot, carb, gras = numeros
    if not 0 < kcal <= KCAL_MAXIMAS:
        return None
    if any(g < 0 or g * 10 > DECIMAS_MAXIMAS for g in (prot, carb, gras)):
        return None
    if 4 * prot + 4 * carb + 9 * gras > 1.3 * kcal + 20:
        return None
    return round(kcal), round(prot * 10), round(carb * 10), round(gras * 10)


def numeros_de(
    alimento: str, cantidad: str, unidad: str, conocidas: list[Registro],
    estimacion_de_claude: Numeros | None = None,
) -> tuple[Numeros, str] | None:
    """Los números y la nota que los acompaña («» = exactos, lo tuyo), o None
    si no se saben. En el orden de la cabecera.

    LA USAN APUNTAR Y CORREGIR: «en realidad eran 250 g» se recalcula igual
    que la primera vez, no con otra cuenta.
    """
    def numeros(registro: Registro) -> Numeros:
        return registro.kcal, registro.proteinas, registro.carbohidratos, registro.grasas

    mismos = [r for r in conocidas if mismo_nombre(r.nombre, alimento)]
    tuyo = next((r for r in mismos if r.cantidad == cantidad and r.unidad == unidad), None)
    if tuyo is not None:
        return numeros(tuyo), ""
    estimacion = estimar(f"{cantidad} {unidad} {alimento}".strip())
    if estimacion is not None:
        return (
            (estimacion.kcal, estimacion.proteinas, estimacion.carbohidratos, estimacion.grasas),
            NOTA_ESTIMADO,
        )
    hoy = _cantidad(cantidad)
    base = next((r for r in mismos if r.unidad == unidad and _cantidad(r.cantidad)), None)
    if hoy is not None and base is not None:
        factor = hoy / _cantidad(base.cantidad)
        proporcional = tuple(round(n * factor) for n in numeros(base))
        return proporcional, base.nota or NOTA_PROPORCION
    if estimacion_de_claude is not None:
        return estimacion_de_claude, NOTA_ASISTENTE
    return None


def decidir_comida(
    datos: dict, jornada: date, ahora: datetime, conocidas: list[Registro]
) -> Decir | Hacer:
    """Qué hace Focus con un «registrar_comida»."""
    alimentos = datos.get("alimentos")
    if not isinstance(alimentos, list) or not alimentos:
        return Decir("¿Qué comiste y cuánto?")
    if len(alimentos) > MAXIMO_ALIMENTOS:
        return Decir("Son demasiadas cosas juntas. ¿Me las mandás en dos mensajes?")
    dia = _dia(str(datos.get("dia") or ""), jornada)
    if dia is None or dia > jornada:
        return Decir("¿Qué día fue?")
    momento = datetime.combine(dia, ahora.time().replace(microsecond=0))

    registros: list[Registro] = []
    estimado = False
    no_se: list[str] = []
    for crudo in alimentos:
        crudo = crudo if isinstance(crudo, dict) else {}
        alimento = str(crudo.get("alimento") or "").strip()
        cantidad = str(crudo.get("cantidad") or "").strip()
        unidad = str(crudo.get("unidad") or "").strip()
        if not alimento:
            continue
        hallado = numeros_de(alimento, cantidad, unidad, conocidas, de_claude(crudo))
        if hallado is None:
            no_se.append(alimento)
            continue
        numeros, nota = hallado
        estimado = estimado or bool(nota)
        try:
            registros.append(Registro(
                nombre=alimento, jornada=dia, momento=momento, cantidad=cantidad,
                unidad=unidad, kcal=numeros[0], proteinas=numeros[1],
                carbohidratos=numeros[2], grasas=numeros[3], nota=nota,
            ))
        except (TypeError, ValueError):
            no_se.append(alimento)

    if not registros:
        return Decir(_no_se(tuple(no_se))) if no_se else Decir("¿Qué comiste y cuánto?")
    return Hacer(RegistrarComida(tuple(registros), estimado, tuple(no_se)))
