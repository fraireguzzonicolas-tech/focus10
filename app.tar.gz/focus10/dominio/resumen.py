"""Sumar movimientos sin mentir cuando falta algún tipo de cambio.

EL PROBLEMA QUE RESUELVE: si hay un gasto de 85 US$ que se apuntó sin internet,
no se puede saber cuántos euros son. Hay tres formas de responder "cuánto he
gastado este mes" y dos son malas:

  - Ignorar el pendiente y dar el total como si estuviera completo: miente.
  - No dar ningún total hasta que se resuelva: inútil.
  - Dar el total de lo que SÍ se puede convertir, y decir claramente qué queda
    fuera. Esto es lo que se hace aquí, y es la decisión que tomó el usuario.

Por eso sumar() no devuelve un número: devuelve un Total que lleva encima la
lista de lo que no pudo convertir. Quien lo enseñe está obligado a ver que
existe, en vez de poder olvidarse.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass

from . import dinero
from .moneda import EUR, Moneda
from .movimiento import Movimiento, Tipo


@dataclass(frozen=True)
class Total:
    principal: Moneda
    convertido: int
    """Suma en unidades mínimas de la moneda principal, contando SOLO los
    movimientos que tenían tasa."""

    cuantos: int
    """Cuántos movimientos entraron en la suma."""

    pendientes: tuple[Movimiento, ...]
    """Los que no se pudieron convertir. Vacío en el caso normal."""

    @property
    def hay_pendientes(self) -> bool:
        return bool(self.pendientes)

    @property
    def esta_completo(self) -> bool:
        """True si el total refleja absolutamente todo lo que se le pasó."""
        return not self.pendientes

    def sin_convertir_por_moneda(self) -> dict[str, int]:
        """Lo que queda fuera, agrupado por moneda: {"USD": 8500}.

        Agrupado porque el aviso útil es "85 US$ sin convertir", no "hay 1
        movimiento raro".
        """
        por_moneda: dict[str, int] = defaultdict(int)
        for movimiento in self.pendientes:
            por_moneda[movimiento.moneda.codigo] += movimiento.importe
        return dict(por_moneda)

    def texto(self) -> str:
        """El total escrito, listo para enseñar."""
        return dinero.formatear(self.convertido, self.principal)

    def texto_aviso(self) -> str | None:
        """El aviso de lo que falta, o None si no falta nada.

        Devuelve None (y no una cadena vacía) para que quien lo use tenga que
        decidir expresamente qué hacer cuando no hay nada que avisar.
        """
        if not self.pendientes:
            return None
        trozos = [
            dinero.formatear(importe, _moneda_de(codigo, self.pendientes))
            for codigo, importe in sorted(self.sin_convertir_por_moneda().items())
        ]
        cuantos = len(self.pendientes)
        movimientos = "movimiento" if cuantos == 1 else "movimientos"
        return (
            f"{cuantos} {movimientos} sin convertir ({', '.join(trozos)}): "
            "el total no los incluye"
        )


def sumar(
    movimientos: Iterable[Movimiento],
    *,
    tipo: Tipo | None = None,
    principal: Moneda = EUR,
) -> Total:
    """Suma los movimientos en la moneda principal, apartando los pendientes.

    Con `tipo` se suman solo los gastos o solo los ingresos; sin él, todos
    (que casi nunca tiene sentido, pero no es esta función quien debe decidirlo).
    """
    if tipo is not None and not isinstance(tipo, Tipo):
        raise TypeError(f"tipo tiene que ser Tipo o None, no {type(tipo).__name__}")

    convertido = 0
    cuantos = 0
    pendientes: list[Movimiento] = []

    for movimiento in movimientos:
        if not isinstance(movimiento, Movimiento):
            raise TypeError(f"esto no es un Movimiento: {movimiento!r}")
        if tipo is not None and movimiento.tipo is not tipo:
            continue
        # SE PREGUNTA POR ESTA MONEDA, no solo si tiene conversion. Un gasto
        # convertido a euros no sirve para un total en dolares por muy
        # convertido que este: el numero existe, pero no es de esa unidad.
        #
        # Antes se sumaba `importe_principal` a ciegas, y al cambiar la moneda
        # principal el total salia mal sin dar ningun error. Ahora esos
        # movimientos caen en `pendientes`, que es la lista que la pantalla
        # esta obligada a ensenar.
        if not movimiento.cuenta_en(principal):
            pendientes.append(movimiento)
            continue
        convertido += movimiento.importe_principal
        cuantos += 1

    return Total(
        principal=principal,
        convertido=convertido,
        cuantos=cuantos,
        pendientes=tuple(pendientes),
    )


def _moneda_de(codigo: str, movimientos: Iterable[Movimiento]) -> Moneda:
    """La moneda ya viene dentro de los movimientos, así que se coge de ahí en
    vez de volver a buscarla en el catálogo."""
    for movimiento in movimientos:
        if movimiento.moneda.codigo == codigo:
            return movimiento.moneda
    raise KeyError(codigo)
