"""Lo que se guarda de una pizarra: su documento, en JSON.

QUIÉN HACE QUÉ: la pizarra que se ve y se edita es una pieza de Flutter
(extensiones/focus10_pizarra); ella decide qué es un trazo, una forma o una
flecha. Aquí solo se lee y se guarda el documento entero, y se convierten las
páginas del formato de antes.

LAS PÁGINAS DE ANTES (del 7 al 11 nov 2026) SE CONVIERTEN AL ABRIRLAS, no con
una migración: así también se convierte una que llegue de la nube en el
formato viejo, y si algo no se entiende no se pierde la página entera.
"""

from __future__ import annotations

import json
import math

MAXIMO_BYTES = 1_000_000
"""Lo que puede pesar el documento de una pizarra. EL MISMO TOPE QUE LA TABLA
(migracion_41: contenido ≤ 1 MB) y que la nube aguanta sin problema en una fila.
Las imágenes no van aquí dentro (llegan en la fase 4, aparte)."""

RENGLON = 32
"""El renglón de las páginas de antes; la pizarra nueva usa el mismo paso."""

PRIMER_RENGLON = RENGLON * 2

BASE_LETRA = {14: 21.7, 18: 22.3, 26: 25.7}
"""Dónde se apoyaban las letras de las páginas de antes: lo que baja la base de
la letra desde el borde de arriba del texto, medido el 8 nov 2026 con una foto
de la letra de Focus (estilo.FUENTE) en renglones de 32. Hace falta para que lo
que estaba escrito sobre una raya siga sobre la raya al convertirlo."""

ENCIMA_DE_LA_RAYA = 2


class DocumentoLleno(ValueError):
    """El documento pesaría más de MAXIMO_BYTES."""


def vacio() -> dict:
    return {"version": 1, "elementos": [], "rejilla": True}


def desde_guardado(texto: str | None) -> dict:
    """El documento guardado, en el formato nuevo. NUNCA FALLA: lo que no se
    entiende da una pizarra vacía o se salta, la página se abre igual."""
    try:
        datos = json.loads(texto or "{}")
    except (TypeError, ValueError):
        return vacio()
    if not isinstance(datos, dict):
        return vacio()
    if isinstance(datos.get("elementos"), list):
        datos.setdefault("rejilla", True)
        return datos
    if "trazos" in datos or "textos" in datos or "fondo" in datos:
        return _de_la_hoja_vieja(datos)
    return vacio()


def a_guardado(documento: dict) -> str:
    """El documento como JSON compacto. Si pasa del tope, DocumentoLleno (y no
    se guarda nada: lo de antes queda intacto)."""
    salida = json.dumps(documento, ensure_ascii=False, separators=(",", ":"))
    if len(salida.encode("utf-8")) > MAXIMO_BYTES:
        raise DocumentoLleno(len(salida))
    return salida


# ------------------------------------------------------------ el formato viejo


def _base(tamano: int) -> float:
    return BASE_LETRA.get(tamano, RENGLON / 2 + 0.38 * tamano) + ENCIMA_DE_LA_RAYA


def _apoyado(arriba: float, tamano: int, fondo: str) -> float:
    """El borde de arriba con que se dibujaba un texto viejo: sobre la raya más
    cercana (en una hoja con rayas)."""
    if fondo == "liso":
        return arriba
    base = _base(tamano)
    raya = max(PRIMER_RENGLON, round((arriba + base) / RENGLON) * RENGLON)
    return raya - base


def _de_la_hoja_vieja(datos: dict) -> dict:
    fondo = datos.get("fondo") if datos.get("fondo") in ("rayado", "cuadriculado", "liso") else "rayado"
    elementos: list[dict] = []
    for i, uno in enumerate(datos.get("trazos") or []):
        try:
            puntos = [float(n) for n in uno["p"]]
            if not puntos or len(puntos) % 2 or not all(math.isfinite(n) for n in puntos):
                continue
            elementos.append({
                "tipo": "trazo", "id": f"viejo-t{i}", "color": str(uno.get("c") or "tinta"),
                "grosor": float(uno.get("g") or 2), "puntos": puntos,
            })
        except (TypeError, ValueError, KeyError):
            continue
    for i, uno in enumerate(datos.get("textos") or []):
        try:
            tamano = int(uno.get("s") or 18)
            elementos.append({
                "tipo": "texto", "id": f"viejo-x{i}", "x": float(uno["x"]),
                "y": round(_apoyado(float(uno["y"]), tamano, fondo), 1),
                "texto": str(uno["t"]), "tamano": tamano,
                "color": str(uno.get("c") or "tinta"), "ancho": float(uno.get("a", 520)),
            })
        except (TypeError, ValueError, KeyError):
            continue
    # LA HOJA LISA NO TENÍA RAYAS: sin cuadrícula. Las otras sí.
    return {"version": 1, "elementos": elementos, "rejilla": fondo != "liso"}
