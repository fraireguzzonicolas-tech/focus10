"""Las posiciones y sus operaciones: unidades, coste medio y ganancia.

LA CANTIDAD Y EL PRECIO MEDIO NO SE GUARDAN EN NINGÚN SITIO. Se calculan siempre
a partir de la lista de operaciones. Es lo que pidió el usuario y es la decisión
más importante del archivo: si se guardaran, habría dos versiones de la verdad —
la guardada y la que sale de las operaciones— y el día que no cuadren no habrá
forma de saber cuál está bien.

EL FALLO QUE DIO ORIGEN A LA MITAD DE ESTE ARCHIVO: en una versión anterior la
columna se llamaba solo "Cantidad", y el usuario metió ahí los EUROS INVERTIDOS
en vez de las participaciones. La aplicación multiplicó por el precio y le dijo
que tenía 49.959 € invertidos cuando eran 761 €. No fue un fallo de cálculo: fue
que la etiqueta no decía lo que el campo esperaba.

De ahí salen tres cosas que están aquí a propósito:

  1. DOS FORMAS DE APUNTAR UNA COMPRA, cada una con su nombre entero:
     `compra_por_dinero` (pones euros y precio, salen las unidades) y
     `compra_por_unidades` (pones unidades y precio, salen los euros). No hay
     una función genérica que acepte "cantidad": ese nombre es el que engañó.
  2. `vista_previa`, que escribe en palabras lo que se va a guardar ANTES de
     guardarlo. Con ella, el error de los 49.959 € se ve en la pantalla.
  3. La palabra "unidades" no se usa nunca para hablar de dinero, ni al revés.

CÓMO SE GUARDAN LOS NÚMEROS:

  - El dinero, en unidades mínimas enteras (céntimos), como en todo el programa.
  - Las unidades, en MILLONÉSIMAS enteras. Los fondos y ETFs se compran por
    fracciones (0,7614 participaciones), y con decimales de coma flotante sumar
    treinta compras acumula error. Enteros y una constante, igual que el dinero.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import date, datetime
from decimal import ROUND_HALF_UP, Decimal
from enum import StrEnum

from .moneda import EUR, Moneda

UNIDADES_POR_ENTERO = 1_000_000
"""Una participación son un millón de millonésimas: seis decimales.

Seis y no dos porque los brókeres reparten fracciones muy pequeñas al reinvertir,
y redondear a dos decimales en cada compra se come dinero de verdad al cabo de
treinta operaciones.
"""

LARGO_MAXIMO_NOMBRE = 60
LARGO_MAXIMO_TICKER = 20

_SOLO_CIFRAS_Y_SEPARADORES = re.compile(r"[0-9.,]+")

LIMITE_UNIDADES = 10**15
"""Tope de cordura, no de mercado: evita que un dedo torpe descuadre la pantalla."""


class TipoOperacion(StrEnum):
    COMPRA = "compra"
    VENTA = "venta"
    DIVIDENDO = "dividendo"


class TipoActivo(StrEnum):
    ACCION = "acción"
    ETF = "ETF"
    FONDO = "fondo"
    CRIPTO = "cripto"
    OTRO = "otro"


@dataclass(frozen=True)
class Operacion:
    """Una compra, una venta o un dividendo. Es el único dato que se guarda."""

    tipo: TipoOperacion
    fecha: date
    unidades: int = 0
    """En millonésimas. Cero en los dividendos: no cambian lo que tienes."""

    precio: int = 0
    """Lo que costaba cada unidad, en céntimos. Cero en los dividendos."""

    importe: int = 0
    """Solo para los dividendos: lo cobrado, en céntimos."""

    posicion_id: int | None = None
    id: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.tipo, TipoOperacion):
            raise TypeError("el tipo tiene que ser un TipoOperacion")
        if not isinstance(self.fecha, date) or isinstance(self.fecha, datetime):
            raise TypeError("la fecha tiene que ser un date, no un datetime")

        for campo in ("unidades", "precio", "importe"):
            valor = getattr(self, campo)
            if isinstance(valor, bool) or not isinstance(valor, int):
                raise TypeError(f"{campo} tiene que ser un entero")
            if valor < 0:
                raise ValueError(f"{campo} no puede ser negativo")

        if self.unidades > LIMITE_UNIDADES or self.precio > LIMITE_UNIDADES:
            raise ValueError("ese número es demasiado grande")

        if self.tipo is TipoOperacion.DIVIDENDO:
            if self.unidades or self.precio:
                raise ValueError(
                    "un dividendo no lleva unidades ni precio: solo lo cobrado"
                )
            if self.importe <= 0:
                raise ValueError("un dividendo tiene que ser de más de cero")
        else:
            if self.importe:
                raise ValueError(
                    "el importe es solo para los dividendos; en compras y ventas "
                    "sale de las unidades por el precio"
                )
            if self.unidades <= 0:
                raise ValueError(f"una {self.tipo.value} tiene que llevar unidades")

    @property
    def coste(self) -> int:
        """Lo que movió esta operación, en céntimos."""
        if self.tipo is TipoOperacion.DIVIDENDO:
            return self.importe
        return _redondear(
            Decimal(self.unidades) * Decimal(self.precio) / UNIDADES_POR_ENTERO
        )


@dataclass(frozen=True)
class Posicion:
    """Lo que tienes de algo. Ni las unidades ni el coste medio se guardan aquí."""

    nombre: str
    ticker: str
    tipo: TipoActivo
    moneda: Moneda = EUR
    precio_actual: int | None = None
    """El último precio conocido, en céntimos. None si no hay ninguno todavía."""

    id: int | None = None

    def __post_init__(self) -> None:
        for campo, largo in (
            ("nombre", LARGO_MAXIMO_NOMBRE),
            ("ticker", LARGO_MAXIMO_TICKER),
        ):
            valor = getattr(self, campo)
            if not isinstance(valor, str):
                raise TypeError(f"{campo} tiene que ser texto")
            limpio = valor.strip()
            if not limpio:
                raise ValueError(f"{campo} no puede estar vacío")
            if len(limpio) > largo:
                raise ValueError(f"{campo} no puede pasar de {largo} caracteres")
            object.__setattr__(self, campo, limpio)
        object.__setattr__(self, "ticker", self.ticker.upper())

        if not isinstance(self.tipo, TipoActivo):
            raise TypeError("el tipo tiene que ser un TipoActivo")
        if self.precio_actual is not None:
            if isinstance(self.precio_actual, bool) or not isinstance(
                self.precio_actual, int
            ):
                raise TypeError("el precio actual tiene que ser un entero o None")
            if self.precio_actual < 0:
                raise ValueError("el precio actual no puede ser negativo")


@dataclass(frozen=True)
class Resumen:
    """Lo que se enseña en la tabla, todo calculado desde las operaciones."""

    unidades: int
    """En millonésimas."""

    invertido: int
    """Lo que te queda puesto, en céntimos. Coste medio × unidades."""

    precio_medio: int
    """Céntimos por unidad. Cero si no queda nada."""

    dividendos: int
    """Lo cobrado en dividendos, en céntimos. NO toca el precio medio: lo decidió
    el usuario, y así el precio de compra sigue siendo lo que pagaste."""

    realizado: int
    """Ganancia ya materializada al vender, en céntimos.

    NO SE ENSEÑA EN LA TABLA, por decisión del usuario: la tabla se queda con las
    seis columnas que pidió. Se calcula igualmente porque es la otra mitad de la
    resta que hace la venta —lo que sale de "invertido" va aquí— y tenerlo
    permite comprobar en los tests que vender no se come dinero por el camino.
    """

    precio_actual: int | None

    @property
    def valor(self) -> int | None:
        """Lo que vale hoy, en céntimos. None sin precio actual: no se inventa."""
        if self.precio_actual is None:
            return None
        return _redondear(
            Decimal(self.unidades) * Decimal(self.precio_actual) / UNIDADES_POR_ENTERO
        )

    @property
    def ganancia(self) -> int | None:
        """Lo latente: lo que vale hoy menos lo que te queda puesto."""
        valor = self.valor
        return None if valor is None else valor - self.invertido

    @property
    def diferencia_por_unidad(self) -> int | None:
        """Lo que ha subido o bajado CADA unidad desde que la compraste.

        Es otra forma de mirar lo mismo que la ganancia, y hace falta las dos: la
        ganancia te dice cuánto dinero es, y esta te dice si el activo se ha
        movido mucho o poco, que es lo que se compara con lo que dicen las
        noticias.
        """
        if self.precio_actual is None or not self.unidades:
            return None
        return self.precio_actual - self.precio_medio

    @property
    def rentabilidad(self) -> float | None:
        """De 0 a 1 (o negativo). None si no hay precio o no hay nada invertido."""
        ganancia = self.ganancia
        if ganancia is None or not self.invertido:
            return None
        return ganancia / self.invertido

    @property
    def tiene_algo(self) -> bool:
        return self.unidades > 0


def calcular(operaciones: Iterable[Operacion], precio_actual: int | None = None) -> Resumen:
    """El estado de la posición a partir de sus operaciones. Coste medio móvil.

    CÓMO FUNCIONA EL COSTE MEDIO MÓVIL, en corto: cada compra suma unidades y
    suma su dinero al montón; el precio medio es el montón entre las unidades.
    Una VENTA saca unidades al precio medio del momento, así que el precio medio
    NO cambia al vender: lo que cambia es cuántas te quedan. La diferencia entre
    lo que te dieron y lo que te costaban va a `realizado`.

    Las operaciones se ordenan por fecha antes de calcular: el coste medio
    depende del orden, y una lista que llegue desordenada daría otro número.
    """
    unidades = 0
    invertido = 0
    dividendos = 0
    realizado = 0

    for operacion in sorted(_validadas(operaciones), key=_orden):
        if operacion.tipo is TipoOperacion.DIVIDENDO:
            dividendos += operacion.importe
            continue

        if operacion.tipo is TipoOperacion.COMPRA:
            unidades += operacion.unidades
            invertido += operacion.coste
            continue

        # Venta: no se puede vender más de lo que hay. Se vende lo que queda y se
        # sigue, en vez de reventar: los datos vienen de un archivo que puede
        # estar tocado, y una posición rara no puede impedir ver el resto.
        vendidas = min(operacion.unidades, unidades)
        if not vendidas:
            continue
        coste_de_lo_vendido = _redondear(
            Decimal(invertido) * Decimal(vendidas) / Decimal(unidades)
        )
        cobrado = _redondear(
            Decimal(vendidas) * Decimal(operacion.precio) / UNIDADES_POR_ENTERO
        )
        unidades -= vendidas
        invertido -= coste_de_lo_vendido
        realizado += cobrado - coste_de_lo_vendido

    # AQUÍ HABÍA UNA GUARDA "si no quedan unidades, poner invertido a cero", por
    # miedo a que el redondeo dejara una posición fantasma de 0,01 €. La quité al
    # descubrir, rompiéndola a propósito, que ningún test podía notar su
    # ausencia. Y no era casualidad: cuando la venta se lleva TODAS las unidades,
    # `coste_de_lo_vendido` es `invertido * vendidas / unidades` con vendidas
    # igual a unidades, o sea `invertido` exacto, sin redondeo ninguno. Lo
    # comprobé además a la fuerza bruta con 200.000 secuencias de compras y
    # ventas al azar: el resto fue cero siempre.
    #
    # Las unidades tampoco pueden quedar negativas, porque la venta ya está
    # limitada con min() a lo que hay.

    return Resumen(
        unidades=unidades,
        invertido=invertido,
        precio_medio=_redondear(
            Decimal(invertido) * UNIDADES_POR_ENTERO / Decimal(unidades)
        )
        if unidades
        else 0,
        dividendos=dividendos,
        realizado=realizado,
        precio_actual=precio_actual,
    )


# ---------------------------------------------------------------------------
# Las DOS formas de apuntar una compra. Cada una con su nombre entero.
# ---------------------------------------------------------------------------


def compra_por_unidades(unidades: int, precio: int, fecha: date) -> Operacion:
    """"Compré N participaciones a X € cada una". Los euros salen de la cuenta."""
    return Operacion(
        tipo=TipoOperacion.COMPRA, unidades=unidades, precio=precio, fecha=fecha
    )


def unidades_por_dinero(dinero: int, precio: int) -> int:
    """Cuántas unidades salen de poner ese dinero a ese precio.

    Es la cuenta que evita el fallo de los 49.959 €: quien pone euros recibe
    unidades, y nunca se confunden los dos números porque cada uno entra por su
    puerta y sale por la contraria.
    """
    if isinstance(dinero, bool) or not isinstance(dinero, int):
        raise TypeError("el dinero tiene que ser un entero de céntimos")
    if isinstance(precio, bool) or not isinstance(precio, int):
        raise TypeError("el precio tiene que ser un entero de céntimos")
    if dinero <= 0:
        raise ValueError("el dinero invertido tiene que ser mayor que cero")
    if precio <= 0:
        raise ValueError("el precio tiene que ser mayor que cero")
    return _redondear(Decimal(dinero) * UNIDADES_POR_ENTERO / Decimal(precio))


def compra_por_dinero(dinero: int, precio: int, fecha: date) -> Operacion:
    """"Puse X € a Y € la unidad". Las unidades salen de la cuenta."""
    return compra_por_unidades(unidades_por_dinero(dinero, precio), precio, fecha)


def vista_previa(operacion: Operacion, moneda: Moneda = EUR) -> str:
    """Lo que se va a guardar, escrito en palabras, ANTES de guardarlo.

    Es la pieza que habría cazado el fallo de los 49.959 €: con esta frase
    delante, "se guardará como 49959 unidades" salta a la vista antes de que
    nadie pulse Guardar.

    Vive en el dominio y no en la pantalla para poder probarla: comprobar un
    texto de aviso dándole a un botón es mucho más frágil que comprobarlo aquí.
    """
    from .dinero import formatear

    if operacion.tipo is TipoOperacion.DIVIDENDO:
        return f"se guardará como un dividendo de {formatear(operacion.importe, moneda)}"

    verbo = "comprarán" if operacion.tipo is TipoOperacion.COMPRA else "venderán"
    return (
        f"se {verbo} {texto_unidades(operacion.unidades)} unidades a "
        f"{formatear(operacion.precio, moneda)} cada una = "
        f"{formatear(operacion.coste, moneda)} en total"
    )


def texto_unidades(unidades: int) -> str:
    """Las unidades como se leen: "0,7614", "12", "1.250,5".

    Se quitan los ceros de la derecha: "12,000000" no dice nada que no diga "12",
    y una columna llena de ceros hace más difícil ver la coma.
    """
    if isinstance(unidades, bool) or not isinstance(unidades, int):
        raise TypeError("las unidades tienen que ser un entero")
    signo = "-" if unidades < 0 else ""
    enteras, resto = divmod(abs(unidades), UNIDADES_POR_ENTERO)
    miles = f"{enteras:,}".replace(",", ".")
    if not resto:
        return f"{signo}{miles}"
    decimales = f"{resto:06d}".rstrip("0")
    return f"{signo}{miles},{decimales}"


def parsear_unidades(texto: str) -> int | None:
    """Las unidades escritas, en millonésimas. None si no se entiende.

    POR QUÉ NO SE REUTILIZA EL LECTOR DE IMPORTES: lo intenté, pasándole una
    moneda falsa de seis decimales, y Moneda se negó — no admite más de cuatro,
    porque no existe ninguna moneda con más. Tenía razón en negarse: las
    participaciones no son dinero y colarlas por la puerta del dinero habría
    sido exactamente la clase de confusión que costó el fallo de los 49.959 €.

    Las reglas son las mismas que las del dinero, con seis decimales en vez de
    dos: el ÚLTIMO separador es el decimal, y un punto con tres cifras justas
    detrás es separador de miles.
    """
    if not isinstance(texto, str):
        return None

    limpio = texto.strip().replace(" ", "")
    if not limpio or not _SOLO_CIFRAS_Y_SEPARADORES.fullmatch(limpio):
        return None

    corte = max(limpio.rfind("."), limpio.rfind(","))
    if corte == -1:
        return int(limpio) * UNIDADES_POR_ENTERO if limpio.isdigit() else None

    decimales = limpio[corte + 1 :]
    entera = limpio[:corte]

    if 1 <= len(decimales) <= 6 and decimales.isdigit():
        enteras = _parte_entera(entera)
        if enteras is not None:
            # "0,5" son medio, no cinco millonésimas: se rellena a la derecha.
            return enteras * UNIDADES_POR_ENTERO + int(decimales.ljust(6, "0"))

    # No era un decimal: la última lectura posible es separador de miles.
    if len(decimales) == 3 and decimales.isdigit():
        completo = _parte_entera(limpio)
        if completo is not None:
            return completo * UNIDADES_POR_ENTERO
    return None


def _parte_entera(texto: str) -> int | None:
    """La parte de delante de la coma, con o sin separadores de miles."""
    if not texto:
        return 0
    grupos = texto.replace(",", ".").split(".")
    if not all(grupo.isdigit() for grupo in grupos):
        return None
    if len(grupos) > 1:
        # Los de detrás, de tres cifras justas; el primero, sin ceros delante.
        if any(len(grupo) != 3 for grupo in grupos[1:]):
            return None
        if not grupos[0] or (len(grupos[0]) > 1 and grupos[0].startswith("0")):
            return None
    return int("".join(grupos))


def _validadas(operaciones: Iterable[Operacion]) -> list[Operacion]:
    lista = list(operaciones)
    for operacion in lista:
        if not isinstance(operacion, Operacion):
            raise TypeError(f"esto no es una Operacion: {operacion!r}")
    return lista


def _orden(operacion: Operacion) -> tuple:
    # A igual fecha manda el id: dos operaciones del mismo día son normales, y
    # sin desempate el coste medio saldría distinto según cómo llegaran.
    return (operacion.fecha, operacion.id or 0)


def _redondear(valor: Decimal) -> int:
    return int(valor.quantize(Decimal(1), rounding=ROUND_HALF_UP))
