"""Lo que se come: un registro por cosa, con los números que acepta el usuario.

UN REGISTRO NO SABE DE DÓNDE SALIERON SUS NÚMEROS, y es a propósito. Pueden
haberlos escrito a mano, venir de una comida suya de otro día o de una
estimación de estimar_comida.py; en los tres casos el usuario los vio y dio a
guardar. Aquí no se analiza nada ni se rellena nada: se valida y se guarda.

POR QUÉ LA ESTIMACIÓN VIVE EN OTRO ARCHIVO Y CON FRENOS: una versión muy
anterior calculaba las calorías sola y le puso 29 kcal a 300 gramos de fideos.
Durante un tiempo la regla fue no estimar nunca; el usuario la cambió a
sabiendas, y los frenos que la hacen segura están escritos en estimar_comida.py.

POR QUÉ LA CANTIDAD Y LA UNIDAD SON TEXTO: porque de ellas no se deriva nada. Son
para que TÚ te acuerdes de qué te comiste: "300" y "g", o "1" y "plato hondo".
Guardarlas como número obligaría a decidir qué hacer con "1 puñado", y esa
decisión es justo la que sobra. Las calorías las escribes tú, no salen de aquí.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime
from .validar import exigir_texto

LARGO_MAXIMO_NOMBRE = 80
LARGO_MAXIMO_CANTIDAD = 20
LARGO_MAXIMO_UNIDAD = 20

KCAL_MAXIMAS = 20_000
"""Por registro. No es un límite nutricional, es un tope para que un dedo torpe
no meta un número de siete cifras que descuadre las barras del día entero."""

DECIMAS_MAXIMAS = 100_000
"""1.000 gramos de un macro en un solo registro. Mismo motivo."""

DECIMAS = 10
"""Los macros se guardan en décimas de gramo: las etiquetas traen decimales
("23,5 g de proteína") y redondear a gramos enteros perdería ese dato. Entero y
no decimal por lo mismo que el dinero: sumar decimales acumula error."""


LARGO_MAXIMO_NOTA = 500
"""Lo que cabe en el comentario de un registro."""

LARGO_MAXIMO_COMIDA = 30
"""El momento del día del registro («desayuno», «cena»), escrito a mano."""


@dataclass(frozen=True)
class Registro:
    """Una cosa comida. Todos los números son los que escribió el usuario."""

    nombre: str

    jornada: date
    momento: datetime
    """Cuándo se apuntó. Solo sirve para ordenar la lista del día."""

    comida: str = ""
    """El momento del día (desayuno, cena...), por su nombre. YA NO SE PIDE.

    LO QUITO EL USUARIO: "yo pongo el nombre, no importa si es almuerzo, cena,
    lo que sea; no me pongas opcion de desayuno, almuerzo, ninguna".

    LA COLUMNA SE QUEDA Y PUEDE VENIR LLENA, porque lo que ya estaba apuntado
    conserva su etiqueta: borrarla seria tirar informacion que costo escribir
    para no ganar nada. Lo nuevo se guarda con esto vacio.
    """

    nota: str = ""
    """Un comentario tuyo. Lo pidio el usuario junto con lo de arriba."""

    cantidad: str = ""
    unidad: str = ""
    kcal: int = 0
    proteinas: int = 0
    """En décimas de gramo."""

    carbohidratos: int = 0
    grasas: int = 0
    id: int | None = None

    def __post_init__(self) -> None:
        exigir_texto("nombre", self.nombre, LARGO_MAXIMO_NOMBRE, obligatorio=True)
        exigir_texto("cantidad", self.cantidad, LARGO_MAXIMO_CANTIDAD)
        exigir_texto("unidad", self.unidad, LARGO_MAXIMO_UNIDAD)
        for campo in ("nombre", "cantidad", "unidad"):
            object.__setattr__(self, campo, getattr(self, campo).strip())

        exigir_texto("comida", self.comida, LARGO_MAXIMO_COMIDA)
        object.__setattr__(self, "comida", self.comida.strip())
        exigir_texto("nota", self.nota, LARGO_MAXIMO_NOTA)
        object.__setattr__(self, "nota", self.nota.strip())

        if not isinstance(self.jornada, date) or isinstance(self.jornada, datetime):
            raise TypeError("la jornada tiene que ser un date, no un datetime")
        if not isinstance(self.momento, datetime):
            raise TypeError("el momento tiene que ser un datetime")

        _exigir_cantidad("kcal", self.kcal, KCAL_MAXIMAS)
        for campo in ("proteinas", "carbohidratos", "grasas"):
            _exigir_cantidad(campo, getattr(self, campo), DECIMAS_MAXIMAS)

        if self.id is not None:
            if isinstance(self.id, bool) or not isinstance(self.id, int):
                raise TypeError("el id tiene que ser int o None")
            if self.id <= 0:
                raise ValueError("id tiene que ser mayor que cero")

    # ----------------------------------------------------------------------


    def resumen(self) -> str:
        """La línea que se ve en la lista del día: solo el nombre.

        YA NO SE ENSEÑA LA CANTIDAD, y lo pidió el usuario para quitar ruido:
        "el nombre puede mantenerse, pero sin agregar información innecesaria".
        Con los macros justo debajo, el "300 g" de al lado del nombre no añadía
        nada que no estuviera ya.

        LOS CAMPOS SIGUEN EN LA BASE con lo que se escribió en su día: dejaron
        de pedirse y de enseñarse, pero borrarlos habría tirado datos que el
        usuario escribió a mano. Cuestan cero y ahí están por si algún día
        hacen falta.
        """
        return self.nombre


# ---------------------------------------------------------------------------
# Leer y escribir números, sin inventarse ninguno
# ---------------------------------------------------------------------------

_ENTERO = re.compile(r"^\d{1,7}$")
_CON_DECIMALES = re.compile(r"^(\d{1,7})[.,](\d{1,2})$")


def parsear_kcal(texto: str) -> int:
    """Las calorías escritas. Vacío es CERO, no "no lo sé".

    Cero es un dato válido: el agua tiene cero calorías. Lo que no se hace nunca
    es rellenarlo con una estimación.
    """
    return _parsear(texto, KCAL_MAXIMAS, decimales=False, nombre="las calorías")


def parsear_gramos(texto: str) -> int:
    """Los gramos escritos, en décimas. "23,5" son 235.

    Se admiten la coma y el punto: las etiquetas españolas usan coma y las
    inglesas punto, y pelearse con el usuario por eso no tiene sentido.
    """
    return _parsear(texto, DECIMAS_MAXIMAS, decimales=True, nombre="los gramos")


def texto_gramos(decimas: int) -> str:
    """235 -> "23,5". Sin decimal cuando es redondo: "20", no "20,0"."""
    if not isinstance(decimas, int) or isinstance(decimas, bool):
        raise TypeError("las décimas tienen que ser un entero")
    enteros, resto = divmod(abs(decimas), DECIMAS)
    signo = "-" if decimas < 0 else ""
    return f"{signo}{enteros},{resto}" if resto else f"{signo}{enteros}"


def _parsear(texto: str, tope: int, *, decimales: bool, nombre: str) -> int:
    if not isinstance(texto, str):
        raise TypeError(f"{nombre} tienen que venir como texto")
    limpio = texto.strip().replace(" ", "")
    if not limpio:
        return 0

    if _ENTERO.match(limpio):
        valor = int(limpio) * (DECIMAS if decimales else 1)
    elif decimales and (con_coma := _CON_DECIMALES.match(limpio)):
        entera = int(con_coma.group(1))
        parte = con_coma.group(2)
        if len(parte) > 1:
            raise ValueError(
                f"{nombre} admiten un solo decimal: escribe 23,5 y no 23,55"
            )
        valor = entera * DECIMAS + int(parte)
    else:
        raise ValueError(f"no entiendo «{texto.strip()}» en {nombre}")

    if valor > tope:
        raise ValueError(f"ese número es demasiado grande para {nombre}")
    return valor


def _exigir_cantidad(nombre: str, valor, tope: int) -> None:
    if isinstance(valor, bool) or not isinstance(valor, int):
        raise TypeError(f"{nombre} tiene que ser un entero")
    if valor < 0:
        raise ValueError(f"{nombre} no puede ser negativo")
    if valor > tope:
        raise ValueError(f"{nombre} se pasa del máximo ({tope})")
