"""Un movimiento de dinero: un gasto o un ingreso.

POR QUÉ EL IMPORTE ES SIEMPRE POSITIVO Y EL SIGNO LO DICE EL TIPO: si los gastos
se guardaran en negativo, "cuánto he gastado" sería una suma de negativos que
hay que acordarse de invertir, y un ingreso mal firmado se confundiría con un
gasto sin que salte ningún error. Con tipo + importe positivo, cada consulta dice
explícitamente qué está sumando y un signo equivocado es imposible.

POR QUÉ SE GUARDAN LAS DOS FECHAS (momento y jornada): el momento es la hora del
reloj, que hace falta para ordenar y para saber cuándo pasó de verdad. La jornada
es a qué día de trabajo pertenece según el horario configurado, y es la que usan
todos los resúmenes. Se calcula UNA vez, al crear el movimiento, y se guarda: así
cambiar de turno en octubre no recoloca el historial de agosto.

POR QUÉ LA TASA PUEDE SER None: es un movimiento en moneda extranjera que se
apuntó sin internet, así que todavía no se sabe a cuánto convertirlo. Se guarda
igual (nunca se pierde un gasto por no tener cobertura) y queda marcado como
pendiente. Ver dominio/resumen.py para lo que eso significa en los totales.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum

from . import apunte, dinero
from .moneda import EUR, Moneda

LARGO_MAXIMO_DESCRIPCION = 500


class Tipo(StrEnum):
    """Qué le pasó al dinero.

    StrEnum (y no Enum normal) porque el valor se guarda tal cual como texto en
    la base de datos: 'gasto'. Así lo que hay en el archivo se lee sin traducir
    y se entiende abriendo la base con cualquier visor.

    ERAN DOS Y AHORA SON SEIS, y lo pidió el usuario con un ejemplo que dejaba
    claro el fallo: apartaba 500 € para ahorrar y la aplicación se los contaba
    como gasto de transporte. "Se verá como que lo perdí, pero no lo perdí,
    porque lo estoy ahorrando".

    Y TENÍA RAZÓN: ahorrar no es gastar. El dinero sale de la cuenta corriente
    igual, pero sigue siendo suyo. Meterlos en el mismo saco hacía que el total
    de gastos del mes fuera falso y que el círculo del Dashboard dijera que se
    va la mitad del sueldo en transporte.

    LAS RETIRADAS EXISTEN PORQUE SI NO, EL TOTAL MIENTE. Un ahorro que solo
    puede crecer sigue diciendo que tienes 2.000 € guardados el día que gastas
    300. El usuario lo pidió para el ahorro —"un botón que diga retirar"— y la
    inversión lleva el suyo por lo mismo: el día que vendas, el número tiene que
    poder bajar.
    """

    GASTO = "gasto"
    INGRESO = "ingreso"

    AHORRO = "ahorro"
    """Dinero apartado. Sale de la cuenta pero NO se ha perdido."""

    RETIRADA_AHORRO = "retirada de ahorro"
    """Dinero que vuelve del ahorro. Baja lo ahorrado y no es un ingreso."""

    INVERSION = "inversión"
    """Dinero mandado a invertir.

    ES EL TRASPASO, no lo que compraste con él: qué fondo y a qué precio vive en
    el apartado de Inversiones, que lleva las posiciones de verdad. Son dos
    preguntas distintas y lo eligió así el usuario. PUEDEN NO CUADRAR —mandas
    500 y compras por 480— y eso no es un fallo: es que son cosas distintas.
    """

    RETIRADA_INVERSION = "retirada de inversión"
    """Dinero que vuelve de la inversión."""

    AJUSTE_AHORRO = "ajuste de ahorro"
    """Lo que YA tenías ahorrado antes de usar esto, o una corrección.

    POR QUÉ EXISTE, con el caso del usuario: tenía dinero ahorrado de antes y al
    meterlo se le ponía el balance en negativo, porque un ahorro normal es
    dinero que SALE de la cuenta corriente este mes. Esto no salió de ningún
    sitio: ya estaba ahorrado.

    NO TOCA LA CAJA, y es toda la diferencia: sube lo ahorrado y deja el balance
    exactamente como estaba.
    """

    AJUSTE_INVERSION = "ajuste de inversión"
    """Lo mismo para lo que ya tenías invertido."""

    AJUSTE_INGRESO = "ajuste de ingresos"
    """Ingresos que no apuntaste uno a uno, en un solo número.

    CUENTA COMO INGRESO Y ENTRA EN LA CAJA: es dinero que has cobrado de
    verdad, solo que no te apetece detallarlo.
    """

    AJUSTE_GASTO = "ajuste de gastos"
    """Gastos que no apuntaste uno a uno, en un solo número."""

    CUADRE_MAS = "cuadre a favor"
    """El banco tiene MÁS de lo que dice el balance, y no sabes por qué.

    POR QUÉ NO ES UN INGRESO, y lo dijo el usuario: "por algún motivo que
    desconozco tengo menos en el banco que en el balance, y quiero modificar
    eso sin agregar un gasto fantasma". Un ingreso inventado ensuciaría el
    total de ingresos del mes, que es un dato que sí te crees. El cuadre mueve
    el balance y deja los ingresos y los gastos exactamente como están.

    ES EXCEPCIONAL A PROPÓSITO: el balance sigue anclado a lo que apuntas, y
    esto solo tapa la diferencia que no se explica.
    """

    CUADRE_MENOS = "cuadre en contra"
    """El banco tiene MENOS de lo que dice el balance. Es el caso del usuario."""


AJUSTES = frozenset(
    {
        Tipo.AJUSTE_AHORRO,
        Tipo.AJUSTE_INVERSION,
        Tipo.AJUSTE_INGRESO,
        Tipo.AJUSTE_GASTO,
        Tipo.CUADRE_MAS,
        Tipo.CUADRE_MENOS,
    }
)
"""Los que se escriben con el lápiz de una cifra y NO salen en la lista.

SON UNA COSA DISTINTA DE UN MOVIMIENTO: no es dinero que se movió tal día a tal
hora, es una cifra que pusiste tú de una vez. Por eso hay UNO de cada —escribir
otro sustituye al anterior— y por eso la lista de abajo no los enseña: esa lista
es de dinero que se movió de verdad.
"""

NEUTRALES_EN_CAJA = frozenset({Tipo.AJUSTE_AHORRO, Tipo.AJUSTE_INVERSION})
"""Los que NO mueven el dinero disponible.

SON LOS ÚNICOS QUE NO ENTRAN NI SALEN, y por eso están aparte en vez de en una
de las otras dos listas: un ajuste no es dinero que se mueva hoy, es dinero que
ya estaba donde está. Contarlo como salida pondría el balance en negativo —que
es justo el fallo que hizo falta arreglar— y contarlo como entrada diría que has
cobrado algo que no has cobrado.
"""

SALIDAS_DE_CAJA = frozenset(
    {Tipo.GASTO, Tipo.AHORRO, Tipo.INVERSION, Tipo.AJUSTE_GASTO, Tipo.CUADRE_MENOS}
)
"""Los que HACEN QUE BAJE el dinero disponible.

Ahorrar e invertir vacían la cuenta corriente igual que un gasto: por eso están
aquí. Lo que los distingue de un gasto no es esto, es que el dinero sigue siendo
tuyo, y eso lo dice CUENTAN_COMO_GASTO.
"""

ENTRADAS_DE_CAJA = frozenset(
    {
        Tipo.INGRESO,
        Tipo.RETIRADA_AHORRO,
        Tipo.RETIRADA_INVERSION,
        Tipo.AJUSTE_INGRESO,
        Tipo.CUADRE_MAS,
    }
)
"""Los que hacen que suba el dinero disponible."""

CUENTAN_COMO_GASTO = frozenset({Tipo.GASTO, Tipo.AJUSTE_GASTO})
"""Dinero que ya no es tuyo. SOLO EL GASTO.

ESTE CONJUNTO ES EL ARREGLO ENTERO, escrito en una línea: es lo que hace que
apartar 500 € para ahorrar deje de salir en el total de gastos y en el círculo
de "en qué se me va el dinero".
"""

CUENTAN_COMO_INGRESO = frozenset({Tipo.INGRESO, Tipo.AJUSTE_INGRESO})
"""Dinero que entra de fuera. Sacar del ahorro NO es ingresar: es recuperar algo
que ya era tuyo, y contarlo como ingreso inflaría el sueldo del mes.

EL CUADRE TAMPOCO ESTÁ AQUÍ: mueve el balance pero no es dinero cobrado, y
meterlo entre los ingresos sería inventarse un cobro para tapar un descuadre."""

@dataclass(frozen=True)
class Guardado:
    """Un sitio donde el dinero se aparta: el ahorro o la inversión.

    ANTES ERA UNA PAREJA DE TIPOS y se quedó corta en cuanto aparecieron los
    ajustes: hacían falta tres papeles —lo que mete, lo que saca y lo que
    corrige— y una tupla de dos no tiene sitio para el tercero sin que el orden
    signifique algo, que es la clase de detalle que se olvida y rompe.
    """

    nombre: str
    mete: frozenset[Tipo]
    saca: frozenset[Tipo]

    @property
    def tipos(self) -> frozenset[Tipo]:
        """Todos los suyos, para pintarlos del mismo color."""
        return self.mete | self.saca


AHORRO = Guardado(
    nombre="ahorro",
    mete=frozenset({Tipo.AHORRO, Tipo.AJUSTE_AHORRO}),
    saca=frozenset({Tipo.RETIRADA_AHORRO}),
)

INVERSION = Guardado(
    nombre="inversión",
    mete=frozenset({Tipo.INVERSION, Tipo.AJUSTE_INVERSION}),
    saca=frozenset({Tipo.RETIRADA_INVERSION}),
)

AJUSTE_DE = {AHORRO.nombre: Tipo.AJUSTE_AHORRO, INVERSION.nombre: Tipo.AJUSTE_INVERSION}
"""Qué tipo de ajuste le toca a cada uno."""


def signo_en_caja(tipo: Tipo) -> int:
    """+1 si el dinero disponible sube, -1 si baja, 0 si no lo toca.

    NO SE GUARDA NINGÚN IMPORTE EN NEGATIVO, aquí ni en ningún sitio: el importe
    siempre es positivo y el signo lo dice el tipo. Es la regla de todo el
    archivo y no cambia por tener seis tipos en vez de dos.
    """
    if tipo in NEUTRALES_EN_CAJA:
        return 0
    if tipo in ENTRADAS_DE_CAJA:
        return 1
    if tipo in SALIDAS_DE_CAJA:
        return -1
    raise ValueError(f"no se sabe si «{tipo}» entra o sale de la caja")


def signo_en_el_saldo(tipo: Tipo, guardado: Guardado) -> int:
    """+1 si ese movimiento hace crecer ese saldo, -1 si lo baja, 0 si no le toca.

    `guardado` es AHORRO o INVERSION.
    """
    if tipo in guardado.mete:
        return 1
    if tipo in guardado.saca:
        return -1
    return 0


@dataclass(frozen=True)
class Movimiento:
    tipo: Tipo
    importe: int
    """Unidades mínimas de SU moneda. Siempre mayor que cero."""

    moneda: Moneda
    categoria_id: int
    momento: datetime
    jornada: date
    descripcion: str = ""

    tasa: Decimal | None = None
    """Cuántas unidades grandes de la moneda principal vale una de la suya.
    None = pendiente de cambio."""

    importe_principal: int | None = None
    """El importe ya convertido a la moneda principal. None = pendiente."""

    moneda_principal: Moneda | None = None
    """A QUÉ moneda se convirtió ese importe.

    SIN ESTE DATO, `importe_principal` es un número sin unidad. Faltaba, y el
    fallo apareció en cuanto se pudo cambiar la moneda principal: unos treinta
    euros convertidos cuando la principal era el euro se seguían sumando como
    treinta DÓLARES al cambiar a dólares. La cuenta estaba bien hecha; lo que
    estaba mal era no saber para qué moneda se hizo.

    None quiere decir "no se sabe", y quien suma lo aparta como pendiente en vez
    de contarlo por si acaso.
    """

    id: int | None = None
    """None mientras no se haya guardado en la base de datos."""

    def __post_init__(self) -> None:
        if not isinstance(self.tipo, Tipo):
            raise TypeError(f"tipo tiene que ser Tipo, no {type(self.tipo).__name__}")
        if not isinstance(self.moneda, Moneda):
            raise TypeError("moneda tiene que ser una Moneda del catálogo")
        _exigir_entero_positivo("importe", self.importe)
        _exigir_entero_positivo("categoria_id", self.categoria_id)

        apunte.exigir_momento(self.momento)
        apunte.exigir_jornada(self.jornada)

        if not isinstance(self.descripcion, str):
            raise TypeError("la descripción tiene que ser texto")
        if len(self.descripcion) > LARGO_MAXIMO_DESCRIPCION:
            raise ValueError(
                f"la descripción no puede pasar de {LARGO_MAXIMO_DESCRIPCION} "
                f"caracteres (llegaron {len(self.descripcion)})"
            )
        # El dataclass es frozen, así que para normalizar hay que saltarse la
        # inmutabilidad aquí dentro. Se hace solo en la construcción, y evita
        # guardar descripciones con espacios sobrantes que luego no coinciden.
        object.__setattr__(self, "descripcion", self.descripcion.strip())

        apunte.exigir_conversion(self.tasa, self.importe_principal)

        if self.moneda_principal is not None and not isinstance(
            self.moneda_principal, Moneda
        ):
            raise TypeError("moneda_principal tiene que ser una Moneda o None")
        # UN IMPORTE CONVERTIDO SIN DECIR A QUE MONEDA es un numero sin unidad, y
        # es exactamente el fallo que hizo falta arreglar: se sumaban euros
        # dentro de un total en dolares. Se prohibe construirlo asi.
        if self.importe_principal is not None and self.moneda_principal is None:
            raise ValueError(
                "hay un importe convertido pero no se dice a que moneda; "
                "un importe sin unidad no se puede sumar a nada"
            )

    # ----------------------------------------------------------------------
    # Construcción
    # ----------------------------------------------------------------------

    @classmethod
    def nuevo(
        cls,
        *,
        tipo: Tipo,
        importe: int,
        categoria_id: int,
        momento: datetime,
        jornada: date,
        moneda: Moneda = EUR,
        descripcion: str = "",
        principal: Moneda = EUR,
        tasa: Decimal | None = None,
    ) -> Movimiento:
        """Crea un movimiento con su jornada y su conversión.

        LA JORNADA SE PASA, NO SE CALCULA, y esa es la regla nueva: es la del
        día que el usuario tenga abierto. Antes salía de comparar el reloj con
        una hora configurada, y a esa hora el día cambiaba solo; ahora un día
        solo termina cuando el usuario lo cierra.

        SE SIGUE OBLIGANDO A PASARLA para que nunca salga de datetime.now(): un
        gasto apuntado a las tres de la mañana pertenece al día que sigue
        abierto, no al que diga el calendario.

        - Si la moneda ES la principal, la tasa es 1 y no hace falta internet.
        - Si es otra y se pasa una tasa, se convierte al crearlo.
        - Si es otra y no hay tasa, queda pendiente de cambio.
        """
        # datetime.now() siempre trae microsegundos, asi que se recortan aqui
        # en vez de obligar a quien llame a acordarse de hacerlo.
        momento = momento.replace(microsecond=0)

        tasa_final, convertido = apunte.resolver_conversion(
            importe, moneda, principal, tasa
        )

        return cls(
            tipo=tipo,
            importe=importe,
            moneda=moneda,
            categoria_id=categoria_id,
            momento=momento,
            jornada=jornada,
            descripcion=descripcion,
            tasa=tasa_final,
            importe_principal=convertido,
            # A QUE moneda se convirtio. Solo si de verdad se convirtio: sin
            # tasa no hay conversion, y decir que se convirtio a algo seria
            # afirmar un dato que no existe.
            moneda_principal=principal if tasa_final is not None else None,
        )

    # ----------------------------------------------------------------------
    # Consultas
    # ----------------------------------------------------------------------

    @property
    def pendiente_de_cambio(self) -> bool:
        """True si falta saber a cuánto convertirlo a la moneda principal."""
        return self.tasa is None

    def cuenta_en(self, principal: Moneda) -> bool:
        """Si este movimiento se puede sumar a un total en esa moneda.

        HACEN FALTA LAS DOS COSAS: que tenga conversión hecha, y que esa
        conversión fuera A ESA MISMA moneda. Un gasto convertido a euros no sirve
        para un total en dólares por muy convertido que esté; el número existe,
        pero no es de esa unidad.
        """
        if self.pendiente_de_cambio or self.moneda_principal is None:
            return False
        return self.moneda_principal == principal

    def texto_importe(self) -> str:
        """El importe en su propia moneda, listo para enseñar: "8,50 €"."""
        return dinero.formatear(self.importe, self.moneda)

    def texto_importe_principal(self, principal: Moneda = EUR) -> str | None:
        """El importe convertido, o None si está pendiente.

        Devuelve None en vez de un cero o un guion: quien lo enseñe tiene que
        decidir qué poner, y así no se cuela un "0,00 €" que parece un dato real.
        """
        if self.importe_principal is None:
            return None
        return dinero.formatear(self.importe_principal, principal)

    def con_tasa(self, tasa: Decimal, principal: Moneda = EUR) -> Movimiento:
        """Devuelve una copia con la tasa resuelta. No modifica el original.

        Falla si el movimiento ya tenía tasa: reescribir la conversión de algo
        ya convertido cambiaría un resumen antiguo, y eso solo puede hacerse
        a propósito, nunca por accidente.
        """
        if not self.pendiente_de_cambio:
            raise ValueError(
                f"este movimiento ya tiene tasa ({self.tasa}); no se reescribe"
            )
        tasa_final, convertido = apunte.resolver_conversion(
            self.importe, self.moneda, principal, tasa
        )
        return replace(
            self,
            tasa=tasa_final,
            importe_principal=convertido,
            # Sin esto, resolver un cambio dejaba el importe convertido sin
            # unidad y el constructor lo rechaza; que es justo lo que se quiere,
            # pero aqui hay que decirla, no omitirla.
            moneda_principal=principal,
        )


def _exigir_entero_positivo(nombre: str, valor: int) -> None:
    if isinstance(valor, bool) or not isinstance(valor, int):
        raise TypeError(f"{nombre} tiene que ser int, no {type(valor).__name__}")
    if valor <= 0:
        raise ValueError(f"{nombre} tiene que ser mayor que cero, y llegó {valor}")
