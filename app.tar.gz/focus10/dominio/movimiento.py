"""Un movimiento de dinero: un gasto o un ingreso.

POR QUÉ EL IMPORTE ES SIEMPRE POSITIVO Y EL SIGNO LO DICE EL TIPO: si los gastos
se guardaran en negativo, "cuánto he gastado" sería una suma de negativos que
hay que acordarse de invertir, y un ingreso mal firmado se confundiría con un
gasto sin que salte ningún error. Con tipo + importe positivo, cada consulta dice
explícitamente qué está sumando y un signo equivocado es imposible.

POR QUÉ SE GUARDAN LAS DOS FECHAS (momento y jornada): el momento es la hora del
reloj, que hace falta para ordenar y para saber cuándo pasó de verdad. La jornada
es a qué día de trabajo pertenece según el horario configurado, y es la que usan
todos los resúmenes. Se calcula UNA vez, al crear el movimiento, y se guarda: así
cambiar de turno en octubre no recoloca el historial de agosto.

POR QUÉ LA TASA PUEDE SER None: es un movimiento en moneda extranjera que se
apuntó sin internet, así que todavía no se sabe a cuánto convertirlo. Se guarda
igual (nunca se pierde un gasto por no tener cobertura) y queda marcado como
pendiente. Ver dominio/resumen.py para lo que eso significa en los totales.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum

from . import apunte, dinero
from .jornada import Horario, jornada_de
from .moneda import EUR, Moneda

LARGO_MAXIMO_DESCRIPCION = 500


class Tipo(StrEnum):
    """Gasto o ingreso.

    StrEnum (y no Enum normal) porque el valor se guarda tal cual como texto en
    la base de datos: 'gasto'. Así lo que hay en el archivo se lee sin traducir
    y se entiende abriendo la base con cualquier visor.
    """

    GASTO = "gasto"
    INGRESO = "ingreso"


@dataclass(frozen=True)
class Movimiento:
    tipo: Tipo
    importe: int
    """Unidades mínimas de SU moneda. Siempre mayor que cero."""

    moneda: Moneda
    categoria_id: int
    momento: datetime
    jornada: date
    descripcion: str = ""

    tasa: Decimal | None = None
    """Cuántas unidades grandes de la moneda principal vale una de la suya.
    None = pendiente de cambio."""

    importe_principal: int | None = None
    """El importe ya convertido a la moneda principal. None = pendiente."""

    moneda_principal: Moneda | None = None
    """A QUÉ moneda se convirtió ese importe.

    SIN ESTE DATO, `importe_principal` es un número sin unidad. Faltaba, y el
    fallo apareció en cuanto se pudo cambiar la moneda principal: unos treinta
    euros convertidos cuando la principal era el euro se seguían sumando como
    treinta DÓLARES al cambiar a dólares. La cuenta estaba bien hecha; lo que
    estaba mal era no saber para qué moneda se hizo.

    None quiere decir "no se sabe", y quien suma lo aparta como pendiente en vez
    de contarlo por si acaso.
    """

    id: int | None = None
    """None mientras no se haya guardado en la base de datos."""

    def __post_init__(self) -> None:
        if not isinstance(self.tipo, Tipo):
            raise TypeError(f"tipo tiene que ser Tipo, no {type(self.tipo).__name__}")
        if not isinstance(self.moneda, Moneda):
            raise TypeError("moneda tiene que ser una Moneda del catálogo")
        _exigir_entero_positivo("importe", self.importe)
        _exigir_entero_positivo("categoria_id", self.categoria_id)

        apunte.exigir_momento(self.momento)
        apunte.exigir_jornada(self.jornada)

        if not isinstance(self.descripcion, str):
            raise TypeError("la descripción tiene que ser texto")
        if len(self.descripcion) > LARGO_MAXIMO_DESCRIPCION:
            raise ValueError(
                f"la descripción no puede pasar de {LARGO_MAXIMO_DESCRIPCION} "
                f"caracteres (llegaron {len(self.descripcion)})"
            )
        # El dataclass es frozen, así que para normalizar hay que saltarse la
        # inmutabilidad aquí dentro. Se hace solo en la construcción, y evita
        # guardar descripciones con espacios sobrantes que luego no coinciden.
        object.__setattr__(self, "descripcion", self.descripcion.strip())

        apunte.exigir_conversion(self.tasa, self.importe_principal)

        if self.moneda_principal is not None and not isinstance(
            self.moneda_principal, Moneda
        ):
            raise TypeError("moneda_principal tiene que ser una Moneda o None")
        # UN IMPORTE CONVERTIDO SIN DECIR A QUE MONEDA es un numero sin unidad, y
        # es exactamente el fallo que hizo falta arreglar: se sumaban euros
        # dentro de un total en dolares. Se prohibe construirlo asi.
        if self.importe_principal is not None and self.moneda_principal is None:
            raise ValueError(
                "hay un importe convertido pero no se dice a que moneda; "
                "un importe sin unidad no se puede sumar a nada"
            )

    # ----------------------------------------------------------------------
    # Construcción
    # ----------------------------------------------------------------------

    @classmethod
    def nuevo(
        cls,
        *,
        tipo: Tipo,
        importe: int,
        categoria_id: int,
        momento: datetime,
        horario: Horario,
        moneda: Moneda = EUR,
        descripcion: str = "",
        principal: Moneda = EUR,
        tasa: Decimal | None = None,
    ) -> Movimiento:
        """Crea un movimiento calculando su jornada y su conversión.

        Es la única forma correcta de crear uno: obliga a pasar el horario, y
        así la jornada sale de jornada_de() y nunca de la fecha del reloj.

        - Si la moneda ES la principal, la tasa es 1 y no hace falta internet.
        - Si es otra y se pasa una tasa, se convierte al crearlo.
        - Si es otra y no hay tasa, queda pendiente de cambio.
        """
        # datetime.now() siempre trae microsegundos, asi que se recortan aqui
        # en vez de obligar a quien llame a acordarse de hacerlo.
        momento = momento.replace(microsecond=0)
        jornada = jornada_de(momento, horario)

        tasa_final, convertido = apunte.resolver_conversion(
            importe, moneda, principal, tasa
        )

        return cls(
            tipo=tipo,
            importe=importe,
            moneda=moneda,
            categoria_id=categoria_id,
            momento=momento,
            jornada=jornada,
            descripcion=descripcion,
            tasa=tasa_final,
            importe_principal=convertido,
            # A QUE moneda se convirtio. Solo si de verdad se convirtio: sin
            # tasa no hay conversion, y decir que se convirtio a algo seria
            # afirmar un dato que no existe.
            moneda_principal=principal if tasa_final is not None else None,
        )

    # ----------------------------------------------------------------------
    # Consultas
    # ----------------------------------------------------------------------

    @property
    def pendiente_de_cambio(self) -> bool:
        """True si falta saber a cuánto convertirlo a la moneda principal."""
        return self.tasa is None

    def cuenta_en(self, principal: Moneda) -> bool:
        """Si este movimiento se puede sumar a un total en esa moneda.

        HACEN FALTA LAS DOS COSAS: que tenga conversión hecha, y que esa
        conversión fuera A ESA MISMA moneda. Un gasto convertido a euros no sirve
        para un total en dólares por muy convertido que esté; el número existe,
        pero no es de esa unidad.
        """
        if self.pendiente_de_cambio or self.moneda_principal is None:
            return False
        return self.moneda_principal == principal

    def texto_importe(self) -> str:
        """El importe en su propia moneda, listo para enseñar: "8,50 €"."""
        return dinero.formatear(self.importe, self.moneda)

    def texto_importe_principal(self, principal: Moneda = EUR) -> str | None:
        """El importe convertido, o None si está pendiente.

        Devuelve None en vez de un cero o un guion: quien lo enseñe tiene que
        decidir qué poner, y así no se cuela un "0,00 €" que parece un dato real.
        """
        if self.importe_principal is None:
            return None
        return dinero.formatear(self.importe_principal, principal)

    def con_tasa(self, tasa: Decimal, principal: Moneda = EUR) -> Movimiento:
        """Devuelve una copia con la tasa resuelta. No modifica el original.

        Falla si el movimiento ya tenía tasa: reescribir la conversión de algo
        ya convertido cambiaría un resumen antiguo, y eso solo puede hacerse
        a propósito, nunca por accidente.
        """
        if not self.pendiente_de_cambio:
            raise ValueError(
                f"este movimiento ya tiene tasa ({self.tasa}); no se reescribe"
            )
        tasa_final, convertido = apunte.resolver_conversion(
            self.importe, self.moneda, principal, tasa
        )
        return replace(
            self,
            tasa=tasa_final,
            importe_principal=convertido,
            # Sin esto, resolver un cambio dejaba el importe convertido sin
            # unidad y el constructor lo rechaza; que es justo lo que se quiere,
            # pero aqui hay que decirla, no omitirla.
            moneda_principal=principal,
        )


def _exigir_entero_positivo(nombre: str, valor: int) -> None:
    if isinstance(valor, bool) or not isinstance(valor, int):
        raise TypeError(f"{nombre} tiene que ser int, no {type(valor).__name__}")
    if valor <= 0:
        raise ValueError(f"{nombre} tiene que ser mayor que cero, y llegó {valor}")
