"""Si un día se cumplió lo que te habías propuesto comer.

LO PIDIÓ EL USUARIO: "un gráfico tipo qué días cumplí y qué días no, en el
apartado mensual, que yo pueda entrar a cada día y ver un resumen: cuánta prote,
carbos... agua, y qué comí".

MANDAN LAS CALORÍAS Y LA PROTEÍNA, y lo eligió él: son las dos que de verdad
deciden en volumen. Los carbohidratos y las grasas se ven en el detalle del día,
pero no pintan el día de ningún color. Con los cuatro a la vez casi ningún día
saldría verde, y un calendario todo en rojo se deja de mirar a la semana.

EL AGUA NO DECIDE, también decisión suya: se ve en el resumen del día con su
objetivo, pero un día de comida perfecta no puede salir fallado porque se te
olvidara apuntar que bebiste.

SIN OBJETIVO NO HAY VEREDICTO. Si no has puesto cuántas calorías o cuánta
proteína quieres, no se puede decir si un día está cumplido: no hay contra qué
compararlo. Ese día sale como SIN_OBJETIVO y no como fallado, que sería
inventarse una nota.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from enum import StrEnum

from .agua import Trago
from .alimento import Registro
from .nutricion import Objetivos, Totales
from .resumen_comida import DiaDeComida


class Cumplimiento(StrEnum):
    """Cómo salió un día."""

    CUMPLIDO = "cumplido"
    CERCA = "cerca"
    NO_CUMPLIDO = "no cumplido"

    SIN_OBJETIVO = "sin objetivo"
    """No hay con qué comparar: falta el objetivo de calorías o el de proteína."""

    FUTURO = "futuro"
    """Todavía no ha pasado. NO ES LO MISMO QUE FALLADO, y por eso está aparte:
    pintar de rojo el resto del mes diría que fallaste treinta días que aún no
    has vivido."""


FRACCION_CUMPLIDO = 0.95
"""Desde cuánto se da por cumplido un objetivo.

NO ES EL 100% A PROPÓSITO: nadie clava 3300 kcal exactas, y exigirlo haría que
un día de 3290 saliera igual de rojo que uno de 1200. Un 95% es "lo hiciste".
"""

FRACCION_CERCA = 0.80
"""Desde cuánto se considera que faltó poco.

EXISTE PARA NO MENTIR POR SIMPLIFICAR: un día al 85% no es lo mismo que un día
al 20%, y meterlos en el mismo color diría que fueron igual de malos.
"""


@dataclass(frozen=True)
class ResumenDeDia:
    """Todo lo de un día, para poder abrirlo y verlo entero.

    LLEVA LOS REGISTROS Y NO SOLO LOS TOTALES porque lo que se pidió fue "ver qué
    comí", y eso no se puede sacar de una suma.
    """

    jornada: date
    totales: Totales = field(default_factory=Totales)
    objetivos: Objetivos = field(default_factory=Objetivos)
    registros: tuple[Registro, ...] = ()
    agua_ml: int = 0
    objetivo_agua: int | None = None

    @property
    def apuntado(self) -> bool:
        """Si ese día se apuntó algo de comer.

        EL AGUA NO CUENTA AQUÍ: un día en el que solo bebiste agua no es un día
        con la comida apuntada, y decir que sí haría que el calendario tratara
        como "día flojo" lo que en realidad es un día sin datos.
        """
        return bool(self.registros)

    def falta_de_agua(self) -> int | None:
        """Cuánta agua falta para el objetivo, o None si no hay objetivo."""
        if self.objetivo_agua is None:
            return None
        return max(0, self.objetivo_agua - self.agua_ml)


def fraccion_de(logrado: int, objetivo: int | None) -> float | None:
    """Qué parte del objetivo se cubrió. None si no hay objetivo que cubrir.

    UN OBJETIVO A CERO TAMPOCO SE PUEDE DIVIDIR, y decir que un cero entre cero
    está "cumplido al 100%" sería una respuesta inventada para una pregunta que
    no tiene sentido.
    """
    if not objetivo:
        return None
    return logrado / objetivo


def cumplimiento_de(
    dia: DiaDeComida, objetivos: Objetivos, hoy: date
) -> Cumplimiento:
    """Cómo salió ese día: cumplido, cerca, fallado, sin objetivo o futuro.

    SE MIRA LA PEOR DE LAS DOS. Un día con las calorías clavadas y la mitad de la
    proteína no está cumplido a medias: no está cumplido. La nota de un día es la
    del objetivo que peor fue.
    """
    if dia.jornada > hoy:
        return Cumplimiento.FUTURO

    partes = [
        fraccion_de(dia.de("kcal"), objetivos.kcal),
        fraccion_de(dia.de("proteinas"), objetivos.proteinas),
    ]
    if any(una is None for una in partes):
        return Cumplimiento.SIN_OBJETIVO

    peor = min(partes)
    if peor >= FRACCION_CUMPLIDO:
        return Cumplimiento.CUMPLIDO
    if peor >= FRACCION_CERCA:
        return Cumplimiento.CERCA
    return Cumplimiento.NO_CUMPLIDO


def cuenta(
    dias: list[DiaDeComida], objetivos: Objetivos, hoy: date
) -> dict[Cumplimiento, int]:
    """Cuántos días de cada clase, para poder decir "cumpliste 12 de 30".

    LOS DÍAS FUTUROS NO SE CUENTAN en ninguna parte: no son ni buenos ni malos,
    y meterlos en el total haría que a primeros de mes pareciera que llevas
    veintiocho días fallados.
    """
    resultado = {uno: 0 for uno in Cumplimiento}
    for dia in dias:
        resultado[cumplimiento_de(dia, objetivos, hoy)] += 1
    return resultado


def agua_por_dia(tragos: list[Trago]) -> dict[date, int]:
    """Cuánta agua se bebió cada jornada."""
    total: dict[date, int] = {}
    for trago in tragos:
        total[trago.jornada] = total.get(trago.jornada, 0) + trago.ml
    return total
