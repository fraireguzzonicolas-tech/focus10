"""Las reglas del asistente. Sin red y sin pantalla: se prueban solas.

EL REPARTO DE PAPELES:
- Claude (servidor/api/asistente.py) ENTIENDE la frase y elige UNA acción con
  sus datos: «creame un hábito los lunes a las 14h» -> crear_habito.
- Focus DECIDE qué hacer con eso, aquí y en asistente_finanzas.py /
  asistente_habitos.py: si los datos valen, si hace falta preguntar antes
  (un pago que parece repetido, un borrado) o si se hace en el acto.

EL «SÍ» Y EL «NO» SE ENTIENDEN AQUÍ, SIN LLAMAR A CLAUDE: después de «¿Seguro
que querés agregar otros 400 €?» la respuesta es casi siempre una palabra.
Mandarla al servidor costaría un mensaje del tope diario y unos segundos de
espera, manejando, para entender «sí».
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time

from . import asistente_comidas, asistente_finanzas, asistente_gimnasio, asistente_habitos
from . import asistente_correcciones, asistente_organizacion
from . import dinero
from .alimento import Registro
from .ejercicio import Ejercicio, Medida
from .sesion import Sesion
from .tarea import Tarea
from .asistente_habitos import NOMBRES_DE_DIAS, texto_cuando
from .asistente_tipos import Confirmar, Decir, Hacer, Respuesta
from .categoria import Categoria
from .habito import Habito
from .memoria_gastos import Recordado
from .moneda import Moneda
from .movimiento import Movimiento
from .movimiento import Tipo
from .palabras import palabras

LARGO_MAXIMO_MEMORIA = 20_000
"""Cuánto texto de memoria se manda como mucho. El servidor acepta un poco
más; este margen evita que una memoria justo en el borde se rechace entera."""

AFIRMACIONES = frozenset(
    {"si", "dale", "confirmo", "ok", "okay", "listo", "agregalo", "agrega",
     "obvio", "claro", "correcto", "exacto", "afirmativo", "seguro", "va", "bueno"}
)
NEGACIONES = frozenset(
    {"no", "nop", "cancela", "cancelalo", "cancelar", "deja", "dejalo", "olvidalo",
     "negativo", "nada"}
)


# --------------------------------------------------------------------------
# Lo que se manda: la memoria en texto
# --------------------------------------------------------------------------


def memoria_para_la_ia(memoria: list[Recordado]) -> str:
    """La memoria en el texto que lee Claude: primero los totales, luego cada gasto.

    LOS TOTALES LOS SUMA FOCUS Y SE LOS DA HECHOS: a la pregunta «¿cuánto llevo
    en Proyecto IA?» la respuesta tiene que ser exacta, y un modelo sumando
    treinta importes puede equivocarse. Así solo tiene que leerlos.

    SI NO ENTRA TODO, SE CORTAN LOS MÁS VIEJOS, y se dice cuántos quedaron
    fuera. Los totales siguen contándolos a todos.
    """
    if not memoria:
        return ""
    totales: dict[tuple[str, Moneda], tuple[int, int]] = {}
    for uno in memoria:
        suma, cuantos = totales.get((uno.categoria, uno.moneda), (0, 0))
        totales[(uno.categoria, uno.moneda)] = (suma + uno.importe, cuantos + 1)
    lineas = ["TOTALES:"] + [
        f"- {categoria}: {dinero.formatear(suma, moneda)} en {cuantos} "
        f"gasto{'s' if cuantos != 1 else ''}"
        for (categoria, moneda), (suma, cuantos) in sorted(
            totales.items(), key=lambda par: (par[0][0], par[0][1].codigo)
        )
    ]
    lineas.append("GASTOS (del más nuevo al más viejo):")
    largo = sum(len(una) + 1 for una in lineas)
    for indice, uno in enumerate(memoria):
        linea = (
            f"- {uno.jornada.isoformat()} · {uno.categoria} · "
            f"{dinero.formatear(uno.importe, uno.moneda)} · {uno.descripcion or 'sin nota'}"
        )
        if largo + len(linea) + 1 > LARGO_MAXIMO_MEMORIA:
            lineas.append(f"(y {len(memoria) - indice} gastos más viejos que no entran)")
            break
        lineas.append(linea)
        largo += len(linea) + 1
    return "\n".join(lineas)


# --------------------------------------------------------------------------
# Lo que se manda: el contexto entero
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class Contexto:
    """Todo lo que Focus sabe en el momento de contestar. Lo arma la pantalla
    leyendo la base; aquí solo se usa, así esto se prueba sin base."""

    hoy: date
    principal: Moneda
    categorias: list[Categoria]
    """Las activas de gasto e ingreso."""
    memoria: list[Recordado]
    habitos: list[Habito]
    """Los activos."""
    con_historial: frozenset[int]
    """Los ids de los hábitos con marcas: esos no se borran, se archivan."""
    iconos: tuple[str, ...]
    """Las claves de ícono que existen (interfaz/iconos_habito.py)."""
    jornada: date | None = None
    """El día abierto de Focus: donde caen las comidas de «hoy»."""
    ahora: datetime | None = None
    comidas_conocidas: tuple[Registro, ...] = ()
    """Lo que ya apuntaste alguna vez (lo último de cada nombre): lo tuyo gana
    a la tabla al estimar una comida."""
    biblioteca: tuple[Ejercicio, ...] = ()
    """Los ejercicios de la biblioteca: el gimnasio busca aquí por nombre."""
    sesion_hoy: Sesion | None = None
    """El entreno del día abierto, si lo hay."""
    ejercicios_recientes: frozenset[int] = frozenset()
    """Los ids de lo que hiciste en las últimas semanas: si «press banca»
    encaja con varios, gana el que hiciste."""
    comidas_de_hoy: tuple[Registro, ...] = ()
    """Lo comido hoy: una corrección («eran 250 g de arroz») cambia uno de estos."""
    ultimo_movimiento: Movimiento | None = None
    """El último movimiento del día abierto: lo que corrige «eran para el ahorro»."""
    tareas_pendientes: tuple[Tarea, ...] = ()
    """Los recordatorios sin hacer: para dar uno por hecho por su nombre."""
    resumen: str = ""
    """Los totales de hoy, la semana y el mes, YA CALCULADOS por Focus
    (datos/asistente_resumen.py), para contestar preguntas sin inventar."""


def contexto_para_la_ia(contexto: Contexto) -> str:
    """El texto que lee Claude además de la conversación.

    SOLO NOMBRES Y LO JUSTO: para elegir bien una categoría o un hábito hace
    falta saber cuáles hay; el resto de tus datos no viaja.
    """
    gastos = [una.nombre for una in contexto.categorias if una.tipo is Tipo.GASTO]
    ingresos = [una.nombre for una in contexto.categorias if una.tipo is Tipo.INGRESO]
    habitos = [
        f"- {uno.nombre} · {texto_cuando(uno)} · {uno.objetivo} {uno.unidad}"
        for uno in contexto.habitos
    ]
    partes = [
        f"Hoy es {contexto.hoy.isoformat()} ({NOMBRES_DE_DIAS[contexto.hoy.weekday()]}). "
        f"Moneda principal: {contexto.principal.codigo}.",
        f"Categorías de gasto: {', '.join(gastos) or '(ninguna)'}",
        f"Categorías de ingreso: {', '.join(ingresos) or '(ninguna)'}",
        "HÁBITOS:\n" + ("\n".join(habitos) or "(ninguno)"),
        f"Íconos de hábito: {', '.join(contexto.iconos)}",
        "Ejercicios de tiempo de la biblioteca: "
        + (", ".join(uno.nombre for uno in contexto.biblioteca if uno.medida is Medida.TIEMPO)
           or "(ninguno)"),
        "MEMORIA DE GASTOS (las categorías que la persona marcó para recordar):\n"
        + (memoria_para_la_ia(contexto.memoria) or "(vacía)"),
    ]
    if contexto.resumen:
        partes.append("RESUMEN DE LA CUENTA (calculado por Focus, usalo tal cual):\n" + contexto.resumen)
    return "\n\n".join(partes)


# --------------------------------------------------------------------------
# Qué hace Focus con lo que vuelve
# --------------------------------------------------------------------------


def decidir(respuesta: Respuesta, contexto: Contexto) -> Decir | Hacer | Confirmar:
    """Cada acción, a quien sabe de ella. Sin acción, se dice lo que contestó."""
    accion = respuesta.accion
    if accion is None:
        return Decir(respuesta.texto or "No te entendí. ¿Me lo decís de otra forma?")
    if accion.nombre == "registrar_movimiento":
        return asistente_finanzas.decidir(
            accion.datos, contexto.categorias, contexto.memoria, contexto.principal
        )
    if accion.nombre == "crear_habito":
        return asistente_habitos.decidir_crear(accion.datos, contexto.iconos)
    if accion.nombre == "cambiar_habito":
        return asistente_habitos.decidir_cambiar(accion.datos, contexto.habitos, contexto.iconos)
    if accion.nombre == "registrar_comida":
        jornada = contexto.jornada or contexto.hoy
        return asistente_comidas.decidir_comida(
            accion.datos, jornada,
            contexto.ahora or datetime.combine(jornada, time(12)),
            list(contexto.comidas_conocidas),
        )
    if accion.nombre == "marcar_habito":
        return asistente_organizacion.decidir_marcar(
            accion.datos, contexto.habitos, contexto.jornada or contexto.hoy
        )
    if accion.nombre == "crear_recordatorio":
        return asistente_organizacion.decidir_recordatorio(accion.datos, contexto.jornada or contexto.hoy)
    if accion.nombre == "completar_recordatorio":
        return asistente_organizacion.decidir_completar(
            accion.datos, list(contexto.tareas_pendientes), contexto.jornada or contexto.hoy
        )
    if accion.nombre == "anotar_series":
        return asistente_gimnasio.decidir_anotar(
            accion.datos, list(contexto.biblioteca), set(contexto.ejercicios_recientes),
            contexto.jornada or contexto.hoy,
        )
    if accion.nombre == "corregir_serie":
        return asistente_gimnasio.decidir_corregir(
            accion.datos, contexto.sesion_hoy, list(contexto.biblioteca),
            set(contexto.ejercicios_recientes),
        )
    if accion.nombre == "terminar_entreno":
        return asistente_gimnasio.decidir_terminar(
            contexto.sesion_hoy, contexto.ahora or datetime.combine(contexto.hoy, time(12))
        )
    if accion.nombre == "corregir_comida":
        return asistente_correcciones.decidir_comida(
            accion.datos, list(contexto.comidas_de_hoy), list(contexto.comidas_conocidas)
        )
    if accion.nombre == "corregir_movimiento":
        return asistente_correcciones.decidir_movimiento(
            accion.datos, contexto.ultimo_movimiento, contexto.categorias, contexto.principal
        )
    if accion.nombre == "borrar_habito":
        return asistente_habitos.decidir_borrar(
            accion.datos, contexto.habitos, contexto.con_historial
        )
    # UNA ACCIÓN QUE ESTA VERSIÓN NO CONOCE: el servidor ya sabe hacer algo
    # nuevo y esta app todavía no se actualizó. Se dice, no se finge.
    return Decir("Eso todavía no lo sé hacer en esta versión de Focus.")


def resultado_para_la_ia(decision: Decir | Hacer | Confirmar, hecho: bool | None) -> str:
    """Lo que se le cuenta a Claude de cómo salió su acción («[Focus] …»).

    HACE FALTA CONTÁRSELO: si no, la próxima vez no sabe si el hábito existe
    o si el gasto quedó apuntado, y contestaría a ciegas.
    """
    if isinstance(decision, Decir):
        return f"[Focus] No se hizo: {decision.texto}"
    if hecho is False:
        return "[Focus] La persona dijo que no: no se hizo."
    return f"[Focus] Hecho: {decision.orden.frase()}."


def contesta_si_o_no(texto: str) -> bool | None:
    """True si dice que sí, False si dice que no, None si dice otra cosa.

    SE MIRA LA PRIMERA PALABRA: «sí, dale», «no, dejá». Si dice otra cosa
    («en realidad eran 300»), no es ni sí ni no y se le manda a Claude.
    """
    primeras = palabras(texto)[:1]
    if not primeras:
        return None
    if primeras[0] in AFIRMACIONES:
        return True
    if primeras[0] in NEGACIONES:
        return False
    return None
