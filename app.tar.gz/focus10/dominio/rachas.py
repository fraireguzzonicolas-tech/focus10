"""Las rachas y el cumplimiento diario.

LAS DOS REGLAS QUE LO DECIDEN TODO, acordadas con el usuario:

  1. Solo cuentan los días en que el hábito TOCABA. Si "gimnasio" es lunes,
     miércoles y viernes, no hacerlo un martes no rompe nada: ese martes no
     existe para la racha.

  2. HOY NO ROMPE LA RACHA. Si hoy tocaba y todavía no lo has cumplido, la racha
     se queda como estaba, porque el día no ha terminado. Solo la rompe un día
     PASADO sin cumplir. Ver la racha caer a cero a media mañana desanima, y
     además sería mentira: aún puedes cumplirla.

POR QUÉ ESTO ESTÁ AQUÍ Y NO EN LA BASE DE DATOS: es una cuenta, no un dato. Si
se guardara la racha habría que acordarse de recalcularla cada vez que se marca,
se desmarca o se cambian los días del hábito; calculada al vuelo no puede quedar
desfasada nunca.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from datetime import date, timedelta

from .habito import Habito

UN_DIA = timedelta(days=1)


@dataclass(frozen=True)
class Rachas:
    actual: int
    """Días seguidos cumpliendo, contando hasta hoy."""

    mejor: int
    """La racha más larga que se ha llegado a tener."""


@dataclass(frozen=True)
class CumplimientoDelDia:
    """Cuántos hábitos tocaban ese día y cuántos se cumplieron."""

    jornada: date
    cumplidos: int
    programados: int

    @property
    def hay_algo_programado(self) -> bool:
        """False si ese día no tocaba ningún hábito.

        Se distingue de "programados = 0 y cumplidos = 0" a propósito: un día sin
        nada programado no es un día fallado, y en el calendario va en gris en
        vez de en rojo.
        """
        return self.programados > 0

    @property
    def proporcion(self) -> float:
        """De 0 a 1. Cero si no tocaba nada, para poder pintarlo sin dividir."""
        if not self.programados:
            return 0.0
        return self.cumplidos / self.programados

    def texto(self) -> str:
        """Lo que se escribe en el calendario: "3/5", o "—" si no tocaba nada."""
        if not self.hay_algo_programado:
            return "—"
        return f"{self.cumplidos}/{self.programados}"


def calcular_rachas(
    habito: Habito, cantidades: dict[date, int], hoy: date
) -> Rachas:
    """La racha actual y la mejor de un hábito.

    `cantidades` es lo marcado en cada jornada; las jornadas que no estén se
    tratan como cero. Se recorre desde la primera jornada con datos hasta hoy.
    """
    if not isinstance(hoy, date):
        raise TypeError("hoy tiene que ser un date")

    if not cantidades:
        # Sin nada marcado no hay racha, ni buena ni mala.
        return Rachas(actual=0, mejor=0)

    # El recorrido TERMINA en hoy: una marca con fecha futura (o el reloj mal
    # puesto) no puede inflar la racha. Y empieza en la primera marca que haya:
    # si todas fueran futuras, el recorrido sale vacío y la racha es cero, que
    # es lo correcto.
    actual = 0
    mejor = 0
    for dia in _dias_entre(min(cantidades), hoy):
        if not habito.toca_en(dia):
            # Ese día no tocaba: ni suma ni rompe.
            continue

        if habito.cumplido_con(cantidades.get(dia, 0)):
            actual += 1
            mejor = max(mejor, actual)
        elif dia == hoy:
            # Hoy no rompe: el día no ha terminado todavía.
            continue
        else:
            actual = 0

    return Rachas(actual=actual, mejor=mejor)


def cumplimiento(
    habitos: Iterable[Habito],
    cantidades: dict[tuple[int, date], int],
    jornada: date,
) -> CumplimientoDelDia:
    """Cuántos de los hábitos que tocaban ese día se cumplieron.

    `cantidades` va indexado por (id del hábito, jornada), que es como sale de la
    base de datos cuando se piden varios días de varios hábitos de una vez.
    """
    programados = 0
    cumplidos = 0
    for habito in habitos:
        if not habito.toca_en(jornada):
            continue
        programados += 1
        if habito.cumplido_con(cantidades.get((habito.id, jornada), 0)):
            cumplidos += 1

    return CumplimientoDelDia(
        jornada=jornada, cumplidos=cumplidos, programados=programados
    )


def cumplimiento_de_varios(
    habitos: Iterable[Habito],
    cantidades: dict[tuple[int, date], int],
    dias: Iterable[date],
) -> list[CumplimientoDelDia]:
    """Lo mismo para una tira de días: la semana, o el mes entero."""
    habitos = list(habitos)
    return [cumplimiento(habitos, cantidades, dia) for dia in dias]


def media_de_semanas_anteriores(
    cumplimientos_por_semana: list[list[CumplimientoDelDia]],
) -> list[float | None]:
    """La media de cumplimiento de cada día de la semana, entre varias semanas.

    Devuelve siete números (lunes a domingo), o None en el día del que no haya
    ningún dato. None y no cero, porque "nunca tuve nada ese día" no es lo mismo
    que "ese día lo fallé todo", y dibujarlos igual sería mentir.

    Es la línea punteada de la gráfica: sirve para distinguir un mal miércoles
    suelto de que TODOS los miércoles se hundan, que es información distinta.
    """
    sumas: list[float] = [0.0] * 7
    cuantos: list[int] = [0] * 7

    for semana in cumplimientos_por_semana:
        for dia in semana:
            if not dia.hay_algo_programado:
                continue
            indice = dia.jornada.weekday()
            sumas[indice] += dia.proporcion
            cuantos[indice] += 1

    return [
        sumas[indice] / cuantos[indice] if cuantos[indice] else None
        for indice in range(7)
    ]


def _dias_entre(desde: date, hasta: date) -> Iterator[date]:
    """Todos los días del intervalo, los dos extremos incluidos."""
    dia = desde
    while dia <= hasta:
        yield dia
        dia += UN_DIA
