"""El dibujo del hueco de la barra lateral, uno por tema.

LO PIDIÓ EL USUARIO señalando el hueco entre «Configuración» y la versión: «la
verdad que me molesta». Y dijo cómo lo quería: «tipo croquis, no un dibujo
profesional». Natural lleva un zorro, Galaxia un planeta, y así trece de
los catorce: Elegante se queda vacío, ver DIBUJOS.

POR QUÉ A TRAZO Y NO UNA IMAGEN: por lo mismo que los motivos de fondo. Catorce
imágenes serían catorce archivos que pesan, que hay que meter en la web y en el
móvil, y que no cambian de color cuando cambias de claro a oscuro. Un trazo sí:
toma el acento del tema y no pesa nada.

EL AIRE DE CROQUIS SALE DE PASAR DOS VECES. Cada línea se dibuja una vez bien y
otra desplazada un pelo, como quien repasa a lápiz. Una sola pasada perfecta
parece un icono; dos que no coinciden del todo parecen hechas a mano.

EL AZAR LLEVA SEMILLA FIJA, igual que en motivo_fondo.py: la barra se vuelve a
montar en cada cambio de sección, y un temblor distinto cada vez se vería como
que el dibujo tiembla de verdad.

UNA COSA QUE NO HACE, y hay que saberla: en el móvil esta barra no existe (el
menú va abajo), así que el dibujo solo se ve con la ventana ancha.
"""

from __future__ import annotations

import math
import random

import flet as ft
import flet.canvas as cv

from .estilo import Paleta, con_opacidad

LADO = 140
"""Todos los dibujos se piensan en un cuadrado de 140 x 140.

Cabe en la barra (236 de ancho) con margen, y deja sitio a los enlaces en una
ventana de altura normal.
"""

OPACIDAD = 0.40
"""Elegido por él: «visible pero suave». Como un dibujo a lápiz en el margen de
un cuaderno: se ve a la primera, pero no compite con el menú."""

TEMBLOR = 1.1
"""Cuánto se aparta la segunda pasada, en píxeles. Con más, parece borroso; con
menos, las dos pasadas se funden y vuelve a parecer un icono."""


# ---------------------------------------------------------------------------
# Las piezas con que se dibuja todo
# ---------------------------------------------------------------------------
#
# Un dibujo es una lista de trazos. Cada trazo es una de estas tres cosas:
#   ("l", [(x, y), ...])   una línea que pasa por esos puntos
#   ("c", x, y, radio)     una circunferencia
#   ("p", x, y, radio)     un punto relleno (ojos, estrellas)


def _elipse(cx, cy, rx, ry, *, desde=0.0, hasta=360.0, giro=0.0, pasos=28):
    """Los puntos de una elipse o de un trozo de ella, girada si hace falta.

    SE DEVUELVEN PUNTOS Y NO UN ARCO DE VERDAD porque así cualquier curva pasa
    por el mismo camino que las rectas, y le toca el mismo temblor de croquis.
    """
    g = math.radians(giro)
    puntos = []
    for i in range(pasos + 1):
        a = math.radians(desde + (hasta - desde) * i / pasos)
        x, y = rx * math.cos(a), ry * math.sin(a)
        puntos.append((cx + x * math.cos(g) - y * math.sin(g), cy + x * math.sin(g) + y * math.cos(g)))
    return puntos


def _onda(x0, x1, y, alto, periodo, *, pasos=24):
    """Una línea ondulada de izquierda a derecha. Para la aurora."""
    return [
        (x0 + (x1 - x0) * i / pasos, y + alto * math.sin((x0 + (x1 - x0) * i / pasos) / periodo))
        for i in range(pasos + 1)
    ]


# ---------------------------------------------------------------------------
# Los trece dibujos
# ---------------------------------------------------------------------------


def _palmera():
    """80s: una palmera delante de un sol partido en rayas."""
    trazos = [("c", 62, 72, 32), ("l", [(10, 104), (130, 104)])]
    for y in (80, 90, 98):
        mitad = math.sqrt(32**2 - (y - 72) ** 2)
        trazos.append(("l", [(62 - mitad, y), (62 + mitad, y)]))
    trazos += [
        ("l", [(96, 104), (94, 80), (98, 56), (104, 40)]),
        ("l", [(104, 40), (86, 34), (72, 44)]),
        ("l", [(104, 40), (92, 24), (80, 20)]),
        ("l", [(104, 40), (118, 26), (130, 28)]),
        ("l", [(104, 40), (124, 44), (132, 58)]),
        ("l", [(104, 40), (107, 20)]),
    ]
    return trazos


def _copa():
    """Premium: una copa de vino."""
    return [
        ("l", _elipse(70, 24, 24, 5)),
        ("l", [(46, 24), (46, 48), (52, 64), (70, 76), (88, 64), (94, 48), (94, 24)]),
        ("l", [(47, 46), (93, 46)]),
        ("l", [(70, 76), (70, 110)]),
        ("l", _elipse(70, 112, 20, 4)),
    ]


def _enso():
    """Minimalista: un círculo a pincel que no se cierra, y nada más.

    NO SE CIERRA A PROPÓSITO: el ensō japonés deja el hueco para decir que falta
    algo, que es lo más cercano a «menos es más» que se puede dibujar.
    """
    return [("l", _elipse(70, 70, 44, 42, desde=120, hasta=430, pasos=40))]


def _zorro():
    """Natural: un zorro sentado, de frente, con la cola a un lado."""
    return [
        ("l", [(50, 52), (44, 28), (60, 42), (70, 40), (80, 42), (96, 28), (90, 52),
               (84, 64), (70, 74), (56, 64), (50, 52)]),
        ("p", 62, 54, 1.8),
        ("p", 78, 54, 1.8),
        ("p", 70, 67, 2.2),
        ("l", [(58, 70), (50, 90), (48, 114), (92, 114), (90, 90), (82, 70)]),
        ("l", [(62, 78), (70, 96), (78, 78)]),
        ("l", [(60, 114), (60, 100)]),
        ("l", [(80, 114), (80, 100)]),
        ("l", [(92, 112), (112, 108), (124, 92), (118, 78), (106, 88), (96, 104)]),
    ]


def _naranja():
    """Solar Pop: media naranja en rodaja, apoyada en su corte."""
    trazos = [
        ("l", _elipse(70, 92, 52, 52, desde=180, hasta=360)),
        ("l", _elipse(70, 92, 44, 44, desde=180, hasta=360)),
        ("l", [(18, 92), (122, 92)]),
    ]
    for grados in (210, 240, 270, 300, 330):
        a = math.radians(grados)
        trazos.append(("l", [(70, 92), (70 + 40 * math.cos(a), 92 + 40 * math.sin(a))]))
    return trazos


def _rayo():
    """Electric Studio: un rayo con tres chispas."""
    return [
        ("l", [(84, 14), (42, 78), (66, 78), (54, 126), (100, 58), (74, 58), (92, 14), (84, 14)]),
        ("l", [(104, 38), (116, 32)]),
        ("l", [(108, 50), (122, 50)]),
        ("l", [(34, 96), (22, 102)]),
    ]


def _tortuga():
    """Isla Serena: una tortuga marina nadando despacio, vista desde arriba."""
    return [
        ("l", _elipse(70, 72, 28, 24)),
        ("l", [(70, 56), (84, 64), (84, 80), (70, 88), (56, 80), (56, 64), (70, 56)]),
        ("l", _elipse(70, 40, 7, 9)),
        ("l", [(48, 62), (28, 46), (22, 52), (44, 72)]),
        ("l", [(92, 62), (112, 46), (118, 52), (96, 72)]),
        ("l", [(54, 90), (42, 104), (50, 106), (62, 94)]),
        ("l", [(86, 90), (98, 104), (90, 106), (78, 94)]),
        ("l", [(12, 118), (22, 114), (32, 118)]),
        ("l", [(108, 22), (118, 18), (128, 22)]),
    ]


def _aurora():
    """Aurora: unas montañas y la aurora ondeando encima."""
    trazos = [
        ("l", [(8, 118), (40, 76), (58, 94), (82, 56), (132, 118)]),
        ("l", [(74, 67), (82, 56), (90, 67)]),
        ("l", _onda(10, 130, 22, 6, 14)),
        ("p", 24, 10, 1.2),
        ("p", 116, 8, 1.2),
    ]
    # LAS CORTINAS: rayas que cuelgan de la onda, DE LARGOS DISTINTOS. Con todas
    # iguales y una segunda onda debajo parecía un puente colgante; es el largo
    # desigual lo que hace que se lean como luz que cae.
    for i, x in enumerate(range(18, 128, 9)):
        y = 22 + 6 * math.sin(x / 14)
        largo = (14, 26, 20, 32, 18, 28, 16, 24, 30, 18, 22, 14, 20)[i]
        trazos.append(("l", [(x, y), (x + 1.5, y + largo)]))
    return trazos


def _taza():
    """Terra Bold: una taza de café humeando sobre una libreta."""
    return [
        ("l", [(14, 100), (98, 100), (126, 78), (42, 78), (14, 100)]),
        ("l", [(14, 100), (14, 106), (98, 106), (126, 84), (126, 78)]),
        ("l", [(98, 100), (98, 106)]),
        ("l", _elipse(70, 40, 18, 4)),
        ("l", [(52, 40), (55, 80), (85, 80), (88, 40)]),
        ("l", [(88, 48), (100, 50), (100, 64), (86, 68)]),
        ("l", [(62, 32), (58, 24), (64, 16)]),
        ("l", [(76, 32), (72, 24), (78, 16)]),
    ]


def _robot():
    """AI Workspace: un robot pequeño. Le da algo de calidez a un tema frío."""
    return [
        ("l", [(44, 36), (96, 36), (96, 74), (44, 74), (44, 36)]),
        ("l", [(70, 36), (70, 24)]),
        ("c", 70, 21, 3),
        ("c", 58, 54, 5),
        ("c", 82, 54, 5),
        ("l", [(60, 66), (80, 66)]),
        ("l", [(64, 74), (64, 80)]),
        ("l", [(76, 74), (76, 80)]),
        ("l", [(50, 80), (90, 80), (90, 114), (50, 114), (50, 80)]),
        ("c", 70, 96, 5),
        ("l", [(50, 88), (36, 100), (38, 108)]),
        ("l", [(90, 88), (104, 100), (102, 108)]),
    ]


def _lampara():
    """Focus Studio: una lámpara de escritorio articulada."""
    return [
        ("l", [(28, 118), (72, 118)]),
        ("l", [(34, 118), (38, 110), (62, 110), (66, 118)]),
        ("l", [(50, 110), (40, 72)]),
        ("c", 40, 72, 3),
        ("l", [(40, 72), (76, 44)]),
        ("c", 76, 44, 3),
        ("l", [(74, 38), (86, 28), (112, 60), (94, 72), (74, 38)]),
        ("l", [(104, 78), (112, 94)]),
        ("l", [(94, 82), (96, 98)]),
        ("l", [(114, 72), (126, 84)]),
    ]


def _anillo(cx, cy, radio_planeta):
    """El anillo del planeta, cortado donde pasa POR DETRÁS.

    Dibujado entero, el anillo cruza el planeta por delante y parece un
    planeta tachado. La mitad de atrás se corta donde la tapa el planeta; la
    de delante se dibuja entera, por encima.
    """
    trozos, actual = [], []
    for i, (x, y) in enumerate(_elipse(cx, cy, 46, 11, giro=-20, pasos=48)):
        detras = i > 24 and (x - cx) ** 2 + (y - cy) ** 2 < radio_planeta**2
        if detras:
            if len(actual) > 1:
                trozos.append(("l", actual))
            actual = []
        else:
            actual.append((x, y))
    if len(actual) > 1:
        trozos.append(("l", actual))
    return trozos


def _planeta():
    """Galaxia: un planeta con anillo y un cohetito subiendo."""
    return [
        ("c", 56, 78, 26),
        *_anillo(56, 78, 26),
        ("l", [(106, 18), (98, 32), (98, 50), (114, 50), (114, 32), (106, 18)]),
        ("c", 106, 34, 3),
        ("l", [(98, 44), (92, 54), (98, 52)]),
        ("l", [(114, 44), (120, 54), (114, 52)]),
        ("l", [(102, 52), (106, 62), (110, 52)]),
        ("p", 22, 28, 1.4),
        ("p", 124, 104, 1.4),
        ("p", 30, 122, 1.2),
        ("p", 128, 70, 1.0),
    ]


def _nube(x, y, escala):
    """Una nube a trazo: una línea de base y tres bultos encima."""
    def punto(px, py):
        return (x + px * escala, y + py * escala)

    return (
        "l",
        [punto(0, 0), punto(2, -8), punto(10, -12), punto(16, -20), punto(26, -18),
         punto(30, -10), punto(36, -8), punto(38, 0), punto(0, 0)],
    )


def _globo():
    """Heaven: un globo aerostático entre nubes."""
    return [
        ("l", [(58, 86), (44, 66), (40, 48), (46, 30), (58, 20), (70, 18), (82, 20),
               (94, 30), (100, 48), (96, 66), (82, 86), (58, 86)]),
        ("l", [(70, 18), (70, 86)]),
        ("l", [(57, 22), (52, 50), (62, 86)]),
        ("l", [(83, 22), (88, 50), (78, 86)]),
        ("l", [(61, 86), (63, 100)]),
        ("l", [(79, 86), (77, 100)]),
        ("l", [(60, 100), (80, 100), (78, 112), (62, 112), (60, 100)]),
        _nube(8, 124, 0.9),
        _nube(104, 58, 0.8),
    ]


DIBUJOS = {
    "ochentas": _palmera,
    "premium": _copa,
    "minimalista": _enso,
    "natural": _zorro,
    "solar": _naranja,
    "electric": _rayo,
    "isla": _tortuga,
    "aurora": _aurora,
    "terra": _taza,
    "ia": _robot,
    "focus": _lampara,
    "galaxia": _planeta,
    "cielo": _globo,
}
"""Uno por tema, menos Elegante. Lo vigila un test, para que un tema nuevo no
deje el hueco vacío sin que nadie se entere.

ELEGANTE NO LLEVA, Y LO DECIDIÓ ÉL después de verlo con una pluma: «el elegante
dejalo vacío». Es coherente con su motivo de fondo, que tampoco tiene: su
identidad es el espacio en blanco.
"""


# ---------------------------------------------------------------------------
# Pasarlo al lienzo
# ---------------------------------------------------------------------------


def _formas(trazos, color: str, azar: random.Random) -> list[cv.Shape]:
    """Los trazos convertidos en formas del lienzo, dos pasadas cada uno."""
    pincel = ft.Paint(
        color=color,
        stroke_width=1.6,
        style=ft.PaintingStyle.STROKE,
        stroke_cap=ft.StrokeCap.ROUND,
        stroke_join=ft.StrokeJoin.ROUND,
    )
    relleno = ft.Paint(color=color)
    formas: list[cv.Shape] = []
    for trazo in trazos:
        tipo = trazo[0]
        if tipo == "p":
            # UN PUNTO NO SE REPASA: dos puntos desplazados se leen como dos
            # ojos, no como uno dibujado a mano.
            formas.append(cv.Circle(trazo[1], trazo[2], trazo[3], paint=relleno))
            continue
        for pasada in range(2):
            temblor = TEMBLOR if pasada else 0.0

            def mover(x, y):
                return x + azar.uniform(-temblor, temblor), y + azar.uniform(-temblor, temblor)

            if tipo == "c":
                x, y = mover(trazo[1], trazo[2])
                formas.append(cv.Circle(x, y, trazo[3] + azar.uniform(-temblor, temblor) / 2, paint=pincel))
            else:
                puntos = [mover(x, y) for x, y in trazo[1]]
                elementos = [cv.Path.MoveTo(*puntos[0])]
                elementos += [cv.Path.LineTo(x, y) for x, y in puntos[1:]]
                formas.append(cv.Path(elementos, paint=pincel))
    return formas


def dibujar(paleta: Paleta) -> ft.Control | None:
    """El dibujo del tema de esta paleta, o None si el tema no tiene."""
    hacer = DIBUJOS.get(paleta.tema)
    if hacer is None:
        return None
    azar = random.Random(sum(ord(letra) for letra in paleta.tema) or 7)
    return ft.Container(
        content=cv.Canvas(_formas(hacer(), con_opacidad(paleta.acento, OPACIDAD), azar)),
        width=LADO,
        height=LADO,
        # ES DECORACIÓN: no se puede pulsar, igual que los fondos.
        disabled=True,
    )
