"""El entreno en la ventana: abrirlo, el resumen al terminar y volver.

ENTRENANDO, LA VENTANA ENTERA ES EL ENTRENO (sin menú), con la franja del
descanso debajo. Esto estaba dentro de app.py, que pasaba de las mil
trescientas líneas; se separó en la auditoría del 13 nov 2026. Es parte de
Ventana, que hereda esta clase.
"""

from __future__ import annotations

from datetime import date, datetime

import flet as ft

from ..datos import asistente_guardado, repositorio_gimnasio
from ..datos.bd import conectado
from .entreno import PantallaEntreno
from .secciones import SECCION_INICIAL


class EntrenoEnLaVentana:
    """Lo que hace la ventana con el entreno y su resumen."""

    def _montar_el_entreno(self) -> None:
        """Dibuja solo el entreno, con la franja del descanso debajo.

        LA FRANJA SI VA: es el cronometro de descanso entre series, y es
        justamente entrenando cuando hace falta. El menu no.
        """
        if (
            self.pantalla_entreno is None
            or self.pantalla_entreno.dia != self.entrenando
            or self.pantalla_entreno.bloque != self.entrenando_bloque
        ):
            self.pantalla_entreno = PantallaEntreno(
                self.pagina,
                self.paleta,
                self.entrenando,
                al_salir=self._cerrar_entreno,
                al_repintar=self.montar,
                al_terminar=self._resumen_al_terminar,
                franja=self.franja,
                bloque=self.entrenando_bloque,
            )
        self.pagina.add(
            ft.Column(
                [
                    self.pantalla_entreno.control(self.paleta),
                    self.franja.control(self.paleta),
                ],
                spacing=0,
                expand=True,
            )
        )
        self.pagina.update()
        self.franja.empezar_a_latir()
        # Y EL RELOJ DEL ENTRENO. Después del update, como la franja: necesita
        # estar ya en la página para poder cambiarse a sí mismo cada segundo.
        self.pantalla_entreno.empezar_a_latir()

    def _retomar_lo_que_quedo_a_medias(self) -> None:
        """Vuelve al entreno y al descanso que había si la app se cerró sola."""
        try:
            with conectado() as conexion:
                # Y DE PASO, LA CHARLA DEL ASISTENTE QUE YA VENCIÓ: se borra al
                # abrir aunque no abras el asistente (ver asistente_guardado).
                asistente_guardado.borrar_si_vencio(conexion, datetime.now())
                en_marcha = repositorio_gimnasio.sesion_en_marcha(
                    conexion, datetime.now()
                )
        except Exception:  # noqa: BLE001
            # MEJOR ABRIR EN EL DASHBOARD QUE NO ABRIR: si algo falla al mirar,
            # el entreno sigue guardado y se retoma a mano desde Gimnasio.
            return
        if en_marcha is None:
            return
        self.entrenando = en_marcha.fecha
        self.entrenando_bloque = en_marcha.bloque
        self.franja.retomar()

    def _abrir_entreno(self, dia: date, bloque: str | None = None) -> None:
        """Deja la ventana entera en modo entrenar, con ESE entreno del día."""
        self.entrenando = dia
        self.entrenando_bloque = bloque
        self.montar()

    def _abrir_resumen(self, dia: date, bloque: str | None = None) -> None:
        """Deja el entreno y ensena lo que se hizo: ESE entreno, si se dice."""
        if self.pantalla_entreno is not None:
            self.pantalla_entreno.parar()
        self.entrenando = None
        self.pantalla_entreno = None
        self.resumiendo = dia
        self.resumiendo_bloque = bloque
        self.montar()

    def _resumen_al_terminar(self, dia: date, bloque: str | None = None) -> None:
        """«Terminar» lleva al resumen, y del resumen SE VUELVE AL DASHBOARD.

        LO PIDIÓ EL USUARIO: al acabar quería volver «al dashboard y al apartado
        principal». El resumen que se abre desde el calendario del gimnasio, en
        cambio, vuelve al gimnasio: ahí estabas mirando.
        """
        self.seleccionada = SECCION_INICIAL
        self._abrir_resumen(dia, bloque)

    def _ver_otro_entreno_del_dia(self, bloque: str) -> None:
        self.resumiendo_bloque = bloque
        self.montar()

    def _cerrar_resumen(self) -> None:
        self.resumiendo = None
        self.resumiendo_bloque = None
        self.montar()

    def _volver_al_entreno(self, sesion) -> None:
        """La franja «Entrenando · Volver»: de vuelta a ESE entreno."""
        self._abrir_entreno(sesion.fecha, sesion.bloque)

    def _atras_del_celular(self) -> None:
        """El botón «atrás» del celular, entrenando o en el resumen, sale de esa
        pantalla y no de Focus.

        CÓMO: la vista de la página se marca como «no se puede cerrar» y, al
        intentarlo, Flet avisa en vez de cerrar. EN LO DEMÁS SE DESHACE, para
        que «atrás» siga haciendo lo de siempre en el resto de la app.
        En la PC no hay botón «atrás» y esto no cambia nada.

        EL RESUMEN TAMBIÉN (lo pidió el usuario): sin esto, «atrás» ahí cerraba
        la aplicación entera, porque el resumen tapa la ventana igual que el
        entreno.
        """
        vistas = getattr(self.pagina, "views", None)
        if not vistas:
            return
        vista = vistas[0]
        if self.entrenando is None and self.resumiendo is None:
            vista.can_pop = True
            vista.on_confirm_pop = None
            return

        async def al_pulsar_atras(_):
            # SE CANCELA EL CIERRE PRIMERO: si no se contesta, Flet lo cancela
            # solo tras una espera, y la flecha tardaría en reaccionar.
            await vista.confirm_pop(False)
            if self.entrenando is not None:
                self._cerrar_entreno()
            elif self.resumiendo is not None:
                self._cerrar_resumen()

        vista.can_pop = False
        vista.on_confirm_pop = al_pulsar_atras

    def _cerrar_entreno(self) -> None:
        """Vuelve a la aplicacion. El entreno sigue guardado como estaba.

        SE PARA EL RELOJ ANTES DE SOLTAR LA PANTALLA: si no, la cuenta se
        quedaria dando vueltas para siempre sobre un control que ya no esta en
        ninguna ventana, y cada entreno dejaria otra.
        """
        if self.pantalla_entreno is not None:
            self.pantalla_entreno.parar()
        self.entrenando = None
        self.entrenando_bloque = None
        self.pantalla_entreno = None
        self.montar()
