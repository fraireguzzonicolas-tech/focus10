"""La ventanita de elegir un ejercicio, y la biblioteca entera de paso.

La usan dos sitios: añadir un ejercicio al plan de un día, y añadir uno suelto al
entreno en marcha. Es la misma ventana porque es la misma pregunta.

AQUÍ TAMBIÉN SE CREAN, SE CORRIGEN Y SE BORRAN, y eso es nuevo: antes había una
pestaña «Ejercicios» en el gimnasio solo para eso. La quitó el usuario, y el
sitio natural es éste: te das cuenta de que te falta un ejercicio JUSTO cuando
lo estás buscando para añadirlo, no antes.

LA LISTA SE LEE DE LA BASE Y NO SE RECIBE DE FUERA, porque ahora cambia mientras
la ventana está abierta: creas uno y tiene que aparecer sin cerrar nada.

CON BUSCADOR Y NO CON UN DESPLEGABLE: con cuarenta ejercicios de salida, un
desplegable obliga a recorrer la lista entera para llegar al fondo. Escribiendo
"banca" sale en dos letras, y el buscador ignora los acentos porque nadie
escribe "tríceps" con tilde estando de pie en el gimnasio.

LAS VENTANITAS NO SE APILAN: para crear o corregir hay que abrir OTRA ventana
encima, y Flet solo lleva una. Así que ésta se cierra, se abre la otra, y al
acabar ésta se vuelve a abrir sola con la lista al día. Se ve como ir y volver,
que es lo que es.
"""

from __future__ import annotations

from collections.abc import Callable

import flet as ft

from ..datos import repositorio_ejercicios
from ..datos.bd import conectado
from ..dominio.ejercicio import Ejercicio, Grupo, filtrar, ordenar
from ..dominio.zona_musculo import zona_de
from . import componentes, dialogo_ejercicio, dibujo_musculo, estilo
from .estilo import Paleta

ALTO_LISTA = 340
"""El alto de la lista. Ya no aprieta: la ventana entera se desplaza si no
cabe (ver `control`), así que con el teclado abierto encoge sin encimarse."""

ANCHO_FILTRO = 128
"""El desplegable del grupo: lo justo para «Antebrazo» y la flecha. Junto al
buscador, que se lleva el resto, entra en 375 puntos con holgura."""

TODOS = "todos"
"""La opción «Todos» del desplegable. Una clave con letras y no vacía: un
desplegable con una opción de clave vacía no la marca como elegida."""

CUANTOS_DE_GOLPE = 40
"""Cuantas fichas se pintan como mucho.

CON 255 EJERCICIOS ESTO NO ES UN CAPRICHO: cada tecla vuelve a construir la
lista, y 255 controles por pulsacion se notan como un tiron al escribir. Nadie
recorre 255 nombres con la vista de todas formas; para eso esta el buscador.
Cuando hay mas de los que caben se dice cuantos faltan, que es muy distinto de
esconderlos sin avisar."""


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    al_elegir: Callable[[Ejercicio], None],
    buscado: str = "",
) -> None:
    """Abre la ventanita. `buscado` la reabre con la búsqueda de antes puesta."""
    pagina.show_dialog(_Dialogo(pagina, paleta, al_elegir, buscado).control)


class _Dialogo:
    def __init__(
        self,
        pagina: ft.Page,
        paleta: Paleta,
        al_elegir: Callable[[Ejercicio], None],
        buscado: str = "",
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.al_elegir = al_elegir
        self.grupo: Grupo | None = None
        self._releer()

        self.buscador = componentes.campo_texto(paleta, "Buscar", valor=buscado)
        self.buscador.on_change = lambda _: self._repintar()
        self.buscador.autofocus = True

        self.lista = ft.Column(spacing=2, scroll=ft.ScrollMode.AUTO, height=ALTO_LISTA)
        self._llenar()

    def _releer(self) -> None:
        """Vuelve a leer la biblioteca. Se llama al abrir y al volver de crear."""
        with conectado() as conexion:
            self.todos = repositorio_ejercicios.listar(conexion)

    @property
    def control(self) -> ft.AlertDialog:
        """La ventana: título con su ✕, una línea de búsqueda y la lista.

        REDISEÑADA POR UNA FOTO DEL USUARIO, donde se veían tres fallos a la
        vez: los doce filtros ocupaban cuatro renglones, la lista tenía un alto
        fijo, y «Nuevo ejercicio» y «Cancelar» iban en la barra de abajo. Con el
        teclado abierto no entraba todo y la lista se metía por debajo de esos
        botones, encimando los textos.

        LO QUE CAMBIÓ Y POR QUÉ:
          - Los filtros son UN desplegable al lado del buscador: un renglón en
            vez de cuatro. Deslizar botones de costado no, por regla del
            usuario: en el móvil nada se desliza a lo ancho.
          - Sin barra de botones abajo. Cerrar es la ✕ del título, y crear un
            ejercicio es un botón ancho bajo el buscador. Sin nada debajo de la
            lista, la lista no tiene con qué encimarse.
          - La ventana entera se desplaza si no cabe (scrollable): con el
            teclado abierto encoge en vez de desbordarse.
          - En el móvil, la ventana casi toca los bordes: los márgenes de
            serie de una ventanita se comían un cuarto del ancho.
        """
        estrecha = estilo.pantalla_estrecha()
        return ft.AlertDialog(
            modal=True,
            scrollable=True,
            bgcolor=self.paleta.surface,
            inset_padding=(
                ft.Padding.symmetric(horizontal=10, vertical=20) if estrecha else None
            ),
            title=ft.Row(
                [
                    ft.Text(
                        "Elegir ejercicio",
                        size=15,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.ink,
                        expand=True,
                    ),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.CLOSE,
                        ayuda="Cerrar",
                        al_pulsar=lambda _: self.pagina.pop_dialog(),
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.Container(content=self.buscador, expand=True),
                            self._filtros(),
                        ],
                        spacing=8,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    componentes.boton_ancho(
                        self.paleta,
                        "Nuevo ejercicio",
                        icono=ft.Icons.ADD,
                        al_pulsar=lambda _: self._editar(None),
                    ),
                    self.lista,
                ],
                spacing=12,
                tight=True,
                # 460 EN LA PC, Y LO QUE HAYA EN EL MÓVIL: fijo, pedía más
                # ancho que el teléfono entero. Lo cazó la medida del buscador
                # en probar_interfaz nada más escribirla.
                width=None if estrecha else 460,
            ),
        )

    def _filtros(self) -> ft.Control:
        """El grupo muscular, en un desplegable de un solo renglón."""
        opciones = [(TODOS, "Todos")] + [
            (uno.value, uno.value.capitalize()) for uno in Grupo
        ]
        return componentes.selector(
            self.paleta,
            "Grupo",
            opciones,
            valor=self.grupo.value if self.grupo else TODOS,
            ancho=ANCHO_FILTRO,
            al_elegir=lambda evento: self._elegir_grupo(evento.control.value or TODOS),
        )

    def _elegir_grupo(self, clave: str) -> None:
        self.grupo = None if clave in ("", TODOS) else Grupo(clave)
        self._repintar()

    def _repintar(self) -> None:
        self._llenar()
        self.lista.update()

    def _llenar(self) -> None:
        encontrados = ordenar(
            filtrar(self.todos, texto=self.buscador.value or "", grupo=self.grupo)
        )
        if not encontrados:
            self.lista.controls = [
                componentes.aviso_vacio(
                    self.paleta, "Ningún ejercicio con esa búsqueda.", alto=120
                )
            ]
            return

        ensenados = encontrados[:CUANTOS_DE_GOLPE]
        self.lista.controls = [self._fila(uno) for uno in ensenados]

        faltan = len(encontrados) - len(ensenados)
        if faltan:
            # SE DICE CUANTOS FALTAN. Cortar la lista sin avisar haria creer que
            # el ejercicio que buscas no esta en la biblioteca.
            self.lista.controls.append(
                ft.Container(
                    content=ft.Text(
                        f"y {faltan} más. Escribe para encontrarlo.",
                        size=estilo.TEXTO_APOYO,
                        color=self.paleta.muted,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    padding=ft.Padding.symmetric(vertical=12),
                    alignment=ft.Alignment.CENTER,
                )
            )

    def _fila(self, ejercicio: Ejercicio) -> ft.Control:
        """Un ejercicio: su dibujo, su nombre y su grupo. Tocarlo lo añade.

        EL DIBUJO ES EL MISMO QUE EN LA RUTINA Y EN ENTRENAR: el músculo que
        trabaja, pintado en el color del tema. Se reconoce un ejercicio antes
        de leer el nombre, que es como se busca de pie en el gimnasio.

        EL NOMBRE PUEDE OCUPAR DOS RENGLONES Y NO MÁS: «Jalón de tríceps con
        agarre invertido» no cabe en uno en el móvil, y cortarlo en el primero
        escondería justo lo que lo distingue de los otros jalones.
        """
        return ft.Container(
            content=ft.Row(
                [
                    dibujo_musculo.silueta(
                        self.paleta,
                        ejercicio.grupo,
                        secundarios=ejercicio.secundarios,
                        zona=zona_de(ejercicio.nombre, ejercicio.grupo),
                        alto=dibujo_musculo.ALTO_EN_FILA,
                    ),
                    ft.Column(
                        [
                            ft.Text(
                                ejercicio.nombre,
                                size=estilo.TEXTO,
                                weight=ft.FontWeight.W_500,
                                color=self.paleta.ink,
                                max_lines=2,
                                overflow=ft.TextOverflow.ELLIPSIS,
                            ),
                            ft.Text(
                                ejercicio.resumen(),
                                size=estilo.TEXTO_APOYO,
                                color=self.paleta.muted,
                                max_lines=1,
                                overflow=ft.TextOverflow.ELLIPSIS,
                            ),
                        ],
                        spacing=1,
                        tight=True,
                        expand=True,
                    ),
                    # CORREGIR Y BORRAR, aquí mismo: te das cuenta de que una
                    # ficha está mal justo cuando la estás buscando. Van en gris,
                    # para que la fila se lea por el nombre y no por los botones.
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.EDIT_OUTLINED,
                        ayuda="Corregir",
                        al_pulsar=lambda _, e=ejercicio: self._editar(e),
                    ),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.DELETE_OUTLINE,
                        ayuda="Borrar de la biblioteca",
                        al_pulsar=lambda _, e=ejercicio: self._borrar(e),
                    ),
                ],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=8, vertical=8),
            border_radius=10,
            on_click=lambda _, e=ejercicio: self._elegido(e),
            ink=True,
        )

    def _elegido(self, ejercicio: Ejercicio) -> None:
        self.pagina.pop_dialog()
        self.al_elegir(ejercicio)

    # ------------------------------------------------------------------
    # La biblioteca: crear, corregir y borrar
    # ------------------------------------------------------------------

    def _editar(self, ejercicio: Ejercicio | None) -> None:
        """Cierra esta ventana, abre la de la ficha, y al acabar vuelve.

        SE CIERRA Y SE REABRE porque Flet solo lleva una ventanita a la vez:
        abrir la segunda encima cerraría ésta de todas formas, pero sin volver.
        Así al menos vuelves donde estabas y con lo que habías escrito.
        """
        buscado = self.buscador.value or ""
        self.pagina.pop_dialog()
        dialogo_ejercicio.abrir(
            self.pagina,
            self.paleta,
            lambda: abrir(self.pagina, self.paleta, self.al_elegir, buscado),
            ejercicio,
        )

    def _borrar(self, ejercicio: Ejercicio) -> None:
        buscado = self.buscador.value or ""
        self.pagina.pop_dialog()
        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo=f"Borrar «{ejercicio.nombre}»",
            texto=(
                "Los entrenos donde aparece SE CONSERVAN enteros: guardan el "
                "nombre aparte. Lo que se pierde es la ficha y su sitio en la "
                "rutina."
            ),
            al_aceptar=lambda _: self._borrar_de_verdad(ejercicio, buscado),
        )

    def _borrar_de_verdad(self, ejercicio: Ejercicio, buscado: str) -> None:
        # SOLTAR LAS REFERENCIAS LO HACE YA `borrar`, y esta pantalla no tiene
        # que saberlo. Aquí había una llamada a `olvidar_ejercicio` antes de
        # ésta, copiada de la pantalla vieja; la destapó un sabotaje, al ver que
        # quitarla no rompía nada. Dos sitios decidiendo el mismo orden es un
        # sitio de más donde equivocarse.
        with conectado() as conexion:
            repositorio_ejercicios.borrar(conexion, ejercicio.id)
        self.pagina.pop_dialog()
        abrir(self.pagina, self.paleta, self.al_elegir, buscado)
