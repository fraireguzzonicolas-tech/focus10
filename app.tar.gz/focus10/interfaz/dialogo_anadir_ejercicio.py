"""La ventanita de elegir un ejercicio de la biblioteca.

La usan dos sitios: añadir un ejercicio al plan de un día, y añadir uno suelto al
entreno de hoy. Es la misma ventana porque es la misma pregunta.

CON BUSCADOR Y NO CON UN DESPLEGABLE: con cuarenta ejercicios de salida, un
desplegable obliga a recorrer la lista entera para llegar al fondo. Escribiendo
"banca" sale en dos letras, y el buscador ignora los acentos porque nadie
escribe "tríceps" con tilde estando de pie en el gimnasio.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence

import flet as ft

from ..dominio.ejercicio import Ejercicio, Grupo, filtrar, ordenar
from . import componentes, estilo
from .estilo import Paleta

ALTO_LISTA = 320

CUANTOS_DE_GOLPE = 40
"""Cuantas fichas se pintan como mucho.

CON 255 EJERCICIOS ESTO NO ES UN CAPRICHO: cada tecla vuelve a construir la
lista, y 255 controles por pulsacion se notan como un tiron al escribir. Nadie
recorre 255 nombres con la vista de todas formas; para eso esta el buscador.
Cuando hay mas de los que caben se dice cuantos faltan, que es muy distinto de
esconderlos sin avisar."""


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    ejercicios: Sequence[Ejercicio],
    al_elegir: Callable[[Ejercicio], None],
) -> None:
    pagina.show_dialog(_Dialogo(pagina, paleta, ejercicios, al_elegir).control)


class _Dialogo:
    def __init__(
        self,
        pagina: ft.Page,
        paleta: Paleta,
        ejercicios: Sequence[Ejercicio],
        al_elegir: Callable[[Ejercicio], None],
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.todos = list(ejercicios)
        self.al_elegir = al_elegir
        self.grupo: Grupo | None = None

        self.buscador = componentes.campo_texto(paleta, "Buscar")
        self.buscador.on_change = lambda _: self._repintar()
        self.buscador.autofocus = True

        self.lista = ft.Column(spacing=2, scroll=ft.ScrollMode.AUTO, height=ALTO_LISTA)
        self._llenar()

    @property
    def control(self) -> ft.AlertDialog:
        return ft.AlertDialog(
            modal=True,
            title=ft.Text(
                "Elegir ejercicio",
                size=15,
                weight=ft.FontWeight.W_600,
                color=self.paleta.ink,
            ),
            bgcolor=self.paleta.surface,
            content=ft.Column(
                [self.buscador, self._filtros(), self.lista],
                spacing=12,
                tight=True,
                width=460,
            ),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda _: self.pagina.pop_dialog())
            ],
        )

    def _filtros(self) -> ft.Control:
        opciones = [("", "Todos")] + [(uno.value, uno.value.capitalize()) for uno in Grupo]
        return componentes.segmentado(
            self.paleta,
            opciones,
            self.grupo.value if self.grupo else "",
            self._elegir_grupo,
        )

    def _elegir_grupo(self, clave: str) -> None:
        self.grupo = Grupo(clave) if clave else None
        self._repintar()

    def _repintar(self) -> None:
        self._llenar()
        self.lista.update()

    def _llenar(self) -> None:
        encontrados = ordenar(
            filtrar(self.todos, texto=self.buscador.value or "", grupo=self.grupo)
        )
        if not encontrados:
            self.lista.controls = [
                componentes.aviso_vacio(
                    self.paleta, "Ningún ejercicio con esa búsqueda.", alto=120
                )
            ]
            return

        ensenados = encontrados[:CUANTOS_DE_GOLPE]
        self.lista.controls = [self._fila(uno) for uno in ensenados]

        faltan = len(encontrados) - len(ensenados)
        if faltan:
            # SE DICE CUANTOS FALTAN. Cortar la lista sin avisar haria creer que
            # el ejercicio que buscas no esta en la biblioteca.
            self.lista.controls.append(
                ft.Container(
                    content=ft.Text(
                        f"y {faltan} más. Escribe para encontrarlo.",
                        size=estilo.TEXTO_APOYO,
                        color=self.paleta.muted,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    padding=ft.Padding.symmetric(vertical=12),
                    alignment=ft.Alignment.CENTER,
                )
            )

    def _fila(self, ejercicio: Ejercicio) -> ft.Control:
        return ft.Container(
            content=ft.Row(
                [
                    ft.Column(
                        [
                            ft.Text(
                                ejercicio.nombre,
                                size=estilo.TEXTO,
                                color=self.paleta.ink,
                            ),
                            ft.Text(
                                ejercicio.resumen(),
                                size=estilo.TEXTO_APOYO,
                                color=self.paleta.muted,
                            ),
                        ],
                        spacing=0,
                        tight=True,
                        expand=True,
                    ),
                    # AQUI NO VA EL DESCANSO, y se quito a proposito. Lo que
                    # ensenaba era el de la FICHA del ejercicio, que desde la
                    # migracion 13 es solo el valor de partida: en cuanto lo
                    # anades al dia, manda lo que escribas en la Rutina.
                    # Ensenarlo aqui hacia creer que el ejercicio "viene con"
                    # ese descanso fijo, que es justo lo contrario de lo que
                    # ahora hace la aplicacion. Y de paso, la lista se lee
                    # mejor: eligiendo ejercicio lo unico que importa es cual.
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=12, vertical=9),
            border_radius=10,
            on_click=lambda _, e=ejercicio: self._elegido(e),
            ink=True,
        )

    def _elegido(self, ejercicio: Ejercicio) -> None:
        self.pagina.pop_dialog()
        self.al_elegir(ejercicio)
