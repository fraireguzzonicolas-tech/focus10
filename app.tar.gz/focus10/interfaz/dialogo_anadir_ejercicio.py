"""La ventanita de elegir un ejercicio, y la biblioteca entera de paso.

La usan dos sitios: añadir un ejercicio al plan de un día, y añadir uno suelto al
entreno en marcha. Es la misma ventana porque es la misma pregunta.

AQUÍ TAMBIÉN SE CREAN, SE CORRIGEN Y SE BORRAN, y eso es nuevo: antes había una
pestaña «Ejercicios» en el gimnasio solo para eso. La quitó el usuario, y el
sitio natural es éste: te das cuenta de que te falta un ejercicio JUSTO cuando
lo estás buscando para añadirlo, no antes.

LA LISTA SE LEE DE LA BASE Y NO SE RECIBE DE FUERA, porque ahora cambia mientras
la ventana está abierta: creas uno y tiene que aparecer sin cerrar nada.

CON BUSCADOR Y NO CON UN DESPLEGABLE: con cuarenta ejercicios de salida, un
desplegable obliga a recorrer la lista entera para llegar al fondo. Escribiendo
"banca" sale en dos letras, y el buscador ignora los acentos porque nadie
escribe "tríceps" con tilde estando de pie en el gimnasio.

LAS VENTANITAS NO SE APILAN: para crear o corregir hay que abrir OTRA ventana
encima, y Flet solo lleva una. Así que ésta se cierra, se abre la otra, y al
acabar ésta se vuelve a abrir sola con la lista al día. Se ve como ir y volver,
que es lo que es.
"""

from __future__ import annotations

from collections.abc import Callable

import flet as ft

from ..datos import repositorio_ejercicios
from ..datos.bd import conectado
from ..dominio.ejercicio import Ejercicio, Grupo, filtrar, ordenar
from . import componentes, dialogo_ejercicio, estilo
from .estilo import Paleta

ALTO_LISTA = 320

CUANTOS_DE_GOLPE = 40
"""Cuantas fichas se pintan como mucho.

CON 255 EJERCICIOS ESTO NO ES UN CAPRICHO: cada tecla vuelve a construir la
lista, y 255 controles por pulsacion se notan como un tiron al escribir. Nadie
recorre 255 nombres con la vista de todas formas; para eso esta el buscador.
Cuando hay mas de los que caben se dice cuantos faltan, que es muy distinto de
esconderlos sin avisar."""


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    al_elegir: Callable[[Ejercicio], None],
    buscado: str = "",
) -> None:
    """Abre la ventanita. `buscado` la reabre con la búsqueda de antes puesta."""
    pagina.show_dialog(_Dialogo(pagina, paleta, al_elegir, buscado).control)


class _Dialogo:
    def __init__(
        self,
        pagina: ft.Page,
        paleta: Paleta,
        al_elegir: Callable[[Ejercicio], None],
        buscado: str = "",
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.al_elegir = al_elegir
        self.grupo: Grupo | None = None
        self._releer()

        self.buscador = componentes.campo_texto(paleta, "Buscar", valor=buscado)
        self.buscador.on_change = lambda _: self._repintar()
        self.buscador.autofocus = True

        self.lista = ft.Column(spacing=2, scroll=ft.ScrollMode.AUTO, height=ALTO_LISTA)
        self._llenar()

    def _releer(self) -> None:
        """Vuelve a leer la biblioteca. Se llama al abrir y al volver de crear."""
        with conectado() as conexion:
            self.todos = repositorio_ejercicios.listar(conexion)

    @property
    def control(self) -> ft.AlertDialog:
        return ft.AlertDialog(
            modal=True,
            title=ft.Text(
                "Elegir ejercicio",
                size=15,
                weight=ft.FontWeight.W_600,
                color=self.paleta.ink,
            ),
            bgcolor=self.paleta.surface,
            content=ft.Column(
                [self.buscador, self._filtros(), self.lista],
                spacing=12,
                tight=True,
                width=460,
            ),
            actions=[
                componentes.boton(
                    self.paleta,
                    "Nuevo ejercicio",
                    icono=ft.Icons.ADD,
                    al_pulsar=lambda _: self._editar(None),
                ),
                ft.TextButton("Cancelar", on_click=lambda _: self.pagina.pop_dialog()),
            ],
        )

    def _filtros(self) -> ft.Control:
        opciones = [("", "Todos")] + [(uno.value, uno.value.capitalize()) for uno in Grupo]
        return componentes.segmentado(
            self.paleta,
            opciones,
            self.grupo.value if self.grupo else "",
            self._elegir_grupo,
        )

    def _elegir_grupo(self, clave: str) -> None:
        self.grupo = Grupo(clave) if clave else None
        self._repintar()

    def _repintar(self) -> None:
        self._llenar()
        self.lista.update()

    def _llenar(self) -> None:
        encontrados = ordenar(
            filtrar(self.todos, texto=self.buscador.value or "", grupo=self.grupo)
        )
        if not encontrados:
            self.lista.controls = [
                componentes.aviso_vacio(
                    self.paleta, "Ningún ejercicio con esa búsqueda.", alto=120
                )
            ]
            return

        ensenados = encontrados[:CUANTOS_DE_GOLPE]
        self.lista.controls = [self._fila(uno) for uno in ensenados]

        faltan = len(encontrados) - len(ensenados)
        if faltan:
            # SE DICE CUANTOS FALTAN. Cortar la lista sin avisar haria creer que
            # el ejercicio que buscas no esta en la biblioteca.
            self.lista.controls.append(
                ft.Container(
                    content=ft.Text(
                        f"y {faltan} más. Escribe para encontrarlo.",
                        size=estilo.TEXTO_APOYO,
                        color=self.paleta.muted,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    padding=ft.Padding.symmetric(vertical=12),
                    alignment=ft.Alignment.CENTER,
                )
            )

    def _fila(self, ejercicio: Ejercicio) -> ft.Control:
        return ft.Container(
            content=ft.Row(
                [
                    ft.Column(
                        [
                            ft.Text(
                                ejercicio.nombre,
                                size=estilo.TEXTO,
                                color=self.paleta.ink,
                            ),
                            ft.Text(
                                ejercicio.resumen(),
                                size=estilo.TEXTO_APOYO,
                                color=self.paleta.muted,
                            ),
                        ],
                        spacing=0,
                        tight=True,
                        expand=True,
                    ),
                    # CORREGIR Y BORRAR, aqui mismo. Antes esto vivia en una
                    # pestana aparte del gimnasio; se quito, y este es el
                    # momento en que hacen falta.
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.EDIT_OUTLINED,
                        ayuda="Corregir",
                        al_pulsar=lambda _, e=ejercicio: self._editar(e),
                    ),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.DELETE_OUTLINE,
                        ayuda="Borrar de la biblioteca",
                        al_pulsar=lambda _, e=ejercicio: self._borrar(e),
                    ),
                    # AQUI NO VA EL DESCANSO, y se quito a proposito. Lo que
                    # ensenaba era el de la FICHA del ejercicio, que desde la
                    # migracion 13 es solo el valor de partida: en cuanto lo
                    # anades al dia, manda lo que escribas en la Rutina.
                    # Ensenarlo aqui hacia creer que el ejercicio "viene con"
                    # ese descanso fijo, que es justo lo contrario de lo que
                    # ahora hace la aplicacion. Y de paso, la lista se lee
                    # mejor: eligiendo ejercicio lo unico que importa es cual.
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=12, vertical=9),
            border_radius=10,
            on_click=lambda _, e=ejercicio: self._elegido(e),
            ink=True,
        )

    def _elegido(self, ejercicio: Ejercicio) -> None:
        self.pagina.pop_dialog()
        self.al_elegir(ejercicio)

    # ------------------------------------------------------------------
    # La biblioteca: crear, corregir y borrar
    # ------------------------------------------------------------------

    def _editar(self, ejercicio: Ejercicio | None) -> None:
        """Cierra esta ventana, abre la de la ficha, y al acabar vuelve.

        SE CIERRA Y SE REABRE porque Flet solo lleva una ventanita a la vez:
        abrir la segunda encima cerraría ésta de todas formas, pero sin volver.
        Así al menos vuelves donde estabas y con lo que habías escrito.
        """
        buscado = self.buscador.value or ""
        self.pagina.pop_dialog()
        dialogo_ejercicio.abrir(
            self.pagina,
            self.paleta,
            lambda: abrir(self.pagina, self.paleta, self.al_elegir, buscado),
            ejercicio,
        )

    def _borrar(self, ejercicio: Ejercicio) -> None:
        buscado = self.buscador.value or ""
        self.pagina.pop_dialog()
        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo=f"Borrar «{ejercicio.nombre}»",
            texto=(
                "Los entrenos donde aparece SE CONSERVAN enteros: guardan el "
                "nombre aparte. Lo que se pierde es la ficha y su sitio en la "
                "rutina."
            ),
            al_aceptar=lambda _: self._borrar_de_verdad(ejercicio, buscado),
        )

    def _borrar_de_verdad(self, ejercicio: Ejercicio, buscado: str) -> None:
        # SOLTAR LAS REFERENCIAS LO HACE YA `borrar`, y esta pantalla no tiene
        # que saberlo. Aquí había una llamada a `olvidar_ejercicio` antes de
        # ésta, copiada de la pantalla vieja; la destapó un sabotaje, al ver que
        # quitarla no rompía nada. Dos sitios decidiendo el mismo orden es un
        # sitio de más donde equivocarse.
        with conectado() as conexion:
            repositorio_ejercicios.borrar(conexion, ejercicio.id)
        self.pagina.pop_dialog()
        abrir(self.pagina, self.paleta, self.al_elegir, buscado)
