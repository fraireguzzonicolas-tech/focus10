"""La pantalla de Inversiones: la cartera, con columnas que dicen lo que son.

LAS COLUMNAS TIENEN NOMBRE ENTERO Y SEPARADO, y no es cosmética. Con una columna
llamada solo "Cantidad", el usuario metió ahí los euros invertidos en vez de las
participaciones y la aplicación le dijo que tenía 49.959 € invertidos cuando eran
761 €. No fue un fallo de cálculo: la etiqueta no decía lo que el campo esperaba.

Por eso hay "Unidades" y, aparte, "Invertido": son dos cosas distintas y ahora se
llaman distinto. Y por eso la ventanita de apuntar una compra tiene dos formas de
hacerlo y una vista previa que dice en palabras lo que se va a guardar.

EL PRECIO ACTUAL SE ESCRIBE EN LA PROPIA TABLA, sin abrir nada, y se guarda con
Enter. En pantalla se distingue si vino de internet o lo escribiste tú, y de
cuándo es: un precio de hace tres semanas y uno de hace un minuto valen lo mismo
en la tabla y muy distinto en la cabeza.
"""

from __future__ import annotations

import asyncio
from datetime import datetime

import flet as ft

from ..datos import repositorio_inversiones as repo
from ..datos.bd import conectado
from ..dominio.dinero import formatear, parsear_importe
from ..dominio.inversion import texto_unidades
from ..dominio.moneda import EUR
from ..sistema import mercado
from . import componentes, dialogo_inversion, dialogo_posicion
from . import estilo
from .estilo import Paleta

ANCHO_NUMERO = 110


def _ancho_numero() -> int | None:
    """Lo que mide una columna de cifras, o None para que se estire.

    EN UN MÓVIL LAS CIFRAS NO PUEDEN LLEVAR ANCHO CLAVADO: seis columnas de 110
    son 660 puntos, y la pantalla tiene 375. Devolviendo None, cada cifra ocupa
    lo que haya.

    EN EL ORDENADOR SIGUEN CLAVADAS, y eso es lo que hace que las filas queden
    alineadas unas debajo de otras: es media gracia de una tabla de números.
    """
    return None if estilo.pantalla_estrecha() else ANCHO_NUMERO
ANCHO_PRECIO = 120


class PantallaInversiones(componentes.Pantalla):
    def __init__(self, pagina: ft.Page, paleta: Paleta) -> None:
        super().__init__(pagina, paleta)
        self._error = ""
        self._aviso = ""
        self.refrescar()

    def montada(self) -> None:
        super().montada()
        # Al entrar, los números ya están al día. En otro hilo para que la
        # pantalla se vea al momento en vez de esperar a Yahoo.
        self.pagina.run_task(self._actualizar_los_viejos)

    async def _actualizar_los_viejos(self) -> None:
        """Trae solo los precios que ya están viejos.

        Los de hace menos de quince minutos no se vuelven a pedir: entrar y salir
        de la pantalla tres veces no puede costar tres tandas de peticiones, y
        Yahoo contesta 429 si se le insiste.
        """
        with conectado() as conexion:
            if not repo.leer_precios_de_mercado(conexion):
                return
            viejas = [
                una
                for una in repo.listar(conexion)
                if mercado.necesita_refresco(
                    (repo.detalle_del_precio(conexion, una.id) or {}).get("momento"),
                    datetime.now(),
                )
            ]
        if not viejas:
            return

        await asyncio.to_thread(self._traer_precios, viejas)
        try:
            self.refrescar()
        except Exception:  # noqa: BLE001
            pass  # ya no está en pantalla

    def _traer_precio(self, id_posicion: int) -> None:
        """El precio de una sola posición, para justo después de crearla."""
        with conectado() as conexion:
            if not repo.leer_precios_de_mercado(conexion):
                return
            posicion = repo.obtener(conexion, id_posicion)
        if posicion is not None:
            self._traer_precios([posicion])

    # ----------------------------------------------------------------------

    def refrescar(self, traer_precio_de: int | None = None) -> None:
        if traer_precio_de is not None:
            # Recién creada: se le busca el precio sin que el usuario lo pida. Es
            # el punto del que se quejaba: "el precio actual no quiero
            # introducirlo manualmente".
            self._traer_precio(traer_precio_de)

        with conectado() as conexion:
            self.posiciones = repo.listar(conexion)
            self.con_mercado = repo.leer_precios_de_mercado(conexion)
            self.resumenes = {
                una.id: repo.resumen_de(conexion, una) for una in self.posiciones
            }
            self.detalles = {
                una.id: repo.detalle_del_precio(conexion, una.id)
                for una in self.posiciones
            }

        piezas: list[ft.Control] = [self._cabecera(), self._tarjeta_total()]
        if self._error:
            piezas.append(componentes.aviso_error(self.paleta, [self._error]))
        if self._aviso:
            piezas.append(componentes.aviso(self.paleta, [self._aviso]))
        piezas.append(self._tarjeta_cartera())

        self.pintar(piezas)

    def _cabecera(self) -> ft.Control:
        return componentes.titulo_pagina(
            self.paleta,
            "Inversiones",
            f"{len(self.posiciones)} posiciones"
            if self.posiciones
            else "todavía no has apuntado ninguna",
            acciones=[
                componentes.boton(
                    self.paleta,
                    "Nueva posición",
                    icono=ft.Icons.ADD,
                    principal=True,
                    al_pulsar=lambda _: dialogo_inversion.abrir(
                        self.pagina, self.paleta, self.refrescar
                    ),
                )
            ],
        )

    # ----------------------------------------------------------------------

    def _tarjeta_total(self) -> ft.Control:
        """El total de la cartera. Solo cuenta lo que tiene precio.

        Las posiciones sin precio actual se cuentan aparte y se avisa: meterlas
        en el total a su precio de compra haría que el total pareciera completo
        cuando no lo es, que es la misma clase de mentira que un precio en
        dólares guardado como euros.
        """
        invertido = sum(uno.invertido for uno in self.resumenes.values())
        con_precio = [uno for uno in self.resumenes.values() if uno.valor is not None]
        sin_precio = [
            una
            for una in self.posiciones
            if self.resumenes[una.id].valor is None
            and self.resumenes[una.id].tiene_algo
        ]
        valor = sum(uno.valor for uno in con_precio)
        invertido_con_precio = sum(uno.invertido for uno in con_precio)
        ganancia = valor - invertido_con_precio
        dividendos = sum(uno.dividendos for uno in self.resumenes.values())

        cifras = [
            ("Invertido", formatear(invertido, EUR), self.paleta.ink),
            ("Valor de lo que tiene precio", formatear(valor, EUR), self.paleta.ink),
            (
                "Ganancia / pérdida",
                _con_signo(ganancia),
                self._color(ganancia),
            ),
        ]
        if dividendos:
            cifras.append(
                ("Cobrado en dividendos", formatear(dividendos, EUR), self.paleta.ink)
            )

        piezas: list[ft.Control] = [
            ft.Row(
                [self._cifra(etiqueta, texto, color) for etiqueta, texto, color in cifras],
                spacing=28,
                wrap=True,
            ),
            self._interruptor_de_mercado(),
        ]
        if sin_precio:
            nombres = ", ".join(una.nombre for una in sin_precio)
            piezas.append(
                componentes.aviso(
                    self.paleta,
                    [
                        f"{nombres} no tiene precio actual, así que no está en el "
                        "valor de arriba. Escríbelo en su casilla o tráelo de "
                        "internet."
                    ],
                )
            )
        return componentes.tarjeta(self.paleta, ft.Column(piezas, spacing=14))

    def _cifra(self, etiqueta: str, texto: str, color: str) -> ft.Control:
        return ft.Column(
            [
                ft.Text(etiqueta, size=11, color=self.paleta.muted),
                ft.Text(texto, size=19, weight=ft.FontWeight.W_700, color=color),
            ],
            spacing=1,
            tight=True,
        )

    def _color(self, cantidad: int) -> str:
        if cantidad > 0:
            return self.paleta.positivo
        return self.paleta.negativo if cantidad < 0 else self.paleta.ink

    def _interruptor_de_mercado(self) -> ft.Control:
        piezas: list[ft.Control] = [
            componentes.interruptor(
                self.paleta,
                "Traer precios de internet (Yahoo Finance)",
                valor=self.con_mercado,
                al_cambiar=lambda e: self._cambiar_mercado(e.control.value),
            )
        ]
        if self.con_mercado:
            piezas.append(
                componentes.boton(
                    self.paleta,
                    "Actualizar todos",
                    icono=ft.Icons.CLOUD_DOWNLOAD_OUTLINED,
                    al_pulsar=lambda _: self._actualizar_todos(),
                )
            )
        piezas.append(
            ft.Text(
                "De tu ordenador sale solo el símbolo. Nada de lo que tienes ni de "
                "lo que pagaste.",
                size=11,
                color=self.paleta.muted,
            )
        )
        return ft.Row(piezas, spacing=12, wrap=True,
                      vertical_alignment=ft.CrossAxisAlignment.CENTER)

    def _cambiar_mercado(self, encendido: bool) -> None:
        with conectado() as conexion:
            repo.guardar_precios_de_mercado(conexion, bool(encendido))
        self._error = self._aviso = ""
        self.refrescar()

    # ----------------------------------------------------------------------
    # La tabla
    # ----------------------------------------------------------------------

    def _tarjeta_cartera(self) -> ft.Control:
        if not self.posiciones:
            return componentes.tarjeta(
                self.paleta,
                componentes.aviso_vacio(
                    self.paleta,
                    "Todavía no tienes ninguna posición. Créala con el botón de "
                    "arriba y apúntale la compra.",
                    icono=ft.Icons.TRENDING_UP,
                    alto=140,
                ),
            )

        filas = [self._fila(una) for una in self.posiciones]
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    self._cabecera_tabla(),
                    ft.Column(filas, spacing=0),
                ],
                spacing=8,
            ),
        )

    def _cabecera_tabla(self) -> ft.Control:
        """Los nombres de las columnas, enteros. Aquí estuvo el fallo."""
        columnas = [
            ("Posición", None),
            ("Unidades", _ancho_numero()),
            ("Precio de compra", _ancho_numero()),
            ("Invertido", _ancho_numero()),
            ("Precio actual", ANCHO_PRECIO),
            ("Valor", _ancho_numero()),
            ("Ganancia / pérdida", _ancho_numero()),
            ("", 88),
        ]
        return ft.Container(
            content=ft.Row(
                [
                    ft.Container(
                        content=ft.Text(
                            titulo,
                            size=11,
                            weight=ft.FontWeight.W_600,
                            color=self.paleta.muted,
                            text_align=ft.TextAlign.RIGHT if ancho else ft.TextAlign.LEFT,
                        ),
                        width=ancho,
                        expand=ancho is None,
                        alignment=ft.Alignment.CENTER_RIGHT
                        if ancho
                        else ft.Alignment.CENTER_LEFT,
                    )
                    for titulo, ancho in columnas
                ],
                spacing=8,
            ),
            padding=ft.Padding.only(bottom=6),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde_fuerte)),
        )

    def _fila(self, posicion) -> ft.Control:
        resumen = self.resumenes[posicion.id]
        detalle = self.detalles.get(posicion.id)

        casilla = componentes.campo_texto(
            self.paleta,
            "",
            valor=formatear(posicion.precio_actual, EUR, con_simbolo=False)
            if posicion.precio_actual is not None
            else "",
            pista="escríbelo",
            ancho=ANCHO_PRECIO,
            al_enviar=lambda e, p=posicion: self._guardar_precio(p, e.control.value),
        )
        casilla.text_align = ft.TextAlign.RIGHT

        return ft.Container(
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.Container(
                                content=ft.Column(
                                    [
                                        ft.Text(
                                            posicion.nombre,
                                            size=13,
                                            color=self.paleta.ink,
                                        ),
                                        ft.Text(
                                            f"{posicion.ticker} · {posicion.tipo.value}",
                                            size=11,
                                            color=self.paleta.muted,
                                        ),
                                    ],
                                    spacing=1,
                                    tight=True,
                                ),
                                expand=True,
                            ),
                            self._numero(texto_unidades(resumen.unidades)),
                            self._numero(formatear(resumen.precio_medio, EUR)),
                            self._numero(
                                formatear(resumen.invertido, EUR),
                                grueso=True,
                            ),
                            casilla,
                            self._numero(
                                formatear(resumen.valor, EUR)
                                if resumen.valor is not None
                                else "—"
                            ),
                            self._ganancia(resumen),
                            ft.Row(
                                [
                                    componentes.boton_icono(
                                        self.paleta,
                                        ft.Icons.ADD,
                                        ayuda="Apuntar una operación",
                                        al_pulsar=lambda _, p=posicion: (
                                            dialogo_posicion.abrir_operacion(
                                                self.pagina,
                                                self.paleta,
                                                p.id,
                                                self.refrescar,
                                            )
                                        ),
                                    ),
                                    componentes.boton_icono(
                                        self.paleta,
                                        ft.Icons.EDIT_OUTLINED,
                                        ayuda="Editar la posición y sus operaciones",
                                        al_pulsar=lambda _, p=posicion: (
                                            self._abrir_operaciones(p)
                                        ),
                                    ),
                                ],
                                spacing=0,
                                tight=True,
                            ),
                        ],
                        spacing=8,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    self._pie_del_precio(posicion, detalle),
                ],
                spacing=2,
                tight=True,
            ),
            padding=ft.Padding.symmetric(vertical=8),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
        )

    def _ganancia(self, resumen) -> ft.Control:
        """El dinero ganado y, debajo, el porcentaje.

        Los dos juntos porque dicen cosas distintas: "+61,42 €" te dice cuánto
        es, y "+8,1 %" te dice si eso es mucho para lo que pusiste. Con solo uno
        de los dos siempre falta la mitad.
        """
        if resumen.ganancia is None:
            return self._numero("—")
        color = self._color(resumen.ganancia)
        porcentaje = (
            f"{resumen.rentabilidad * 100:+.1f} %".replace(".", ",")
            if resumen.rentabilidad is not None
            else ""
        )
        return ft.Container(
            content=ft.Column(
                [
                    ft.Text(
                        _con_signo(resumen.ganancia),
                        size=13,
                        weight=ft.FontWeight.W_600,
                        color=color,
                        text_align=ft.TextAlign.RIGHT,
                    ),
                    ft.Text(
                        porcentaje, size=11, color=color, text_align=ft.TextAlign.RIGHT
                    ),
                ],
                spacing=0,
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.END,
            ),
            width=_ancho_numero(),
            alignment=ft.Alignment.CENTER_RIGHT,
        )

    def _numero(self, texto: str, *, grueso: bool = False, color=None) -> ft.Control:
        return ft.Container(
            content=ft.Text(
                texto,
                size=13,
                weight=ft.FontWeight.W_700 if grueso else ft.FontWeight.NORMAL,
                color=color or self.paleta.ink,
                text_align=ft.TextAlign.RIGHT,
            ),
            width=_ancho_numero(),
            alignment=ft.Alignment.CENTER_RIGHT,
        )

    def _pie_del_precio(self, posicion, detalle) -> ft.Control:
        """De dónde salió el precio y de cuándo. Lo pidió el usuario.

        Un precio de hace tres semanas y uno de hace un minuto valen lo mismo en
        la tabla y muy distinto en la cabeza.
        """
        if detalle is None:
            return ft.Container(height=0)

        resumen = self.resumenes[posicion.id]
        de_internet = detalle["origen"] == repo.ORIGEN_MERCADO
        trozos = []
        if resumen.diferencia_por_unidad is not None:
            trozos.append(
                f"cada unidad {_con_signo(resumen.diferencia_por_unidad)} "
                "desde que la compraste"
            )
        trozos += [
            "de internet" if de_internet else "escrito a mano",
            _hace_cuanto(detalle["momento"]),
        ]
        if de_internet and detalle["cambio"] is not None and detalle["moneda"] != "EUR":
            original = detalle["original"] / 100
            cambio = str(detalle["cambio"]).replace(".", ",")
            trozos.append(
                f"{original:.2f} {detalle['moneda']} × {cambio}"
            )
        return ft.Row(
            [
                ft.Icon(
                    ft.Icons.CLOUD_OUTLINED if de_internet else ft.Icons.EDIT_NOTE,
                    size=13,
                    color=self.paleta.muted,
                ),
                ft.Text(" · ".join(trozos), size=10, color=self.paleta.muted),
            ],
            spacing=5,
            alignment=ft.MainAxisAlignment.END,
        )

    # ----------------------------------------------------------------------

    def _guardar_precio(self, posicion, escrito: str) -> None:
        """El precio escrito en la casilla de la tabla. Sin abrir ningún diálogo."""
        limpio = (escrito or "").strip()
        if not limpio:
            return
        precio = parsear_importe(limpio, EUR)
        if precio is None or precio < 0:
            self._error = f"No entiendo «{limpio}» como precio."
            self.refrescar()
            return
        with conectado() as conexion:
            repo.guardar_precio_a_mano(conexion, posicion.id, precio)
        self._error = ""
        self.refrescar()

    def _abrir_operaciones(self, posicion) -> None:
        """La lista de operaciones de esa posición, para corregir cualquiera."""
        with conectado() as conexion:
            operaciones = repo.operaciones_de(conexion, posicion.id)

        filas = [
            ft.Container(
                content=ft.Row(
                    [
                        ft.Text(
                            str(una.fecha), size=12, color=self.paleta.muted, width=90
                        ),
                        ft.Text(
                            una.tipo.value.capitalize(),
                            size=12,
                            color=self.paleta.ink,
                            width=80,
                        ),
                        ft.Text(
                            texto_unidades(una.unidades) if una.unidades else "—",
                            size=12,
                            color=self.paleta.ink,
                            expand=True,
                            text_align=ft.TextAlign.RIGHT,
                        ),
                        ft.Text(
                            formatear(una.coste, EUR),
                            size=12,
                            weight=ft.FontWeight.W_600,
                            color=self.paleta.ink,
                            width=100,
                            text_align=ft.TextAlign.RIGHT,
                        ),
                    ],
                    spacing=8,
                ),
                padding=ft.Padding.symmetric(vertical=7, horizontal=6),
                on_click=lambda _, o=una: self._corregir_operacion(posicion, o),
                ink=True,
                tooltip="Pulsa para corregirla",
            )
            for una in operaciones
        ]

        cuerpo: ft.Control = (
            ft.Column(filas, spacing=0, scroll=ft.ScrollMode.AUTO, height=300)
            if filas
            else componentes.aviso_vacio(
                self.paleta, "Esta posición no tiene ninguna operación todavía."
            )
        )
        self.pagina.show_dialog(
            componentes.dialogo(
                self.paleta,
                posicion.nombre,
                ft.Container(
                    content=ft.Column(
                        [
                            cuerpo,
                            componentes.boton(
                                self.paleta,
                                "Corregir nombre, símbolo o tipo",
                                icono=ft.Icons.EDIT_OUTLINED,
                                al_pulsar=lambda _: self._corregir_posicion(posicion),
                            ),
                        ],
                        spacing=12,
                        tight=True,
                    ),
                    width=460,
                ),
                pagina=self.pagina,
                texto_aceptar="Cerrar",
                al_aceptar=lambda _: self.pagina.pop_dialog(),
            )
        )

    def _corregir_operacion(self, posicion, operacion) -> None:
        self.pagina.pop_dialog()
        dialogo_posicion.abrir_operacion(
            self.pagina, self.paleta, posicion.id, self.refrescar, operacion
        )

    def _corregir_posicion(self, posicion) -> None:
        self.pagina.pop_dialog()
        dialogo_posicion.abrir_posicion(
            self.pagina, self.paleta, self.refrescar, posicion
        )

    # ----------------------------------------------------------------------

    def _traer_precios(self, posiciones: list) -> tuple[int, list[str]]:
        """Trae el precio de esas posiciones. Devuelve (cuántas, qué falló).

        Una posición que falla NO impide traer las demás: quedarse sin actualizar
        la cartera entera porque un símbolo está mal escrito sería un castigo
        desproporcionado.
        """
        traidos, fallos = 0, []
        with conectado() as conexion:
            for posicion in posiciones:
                try:
                    precio = mercado.precio_en_euros(posicion.ticker)
                except mercado.MercadoNoDisponible as fallo:
                    fallos.append(f"{posicion.ticker}: {fallo}")
                    continue
                repo.guardar_precio_de_mercado(
                    conexion,
                    posicion.id,
                    euros=precio.euros,
                    original=precio.original,
                    moneda=precio.moneda_original,
                    cambio=precio.cambio,
                    momento=precio.momento,
                )
                traidos += 1
        self._aviso = " · ".join(fallos) if fallos else ""
        return traidos, fallos

    def _actualizar_todos(self) -> None:
        traidos, fallos = self._traer_precios(self.posiciones)
        self._error = ""
        if not traidos and not fallos:
            self._aviso = "No hay ninguna posición que actualizar."
        self.refrescar()


def _con_signo(cantidad: int) -> str:
    """"+340,00 €" o "-120,00 €". El signo delante siempre, también en positivo.

    Sin el "+", una ganancia y una pérdida se distinguen solo por el color, y con
    el tema claro a media tarde eso no basta.
    """
    texto = formatear(abs(cantidad), EUR)
    return f"+{texto}" if cantidad > 0 else (f"-{texto}" if cantidad < 0 else texto)


def _hace_cuanto(momento: datetime | None) -> str:
    """"hace 2 minutos", "hace 3 días". Nunca una hora suelta sin contexto."""
    if momento is None:
        return "sin fecha"
    segundos = (datetime.now() - momento).total_seconds()
    if segundos < 90:
        return "ahora mismo"
    minutos = int(segundos // 60)
    if minutos < 60:
        return f"hace {minutos} minutos"
    horas = minutos // 60
    if horas < 24:
        return f"hace {horas} horas" if horas > 1 else "hace 1 hora"
    dias = horas // 24
    return f"hace {dias} días" if dias > 1 else "ayer"
