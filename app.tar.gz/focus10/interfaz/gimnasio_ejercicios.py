"""La biblioteca de ejercicios: la vista de EJERCICIOS del gimnasio.

BORRAR UN EJERCICIO NO BORRA EL HISTORIAL, y esto se dice en la propia ventana de
confirmar. La sesión guarda el nombre además de la referencia, así que un entreno
de hace dos años se sigue leyendo entero. Perder dos años de registro por ordenar
una lista sería mucho peor que tener un nombre repetido en dos sitios.

EL BUSCADOR NO REPINTA LA PANTALLA ENTERA, y esto costó un fallo bien feo: la
primera versión llamaba a `pantalla.refrescar()` en cada tecla. Eso construye
todos los controles de nuevo, incluido EL PROPIO CAMPO DE BÚSQUEDA, así que el
campo donde estabas escribiendo dejaba de existir y el foco se perdía. Había que
volver a pinchar para escribir cada letra.

La solución es que el campo y la lista de resultados VIVAN entre repintados
—guardados en la pantalla, que sí sobrevive— y que escribir solo cambie la lista.
La pantalla completa se vuelve a montar únicamente cuando cambian los datos: al
crear, corregir o borrar un ejercicio.
"""

from __future__ import annotations

import flet as ft

from ..datos import repositorio_ejercicios, repositorio_gimnasio
from ..datos.bd import conectado
from ..dominio.ejercicio import Ejercicio, Grupo, filtrar, ordenar
from . import componentes, dialogo_ejercicio, estilo

CUANTOS_DE_GOLPE = 40
"""Cuántas fichas se pintan como mucho.

CON 255 EJERCICIOS ESTO NO ES UN CAPRICHO: pintar las 255 en cada tecla se nota
como un tirón al escribir. Y además nadie recorre 255 nombres con la vista; para
eso está el buscador. Cuando hay más de los que caben se dice cuántos faltan, que
es distinto de esconderlos sin avisar.
"""


def vista(pantalla) -> list[ft.Control]:
    """Las piezas de la vista. `pantalla` es la PantallaGimnasio."""
    _asegurar_controles(pantalla)
    _llenar(pantalla)

    return [
        ft.Row(
            [
                pantalla.buscador_ejercicios,
                ft.Container(expand=True),
                componentes.boton(
                    pantalla.paleta,
                    "Nuevo ejercicio",
                    icono=ft.Icons.ADD,
                    principal=True,
                    al_pulsar=lambda _: dialogo_ejercicio.abrir(
                        pantalla.pagina, pantalla.paleta, pantalla.refrescar
                    ),
                ),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        componentes.segmentado(
            pantalla.paleta,
            [("", "Todos")] + [(uno.value, uno.value.capitalize()) for uno in Grupo],
            pantalla.grupo_ejercicios.value if pantalla.grupo_ejercicios else "",
            lambda clave: _filtrar(pantalla, clave),
        ),
        componentes.tarjeta(pantalla.paleta, pantalla.resultados_ejercicios),
        pantalla.cuenta_ejercicios,
    ]


def _asegurar_controles(pantalla) -> None:
    """Crea el campo y la lista UNA vez, y los guarda en la pantalla.

    Se guardan ahí y no en este módulo porque la pantalla es lo que dura: al
    cambiar de tema o de sección se construye una nueva y estos controles se
    crean con ella, con la paleta nueva.
    """
    if hasattr(pantalla, "buscador_ejercicios"):
        return

    pantalla.busqueda_ejercicios = ""
    pantalla.grupo_ejercicios = None

    campo = componentes.campo_texto(
        pantalla.paleta, "Buscar ejercicio", ancho=300
    )
    campo.on_change = lambda e: _buscar(pantalla, e.control.value or "")
    pantalla.buscador_ejercicios = campo

    pantalla.resultados_ejercicios = ft.Column(spacing=0)
    pantalla.cuenta_ejercicios = ft.Text(
        "", size=estilo.TEXTO_APOYO, color=pantalla.paleta.muted
    )


def _buscar(pantalla, texto: str) -> None:
    """Solo cambia la lista. NO toca el campo, que es donde está el foco."""
    pantalla.busqueda_ejercicios = texto
    _llenar(pantalla)
    _repintar(pantalla)


def _filtrar(pantalla, clave: str) -> None:
    """El grupo sí repinta la pantalla entera: hay que redibujar las pestañas
    para que se vea cuál está elegida, y como se cambia con un clic y no
    escribiendo, aquí no hay foco que perder."""
    pantalla.grupo_ejercicios = Grupo(clave) if clave else None
    pantalla.refrescar()


def _llenar(pantalla) -> None:
    encontrados = ordenar(
        filtrar(
            pantalla.ejercicios,
            texto=pantalla.busqueda_ejercicios,
            grupo=pantalla.grupo_ejercicios,
        )
    )
    ensenados = encontrados[:CUANTOS_DE_GOLPE]

    pantalla.resultados_ejercicios.controls = [
        componentes.tabla(
            pantalla.paleta,
            [
                ("EJERCICIO", None),
                ("GRUPO", 120),
                ("MATERIAL", 130),
                ("DESCANSO", 110),
                ("", 96),
            ],
            [_fila(pantalla, uno) for uno in ensenados],
            vacia="Ningún ejercicio con esa búsqueda.",
        )
    ]

    faltan = len(encontrados) - len(ensenados)
    if faltan:
        # SE DICE CUÁNTOS FALTAN. Cortar la lista sin avisar haría creer que la
        # biblioteca tiene 40 ejercicios y que el resto se ha perdido.
        pantalla.cuenta_ejercicios.value = (
            f"Enseñando {len(ensenados)} de {len(encontrados)}. "
            f"Escribe en el buscador para llegar a los otros {faltan}."
        )
    else:
        pantalla.cuenta_ejercicios.value = (
            f"{len(encontrados)} de {len(pantalla.ejercicios)} ejercicios"
        )


def _repintar(pantalla) -> None:
    try:
        pantalla.resultados_ejercicios.update()
        pantalla.cuenta_ejercicios.update()
    except Exception:  # noqa: BLE001
        # Todavía no están en la página: pasa en el primer montaje, antes de que
        # la ventana los coloque. No es un fallo.
        pass


def _fila(pantalla, ejercicio: Ejercicio) -> list[ft.Control]:
    paleta = pantalla.paleta
    nombre: list[ft.Control] = [
        ft.Text(ejercicio.nombre, size=estilo.TEXTO, color=paleta.ink)
    ]
    if ejercicio.notas:
        nombre.append(
            ft.Text(
                ejercicio.notas,
                size=estilo.TEXTO_APOYO,
                color=paleta.muted,
                max_lines=1,
                overflow=ft.TextOverflow.ELLIPSIS,
            )
        )

    return [
        ft.Column(nombre, spacing=0, tight=True),
        ft.Text(
            ejercicio.grupo.value.capitalize(), size=estilo.TEXTO, color=paleta.ink_soft
        ),
        ft.Text(
            ejercicio.material.value.capitalize(),
            size=estilo.TEXTO,
            color=paleta.ink_soft,
        ),
        ft.Text(ejercicio.texto_descanso(), size=estilo.TEXTO, color=paleta.ink_soft),
        ft.Row(
            [
                componentes.boton_icono(
                    paleta,
                    ft.Icons.EDIT_OUTLINED,
                    ayuda="Corregir",
                    al_pulsar=lambda _, e=ejercicio: dialogo_ejercicio.abrir(
                        pantalla.pagina, paleta, pantalla.refrescar, e
                    ),
                ),
                componentes.boton_icono(
                    paleta,
                    ft.Icons.DELETE_OUTLINE,
                    ayuda="Borrar de la biblioteca",
                    al_pulsar=lambda _, e=ejercicio: _borrar(pantalla, e),
                ),
            ],
            spacing=0,
            tight=True,
        ),
    ]


def _borrar(pantalla, ejercicio: Ejercicio) -> None:
    componentes.confirmar(
        pantalla.paleta,
        pantalla.pagina,
        titulo=f"Borrar «{ejercicio.nombre}»",
        texto=(
            "Los entrenos donde aparece SE CONSERVAN enteros: guardan el nombre "
            "aparte. Lo que se pierde es la ficha y su sitio en la rutina."
        ),
        al_aceptar=lambda _: _borrar_de_verdad(pantalla, ejercicio),
    )


def _borrar_de_verdad(pantalla, ejercicio: Ejercicio) -> None:
    with conectado() as conexion:
        # PRIMERO se sueltan las referencias y DESPUÉS se borra la ficha. Al
        # revés, la base se quejaría de que hay filas apuntando a algo que ya no
        # existe, y el borrado fallaría a medias.
        repositorio_gimnasio.olvidar_ejercicio(conexion, ejercicio.id)
        repositorio_ejercicios.borrar(conexion, ejercicio.id)
    pantalla.pagina.pop_dialog()
    pantalla.refrescar()
