"""Cerrar el día: valoración del 1 al 10 y una reflexión.

LO PIDIÓ EL USUARIO ASÍ: al pulsar "Finalizar día" no se pasa de día
directamente; primero se abre esto, y solo al confirmar se cierra el día y
empieza el siguiente.

LAS DOS COSAS SON OBLIGATORIAS, también decisión suya. Un cierre sin nota es un
botón de "siguiente" con pasos de más; lo que le da sentido es pararse a escribir
qué salió bien y qué no.

NO SE PUEDE DESHACER Y SE AVISA ANTES. Cerrar un día abre el siguiente y todo lo
que apuntes a partir de ahí cae en el nuevo: si alguien lo pulsa sin querer a
media tarde, se queda con medio día partido en dos y sin forma de juntarlo.
"""

from __future__ import annotations

from datetime import datetime
from typing import Callable

import flet as ft

from ..datos import repositorio_dias
from ..datos.bd import conectado
from ..dominio.dia import (
    LARGO_MINIMO_REFLEXION,
    VALORACION_MAXIMA,
    VALORACION_MINIMA,
)
from . import componentes, estilo
from .estilo import Paleta


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    al_cerrar: Callable[[], None],
) -> ft.AlertDialog:
    """Pregunta cómo fue el día. Devuelve la ventanita para poder probarla."""
    with conectado() as conexion:
        hoy = repositorio_dias.abierto(conexion)

    elegida: dict[str, int | None] = {"valoracion": None}
    aviso = ft.Text("", size=12, color=paleta.negativo, visible=False)

    reflexion = componentes.campo_texto(
        paleta,
        "¿Qué tal fue?",
        pista="qué hiciste bien, qué no, qué aprendes de hoy",
    )
    reflexion.multiline = True
    reflexion.min_lines = 4

    numeros = ft.Row(spacing=4, wrap=True, run_spacing=4)

    def pintar_numeros() -> None:
        numeros.controls = [
            _numero(paleta, cual, elegida["valoracion"] == cual, elegir)
            for cual in range(VALORACION_MINIMA, VALORACION_MAXIMA + 1)
        ]

    def elegir(cual: int) -> None:
        elegida["valoracion"] = cual
        # SE REPINTA LA FILA, NO LA VENTANITA: rehacer la ventanita entera
        # desconecta los campos de texto y lo escrito deja de llegar a Python.
        # Ya pasó una vez, en la de apuntar comida, y costó encontrarlo.
        pintar_numeros()
        pagina.update()

    pintar_numeros()

    def guardar(_):
        texto = (reflexion.value or "").strip()
        if elegida["valoracion"] is None:
            aviso.value = "Elige del 1 al 10 cómo fue el día."
            aviso.visible = True
            pagina.update()
            return
        if len(texto) < LARGO_MINIMO_REFLEXION:
            aviso.value = (
                f"Escribe al menos {LARGO_MINIMO_REFLEXION} letras: dos palabras "
                "de hoy valen más que un día en blanco."
            )
            aviso.visible = True
            pagina.update()
            return

        with conectado() as conexion:
            repositorio_dias.cerrar(
                conexion,
                valoracion=elegida["valoracion"],
                reflexion=texto,
                ahora=datetime.now(),
            )
        pagina.pop_dialog()
        al_cerrar()

    ventanita = componentes.dialogo(
        paleta,
        f"Finalizar el día {hoy.numero}",
        ft.Column(
            [
                ft.Text(
                    "Al confirmar se cierra este día y empieza el siguiente. "
                    "Lo que apuntes a partir de ahí irá al día nuevo.",
                    size=12,
                    color=paleta.muted,
                ),
                ft.Text(
                    "Del 1 al 10, ¿cómo fue?",
                    size=estilo.TEXTO_APOYO,
                    color=paleta.ink_soft,
                ),
                numeros,
                reflexion,
                aviso,
            ],
            spacing=12,
            tight=True,
            width=360,
        ),
        pagina=pagina,
        texto_aceptar="Finalizar día",
        al_aceptar=guardar,
    )
    pagina.show_dialog(ventanita)
    return ventanita


def _numero(
    paleta: Paleta, cual: int, elegido: bool, al_pulsar: Callable[[int], None]
) -> ft.Control:
    """Uno de los diez botones de la valoración.

    SE MIDE POR EL COLOR DE FONDO cuál está elegido, no por el texto: los diez
    llevan su número puesto, elegidos o no.
    """
    return ft.Container(
        content=ft.Text(
            str(cual),
            size=estilo.TEXTO,
            color=paleta.acento_ink if elegido else paleta.ink,
            text_align=ft.TextAlign.CENTER,
        ),
        width=30,
        height=34,
        alignment=ft.Alignment.CENTER,
        bgcolor=paleta.acento if elegido else paleta.surface,
        border=ft.Border.all(1, paleta.borde),
        border_radius=estilo.RADIO_CAMPO,
        on_click=lambda _, c=cual: al_pulsar(c),
    )
