"""Las piezas con las que se construyen todas las pantallas.

LA REGLA: ninguna pantalla dibuja un recuadro, un botón o un campo por su
cuenta. Todo sale de aquí. Y ninguna pieza escribe un color suelto: los pide a
la paleta (ver estilo.py). Así, cambiar el aspecto de la aplicación entera es
tocar un archivo, y no hay forma de que dos pantallas se parezcan "casi".

Hay un test que lo vigila: tests/test_arquitectura.py comprueba que fuera de
estilo.py no aparece ningún color escrito a mano.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence

import flet as ft

from ..dominio import dinero
from ..dominio.moneda import CATALOGO, Moneda, por_codigo
from . import estilo
from .estilo import (
    ALTO_BOTON,
    BLANCO,
    CIFRA,
    RADIO_BOTON,
    RADIO_CAMPO,
    RADIO_TARJETA,
    RELLENO_TARJETA,
    ROTULO,
    TEXTO,
    TEXTO_APOYO,
    TEXTO_TARJETA,
    TITULAR_GRANDE,
    Paleta,
    con_opacidad,
    sombra_tarjeta,
)


# --------------------------------------------------------------------------
# Recuadros y cabeceras
# --------------------------------------------------------------------------


class Pantalla:
    """Lo que las diez pantallas de la aplicación tenían escrito igual.

    ERA EL MISMO ESQUELETO COPIADO DIEZ VECES: la página, la paleta, la columna
    con scroll, y la cuenta de si el control ya está puesto en la ventana. Diez
    copias de la misma regla es una regla que algún día se corrige en nueve
    sitios.

    LO DE `_en_pagina` NO ES CAPRICHO: en Flet 0.86, pedirle a un control que se
    repinte antes de estar dentro de la ventana lanza un error. La ventana avisa
    llamando a `montada()`, y hasta entonces `pintar()` solo cambia el contenido.

    QUIEN HEREDE llama a `super().__init__(pagina, paleta)`, pone lo suyo y
    termina con `self.refrescar()`. La base NO refresca: hacerlo aquí pintaría
    la pantalla antes de que la hija tenga sus datos puestos.
    """

    def __init__(self, pagina: ft.Page, paleta: Paleta) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.contenido = ft.Column(spacing=16, scroll=ft.ScrollMode.AUTO, expand=True)
        self._en_pagina = False

    @property
    def control(self) -> ft.Control:
        return self.contenido

    def montada(self) -> None:
        """La llama la ventana justo después de añadir el control a la página."""
        self._en_pagina = True

    def pintar(self, piezas: list[ft.Control]) -> None:
        """Deja la pantalla con esas piezas, y la repinta si ya está puesta."""
        self.contenido.controls = piezas
        if self._en_pagina:
            self.contenido.update()


def tarjeta(
    paleta: Paleta,
    contenido: ft.Control,
    *,
    relleno: int = RELLENO_TARJETA,
    expandir: bool = False,
    al_pulsar=None,
) -> ft.Container:
    """El recuadro donde va todo: fondo propio, esquina redondeada y sombra.

    SOMBRA Y NO BORDE, que es el cambio que más se nota del rediseño. Un borde de
    un píxel alrededor de cada tarjeta llena la pantalla de líneas y se ve
    barato; una sombra muy suave hace el mismo trabajo —decir dónde acaba la
    tarjeta— sin dibujar nada. En el tema oscuro no hay sombra: allí separa el
    escalón de tono entre el lienzo y la superficie. Ver estilo.sombra_tarjeta.
    """
    return ft.Container(
        content=contenido,
        padding=relleno,
        bgcolor=paleta.surface,
        border_radius=RADIO_TARJETA,
        shadow=sombra_tarjeta(paleta),
        expand=expandir,
        # LA ONDA AL PULSAR (ink) ES LO QUE DICE QUE LA TARJETA ES UN BOTÓN.
        # Una tarjeta se parece a un cartel, y sin ninguna respuesta al tocarla
        # el usuario no volvería a intentarlo.
        on_click=al_pulsar,
        ink=al_pulsar is not None,
    )


def cabecera_tarjeta(
    paleta: Paleta,
    titulo: str,
    subtitulo: str | None = None,
    accion: ft.Control | None = None,
) -> ft.Control:
    """El título pequeño de dentro de una tarjeta, con su acción a la derecha."""
    izquierda: list[ft.Control] = [
        ft.Text(
            titulo, size=TEXTO_TARJETA, weight=ft.FontWeight.W_600, color=paleta.ink
        )
    ]
    if subtitulo is not None:
        izquierda.append(ft.Text(subtitulo, size=TEXTO_APOYO, color=paleta.muted))

    piezas: list[ft.Control] = [
        ft.Column(izquierda, spacing=2, tight=True),
        ft.Container(expand=True),
    ]
    if accion is not None:
        piezas.append(accion)
    return ft.Row(piezas, vertical_alignment=ft.CrossAxisAlignment.START)


def titulo_pagina(
    paleta: Paleta,
    titulo: str,
    subtitulo: str | None = None,
    acciones: list[ft.Control] | None = None,
) -> ft.Control:
    """La cabecera de una pantalla: título a la izquierda, botones a la DERECHA.

    EL SUBTÍTULO VA ARRIBA Y EN VERSALITAS, y el título debajo en serif. Es al
    revés de lo habitual a propósito: así el nombre de la pantalla es lo único
    grande, y el dato de apoyo —la fecha, cuántos hay— no le compite. Antes los
    dos eran texto de tamaños parecidos y no había jerarquía ninguna.
    """
    izquierda: list[ft.Control] = []
    if subtitulo is not None:
        izquierda.append(
            ft.Text(
                subtitulo.upper(),
                size=ROTULO,
                weight=ft.FontWeight.W_600,
                color=paleta.muted,
            )
        )
    izquierda.append(
        ft.Text(
            titulo,
            size=TITULAR_GRANDE,
            color=paleta.ink,
            # LA TIPOGRAFIA SALE DE LA PALETA, que es lo que hace que
            # cambiar de estilo cambie tambien la letra. Antes era una
            # constante del modulo y por eso solo habia un aspecto.
            font_family=paleta.titular,
        )
    )

    return ft.Row(
        [
            ft.Column(izquierda, spacing=2, tight=True),
            ft.Container(expand=True),
            ft.Row(acciones or [], spacing=8),
        ],
        vertical_alignment=ft.CrossAxisAlignment.END,
    )


def cifra(
    paleta: Paleta,
    etiqueta: str,
    valor: str,
    *,
    tono: str = "normal",
    ayuda: str | None = None,
    accion: ft.Control | None = None,
) -> ft.Control:
    """Un número grande con su etiqueta pequeña encima."""
    colores = {
        "positivo": paleta.positivo,
        "negativo": paleta.negativo,
        "normal": paleta.ink,
    }
    fila_etiqueta: list[ft.Control] = [
        ft.Text(
            etiqueta.upper(), size=ROTULO, weight=ft.FontWeight.W_600, color=paleta.muted
        )
    ]
    if accion is not None:
        fila_etiqueta.append(accion)

    piezas: list[ft.Control] = [
        ft.Row(
            fila_etiqueta,
            spacing=4,
            tight=True,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        # En serif y más grande: es el número por el que se abre la pantalla.
        ft.Text(
            valor,
            size=CIFRA,
            color=colores.get(tono, paleta.ink),
            font_family=paleta.titular,
        ),
    ]
    if ayuda is not None:
        piezas.append(ft.Text(ayuda, size=ROTULO, color=paleta.muted))
    return ft.Column(piezas, spacing=2, tight=True)


def separador(paleta: Paleta) -> ft.Control:
    return ft.Container(height=1, bgcolor=paleta.borde)


# --------------------------------------------------------------------------
# Botones
# --------------------------------------------------------------------------


def boton(
    paleta: Paleta,
    texto: str,
    *,
    al_pulsar: Callable,
    icono: str | None = None,
    color_icono: str | None = None,
    principal: bool = False,
) -> ft.Control:
    """Un botón con forma de cápsula.

    LA FORMA SEPARA LO QUE SE PULSA DE LO QUE SE LEE. Con esquinas de ocho
    píxeles, un botón y una tarjeta pequeña se parecían demasiado; con la cápsula
    no hay duda ni un segundo.

    Por omisión es "secundario": sin fondo y con un borde fino. El principal va en
    el color de la TINTA y no en el del acento, porque el acento se reserva para
    lo que hay que MIRAR —una cifra, una barra— y no para lo que hay que pulsar.
    Un botón verde grande le roba la atención al número que tiene al lado.
    """
    contenido: list[ft.Control] = []
    if icono is not None:
        contenido.append(
            ft.Icon(
                icono,
                size=16,
                color=color_icono
                or (paleta.canvas if principal else paleta.ink_soft),
            )
        )
    contenido.append(
        ft.Text(
            texto,
            size=13,
            weight=ft.FontWeight.W_500,
            color=paleta.canvas if principal else paleta.ink,
        )
    )

    return ft.Container(
        content=ft.Row(contenido, spacing=7, tight=True),
        height=ALTO_BOTON,
        padding=ft.Padding.symmetric(horizontal=17),
        bgcolor=paleta.ink if principal else None,
        border=None if principal else ft.Border.all(1, paleta.borde_fuerte),
        border_radius=RADIO_BOTON,
        on_click=al_pulsar,
        # ink=True dibuja la ondita al pulsar; sin esto el botón parece muerto.
        ink=True,
    )


def segmentado(
    paleta: Paleta,
    opciones: Sequence[tuple[str, str]],
    elegida: str,
    al_elegir: Callable[[str], None],
) -> ft.Control:
    """Una fila de pestanas para cambiar de vista dentro de un apartado.

    POR QUE ESTA AQUI Y NO DENTRO DE UNA PANTALLA: el gimnasio tiene cinco
    vistas y los habitos tres. Escrito dos veces, en tres meses habria dos
    selectores que se parecen pero no del todo, y esa clase de diferencia es la
    que hace que una aplicacion se sienta hecha a cachos.

    `opciones` son parejas (clave, texto). La clave es lo que se le pasa a
    `al_elegir`, y el texto lo que se lee.
    """
    piezas = [
        ft.Container(
            content=ft.Text(
                texto,
                size=13,
                weight=ft.FontWeight.W_500,
                color=paleta.acento_ink if clave == elegida else paleta.ink_soft,
            ),
            # SIN alignment Y SIN height, y esto costo un rato: un Container de
            # Flet que lleva alignment SE ESTIRA a todo el ancho que le dejen.
            # Dentro de una fila que envuelve, eso significa que cada pestana
            # ocupa una linea entera y las nueve se apilan una debajo de otra.
            # En el dialogo de elegir ejercicio empujaba la lista fuera de la
            # pantalla y no se podia elegir nada. El relleno ya centra el texto.
            padding=ft.Padding.symmetric(horizontal=16, vertical=9),
            bgcolor=paleta.acento if clave == elegida else None,
            border=None if clave == elegida else ft.Border.all(1, paleta.borde),
            border_radius=RADIO_BOTON,
            on_click=lambda _, c=clave: al_elegir(c),
            ink=True,
        )
        for clave, texto in opciones
    ]
    return ft.Row(piezas, spacing=6, wrap=True, run_spacing=6)


def boton_icono(
    paleta: Paleta, icono: str, *, al_pulsar: Callable, ayuda: str | None = None
) -> ft.Control:
    """Un botón cuadrado de solo icono, para acciones secundarias de una fila."""
    return ft.Container(
        content=ft.Icon(icono, size=16, color=paleta.muted),
        width=ALTO_BOTON,
        height=ALTO_BOTON,
        alignment=ft.Alignment.CENTER,
        border_radius=RADIO_BOTON,
        on_click=al_pulsar,
        tooltip=ayuda,
        ink=True,
    )


def campana(
    paleta: Paleta,
    pendientes: int,
    *,
    al_pulsar: Callable | None = None,
) -> ft.Control:
    """La campanita de los recordatorios: blanca si no hay nada, ámbar si sí.

    LO PIDIÓ EL USUARIO ASÍ: "que haya una campanita o algo que sea llamativa
    para recordarle al usuario; si está vacía campana blanca, si hay algo a
    hacer amarilla".

    LLEVA EL NÚMERO Y NO SOLO EL COLOR. Un color a secas dice que hay algo; el
    número dice cuánto, y no cuesta nada. Además, quien no distinga bien el
    ámbar del blanco sigue viendo el 3.

    LA CAMPANA VACÍA NO GRITA: va del color del texto normal y sin número. Si
    también llamara la atención, dejaría de significar nada cuando sí hay algo,
    que es justo lo que se le pide.
    """
    hay = pendientes > 0
    color = paleta.aviso if hay else paleta.ink

    icono = ft.Icon(
        ft.Icons.NOTIFICATIONS_ACTIVE if hay else ft.Icons.NOTIFICATIONS_NONE,
        color=color,
        size=20,
    )

    dentro: list[ft.Control] = [icono]
    if hay:
        dentro.append(
            ft.Container(
                content=ft.Text(
                    str(pendientes),
                    size=11,
                    weight=ft.FontWeight.W_600,
                    color=paleta.acento_ink,
                ),
                bgcolor=paleta.aviso,
                border_radius=999,
                padding=ft.Padding.symmetric(horizontal=6, vertical=1),
            )
        )

    return ft.Container(
        content=ft.Row(dentro, spacing=5, tight=True),
        padding=ft.Padding.symmetric(horizontal=8, vertical=6),
        border_radius=999,
        tooltip=(
            f"{pendientes} cosa(s) por hacer" if hay else "Nada pendiente"
        ),
        on_click=al_pulsar,
    )


def boton_lapiz(
    paleta: Paleta, *, al_pulsar: Callable, ayuda: str | None = None
) -> ft.Control:
    """Un lápiz diminuto para editar lo que tiene al lado.

    Más pequeño que boton_icono porque va pegado a una etiqueta de 11 píxeles;
    con el tamaño normal parecería que manda él.
    """
    return ft.Container(
        content=ft.Icon(ft.Icons.EDIT_OUTLINED, size=13, color=paleta.muted),
        width=22,
        height=22,
        alignment=ft.Alignment.CENTER,
        border_radius=6,
        on_click=al_pulsar,
        tooltip=ayuda,
        ink=True,
    )


# --------------------------------------------------------------------------
# Campos
# --------------------------------------------------------------------------


def campo_texto(
    paleta: Paleta,
    etiqueta: str,
    *,
    valor: str = "",
    pista: str | None = None,
    ancho: int | None = None,
    largo_maximo: int | None = None,
    lineas: int | None = None,
    secreto: bool = False,
    al_enviar: Callable | None = None,
) -> ft.TextField:
    """Un campo de escribir. Se devuelve el propio control para poder leerlo.

    `lineas` lo convierte en un campo de varios renglones. Hace falta para
    escribir un comentario: en una sola línea, un texto de tres frases se lee
    por una rendija y no se puede releer antes de mandarlo.

    `secreto` tapa lo escrito con puntos Y DEJA UN OJO PARA DESTAPARLO. Lo
    segundo importa tanto como lo primero: una contraseña escrita a ciegas en
    el teclado de un móvil se falla la mitad de las veces, y quien la falla no
    sabe si se equivocó al escribirla o si no es la suya.
    """
    return ft.TextField(
        label=etiqueta,
        value=valor,
        hint_text=pista,
        width=ancho,
        max_length=largo_maximo,
        on_submit=al_enviar,
        password=secreto,
        can_reveal_password=secreto,
        multiline=lineas is not None,
        min_lines=lineas,
        max_lines=lineas,
        border_color=paleta.borde,
        focused_border_color=paleta.acento,
        color=paleta.ink,
        label_style=ft.TextStyle(color=paleta.muted),
        text_size=TEXTO,
        border_radius=RADIO_CAMPO,
        content_padding=ft.Padding.symmetric(horizontal=14, vertical=12),
    )


def selector(
    paleta: Paleta,
    etiqueta: str,
    opciones: Sequence[tuple[str, str]],
    *,
    valor: str | None = None,
    ancho: int | None = None,
    al_elegir: Callable | None = None,
) -> ft.Dropdown:
    """Un desplegable. `opciones` son parejas (clave, texto a la vista)."""
    return ft.Dropdown(
        label=etiqueta,
        value=valor,
        width=ancho,
        options=[ft.DropdownOption(key=clave, text=texto) for clave, texto in opciones],
        # on_select y no on_change: en Flet 0.86 el desplegable avisa así.
        on_select=al_elegir,
        border_color=paleta.borde,
        color=paleta.ink,
        label_style=ft.TextStyle(color=paleta.muted),
        text_size=13,
    )


def interruptor(
    paleta: Paleta, etiqueta: str, *, valor: bool, al_cambiar: Callable
) -> ft.Control:
    """Un sí/no con su texto al lado."""
    return ft.Row(
        [
            ft.Switch(value=valor, on_change=al_cambiar, active_color=paleta.acento),
            ft.Text(etiqueta, size=13, color=paleta.ink),
        ],
        spacing=8,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )


class CampoDinero:
    """Un importe con su moneda al lado, y la lectura de lo escrito.

    Existe como pieza propia porque el dinero se escribe en tres sitios (gastos,
    ingresos y saldos) y las reglas de lectura son delicadas: "1.234" son mil
    doscientos treinta y cuatro, "8,5" son ocho con cincuenta, y lo que no se
    entiende NO se adivina. Repetir eso a mano en cada pantalla acabaría con tres
    comportamientos distintos.
    """

    def __init__(
        self,
        paleta: Paleta,
        etiqueta: str,
        *,
        moneda: Moneda,
        pista: str = "8,50",
        ancho_importe: int = 190,
        al_enviar: Callable | None = None,
        al_cambiar_moneda: Callable | None = None,
    ) -> None:
        self.paleta = paleta
        self.importe = campo_texto(
            paleta, etiqueta, pista=pista, ancho=ancho_importe, al_enviar=al_enviar
        )
        self.importe.keyboard_type = ft.KeyboardType.NUMBER
        self.importe.autofocus = True
        self.moneda = selector(
            paleta,
            "Moneda",
            [
                (codigo, f"{una.simbolo}  {codigo}")
                for codigo, una in sorted(CATALOGO.items())
            ],
            valor=moneda.codigo,
            ancho=130,
            al_elegir=al_cambiar_moneda,
        )

    @property
    def control(self) -> ft.Control:
        return ft.Row([self.importe, self.moneda], spacing=10)

    def moneda_elegida(self) -> Moneda:
        return por_codigo(self.moneda.value)

    def unidades(self) -> int | None:
        """Lo escrito, en unidades mínimas. None si no se entiende."""
        return dinero.parsear_importe(self.importe.value or "", self.moneda_elegida())

    def marcar_error(self, texto: str) -> None:
        self.importe.error_text = texto

    def limpiar_error(self) -> None:
        self.importe.error_text = None


# --------------------------------------------------------------------------
# El círculo de marcar un hábito
# --------------------------------------------------------------------------

TAMANO_CIRCULO_DIA = 46
"""Grande a propósito: es la acción que se hace veinte veces al día, y un
objetivo pequeño se falla. Cuarenta y seis píxeles superan el mínimo cómodo de
cuarenta y cuatro que recomiendan Apple y Google."""

TAMANO_CIRCULO_SEMANA = 30


def circulo_habito(
    paleta: Paleta,
    *,
    color: str,
    emoji: str,
    cantidad: int,
    objetivo: int,
    programado: bool = True,
    tamano: int = TAMANO_CIRCULO_DIA,
    con_barra: bool = False,
    al_pulsar: Callable | None = None,
    ayuda: str | None = None,
) -> ft.Control:
    """El círculo de marcar.

    EL EMOJI SE VE SIEMPRE, también cuando el hábito está cumplido. Antes el
    emoji se sustituía por un check y desaparecía justo en el momento en que uno
    repasa la lista: con seis hábitos hechos, seis círculos idénticos con un
    check no dicen cuál es cuál. Ahora el círculo se llena de color y el emoji se
    queda encima, con una marca pequeña en la esquina que confirma que está
    hecho.

    - Sin empezar: hueco, borde del color del hábito, emoji dentro.
    - A medias: igual, y la barra de avance marca por dónde vas.
    - Cumplido: relleno del color, emoji encima y una marca en la esquina.

    Con objetivo 1 —el gimnasio, meditar— una sola pulsación lo llena entero.

    EL COLOR ES EL DEL HÁBITO, no un azul único: con ocho hábitos en pantalla es
    el color lo que te deja encontrar el tuyo sin leer.

    AVISO SOBRE LOS DÍAS NO PROGRAMADOS: se pidió borde punteado, y Flet no sabe
    dibujar bordes discontinuos. Se distinguen con un borde fino y gris en vez
    del color del hábito, y el conjunto algo apagado. Se pueden marcar igual;
    simplemente no cuentan para la racha.
    """
    tono = paleta.color_de(color)
    cumplido = cantidad >= objetivo
    fraccion = min(1.0, cantidad / objetivo) if objetivo else 0.0

    circulo = ft.Container(
        content=ft.Text(emoji, size=int(tamano * 0.46)),
        width=tamano,
        height=tamano,
        # Cumplido: relleno del color del hábito, pero suave, para que el emoji
        # siga leyéndose encima.
        bgcolor=con_opacidad(tono, 0.85) if cumplido else None,
        border=None
        if cumplido
        else ft.Border.all(
            2 if programado else 1, tono if programado else paleta.borde_fuerte
        ),
        border_radius=tamano,
        alignment=ft.Alignment.CENTER,
        on_click=al_pulsar,
        tooltip=ayuda,
        ink=True,
    )

    if cumplido:
        marca = int(tamano * 0.36)
        circulo = ft.Stack(
            [
                circulo,
                ft.Container(
                    content=ft.Icon(
                        ft.Icons.CHECK_ROUNDED, size=int(marca * 0.72), color=BLANCO
                    ),
                    width=marca,
                    height=marca,
                    bgcolor=tono,
                    border=ft.Border.all(2, paleta.surface),
                    border_radius=marca,
                    alignment=ft.Alignment.CENTER,
                    right=0,
                    bottom=0,
                ),
            ],
            width=tamano,
            height=tamano,
        )

    if not con_barra:
        return ft.Container(content=circulo, opacity=1.0 if programado else 0.55)

    return ft.Column(
        [circulo, barra_de_avance(paleta, color=color, fraccion=fraccion, ancho=tamano)],
        spacing=4,
        tight=True,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        opacity=1.0 if programado else 0.55,
    )


def barra_de_avance(
    paleta: Paleta,
    *,
    color: str,
    fraccion: float,
    ancho: int | None = None,
    alto: int = 4,
) -> ft.Control:
    """La barrita que enseña por dónde vas.

    Sin `ancho` se estira a lo que le den: así puede ocupar el ancho entero de la
    fila de un hábito, que es donde mejor se ve el avance. Con `ancho` se queda
    del tamaño pedido, que es lo que hace falta debajo de cada círculo de la
    vista de semana.

    Vacía no desaparece: se queda como una raya apagada, para que se vea que ahí
    va algo y cuánto falta.
    """
    tono = paleta.color_de(color)
    relleno = ft.Container(height=alto, bgcolor=tono, border_radius=alto)

    if ancho is None:
        # Sin ancho fijo, el reparto se hace con pesos: la parte hecha y la que
        # falta se reparten la fila.
        hecho = max(1, round(fraccion * 1000))
        falta = max(0, 1000 - hecho)
        dentro: ft.Control = ft.Row(
            [
                ft.Container(content=relleno, expand=hecho),
                ft.Container(expand=falta) if falta else ft.Container(width=0),
            ],
            spacing=0,
        )
        if fraccion <= 0:
            dentro = ft.Container()
    else:
        relleno.width = max(0.0, ancho * fraccion)
        dentro = relleno

    return ft.Container(
        content=dentro,
        width=ancho,
        height=alto,
        bgcolor=paleta.surface_3,
        border_radius=alto,
        alignment=ft.Alignment.CENTER_LEFT,
    )


# --------------------------------------------------------------------------
# Avisos
# --------------------------------------------------------------------------


def aviso(paleta: Paleta, textos: list[str]) -> ft.Control:
    """El recuadro de "ojo con esto", en tono ámbar."""
    return _caja_de_aviso(paleta, textos, ft.Icons.WARNING_AMBER_ROUNDED, paleta.aviso)


def aviso_error(paleta: Paleta, textos: list[str]) -> ft.Control:
    """Lo mismo, pero en rojo: algo ha fallado de verdad."""
    return _caja_de_aviso(paleta, textos, ft.Icons.ERROR_OUTLINE, paleta.negativo)


def aviso_vacio(
    paleta: Paleta, texto: str, *, icono: str | None = None, alto: int = 90
) -> ft.Control:
    """Lo que se enseña cuando todavía no hay nada.

    Nunca se deja un hueco en blanco: un hueco parece que la aplicación se ha
    roto, y una frase explica que simplemente aún no has apuntado nada.
    """
    dentro: list[ft.Control] = []
    if icono is not None:
        dentro.append(ft.Icon(icono, size=22, color=paleta.muted))
    dentro.append(ft.Text(texto, size=13, color=paleta.muted))

    return ft.Container(
        content=ft.Column(
            dentro,
            spacing=8,
            tight=True,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
        ),
        height=alto,
        alignment=ft.Alignment.CENTER,
    )


def _caja_de_aviso(
    paleta: Paleta, textos: list[str], icono: str, color: str
) -> ft.Control:
    return ft.Container(
        content=ft.Column(
            [
                ft.Row(
                    [
                        ft.Icon(icono, size=16, color=color),
                        ft.Text(texto, size=12, color=paleta.ink_soft, expand=True),
                    ],
                    spacing=8,
                )
                for texto in textos
            ],
            spacing=6,
            tight=True,
        ),
        padding=14,
        bgcolor=paleta.surface_2,
        border=ft.Border.all(1, paleta.borde),
        border_radius=RADIO_TARJETA,
    )


# --------------------------------------------------------------------------
# Tabla
# --------------------------------------------------------------------------


def tabla(
    paleta: Paleta,
    columnas: Sequence[tuple[str, int | None]],
    filas: Sequence[Sequence[ft.Control]],
    *,
    vacia: str = "No hay nada que enseñar.",
) -> ft.Control:
    """Una tabla sencilla: cabecera y filas separadas por una línea.

    POR QUÉ NO SE USA DataTable: aquí cada celda es un control cualquiera (un
    importe de color, un botón de borrar), y con anchos fijos por columna se
    controla mejor que todas las filas queden alineadas. DataTable reparte el
    ancho por su cuenta y pelea con los botones.

    `columnas` son parejas (título, ancho). Un ancho None hace que esa columna
    se coma el espacio que sobre.
    """
    if not filas:
        return aviso_vacio(paleta, vacia)

    # EN UN MÓVIL NO SE DIBUJA UNA TABLA, se apilan fichas. Una tabla con
    # columnas de ancho fijo pide 862 puntos en Inversiones, y un móvil tiene
    # 375: o se sale de la pantalla o hay que arrastrarla a lo ancho, que para
    # leer una lista es horrible.
    #
    # NO SE PIERDE NADA: son los mismos datos con sus mismos títulos, uno debajo
    # de otro en vez de uno al lado de otro.
    if estilo.pantalla_estrecha():
        return _tabla_apilada(paleta, columnas, filas)

    cabecera = ft.Container(
        content=ft.Row(
            [_celda(ft.Text(titulo, size=11, color=paleta.muted), ancho)
             for titulo, ancho in columnas],
            spacing=10,
        ),
        padding=ft.Padding.only(bottom=6),
        border=ft.Border.only(bottom=ft.BorderSide(1, paleta.borde)),
    )

    cuerpo = [
        ft.Container(
            content=ft.Row(
                [_celda(celda, ancho)
                 for celda, (_, ancho) in zip(fila, columnas, strict=True)],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(vertical=6),
            border=ft.Border.only(bottom=ft.BorderSide(1, paleta.borde)),
        )
        for fila in filas
    ]

    return ft.Column([cabecera, *cuerpo], spacing=0)


def _tabla_apilada(
    paleta: Paleta,
    columnas: Sequence[tuple[str, int | None]],
    filas: Sequence[Sequence[ft.Control]],
) -> ft.Control:
    """La misma tabla, pero cada fila como una ficha con sus etiquetas.

    LAS ETIQUETAS SE REPITEN EN CADA FICHA a propósito. En una tabla la cabecera
    está arriba y vale para todas las filas; apilando, la de arriba quedaría a
    diez fichas de distancia y no diría nada. Repetirlas ocupa más, pero es la
    diferencia entre entender un número y verlo suelto.

    UNA COLUMNA SIN TÍTULO no lleva etiqueta: suelen ser los botones de borrar o
    editar, y ponerles un rótulo vacío dejaría un hueco raro.
    """
    fichas = []
    for fila in filas:
        lineas = []
        for celda, (titulo, _) in zip(fila, columnas, strict=True):
            if titulo:
                lineas.append(
                    ft.Row(
                        [
                            ft.Container(
                                content=ft.Text(titulo, size=11, color=paleta.muted),
                                width=96,
                            ),
                            ft.Container(content=celda, expand=True),
                        ],
                        spacing=8,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    )
                )
            else:
                lineas.append(
                    ft.Row([celda], alignment=ft.MainAxisAlignment.END)
                )
        fichas.append(
            ft.Container(
                content=ft.Column(lineas, spacing=4, tight=True),
                padding=ft.Padding.symmetric(vertical=10),
                border=ft.Border.only(bottom=ft.BorderSide(1, paleta.borde)),
            )
        )
    return ft.Column(fichas, spacing=0)


def _celda(contenido: ft.Control, ancho: int | None) -> ft.Control:
    if ancho is None:
        return ft.Container(content=contenido, expand=True)
    return ft.Container(content=contenido, width=ancho)


# --------------------------------------------------------------------------
# Diálogos
# --------------------------------------------------------------------------


def dialogo(
    paleta: Paleta,
    titulo: str,
    contenido: ft.Control,
    *,
    pagina: ft.Page,
    texto_aceptar: str = "Guardar",
    al_aceptar: Callable,
    peligroso: bool = False,
) -> ft.AlertDialog:
    """Una ventanita con sus dos botones de siempre: cancelar y aceptar."""
    return ft.AlertDialog(
        modal=True,
        title=ft.Text(titulo, size=15, weight=ft.FontWeight.W_600, color=paleta.ink),
        content=contenido,
        bgcolor=paleta.surface,
        actions=[
            ft.TextButton("Cancelar", on_click=lambda _: pagina.pop_dialog()),
            ft.FilledButton(
                texto_aceptar,
                on_click=al_aceptar,
                bgcolor=paleta.negativo if peligroso else paleta.acento,
                color=BLANCO if peligroso else paleta.acento_ink,
            ),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )


def confirmar(
    paleta: Paleta,
    pagina: ft.Page,
    *,
    titulo: str,
    texto: str,
    texto_aceptar: str = "Borrar",
    al_aceptar: Callable,
) -> None:
    """Pregunta antes de algo que no tiene vuelta atrás, y lo enseña."""
    pagina.show_dialog(
        dialogo(
            paleta,
            titulo,
            ft.Text(texto, size=13, color=paleta.ink_soft),
            pagina=pagina,
            texto_aceptar=texto_aceptar,
            al_aceptar=al_aceptar,
            peligroso=True,
        )
    )


def avisar(pagina: ft.Page, texto: str) -> None:
    """El mensajito de abajo que confirma que algo se ha hecho."""
    pagina.show_dialog(ft.SnackBar(content=ft.Text(texto)))
