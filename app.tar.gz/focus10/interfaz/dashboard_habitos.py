"""La tarjeta de los hábitos de hoy en el Dashboard: marcarlos y cuánto llevás.

ESTABA DENTRO DE dashboard.py, que pasaba de las mil trescientas líneas. Se
separó en la auditoría del 13 nov 2026. Es parte de PantallaDashboard (que
hereda esta clase): usa lo que ella lee en refrescar (self.habitos, self.hoy)
y vuelve a llamar a refrescar después de marcar.
"""

from __future__ import annotations

from datetime import date

import flet as ft

from ..datos import repositorio_habitos
from ..datos.bd import conectado
from ..dominio.habito import Franja, Habito
from . import componentes, dialogo_habito, estilo


ALTO_DE_LA_LISTA = 430
"""A cuanto alto tiene que llegar la lista de habitos, en pixeles.

DE DONDE SALE ESTE NUMERO: es lo que miden las tres tarjetas cortas de la
columna de al lado —gastos, gimnasio y educación— apiladas con sus huecos.
Haciendo que los habitos lleguen ahi, las dos columnas acaban a la misma altura
y no queda el rectangulo negro que hay que mirar todos los dias.

SE REPARTE ENTRE LOS HABITOS QUE HAYA, que es justo lo que pidio el usuario: con
uno, ese habito se ve grande; con dos, cada uno se queda con la mitad; con siete,
son mas bajitos pero llenan igual. Lo que NO se hace es pedirle a Flet que los
estire: esto cuelga de una columna con scroll y ahi no hay alto que repartir.
El calculo se hace aqui, en Python, con un numero concreto.

SI ALGUN DIA CAMBIAN LAS TARJETAS DE LA DERECHA, este numero se queda corto o
largo. Es el precio de repartir a mano; la alternativa —medir de verdad— Flet no
la ofrece desde Python."""

ALTO_MINIMO_HABITO = 54
"""Por debajo de esto la fila deja de leerse: no caben el nombre, la hora y la
barra. Con muchos habitos la tarjeta crece hacia abajo antes que apretarlos."""

ALTO_MAXIMO_HABITO = 108
"""Y por encima, una sola fila con doscientos pixeles de aire dentro parece un
fallo, no un diseno. Con uno o dos habitos sobrara algo de sitio; es preferible
a una fila gigante y hueca."""


class TarjetaHabitos:
    """Los hábitos de hoy, con su círculo para marcar y su barra de avance."""

    def _tarjeta_habitos(self) -> ft.Control:
        if not self.habitos:
            return componentes.tarjeta(
                self.paleta,
                ft.Column(
                    [
                        self._cabecera_habitos(0, 0),
                        componentes.aviso_vacio(
                            self.paleta,
                            "Todavía no tienes ningún hábito. Créalo con el botón "
                            "de arriba.",
                            icono=ft.Icons.CHECK_CIRCLE_OUTLINE,
                            alto=120,
                        ),
                    ],
                    spacing=14,
                ),
            )

        de_hoy = [uno for uno in self.habitos if uno.toca_en(self.hoy)]
        visibles = [
            uno
            for uno in de_hoy
            if self.franja is None or uno.esta_en_franja(self.franja)
        ]

        with conectado() as conexion:
            cantidades = {
                uno.id: repositorio_habitos.cantidad(conexion, uno.id, self.hoy)
                for uno in de_hoy
            }

        cumplidos = sum(
            1 for uno in de_hoy if uno.cumplido_con(cantidades.get(uno.id, 0))
        )

        if visibles:
            alto = _alto_de_cada_habito(len(visibles))
            cuerpo: ft.Control = ft.Column(
                [
                    self._fila_habito(uno, cantidades.get(uno.id, 0), alto)
                    for uno in visibles
                ],
                spacing=0,
            )
        elif de_hoy:
            cuerpo = componentes.aviso_vacio(
                self.paleta, "Ninguno de hoy cae en esta franja."
            )
        else:
            cuerpo = componentes.aviso_vacio(
                self.paleta, "Hoy no toca ninguno de tus hábitos."
            )

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    self._cabecera_habitos(cumplidos, len(de_hoy)),
                    self._pestanas_de_franja(),
                    cuerpo,
                ],
                spacing=14,
            ),
        )

    def _cabecera_habitos(self, cumplidos: int, cuantos: int) -> ft.Control:
        return ft.Row(
            [
                ft.Container(
                    content=componentes.cabecera_tarjeta(
                        self.paleta,
                        "Hábitos",
                        f"{cumplidos} de {cuantos} cumplidos"
                        if cuantos
                        else "no toca ninguno",
                    ),
                    expand=True,
                ),
                componentes.boton(
                    self.paleta,
                    "Nuevo",
                    icono=ft.Icons.ADD,
                    al_pulsar=lambda _: dialogo_habito.abrir(
                        self.pagina, self.paleta, self.refrescar
                    ),
                ),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _pestanas_de_franja(self) -> ft.Control:
        opciones: list[tuple[str, Franja | None]] = [("Todos", None)]
        opciones += [(franja.value.capitalize(), franja) for franja in Franja]

        return ft.Row(
            [
                ft.Container(
                    content=ft.Text(
                        texto,
                        size=12,
                        color=self.paleta.acento
                        if franja is self.franja
                        else self.paleta.muted,
                        weight=ft.FontWeight.W_600
                        if franja is self.franja
                        else ft.FontWeight.NORMAL,
                    ),
                    padding=ft.Padding.symmetric(horizontal=12, vertical=6),
                    bgcolor=self.paleta.acento_suave if franja is self.franja else None,
                    border_radius=estilo.RADIO_BOTON,
                    on_click=lambda _, f=franja: self._cambiar_franja(f),
                    ink=True,
                )
                for texto, franja in opciones
            ],
            spacing=4,
        )

    def _cambiar_franja(self, franja: Franja | None) -> None:
        self.franja = franja
        self.refrescar()

    def _fila_habito(
        self, habito: Habito, cantidad: int, alto: int | None = None
    ) -> ft.Control:
        cumplido = habito.cumplido_con(cantidad)
        fraccion = min(1.0, cantidad / habito.objetivo) if habito.objetivo else 0.0

        contador, sobrante = habito.texto_avance(cantidad)
        derecha: list[ft.Control] = [
            ft.Text(
                contador,
                size=13,
                weight=ft.FontWeight.W_600,
                color=self.paleta.positivo if cumplido else self.paleta.ink_soft,
            )
        ]
        # Lo que te pasaste del objetivo, en pequeño y apagado: es un dato de más,
        # no la cuenta principal.
        if sobrante:
            derecha.append(
                ft.Text(
                    sobrante,
                    size=11,
                    weight=ft.FontWeight.W_500,
                    color=self.paleta.muted,
                )
            )
        # El botón de quitar solo tiene sentido cuando se cuenta: en un hábito de
        # "1 vez" se apaga volviendo a pulsar el círculo.
        if cantidad > 0 and habito.objetivo > 1:
            derecha.append(
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.REMOVE,
                    ayuda="Quitar uno",
                    al_pulsar=lambda _, h=habito: self._sumar(h, -1),
                )
            )

        hora = habito.hora.strftime("%H:%M") if habito.hora else "—"
        fila = ft.Row(
            [
                componentes.circulo_habito(
                    self.paleta,
                    color=habito.color,
                    icono=habito.icono,
                    cantidad=cantidad,
                    objetivo=habito.objetivo,
                    ayuda=self._ayuda_del_circulo(habito, cantidad),
                    al_pulsar=lambda _, h=habito: self._pulsar(h, cantidad),
                ),
                ft.Column(
                    [
                        ft.Text(
                            habito.nombre,
                            size=14,
                            weight=ft.FontWeight.W_500,
                            color=self.paleta.ink,
                        ),
                        ft.Text(
                            f"{hora} · {habito.texto_objetivo()}",
                            size=11,
                            color=self.paleta.muted,
                        ),
                    ],
                    spacing=1,
                    tight=True,
                    expand=True,
                ),
                ft.Row(derecha, spacing=4, tight=True),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.MORE_HORIZ,
                    ayuda="Corregir o archivar",
                    al_pulsar=lambda _, h=habito: dialogo_habito.abrir(
                        self.pagina, self.paleta, self.refrescar, h
                    ),
                ),
            ],
            spacing=12,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

        return ft.Container(
            content=ft.Column(
                [
                    fila,
                    # La barra ocupa el ancho entero de la fila: así el avance se
                    # ve de un vistazo desde el otro lado de la mesa, en vez de
                    # tener que fijarse en una rayita de cuarenta píxeles.
                    componentes.barra_de_avance(
                        self.paleta, color=habito.color, fraccion=fraccion
                    ),
                ],
                spacing=8,
                # El contenido centrado dentro del alto que le toque: con pocos
                # hábitos la fila es alta y el nombre tiene que quedar en medio,
                # no pegado arriba con un agujero debajo.
                alignment=ft.MainAxisAlignment.CENTER,
            ),
            height=alto,
            padding=ft.Padding.symmetric(vertical=9),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
        )

    def _ayuda_del_circulo(self, habito: Habito, cantidad: int) -> str:
        if habito.objetivo == 1:
            return (
                f"Deshacer {habito.nombre}"
                if habito.cumplido_con(cantidad)
                else f"Marcar {habito.nombre}"
            )
        return f"Sumar uno a {habito.nombre}"

    def _pulsar(self, habito: Habito, cantidad: int) -> None:
        """Qué hace pulsar el círculo.

        En un hábito de "1 vez" es un interruptor: pulsar otra vez lo apaga. Sin
        esto, el gimnasio acababa en "3/1", que no significa nada.

        En uno que se cuenta, cada pulsación suma uno, y pasarse del objetivo es
        legítimo: si te bebes nueve vasos, fueron nueve.
        """
        if habito.se_apaga_al_pulsar(cantidad):
            self._marcar(habito, self.hoy, 0)
        else:
            self._sumar(habito, 1)

    def _sumar(self, habito: Habito, cuanto: int) -> None:
        with conectado() as conexion:
            repositorio_habitos.sumar(conexion, habito.id, self.hoy, cuanto)
        self.refrescar()

    def _marcar(self, habito: Habito, dia: date, cantidad: int) -> None:
        with conectado() as conexion:
            repositorio_habitos.marcar(conexion, habito.id, dia, cantidad)
        self.refrescar()


def _alto_de_cada_habito(cuantos: int) -> int:
    """Cuánto mide cada fila para que entre todas llenen la columna.

    ES UNA DIVISIÓN, no una regla de diseño: el alto que hay que llenar partido
    por los hábitos que se ven. Con uno se lleva todo, con dos la mitad cada uno,
    con siete un séptimo. Es lo que pidió el usuario con estas palabras: "si
    pongo un hábito, ese hábito se ve grande; si pongo dos, se separa en la
    mitad; si pongo otro, en tres".

    LOS DOS TOPES NO SON CAPRICHO. Por debajo del mínimo la fila deja de leerse
    —no caben el nombre, la hora y la barra—; por encima del máximo, una sola
    fila con un palmo de aire dentro parece un fallo. Fuera de ese rango se
    prefiere que sobre un poco de sitio antes que enseñar algo ilegible o
    ridículo.
    """
    if cuantos <= 0:
        return ALTO_MINIMO_HABITO
    repartido = ALTO_DE_LA_LISTA // cuantos
    return max(ALTO_MINIMO_HABITO, min(ALTO_MAXIMO_HABITO, repartido))
