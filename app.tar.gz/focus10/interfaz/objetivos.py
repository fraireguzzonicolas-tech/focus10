"""La pantalla de Objetivos: a dónde vas, con o sin dinero de por medio.

LOS DOS TIPOS SE VEN DISTINTOS a propósito. Uno de dinero enseña su gráfico de
ahorro, lo que lleva apartado y sus últimas aportaciones. Uno libre enseña dos
botones para mover el avance de diez en diez, y ni una cifra de euros: inventarle
un importe para que las dos tarjetas fueran iguales sería enseñar un número que
no significa nada.

LO CUMPLIDO BAJA PERO NO SE BORRA, como pidió el usuario. Abajo del todo, con su
fecha. Ver lo que ya conseguiste es la mitad de la gracia de tener objetivos.

CUMPLIDO Y VENCIDO NO SE LLAMAN IGUAL. Cumplido es que llegaste; vencido es que
se pasó la fecha sin llegar. Los dos bajan, pero llamar "cumplido" a algo que no
se consiguió sería la clase de mentira que esta aplicación no cuenta en ningún
otro sitio.
"""

from __future__ import annotations

from datetime import date

import flet as ft

from ..datos import repositorio_objetivos as repo
from ..datos import repositorio_dias
from ..datos.bd import conectado
from ..dominio.dinero import formatear
from ..dominio.moneda import EUR
from ..dominio.objetivo import (
    Avance,
    Estado,
    acumulado,
    avance as calcular_avance,
    ordenar,
    siguiente_avance,
)
from . import componentes, dialogo_objetivo, estilo, grafico_ahorro
from .estilo import Paleta

ETIQUETAS = {
    Estado.ABIERTO: "",
    Estado.CUMPLIDO: "cumplido",
    Estado.VENCIDO: "se pasó la fecha",
}


class PantallaObjetivos(componentes.Pantalla):
    def __init__(self, pagina: ft.Page, paleta: Paleta) -> None:
        super().__init__(pagina, paleta)
        self.refrescar()

    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            self.hoy = repositorio_dias.jornada_abierta(conexion)
            objetivos = repo.listar(conexion)
            aportaciones = repo.todas_las_aportaciones(conexion)
            self.ultimas = repo.ultimas_aportaciones(conexion)

        self.avances = ordenar(
            [
                calcular_avance(uno, aportaciones.get(uno.id, []), self.hoy)
                for uno in objetivos
            ]
        )
        self.aportaciones = aportaciones

        abiertos = [uno for uno in self.avances if uno.estado is Estado.ABIERTO]
        cerrados = [uno for uno in self.avances if uno.estado is not Estado.ABIERTO]

        piezas: list[ft.Control] = [self._cabecera(len(abiertos))]
        if not self.avances:
            piezas.append(
                componentes.tarjeta(
                    self.paleta,
                    componentes.aviso_vacio(
                        self.paleta,
                        "Todavía no tienes ningún objetivo. Crea el primero con el "
                        "botón de arriba, y no te dejes el «por qué lo quiero»: es "
                        "lo que vas a leer cada mañana.",
                        icono=ft.Icons.FLAG_OUTLINED,
                        alto=150,
                    ),
                )
            )
        else:
            piezas += [self._tarjeta(uno) for uno in abiertos]
            if self.ultimas:
                piezas.append(self._tarjeta_ultimas())
            if cerrados:
                piezas.append(
                    ft.Text(
                        "Ya cerrados",
                        size=13,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.muted,
                    )
                )
                piezas += [self._tarjeta(uno) for uno in cerrados]

        self.pintar(piezas)

    def _cabecera(self, abiertos: int) -> ft.Control:
        return componentes.titulo_pagina(
            self.paleta,
            "Objetivos",
            f"{abiertos} en marcha" if abiertos else "ninguno en marcha",
            acciones=[
                componentes.boton(
                    self.paleta,
                    "Nuevo objetivo",
                    icono=ft.Icons.ADD,
                    principal=True,
                    al_pulsar=lambda _: dialogo_objetivo.abrir(
                        self.pagina, self.paleta, self.refrescar
                    ),
                )
            ],
        )

    # ----------------------------------------------------------------------

    def _tarjeta(self, como_va: Avance) -> ft.Control:
        objetivo = como_va.objetivo
        piezas: list[ft.Control] = [self._encabezado(como_va)]

        if objetivo.porque:
            piezas.append(
                ft.Container(
                    content=ft.Text(
                        objetivo.porque,
                        size=12,
                        color=self.paleta.ink_soft,
                        italic=True,
                    ),
                    padding=ft.Padding.symmetric(horizontal=12, vertical=10),
                    bgcolor=estilo.con_opacidad(
                        self.paleta.color_de(objetivo.color), 0.10
                    ),
                    border_radius=8,
                )
            )

        piezas.append(self._barra(como_va))

        if objetivo.es_de_dinero:
            piezas += self._piezas_de_dinero(como_va)
        else:
            piezas.append(self._botones_de_avance(como_va))

        return componentes.tarjeta(self.paleta, ft.Column(piezas, spacing=12))

    def _encabezado(self, como_va: Avance) -> ft.Control:
        objetivo = como_va.objetivo
        tono = self.paleta.color_de(objetivo.color)

        derecha: list[ft.Control] = []
        etiqueta = ETIQUETAS[como_va.estado]
        if etiqueta:
            derecha.append(
                ft.Container(
                    content=ft.Text(
                        etiqueta,
                        size=10,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.positivo
                        if como_va.estado is Estado.CUMPLIDO
                        else self.paleta.aviso,
                    ),
                    padding=ft.Padding.symmetric(horizontal=8, vertical=4),
                    bgcolor=self.paleta.surface_2,
                    border_radius=6,
                )
            )
        derecha.append(
            componentes.boton_icono(
                self.paleta,
                ft.Icons.MORE_HORIZ,
                ayuda="Corregir o borrar",
                al_pulsar=lambda _, o=objetivo: dialogo_objetivo.abrir(
                    self.pagina, self.paleta, self.refrescar, o
                ),
            )
        )

        return ft.Row(
            [
                ft.Container(width=6, height=34, bgcolor=tono, border_radius=3),
                ft.Column(
                    [
                        ft.Text(
                            objetivo.nombre,
                            size=15,
                            weight=ft.FontWeight.W_600,
                            color=self.paleta.ink,
                        ),
                        ft.Text(
                            self._pie(como_va), size=11, color=self.paleta.muted
                        ),
                    ],
                    spacing=1,
                    tight=True,
                    expand=True,
                ),
                *derecha,
            ],
            spacing=10,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _pie(self, como_va: Avance) -> str:
        """La línea pequeña: cuánto falta y cuánto tiempo queda."""
        trozos = []
        if como_va.objetivo.es_de_dinero:
            if como_va.falta:
                trozos.append(f"faltan {formatear(como_va.falta, EUR)}")
            else:
                trozos.append("meta alcanzada")
        dias = como_va.dias_hasta(self.hoy)
        if dias is not None:
            if dias > 0:
                trozos.append(f"quedan {dias} días")
            elif dias == 0:
                trozos.append("la fecha es hoy")
            else:
                trozos.append(f"la fecha pasó hace {abs(dias)} días")
        return " · ".join(trozos) if trozos else "sin fecha límite"

    def _barra(self, como_va: Avance) -> ft.Control:
        return ft.Column(
            [
                ft.Row(
                    [
                        ft.Text(
                            f"{como_va.porcentaje} %",
                            size=13,
                            weight=ft.FontWeight.W_700,
                            color=self.paleta.color_de(como_va.objetivo.color),
                            expand=True,
                        ),
                        ft.Text(
                            f"{formatear(como_va.ahorrado, EUR)} de "
                            f"{formatear(como_va.objetivo.importe_objetivo, EUR)}"
                            if como_va.objetivo.es_de_dinero
                            else "",
                            size=12,
                            color=self.paleta.ink_soft,
                        ),
                    ],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                componentes.barra_de_avance(
                    self.paleta,
                    color=como_va.objetivo.color,
                    fraccion=como_va.fraccion,
                    alto=8,
                ),
            ],
            spacing=6,
            tight=True,
        )

    # ----------------------------------------------------------------------

    def _piezas_de_dinero(self, como_va: Avance) -> list[ft.Control]:
        objetivo = como_va.objetivo
        puntos = acumulado(self.aportaciones.get(objetivo.id, []))
        return [
            grafico_ahorro.grafico(
                self.paleta,
                puntos,
                color=objetivo.color,
                meta=objetivo.importe_objetivo or None,
            ),
            ft.Row(
                [
                    componentes.boton(
                        self.paleta,
                        "Apartar dinero",
                        icono=ft.Icons.SAVINGS_OUTLINED,
                        principal=True,
                        al_pulsar=lambda _, o=objetivo: dialogo_objetivo.abrir_aportacion(
                            self.pagina, self.paleta, o, self.refrescar
                        ),
                    )
                ]
            ),
        ]

    def _botones_de_avance(self, como_va: Avance) -> ft.Control:
        """Los dos botones de un objetivo libre, de diez en diez.

        En la propia tarjeta, como se pidió: mover el avance es un gesto de todos
        los días y abrir una ventanita para eso lo convierte en un trámite.
        """
        objetivo = como_va.objetivo
        return ft.Row(
            [
                componentes.boton(
                    self.paleta,
                    "−10 %",
                    al_pulsar=lambda _, o=objetivo: self._mover(o, False),
                ),
                componentes.boton(
                    self.paleta,
                    "+10 %",
                    principal=True,
                    al_pulsar=lambda _, o=objetivo: self._mover(o, True),
                ),
                ft.Text(
                    "el avance de un objetivo libre lo pones tú",
                    size=11,
                    color=self.paleta.muted,
                ),
            ],
            spacing=8,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _mover(self, objetivo, hacia_arriba: bool) -> None:
        nuevo = siguiente_avance(objetivo.avance_manual, hacia_arriba)
        if nuevo == objetivo.avance_manual:
            return
        with conectado() as conexion:
            repo.cambiar_avance(conexion, objetivo.id, nuevo)
            # Al llegar al 100 % se da por conseguido, con la fecha de hoy: es lo
            # que lo baja de la lista y lo guarda para siempre.
            if nuevo == 100 and objetivo.cumplido_en is None:
                repo.marcar_cumplido(conexion, objetivo.id, self.hoy)
            elif nuevo < 100 and objetivo.cumplido_en is not None:
                repo.marcar_cumplido(conexion, objetivo.id, None)
        self.refrescar()

    # ----------------------------------------------------------------------

    def _tarjeta_ultimas(self) -> ft.Control:
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta, "Últimas aportaciones", None
                    ),
                    ft.Column(
                        [
                            self._fila_aportacion(una, nombre)
                            for una, nombre in self.ultimas
                        ],
                        spacing=0,
                    ),
                ],
                spacing=12,
            ),
        )

    def _fila_aportacion(self, aportacion, nombre: str) -> ft.Control:
        saca = aportacion.importe < 0
        return ft.Container(
            content=ft.Row(
                [
                    ft.Text(
                        _fecha(aportacion.fecha),
                        size=11,
                        color=self.paleta.muted,
                        width=80,
                    ),
                    ft.Column(
                        [
                            ft.Text(nombre, size=13, color=self.paleta.ink),
                            ft.Text(
                                aportacion.nota, size=11, color=self.paleta.muted
                            )
                            if aportacion.nota
                            else ft.Container(height=0),
                        ],
                        spacing=1,
                        tight=True,
                        expand=True,
                    ),
                    ft.Text(
                        ("−" if saca else "+") + formatear(abs(aportacion.importe), EUR),
                        size=13,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.negativo if saca else self.paleta.positivo,
                    ),
                ],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(vertical=7),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
        )


def _fecha(dia: date) -> str:
    return f"{dia.day}/{dia.month}/{dia.year % 100:02d}"
