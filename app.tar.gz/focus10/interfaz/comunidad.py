"""La Comunidad: el ranking de quién es más constante. NADA MÁS.

LO PIDIÓ EL USUARIO (7 nov 2026): «no quiero una red social: no quiero
publicaciones, fotos, comentarios ni contenido de usuarios». La Comunidad es
una competencia: el podio del mes, tu puesto, la tabla, y el perfil
competitivo de cada uno. Solo se ven cuentas (hábitos cumplidos, entrenos,
días activos, racha) y el @alias. Las reglas de los puntos están en
dominio/ranking.py; los calcula el SERVIDOR, no esta pantalla.

SOLO COMPITE QUIEN SE ANOTA (lo eligió él). Mirar la tabla no lo pide: ver
quién va primero es la mejor invitación.

TODO LO DE LA RED VA POR DETRÁS (con_la_sesion): la pantalla se pinta al
momento con «Cargando…» y se completa cuando llega. Sin internet, lo dice.
"""

from __future__ import annotations

import flet as ft

from ..datos import ajustes
from ..datos.bd import conectado
from ..dominio import ranking as reglas
from ..sistema import ranking as red
from . import componentes, comunidad_perfil, estilo
from .comunidad_perfil import nombre_del_mes
from .con_sesion import con_la_sesion
from .estilo import Paleta

PERIODOS = (("mes", "Este mes"), ("siempre", "De siempre"))
PODIO = ("oro", "plata", "bronce")


def motivo(fallo: Exception) -> str:
    """El fallo, en una frase que se entienda."""
    texto = str(fallo)
    if "hace falta entrar" in texto:
        return "Entrá con tu cuenta en Configuración → Tu cuenta."
    return texto or "No se pudo cargar el ranking."


class PantallaComunidad(componentes.Pantalla):
    def __init__(self, pagina: ft.Page, paleta: Paleta) -> None:
        super().__init__(pagina, paleta)
        self.periodo = "mes"
        self.mes: str | None = None
        self.estado: dict | None = None
        self.tabla: dict | None = None
        self.otro: dict | None = None
        """El perfil competitivo que se está mirando, o None."""
        self.error = ""
        self._cargando = False
        self.alias = componentes.campo_texto(paleta, "Tu @alias", largo_maximo=20, ancho=260)
        self.aviso_alias = ft.Text("", size=12, color=paleta.negativo, visible=False)
        self.refrescar()

    # ------------------------------------------------------------------ cargar

    def recargar(self) -> None:
        self.estado = self.tabla = None
        self.error = ""
        self.refrescar()

    def _por_detras(self, que_hacer, despues, al_fallar=None) -> None:
        """Hace algo con la red sin congelar la ventana, y repinta al terminar.

        `al_fallar` recibe el motivo; sin él, el fallo ocupa la pantalla con
        «Reintentar». Un alias ocupado, en cambio, se dice debajo del campo.
        """
        if self._cargando:
            return
        self._cargando = True

        async def hacerlo():
            try:
                despues(await con_la_sesion(que_hacer))
            except Exception as fallo:  # noqa: BLE001
                if al_fallar is None:
                    self.error = motivo(fallo)
                else:
                    al_fallar(motivo(fallo))
            finally:
                self._cargando = False
            self.refrescar()

        self.pagina.run_task(hacerlo)

    def _traer(self, testigo: str) -> tuple[dict, dict]:
        estado = red.estado(testigo)
        # EL ALIAS SE APUNTA EN EL APARATO: lo lleva la imagen para compartir
        # un logro, que se arma sin conexión (ver imagen_logro.py).
        with conectado() as conexion:
            ajustes.escribir(conexion, ajustes.CLAVE_ALIAS_COMUNIDAD, estado.get("alias") or "")
        return estado, red.tabla(testigo, self.periodo, self.mes)

    def _llego(self, par) -> None:
        self.estado, self.tabla = par

    def _cambiar(self, periodo: str | None = None, mes: str | None = None) -> None:
        self.periodo = periodo or self.periodo
        self.mes = mes or self.mes
        self.tabla = None
        self.refrescar()

    def _abrir_perfil(self, alias: str) -> None:
        def llego(datos):
            self.otro = datos

        self._por_detras(lambda t: red.perfil(t, alias), llego)

    def cerrar_perfil(self) -> None:
        self.otro = None
        self.refrescar()

    # ------------------------------------------------------------------ pintar

    def refrescar(self) -> None:
        with conectado() as conexion:
            sin_cuenta = ajustes.leer_sesion(conexion) is None
        if sin_cuenta:
            self.pintar([self._titulo(), componentes.aviso_vacio(
                self.paleta,
                "El ranking necesita tu cuenta. Entrá en Configuración → Tu cuenta y volvé aquí.",
                icono=ft.Icons.EMOJI_EVENTS_OUTLINED,
            )])
            return
        if self.error:
            error, self.error = self.error, ""
            self.pintar([self._titulo(), componentes.aviso_error(self.paleta, [error]),
                         componentes.boton(self.paleta, "Reintentar", icono=ft.Icons.REFRESH,
                                           al_pulsar=lambda _: self.recargar())])
            return
        if self.otro is not None:
            self.pintar(comunidad_perfil.piezas(self, self.otro))
            return
        if self.estado is None or self.tabla is None:
            self.pintar([self._titulo(), componentes.aviso_vacio(self.paleta, "Cargando el ranking…")])
            self._por_detras(self._traer, self._llego)
            return
        self.pintar(self.piezas())

    def piezas(self) -> list[ft.Control]:
        """El ranking ya cargado. Aparte para poder dibujarlo sin red (ver
        herramientas/probar_interfaz.py)."""
        filas = self.tabla.get("filas") or []
        piezas: list[ft.Control] = [self._titulo()]
        piezas.append(self._mi_puesto(filas) if self.estado.get("compite") else self._invitacion())
        piezas += [self._selector(), self._podio(filas[:3]), self._lista(filas), self._reglas()]
        if self.estado.get("compite"):
            piezas.append(ft.Row([ft.TextButton(
                "Salirme del ranking", on_click=lambda _: self._preguntar_salir())]))
        return piezas

    def _titulo(self) -> ft.Control:
        return componentes.titulo_pagina(
            self.paleta, "Comunidad", "Quién es el 1% más constante",
            acciones=[componentes.boton_icono(self.paleta, ft.Icons.REFRESH, ayuda="Actualizar",
                                              al_pulsar=lambda _: self.recargar())],
        )

    def _mi_puesto(self, filas: list[dict]) -> ft.Control:
        paleta = self.paleta
        mia = next((f for f in filas if f.get("yo")), None)
        if mia is None:
            cuerpo = ft.Text("Todavía sin puntos este mes. Marcá un hábito y aparecés.",
                             size=estilo.TEXTO, color=paleta.ink_soft)
        else:
            cuerpo = ft.Row(
                [
                    ft.Text(f"#{mia['puesto']}", size=estilo.CIFRA_GRANDE, weight=ft.FontWeight.W_700,
                            color=paleta.acento, font_family=paleta.titular),
                    ft.Column(
                        [
                            ft.Text(f"de {len(filas)} · {mia['puntos']} puntos", size=estilo.TEXTO_TARJETA,
                                    color=paleta.ink, weight=ft.FontWeight.W_600),
                            ft.Text(_cuentas(mia), size=estilo.TEXTO_APOYO, color=paleta.muted),
                        ],
                        spacing=2, tight=True, expand=True,
                    ),
                ],
                spacing=16, vertical_alignment=ft.CrossAxisAlignment.CENTER,
            )
        return componentes.tarjeta(
            paleta,
            ft.Column([componentes.cabecera_tarjeta(paleta, f"Tu posición · @{self.estado.get('alias', '')}"),
                       cuerpo], spacing=10),
            al_pulsar=(lambda _: self._abrir_perfil(mia["alias"])) if mia else None,
        )

    def _invitacion(self) -> ft.Control:
        paleta = self.paleta
        if not self.alias.value:
            self.alias.value = self.estado.get("alias") or ""

        def anotarme(_):
            def llego(estado):
                self.aviso_alias.visible = False
                self.estado, self.tabla = estado, None

            def fallo(texto):
                self.aviso_alias.value, self.aviso_alias.visible = texto, True

            self._por_detras(lambda t: red.anotarme(t, self.alias.value or ""), llego, fallo)

        return componentes.tarjeta(paleta, ft.Column(
            [
                componentes.cabecera_tarjeta(paleta, "Competí por el puesto 1"),
                ft.Text(
                    "Los puntos salen solos de lo que hacés en Focus: hábitos cumplidos, "
                    "entrenos y constancia. Los demás verán tu @alias y esas cuentas; "
                    "nunca los nombres de tus hábitos, tus comidas ni tu dinero.",
                    size=estilo.TEXTO_APOYO, color=paleta.ink_soft,
                ),
                ft.Row([self.alias, componentes.boton(paleta, "Anotarme", principal=True,
                                                      al_pulsar=anotarme)],
                       wrap=True, spacing=10, run_spacing=10,
                       vertical_alignment=ft.CrossAxisAlignment.CENTER),
                self.aviso_alias,
            ],
            spacing=12,
        ))

    def _selector(self) -> ft.Control:
        piezas: list[ft.Control] = [componentes.segmentado(
            self.paleta, PERIODOS, self.periodo, lambda p: self._cambiar(periodo=p))]
        meses = self.tabla.get("meses") or []
        if self.periodo == "mes" and len(meses) > 1:
            elegido = self.mes or meses[-1]
            piezas.append(componentes.selector(
                self.paleta, "Mes", [(m, nombre_del_mes(m)) for m in reversed(meses)],
                valor=elegido, ancho=160,
                al_elegir=lambda e: self._cambiar(mes=e.control.value),
            ))
        return ft.Row(piezas, wrap=True, spacing=10, run_spacing=10,
                      vertical_alignment=ft.CrossAxisAlignment.CENTER)

    def _podio(self, primeros: list[dict]) -> ft.Control:
        """Los tres primeros, destacados. EL PRIMERO EN EL MEDIO Y MÁS ALTO,
        como un podio de verdad: se reconoce sin leer."""
        paleta = self.paleta
        if not primeros:
            return componentes.aviso_vacio(paleta, "Todavía nadie sumó puntos. ¿Arrancás vos?",
                                           icono=ft.Icons.EMOJI_EVENTS_OUTLINED)
        orden = [1, 0, 2] if len(primeros) == 3 else list(range(len(primeros)))
        alturas = {0: 96, 1: 70, 2: 54}
        columnas = []
        for i in orden:
            fila = primeros[i]
            metal = estilo.METALES[PODIO[min(fila["puesto"], 3) - 1]]
            columnas.append(ft.Container(
                ft.Column(
                    [
                        ft.Text(f"@{fila['alias']}", size=estilo.TEXTO, weight=ft.FontWeight.W_600,
                                color=paleta.acento if fila.get("yo") else paleta.ink,
                                max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
                        ft.Text(f"{fila['puntos']} pts", size=estilo.TEXTO_APOYO, color=paleta.muted),
                        ft.Container(
                            ft.Text(str(fila["puesto"]), size=estilo.SUBTITULAR,
                                    weight=ft.FontWeight.W_700, color=estilo.TINTA_MEDALLA),
                            height=alturas[i], bgcolor=metal, border_radius=10,
                            alignment=ft.Alignment.CENTER,
                        ),
                    ],
                    spacing=4, horizontal_alignment=ft.CrossAxisAlignment.CENTER, tight=True,
                ),
                expand=True, on_click=lambda _, a=fila["alias"]: self._abrir_perfil(a),
            ))
        return componentes.tarjeta(paleta, ft.Row(
            columnas, spacing=10, vertical_alignment=ft.CrossAxisAlignment.END))

    def _lista(self, filas: list[dict]) -> ft.Control:
        """La tabla entera. SIN DESLIZAR A LO ANCHO en el celular: las cuentas
        van en un segundo renglón debajo del alias."""
        paleta = self.paleta
        renglones = []
        for fila in filas:
            renglones.append(ft.Container(
                ft.Row(
                    [
                        ft.Text(f"{fila['puesto']}", width=30, size=estilo.TEXTO_TARJETA,
                                weight=ft.FontWeight.W_700, color=paleta.muted),
                        ft.Column(
                            [
                                ft.Text(f"@{fila['alias']}", size=estilo.TEXTO,
                                        weight=ft.FontWeight.W_600,
                                        color=paleta.acento if fila.get("yo") else paleta.ink,
                                        max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
                                ft.Text(_cuentas(fila), size=estilo.ROTULO, color=paleta.muted),
                            ],
                            spacing=1, tight=True, expand=True,
                        ),
                        ft.Text(f"{fila['puntos']}", size=estilo.TEXTO_TARJETA,
                                weight=ft.FontWeight.W_600, color=paleta.ink),
                    ],
                    spacing=10, vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                padding=ft.Padding.symmetric(horizontal=8, vertical=8),
                border_radius=10,
                bgcolor=paleta.surface_2 if fila.get("yo") else None,
                on_click=lambda _, a=fila["alias"]: self._abrir_perfil(a), ink=True,
            ))
        if not renglones:
            return ft.Container()
        return componentes.tarjeta(paleta, ft.Column(
            [componentes.cabecera_tarjeta(paleta, "Ranking", f"{len(filas)} compitiendo"), *renglones],
            spacing=2,
        ))

    def _reglas(self) -> ft.Control:
        texto = (
            f"Hábito cumplido {reglas.PUNTOS_HABITO} · entreno terminado {reglas.PUNTOS_ENTRENO} · "
            f"día con algo hecho {reglas.PUNTOS_DIA} · +{reglas.PUNTOS_RACHA} por cada día de tu "
            "racha más larga del mes. Cuenta lo apuntado ese día (con 2 días de margen); "
            f"como mucho {reglas.HABITOS_POR_DIA} hábitos y {reglas.ENTRENOS_POR_DIA} entrenos por día, "
            f"y entrenos de {reglas.ENTRENO_MINIMO // 60} minutos o más, cronometrados en Focus."
        )
        return ft.Text(texto, size=estilo.ROTULO, color=self.paleta.muted)

    def _preguntar_salir(self) -> None:
        def salir(_):
            self.pagina.pop_dialog()

            def llego(respuesta):
                self.estado = {**(self.estado or {}), "compite": False}
                self.tabla = None

            self._por_detras(red.salirme, llego)

        componentes.confirmar(
            self.paleta, self.pagina, titulo="Salirme del ranking",
            texto="Dejás de aparecer en la tabla. Tu @alias se queda tuyo y podés volver cuando quieras.",
            texto_aceptar="Salirme", al_aceptar=salir,
        )


def _cuentas(fila: dict) -> str:
    return (f"{fila.get('habitos', 0)} hábitos · {fila.get('entrenos', 0)} entrenos · "
            f"{fila.get('dias', 0)} días · racha {fila.get('racha', 0)}")
