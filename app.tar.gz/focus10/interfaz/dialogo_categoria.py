"""Crear una categoría, y la pregunta de si el asistente recuerda sus gastos.

LA PREGUNTA SALE AL CREARLA, como pidió el usuario: es el momento en que sabe
para qué la quiere («Proyecto IA» sí, «Comida» no). Si elige «Preguntar más
adelante», se le vuelve a preguntar al apuntar el primer gasto en ella.

SOLO EN LAS DE GASTO: la memoria sirve para avisar de pagos repetidos y para
que la IA relacione gastos. Un sueldo o un ahorro no se «paga dos veces».
"""

from __future__ import annotations

from collections.abc import Callable

import flet as ft

from ..datos import repositorio_categorias
from ..datos.bd import conectado
from ..dominio.categoria import (
    LARGO_MAXIMO_NOMBRE,
    PREGUNTA_MEMORIA,
    TEXTOS_MEMORIA,
    Categoria,
    Memoria,
)
from ..dominio.movimiento import Tipo
from . import componentes
from .estilo import Paleta


def opciones_de_memoria(paleta: Paleta, valor: Memoria) -> ft.RadioGroup:
    """Las tres respuestas, una debajo de otra: en el móvil no caben en fila."""
    return ft.RadioGroup(
        value=valor.value,
        content=ft.Column(
            [
                ft.Radio(
                    value=memoria.value,
                    label=texto,
                    active_color=paleta.acento,
                    label_style=ft.TextStyle(size=13, color=paleta.ink),
                )
                for memoria, texto in TEXTOS_MEMORIA.items()
            ],
            spacing=0,
            tight=True,
        ),
    )


def crear(
    pagina: ft.Page,
    paleta: Paleta,
    tipo: Tipo,
    al_crear: Callable[[Categoria], None],
) -> None:
    """La ventanita de «Nueva categoría». `al_crear` recibe la ya guardada."""
    nombre = componentes.campo_texto(
        paleta, "Nombre", pista="Proyecto IA", ancho=300,
        largo_maximo=LARGO_MAXIMO_NOMBRE,
    )
    # «PREGUNTAR MÁS ADELANTE» VIENE MARCADA: es la única que no decide nada
    # por el usuario. Si guarda sin mirar, no se recuerda nada a escondidas ni
    # se pierde la pregunta.
    memoria = opciones_de_memoria(paleta, Memoria.PREGUNTAR)
    piezas: list[ft.Control] = [nombre]
    if tipo is Tipo.GASTO:
        piezas += [ft.Text(PREGUNTA_MEMORIA, size=13, color=paleta.ink_soft), memoria]

    def guardar(_):
        elegida = Memoria(memoria.value) if tipo is Tipo.GASTO else Memoria.NO
        try:
            with conectado() as conexion:
                nueva = repositorio_categorias.crear(
                    conexion, nombre.value or "", tipo, memoria=elegida
                )
        except repositorio_categorias.CategoriaRepetida:
            nombre.error_text = "Ya tenés una categoría con ese nombre"
            pagina.update()
            return
        except ValueError as fallo:
            nombre.error_text = str(fallo).capitalize()
            pagina.update()
            return
        pagina.pop_dialog()
        al_crear(nueva)

    nombre.on_submit = guardar
    pagina.show_dialog(
        componentes.dialogo(
            paleta,
            "Nueva categoría",
            ft.Column(piezas, spacing=12, tight=True, width=320),
            pagina=pagina,
            texto_aceptar="Crear",
            al_aceptar=guardar,
        )
    )


def preguntar(
    pagina: ft.Page,
    paleta: Paleta,
    categoria: Categoria,
    al_responder: Callable[[Categoria], None],
) -> None:
    """La pregunta para una categoría que quedó en «Preguntar más adelante».

    SE PREGUNTA ANTES DE APUNTAR Y NO DESPUÉS: si la respuesta es «sí», este
    mismo gasto ya tiene que compararse con la memoria.
    """
    memoria = opciones_de_memoria(paleta, Memoria.SI)

    def responder(_):
        with conectado() as conexion:
            actualizada = repositorio_categorias.cambiar_memoria(
                conexion, categoria.id, Memoria(memoria.value)
            )
        pagina.pop_dialog()
        al_responder(actualizada)

    pagina.show_dialog(
        componentes.dialogo(
            paleta,
            f"«{categoria.nombre}»",
            ft.Column(
                [ft.Text(PREGUNTA_MEMORIA, size=13, color=paleta.ink_soft), memoria],
                spacing=12,
                tight=True,
                width=320,
            ),
            pagina=pagina,
            texto_aceptar="Seguir",
            al_aceptar=responder,
        )
    )


def avisar_repetido(
    pagina: ft.Page, paleta: Paleta, texto: str, al_confirmar: Callable[[], None]
) -> None:
    """«Ya registraste 100 € para Jorge. ¿Seguro…?» con «Agregar igual».

    NO ES ROJO NI DICE «BORRAR»: no se está por perder nada, solo se pregunta.
    Por eso no usa componentes.confirmar, que es para lo que no tiene vuelta.
    """

    def seguir(_):
        pagina.pop_dialog()
        al_confirmar()

    pagina.show_dialog(
        componentes.dialogo(
            paleta,
            "¿Ya lo pagaste?",
            ft.Text(texto, size=13, color=paleta.ink_soft, width=320),
            pagina=pagina,
            texto_aceptar="Agregar igual",
            al_aceptar=seguir,
        )
    )
