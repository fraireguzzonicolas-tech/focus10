"""La franja de «hay una versión nueva», abajo del todo, con su botón.

LO ELIGIÓ ÉL ASÍ, entre recargar sola o avisar: una franja discreta con un
botón. La razón de no recargar sola es la de siempre en esta aplicación: si
estás a mitad de apuntar algo, reiniciarte la pantalla en la cara es peor que
esperar.

SOLO SALE EN LA WEB, y solo cuando de verdad hay otra versión publicada. En
Windows y en el móvil la actualización la hacen el instalador y Google Play.

MIENTRAS NO HAY NADA QUE DECIR NO OCUPA NADA: la franja mide cero y no se ve.
Es la misma idea que la franja del descanso del gimnasio.
"""

from __future__ import annotations

import asyncio

import flet as ft

from ..sello import SELLO
from .. import NOMBRE
from ..sistema import actualizacion
from . import componentes
from .estilo import Paleta

CADA_CUANTO = 600
"""Cada cuántos segundos se pregunta si hay versión nueva.

DIEZ MINUTOS Y NO MENOS: una publicación no es urgente, y esto es una petición
más. Además se pregunta al volver a la ventana, que es cuando de verdad importa.
"""


class AvisoVersion:
    """La franja, su comprobación y el botón que recarga."""

    def __init__(self, pagina: ft.Page) -> None:
        self.pagina = pagina
        self.hay_nueva = False
        self._mirando = False
        # LA FRANJA SE CREA UNA VEZ, como el reloj del entreno y la nube de la
        # sincronización: la ventana se vuelve a montar en cada cambio de
        # sección y el aviso tiene que sobrevivir.
        self.franja = ft.Container(height=0)
        self._paleta: Paleta | None = None

    # ------------------------------------------------------------ la franja

    def control(self, paleta: Paleta) -> ft.Control:
        self._paleta = paleta
        self._pintar(paleta)
        return self.franja

    def _pintar(self, paleta: Paleta) -> None:
        if not self.hay_nueva:
            self.franja.content = None
            self.franja.height = 0
            self.franja.bgcolor = None
            self.franja.padding = 0
            return
        self.franja.content = ft.Row(
            [
                ft.Icon(ft.Icons.SYSTEM_UPDATE_ALT, size=18, color=paleta.acento_ink),
                ft.Text(
                    f"Hay una versión nueva de {NOMBRE}.",
                    size=13,
                    color=paleta.acento_ink,
                    expand=True,
                ),
                componentes.boton(
                    paleta,
                    "Actualizar",
                    principal=False,
                    al_pulsar=lambda _: actualizacion.recargar(),
                ),
            ],
            spacing=10,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )
        self.franja.height = 52
        self.franja.bgcolor = paleta.acento
        self.franja.padding = ft.Padding.symmetric(horizontal=14, vertical=6)

    # ------------------------------------------------------------ el latido

    def empezar(self) -> None:
        """Arranca la comprobación. Solo cuenta la primera vez."""
        if self._mirando or not actualizacion.se_puede_comprobar(SELLO):
            return
        self._mirando = True
        self.pagina.run_task(self._mirar_cada_tanto)

    async def _mirar_cada_tanto(self) -> None:
        while not self.hay_nueva:
            await asyncio.sleep(CADA_CUANTO)
            self.mirar_ahora()

    def mirar_ahora(self) -> None:
        """Comprueba ya. La ventana lo llama también al volver a ella."""
        if self.hay_nueva or not actualizacion.se_puede_comprobar(SELLO):
            return
        if actualizacion.hay_otra_version(SELLO):
            self.hay_nueva = True
            if self._paleta is not None:
                self._pintar(self._paleta)
                try:
                    self.franja.update()
                except Exception:  # noqa: BLE001
                    # Todavía no está en la ventana: se pintará al montarla.
                    pass
