"""La pantalla de Configuración.

CADA AJUSTE SE GUARDA SOLO, en cuanto lo cambias. No hay botón de "Guardar" ni
de "Cancelar" a propósito: son cuatro ajustes sueltos, no un formulario, y un
botón de guardar solo sirve para que un día te vayas sin pulsarlo y te preguntes
por qué no se ha aplicado.

LO QUE NO SE PUEDE CONFIGURAR, y es una decisión, no un olvido: los colores. El
acento es índigo y punto. Se probó a dejar cambiar colores y tamaños y quedaba
peor; la aplicación es bonita porque está decidida.
"""

from __future__ import annotations

import flet as ft

from ..datos import ajustes
from ..datos.bd import conectado
from ..dominio.jornada import Horario
from ..dominio.moneda import CATALOGO, por_codigo
from . import componentes, estilo
from .estilo import Paleta

LARGO_MAXIMO_NOMBRE = 40


class PantallaConfiguracion:
    """Los ajustes de la aplicación."""

    def __init__(
        self, pagina: ft.Page, paleta: Paleta, al_cambiar_tema
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        # Cambiar el tema obliga a repintar la ventana entera, y eso solo lo
        # sabe hacer quien la montó: por eso se recibe de fuera.
        self.al_cambiar_tema = al_cambiar_tema
        self.contenido = ft.Column(spacing=16, scroll=ft.ScrollMode.AUTO, expand=True)
        self._en_pagina = False
        self.refrescar()

    @property
    def control(self) -> ft.Control:
        return self.contenido

    def montada(self) -> None:
        self._en_pagina = True

    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            self.tema = ajustes.leer(conexion, ajustes.CLAVE_TEMA)
            self.nombre = ajustes.leer(conexion, ajustes.CLAVE_NOMBRE)
            self.moneda = ajustes.leer_moneda_principal(conexion)
            self.estilo = ajustes.leer_estilo(conexion)
            self.horario = ajustes.leer_horario(conexion)

        self.contenido.controls = [
            componentes.titulo_pagina(
                self.paleta, "Configuración", "cada cambio se guarda solo"
            ),
            self._tarjeta_aspecto(),
            self._tarjeta_nombre(),
            self._tarjeta_estilo(),
            self._tarjeta_moneda(),
            self._tarjeta_jornada(),
        ]
        if self._en_pagina:
            self.contenido.update()

    # ----------------------------------------------------------------------

    def _tarjeta_aspecto(self) -> ft.Control:
        def elegir(_):
            with conectado() as conexion:
                ajustes.escribir(conexion, ajustes.CLAVE_TEMA, selector.value)
            self.al_cambiar_tema()

        selector = componentes.selector(
            self.paleta,
            "Tema",
            estilo.TEMAS,
            valor=self.tema,
            ancho=240,
            al_elegir=elegir,
        )
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Aspecto",
                        "el color de acento no se puede cambiar, y es a propósito",
                    ),
                    selector,
                ],
                spacing=14,
            ),
        )

    def _tarjeta_nombre(self) -> ft.Control:
        def guardar(_):
            with conectado() as conexion:
                ajustes.escribir(
                    conexion, ajustes.CLAVE_NOMBRE, (campo.value or "").strip()
                )
            componentes.avisar(self.pagina, "Nombre guardado.")

        campo = componentes.campo_texto(
            self.paleta,
            "Tu nombre",
            valor=self.nombre,
            pista="para saludarte y poco más",
            ancho=320,
            largo_maximo=LARGO_MAXIMO_NOMBRE,
            al_enviar=guardar,
        )
        # También al salir del campo: nadie pulsa Intro en un campo de texto.
        campo.on_blur = guardar

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta, "Tú", "solo se usa dentro de la aplicación"
                    ),
                    campo,
                ],
                spacing=14,
            ),
        )

    def _tarjeta_estilo(self) -> ft.Control:
        """Los cinco estilos, para cambiarlos cuando quieras.

        SE PINTA CADA UNO CON SUS PROPIOS COLORES, no con los del estilo activo:
        una lista donde todas las opciones se ven igual no ayuda a elegir. Cada
        fila enseña tres muestras —el fondo, la superficie y el acento— y su
        nombre escrito con SU tipografía, que es lo que de verdad cambia.
        """
        filas = [self._fila_de_estilo(uno) for uno in estilo.ESTILOS]
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Estilo",
                        "cómo se ve la aplicación; el claro/oscuro va aparte",
                    ),
                    ft.Column(filas, spacing=8),
                ],
                spacing=14,
            ),
        )

    def _fila_de_estilo(self, uno) -> ft.Control:
        elegido = uno.clave == self.estilo
        muestra = uno.oscura if self.paleta.modo is ft.ThemeMode.DARK else uno.clara

        return ft.Container(
            content=ft.Row(
                [
                    ft.Row(
                        [
                            self._muestra_de_color(muestra.canvas),
                            self._muestra_de_color(muestra.surface_2),
                            self._muestra_de_color(muestra.acento),
                        ],
                        spacing=4,
                        tight=True,
                    ),
                    ft.Column(
                        [
                            ft.Text(
                                uno.nombre,
                                size=estilo.TEXTO_TARJETA,
                                color=self.paleta.ink,
                                # SU tipografía, no la de ahora: es media
                                # decisión y no se puede juzgar sin verla.
                                font_family=uno.clara.titular,
                            ),
                            ft.Text(
                                uno.descripcion,
                                size=estilo.TEXTO_APOYO,
                                color=self.paleta.muted,
                            ),
                        ],
                        spacing=0,
                        tight=True,
                        expand=True,
                    ),
                    ft.Icon(
                        ft.Icons.CHECK_CIRCLE if elegido else ft.Icons.CIRCLE_OUTLINED,
                        size=20,
                        color=self.paleta.acento if elegido else self.paleta.borde_fuerte,
                    ),
                ],
                spacing=14,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=12, vertical=10),
            bgcolor=self.paleta.surface_2 if elegido else None,
            border=ft.Border.all(
                1, self.paleta.acento if elegido else self.paleta.borde
            ),
            border_radius=estilo.RADIO_CAMPO,
            on_click=lambda _, c=uno.clave: self._elegir_estilo(c),
            ink=True,
        )

    def _muestra_de_color(self, color: str) -> ft.Control:
        return ft.Container(
            width=18,
            height=32,
            bgcolor=color,
            border_radius=5,
            border=ft.Border.all(1, self.paleta.borde),
        )

    def _elegir_estilo(self, clave: str) -> None:
        if clave == self.estilo:
            return
        with conectado() as conexion:
            ajustes.guardar_estilo(conexion, clave)
        # Repinta la ventana ENTERA. Se llama "al_cambiar_tema" porque nació
        # para eso, pero hace lo mismo que hace falta aquí: el estilo cambia los
        # colores y la tipografía de TODAS las pantallas, no solo de esta.
        self.al_cambiar_tema()

    def _tarjeta_moneda(self) -> ft.Control:
        def elegir(_):
            with conectado() as conexion:
                ajustes.guardar_moneda_principal(conexion, por_codigo(selector.value))
            componentes.avisar(self.pagina, "Moneda principal cambiada.")
            self.refrescar()

        selector = componentes.selector(
            self.paleta,
            "Moneda principal",
            [
                (codigo, f"{una.simbolo}  {una.nombre}")
                for codigo, una in sorted(CATALOGO.items())
            ],
            valor=self.moneda.codigo,
            ancho=280,
            al_elegir=elegir,
        )
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta, "Dinero", "en qué moneda se enseñan los totales"
                    ),
                    selector,
                    componentes.aviso(
                        self.paleta,
                        [
                            "Cambiarla NO toca lo ya guardado: cada movimiento "
                            "conserva su importe y la conversión que tenía el día "
                            "que lo apuntaste. Solo lo nuevo usará la moneda nueva."
                        ],
                    ),
                ],
                spacing=14,
            ),
        )

    def _tarjeta_jornada(self) -> ft.Control:
        inicio = componentes.campo_texto(
            self.paleta,
            "Mi día empieza a las",
            valor=self.horario.a_texto()[0],
            pista="18:00",
            ancho=170,
        )
        fin = componentes.campo_texto(
            self.paleta,
            "y termina a las",
            valor=self.horario.a_texto()[1],
            pista="10:00",
            ancho=170,
        )

        def guardar(_):
            inicio.error_text = None
            fin.error_text = None
            try:
                nuevo = Horario.desde_texto(inicio.value or "", fin.value or "")
            except (ValueError, TypeError) as error:
                # No se guarda nada a medias: si una de las dos horas está mal,
                # el horario entero se queda como estaba.
                inicio.error_text = str(error)
                self.pagina.update()
                return

            with conectado() as conexion:
                ajustes.guardar_horario(conexion, nuevo)
            componentes.avisar(self.pagina, "Jornada guardada.")
            self.refrescar()

        inicio.on_blur = guardar
        inicio.on_submit = guardar
        fin.on_blur = guardar
        fin.on_submit = guardar

        cruza = self.horario.cruza_medianoche
        explicacion = (
            "Tu jornada cruza la medianoche, así que lo que apuntes de madrugada "
            "cuenta para el día anterior. La hora de INICIO es la que decide a qué "
            "día pertenece cada cosa."
            if cruza
            else "Tu jornada empieza y termina el mismo día. La hora de INICIO es "
            "la que decide a qué día pertenece cada cosa."
        )

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Mi jornada",
                        f"dura {_horas_y_minutos(self.horario)}",
                    ),
                    # ENVUELVE: las dos horas miden 170 cada una, y juntas se
                    # salen de un movil. Con wrap, la segunda baja a la linea de
                    # abajo cuando no cabe al lado, y en el ordenador se siguen
                    # viendo en la misma fila como siempre.
                    ft.Row([inicio, fin], spacing=12, wrap=True, run_spacing=12),
                    ft.Text(explicacion, size=12, color=self.paleta.muted),
                ],
                spacing=14,
            ),
        )


def _horas_y_minutos(horario: Horario) -> str:
    """La duración del turno, escrita para leerla: "16 h" o "7 h 45 min"."""
    total = int(horario.duracion.total_seconds() // 60)
    horas, minutos = divmod(total, 60)
    return f"{horas} h" if minutos == 0 else f"{horas} h {minutos} min"
