"""La pantalla de Configuración.

CADA AJUSTE SE GUARDA SOLO, en cuanto lo cambias. No hay botón de "Guardar" ni
de "Cancelar" a propósito: son cuatro ajustes sueltos, no un formulario, y un
botón de guardar solo sirve para que un día te vayas sin pulsarlo y te preguntes
por qué no se ha aplicado.

LO QUE NO SE PUEDE CONFIGURAR, y es una decisión, no un olvido: los colores. El
acento es índigo y punto. Se probó a dejar cambiar colores y tamaños y quedaba
peor; la aplicación es bonita porque está decidida.
"""

from __future__ import annotations

import asyncio

import flet as ft

from ..datos import ajustes
from ..datos import repositorio_recompensas
from ..datos.bd import conectado
from ..dominio.recompensa import LARGO_MAXIMO_NOMBRE as LARGO_MAXIMO_RECOMPENSA
from ..dominio.recompensa import MAXIMO_RECOMPENSAS
from ..dominio.comentario import LARGO_MAXIMO as LARGO_MAXIMO_COMENTARIO
from ..dominio.comentario import Comentario
from ..dominio.moneda import CATALOGO, por_codigo
from ..sistema import comentarios
from .. import __version__
from . import componentes, estilo
from .estilo import Paleta

LARGO_MAXIMO_NOMBRE = 40


class PantallaConfiguracion(componentes.Pantalla):
    """Los ajustes de la aplicación."""

    def __init__(
        self, pagina: ft.Page, paleta: Paleta, al_cambiar_tema
    ) -> None:
        super().__init__(pagina, paleta)
        # Cambiar el tema obliga a repintar la ventana entera, y eso solo lo
        # sabe hacer quien la montó: por eso se recibe de fuera.
        self.al_cambiar_tema = al_cambiar_tema

        # EL CAMPO SE CREA UNA VEZ Y VIVE CON LA PANTALLA. Si se construyera en
        # cada refresco, enseñar un error borraría lo que la persona acaba de
        # escribir, que es exactamente cuando más rabia da.
        self.campo_comentario = componentes.campo_texto(
            paleta,
            "Tu comentario",
            pista="Cuéntame qué falla o qué mejorarías",
            largo_maximo=LARGO_MAXIMO_COMENTARIO,
            lineas=4,
        )
        self._error_comentario = ""
        self._enviando = False

        self.refrescar()

    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            self.tema = ajustes.leer(conexion, ajustes.CLAVE_TEMA)
            self.nombre = ajustes.leer(conexion, ajustes.CLAVE_NOMBRE)
            self.moneda = ajustes.leer_moneda_principal(conexion)
            self.estilo = ajustes.leer_estilo(conexion)

        self.pintar(
            [
                componentes.titulo_pagina(
                    self.paleta, "Configuración", "cada cambio se guarda solo"
                ),
                self._tarjeta_aspecto(),
                self._tarjeta_nombre(),
                self._tarjeta_estilo(),
                self._tarjeta_moneda(),
                # AL FINAL Y LA ÚLTIMA, como se pidió: es un extra, no un
                # ajuste de los que se tocan.
                self._tarjeta_recompensas(),
                # DEBAJO DE TODO, como se pidió: no es un ajuste, es una puerta
                # para escribirle a quien hizo la aplicación.
                self._tarjeta_comentarios(),
            ]
        )

    # ----------------------------------------------------------------------

    def _tarjeta_recompensas(self) -> ft.Control:
        """Hasta cinco cosas para elegir cuando la semana sale bien.

        SE QUEDA EN CONFIGURACIÓN Y NO TIENE PANTALLA PROPIA, y lo pidió así el
        usuario: "no quiero una pantalla independiente ni una sección importante
        de la aplicación".
        """
        with conectado() as conexion:
            recompensas = repositorio_recompensas.listar(conexion)

        piezas: list[ft.Control] = [
            componentes.cabecera_tarjeta(
                self.paleta,
                "🎁 Recompensas semanales",
                f"{len(recompensas)} de {MAXIMO_RECOMPENSAS}",
            ),
            ft.Text(
                "Configura hasta 5 recompensas para elegir cuando completes al "
                "menos el 70% de tus hábitos semanales.",
                size=estilo.TEXTO_APOYO,
                color=self.paleta.muted,
            ),
        ]

        if not recompensas:
            piezas.append(
                componentes.aviso_vacio(
                    self.paleta, "Todavía no has puesto ninguna."
                )
            )
        piezas += [self._fila_recompensa(una) for una in recompensas]

        # EL BOTÓN DESAPARECE AL LLEGAR A CINCO en vez de avisar al pulsarlo: un
        # botón que solo sirve para decirte que no se puede es un botón de más.
        if len(recompensas) < MAXIMO_RECOMPENSAS:
            piezas.append(
                componentes.boton(
                    self.paleta,
                    "Agregar recompensa",
                    icono=ft.Icons.ADD,
                    al_pulsar=lambda _: self._pedir_recompensa(),
                )
            )

        return componentes.tarjeta(
            self.paleta, ft.Column(piezas, spacing=12, tight=True)
        )

    def _fila_recompensa(self, recompensa) -> ft.Control:
        return ft.Row(
            [
                ft.Text(
                    recompensa.nombre,
                    size=estilo.TEXTO,
                    color=self.paleta.ink,
                    expand=True,
                ),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.DELETE_OUTLINE,
                    ayuda=f"Quitar «{recompensa.nombre}»",
                    al_pulsar=lambda _, r=recompensa: self._quitar_recompensa(r),
                ),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _quitar_recompensa(self, recompensa) -> None:
        with conectado() as conexion:
            repositorio_recompensas.borrar(conexion, recompensa.id)
        self.refrescar()

    def _pedir_recompensa(self) -> ft.AlertDialog:
        """Pregunta el nombre. El emoji se escribe delante, si quieres."""
        campo = componentes.campo_texto(
            self.paleta,
            "La recompensa",
            pista="🍔 Ir a comer algo rico",
            largo_maximo=LARGO_MAXIMO_RECOMPENSA,
        )
        error = ft.Text(
            "", size=estilo.TEXTO_APOYO, color=self.paleta.negativo, visible=False
        )

        def guardar(_):
            try:
                with conectado() as conexion:
                    repositorio_recompensas.crear(conexion, campo.value or "")
            except (ValueError, TypeError) as fallo:
                error.value = str(fallo)
                error.visible = True
                self.pagina.update()
                return
            self.pagina.pop_dialog()
            self.refrescar()

        ventanita = componentes.dialogo(
            self.paleta,
            "Agregar recompensa",
            ft.Column([campo, error], spacing=10, tight=True, width=340),
            pagina=self.pagina,
            texto_aceptar="Agregar",
            al_aceptar=guardar,
        )
        self.pagina.show_dialog(ventanita)
        return ventanita

    def _tarjeta_comentarios(self) -> ft.Control:
        """Un hueco para contar un fallo o proponer algo, y un botón de enviar.

        LO PIDIÓ EL USUARIO para la gente que use la aplicación: "che, esto
        funciona mal", "che, recomendaría esto". El mensaje va a un servidor
        suyo, que es quien manda el correo.

        SOLO VIAJA EL TEXTO Y LA VERSIÓN, y se dice en pantalla. Que alguien
        escriba una queja sin saber qué más se está mandando de su equipo es
        justo lo que hace que no vuelva a escribir.
        """
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta, "💬 Comentarios y sugerencias"
                    ),
                    ft.Text(
                        "¿Algo va mal, o se te ocurre algo mejor? Cuéntalo aquí. "
                        "Solo se manda tu mensaje y la versión de la aplicación.",
                        size=estilo.TEXTO_APOYO,
                        color=self.paleta.muted,
                    ),
                    *self._cuerpo_comentarios(),
                ],
                spacing=12,
                tight=True,
            ),
        )

    def _cuerpo_comentarios(self) -> list[ft.Control]:
        """El cuadro de escribir y el botón, o el aviso de que aún no se puede.

        SIN SERVIDOR NO SE OFRECE EL CUADRO, y es a propósito: dejar escribir
        dos mil letras para contestar después que no se puede enviar es la peor
        forma de decirlo. Se avisa ANTES, que es cuando sirve de algo.
        """
        if not comentarios.DIRECCION:
            return [
                componentes.aviso_vacio(
                    self.paleta,
                    "Todavía no se pueden enviar comentarios desde esta "
                    "versión. Estará en la siguiente.",
                )
            ]

        return [
            self.campo_comentario,
            *(
                [componentes.aviso_error(self.paleta, [self._error_comentario])]
                if self._error_comentario
                else []
            ),
            componentes.boton(
                self.paleta,
                "Enviando..." if self._enviando else "Enviar",
                icono=ft.Icons.SEND_OUTLINED,
                al_pulsar=lambda _: self._enviar_comentario(),
            ),
        ]

    def _enviar_comentario(self) -> None:
        """Comprueba lo escrito y lo manda, sin congelar la pantalla.

        EL TEXTO NO SE BORRA HASTA QUE LLEGA. Si falla la red, lo escrito sigue
        ahí para volver a intentarlo; perder tres frases por un corte de wifi es
        la clase de cosa que hace que no las escribas otra vez.
        """
        if self._enviando:
            return

        try:
            comentario = Comentario(
                texto=self.campo_comentario.value or "", version=__version__
            )
        except (ValueError, TypeError) as fallo:
            self._error_comentario = str(fallo)
            self.refrescar()
            return

        self._error_comentario = ""
        self._enviando = True
        self.refrescar()
        self.pagina.run_task(self._mandar_comentario, comentario)

    async def _mandar_comentario(self, comentario) -> None:
        """El envío, en otro hilo: la red puede tardar quince segundos.

        SE USA UN HILO Y NO UNA ESPERA A SECAS porque urllib bloquea, y la
        ventana entera se quedaría congelada mientras tanto.
        """
        try:
            await asyncio.to_thread(comentarios.enviar, comentario)
        except comentarios.NoSePudoEnviar as fallo:
            self._error_comentario = str(fallo)
        else:
            self._error_comentario = ""
            self.campo_comentario.value = ""
            componentes.avisar(self.pagina, "¡Gracias! Tu comentario ha llegado.")
        finally:
            self._enviando = False
            self.refrescar()

    def _tarjeta_aspecto(self) -> ft.Control:
        def elegir(_):
            with conectado() as conexion:
                ajustes.escribir(conexion, ajustes.CLAVE_TEMA, selector.value)
            self.al_cambiar_tema()

        selector = componentes.selector(
            self.paleta,
            "Tema",
            estilo.TEMAS,
            valor=self.tema,
            ancho=240,
            al_elegir=elegir,
        )
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Aspecto",
                        "el color de acento no se puede cambiar, y es a propósito",
                    ),
                    selector,
                ],
                spacing=14,
            ),
        )

    def _tarjeta_nombre(self) -> ft.Control:
        def guardar(_):
            with conectado() as conexion:
                ajustes.escribir(
                    conexion, ajustes.CLAVE_NOMBRE, (campo.value or "").strip()
                )
            componentes.avisar(self.pagina, "Nombre guardado.")

        campo = componentes.campo_texto(
            self.paleta,
            "Tu nombre",
            valor=self.nombre,
            pista="para saludarte y poco más",
            ancho=320,
            largo_maximo=LARGO_MAXIMO_NOMBRE,
            al_enviar=guardar,
        )
        # También al salir del campo: nadie pulsa Intro en un campo de texto.
        campo.on_blur = guardar

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta, "Tú", "solo se usa dentro de la aplicación"
                    ),
                    campo,
                ],
                spacing=14,
            ),
        )

    def _tarjeta_estilo(self) -> ft.Control:
        """Los cinco estilos, para cambiarlos cuando quieras.

        SE PINTA CADA UNO CON SUS PROPIOS COLORES, no con los del estilo activo:
        una lista donde todas las opciones se ven igual no ayuda a elegir. Cada
        fila enseña tres muestras —el fondo, la superficie y el acento— y su
        nombre escrito con SU tipografía, que es lo que de verdad cambia.
        """
        filas = [self._fila_de_estilo(uno) for uno in estilo.ESTILOS]
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Estilo",
                        "cómo se ve la aplicación; el claro/oscuro va aparte",
                    ),
                    ft.Column(filas, spacing=8),
                ],
                spacing=14,
            ),
        )

    def _fila_de_estilo(self, uno) -> ft.Control:
        elegido = uno.clave == self.estilo
        muestra = uno.oscura if self.paleta.modo is ft.ThemeMode.DARK else uno.clara

        return ft.Container(
            content=ft.Row(
                [
                    ft.Row(
                        [
                            self._muestra_de_color(muestra.canvas),
                            self._muestra_de_color(muestra.surface_2),
                            self._muestra_de_color(muestra.acento),
                        ],
                        spacing=4,
                        tight=True,
                    ),
                    ft.Column(
                        [
                            ft.Text(
                                uno.nombre,
                                size=estilo.TEXTO_TARJETA,
                                color=self.paleta.ink,
                                # SU tipografía, no la de ahora: es media
                                # decisión y no se puede juzgar sin verla.
                                font_family=uno.clara.titular,
                            ),
                            ft.Text(
                                uno.descripcion,
                                size=estilo.TEXTO_APOYO,
                                color=self.paleta.muted,
                            ),
                        ],
                        spacing=0,
                        tight=True,
                        expand=True,
                    ),
                    ft.Icon(
                        ft.Icons.CHECK_CIRCLE if elegido else ft.Icons.CIRCLE_OUTLINED,
                        size=20,
                        color=self.paleta.acento if elegido else self.paleta.borde_fuerte,
                    ),
                ],
                spacing=14,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=12, vertical=10),
            bgcolor=self.paleta.surface_2 if elegido else None,
            border=ft.Border.all(
                1, self.paleta.acento if elegido else self.paleta.borde
            ),
            border_radius=estilo.RADIO_CAMPO,
            on_click=lambda _, c=uno.clave: self._elegir_estilo(c),
            ink=True,
        )

    def _muestra_de_color(self, color: str) -> ft.Control:
        return ft.Container(
            width=18,
            height=32,
            bgcolor=color,
            border_radius=5,
            border=ft.Border.all(1, self.paleta.borde),
        )

    def _elegir_estilo(self, clave: str) -> None:
        if clave == self.estilo:
            return
        with conectado() as conexion:
            ajustes.guardar_estilo(conexion, clave)
        # Repinta la ventana ENTERA. Se llama "al_cambiar_tema" porque nació
        # para eso, pero hace lo mismo que hace falta aquí: el estilo cambia los
        # colores y la tipografía de TODAS las pantallas, no solo de esta.
        self.al_cambiar_tema()

    def _tarjeta_moneda(self) -> ft.Control:
        def elegir(_):
            with conectado() as conexion:
                ajustes.guardar_moneda_principal(conexion, por_codigo(selector.value))
            componentes.avisar(self.pagina, "Moneda principal cambiada.")
            self.refrescar()

        selector = componentes.selector(
            self.paleta,
            "Moneda principal",
            [
                (codigo, f"{una.simbolo}  {una.nombre}")
                for codigo, una in sorted(CATALOGO.items())
            ],
            valor=self.moneda.codigo,
            ancho=280,
            al_elegir=elegir,
        )
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta, "Dinero", "en qué moneda se enseñan los totales"
                    ),
                    selector,
                    componentes.aviso(
                        self.paleta,
                        [
                            "Cambiarla NO toca lo ya guardado: cada movimiento "
                            "conserva su importe y la conversión que tenía el día "
                            "que lo apuntaste. Solo lo nuevo usará la moneda nueva."
                        ],
                    ),
                ],
                spacing=14,
            ),
        )

