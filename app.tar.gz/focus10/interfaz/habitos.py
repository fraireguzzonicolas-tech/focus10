"""La pantalla de hábitos: el historial, con sus tres vistas.

  AÑO     la foto del año entero: un cuadrito por día y por hábito, con el
          porcentaje de cumplimiento a la derecha.
  SEMANA  el tracker de toda la vida: una fila por hábito y siete círculos,
          con la gráfica de cómo va la semana encima. ES LA VISTA DE ENTRADA.
  MES     un calendario con los días grandes, cada uno con su "3/5".

QUÉ NO ESTÁ AQUÍ: marcar lo de hoy. Eso vive en el Dashboard, porque son dos
preguntas distintas —"¿qué me toca hoy?" y "¿cómo llevo el año?"— y juntarlas
obligaba a elegir vista cada vez que abrías la app solo para marcar el agua. La
vista de SEMANA sí deja marcar, pero para lo que sirve es para corregir días
pasados que se te olvidaron.

TODO SE FECHA POR JORNADA, no por el reloj: marcar un hábito a las 3 de la
madrugada cuenta para la jornada que empezó ayer. Es la misma regla del dinero, y
para quien trabaja de noche es la diferencia entre una racha real y una racha
rota cada madrugada.
"""

from __future__ import annotations

import calendar
from datetime import date, timedelta
from enum import StrEnum

import flet as ft

from ..datos import repositorio_habitos
from ..datos import repositorio_dias
from ..datos.bd import conectado
from ..dominio.anuario import rejilla_del_ano
from ..dominio.habito import Habito
from ..dominio.semana import LETRAS, texto_mes
from ..dominio.rachas import (
    calcular_rachas,
    cumplimiento_de_varios,
    media_de_semanas_anteriores,
)
from . import componentes, dialogo_habito, estilo, rejilla_ano
from . import estilo
from .estilo import Paleta
from .grafico_semana import grafico_semana

UN_DIA = timedelta(days=1)
UNA_SEMANA = timedelta(days=7)
SEMANAS_DE_MEDIA = 8



class Vista(StrEnum):
    ANO = "año"
    SEMANA = "semana"
    MES = "mes"


ANCHO_NOMBRE = 190
"""Lo que ocupa la columna de los nombres en la vista de semana."""

ANCHO_NOMBRE_ESTRECHO = 88
"""Lo mismo en un móvil.

190 más los siete días son casi 500 puntos, y la pantalla tiene 375. El nombre
del hábito se corta antes, sí, pero la alternativa era no ver la semana entera,
y la semana es justo lo que se viene a mirar aquí.
"""


ANCHO_DIA = 42
"""Lo que ocupa cada dia en la vista de semana."""

ANCHO_DIA_ESTRECHO = 30
"""Lo mismo en un movil.

Siete dias de 42 son 294, y con la columna de nombres no caben en 375. A 30 el
circulito del habito se sigue tocando bien con el dedo: el minimo comodo son
unos 28 puntos.
"""


def _ancho_nombre() -> int:
    return ANCHO_NOMBRE_ESTRECHO if estilo.pantalla_estrecha() else ANCHO_NOMBRE


def _ancho_dia() -> int:
    return ANCHO_DIA_ESTRECHO if estilo.pantalla_estrecha() else ANCHO_DIA


class PantallaHabitos(componentes.Pantalla):
    def __init__(self, pagina: ft.Page, paleta: Paleta) -> None:
        super().__init__(pagina, paleta)
        # SE ENTRA POR SEMANA, y lo pidió el usuario: "quiero que se quede fija
        # esa vista". Tiene sentido: la semana es la escala en la que uno se
        # corrige —"llevo tres días sin"— mientras que el año es para mirar de
        # vez en cuando. Entrar por el año obligaba a cambiar de vista casi
        # siempre.
        self.vista = Vista.SEMANA
        self.desplazamiento = 0  # años, semanas o meses hacia atrás, según la vista
        self.refrescar()

    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            self.hoy = repositorio_dias.jornada_abierta(conexion)
            self.habitos = repositorio_habitos.listar(conexion)

        piezas: list[ft.Control] = [self._cabecera(), self._selector_de_vista()]

        if not self.habitos:
            piezas.append(
                componentes.tarjeta(
                    self.paleta,
                    componentes.aviso_vacio(
                        self.paleta,
                        "Todavía no tienes ningún hábito. Crea el primero con el "
                        "botón de arriba.",
                        icono=ft.Icons.CHECK_CIRCLE_OUTLINE,
                        alto=140,
                    ),
                )
            )
        elif self.vista is Vista.ANO:
            piezas += self._vista_ano()
        elif self.vista is Vista.SEMANA:
            piezas += self._vista_semana()
        else:
            piezas += self._vista_mes()

        self.pintar(piezas)

    # ----------------------------------------------------------------------
    # Cabecera y navegación
    # ----------------------------------------------------------------------

    def _cabecera(self) -> ft.Control:
        return componentes.titulo_pagina(
            self.paleta,
            "Hábitos",
            self._subtitulo(),
            acciones=[
                # MODIFICAR VA ANTES QUE CREAR, y no es casualidad: el usuario
                # se puso "tres veces al día" de alemán, no pudo bajarlo y no
                # encontró dónde. Corregir es lo que se busca cuando algo ya no
                # encaja; crear se busca una vez y ya sabes dónde está.
                #
                # SOLO SALE SI HAY HÁBITOS: un botón para corregir cuando no
                # tienes ninguno abre una lista vacía y no hace nada.
                *(
                    [
                        componentes.boton(
                            self.paleta,
                            "Modificar",
                            icono=ft.Icons.EDIT_OUTLINED,
                            al_pulsar=lambda _: self._elegir_para_modificar(),
                        )
                    ]
                    if self.habitos
                    else []
                ),
                componentes.boton(
                    self.paleta,
                    "Nuevo hábito",
                    icono=ft.Icons.ADD,
                    principal=True,
                    al_pulsar=lambda _: dialogo_habito.abrir(
                        self.pagina, self.paleta, self.refrescar
                    ),
                ),
            ],
        )

    def _elegir_para_modificar(self) -> ft.AlertDialog:
        """Pregunta cuál quieres tocar y abre su ficha.

        DOS PASOS Y NO UNO porque el botón está en la cabecera, que no sabe de
        qué hábito hablas. En la vista de semana se puede ir directo tocando su
        nombre; esto es para llegar desde cualquier vista.
        """
        filas = [
            ft.Container(
                content=ft.Text(
                    f"{uno.emoji}  {uno.nombre}",
                    size=estilo.TEXTO,
                    color=self.paleta.ink,
                ),
                padding=ft.Padding.symmetric(horizontal=10, vertical=10),
                border_radius=estilo.RADIO_CAMPO,
                on_click=lambda _, h=uno: self._modificar(h),
            )
            for uno in self.habitos
        ]

        ventanita = ft.AlertDialog(
            modal=True,
            title=ft.Text(
                "¿Cuál quieres modificar?",
                size=15,
                weight=ft.FontWeight.W_600,
                color=self.paleta.ink,
            ),
            content=ft.Container(
                content=ft.Column(filas, spacing=2, tight=True,
                                  scroll=ft.ScrollMode.AUTO),
                width=320,
            ),
            bgcolor=self.paleta.surface,
            actions=[
                ft.TextButton(
                    "Cancelar", on_click=lambda _: self.pagina.pop_dialog()
                )
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )
        self.pagina.show_dialog(ventanita)
        return ventanita

    def _modificar(self, habito: Habito) -> None:
        """Cierra la lista y abre la ficha de ese hábito."""
        self.pagina.pop_dialog()
        dialogo_habito.abrir(self.pagina, self.paleta, self.refrescar, habito)

    def _subtitulo(self) -> str:
        if self.vista is Vista.ANO:
            return str(self._ano())
        if self.vista is Vista.SEMANA:
            lunes = self._lunes_de_la_semana()
            domingo = lunes + timedelta(days=6)
            return f"{lunes.day}/{lunes.month} – {domingo.day}/{domingo.month}"
        mes = self._primero_del_mes()
        return texto_mes(mes)

    def _selector_de_vista(self) -> ft.Control:
        """Los tres botones de vista, y las flechas de moverse por el tiempo."""
        botones = [
            self._boton_vista(vista) for vista in (Vista.ANO, Vista.SEMANA, Vista.MES)
        ]
        piezas: list[ft.Control] = [ft.Row(botones, spacing=6), ft.Container(expand=True)]

        if True:
            piezas += [
                componentes.boton_icono(
                    self.paleta, ft.Icons.CHEVRON_LEFT,
                    ayuda="Anterior", al_pulsar=lambda _: self._mover(-1),
                ),
                componentes.boton(
                    self.paleta,
                    "Este año" if self.vista is Vista.ANO else "Hoy",
                    al_pulsar=lambda _: self._mover_a_hoy(),
                ),
                componentes.boton_icono(
                    self.paleta, ft.Icons.CHEVRON_RIGHT,
                    ayuda="Siguiente", al_pulsar=lambda _: self._mover(1),
                ),
            ]

        return ft.Row(piezas, vertical_alignment=ft.CrossAxisAlignment.CENTER)

    def _boton_vista(self, vista: Vista) -> ft.Control:
        elegida = vista is self.vista
        return ft.Container(
            content=ft.Text(
                vista.value.capitalize(),
                size=13,
                weight=ft.FontWeight.W_500,
                color=self.paleta.acento_ink if elegida else self.paleta.ink_soft,
            ),
            height=estilo.ALTO_BOTON,
            padding=ft.Padding.symmetric(horizontal=16),
            bgcolor=self.paleta.acento if elegida else self.paleta.surface_2,
            border=None if elegida else ft.Border.all(1, self.paleta.borde),
            border_radius=estilo.RADIO_BOTON,
            alignment=ft.Alignment.CENTER,
            on_click=lambda _, v=vista: self._cambiar_vista(v),
            ink=True,
        )

    def _cambiar_vista(self, vista: Vista) -> None:
        if vista is self.vista:
            return
        self.vista = vista
        # Al cambiar de vista se vuelve a hoy: si no, se pasa de "hace tres
        # semanas" a "hace tres meses" sin querer.
        self.desplazamiento = 0
        self.refrescar()

    def _mover(self, cuanto: int) -> None:
        # Nunca hacia el futuro: no hay nada que ver ahí, y solo confunde.
        self.desplazamiento = min(0, self.desplazamiento + cuanto)
        self.refrescar()

    def _mover_a_hoy(self) -> None:
        self.desplazamiento = 0
        self.refrescar()

    # ----------------------------------------------------------------------
    # Vista año
    # ----------------------------------------------------------------------

    def _ano(self) -> int:
        """El año que se está mirando. El desplazamiento va en años, hacia atrás."""
        return self.hoy.year + self.desplazamiento

    def _vista_ano(self) -> list[ft.Control]:
        """Una tarjeta por hábito con su año entero en cuadritos.

        Cada hábito lleva DOS consultas: lo marcado en el año, y el primer día
        que tiene marca. Ese segundo dato es el que evita que un hábito creado en
        junio salga con cinco meses de fallos que nunca existieron; ver
        dominio/anuario.py.
        """
        ano = self._ano()
        desde = date(ano, 1, 1)
        hasta = date(ano, 12, 31)

        tarjetas: list[ft.Control] = []
        with conectado() as conexion:
            for habito in self.habitos:
                cantidades = repositorio_habitos.cantidades_de(
                    conexion, habito.id, desde, hasta
                )
                primera = repositorio_habitos.primera_jornada(conexion, habito.id)
                anuario = rejilla_del_ano(
                    habito, cantidades, ano=ano, hoy=self.hoy, desde=primera
                )
                tarjetas.append(self._tarjeta_ano(habito, anuario))

        tarjetas.append(
            ft.Text(
                "Cada cuadrito es un día. En color, los que cumpliste; apagados, "
                "los que fallaste; en gris, los que ese hábito no tocaba o "
                "todavía no han llegado. El porcentaje solo cuenta los días que "
                "tocaban y ya pasaron.",
                size=11,
                color=self.paleta.muted,
            )
        )
        return tarjetas

    def _tarjeta_ano(self, habito: Habito, anuario) -> ft.Control:
        with conectado() as conexion:
            historial = repositorio_habitos.cantidades_de(conexion, habito.id)
        rachas = calcular_rachas(habito, historial, self.hoy)

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    rejilla_ano.cabecera(
                        self.paleta,
                        nombre=habito.nombre,
                        emoji=habito.emoji,
                        objetivo=habito.texto_objetivo(),
                        anuario=anuario,
                        color=habito.color,
                    ),
                    # La cuadrícula se sale de la ventana en pantallas estrechas,
                    # así que se deja rodar en horizontal en vez de encogerla:
                    # cuadritos más pequeños ya no se distinguirían.
                    ft.Row(
                        [rejilla_ano.rejilla(self.paleta, anuario, color=habito.color)],
                        scroll=ft.ScrollMode.AUTO,
                    ),
                    ft.Row(
                        [
                            ft.Text(
                                f"racha {rachas.actual} · mejor {rachas.mejor}",
                                size=11,
                                color=self.paleta.muted,
                                expand=True,
                            ),
                            componentes.boton_icono(
                                self.paleta,
                                ft.Icons.MORE_HORIZ,
                                ayuda="Corregir o archivar",
                                al_pulsar=lambda _, h=habito: dialogo_habito.abrir(
                                    self.pagina, self.paleta, self.refrescar, h
                                ),
                            ),
                        ],
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                ],
                spacing=10,
            ),
        )

    # ----------------------------------------------------------------------
    # Vista semana
    # ----------------------------------------------------------------------

    def _lunes_de_la_semana(self) -> date:
        lunes = self.hoy - timedelta(days=self.hoy.weekday())
        return lunes + UNA_SEMANA * self.desplazamiento

    def _vista_semana(self) -> list[ft.Control]:
        lunes = self._lunes_de_la_semana()
        dias = [lunes + timedelta(days=numero) for numero in range(7)]

        with conectado() as conexion:
            cantidades = repositorio_habitos.cantidades_de_todos(
                conexion, lunes - UNA_SEMANA * SEMANAS_DE_MEDIA, dias[-1]
            )

        esta_semana = cumplimiento_de_varios(self.habitos, cantidades, dias)
        anteriores = [
            cumplimiento_de_varios(
                self.habitos,
                cantidades,
                [lunes - UNA_SEMANA * atras + timedelta(days=n) for n in range(7)],
            )
            for atras in range(1, SEMANAS_DE_MEDIA + 1)
        ]
        media = media_de_semanas_anteriores(anteriores)

        return [
            componentes.tarjeta(
                self.paleta,
                ft.Column(
                    [
                        componentes.cabecera_tarjeta(
                            self.paleta,
                            "Cómo va la semana",
                            "la punteada es tu media de las 8 semanas anteriores",
                        ),
                        grafico_semana(esta_semana, media, self.paleta),
                    ],
                    spacing=14,
                ),
            ),
            componentes.tarjeta(
                self.paleta,
                ft.Column(
                    [
                        componentes.cabecera_tarjeta(self.paleta, "Tracker", None),
                        self._cabecera_semana(dias),
                        ft.Column(
                            [
                                self._fila_semana(uno, dias, cantidades)
                                for uno in self.habitos
                            ],
                            spacing=0,
                        ),
                        ft.Text(
                            "Los días apagados son días en que ese hábito no toca: "
                            "se pueden marcar, pero no cuentan para la racha.",
                            size=11,
                            color=self.paleta.muted,
                        ),
                    ],
                    spacing=12,
                ),
            ),
        ]

    def _cabecera_semana(self, dias: list[date]) -> ft.Control:
        return ft.Row(
            [
                ft.Container(width=_ancho_nombre()),
                *[
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Text(
                                    LETRAS[dia.weekday()],
                                    size=11,
                                    color=self.paleta.muted,
                                ),
                                ft.Text(
                                    str(dia.day),
                                    size=11,
                                    weight=ft.FontWeight.W_600
                                    if dia == self.hoy
                                    else ft.FontWeight.NORMAL,
                                    color=self.paleta.acento
                                    if dia == self.hoy
                                    else self.paleta.muted,
                                ),
                            ],
                            spacing=0,
                            tight=True,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                        width=_ancho_dia(),
                        alignment=ft.Alignment.CENTER,
                    )
                    for dia in dias
                ],
            ],
            spacing=4,
        )

    def _fila_semana(
        self, habito: Habito, dias: list[date], cantidades: dict
    ) -> ft.Control:
        with conectado() as conexion:
            historial = repositorio_habitos.cantidades_de(conexion, habito.id)
        rachas = calcular_rachas(habito, historial, self.hoy)

        circulos = []
        for dia in dias:
            cantidad = cantidades.get((habito.id, dia), 0)
            circulos.append(
                ft.Container(
                    content=componentes.circulo_habito(
                        self.paleta,
                        color=habito.color,
                        emoji=habito.emoji,
                        cantidad=cantidad,
                        objetivo=habito.objetivo,
                        programado=habito.toca_en(dia),
                        tamano=componentes.TAMANO_CIRCULO_SEMANA,
                        con_barra=True,
                        ayuda=f"{habito.nombre} · {dia.day}/{dia.month}",
                        al_pulsar=(
                            None
                            if dia > self.hoy
                            else (
                                lambda _, h=habito, d=dia, c=cantidad: self._pulsar_en(
                                    h, d, c
                                )
                            )
                        ),
                    ),
                    width=_ancho_dia(),
                    alignment=ft.Alignment.CENTER,
                    # Los días que aún no han llegado no se pueden marcar.
                    opacity=0.3 if dia > self.hoy else 1.0,
                )
            )

        return ft.Container(
            content=ft.Row(
                [
                    # EL NOMBRE ABRE LA FICHA DEL HÁBITO, y esto faltaba: el
                    # usuario se puso "tres veces al día" de alemán, vio que no
                    # había manera de bajarlo y no encontró dónde. Corregir
                    # existía, pero SOLO en la vista de Año, que es la que menos
                    # se mira.
                    #
                    # SE USA EL NOMBRE Y NO UN BOTÓN NUEVO porque la fila ya va
                    # justa de ancho: siete círculos más el nombre caben en un
                    # móvil de 375 puntos por poco, y un botón de más la sacaría
                    # de la pantalla. El texto de ayuda dice que se puede tocar.
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Text(
                                    f"{habito.emoji}  {habito.nombre}",
                                    size=13,
                                    color=self.paleta.ink,
                                ),
                                ft.Text(
                                    f"racha {rachas.actual} · mejor {rachas.mejor}",
                                    size=10,
                                    color=self.paleta.muted,
                                ),
                            ],
                            spacing=0,
                            tight=True,
                        ),
                        width=_ancho_nombre(),
                        tooltip=f"Tocar para corregir «{habito.nombre}»",
                        on_click=lambda _, h=habito: dialogo_habito.abrir(
                            self.pagina, self.paleta, self.refrescar, h
                        ),
                    ),
                    *circulos,
                ],
                spacing=4,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(vertical=5),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
        )

    def _marcar(self, habito: Habito, dia: date, cantidad: int) -> None:
        with conectado() as conexion:
            repositorio_habitos.marcar(conexion, habito.id, dia, cantidad)
        self.refrescar()

    def _pulsar_en(self, habito: Habito, dia: date, cantidad: int) -> None:
        """Igual que en la vista de día, pero en la jornada que se pulse."""
        if habito.se_apaga_al_pulsar(cantidad):
            self._marcar(habito, dia, 0)
            return
        with conectado() as conexion:
            repositorio_habitos.sumar(conexion, habito.id, dia, 1)
        self.refrescar()

    # ----------------------------------------------------------------------
    # Vista mes
    # ----------------------------------------------------------------------

    def _primero_del_mes(self) -> date:
        mes = self.hoy.month + self.desplazamiento
        ano = self.hoy.year + (mes - 1) // 12
        mes = (mes - 1) % 12 + 1
        return date(ano, mes, 1)

    def _vista_mes(self) -> list[ft.Control]:
        primero = self._primero_del_mes()
        ultimo_dia = calendar.monthrange(primero.year, primero.month)[1]
        dias = [date(primero.year, primero.month, n) for n in range(1, ultimo_dia + 1)]

        with conectado() as conexion:
            cantidades = repositorio_habitos.cantidades_de_todos(
                conexion, primero, dias[-1]
            )

        por_dia = {
            uno.jornada: uno
            for uno in cumplimiento_de_varios(self.habitos, cantidades, dias)
        }

        # El calendario empieza en lunes: se rellenan los huecos del principio.
        celdas: list[ft.Control] = [
            ft.Container(width=88, height=74) for _ in range(primero.weekday())
        ]
        celdas += [self._celda_mes(por_dia[dia]) for dia in dias]

        filas = [
            ft.Row(celdas[inicio : inicio + 7], spacing=6)
            for inicio in range(0, len(celdas), 7)
        ]

        return [
            componentes.tarjeta(
                self.paleta,
                ft.Column(
                    [
                        componentes.cabecera_tarjeta(
                            self.paleta,
                            "El mes",
                            "cuanto más lleno, más cumpliste ese día",
                        ),
                        ft.Row(
                            [
                                ft.Container(
                                    content=ft.Text(
                                        letra, size=11, color=self.paleta.muted
                                    ),
                                    width=88,
                                    alignment=ft.Alignment.CENTER,
                                )
                                for letra in LETRAS
                            ],
                            spacing=6,
                        ),
                        ft.Column(filas, spacing=6),
                        ft.Text(
                            "Los días en gris son días en que no tocaba ningún "
                            "hábito: no son un fallo.",
                            size=11,
                            color=self.paleta.muted,
                        ),
                    ],
                    spacing=12,
                ),
            )
        ]

    def _celda_mes(self, dia) -> ft.Control:
        """Un día del calendario: su número y su "3/5", teñido según cumpliste."""
        es_hoy = dia.jornada == self.hoy

        if not dia.hay_algo_programado:
            fondo = self.paleta.surface_2
            color_numero = self.paleta.muted
        else:
            # El relleno va con lo cumplido; el mínimo es para que un día
            # programado y fallado no parezca un día vacío.
            fondo = estilo.con_opacidad(
                self.paleta.acento, 0.12 + 0.55 * dia.proporcion
            )
            color_numero = self.paleta.ink

        return ft.Container(
            content=ft.Column(
                [
                    ft.Text(
                        str(dia.jornada.day),
                        size=15,
                        weight=ft.FontWeight.W_600,
                        color=color_numero,
                    ),
                    ft.Text(dia.texto(), size=11, color=self.paleta.muted),
                ],
                spacing=2,
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                alignment=ft.MainAxisAlignment.CENTER,
            ),
            width=88,
            height=74,
            bgcolor=fondo,
            border=ft.Border.all(
                2 if es_hoy else 1,
                self.paleta.acento if es_hoy else self.paleta.borde,
            ),
            border_radius=estilo.RADIO_BOTON,
            alignment=ft.Alignment.CENTER,
        )

