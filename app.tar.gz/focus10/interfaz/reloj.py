"""El relojito de agujas del Dashboard.

POR QUÉ UN RELOJ DIBUJADO Y NO SOLO LA HORA EN NÚMEROS: lo pidió el usuario —"un
relojito o algo que se vaya moviendo, que queda más fachero"— y tiene razón en
algo más que lo bonito. Un número que cambia una vez por minuto está muerto casi
todo el rato; un segundero dando vueltas dice de un vistazo que la aplicación
está viva y que lo que enseña es de ahora.

AQUÍ SOLO SE DIBUJA. Este archivo no sabe qué hora es: se la dan. Así se puede
pintar cualquier hora sin esperar a que llegue, que es lo que permite
comprobarlo en un test en vez de mirarlo a las tres de la mañana.

LAS AGUJAS SE MUEVEN CON DECIMALES, no a saltos: a y media, la aguja de las
horas tiene que estar entre el seis y el siete, no clavada en el seis. Es la
diferencia entre un reloj y un dibujo de un reloj.
"""

from __future__ import annotations

import math
from datetime import time

import flet as ft
import flet.canvas as cv

from .estilo import Paleta

LADO = 34
"""Lo que mide el reloj de lado a lado. Pequeño a propósito: acompaña a la hora
escrita, no compite con ella."""

MARGEN = 1.5
"""Para que el trazo del borde no se coma en el filo del lienzo."""

GROSOR_ESFERA = 1.4
GROSOR_HORA = 2.4
GROSOR_MINUTO = 1.8
GROSOR_SEGUNDO = 1.0

# Lo que mide cada aguja, en fracción del radio. Las de siempre: la de las horas
# corta y gorda, la de los minutos larga y fina, y el segundero un pelo más
# largo todavía para que se le siga con la vista.
LARGO_HORA = 0.52
LARGO_MINUTO = 0.76
LARGO_SEGUNDO = 0.84


def dibujar(paleta: Paleta, hora: time, *, con_segundero: bool = True) -> ft.Control:
    """El reloj con las agujas puestas a esa hora."""
    radio = LADO / 2 - MARGEN
    centro = LADO / 2

    formas: list[cv.Shape] = [
        cv.Circle(
            centro,
            centro,
            radio,
            paint=ft.Paint(
                style=ft.PaintingStyle.STROKE,
                stroke_width=GROSOR_ESFERA,
                color=paleta.borde_fuerte,
            ),
        )
    ]

    # LOS MINUTOS CUENTAN PARA LA AGUJA DE LAS HORAS, y los segundos para la de
    # los minutos. Sin esto, a las 12:59 la aguja pequeña seguiría clavada en el
    # doce y el reloj marcaría una hora que no es.
    vuelta_hora = ((hora.hour % 12) + hora.minute / 60) / 12
    vuelta_minuto = (hora.minute + hora.second / 60) / 60

    formas.append(
        _aguja(centro, radio, vuelta_hora, LARGO_HORA, GROSOR_HORA, paleta.ink)
    )
    formas.append(
        _aguja(
            centro, radio, vuelta_minuto, LARGO_MINUTO, GROSOR_MINUTO, paleta.ink_soft
        )
    )

    if con_segundero:
        # El segundero en el color del acento: es lo único de la pantalla que se
        # mueve solo, y así se ve que se mueve sin tener que buscarlo.
        formas.append(
            _aguja(
                centro,
                radio,
                hora.second / 60,
                LARGO_SEGUNDO,
                GROSOR_SEGUNDO,
                paleta.acento,
            )
        )

    # El tornillito del medio, que es lo que hace que las tres agujas parezcan
    # una pieza y no tres rayas que se cruzan.
    formas.append(
        cv.Circle(centro, centro, 1.6, paint=ft.Paint(color=paleta.ink))
    )

    return cv.Canvas(formas, width=LADO, height=LADO)


def _aguja(
    centro: float, radio: float, vuelta: float, largo: float, grosor: float, color: str
) -> cv.Line:
    """Una aguja, desde el centro hacia donde toque.

    `vuelta` va de 0 a 1 dando la vuelta entera al reloj.

    EL MENOS UN CUARTO DE VUELTA es lo que pone el cero ARRIBA. En matemáticas el
    ángulo cero apunta a la derecha —a las tres del reloj—, así que sin esta
    resta el mediodía se dibujaría donde va el cuarto de hora.
    """
    angulo = (vuelta - 0.25) * 2 * math.pi
    punta = radio * largo
    return cv.Line(
        centro,
        centro,
        centro + punta * math.cos(angulo),
        centro + punta * math.sin(angulo),
        paint=ft.Paint(
            stroke_width=grosor,
            color=color,
            stroke_cap=ft.StrokeCap.ROUND,
        ),
    )


def texto_12h(hora: time) -> tuple[str, str]:
    """La hora en doce horas, partida en el número y el AM/PM.

    SE DEVUELVE PARTIDA para poder pintar cada parte de un tamaño: el número
    grande y el "AM"/"PM" pequeño al lado, que si no compite con la hora y
    parece que importa lo mismo.

    NO SE USA %I DE strftime porque en Windows rellena con un cero delante —"01:05
    PM"— y en una hora eso se lee peor. Aquí se calcula a mano: "1:05 PM".
    """
    en_doce = hora.hour % 12 or 12
    return f"{en_doce}:{hora.minute:02d}", "AM" if hora.hour < 12 else "PM"


def texto_24h(hora: time) -> str:
    return f"{hora.hour:02d}:{hora.minute:02d}"
