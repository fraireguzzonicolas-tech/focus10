"""La agenda del día en el Dashboard: el horario, lo de estudiar y las cosas a hacer.

ESTABA DENTRO DE dashboard.py, que pasaba de las mil trescientas líneas. Se
separó en la auditoría del 13 nov 2026. Es parte de PantallaDashboard (que
hereda esta clase): usa lo que ella lee en refrescar (self.horario_semanal,
self.estudio, self.tareas, self.hoy) y vuelve a llamar a refrescar al cambiar algo.
"""

from __future__ import annotations

from datetime import datetime

import flet as ft

from ..datos import repositorio_tareas
from ..datos.bd import conectado
from ..dominio.educacion import (
    de_la_semana as estudio_de_la_semana,
    lo_de_hoy as estudio_de_hoy,
    texto_de_minutos,
)
from ..dominio.semana import texto_hora
from ..dominio.tarea import Tarea, ordenar as ordenar_tareas
from . import componentes, dialogo_tarea, educacion_calendario, estilo


class TarjetasDeHoy:
    """El horario de hoy, la educación y las cosas a hacer."""

    def _tarjeta_horario(self) -> ft.Control:
        """Lo que tienes hoy, solo las horas con algo.

        SOLO LAS QUE TIENEN ALGO, y esto es una CORRECCIÓN. Antes salía la
        columna entera —las diecisiete horas de la franja, la mayoría con un
        guion— porque así lo había pedido el usuario para no esconder los
        huecos. Al verlo funcionando cambió de idea: "que se vea más chico, eso
        no tiene que ocupar todo, solo que se vean las tareas".

        Y tiene razón: el Dashboard es el resumen del día, no el horario. Para
        ver los huecos ya está la sección Horario, que enseña la rejilla entera;
        aquí catorce líneas de guiones empujaban hacia abajo todo lo demás y no
        contaban nada.

        CUENTAN TAMBIÉN LAS HORAS SOLO PINTADAS: una hora marcada de verde sin
        nada escrito también es algo que tienes puesto, y saltársela sería
        contradecir lo que se ve en la otra pantalla.

        LA HORA ACTUAL VA MARCADA cuando tiene algo: es lo que convierte una
        lista en un "vas por aquí".
        """
        dia = self.hoy.weekday()
        con_algo = self.horario_semanal.con_algo_de(dia)

        cuerpo: list[ft.Control] = [
            componentes.cabecera_tarjeta(self.paleta, "Horario de hoy")
        ]

        if not con_algo:
            # NO SE INVENTA NADA para rellenar el hueco: se dice que está vacío
            # y dónde se escribe. Es la norma del usuario y aquí aplica entera.
            cuerpo.append(
                componentes.aviso_vacio(
                    self.paleta,
                    "Hoy no tienes nada escrito en el horario. Se escribe en la "
                    "sección Horario, casilla por casilla.",
                )
            )
            return componentes.tarjeta(self.paleta, ft.Column(cuerpo, spacing=12))

        ahora = datetime.now().hour
        for casilla in con_algo:
            cuerpo.append(
                self._fila_de_horario(
                    casilla.hora,
                    casilla.texto,
                    casilla.color,
                    es_ahora=casilla.hora == ahora,
                )
            )
        return componentes.tarjeta(self.paleta, ft.Column(cuerpo, spacing=2))

    def _fila_de_horario(
        self, hora: int, texto: str, pintada: str | None, *, es_ahora: bool
    ) -> ft.Control:
        """Una hora del día, con su color si lo tiene.

        LA HORA ACTUAL MANDA SOBRE EL COLOR: si son las diez y las diez están
        pintadas de verde, gana el marcado de "vas por aquí". Saber dónde estás
        es más urgente que saber de qué color lo pintaste, y dos marcados a la
        vez no se distinguirían de ninguno.
        """
        if es_ahora:
            fondo = self.paleta.acento
            tinta = self.paleta.acento_ink
        elif pintada is not None:
            fondo = estilo.pastel(pintada, self.paleta)
            tinta = estilo.tinta_sobre_pastel(self.paleta)
        else:
            fondo = None
            tinta = self.paleta.ink if texto else self.paleta.muted

        return ft.Container(
            content=ft.Row(
                [
                    ft.Container(
                        content=ft.Text(
                            texto_hora(hora), size=estilo.TEXTO_APOYO, color=tinta
                        ),
                        width=48,
                    ),
                    # Sin guion de relleno: aqui solo salen horas con algo,
                    # asi que siempre hay texto o, como poco, color.
                    ft.Text(texto, size=13, color=tinta, expand=True),
                ],
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor=fondo,
            border_radius=6,
            padding=ft.Padding.symmetric(horizontal=8, vertical=4),
        )

    def _tarjeta_educacion(self) -> ft.Control:
        """Qué tienes que estudiar hoy, y lo importante de esta semana.

        ES UN RESUMEN Y NO OTRA PANTALLA DE EDUCACION, como pidio el usuario:
        salen como mucho tres cosas de hoy y dos de la semana, y para lo demas
        se entra en su seccion. Una tarjeta con quince lineas deja de ser un
        resumen y ya nadie la lee.

        LO QUE SALE ES LO QUE TU APUNTASTE: sesiones planificadas, examenes,
        entregas. Si no apuntaste nada, lo dice; no se inventa un plan de
        estudio.
        """
        de_hoy = estudio_de_hoy(self.estudio, self.hoy)[:3]
        semana = estudio_de_la_semana(self.estudio, self.hoy)[:2]

        dentro: list[ft.Control] = [
            componentes.cabecera_tarjeta(self.paleta, "Educación", None)
        ]
        if not self.materias_estudio:
            dentro.append(
                ft.Row(
                    [
                        ft.Icon(
                            ft.Icons.SCHOOL_OUTLINED, size=20, color=self.paleta.muted
                        ),
                        ft.Text(
                            "Sin materias todavía. Se crean en Educación.",
                            size=12,
                            color=self.paleta.muted,
                            expand=True,
                        ),
                    ],
                    spacing=10,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                )
            )
            return componentes.tarjeta(self.paleta, ft.Column(dentro, spacing=12))

        if de_hoy:
            dentro.append(
                ft.Text("Hoy deberías estudiar", size=11, color=self.paleta.muted)
            )
            dentro += [self._fila_estudio(uno) for uno in de_hoy]
        else:
            dentro.append(
                ft.Text(
                    "Hoy no tienes nada apuntado.", size=12, color=self.paleta.muted
                )
            )

        if semana:
            dentro.append(componentes.separador(self.paleta))
            dentro.append(
                ft.Text("Esta semana", size=11, color=self.paleta.muted)
            )
            dentro += [self._fila_estudio(uno, con_dia=True) for uno in semana]

        return componentes.tarjeta(self.paleta, ft.Column(dentro, spacing=8))

    def _fila_estudio(self, evento, con_dia: bool = False) -> ft.Control:
        """Una linea del resumen: de que es, como se llama y cuando."""
        color = educacion_calendario.color_de(self.paleta, evento.tipo)
        apoyo: list[str] = []
        if con_dia:
            apoyo.append(evento.fecha.strftime("%d/%m"))
        nombre = next(
            (
                una.nombre
                for una in self.materias_estudio
                if una.id == evento.materia_id
            ),
            "",
        )
        if nombre:
            apoyo.append(nombre)
        if evento.minutos:
            apoyo.append(texto_de_minutos(evento.minutos))

        return ft.Row(
            [
                ft.Icon(
                    educacion_calendario.icono_de(evento.tipo), size=15, color=color
                ),
                ft.Column(
                    [
                        ft.Text(
                            evento.titulo or nombre or "Sesión de estudio",
                            size=12,
                            color=self.paleta.ink,
                        ),
                        ft.Text(
                            " · ".join(apoyo), size=11, color=self.paleta.muted
                        ),
                    ],
                    spacing=0,
                    tight=True,
                    expand=True,
                ),
            ],
            spacing=8,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _tarjeta_tareas(self) -> ft.Control:
        ordenadas = ordenar_tareas(self.tareas, self.hoy)
        pendientes = [una for una in ordenadas if not una.hecha]

        if ordenadas:
            cuerpo: ft.Control = ft.Column(
                [self._fila_tarea(una) for una in ordenadas], spacing=0
            )
        else:
            cuerpo = componentes.aviso_vacio(
                self.paleta,
                "Nada apuntado para hoy. Con el botón de arriba apuntas algo.",
            )

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    ft.Row(
                        [
                            ft.Container(
                                content=componentes.cabecera_tarjeta(
                                    self.paleta,
                                    "Cosas a hacer",
                                    f"{len(pendientes)} pendientes"
                                    if pendientes
                                    else "todo hecho",
                                ),
                                expand=True,
                            ),
                            componentes.boton(
                                self.paleta,
                                "Apuntar",
                                icono=ft.Icons.ADD,
                                principal=True,
                                al_pulsar=lambda _: dialogo_tarea.abrir(
                                    self.pagina, self.paleta, self.hoy, self.refrescar
                                ),
                            ),
                        ],
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    cuerpo,
                ],
                spacing=14,
            ),
        )

    def _fila_tarea(self, tarea: Tarea) -> ft.Control:
        atraso = tarea.texto_de_atraso(self.hoy)

        # La casilla vacía va SIN icono dentro, en vez de con uno transparente:
        # un color inventado a mano aquí es justo lo que prohíbe la regla de que
        # los colores viven solo en estilo.py, y el test de arquitectura lo cazó.
        izquierda = ft.Container(
            content=ft.Icon(ft.Icons.CHECK_ROUNDED, size=15, color=estilo.BLANCO)
            if tarea.hecha
            else None,
            width=24,
            height=24,
            bgcolor=self.paleta.positivo if tarea.hecha else None,
            border=None
            if tarea.hecha
            else ft.Border.all(
                2, self.paleta.aviso if atraso else self.paleta.borde_fuerte
            ),
            border_radius=7,
            alignment=ft.Alignment.CENTER,
            on_click=lambda _, t=tarea: self._alternar(t),
            tooltip="Deshacer" if tarea.hecha else "Dar por hecha",
            ink=True,
        )

        textos: list[ft.Control] = [
            ft.Text(
                tarea.titulo,
                size=13,
                color=self.paleta.muted if tarea.hecha else self.paleta.ink,
                # Tachado al hacerla: se ve de un vistazo qué queda sin leer nada.
                style=ft.TextStyle(
                    decoration=ft.TextDecoration.LINE_THROUGH if tarea.hecha else None
                ),
            )
        ]
        pie: list[str] = []
        if atraso:
            pie.append(atraso)
        if tarea.nota:
            pie.append(tarea.nota)
        if pie:
            textos.append(
                ft.Text(
                    " · ".join(pie),
                    size=11,
                    color=self.paleta.aviso if atraso else self.paleta.muted,
                )
            )

        return ft.Container(
            content=ft.Row(
                [
                    izquierda,
                    ft.Column(textos, spacing=1, tight=True, expand=True),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.MORE_HORIZ,
                        ayuda="Corregir o borrar",
                        al_pulsar=lambda _, t=tarea: dialogo_tarea.abrir(
                            self.pagina, self.paleta, self.hoy, self.refrescar, t
                        ),
                    ),
                ],
                spacing=12,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(vertical=8),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
        )

    def _alternar(self, tarea: Tarea) -> None:
        """Dar por hecha o deshacer.

        Se marca con la jornada de HOY, no con la de la tarea: si una tarea del
        jueves se hace el viernes, lo que pasó es que se hizo el viernes. Es lo
        que mantiene honesto el historial del jueves.
        """
        with conectado() as conexion:
            repositorio_tareas.marcar(
                conexion, tarea.id, None if tarea.hecha else self.hoy
            )
        self.refrescar()
