"""La ventanita para anotar cuánto llevas ahorrado o invertido.

ENSEÑA LO QUE HABÍA ANTES a propósito: al actualizar una cifra, lo primero que
uno quiere saber es de dónde parte. Sin ese dato hay que cerrar, mirar y volver
a abrir.

Y lleva un "Borrar esa" al lado, porque desde que la pantalla no enseña el
historial este es el ÚNICO sitio desde el que se puede deshacer una anotación
mal tecleada.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime

import flet as ft

from ..datos import repositorio_saldos
from ..datos.ajustes import leer_horario
from ..datos.bd import conectado
from ..dominio import dinero
from ..dominio.moneda import PRINCIPAL_POR_OMISION
from ..dominio.saldo import ETIQUETAS, LARGO_MAXIMO_NOTA, Clase, Saldo
from . import componentes
from .estilo import Paleta

AVISO_MONEDA_EXTRANJERA = (
    "El tipo de cambio todavía no se consulta (esa parte no está hecha), así que "
    "esta cifra quedará marcada como pendiente y no entrará en el total del "
    "patrimonio hasta que se resuelva. El importe se guarda intacto."
)


def abrir(
    pagina: ft.Page,
    clase: Clase,
    paleta: Paleta,
    al_guardar: Callable[[], None],
) -> None:
    """Abre la ventanita. `al_guardar` se llama tras guardar, para refrescar."""
    with conectado() as conexion:
        anterior = repositorio_saldos.ultimo(conexion, clase)

    pagina.show_dialog(
        _DialogoSaldo(pagina, clase, paleta, anterior, al_guardar).control
    )


class _DialogoSaldo:
    def __init__(
        self,
        pagina: ft.Page,
        clase: Clase,
        paleta: Paleta,
        anterior: Saldo | None,
        al_guardar: Callable[[], None],
    ) -> None:
        self.pagina = pagina
        self.clase = clase
        self.paleta = paleta
        self.anterior = anterior
        self.al_guardar = al_guardar

        self.dinero = componentes.CampoDinero(
            paleta,
            f"{ETIQUETAS[clase]} ahora",
            moneda=PRINCIPAL_POR_OMISION,
            pista="3.200",
            al_enviar=lambda _: self._guardar(),
            al_cambiar_moneda=lambda _: self._revisar_moneda(),
        )
        self.nota = componentes.campo_texto(
            paleta,
            "Nota (opcional)",
            pista="vendí la moto",
            ancho=340,
            largo_maximo=LARGO_MAXIMO_NOTA,
        )
        self.aviso = ft.Container(
            content=componentes.aviso(paleta, [AVISO_MONEDA_EXTRANJERA]),
            visible=False,
            width=350,
        )

        self.control = componentes.dialogo(
            paleta,
            "Actualizar ahorro" if clase is Clase.AHORRO else "Actualizar inversión",
            ft.Column(
                [
                    self._de_donde_parte(),
                    self.dinero.control,
                    self.nota,
                    self.aviso,
                ],
                spacing=12,
                tight=True,
                width=360,
            ),
            pagina=pagina,
            al_aceptar=lambda _: self._guardar(),
        )

    # ----------------------------------------------------------------------

    def _de_donde_parte(self) -> ft.Control:
        """La cifra anterior, o el aviso de que no hay ninguna."""
        if self.anterior is None:
            return ft.Text(
                "Es la primera vez que lo anotas.", size=12, color=self.paleta.muted
            )

        cuando = self.anterior.jornada.strftime("%d/%m/%Y")
        return ft.Row(
            [
                ft.Text(
                    f"Última anotación: {self.anterior.texto_importe()} el {cuando}",
                    size=12,
                    color=self.paleta.muted,
                ),
                ft.Container(expand=True),
                ft.TextButton("Borrar esa", on_click=lambda _: self._borrar_anterior()),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _borrar_anterior(self) -> None:
        """Borra la última anotación: la cifra vuelve a ser la de antes."""
        if self.anterior is None:
            return
        with conectado() as conexion:
            repositorio_saldos.borrar(conexion, self.anterior.id)
        self.pagina.pop_dialog()
        componentes.avisar(self.pagina, "Anotación borrada.")
        self.al_guardar()

    def _revisar_moneda(self) -> None:
        self.aviso.visible = self.dinero.moneda_elegida() != PRINCIPAL_POR_OMISION
        self.dinero.limpiar_error()
        self.pagina.update()

    def _guardar(self) -> None:
        moneda = self.dinero.moneda_elegida()
        unidades = self.dinero.unidades()

        if unidades is None:
            self.dinero.marcar_error("No entiendo ese importe")
            self.pagina.update()
            return
        if unidades < 0:
            # El cero SÍ vale aquí: tener cero ahorrado es un dato real.
            self.dinero.marcar_error("No puede ser negativo")
            self.pagina.update()
            return

        with conectado() as conexion:
            horario = leer_horario(conexion)
            saldo = Saldo.nuevo(
                clase=self.clase,
                importe=unidades,
                momento=datetime.now(),
                horario=horario,
                moneda=moneda,
                nota=self.nota.value or "",
                # Sin tasa a propósito: el tipo de cambio todavía no se consulta.
                tasa=None,
            )
            repositorio_saldos.anotar(conexion, saldo)

        self.pagina.pop_dialog()
        componentes.avisar(
            self.pagina,
            f"{ETIQUETAS[self.clase]}: {dinero.formatear(unidades, moneda)}"
            + (" (pendiente de convertir)" if saldo.pendiente_de_cambio else ""),
        )
        self.al_guardar()
