"""La rejilla del mes de Educación: qué días tienes algo.

POR QUÉ UN CALENDARIO PROPIO Y NO UNO GENERAL: lo pidió el usuario. Cada área
lleva lo suyo —el gimnasio tiene el suyo, la comida el suyo— y un calendario
que lo mezclara todo obligaría a filtrar para ver los estudios, que es trabajo
que nadie quiere hacer para mirar qué toca hoy.

CADA DÍA DICE CUÁNTO Y DE QUÉ, sin abrirlo: el punto de color es lo más urgente
que hay ese día (un examen manda sobre una sesión), y el número dice cuántas
cosas hay. Un calendario donde todos los días se ven igual no sirve para nada.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import date

import flet as ft

from ..dominio.educacion import Evento, TipoEvento, ordenar
from . import componentes, estilo
from .estilo import Paleta

LADO = 44
"""Lo que mide cada cuadradito. Siete más los huecos caben en un móvil."""

LETRAS = ("L", "M", "X", "J", "V", "S", "D")


def color_de(paleta: Paleta, tipo: TipoEvento) -> str:
    """El color de un tipo de evento. El mismo en la rejilla y en las listas."""
    return {
        TipoEvento.EXAMEN: paleta.negativo,
        TipoEvento.TRABAJO: paleta.aviso,
        TipoEvento.TAREA: paleta.acento,
        TipoEvento.IMPORTANTE: paleta.aviso,
        TipoEvento.SESION: paleta.positivo,
        TipoEvento.OTRO: paleta.muted,
    }[tipo]


def icono_de(tipo: TipoEvento) -> str:
    return {
        TipoEvento.EXAMEN: ft.Icons.WARNING_AMBER_OUTLINED,
        TipoEvento.TRABAJO: ft.Icons.ASSIGNMENT_OUTLINED,
        TipoEvento.TAREA: ft.Icons.CHECK_BOX_OUTLINED,
        TipoEvento.IMPORTANTE: ft.Icons.STAR_OUTLINE,
        TipoEvento.SESION: ft.Icons.MENU_BOOK_OUTLINED,
        TipoEvento.OTRO: ft.Icons.EVENT_OUTLINED,
    }[tipo]


def texto_de(tipo: TipoEvento) -> str:
    return {
        TipoEvento.EXAMEN: "Examen",
        TipoEvento.TRABAJO: "Trabajo",
        TipoEvento.TAREA: "Tarea",
        TipoEvento.IMPORTANTE: "Importante",
        TipoEvento.SESION: "Sesión de estudio",
        TipoEvento.OTRO: "Otro",
    }[tipo]


def rejilla(
    paleta: Paleta,
    dias: list[date],
    eventos: list[Evento],
    hoy: date,
    *,
    elegido: date,
    al_tocar: Callable[[date], None],
) -> ft.Control:
    """El mes entero, de lunes a domingo, con lo que hay cada día."""
    if not dias:
        return componentes.aviso_vacio(paleta, "No hay días que enseñar.")

    por_dia: dict[date, list[Evento]] = {}
    for uno in eventos:
        por_dia.setdefault(uno.fecha, []).append(uno)

    filas: list[ft.Control] = [
        ft.Row(
            [
                ft.Container(
                    content=ft.Text(
                        letra,
                        size=estilo.ROTULO,
                        color=paleta.muted,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    width=LADO,
                    alignment=ft.Alignment.CENTER,
                )
                for letra in LETRAS
            ],
            spacing=4,
        )
    ]

    fila: list[ft.Control] = [
        ft.Container(width=LADO, height=LADO) for _ in range(dias[0].weekday())
    ]
    for dia in dias:
        fila.append(
            _cuadradito(paleta, dia, por_dia.get(dia, []), hoy, elegido, al_tocar)
        )
        if len(fila) == 7:
            filas.append(ft.Row(fila, spacing=4))
            fila = []
    if fila:
        filas.append(ft.Row(fila, spacing=4))

    return ft.Column(filas, spacing=4, tight=True)


def _cuadradito(
    paleta: Paleta,
    dia: date,
    eventos: list[Evento],
    hoy: date,
    elegido: date,
    al_tocar: Callable[[date], None],
) -> ft.Control:
    """Un día: su número, y debajo un punto por cada cosa que tenga.

    TODOS LOS DÍAS SE PUEDEN TOCAR, también los futuros, y aquí sí tiene
    sentido —al revés que en el calendario de la comida—: en el futuro es
    justo donde se planifica.
    """
    pendientes = [uno for uno in eventos if not uno.hecho]
    orden = ordenar(pendientes or eventos)
    puntos = [
        ft.Container(
            width=5,
            height=5,
            bgcolor=color_de(paleta, uno.tipo),
            border_radius=3,
            # Lo hecho se ve más apagado: sigue ahí, pero ya no reclama nada.
            opacity=1.0 if not uno.hecho else 0.45,
        )
        for uno in orden[:3]
    ]

    es_hoy = dia == hoy
    return ft.Container(
        content=ft.Column(
            [
                ft.Text(
                    str(dia.day),
                    size=estilo.TEXTO_APOYO,
                    color=paleta.ink if eventos or es_hoy else paleta.muted,
                    weight=ft.FontWeight.W_600 if es_hoy else None,
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Row(puntos, spacing=2, alignment=ft.MainAxisAlignment.CENTER),
            ],
            spacing=2,
            tight=True,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
        ),
        width=LADO,
        height=LADO,
        alignment=ft.Alignment.CENTER,
        bgcolor=paleta.surface_2 if dia == elegido else None,
        # HOY SE MARCA CON EL BORDE DEL ACENTO: sin esto, en un mes lleno hay
        # que contar los días para saber por dónde vas.
        border=ft.Border.all(1, paleta.acento if es_hoy else paleta.borde),
        border_radius=estilo.RADIO_CAMPO,
        tooltip=_ayuda(dia, eventos),
        on_click=lambda _, d=dia: al_tocar(d),
        ink=True,
    )


def _ayuda(dia: date, eventos: list[Evento]) -> str:
    if not eventos:
        return f"{dia.day}: nada apuntado"
    cuantos = len(eventos)
    return f"{dia.day}: {cuantos} cosa" + ("s" if cuantos != 1 else "")


def leyenda(paleta: Paleta) -> ft.Control:
    """Qué significa cada color. Sin esto, los puntos son adorno."""
    return ft.Row(
        [
            ft.Row(
                [
                    ft.Container(
                        width=5, height=5, bgcolor=color_de(paleta, tipo), border_radius=3
                    ),
                    ft.Text(texto_de(tipo), size=11, color=paleta.muted),
                ],
                spacing=4,
                tight=True,
            )
            for tipo in (
                TipoEvento.SESION,
                TipoEvento.TAREA,
                TipoEvento.EXAMEN,
                TipoEvento.TRABAJO,
            )
        ],
        spacing=12,
        wrap=True,
        run_spacing=4,
    )
