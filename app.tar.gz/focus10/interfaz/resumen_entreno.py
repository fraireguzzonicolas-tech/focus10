"""El resumen de un entreno: lo que hiciste, con el cuerpo de lo trabajado.

LO PIDIÓ EL USUARIO enseñando el resumen de otra aplicación: «al final del
entrenamiento se tiene que mostrar algo como esto... el cuerpo aparece así y
pecho y tríceps tiene que aparecer con un color, lo que entrené, los pesos que
levanté».

SALE AL TERMINAR Y TAMBIÉN DESDE EL CALENDARIO. Un resumen que solo se ve una
vez es un resumen que se olvida; tocando un día del mes vuelve a salir el suyo.

AQUÍ NO SE TOCA NINGUNA SERIE. Los pesos y las repeticiones solo se cambian
entrenando, así que abrir el entreno del martes pasado no puede estropearlo.

LO ÚNICO QUE SÍ SE CORRIGE ES LA DURACIÓN, y lo pidió el usuario por un motivo
bueno: un entreno que se queda abierto cuenta el reloj de pared. Si lo empiezas a
las ocho y lo cierras por la tarde, salen once horas. Eso es literalmente lo que
pasó —la aplicación no midió tu entreno, midió desde que pulsaste empezar— así
que en vez de inventar un tope, se guarda lo que hubo y se te deja escribir lo
que entrenaste de verdad: «si me olvidé, poder editar y poner las horas que sí
entrené».

LAS CALORÍAS SON UNA ESTIMACIÓN y llevan el «unas» delante, no en letra pequeña
debajo. Sin tu peso corporal no salen: ver dominio/esfuerzo.py.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import date

import flet as ft

from ..datos import ajustes, repositorio_ejercicios, repositorio_gimnasio
from ..datos.bd import conectado
from ..dominio.descanso import parsear_duracion
from ..dominio.esfuerzo import (
    ROTULO_ESTIMADO,
    calorias_estimadas,
    texto_calorias,
)
from ..dominio.semana import texto_fecha
from ..dominio.sesion import Sesion, texto_volumen
from . import componentes, dibujo_musculo, estilo
from .entreno import texto_reloj
from .estilo import Paleta


class PantallaResumen:
    """Lo que se hizo un día, a pantalla completa.

    NO HEREDA DE `Pantalla`, igual que la de entrenar: sustituye la ventana
    entera en vez de montarse dentro de su armazón.
    """

    def __init__(
        self,
        pagina: ft.Page,
        paleta: Paleta,
        dia: date,
        al_salir,
        al_repintar=None,
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.dia = dia
        self.al_salir = al_salir
        # Corregir la duración cambia lo que se ve, y repintar esta pantalla lo
        # hace quien la montó: es ella la que sustituye la ventana entera.
        self.al_repintar = al_repintar or (lambda: None)

    # ------------------------------------------------------------------

    def control(self, paleta: Paleta) -> ft.Control:
        self.paleta = paleta

        with conectado() as conexion:
            sesion = repositorio_gimnasio.sesion_de(conexion, self.dia)
            fichas = repositorio_ejercicios.listar(conexion)
            peso = ajustes.leer_peso_corporal(conexion)

        if sesion is None:
            return self._nada(paleta)

        return ft.Container(
            content=ft.Column(
                [
                    self._cabecera(sesion, peso),
                    self._cuerpos(sesion, fichas),
                    *self._ejercicios(sesion),
                    componentes.boton(
                        self.paleta,
                        "Cerrar",
                        icono=ft.Icons.CLOSE,
                        principal=True,
                        al_pulsar=lambda _: self.al_salir(),
                    ),
                ],
                spacing=estilo.DENSIDAD,
                scroll=ft.ScrollMode.AUTO,
                expand=True,
            ),
            padding=estilo.RELLENO_TARJETA,
            expand=True,
            bgcolor=paleta.canvas,
        )

    # ------------------------------------------------------------------

    def _cabecera(self, sesion: Sesion, peso: int | None) -> ft.Control:
        """El nombre, la fecha y las cifras del día."""
        duracion = sesion.segundos
        calorias = calorias_estimadas(duracion, peso)

        cifras: list[ft.Control] = [
            componentes.cifra(self.paleta, "Volumen", texto_volumen(sesion.volumen)),
            componentes.cifra(self.paleta, "Series", str(sesion.series_hechas)),
            componentes.cifra(self.paleta, "Repes", str(_repeticiones(sesion))),
            componentes.cifra(
                self.paleta, "Ejercicios", str(len(sesion.ejercicios))
            ),
        ]
        # LA DURACIÓN SOLO SI SE SABE. Los entrenos de antes del cronómetro no
        # la tienen, y "0:00:00" diría que duraron nada.
        # LA DURACIÓN SIEMPRE, aunque no se sepa: con el lápiz al lado para
        # ponerla. Un entreno de antes del cronómetro, o uno que se quedó
        # abierto toda la tarde, se arreglan aquí.
        cifras.insert(
            1,
            componentes.cifra(
                self.paleta,
                "Duración",
                texto_reloj(duracion) if duracion else "—",
                accion=componentes.boton_icono(
                    self.paleta,
                    ft.Icons.EDIT_OUTLINED,
                    ayuda="Corregir cuánto duró",
                    al_pulsar=lambda _: self._pedir_duracion(duracion),
                ),
            ),
        )
        if calorias is not None:
            cifras.append(
                componentes.cifra(
                    self.paleta,
                    ROTULO_ESTIMADO,
                    texto_calorias(calorias),
                    ayuda=(
                        "Estimado a partir de tu peso y del rato que duró, con "
                        "la cuenta habitual del ejercicio. No mide lo que gastó "
                        "tu cuerpo: sirve para comparar tus entrenos entre sí."
                    ),
                )
            )

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    ft.Text(
                        texto_fecha(self.dia),
                        size=estilo.TEXTO_APOYO,
                        color=self.paleta.muted,
                    ),
                    ft.Text(
                        sesion.titulo() or "Entreno",
                        size=estilo.TITULAR_GRANDE,
                        color=self.paleta.ink,
                        font_family=self.paleta.titular,
                        max_lines=2,
                        overflow=ft.TextOverflow.ELLIPSIS,
                    ),
                    ft.Container(height=10),
                    ft.Row(cifras, spacing=28, wrap=True),
                    *self._nota_de_las_calorias(calorias, peso),
                ],
                spacing=2,
                tight=True,
            ),
        )

    def _nota_de_las_calorias(self, calorias, peso) -> list[ft.Control]:
        """Por qué no hay calorías, cuando no las hay.

        UN HUECO SIN EXPLICAR SE LEE COMO UN FALLO. Decir que falta tu peso, y
        dónde ponerlo, convierte un vacío en una cosa que puedes arreglar.
        """
        if calorias is not None or peso is not None:
            return []
        return [
            ft.Container(height=8),
            ft.Text(
                "Para estimar el gasto hace falta tu peso. Se pone en "
                "Configuración, y es opcional.",
                size=estilo.TEXTO_APOYO,
                color=self.paleta.muted,
            ),
        ]

    def _cuerpos(self, sesion: Sesion, fichas) -> ft.Control:
        """Las figuras con lo trabajado encendido."""
        grupos = _grupos_de(sesion, fichas)
        if not grupos:
            return ft.Container(height=0)

        figuras = [
            dibujo_musculo.del_entreno(self.paleta, grupos, de_espaldas=detras)
            for detras in (False, True)
            if dibujo_musculo.hay_algo_que_pintar(grupos, de_espaldas=detras)
        ]
        if not figuras:
            return ft.Container(height=0)

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    ft.Row(figuras, spacing=24, wrap=True),
                    ft.Text(
                        " · ".join(uno.value.capitalize() for uno in grupos),
                        size=estilo.TEXTO_APOYO,
                        color=self.paleta.muted,
                    ),
                ],
                spacing=12,
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )

    def _ejercicios(self, sesion: Sesion) -> list[ft.Control]:
        """Un renglón por ejercicio con lo que se movió de verdad.

        SOLO LAS SERIES HECHAS. Una serie escrita y sin marcar es una intención,
        no un peso levantado, y meterla aquí inflaría el resumen con lo que no
        hiciste.
        """
        filas = []
        for uno in sesion.ejercicios:
            hechas = [una for una in uno.series if una.hecha]
            if not hechas:
                continue
            filas.append(
                ft.Row(
                    [
                        ft.Text(
                            uno.nombre,
                            size=estilo.TEXTO,
                            color=self.paleta.ink,
                            expand=True,
                        ),
                        ft.Text(
                            _resumen_de_series(hechas),
                            size=estilo.TEXTO,
                            color=self.paleta.ink_soft,
                        ),
                    ],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                )
            )

        if not filas:
            return [
                componentes.aviso_vacio(
                    self.paleta, "Este día no llegaste a marcar ninguna serie."
                )
            ]
        return [
            componentes.tarjeta(
                self.paleta,
                ft.Column(
                    [
                        componentes.cabecera_tarjeta(self.paleta, "Lo que hiciste"),
                        *filas,
                    ],
                    spacing=10,
                ),
            )
        ]

    def _nada(self, paleta: Paleta) -> ft.Control:
        return ft.Container(
            content=ft.Column(
                [
                    componentes.aviso_vacio(paleta, "Ese día no hay ningún entreno."),
                    componentes.boton(
                        paleta,
                        "Volver",
                        icono=ft.Icons.ARROW_BACK,
                        al_pulsar=lambda _: self.al_salir(),
                    ),
                ],
                spacing=14,
                tight=True,
            ),
            padding=estilo.RELLENO_TARJETA,
            alignment=ft.Alignment.CENTER,
            expand=True,
            bgcolor=paleta.canvas,
        )


    # ------------------------------------------------------------------

    def _guardar_duracion(self, escrito: str) -> bool:
        """Lee lo escrito y lo guarda. Devuelve si se pudo.

        SEPARADO DE LA VENTANITA a propósito: así se puede comprobar que un
        «1h15» acaba siendo 4500 segundos en la base sin tener que simular
        pulsaciones, que es lo que de verdad puede romperse.
        """
        segundos = parsear_duracion(escrito)
        if segundos is None:
            componentes.avisar(
                self.pagina, "No entiendo eso. Prueba con «1h15» o «75min»."
            )
            return False
        with conectado() as conexion:
            sesion = repositorio_gimnasio.sesion_de(conexion, self.dia)
            if sesion is None:
                return False
            repositorio_gimnasio.guardar_sesion(
                conexion, replace(sesion, segundos=segundos)
            )
        componentes.avisar(self.pagina, "Duración corregida.")
        return True

    def _pedir_duracion(self, ahora: int) -> None:
        """La ventanita de corregir cuánto duró.

        SE ESCRIBE COMO EN EL RESTO DE LA APLICACIÓN —«1h15», «75min»— porque el
        lector de duraciones es el mismo. Dos lectores acabarían aprendiendo
        formatos distintos, y entonces lo que vale en una casilla no vale en la
        de al lado.
        """
        campo = componentes.campo_texto(
            self.paleta,
            "Cuánto duró",
            valor=texto_reloj(ahora) if ahora else "",
            pista="1h15, 75min, 1:15:00",
            ancho=260,
        )

        def guardar(_):
            if self._guardar_duracion(campo.value or ""):
                self.pagina.pop_dialog()
                self.al_repintar()

        self.pagina.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text(
                    "Cuánto duró el entreno",
                    size=15,
                    weight=ft.FontWeight.W_600,
                    color=self.paleta.ink,
                ),
                bgcolor=self.paleta.surface,
                content=ft.Column(
                    [
                        ft.Text(
                            "El reloj cuenta desde que pulsaste «Empezar». Si te "
                            "dejaste el entreno abierto, aquí pones lo que "
                            "entrenaste de verdad.",
                            size=estilo.TEXTO_APOYO,
                            color=self.paleta.muted,
                        ),
                        campo,
                    ],
                    spacing=12,
                    tight=True,
                    width=320,
                ),
                actions=[
                    componentes.boton(
                        self.paleta,
                        "Guardar",
                        principal=True,
                        al_pulsar=guardar,
                    ),
                    ft.TextButton(
                        "Cancelar", on_click=lambda _: self.pagina.pop_dialog()
                    ),
                ],
            )
        )


# ---------------------------------------------------------------------------


def _repeticiones(sesion: Sesion) -> int:
    """Las repeticiones de las series HECHAS, sumadas."""
    return sum(
        una.repeticiones
        for uno in sesion.ejercicios
        for una in uno.series
        if una.hecha
    )


def _grupos_de(sesion: Sesion, fichas) -> list:
    """Los grupos musculares del entreno, sin repetir y en el orden que salieron.

    UN EJERCICIO BORRADO DE LA BIBLIOTECA NO CUENTA para el dibujo. El entreno se
    sigue leyendo entero —guarda el nombre—, pero de un ejercicio sin ficha no se
    sabe qué músculo era, y pintar uno a boleo sería inventarlo.
    """
    por_id = {uno.id: uno for uno in fichas}
    grupos = []
    for uno in sesion.ejercicios:
        ficha = por_id.get(uno.ejercicio_id)
        if ficha is not None and ficha.grupo not in grupos:
            grupos.append(ficha.grupo)
    return grupos


def _resumen_de_series(hechas) -> str:
    """«4 × 10 · 80 kg» cuando todas fueron iguales, y la lista si no.

    SE AGRUPA CUANDO SE PUEDE porque así se lee de un vistazo, que es para lo que
    sirve un resumen. Cuando no todas fueron iguales se enseñan una a una: decir
    "4 × 10" de un entreno donde bajaste el peso en la última sería mentir sobre
    lo que hiciste, que es justo lo que este resumen tiene que contar bien.
    """
    from ..dominio.rutina import texto_peso

    distintas = {(una.peso, una.repeticiones) for una in hechas}
    if len(distintas) == 1:
        peso, repes = distintas.pop()
        cuerpo = f"{len(hechas)} × {repes}"
        return f"{cuerpo} · {texto_peso(peso)}" if peso else cuerpo

    return " · ".join(
        f"{texto_peso(una.peso)}×{una.repeticiones}" if una.peso
        else str(una.repeticiones)
        for una in hechas
    )
