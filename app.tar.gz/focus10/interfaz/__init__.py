"""Interfaz grafica (Flet).

Punto de entrada: app.ejecutar(), o directamente `python -m focus10`.

  app.py               la ventana y las seis pestanas
  finanzas.py          la pantalla de finanzas
  dialogo_movimiento.py la ventanita de apuntar un gasto o un ingreso
  grafico.py           el grafico diario, dibujado a mano
  en_construccion.py   lo que se ensena en las areas que aun no existen

Esta capa puede usar datos/ y dominio/; ninguna de las dos puede usarla a ella.
"""
