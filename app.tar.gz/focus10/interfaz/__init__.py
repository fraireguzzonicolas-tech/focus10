"""Interfaz grafica (Flet).

Punto de entrada: app.ejecutar(), que es lo que llama abrir.py. La ventana y su
barra lateral viven en app.py; cada sección, en su archivo (finanzas.py,
habitos.py…), y los colores y medidas, solo en estilo.py.

Esta capa puede usar datos/ y dominio/; ninguna de las dos puede usarla a ella.
"""
