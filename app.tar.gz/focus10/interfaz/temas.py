"""Los catorce temas de Focus: cada uno, una paleta clara y una oscura.

ANTES VIVÍAN EN estilo.py, y eran más de la mitad del archivo (setecientas
líneas de colores). Se separaron en la auditoría del 13 nov 2026: estilo.py
queda con lo que es igual en todos los temas (las medidas, la forma de una
Paleta, los pasteles del horario) y aquí está lo que cambia de uno a otro.

QUÉ HAY QUE TOCAR PARA UN TEMA NUEVO: sus dos paletas, su línea en ESTILOS y
su carácter para los pasteles del horario (_CARACTER, en estilo.py). Nada más.
"""

from __future__ import annotations

from dataclasses import dataclass

import flet as ft

from .estilo import Paleta


# ---------------------------------------------------------------------------
# Los catorce temas
# ---------------------------------------------------------------------------
#
# DE DONDE SALEN: de cuatro referencias que dio el usuario, mas el que ya tenia.
# Cada uno es una paleta clara, una oscura y una tipografia de titulares. Lo
# demas —las medidas, las esquinas, las sombras— NO cambia entre estilos, y esa
# fue su decision: "colores y tipografia, sin tocar formas". Se agradece al
# mantenerlo, porque significa que un estilo nuevo son dos paletas y una linea.
#
# LAS TRES REGLAS QUE CUMPLEN TODOS, y que hay tests para cada una:
#   1. El texto se lee sobre su fondo. Un estilo bonito e ilegible no vale.
#   2. El claro es claro y el oscuro es oscuro, en todos.
#   3. Ningun color se repite entre la version clara y la oscura del mismo
#      estilo; si se repitiera, esa parte no cambiaria al cambiar de tema.


@dataclass(frozen=True)
class Estilo:
    """Un traje completo: como se ve la aplicacion de arriba abajo."""

    clave: str
    """Lo que se guarda en los ajustes. No cambia nunca."""

    nombre: str
    """Como se llama en la pantalla de Configuracion."""

    descripcion: str
    """Una linea que dice a que suena, para poder elegir sin probarlos todos."""

    clara: Paleta
    oscura: Paleta

    def paleta(self, *, oscuro: bool) -> Paleta:
        return self.oscura if oscuro else self.clara


# -------------------------------------------------- 1. ELEGANTE
# Editorial y silencioso. El único color es la tinta; todo lo demás es aire.
# Fondo: ninguno, y es la decisión.
ELEGANTE_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f7f5f1", surface="#fffefc", surface_2="#efece6",
    surface_3="#e7e3db", borde="#e2ded7", borde_fuerte="#c3bdb2",
    ink="#14110e", ink_soft="#4a453f", muted="#8b857d",
    acento="#14110e", acento_suave="#e8e4dd", acento_ink="#fffefc",
    positivo="#3d6b4f", negativo="#9c4a44", aviso="#8a6a2f",
    titular="Instrument",
    categorias=("#6b7f8c", "#6e8a70", "#99855c", "#9c7684", "#7f7793", "#63878a", "#a1815f", "#a0706c"),
    motivo="nada",
    tema="elegante",
    radio=12, filete=1,
    sombra=False,
    sombra_de_color=False,
)
ELEGANTE_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#0e0d0b", surface="#171512", surface_2="#201d19",
    surface_3="#282420", borde="#2a2621", borde_fuerte="#494339",
    ink="#f4f1eb", ink_soft="#b3ada4", muted="#7c766e",
    acento="#f4f1eb", acento_suave="#262320", acento_ink="#0e0d0b",
    positivo="#7fae8e", negativo="#d18b85", aviso="#c5a05f",
    titular="Instrument",
    categorias=("#6b7f8c", "#6e8a70", "#99855c", "#9c7684", "#7f7793", "#63878a", "#a1815f", "#a0706c"),
    motivo="nada",
    tema="elegante",
    radio=12, filete=1,
    sombra=False,
    sombra_de_color=False,
)

# -------------------------------------------------- 2. OCHENTAS
# Synthwave de gama alta: noche profunda, magenta eléctrico y cian. Brillo, nunca juguete.
# Fondo: horizonte en perspectiva.
OCHENTAS_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f4f0ff", surface="#ffffff", surface_2="#ece5ff",
    surface_3="#e2d9fb", borde="#d9cdf5", borde_fuerte="#b9a6e8",
    ink="#1a0f3d", ink_soft="#4b3d7a", muted="#7c72a8",
    acento="#c81ea6", acento_suave="#fbe3f6", acento_ink="#ffffff",
    positivo="#0d9c96", negativo="#d63a58", aviso="#c99310",
    titular="Orbitron",
    categorias=("#ff2fd0", "#2ff0d0", "#ffd23f", "#ff6ec7", "#9d5cff", "#35d6ff", "#ff8a3d", "#ff4f6d"),
    motivo="rejilla",
    tema="ochentas",
    radio=14, filete=1,
    sombra=False,
    sombra_de_color=False,
)
OCHENTAS_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#0b0720", surface="#150e33", surface_2="#1e1447",
    surface_3="#271a58", borde="#2c1f63", borde_fuerte="#4a34a0",
    ink="#f0ecff", ink_soft="#b9b0e8", muted="#7e75b5",
    acento="#ff2fd0", acento_suave="#3a0f4a", acento_ink="#0b0720",
    positivo="#2ff0d0", negativo="#ff5470", aviso="#ffd23f",
    titular="Orbitron",
    categorias=("#ff2fd0", "#2ff0d0", "#ffd23f", "#ff6ec7", "#9d5cff", "#35d6ff", "#ff8a3d", "#ff4f6d"),
    motivo="rejilla",
    tema="ochentas",
    radio=14, filete=1,
    sombra=False,
    sombra_de_color=False,
)

# --------------------------------------------------- 3. PREMIUM
# Borgoña sobre carbón y marfil, con un filo dorado. Sobrio, preciso, caro sin gritarlo.
# Fondo: arco dorado.
PREMIUM_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f7f3ec", surface="#ffffff", surface_2="#efe8dd",
    surface_3="#e6ddce", borde="#e0d7c8", borde_fuerte="#b99f63",
    ink="#1b1416", ink_soft="#4e4348", muted="#8a7f7a",
    acento="#8c2634", acento_suave="#f6e4e5", acento_ink="#ffffff",
    positivo="#43714a", negativo="#a8443c", aviso="#9c7c2c",
    titular="CormorantGaramond",
    categorias=("#7a5a66", "#5e7360", "#9b7b3c", "#96606f", "#6d5f86", "#4f7377", "#a06a45", "#9c4c48"),
    motivo="arco",
    tema="premium",
    radio=12, filete=1,
    sombra=False,
    sombra_de_color=False,
)
PREMIUM_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#100c0d", surface="#1a1416", surface_2="#241a1d",
    surface_3="#2c2024", borde="#2b2124", borde_fuerte="#6b5733",
    ink="#f5efe6", ink_soft="#bcb0a3", muted="#8a7f74",
    acento="#a33241", acento_suave="#2c1418", acento_ink="#f8f3ec",
    positivo="#6f9b6e", negativo="#c25a52", aviso="#c8a961",
    titular="CormorantGaramond",
    categorias=("#7a5a66", "#5e7360", "#9b7b3c", "#96606f", "#6d5f86", "#4f7377", "#a06a45", "#9c4c48"),
    motivo="arco",
    tema="premium",
    radio=12, filete=1,
    sombra=False,
    sombra_de_color=False,
)

# ----------------------------------------------- 4. MINIMALISTA
# Blanco cálido, niebla y grafito con un único acento salvia. Calmo y legible por encima de todo.
# Fondo: forma abstracta.
MINIMALISTA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#fbfaf8", surface="#ffffff", surface_2="#f2f0ec",
    surface_3="#eae7e1", borde="#e6e3dd", borde_fuerte="#cbc7c0",
    ink="#23211e", ink_soft="#55524d", muted="#8d8983",
    acento="#6f8a86", acento_suave="#e6edeb", acento_ink="#ffffff",
    positivo="#5d8168", negativo="#a9635c", aviso="#9a7f4e",
    titular="Jost",
    categorias=("#6f8a86", "#7d8a6f", "#8a8470", "#8a707d", "#7a7590", "#6b8790", "#97836a", "#98716c"),
    motivo="blob",
    tema="minimalista",
    radio=12, filete=0,
    sombra=False,
    sombra_de_color=False,
)
MINIMALISTA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#131312", surface="#1c1c1a", surface_2="#242422",
    surface_3="#2b2b28", borde="#2c2c29", borde_fuerte="#474743",
    ink="#eeece8", ink_soft="#b0ada7", muted="#7d7a75",
    acento="#8fada8", acento_suave="#1f2827", acento_ink="#131312",
    positivo="#82a88c", negativo="#c4837c", aviso="#bfa06a",
    titular="Jost",
    categorias=("#6f8a86", "#7d8a6f", "#8a8470", "#8a707d", "#7a7590", "#6b8790", "#97836a", "#98716c"),
    motivo="blob",
    tema="minimalista",
    radio=12, filete=0,
    sombra=False,
    sombra_de_color=False,
)

# --------------------------------------------------- 5. NATURAL
# Bosque, salvia y miel sobre crema. Cálido y orgánico; los hábitos cumplidos se sienten como algo que crece.
# Fondo: rama a línea.
NATURAL_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f8f4ea", surface="#fffdf7", surface_2="#efe9da",
    surface_3="#e6dfcd", borde="#ded5c2", borde_fuerte="#bfb298",
    ink="#1f2a20", ink_soft="#4a5749", muted="#857f70",
    acento="#2f5d3a", acento_suave="#e0ecdd", acento_ink="#fffdf7",
    positivo="#3f7a4a", negativo="#a3583f", aviso="#b8892b",
    titular="Fraunces",
    categorias=("#4a7c59", "#86a05a", "#c19a3f", "#a2673f", "#7d6a94", "#4f8892", "#c2743c", "#a24f43"),
    motivo="rama",
    tema="natural",
    radio=18, filete=0,
    sombra=True,
    sombra_de_color=False,
)
NATURAL_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#0e130e", surface="#171d16", surface_2="#1f271e",
    surface_3="#262f25", borde="#2a332a", borde_fuerte="#44513f",
    ink="#eef2e6", ink_soft="#b2bda9", muted="#7f8a78",
    acento="#6fae74", acento_suave="#16251a", acento_ink="#0e130e",
    positivo="#77b47c", negativo="#cf8158", aviso="#d8ad4a",
    titular="Fraunces",
    categorias=("#4a7c59", "#86a05a", "#c19a3f", "#a2673f", "#7d6a94", "#4f8892", "#c2743c", "#a24f43"),
    motivo="rama",
    tema="natural",
    radio=18, filete=0,
    sombra=True,
    sombra_de_color=False,
)

# ----------------------------------------------------- 6. SOLAR
# Coral, mango y menta sobre crema. Optimista y con recompensa: completar algo tiene que sentirse bien.
# Fondo: sol de rayos.
SOLAR_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#fff8ef", surface="#ffffff", surface_2="#ffeedd",
    surface_3="#ffe4cb", borde="#ffdcc0", borde_fuerte="#f4b98c",
    ink="#2a1a12", ink_soft="#5c4437", muted="#927a68",
    acento="#ff5a4e", acento_suave="#ffe3df", acento_ink="#ffffff",
    positivo="#17b891", negativo="#e03c4a", aviso="#ffb02e",
    titular="Outfit",
    categorias=("#ff5a4e", "#ffb02e", "#17b891", "#ff8fa3", "#a06bff", "#3ec6e0", "#ff7f3f", "#e0464f"),
    motivo="sol",
    tema="solar",
    radio=20, filete=0,
    sombra=True,
    sombra_de_color=True,
)
SOLAR_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#191009", surface="#23180f", surface_2="#2e2014",
    surface_3="#38271a", borde="#3b2a1a", borde_fuerte="#5e422a",
    ink="#fff2e4", ink_soft="#d0b49b", muted="#9c8672",
    acento="#ff6f5e", acento_suave="#3a1c17", acento_ink="#191009",
    positivo="#3ad0a6", negativo="#ff6b6b", aviso="#ffc457",
    titular="Outfit",
    categorias=("#ff5a4e", "#ffb02e", "#17b891", "#ff8fa3", "#a06bff", "#3ec6e0", "#ff7f3f", "#e0464f"),
    motivo="sol",
    tema="solar",
    radio=20, filete=0,
    sombra=True,
    sombra_de_color=True,
)

# -------------------------------------------------- 7. ELECTRIC
# Violeta eléctrico y azul neón sobre azul noche. Para empujar objetivos, inversión y progreso.
# Fondo: curvas de nivel.
ELECTRIC_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f5f5ff", surface="#ffffff", surface_2="#eceafe",
    surface_3="#e2defb", borde="#d8d4f7", borde_fuerte="#b5aeee",
    ink="#14173a", ink_soft="#454a7d", muted="#7a7fae",
    acento="#6a2fe0", acento_suave="#eee6ff", acento_ink="#ffffff",
    positivo="#0f9d7e", negativo="#d62c5c", aviso="#c48a10",
    titular="Sora",
    categorias=("#8b5cff", "#2f8bff", "#ff4fa3", "#2fe0b0", "#ffc63f", "#ff7a45", "#4fd8ff", "#ff4d7d"),
    motivo="topografia",
    tema="electric",
    radio=16, filete=1,
    sombra=False,
    sombra_de_color=False,
)
ELECTRIC_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#080b1f", surface="#101433", surface_2="#171c45",
    surface_3="#1e2455", borde="#232a5e", borde_fuerte="#3d4794",
    ink="#eef0ff", ink_soft="#b0b5e6", muted="#7b81b3",
    acento="#8b5cff", acento_suave="#241a52", acento_ink="#f5f3ff",
    positivo="#2fe0b0", negativo="#ff4d7d", aviso="#ffc63f",
    titular="Sora",
    categorias=("#8b5cff", "#2f8bff", "#ff4fa3", "#2fe0b0", "#ffc63f", "#ff7a45", "#4fd8ff", "#ff4d7d"),
    motivo="topografia",
    tema="electric",
    radio=16, filete=1,
    sombra=False,
    sombra_de_color=False,
)

# ------------------------------------------------------ 8. ISLA
# Turquesa apagado, salvia de mar y arena. Agua quieta: respirar, no correr.
# Fondo: ondas en el agua.
ISLA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f7fbf9", surface="#ffffff", surface_2="#eaf4f0",
    surface_3="#dfece7", borde="#d6e7e1", borde_fuerte="#aecfc5",
    ink="#17282a", ink_soft="#45605f", muted="#839a95",
    acento="#2f8f88", acento_suave="#dcefeb", acento_ink="#ffffff",
    positivo="#4a9a76", negativo="#c0654f", aviso="#c98f45",
    titular="Poppins",
    categorias=("#2f8f88", "#4a9a76", "#c98f45", "#6fb0bd", "#8fb37e", "#c07f6a", "#6d93b5", "#b56d7a"),
    motivo="ondas",
    tema="isla",
    radio=20, filete=0,
    sombra=False,
    sombra_de_color=False,
)
ISLA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#07100f", surface="#0d1a19", surface_2="#132321",
    surface_3="#182b29", borde="#1b2f2c", borde_fuerte="#2d4a46",
    ink="#e6f2ef", ink_soft="#a5c0bb", muted="#75908b",
    acento="#4fb5ab", acento_suave="#0c2422", acento_ink="#07100f",
    positivo="#6cc59b", negativo="#d98a70", aviso="#d8ab6a",
    titular="Poppins",
    categorias=("#2f8f88", "#4a9a76", "#c98f45", "#6fb0bd", "#8fb37e", "#c07f6a", "#6d93b5", "#b56d7a"),
    motivo="ondas",
    tema="isla",
    radio=20, filete=0,
    sombra=False,
    sombra_de_color=False,
)

# ---------------------------------------------------- 9. AURORA
# Noche azul, cian y lavanda con luz suave. Futurista pero sereno; los datos se leen sin esfuerzo.
# Fondo: onda de puntos.
AURORA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f5f8fc", surface="#ffffff", surface_2="#e9eff8",
    surface_3="#dee7f4", borde="#d4dfee", borde_fuerte="#adbfdb",
    ink="#101a2b", ink_soft="#40506b", muted="#78889f",
    acento="#1e91a8", acento_suave="#ddf0f4", acento_ink="#ffffff",
    positivo="#17997a", negativo="#cf4a63", aviso="#c1902f",
    titular="Sora",
    categorias=("#4fd6e8", "#a89bf0", "#7fb2f0", "#5fe0b4", "#c9d3e6", "#f0a3c8", "#ffd070", "#ff8fa0"),
    motivo="semitono",
    tema="aurora",
    radio=16, filete=1,
    sombra=False,
    sombra_de_color=False,
)
AURORA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#070c18", surface="#101728", surface_2="#172037",
    surface_3="#1d2842", borde="#223049", borde_fuerte="#39506f",
    ink="#eef3fb", ink_soft="#adbcd4", muted="#77879f",
    acento="#4fd6e8", acento_suave="#102b33", acento_ink="#070c18",
    positivo="#5fe0b4", negativo="#ff6b83", aviso="#ffd070",
    titular="Sora",
    categorias=("#4fd6e8", "#a89bf0", "#7fb2f0", "#5fe0b4", "#c9d3e6", "#f0a3c8", "#ffd070", "#ff8fa0"),
    motivo="semitono",
    tema="aurora",
    radio=16, filete=1,
    sombra=False,
    sombra_de_color=False,
)

# ---------------------------------------------------- 10. TERRA
# Terracota, bosque y mostaza sobre crema. Una libreta premium contemporánea, con carácter.
# Fondo: grano de papel.
TERRA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#faf4e9", surface="#fffdf8", surface_2="#f0e6d6",
    surface_3="#e8dcc7", borde="#ddd0ba", borde_fuerte="#c0ac8d",
    ink="#241a12", ink_soft="#56463a", muted="#8d7c6b",
    acento="#b8532f", acento_suave="#f7e2d8", acento_ink="#fffdf8",
    positivo="#3d6b40", negativo="#a83a2c", aviso="#c39320",
    titular="Fraunces",
    categorias=("#b8532f", "#3d6b40", "#c39320", "#8a5a7a", "#6b6f9c", "#44807e", "#d1863c", "#a83a2c"),
    motivo="grano",
    tema="terra",
    radio=8, filete=2,
    sombra=False,
    sombra_de_color=False,
)
TERRA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#14100b", surface="#1e1811", surface_2="#282017",
    surface_3="#31281d", borde="#342b20", borde_fuerte="#544636",
    ink="#f4ece0", ink_soft="#bdae9b", muted="#8b7f6e",
    acento="#d9714a", acento_suave="#33190f", acento_ink="#14100b",
    positivo="#6fa06f", negativo="#d4614c", aviso="#dcae44",
    titular="Fraunces",
    categorias=("#b8532f", "#3d6b40", "#c39320", "#8a5a7a", "#6b6f9c", "#44807e", "#d1863c", "#a83a2c"),
    motivo="grano",
    tema="terra",
    radio=8, filete=2,
    sombra=False,
    sombra_de_color=False,
)

# ------------------------------------------------------- 11. IA
# Blanco roto o negro profundo con jade y azul grisáceo. Ordenado, inteligente, sin ruido.
# Fondo: rejilla de puntos.
IA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f8f9f8", surface="#ffffff", surface_2="#eff2f1",
    surface_3="#e6eae9", borde="#e0e5e3", borde_fuerte="#c2cac7",
    ink="#161c1a", ink_soft="#48534f", muted="#7e8a86",
    acento="#14806a", acento_suave="#dcefe9", acento_ink="#ffffff",
    positivo="#14806a", negativo="#b04a44", aviso="#a8802c",
    titular="Archivo",
    categorias=("#14806a", "#5b7f96", "#8a7fa8", "#a8794f", "#4f8a7a", "#7a8a4f", "#96666f", "#56708a"),
    motivo="puntos",
    tema="ia",
    radio=10, filete=1,
    sombra=False,
    sombra_de_color=False,
)
IA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#0a0d0c", surface="#121716", surface_2="#1a201e",
    surface_3="#212826", borde="#232b29", borde_fuerte="#3a4442",
    ink="#eef2f0", ink_soft="#aeb8b4", muted="#7b8481",
    acento="#35b894", acento_suave="#0e2620", acento_ink="#0a0d0c",
    positivo="#35b894", negativo="#d0736c", aviso="#c9a24f",
    titular="Archivo",
    categorias=("#14806a", "#5b7f96", "#8a7fa8", "#a8794f", "#4f8a7a", "#7a8a4f", "#96666f", "#56708a"),
    motivo="puntos",
    tema="ia",
    radio=10, filete=1,
    sombra=False,
    sombra_de_color=False,
)

# ---------------------------------------------------- 12. FOCUS
# Azul tinta, lavanda y celeste sobre blanco. Un estudio personal para construir proyectos y rutinas.
# Fondo: cuadrícula de cuaderno.
FOCUS_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f7f8fc", surface="#ffffff", surface_2="#edf0f9",
    surface_3="#e4e9f5", borde="#dbe1f0", borde_fuerte="#b8c2de",
    ink="#131a33", ink_soft="#414a6b", muted="#7a83a3",
    acento="#2b3f8f", acento_suave="#e3e8fa", acento_ink="#ffffff",
    positivo="#2e8f6f", negativo="#c04a5e", aviso="#b98a26",
    titular="Archivo",
    categorias=("#2b3f8f", "#8f8ae0", "#4fa8e0", "#59c39c", "#e0b45c", "#e8788a", "#6f7fb5", "#45c0c0"),
    motivo="cuadricula",
    tema="focus",
    radio=14, filete=0,
    sombra=True,
    sombra_de_color=False,
)
FOCUS_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#0a0d1a", surface="#131829", surface_2="#1a2036",
    surface_3="#202742", borde="#252d47", borde_fuerte="#3d4869",
    ink="#eceff8", ink_soft="#adb4cc", muted="#79809b",
    acento="#7f8fe8", acento_suave="#171d3a", acento_ink="#0a0d1a",
    positivo="#59c39c", negativo="#e8788a", aviso="#e0b45c",
    titular="Archivo",
    categorias=("#2b3f8f", "#8f8ae0", "#4fa8e0", "#59c39c", "#e0b45c", "#e8788a", "#6f7fb5", "#45c0c0"),
    motivo="cuadricula",
    tema="focus",
    radio=14, filete=0,
    sombra=True,
    sombra_de_color=False,
)

# -------------------------------------------------- 13. GALAXIA
# Vacío profundo y luz de estrella. La racha no es un número: es una constelación que se va encendiendo.
# Fondo: polvo de estrellas.
GALAXIA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f6f5fb", surface="#ffffff", surface_2="#ecebf7",
    surface_3="#e2e0f2", borde="#dedcf0", borde_fuerte="#b6b2dd",
    ink="#14162e", ink_soft="#43476f", muted="#7b7fa3",
    acento="#3b3a8f", acento_suave="#e6e5f9", acento_ink="#ffffff",
    positivo="#17998a", negativo="#cf4a63", aviso="#b8862a",
    titular="Marcellus",
    categorias=("#6f8fe8", "#5fd3a8", "#ffc978", "#ff8fc0", "#a97fe8", "#66d8f0", "#ff9d5c", "#f0616f"),
    motivo="estrellas",
    tema="galaxia",
    radio=12, filete=1,
    sombra=False,
    sombra_de_color=False,
)
GALAXIA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#05060f", surface="#0c0f22", surface_2="#131735",
    surface_3="#1a1f45", borde="#1e2450", borde_fuerte="#38408a",
    ink="#eef0ff", ink_soft="#aeb3dd", muted="#767ba8",
    acento="#ffc978", acento_suave="#2a2038", acento_ink="#05060f",
    positivo="#6fe0c0", negativo="#ff7a92", aviso="#ffd98a",
    titular="Marcellus",
    categorias=("#6f8fe8", "#5fd3a8", "#ffc978", "#ff8fc0", "#a97fe8", "#66d8f0", "#ff9d5c", "#f0616f"),
    motivo="estrellas",
    tema="galaxia",
    radio=12, filete=1,
    sombra=False,
    sombra_de_color=False,
)

# ---------------------------------------------------- 14. CIELO
# Blanco cálido, dorado suave y celeste. El más emocional de los catorce: no es productividad, es un sitio donde estar bien y avanzar.
# Fondo: nubes.
CIELO_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#fbf8f1", surface="#ffffff", surface_2="#f5efe1",
    surface_3="#efe7d4", borde="#ece3cf", borde_fuerte="#d6c49e",
    ink="#3a3120", ink_soft="#6d5e43", muted="#9b8c71",
    acento="#b0862f", acento_suave="#f6ecd4", acento_ink="#ffffff",
    positivo="#5f9a73", negativo="#c4664f", aviso="#d98b3a",
    titular="Fraunces",
    categorias=("#7ea9d0", "#6fa886", "#c9a24a", "#d094a8", "#9d8ec9", "#79bcc9", "#d59a68", "#c4707a"),
    motivo="nubes",
    tema="cielo",
    radio=20, filete=1,
    sombra=False,
    sombra_de_color=False,
)
CIELO_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#0b1120", surface="#121a2c", surface_2="#182238",
    surface_3="#1e2a44", borde="#1f2b45", borde_fuerte="#384a6d",
    ink="#f2ece0", ink_soft="#c2c6d4", muted="#808aa0",
    acento="#e2b862", acento_suave="#242c42", acento_ink="#0b1120",
    positivo="#6fc79b", negativo="#e78472", aviso="#f0a95c",
    titular="Fraunces",
    categorias=("#7ea9d0", "#6fa886", "#c9a24a", "#d094a8", "#9d8ec9", "#79bcc9", "#d59a68", "#c4707a"),
    motivo="nubes",
    tema="cielo",
    radio=20, filete=1,
    sombra=False,
    sombra_de_color=False,
)


ESTILOS: tuple[Estilo, ...] = (
    Estilo(
        clave="elegante",
        nombre="Elegante",
        descripcion="Blanco roto, negro tinta y mucho aire. Sin un solo color.",
        clara=ELEGANTE_CLARA,
        oscura=ELEGANTE_OSCURA,
    ),
    Estilo(
        clave="ochentas",
        nombre="80s",
        descripcion="Synthwave: noche, magenta electrico y cian. Brilla sin ser un juguete.",
        clara=OCHENTAS_CLARA,
        oscura=OCHENTAS_OSCURA,
    ),
    Estilo(
        clave="premium",
        nombre="Premium",
        descripcion="Borgona sobre carbon, con un filo dorado. Caro sin gritarlo.",
        clara=PREMIUM_CLARA,
        oscura=PREMIUM_OSCURA,
    ),
    Estilo(
        clave="minimalista",
        nombre="Minimalista",
        descripcion="Blanco calido, niebla y un unico acento salvia. Todo susurra.",
        clara=MINIMALISTA_CLARA,
        oscura=MINIMALISTA_OSCURA,
    ),
    Estilo(
        clave="natural",
        nombre="Natural",
        descripcion="Bosque, salvia y miel sobre crema. Los habitos crecen.",
        clara=NATURAL_CLARA,
        oscura=NATURAL_OSCURA,
    ),
    Estilo(
        clave="solar",
        nombre="Solar Pop",
        descripcion="Coral, mango y menta. Cumplir algo se siente bien.",
        clara=SOLAR_CLARA,
        oscura=SOLAR_OSCURA,
    ),
    Estilo(
        clave="electric",
        nombre="Electric Studio",
        descripcion="Violeta y neon sobre azul noche. Para empujar objetivos.",
        clara=ELECTRIC_CLARA,
        oscura=ELECTRIC_OSCURA,
    ),
    Estilo(
        clave="isla",
        nombre="Isla Serena",
        descripcion="Turquesa apagado y arena. Agua quieta, sin prisa.",
        clara=ISLA_CLARA,
        oscura=ISLA_OSCURA,
    ),
    Estilo(
        clave="aurora",
        nombre="Aurora",
        descripcion="Noche, cian y lavanda. Futurista y tranquilo.",
        clara=AURORA_CLARA,
        oscura=AURORA_OSCURA,
    ),
    Estilo(
        clave="terra",
        nombre="Terra Bold",
        descripcion="Terracota, bosque y mostaza. Una libreta premium.",
        clara=TERRA_CLARA,
        oscura=TERRA_OSCURA,
    ),
    Estilo(
        clave="ia",
        nombre="AI Workspace",
        descripcion="Jade y grafito, muy ordenado. Cabe mas en cada pantalla.",
        clara=IA_CLARA,
        oscura=IA_OSCURA,
    ),
    Estilo(
        clave="focus",
        nombre="Focus Studio",
        descripcion="Azul tinta y lavanda. Un estudio para construir cosas.",
        clara=FOCUS_CLARA,
        oscura=FOCUS_OSCURA,
    ),
    Estilo(
        clave="galaxia",
        nombre="Galaxia",
        descripcion="Vacio y luz de estrella. Las rachas son constelaciones.",
        clara=GALAXIA_CLARA,
        oscura=GALAXIA_OSCURA,
    ),
    Estilo(
        clave="cielo",
        nombre="Heaven",
        descripcion="Blanco calido, dorado y celeste. Un sitio donde estar bien.",
        clara=CIELO_CLARA,
        oscura=CIELO_OSCURA,
    ),
)

POR_CLAVE: dict[str, Estilo] = {uno.clave: uno for uno in ESTILOS}

ESTILO_POR_OMISION = "elegante"
"""El que sale si nunca tocas el ajuste. Lo eligio el usuario."""


ANTIGUOS = {
    # "reto" se llamaba asi antes del rediseno de los trece temas; ahora es
    # "80s", con otra paleta pero la misma idea.
    #
    # ESTO NO SE BORRA NUNCA. La clave vive en el archivo de ajustes de cada
    # persona: sin el alias, quien tuviera "reto" guardado abriria un dia la
    # aplicacion en blanco y negro sin entender por que. Cuesta dos lineas y
    # evita un "se me ha cambiado solo" que nadie sabria explicar.
    "reto": "ochentas",
}


def estilo_por_clave(clave: str) -> Estilo:
    """El estilo guardado, o el de por omision si el ajuste esta raro.

    NO FALLA A PROPOSITO, al reves que las monedas: equivocarse aqui solo cuesta
    ver la aplicacion de otro color, nunca un dato mal. Y una aplicacion que no
    abre porque el ajuste del tema esta corrupto seria mucho peor que una que
    abre en blanco y negro.
    """
    if not isinstance(clave, str):
        return POR_CLAVE[ESTILO_POR_OMISION]
    limpia = clave.strip().lower()
    limpia = ANTIGUOS.get(limpia, limpia)
    return POR_CLAVE.get(limpia, POR_CLAVE[ESTILO_POR_OMISION])


def paleta_para(
    nombre: str, *, sistema_oscuro: bool, estilo: str = ESTILO_POR_OMISION
) -> Paleta:
    """La paleta que toca: la del ESTILO elegido, en su versión clara u oscura.

    SON DOS AJUSTES INDEPENDIENTES y funcionan como uno espera: el estilo dice
    de qué colores es la aplicación, y el tema dice si esos colores van en su
    versión clara o en la oscura. Todos los temas tienen las dos.

    "sistema" (y cualquier valor raro, por si el ajuste estuviera corrupto) sigue
    a Windows: es lo que el usuario ya decidió una vez para todo su ordenador, y
    equivocarse ahí solo cuesta un tema feo, no un dato mal guardado.
    """
    elegido = estilo_por_clave(estilo)
    if nombre == "claro":
        return elegido.clara
    if nombre == "oscuro":
        return elegido.oscura
    return elegido.paleta(oscuro=sistema_oscuro)
