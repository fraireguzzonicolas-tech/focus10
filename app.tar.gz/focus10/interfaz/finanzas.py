"""La pantalla de finanzas.

FORMA, copiada de Nexo: cabecera con el título a la izquierda y los botones
pequeños a la DERECHA, y debajo todo dentro de tarjetas. El verde y el rojo se
usan solo en las cifras y en las barras; los botones son sobrios.

CÓMO SE REFRESCA: en vez de ir tocando controles sueltos cada vez que cambia
algo, se vuelve a construir el contenido entero desde la base de datos. Con unas
decenas de movimientos es instantáneo, y evita el fallo clásico de las
interfaces: que la pantalla y los datos dejen de coincidir porque alguien se
olvidó de actualizar un trozo.

POR QUÉ SE ABRE UNA CONEXIÓN NUEVA EN CADA OPERACIÓN: las respuestas a los
clics pueden ejecutarse en hilos distintos, y una conexión de sqlite3 no se
puede compartir entre hilos sin cuidado. Abrir una por operación cuesta
microsegundos y quita el problema de raíz.
"""

from __future__ import annotations

import calendar
from datetime import date

import flet as ft

from ..datos import repositorio_categorias, repositorio_movimientos
from ..datos import repositorio_dias
from ..datos.bd import conectado
from ..dominio import dinero, resumen
from ..dominio.semana import texto_mes
from ..dominio.moneda import PRINCIPAL_POR_OMISION
from ..dominio.movimiento import (
    AHORRO,
    AJUSTES,
    AJUSTE_DE,
    CUENTAN_COMO_GASTO,
    CUENTAN_COMO_INGRESO,
    INVERSION,
    SALIDAS_DE_CAJA,
)
from ..dominio.movimiento import Movimiento, Tipo
from ..dominio.guardado import Saldo, ahorrado, disponible, invertido
from . import componentes, dialogo_ajuste, dialogo_cuadre, dialogo_movimiento
from .estilo import Paleta
from .grafico import grafico_diario

# Las columnas de la lista de movimientos: (título, ancho). El ancho None se
# come el espacio que sobre.
COLUMNAS = (
    ("Fecha", 56),
    ("Importe", 150),
    ("Categoría", 150),
    ("Descripción", None),
    ("", 40),
)



class PantallaFinanzas(componentes.Pantalla):
    """Todo el estado de la pantalla de finanzas."""

    def __init__(self, pagina: ft.Page, paleta: Paleta) -> None:
        super().__init__(pagina, paleta)
        self.refrescar()

    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        """Vuelve a leerlo todo y a construir la pantalla."""
        with conectado() as conexion:
            hoy = repositorio_dias.jornada_abierta(conexion)
            primero, ultimo = _extremos_del_mes(hoy)

            totales = repositorio_movimientos.totales_por_jornada(
                conexion, primero, ultimo
            )
            movimientos = repositorio_movimientos.listar(
                conexion, desde=primero, hasta=ultimo
            )
            nombres = {
                categoria.id: categoria.nombre
                for categoria in repositorio_categorias.listar(
                    conexion, incluir_inactivas=True
                )
            }
            # TODOS LOS MOVIMIENTOS, no los del mes: lo ahorrado es un saldo
            # que viene de arrastre. Enseñar solo lo de este mes diría que
            # tienes 500 € ahorrados el día 3 de cada mes.
            historia = repositorio_movimientos.listar(conexion)

        # POR CONJUNTO Y NO POR UN TIPO: los gastos son los apuntados MAS lo
        # que escribes con el lapiz. Si se sumaran por separado, sus pendientes
        # —lo que no se pudo convertir— habria que volver a juntarlos a mano.
        gastos = resumen.sumar(movimientos, tipo=CUENTAN_COMO_GASTO)
        ingresos = resumen.sumar(movimientos, tipo=CUENTAN_COMO_INGRESO)

        saldo_ahorro = ahorrado(historia)
        saldo_inversion = invertido(historia)
        # EL BALANCE ES DEL MES, no de toda la vida: la pregunta que contesta es
        # "cuanto me queda para lo que falta de mes".
        queda = disponible(movimientos)

        piezas: list[ft.Control] = [
            self._cabecera(hoy),
            # Lo que TIENES va antes que lo que ha pasado este mes: es la foto
            # grande, y el mes es el detalle.
            self._tarjeta_ahorros(saldo_ahorro, saldo_inversion),
            self._tarjeta_resumen(gastos, ingresos, queda),
        ]
        sin_convertir = saldo_ahorro.pendientes + saldo_inversion.pendientes
        if sin_convertir:
            piezas.insert(
                2,
                componentes.aviso(
                    self.paleta,
                    [
                        f"{len(sin_convertir)} movimiento(s) en otra moneda sin "
                        "convertir: no están contados en el ahorro ni en la "
                        "inversión."
                    ],
                ),
            )

        textos_aviso = textos_de_aviso(gastos, ingresos)
        if textos_aviso:
            piezas.append(componentes.aviso(self.paleta, textos_aviso))

        piezas += [
            self._tarjeta_grafico(totales, _dias_del_mes(hoy)),
            # LOS AJUSTES NO SALEN EN LA LISTA, y lo eligio el usuario: la
            # lista es para dinero que se ha movido de verdad. Se editan con el
            # lapiz de su propia cifra, que es donde se ven. Son los seis: los
            # dos del ahorro y la inversion, los dos de ingresos y gastos, y los
            # dos del cuadre.
            self._tarjeta_tabla(
                [uno for uno in movimientos if uno.tipo not in AJUSTES],
                nombres,
            ),
        ]

        self.pintar(piezas)

    # ----------------------------------------------------------------------

    def _cabecera(self, hoy: date) -> ft.Control:
        def apuntar(tipo: Tipo):
            return lambda _: dialogo_movimiento.abrir(
                self.pagina, tipo, self.paleta, self.refrescar
            )

        return componentes.titulo_pagina(
            self.paleta,
            "Finanzas",
            texto_mes(hoy),
            acciones=[
                componentes.boton(
                    self.paleta,
                    "Gasto",
                    icono=ft.Icons.ARROW_DOWNWARD,
                    color_icono=self.paleta.negativo,
                    al_pulsar=apuntar(Tipo.GASTO),
                ),
                componentes.boton(
                    self.paleta,
                    "Ingreso",
                    icono=ft.Icons.ARROW_UPWARD,
                    color_icono=self.paleta.positivo,
                    al_pulsar=apuntar(Tipo.INGRESO),
                ),
                # AHORRAR E INVERTIR TIENEN SU PROPIO BOTÓN, y no una casilla
                # dentro del gasto: cuando llega el sueldo se hacen los tres
                # repartos seguidos, y esconder dos de ellos detrás de un menú
                # sería esconder justo lo que se hace una vez al mes y de golpe.
                componentes.boton(
                    self.paleta,
                    "Ahorro",
                    icono=ft.Icons.SAVINGS_OUTLINED,
                    color_icono=self.paleta.aviso,
                    al_pulsar=apuntar(Tipo.AHORRO),
                ),
                componentes.boton(
                    self.paleta,
                    "Inversión",
                    icono=ft.Icons.TRENDING_UP,
                    color_icono=self.paleta.acento,
                    al_pulsar=apuntar(Tipo.INVERSION),
                ),
            ],
        )

    def _tarjeta_ahorros(self, ahorro: Saldo, inversion: Saldo) -> ft.Control:
        """Lo ahorrado y lo mandado a invertir, con su botón de sacar.

        ANTES ERAN DOS CIFRAS QUE SE ESCRIBÍAN A MANO con un lápiz, y ahora
        salen de tus movimientos. Lo eligió el usuario: "cuando yo pongo uno en
        ahorro, que el apartado de ahorro crezca, que los cuente".

        SE GANA que el número no pueda contradecir a la lista de abajo, porque
        es la lista de abajo. SE PIERDE poder escribir "tengo 3.200" sin decir
        de dónde salen; quien quiera eso lo apunta como un ahorro más.
        """
        return componentes.tarjeta(
            self.paleta,
            ft.Row(
                [
                    self._cifra_de_saldo(
                        "Ahorrado", ahorro, AHORRO, Tipo.RETIRADA_AHORRO
                    ),
                    self._cifra_de_saldo(
                        "Invertido", inversion, INVERSION, Tipo.RETIRADA_INVERSION
                    ),
                    componentes.cifra(
                        self.paleta,
                        "Patrimonio",
                        dinero.formatear(
                            ahorro.total + inversion.total, PRINCIPAL_POR_OMISION
                        ),
                        ayuda="ahorrado más invertido",
                    ),
                ],
                spacing=48,
            ),
        )

    def _lapiz_de_ajuste(self, tipo: Tipo, ayuda: str) -> ft.Control:
        """El lápiz de Ingresos y el de Gastos.

        SON UNA CIFRA, no una lista: escribir otra sustituye a la anterior. Es
        lo mismo que ya hace el del ahorro, y por la misma razón: la pregunta
        que contestan es siempre "¿cuánto, en total, no has detallado?".
        """
        return componentes.boton_lapiz(
            self.paleta,
            ayuda=ayuda,
            al_pulsar=lambda _, t=tipo, a=ayuda: dialogo_ajuste.abrir(
                self.pagina, t, a, self.paleta, self.refrescar
            ),
        )

    def _cifra_de_saldo(
        self, etiqueta: str, saldo: Saldo, guardado, retirada: Tipo
    ) -> ft.Control:
        """Una cifra con dos botones: sacar dinero, y decir lo que ya tenías.

        EL LÁPIZ ESTÁ AQUÍ Y NO EN LA LISTA porque el ajuste no sale en la
        lista: el usuario lo eligió así, y sin este botón un ajuste mal puesto
        sería invisible y no habría dónde ir a corregirlo.
        """
        sacar = componentes.boton_icono(
            self.paleta,
            ft.Icons.OUTBOX,
            ayuda=f"Sacar del {etiqueta.lower().replace('ahorrado', 'ahorro')}",
            al_pulsar=lambda _, t=retirada: dialogo_movimiento.abrir(
                self.pagina, t, self.paleta, self.refrescar
            ),
        )
        poner = componentes.boton_lapiz(
            self.paleta,
            ayuda=f"Lo que ya tenías en {guardado.nombre} (no toca el balance)",
            al_pulsar=lambda _, g=guardado: dialogo_ajuste.abrir(
                self.pagina,
                AJUSTE_DE[g.nombre],
                f"Lo que ya tenías en {g.nombre}",
                self.paleta,
                self.refrescar,
            ),
        )
        mandos = ft.Row([poner, sacar], spacing=0, tight=True)
        if not saldo.cuantos and not saldo.hay_pendientes:
            # NUNCA SE HA APUNTADO NADA. Se dice, en vez de enseñar un cero que
            # parecería un dato real.
            return componentes.cifra(
                self.paleta,
                etiqueta,
                "—",
                ayuda="todavía no has apuntado nada aquí",
                accion=mandos,
            )

        ayuda = f"{saldo.cuantos} movimiento(s)"
        if saldo.hay_pendientes:
            ayuda = f"{ayuda} · {len(saldo.pendientes)} sin convertir"
        return componentes.cifra(
            self.paleta,
            etiqueta,
            dinero.formatear(saldo.total, PRINCIPAL_POR_OMISION),
            ayuda=ayuda,
            accion=mandos,
        )

    def _tarjeta_resumen(
        self, gastos: resumen.Total, ingresos: resumen.Total, queda: Saldo
    ) -> ft.Control:
        balance = queda.total
        return componentes.tarjeta(
            self.paleta,
            ft.Row(
                [
                    componentes.cifra(
                        self.paleta,
                        "Ingresos",
                        ingresos.texto(),
                        tono="positivo",
                        accion=self._lapiz_de_ajuste(
                            Tipo.AJUSTE_INGRESO,
                            "Ingresos que no apuntaste uno a uno",
                        ),
                    ),
                    componentes.cifra(
                        self.paleta,
                        "Gastos",
                        gastos.texto(),
                        tono="negativo",
                        accion=self._lapiz_de_ajuste(
                            Tipo.AJUSTE_GASTO,
                            "Gastos que no apuntaste uno a uno",
                        ),
                    ),
                    componentes.cifra(
                        self.paleta,
                        "Balance",
                        dinero.formatear(balance, PRINCIPAL_POR_OMISION),
                        tono="positivo" if balance >= 0 else "negativo",
                        # ANTES PONIA "ingresos menos gastos" Y ERA FALSO desde
                        # que existen el ahorro y la inversion. Lo dijo el
                        # usuario: "es plata que tengo, pero que no puedo usar".
                        # Un balance que no lo reste dice que te quedan 1.757
                        # cuando te quedan 1.057, y con ese numero se decide si
                        # comprar algo.
                        ayuda="lo que te queda para gastar",
                        accion=componentes.boton_lapiz(
                            self.paleta,
                            ayuda="Cuadrar con lo que tienes de verdad en el banco",
                            al_pulsar=lambda _: dialogo_cuadre.abrir(
                                self.pagina, self.paleta, self.refrescar
                            ),
                        ),
                    ),
                ],
                spacing=48,
            ),
        )

    def _tarjeta_grafico(self, totales, dias: list[date]) -> ft.Control:
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta, "Día a día", "una barra por jornada"
                    ),
                    grafico_diario(totales, dias, PRINCIPAL_POR_OMISION, self.paleta),
                ],
                spacing=14,
            ),
        )

    def _tarjeta_tabla(
        self, movimientos: list[Movimiento], nombres: dict[int, str]
    ) -> ft.Control:
        cuantos = len(movimientos)
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Movimientos",
                        f"{cuantos} movimiento{'s' if cuantos != 1 else ''}"
                        if movimientos
                        else "nada por ahora",
                    ),
                    componentes.tabla(
                        self.paleta,
                        COLUMNAS,
                        [self._fila(uno, nombres) for uno in movimientos],
                        vacia="Todavía no has apuntado nada este mes.",
                    ),
                ],
                spacing=10,
            ),
        )

    def _color_de(self, tipo: Tipo) -> str:
        """De qué color va el importe de una fila.

        CUATRO COLORES Y NO DOS, y es el arreglo que pidió el usuario: sus 500 €
        apartados salían en rojo, como si los hubiera perdido. Ahora el rojo es
        solo para el gasto de verdad.

        LAS RETIRADAS VAN DEL COLOR DE SU CAJÓN, no de verde: sacar del ahorro no
        es cobrar, y pintarlo como un ingreso volvería a decir lo que no es. Se
        distinguen por el signo, que es "+" porque el dinero sí vuelve a la
        cuenta.
        """
        if tipo in AHORRO.tipos:
            return self.paleta.aviso
        if tipo in INVERSION.tipos:
            return self.paleta.acento
        if tipo is Tipo.GASTO:
            return self.paleta.negativo
        return self.paleta.positivo

    def _fila(
        self, movimiento: Movimiento, nombres: dict[int, str]
    ) -> list[ft.Control]:
        """Las celdas de una fila, en el orden de COLUMNAS."""
        color = self._color_de(movimiento.tipo)
        signo = "−" if movimiento.tipo in SALIDAS_DE_CAJA else "+"

        importe: list[ft.Control] = [
            ft.Text(
                f"{signo}{movimiento.texto_importe()}",
                size=13,
                weight=ft.FontWeight.W_600,
                color=color,
            )
        ]
        if movimiento.pendiente_de_cambio:
            # Se dice en la propia fila, no solo en el aviso de arriba: si no,
            # habría que sumar mentalmente para entender por qué el total no
            # cuadra con la lista.
            importe.append(ft.Text("sin convertir", size=10, color=self.paleta.aviso))

        return [
            ft.Text(
                f"{movimiento.jornada.day:02d}/{movimiento.jornada.month:02d}",
                size=12,
                color=self.paleta.muted,
            ),
            ft.Column(importe, spacing=0, tight=True),
            ft.Text(
                nombres.get(movimiento.categoria_id, "(sin categoría)"),
                size=12,
                color=self.paleta.ink_soft,
            ),
            ft.Text(
                movimiento.descripcion or "—",
                size=12,
                color=self.paleta.ink_soft
                if movimiento.descripcion
                else self.paleta.muted,
            ),
            componentes.boton_icono(
                self.paleta,
                ft.Icons.DELETE_OUTLINE,
                ayuda="Borrar este movimiento",
                al_pulsar=lambda _, m=movimiento: self._confirmar_borrado(m),
            ),
        ]

    def _confirmar_borrado(self, movimiento: Movimiento) -> None:
        """Pregunta antes de borrar: es lo único de esta pantalla que no tiene
        vuelta atrás."""

        def borrar(_):
            with conectado() as conexion:
                repositorio_movimientos.borrar(conexion, movimiento.id)
            self.pagina.pop_dialog()
            self.refrescar()

        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo="¿Borrar este movimiento?",
            texto=f"{movimiento.texto_importe()} · "
            f"{movimiento.jornada.day:02d}/{movimiento.jornada.month:02d}"
            + (f" · {movimiento.descripcion}" if movimiento.descripcion else "")
            + "\n\nNo se puede deshacer.",
            al_aceptar=borrar,
        )


def textos_de_aviso(gastos: resumen.Total, ingresos: resumen.Total) -> list[str]:
    """Los avisos de lo que no se pudo convertir. Lista vacia si no falta nada.

    Es una funcion suelta, y no codigo dentro de la pantalla, para que se pueda
    probar sin abrir ninguna ventana: es la regla de "el total no miente" y
    conviene tenerla vigilada.
    """
    return [
        texto
        for texto in (gastos.texto_aviso(), ingresos.texto_aviso())
        if texto is not None
    ]


def _extremos_del_mes(dia: date) -> tuple[date, date]:
    ultimo = calendar.monthrange(dia.year, dia.month)[1]
    return date(dia.year, dia.month, 1), date(dia.year, dia.month, ultimo)


def _dias_del_mes(dia: date) -> list[date]:
    # Solo hace falta el ultimo dia: el primero de un mes siempre es el 1.
    _, ultimo = _extremos_del_mes(dia)
    return [date(dia.year, dia.month, numero) for numero in range(1, ultimo.day + 1)]
