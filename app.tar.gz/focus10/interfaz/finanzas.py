"""La pantalla de finanzas.

FORMA, copiada de Nexo: cabecera con el título a la izquierda y los botones
pequeños a la DERECHA, y debajo todo dentro de tarjetas. El verde y el rojo se
usan solo en las cifras y en las barras; los botones son sobrios.

CÓMO SE REFRESCA: en vez de ir tocando controles sueltos cada vez que cambia
algo, se vuelve a construir el contenido entero desde la base de datos. Con unas
decenas de movimientos es instantáneo, y evita el fallo clásico de las
interfaces: que la pantalla y los datos dejen de coincidir porque alguien se
olvidó de actualizar un trozo.

POR QUÉ SE ABRE UNA CONEXIÓN NUEVA EN CADA OPERACIÓN: las respuestas a los
clics pueden ejecutarse en hilos distintos, y una conexión de sqlite3 no se
puede compartir entre hilos sin cuidado. Abrir una por operación cuesta
microsegundos y quita el problema de raíz.
"""

from __future__ import annotations

import calendar
from datetime import date

import flet as ft

from ..datos import repositorio_categorias, repositorio_movimientos, repositorio_saldos
from ..datos.ajustes import leer_horario
from ..datos.bd import conectado
from ..dominio import dinero, resumen
from ..dominio.jornada import jornada_actual
from ..dominio.moneda import PRINCIPAL_POR_OMISION
from ..dominio.movimiento import Movimiento, Tipo
from ..dominio.saldo import Clase, Saldo, calcular_patrimonio
from . import componentes, dialogo_movimiento, dialogo_saldo
from .estilo import Paleta
from .grafico import grafico_diario

# Las columnas de la lista de movimientos: (título, ancho). El ancho None se
# come el espacio que sobre.
COLUMNAS = (
    ("Fecha", 56),
    ("Importe", 150),
    ("Categoría", 150),
    ("Descripción", None),
    ("", 40),
)

MESES = (
    "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
)


class PantallaFinanzas:
    """Todo el estado de la pantalla de finanzas."""

    def __init__(self, pagina: ft.Page, paleta: Paleta) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.contenido = ft.Column(spacing=16, scroll=ft.ScrollMode.AUTO, expand=True)
        # Mientras el control no esté dentro de la ventana no se le puede pedir
        # que se repinte. En Flet 0.86 preguntárselo lanza un error, así que se
        # lleva la cuenta a mano: la ventana avisa llamando a montada().
        self._en_pagina = False
        self.refrescar()

    @property
    def control(self) -> ft.Control:
        return self.contenido

    def montada(self) -> None:
        """La llama la ventana justo después de añadir el control a la página."""
        self._en_pagina = True

    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        """Vuelve a leerlo todo y a construir la pantalla."""
        with conectado() as conexion:
            horario = leer_horario(conexion)
            hoy = jornada_actual(horario)
            primero, ultimo = _extremos_del_mes(hoy)

            totales = repositorio_movimientos.totales_por_jornada(
                conexion, primero, ultimo
            )
            movimientos = repositorio_movimientos.listar(
                conexion, desde=primero, hasta=ultimo
            )
            nombres = {
                categoria.id: categoria.nombre
                for categoria in repositorio_categorias.listar(
                    conexion, incluir_inactivas=True
                )
            }
            saldos = {
                clase: repositorio_saldos.ultimo(conexion, clase) for clase in Clase
            }

        gastos = resumen.sumar(movimientos, tipo=Tipo.GASTO)
        ingresos = resumen.sumar(movimientos, tipo=Tipo.INGRESO)

        patrimonio = calcular_patrimonio(saldos)

        piezas: list[ft.Control] = [
            self._cabecera(hoy),
            # Lo que TIENES va antes que lo que ha pasado este mes: es la foto
            # grande, y el mes es el detalle.
            self._tarjeta_ahorros(saldos, patrimonio),
            self._tarjeta_resumen(gastos, ingresos),
        ]
        if patrimonio.faltan:
            piezas.insert(
                2,
                componentes.aviso(
                    self.paleta,
                    ["El patrimonio no incluye: " + "; ".join(patrimonio.faltan)],
                ),
            )

        textos_aviso = textos_de_aviso(gastos, ingresos)
        if textos_aviso:
            piezas.append(componentes.aviso(self.paleta, textos_aviso))

        piezas += [
            self._tarjeta_grafico(totales, _dias_del_mes(hoy)),
            self._tarjeta_tabla(movimientos, nombres),
        ]

        self.contenido.controls = piezas
        if self._en_pagina:
            self.contenido.update()

    # ----------------------------------------------------------------------

    def _cabecera(self, hoy: date) -> ft.Control:
        def apuntar(tipo: Tipo):
            return lambda _: dialogo_movimiento.abrir(
                self.pagina, tipo, self.paleta, self.refrescar
            )

        return componentes.titulo_pagina(
            self.paleta,
            "Finanzas",
            f"{MESES[hoy.month - 1].capitalize()} {hoy.year}",
            acciones=[
                componentes.boton(
                    self.paleta,
                    "Gasto",
                    icono=ft.Icons.ARROW_DOWNWARD,
                    color_icono=self.paleta.negativo,
                    al_pulsar=apuntar(Tipo.GASTO),
                ),
                componentes.boton(
                    self.paleta,
                    "Ingreso",
                    icono=ft.Icons.ARROW_UPWARD,
                    color_icono=self.paleta.positivo,
                    al_pulsar=apuntar(Tipo.INGRESO),
                ),
            ],
        )

    def _tarjeta_ahorros(self, saldos, patrimonio) -> ft.Control:
        """Las dos cifras de patrimonio, con su lápiz para actualizarlas."""
        return componentes.tarjeta(
            self.paleta,
            ft.Row(
                [
                    self._cifra_de_saldo(Clase.AHORRO, saldos[Clase.AHORRO]),
                    self._cifra_de_saldo(Clase.INVERSION, saldos[Clase.INVERSION]),
                    componentes.cifra(
                        self.paleta,
                        "Patrimonio",
                        dinero.formatear(patrimonio.total, PRINCIPAL_POR_OMISION),
                        ayuda="ahorrado más invertido"
                        if patrimonio.esta_completo
                        else "incompleto, ver aviso",
                    ),
                ],
                spacing=48,
            ),
        )

    def _cifra_de_saldo(self, clase: Clase, saldo: Saldo | None) -> ft.Control:
        """Una cifra de patrimonio. Si nunca se anotó se dice, en vez de enseñar
        un cero que parecería un dato real."""
        etiqueta = "Ahorrado" if clase is Clase.AHORRO else "Invertido"
        lapiz = componentes.boton_lapiz(
            self.paleta,
            ayuda=f"Actualizar {etiqueta.lower()}",
            al_pulsar=lambda _, c=clase: dialogo_saldo.abrir(
                self.pagina, c, self.paleta, self.refrescar
            ),
        )

        if saldo is None:
            return componentes.cifra(
                self.paleta, etiqueta, "—",
                ayuda="aún no lo has anotado", accion=lapiz,
            )

        ayuda = f"anotado el {saldo.jornada.strftime('%d/%m/%Y')}"
        if saldo.pendiente_de_cambio:
            ayuda = f"{ayuda} · sin convertir"
        return componentes.cifra(
            self.paleta, etiqueta, saldo.texto_importe(), ayuda=ayuda, accion=lapiz
        )

    def _tarjeta_resumen(
        self, gastos: resumen.Total, ingresos: resumen.Total
    ) -> ft.Control:
        balance = ingresos.convertido - gastos.convertido
        return componentes.tarjeta(
            self.paleta,
            ft.Row(
                [
                    componentes.cifra(
                        self.paleta, "Ingresos", ingresos.texto(), tono="positivo"
                    ),
                    componentes.cifra(self.paleta, "Gastos", gastos.texto(), tono="negativo"),
                    componentes.cifra(
                        self.paleta,
                        "Balance",
                        dinero.formatear(balance, PRINCIPAL_POR_OMISION),
                        tono="positivo" if balance >= 0 else "negativo",
                        ayuda="ingresos menos gastos",
                    ),
                ],
                spacing=48,
            ),
        )

    def _tarjeta_grafico(self, totales, dias: list[date]) -> ft.Control:
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta, "Día a día", "una barra por jornada"
                    ),
                    grafico_diario(totales, dias, PRINCIPAL_POR_OMISION, self.paleta),
                ],
                spacing=14,
            ),
        )

    def _tarjeta_tabla(
        self, movimientos: list[Movimiento], nombres: dict[int, str]
    ) -> ft.Control:
        cuantos = len(movimientos)
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Movimientos",
                        f"{cuantos} movimiento{'s' if cuantos != 1 else ''}"
                        if movimientos
                        else "nada por ahora",
                    ),
                    componentes.tabla(
                        self.paleta,
                        COLUMNAS,
                        [self._fila(uno, nombres) for uno in movimientos],
                        vacia="Todavía no has apuntado nada este mes.",
                    ),
                ],
                spacing=10,
            ),
        )

    def _fila(
        self, movimiento: Movimiento, nombres: dict[int, str]
    ) -> list[ft.Control]:
        """Las celdas de una fila, en el orden de COLUMNAS."""
        es_gasto = movimiento.tipo is Tipo.GASTO
        color = self.paleta.negativo if es_gasto else self.paleta.positivo
        signo = "−" if es_gasto else "+"

        importe: list[ft.Control] = [
            ft.Text(
                f"{signo}{movimiento.texto_importe()}",
                size=13,
                weight=ft.FontWeight.W_600,
                color=color,
            )
        ]
        if movimiento.pendiente_de_cambio:
            # Se dice en la propia fila, no solo en el aviso de arriba: si no,
            # habría que sumar mentalmente para entender por qué el total no
            # cuadra con la lista.
            importe.append(ft.Text("sin convertir", size=10, color=self.paleta.aviso))

        return [
            ft.Text(
                f"{movimiento.jornada.day:02d}/{movimiento.jornada.month:02d}",
                size=12,
                color=self.paleta.muted,
            ),
            ft.Column(importe, spacing=0, tight=True),
            ft.Text(
                nombres.get(movimiento.categoria_id, "(sin categoría)"),
                size=12,
                color=self.paleta.ink_soft,
            ),
            ft.Text(
                movimiento.descripcion or "—",
                size=12,
                color=self.paleta.ink_soft
                if movimiento.descripcion
                else self.paleta.muted,
            ),
            componentes.boton_icono(
                self.paleta,
                ft.Icons.DELETE_OUTLINE,
                ayuda="Borrar este movimiento",
                al_pulsar=lambda _, m=movimiento: self._confirmar_borrado(m),
            ),
        ]

    def _confirmar_borrado(self, movimiento: Movimiento) -> None:
        """Pregunta antes de borrar: es lo único de esta pantalla que no tiene
        vuelta atrás."""

        def borrar(_):
            with conectado() as conexion:
                repositorio_movimientos.borrar(conexion, movimiento.id)
            self.pagina.pop_dialog()
            self.refrescar()

        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo="¿Borrar este movimiento?",
            texto=f"{movimiento.texto_importe()} · "
            f"{movimiento.jornada.day:02d}/{movimiento.jornada.month:02d}"
            + (f" · {movimiento.descripcion}" if movimiento.descripcion else "")
            + "\n\nNo se puede deshacer.",
            al_aceptar=borrar,
        )


def textos_de_aviso(gastos: resumen.Total, ingresos: resumen.Total) -> list[str]:
    """Los avisos de lo que no se pudo convertir. Lista vacia si no falta nada.

    Es una funcion suelta, y no codigo dentro de la pantalla, para que se pueda
    probar sin abrir ninguna ventana: es la regla de "el total no miente" y
    conviene tenerla vigilada.
    """
    return [
        texto
        for texto in (gastos.texto_aviso(), ingresos.texto_aviso())
        if texto is not None
    ]


def _extremos_del_mes(dia: date) -> tuple[date, date]:
    ultimo = calendar.monthrange(dia.year, dia.month)[1]
    return date(dia.year, dia.month, 1), date(dia.year, dia.month, ultimo)


def _dias_del_mes(dia: date) -> list[date]:
    # Solo hace falta el ultimo dia: el primero de un mes siempre es el 1.
    _, ultimo = _extremos_del_mes(dia)
    return [date(dia.year, dia.month, numero) for numero in range(1, ultimo.day + 1)]
