"""Hacer algo en el servidor con tu sesión al día, sin congelar la ventana.

LO USAN TODOS LOS QUE HABLAN CON EL SERVIDOR CON TU CUENTA: el asistente,
WhatsApp y el ranking de la Comunidad. Antes vivía en el diálogo de publicar
de la Comunidad vieja, que se borró el 8 nov 2026.
"""

from __future__ import annotations

import asyncio
from datetime import datetime

from ..datos.bd import conectado
from ..sistema.sincronizacion import ServidorDijoQueNo
from . import sincronizador


async def con_la_sesion(que_hacer):
    """Hace `que_hacer(testigo)` con la sesión al día. Devuelve lo que dé.

    LA SESIÓN SE RENUEVA ANTES, igual que al sincronizar: con un testigo
    caducado el servidor contesta 401 y parecería que todo falla.
    """
    with conectado() as conexion:
        sesion = sincronizador.sesion_viva(conexion, datetime.now())
    if sesion is None:
        raise ServidorDijoQueNo("hace falta entrar con tu cuenta")
    try:
        return await asyncio.to_thread(que_hacer, sesion.testigo)
    except RuntimeError as fallo:
        # EN LA WEB NO HAY HILOS (ver Sincronizador._en_segundo_plano).
        if "thread" not in str(fallo).lower():
            raise
        return que_hacer(sesion.testigo)
