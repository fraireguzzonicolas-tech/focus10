"""La tarjeta de Configuración donde se elige qué categorías recuerda la IA.

UNA FILA POR CATEGORÍA DE GASTO, con su desplegable. Cambiarlo se guarda en el
momento, como todo en Configuración.

EL NOMBRE ARRIBA Y EL DESPLEGABLE DEBAJO: en el móvil, nombre y desplegable en
la misma fila no caben a lo ancho (ver la regla de no deslizar de costado).
"""

from __future__ import annotations

from collections.abc import Callable

import flet as ft

from ..datos import repositorio_categorias
from ..datos.bd import conectado
from ..dominio.categoria import TEXTOS_MEMORIA, Categoria, Memoria
from ..dominio.movimiento import Tipo
from . import componentes
from .estilo import Paleta


def tarjeta(paleta: Paleta, pagina: ft.Page, al_cambiar: Callable[[], None]) -> ft.Control:
    with conectado() as conexion:
        categorias = repositorio_categorias.listar(conexion, tipo=Tipo.GASTO)

    filas = [_fila(paleta, pagina, una, al_cambiar) for una in categorias]
    return componentes.tarjeta(
        paleta,
        ft.Column(
            [
                componentes.cabecera_tarjeta(
                    paleta, "Memoria de gastos", "qué categorías recuerda la IA"
                ),
                *filas,
                componentes.aviso(
                    paleta,
                    [
                        "Los gastos se guardan siempre en el historial. Esto solo "
                        "dice cuáles recuerda la IA y en cuáles te avisa si "
                        "parece que pagás algo dos veces. Al activarla también "
                        "cuentan los gastos que ya tenías."
                    ],
                ),
            ],
            spacing=14,
        ),
    )


def _fila(
    paleta: Paleta, pagina: ft.Page, categoria: Categoria, al_cambiar: Callable[[], None]
) -> ft.Control:
    def elegir(evento):
        with conectado() as conexion:
            repositorio_categorias.cambiar_memoria(
                conexion, categoria.id, Memoria(evento.control.value)
            )
        componentes.avisar(pagina, f"«{categoria.nombre}» actualizada.")
        al_cambiar()

    return ft.Column(
        [
            ft.Text(categoria.nombre, size=13, weight=ft.FontWeight.W_500, color=paleta.ink),
            componentes.selector(
                paleta,
                "Memoria",
                [(memoria.value, texto) for memoria, texto in TEXTOS_MEMORIA.items()],
                valor=categoria.memoria.value,
                ancho=280,
                al_elegir=elegir,
            ),
        ],
        spacing=6,
        tight=True,
    )
