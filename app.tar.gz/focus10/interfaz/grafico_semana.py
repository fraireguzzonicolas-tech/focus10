"""La gráfica de cómo va la semana.

QUÉ ENSEÑA, y por qué son dos líneas:

  - La CONTINUA es esta semana: qué porcentaje de lo programado cumpliste cada
    día.
  - La PUNTEADA es tu media de las ocho semanas anteriores, día a día.

Juntas responden a algo que ninguna de las dos responde sola: si el miércoles
está bajo, ¿fue un mal miércoles suelto, o es que TODOS los miércoles te hundes?
Lo primero se arregla solo; lo segundo es un problema de cómo tienes montada la
semana.

POR QUÉ SE DIBUJA CON flet.canvas Y NO CON UNA LIBRERÍA: Flet 0.86 no trae
control de gráficos. Pero sí trae un lienzo donde se pueden pintar líneas de
verdad, que es justo lo que hace falta aquí. Sin dependencias externas.

LOS DÍAS SIN DATOS NO SE DIBUJAN: en la línea punteada, un día del que no hay
ninguna semana anterior con hábitos programados se queda sin punto, y la línea se
corta. Dibujarlo como un cero diría "esos miércoles los fallabas", que es una
afirmación distinta de "no había nada que cumplir".
"""

from __future__ import annotations

import flet as ft
import flet.canvas as cv

from ..dominio.habito import DIAS_SEMANA
from ..dominio.rachas import CumplimientoDelDia
from . import estilo
from .estilo import Paleta, con_opacidad

ALTO = 130
MARGEN_ARRIBA = 10
MARGEN_ABAJO = 22
GROSOR_LINEA = 2.5
RADIO_PUNTO = 3.5

# Cuánto mide cada trocito de la línea punteada y cuánto el hueco. Se dibuja a
# mano porque una línea punteada no es más que muchas líneas cortas seguidas.
TRAZO = 5.0
HUECO = 4.0


def grafico_semana(
    dias: list[CumplimientoDelDia],
    media: list[float | None],
    paleta: Paleta,
    *,
    ancho: int | None = None,
) -> ft.Control:
    """La gráfica de la semana. `dias` son siete, de lunes a domingo."""
    # EL ANCHO SE CALCULA SI NO LO DAN: un lienzo necesita un numero concreto
    # —tiene que saber donde cae cada punto— asi que no puede "estirarse hasta
    # lo que haya" como una caja normal. Se le da 620 si cabe, y lo que
    # quepa si no. En un movil eran 620 puntos sobre una pantalla de 375.
    if ancho is None:
        ancho = estilo.ancho_de_grafico(620)
    if len(dias) != 7:
        raise ValueError(f"la semana tiene siete días, y llegaron {len(dias)}")

    formas: list[cv.Shape] = []
    formas += _lineas_de_fondo(paleta, ancho)
    formas += _linea_punteada(media, paleta, ancho)
    formas += _linea_de_la_semana(dias, paleta, ancho)

    return ft.Column(
        [
            ft.Container(
                content=cv.Canvas(formas, expand=True),
                height=ALTO,
                width=ancho,
            ),
            _etiquetas_de_los_dias(dias, paleta, ancho),
            _leyenda(paleta),
        ],
        spacing=6,
        tight=True,
    )


# --------------------------------------------------------------------------


def _x(indice: int, ancho: int) -> float:
    """Dónde cae cada día a lo ancho. Los siete repartidos con medio hueco a los
    lados, para que el lunes y el domingo no queden pegados al borde."""
    paso = ancho / 7
    return paso * indice + paso / 2


def _y(proporcion: float) -> float:
    """De 0 (nada cumplido) a 1 (todo), al revés que la pantalla: arriba es más."""
    util = ALTO - MARGEN_ARRIBA - MARGEN_ABAJO
    return MARGEN_ARRIBA + util * (1 - proporcion)


def _lineas_de_fondo(paleta: Paleta, ancho: int) -> list[cv.Shape]:
    """Tres rayas horizontales: 0%, 50% y 100%. Sin ellas, las líneas flotan y
    no se sabe si un punto alto es un 70% o un 95%."""
    pintura = ft.Paint(color=paleta.borde, stroke_width=1)
    return [
        cv.Line(0, _y(proporcion), ancho, _y(proporcion), paint=pintura)
        for proporcion in (0.0, 0.5, 1.0)
    ]


def _linea_de_la_semana(
    dias: list[CumplimientoDelDia], paleta: Paleta, ancho: int
) -> list[cv.Shape]:
    """La línea continua, con un punto por día. Los días sin nada programado se
    saltan, igual que en la media."""
    pintura = ft.Paint(
        color=paleta.acento,
        stroke_width=GROSOR_LINEA,
        style=ft.PaintingStyle.STROKE,
    )
    relleno = ft.Paint(color=paleta.acento)

    puntos = [
        (_x(indice, ancho), _y(dia.proporcion))
        for indice, dia in enumerate(dias)
        if dia.hay_algo_programado
    ]

    formas: list[cv.Shape] = []
    for anterior, siguiente in zip(puntos, puntos[1:], strict=False):
        formas.append(
            cv.Line(anterior[0], anterior[1], siguiente[0], siguiente[1], paint=pintura)
        )
    formas += [cv.Circle(x, y, RADIO_PUNTO, paint=relleno) for x, y in puntos]
    return formas


def _linea_punteada(
    media: list[float | None], paleta: Paleta, ancho: int
) -> list[cv.Shape]:
    """La media de las ocho semanas anteriores, punteada para que no se confunda
    con la de esta semana."""
    color = con_opacidad(paleta.ink_soft, 0.7)
    pintura = ft.Paint(
        color=color, stroke_width=GROSOR_LINEA - 1, style=ft.PaintingStyle.STROKE
    )

    puntos = [
        (_x(indice, ancho), _y(valor))
        for indice, valor in enumerate(media)
        if valor is not None
    ]

    formas: list[cv.Shape] = []
    for anterior, siguiente in zip(puntos, puntos[1:], strict=False):
        formas += _trocitos(anterior, siguiente, pintura)
    return formas


def _trocitos(
    desde: tuple[float, float], hasta: tuple[float, float], pintura: ft.Paint
) -> list[cv.Shape]:
    """Parte un segmento en trocitos con huecos: eso es una línea punteada.

    Hay que hacerlo a mano porque el lienzo de Flet dibuja líneas enteras y no
    sabe de puntos ni rayas.
    """
    (x1, y1), (x2, y2) = desde, hasta
    largo = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
    if largo == 0:
        return []

    formas: list[cv.Shape] = []
    avance = 0.0
    while avance < largo:
        fin = min(avance + TRAZO, largo)
        formas.append(
            cv.Line(
                x1 + (x2 - x1) * (avance / largo),
                y1 + (y2 - y1) * (avance / largo),
                x1 + (x2 - x1) * (fin / largo),
                y1 + (y2 - y1) * (fin / largo),
                paint=pintura,
            )
        )
        avance = fin + HUECO
    return formas


def _etiquetas_de_los_dias(
    dias: list[CumplimientoDelDia], paleta: Paleta, ancho: int
) -> ft.Control:
    """La letra de cada día debajo, con su "3/5" pequeño."""
    columnas = []
    for indice, dia in enumerate(dias):
        letra = DIAS_SEMANA[indice][1]
        columnas.append(
            ft.Container(
                content=ft.Column(
                    [
                        ft.Text(letra, size=11, color=paleta.muted),
                        ft.Text(dia.texto(), size=10, color=paleta.muted),
                    ],
                    spacing=0,
                    tight=True,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                width=ancho / 7,
                alignment=ft.Alignment.CENTER,
            )
        )
    return ft.Row(columnas, spacing=0, width=ancho)


def _leyenda(paleta: Paleta) -> ft.Control:
    return ft.Row(
        [
            _muestra(paleta.acento, "esta semana", paleta, punteada=False),
            _muestra(paleta.ink_soft, "media de las 8 anteriores", paleta, punteada=True),
        ],
        spacing=16,
    )


def _muestra(color: str, texto: str, paleta: Paleta, *, punteada: bool) -> ft.Control:
    if punteada:
        # Tres trocitos separados, para que se vea que es la punteada.
        muestra: ft.Control = ft.Row(
            [
                ft.Container(width=4, height=2, bgcolor=con_opacidad(color, 0.7))
                for _ in range(3)
            ],
            spacing=2,
            tight=True,
        )
    else:
        muestra = ft.Container(width=16, height=2.5, bgcolor=color, border_radius=2)

    return ft.Row(
        [muestra, ft.Text(texto, size=11, color=paleta.muted)], spacing=6, tight=True
    )
