"""El temporizador circular de Focus: un anillo que se vacía con el tiempo.

POR QUÉ SE DIBUJA A MANO: Flet 0.86 no trae ningún control de gráficas ni de
progreso circular grande. Se pinta con flet.canvas, igual que el círculo de
gastos y la cuadrícula del año.

POR QUÉ EL ANILLO SE VACÍA EN VEZ DE LLENARSE: enseña lo que QUEDA, que es lo que
miras cuando estás trabajando. Un anillo que se llena enseña lo hecho, que ya no
puedes cambiar.

EL COLOR LO DICE TODO: trabajo en el color de acento, descansos en verde. Es lo
que permite saber en qué estás desde el otro lado de la habitación, sin leer.
"""

from __future__ import annotations

import math

import flet as ft
import flet.canvas as cv

from ..dominio.pomodoro import Ajustes, Estado, Fase
from .estilo import Paleta

LADO = 240
GROSOR = 14
ARRANQUE = -math.pi / 2
"""Se empieza arriba, a las doce, que es por donde se lee un reloj."""


def color_de_fase(paleta: Paleta, fase: Fase) -> str:
    return paleta.acento if fase.es_trabajo else paleta.positivo


def anillo(paleta: Paleta, estado: Estado, ajustes: Ajustes) -> ft.Control:
    """El círculo con el tiempo dentro."""
    tono = color_de_fase(paleta, estado.fase)
    queda = 1.0 - estado.fraccion(ajustes)

    formas: list[cv.Shape] = [
        # El aro apagado del fondo: sin él, con la fase casi terminada solo se
        # vería una rayita suelta y no se entendería que es un círculo.
        cv.Arc(
            x=GROSOR / 2,
            y=GROSOR / 2,
            width=LADO - GROSOR,
            height=LADO - GROSOR,
            start_angle=0,
            sweep_angle=2 * math.pi,
            paint=_pincel(paleta.surface_2),
        )
    ]
    if queda > 0:
        formas.append(
            cv.Arc(
                x=GROSOR / 2,
                y=GROSOR / 2,
                width=LADO - GROSOR,
                height=LADO - GROSOR,
                start_angle=ARRANQUE,
                sweep_angle=queda * 2 * math.pi,
                paint=_pincel(tono),
            )
        )

    return ft.Stack(
        [
            ft.Container(
                content=cv.Canvas(formas, width=LADO, height=LADO),
                width=LADO,
                height=LADO,
            ),
            ft.Container(
                content=ft.Column(
                    [
                        ft.Text(
                            estado.fase.value.upper(),
                            size=11,
                            weight=ft.FontWeight.W_600,
                            color=tono,
                        ),
                        ft.Text(
                            estado.texto(),
                            size=44,
                            weight=ft.FontWeight.W_300,
                            color=paleta.ink,
                        ),
                        ft.Text(
                            _texto_del_ciclo(estado, ajustes),
                            size=11,
                            color=paleta.muted,
                        ),
                    ],
                    spacing=2,
                    tight=True,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
                width=LADO,
                height=LADO,
                alignment=ft.Alignment.CENTER,
            ),
        ],
        width=LADO,
        height=LADO,
    )


def _texto_del_ciclo(estado: Estado, ajustes: Ajustes) -> str:
    """"Sesión 2 de 4". Sitúa dentro del ciclo sin tener que contar."""
    hechas = estado.trabajos_hechos
    if estado.fase.es_trabajo:
        hechas += 1
    return f"sesión {min(hechas, ajustes.sesiones_por_ciclo)} de {ajustes.sesiones_por_ciclo}"


def _pincel(color: str) -> ft.Paint:
    return ft.Paint(
        color=color,
        stroke_width=GROSOR,
        style=ft.PaintingStyle.STROKE,
        stroke_cap=ft.StrokeCap.ROUND,
    )
