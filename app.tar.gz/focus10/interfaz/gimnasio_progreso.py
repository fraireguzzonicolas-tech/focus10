"""El progreso: la vista de PROGRESO del gimnasio.

NADA DE ESTIMACIONES, y lo pidió el usuario con estas palabras: "no calcules mi
1RM teórico". Aquí no hay una sola cifra calculada con una fórmula sobre lo que
uno "podría" levantar. Todo lo que sale en esta pantalla se levantó de verdad un
día concreto, y ese día se enseña al lado.

TRES COSAS Y NADA MÁS:
  - La mejor serie de un ejercicio, con su fecha.
  - El peso máximo mes a mes de ese ejercicio.
  - Cuántas series por grupo muscular, para ver qué se está descuidando.

LO QUE NO SE REPARTE A OJO: los ejercicios borrados de la biblioteca no tienen
grupo, así que no se cuentan en el reparto. Se dice aparte en vez de repartirlos
por su cuenta, que es la clase de invento que hace que un número deje de
significar nada.
"""

from __future__ import annotations


import flet as ft

from ..datos import repositorio_gimnasio
from ..datos.bd import conectado
from ..dominio.rutina import texto_peso
from ..dominio.sesion import (
    mejor_marca,
    peso_maximo_por_mes,
    series_por_grupo,
    texto_volumen,
    volumen_por_semana,
)
from . import componentes, estilo

ALTO_BARRA = 120
ANCHO_BARRA = 34
SEMANAS = 12
"""Cuántas semanas se enseñan de volumen. Tres meses: suficiente para ver una
tendencia y poco para que quepa sin apretar."""

MESES_CORTOS = (
    "ene", "feb", "mar", "abr", "may", "jun",
    "jul", "ago", "sep", "oct", "nov", "dic",
)


def vista(pantalla) -> list[ft.Control]:
    return _Vista(pantalla).piezas()


class _Vista:
    def __init__(self, pantalla) -> None:
        self.pantalla = pantalla
        self.paleta = pantalla.paleta

    def piezas(self) -> list[ft.Control]:
        with conectado() as conexion:
            sesiones = repositorio_gimnasio.todas_las_sesiones(conexion)

        if not any(una.entrenado for una in sesiones):
            return [
                componentes.tarjeta(
                    self.paleta,
                    componentes.aviso_vacio(
                        self.paleta,
                        "Todavía no hay ningún entreno apuntado. En cuanto marques "
                        "series en «Hoy», aquí aparece lo que has hecho.",
                        icono=ft.Icons.FITNESS_CENTER,
                        alto=160,
                    ),
                )
            ]

        return [
            self._volumen_por_semana(sesiones),
            self._reparto(sesiones),
            self._por_ejercicio(),
        ]

    # ------------------------------------------------------------------

    def _volumen_por_semana(self, sesiones) -> ft.Control:
        puntos = volumen_por_semana([una for una in sesiones if una.entrenado])[-SEMANAS:]
        tope = max((valor for _, valor in puntos), default=0)

        barras = [
            self._barra(
                valor,
                tope,
                f"{lunes.day}/{lunes.month}",
                texto_volumen(valor),
                self.paleta.acento,
            )
            for lunes, valor in puntos
        ]

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Volumen por semana",
                        "Peso × repeticiones de las series marcadas",
                    ),
                    ft.Row(barras, spacing=10, vertical_alignment=ft.CrossAxisAlignment.END),
                ],
                spacing=18,
            ),
        )

    def _reparto(self, sesiones) -> ft.Control:
        # LOS GRUPOS SALEN DE LA BIBLIOTECA QUE YA ESTA CARGADA en la pantalla,
        # no de una consulta. Antes esto abria una conexion a la base que no
        # llegaba a usar —quedo asi al mover de sitio la consulta— y despues
        # hacia `del conexion` para que no molestara. Abrir la base para nada no
        # daba ningun error, solo trabajo de mas en cada repintado.
        grupos = {
            uno.id: uno.grupo.value
            for uno in self.pantalla.ejercicios
            if uno.id is not None
        }

        cuenta = series_por_grupo([una for una in sesiones if una.entrenado], grupos)
        huerfanas = sum(
            uno.hechas
            for una in sesiones
            for uno in una.ejercicios
            if uno.ejercicio_id is None or uno.ejercicio_id not in grupos
        )

        if not cuenta:
            cuerpo: ft.Control = componentes.aviso_vacio(
                self.paleta, "Sin series repartibles todavía.", alto=100
            )
        else:
            tope = max(cuenta.values())
            filas = [
                ft.Row(
                    [
                        ft.Text(
                            grupo.capitalize(),
                            size=estilo.TEXTO,
                            color=self.paleta.ink,
                            width=90,
                        ),
                        ft.Container(
                            content=componentes.barra_de_avance(
                                self.paleta,
                                color=self.paleta.acento,
                                fraccion=cuantas / tope,
                                alto=10,
                            ),
                            expand=True,
                        ),
                        ft.Text(
                            str(cuantas),
                            size=estilo.TEXTO,
                            color=self.paleta.ink_soft,
                            width=44,
                            text_align=ft.TextAlign.RIGHT,
                        ),
                    ],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=12,
                )
                for grupo, cuantas in sorted(
                    cuenta.items(), key=lambda par: par[1], reverse=True
                )
            ]
            cuerpo = ft.Column(filas, spacing=10)

        piezas: list[ft.Control] = [
            componentes.cabecera_tarjeta(
                self.paleta, "Series por grupo", "Todo el historial"
            ),
            cuerpo,
        ]
        if huerfanas:
            # SE DICE, NO SE REPARTE. Meterlas en un grupo cualquiera haría que
            # el reparto dejara de ser cierto sin que se notara.
            piezas.append(
                componentes.aviso(
                    self.paleta,
                    [
                        f"{huerfanas} series son de ejercicios que ya no están en "
                        "la biblioteca, así que no tienen grupo y no se cuentan "
                        "aquí. Siguen en su entreno."
                    ],
                )
            )
        return componentes.tarjeta(self.paleta, ft.Column(piezas, spacing=18))

    def _por_ejercicio(self) -> ft.Control:
        elegido = getattr(self.pantalla, "ejercicio_mirado", None)
        if elegido is None and self.pantalla.ejercicios:
            elegido = self.pantalla.ejercicios[0].id

        selector = componentes.selector(
            self.paleta,
            "Ejercicio",
            [(str(uno.id), uno.nombre) for uno in self.pantalla.ejercicios],
            valor=str(elegido) if elegido else None,
            ancho=300,
        )
        selector.on_select = lambda _, s=selector: self._elegir(s.value)

        if elegido is None:
            return componentes.tarjeta(
                self.paleta,
                componentes.aviso_vacio(
                    self.paleta, "No hay ejercicios en la biblioteca.", alto=100
                ),
            )

        with conectado() as conexion:
            historial = repositorio_gimnasio.historial_de(conexion, int(elegido))

        marca = mejor_marca(historial)
        puntos = peso_maximo_por_mes(historial)

        cabecera: list[ft.Control] = [
            ft.Row(
                [selector, ft.Container(expand=True)],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            )
        ]

        if marca is None:
            cabecera.append(
                componentes.aviso_vacio(
                    self.paleta,
                    "Todavía no has marcado ninguna serie con peso en este ejercicio.",
                    alto=120,
                )
            )
            return componentes.tarjeta(self.paleta, ft.Column(cabecera, spacing=18))

        cabecera.append(
            ft.Row(
                [
                    componentes.cifra(
                        self.paleta,
                        "Mejor serie",
                        marca.texto(),
                        ayuda=f"el {marca.fecha.day}/{marca.fecha.month}/{marca.fecha.year}",
                    ),
                    componentes.cifra(
                        self.paleta, "Veces hecho", str(len(historial))
                    ),
                ],
                spacing=40,
            )
        )

        tope = max((peso for _, peso in puntos), default=0)
        cabecera.append(
            ft.Row(
                [
                    self._barra(
                        peso,
                        tope,
                        f"{MESES_CORTOS[mes.month - 1]} {str(mes.year)[2:]}",
                        texto_peso(peso),
                        self.paleta.acento,
                    )
                    for mes, peso in puntos
                ],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.END,
                scroll=ft.ScrollMode.AUTO,
            )
        )
        return componentes.tarjeta(self.paleta, ft.Column(cabecera, spacing=18))

    def _elegir(self, valor: str | None) -> None:
        self.pantalla.ejercicio_mirado = int(valor) if valor else None
        self.pantalla.refrescar()

    # ------------------------------------------------------------------

    def _barra(
        self, valor: int, tope: int, etiqueta: str, ayuda: str, color: str
    ) -> ft.Control:
        """Una barra con su rótulo debajo.

        Con dos píxeles de alto mínimo: una barra de valor pequeño pero no cero
        tiene que verse, porque "poco" y "nada" no son lo mismo y la diferencia
        importa justo cuando se está volviendo de una lesión.
        """
        alto = max(2, round(valor / tope * ALTO_BARRA)) if tope else 2
        return ft.Column(
            [
                ft.Container(
                    width=ANCHO_BARRA,
                    height=alto,
                    bgcolor=color,
                    border_radius=6,
                    tooltip=ayuda,
                ),
                ft.Text(
                    etiqueta,
                    size=estilo.ROTULO,
                    color=self.paleta.muted,
                    text_align=ft.TextAlign.CENTER,
                    width=ANCHO_BARRA + 6,
                ),
            ],
            spacing=6,
            tight=True,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
