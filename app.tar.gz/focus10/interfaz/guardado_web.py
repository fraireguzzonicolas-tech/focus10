"""El guardado automático cuando la aplicación corre dentro de un navegador.

QUÉ RESUELVE: en el navegador el archivo de datos vive en memoria y se borra al
recargar. Aquí se decide CUÁNDO copiarlo al almacén que sí sobrevive.

EN WINDOWS NO HACE ABSOLUTAMENTE NADA: el archivo ya está en el disco.

LAS TRES COSAS QUE PASAN, en este orden:

  1. AL ARRANCAR se recupera el archivo del almacén, ANTES de que nadie abra la
     base. Ese orden no es un detalle: la aplicación lee ajustes —el tema, el
     estilo, la jornada— nada más empezar, y si lo hiciera antes de recuperar,
     encontraría una base vacía, la crearía de cero y machacaría lo guardado.

  2. CADA POCOS SEGUNDOS, si hay algo escrito sin guardar, se vuelca. No en cada
     clic: volcar son 240 KB en una base con uso real, y hacerlo en cada tecla
     sería escribir lo mismo doscientas veces por minuto.

  3. AL IRSE (cambiar de pestaña, minimizar, cerrar) se vuelca en el acto, sin
     esperar al turno. Es lo que reduce lo que se puede perder.

LO QUE AUN ASÍ SE PUEDE PERDER, y conviene decirlo claro: si alguien mata la
pestaña de golpe en el segundo justo entre un cambio y su guardado, ese cambio
se va. Con el aviso de "me voy" la ventana es de milisegundos, pero no es cero.
En el ordenador esto no pasa, porque ahí se escribe en el disco al momento.
"""

from __future__ import annotations

import asyncio

import flet as ft

from ..datos import bd, rutas
from ..sistema import almacen_navegador

CADA_CUANTO = 3.0
"""Segundos entre revisiones.

Tres es el equilibrio: bastante poco para que perder ese rato no duela, y
bastante para que escribir una frase entera acabe en UN volcado y no en veinte.
"""


async def restaurar() -> int:
    """Trae la base guardada al archivo. Devuelve los bytes recuperados.

    HAY QUE LLAMARLA ANTES DE ABRIR LA BASE. Devuelve 0 si no había nada, que es
    lo que pasa la primera vez que alguien abre el link: no es un error, es un
    usuario nuevo.
    """
    if not almacen_navegador.en_el_navegador():
        return 0
    recuperados = await almacen_navegador.cargar(rutas.ruta_bd())
    # ESTE RASTRO SE QUEDA a proposito: dentro de un navegador no hay forma de
    # mirar que ha pasado si no lo cuenta el propio programa, y "no me aparecen
    # mis cosas" es la queja que mas va a costar diagnosticar en el movil de
    # otra persona. En el ordenador no se imprime nunca: se sale antes.
    print(f"Focus10: recuperados {recuperados} bytes del navegador")
    return recuperados


async def guardar_ahora() -> int:
    """Vuelca la base si hay algo que volcar. Devuelve los bytes escritos.

    EL AVISO SE BORRA ANTES DE LEER EL ARCHIVO, y el orden importa: si se
    borrara al final, un cambio hecho MIENTRAS se guardaba quedaría fuera del
    volcado y además sin aviso, así que no se guardaría nunca. Borrándolo antes,
    ese cambio vuelve a marcar el aviso y entra en el volcado siguiente. Como
    mucho se guarda dos veces; nunca se pierde uno.
    """
    if not almacen_navegador.en_el_navegador():
        return 0
    if not bd.hay_cambios():
        return 0

    bd.olvidar_cambios()
    try:
        escritos = await almacen_navegador.guardar(rutas.ruta_bd())
        print(f"Focus10: guardados {escritos} bytes en el navegador")
        return escritos
    except Exception:
        # SI FALLA SE VUELVE A MARCAR: perder el aviso por un fallo del
        # navegador dejaría los cambios en memoria para siempre.
        bd.marcar_cambio()
        raise


def arrancar(pagina: ft.Page) -> None:
    """Pone en marcha el guardado automático. En Windows no hace nada."""
    if not almacen_navegador.en_el_navegador():
        return

    async def cuando_se_va(evento) -> None:
        # HIDE, PAUSE y DETACH son las tres formas de irse: cambiar de pestaña,
        # mandar la aplicación al fondo y cerrarla. En las tres se vuelca ya.
        if evento.data in (
            ft.AppLifecycleState.HIDE,
            ft.AppLifecycleState.PAUSE,
            ft.AppLifecycleState.DETACH,
        ):
            await guardar_ahora()

    pagina.on_app_lifecycle_state_change = cuando_se_va
    pagina.run_task(_vigilar)


async def _vigilar() -> None:
    """Mira cada pocos segundos si hay algo que guardar.

    NO SE CAE NUNCA: si un volcado falla —el navegador puede quedarse sin sitio—
    se sigue intentando en el turno siguiente. Un guardado automático que se
    apaga al primer tropiezo es peor que no tenerlo, porque nadie se entera.
    """
    while True:
        await asyncio.sleep(CADA_CUANTO)
        try:
            await guardar_ahora()
        except Exception:
            pass
