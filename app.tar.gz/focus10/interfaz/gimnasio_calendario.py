"""El calendario del gimnasio: la vista de CALENDARIO.

SU PROPIO CALENDARIO, aparte del de los hábitos, y lo pidió así el usuario. Aquí
un día no es "cumplido o no": puede ser un entreno hecho, uno planeado que aún no
ha llegado, un descanso, o un día en que tocaba y no se fue. Cuatro estados que en
una rejilla de hábitos no caben.

LO QUE NO SE PINTA: un día pasado en el que tocaba entrenar y no se entrenó NO
sale en rojo. Sale apagado, con el nombre del día que tocaba. No es lo mismo
informar que regañar, y esta aplicación no está para reñir a nadie.
"""

from __future__ import annotations

from calendar import monthrange
from datetime import date

import flet as ft

from ..datos import repositorio_gimnasio
from ..datos.bd import conectado
from ..dominio.rutina import dia_de
from ..dominio.sesion import texto_volumen
from . import componentes, estilo

LADO = 82
"""El lado de una casilla. Grande a propósito: dentro va el nombre del día de
rutina, no solo el número."""

LETRAS = ("L", "M", "X", "J", "V", "S", "D")


def vista(pantalla) -> list[ft.Control]:
    return _Vista(pantalla).piezas()


class _Vista:
    def __init__(self, pantalla) -> None:
        self.pantalla = pantalla
        self.paleta = pantalla.paleta

    def piezas(self) -> list[ft.Control]:
        primero = self.pantalla._primero_del_mes()
        _, cuantos = monthrange(primero.year, primero.month)
        ultimo = primero.replace(day=cuantos)

        with conectado() as conexion:
            sesiones = {
                una.fecha: una
                for una in repositorio_gimnasio.sesiones_entre(conexion, primero, ultimo)
            }

        return [
            self._navegacion(),
            componentes.tarjeta(
                self.paleta,
                ft.Column(
                    [self._cabecera_dias(), *self._semanas(primero, cuantos, sesiones)],
                    spacing=6,
                ),
            ),
            self._resumen(sesiones),
        ]

    def _navegacion(self) -> ft.Control:
        return ft.Row(
            [
                ft.Container(expand=True),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.CHEVRON_LEFT,
                    ayuda="Mes anterior",
                    al_pulsar=lambda _: self._mover(1),
                ),
                componentes.boton(
                    self.paleta, "Este mes", al_pulsar=lambda _: self._mover_a_hoy()
                ),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.CHEVRON_RIGHT,
                    ayuda="Mes siguiente",
                    al_pulsar=lambda _: self._mover(-1),
                ),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _mover(self, hacia_atras: int) -> None:
        # Nunca hacia el futuro más allá de este mes: no hay nada que ver ahí.
        self.pantalla.mes_mirado = max(0, self.pantalla.mes_mirado + hacia_atras)
        self.pantalla.refrescar()

    def _mover_a_hoy(self) -> None:
        self.pantalla.mes_mirado = 0
        self.pantalla.refrescar()

    def _cabecera_dias(self) -> ft.Control:
        return ft.Row(
            [
                ft.Container(
                    content=ft.Text(
                        letra,
                        size=estilo.ROTULO,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.muted,
                    ),
                    width=LADO,
                    alignment=ft.Alignment.CENTER,
                )
                for letra in LETRAS
            ],
            spacing=6,
        )

    def _semanas(self, primero: date, cuantos: int, sesiones: dict) -> list[ft.Control]:
        # Los huecos del principio: si el mes empieza en jueves, tres casillas
        # vacías antes. Sin ellos, los días no caerían bajo su letra.
        casillas: list[ft.Control] = [
            ft.Container(width=LADO, height=LADO) for _ in range(primero.weekday())
        ]
        casillas += [
            self._casilla(primero.replace(day=numero), sesiones)
            for numero in range(1, cuantos + 1)
        ]
        while len(casillas) % 7:
            casillas.append(ft.Container(width=LADO, height=LADO))

        return [
            ft.Row(casillas[inicio : inicio + 7], spacing=6)
            for inicio in range(0, len(casillas), 7)
        ]

    def _casilla(self, dia: date, sesiones: dict) -> ft.Control:
        paleta = self.paleta
        hoy = self.pantalla.hoy
        sesion = sesiones.get(dia)
        planeado = dia_de(dia, self.pantalla.rutina)

        entrenado = sesion is not None and sesion.entrenado
        futuro = dia > hoy

        if entrenado:
            fondo = estilo.con_opacidad(self.pantalla.paleta.color_de(sesion.color), 0.22)
            texto_color = paleta.ink
            rotulo = sesion.titulo()
        elif planeado.es_descanso:
            fondo = None
            texto_color = paleta.muted
            rotulo = "Descanso"
        elif planeado.hay_entreno:
            fondo = None
            texto_color = paleta.ink_soft if futuro else paleta.muted
            rotulo = planeado.titulo()
        else:
            fondo = None
            texto_color = paleta.muted
            rotulo = ""

        dentro: list[ft.Control] = [
            ft.Text(
                str(dia.day),
                size=estilo.TEXTO_TARJETA,
                weight=ft.FontWeight.W_600 if dia == hoy else ft.FontWeight.W_400,
                color=texto_color,
            )
        ]
        if rotulo:
            dentro.append(
                ft.Text(
                    rotulo,
                    size=estilo.ROTULO,
                    color=texto_color,
                    max_lines=1,
                    overflow=ft.TextOverflow.ELLIPSIS,
                )
            )
        if entrenado:
            dentro.append(
                ft.Text(
                    f"{sesion.series_hechas} series",
                    size=estilo.ROTULO,
                    color=paleta.muted,
                )
            )

        return ft.Container(
            content=ft.Column(dentro, spacing=1, tight=True),
            width=LADO,
            height=LADO,
            padding=8,
            bgcolor=fondo,
            border=(
                ft.Border.all(2, paleta.acento)
                if dia == hoy
                else ft.Border.all(1, paleta.borde)
            ),
            border_radius=10,
            on_click=lambda _, d=dia: self.pantalla.abrir_dia(d),
            ink=True,
            tooltip=_ayuda(dia, sesion, planeado),
        )

    def _resumen(self, sesiones: dict) -> ft.Control:
        entrenados = [una for una in sesiones.values() if una.entrenado]
        volumen = sum(una.volumen for una in entrenados)
        return componentes.tarjeta(
            self.paleta,
            ft.Row(
                [
                    componentes.cifra(
                        self.paleta, "Entrenos este mes", str(len(entrenados))
                    ),
                    componentes.cifra(
                        self.paleta,
                        "Series",
                        str(sum(una.series_hechas for una in entrenados)),
                    ),
                    componentes.cifra(self.paleta, "Volumen", texto_volumen(volumen)),
                ],
                spacing=40,
            ),
        )


def _ayuda(dia: date, sesion, planeado) -> str:
    if sesion is not None and sesion.entrenado:
        return f"{sesion.titulo()} · {sesion.series_hechas} series hechas"
    if planeado.es_descanso:
        return "Descanso"
    if planeado.hay_entreno:
        return f"Tocaba: {planeado.titulo()}"
    return "Sin nada asignado"
