"""Cuadrar el balance con lo que tienes de verdad en el banco.

LO PIDIÓ EL USUARIO ASÍ: "el usar el lápiz debe ser algo excepcional; el balance
tiene que estar anclado a los gastos e ingresos, pero por algún motivo que
desconozco tengo menos en el banco que en el balance, y quiero modificar eso sin
agregar un gasto fantasma".

POR ESO NO SE ESCRIBE EL BALANCE, SE ESCRIBE LO QUE HAY EN EL BANCO. Tú sabes lo
que dice tu banco; la diferencia la calcula la aplicación. Pedirte "el ajuste"
sería pedirte que hicieras tú la resta, y a mano se hace mal.

Y LA DIFERENCIA SE GUARDA COMO CUADRE, no como gasto ni como ingreso: un gasto
fantasma de 90 € ensuciaría el total de gastos del mes, que es un dato que sí te
crees, y el círculo de "en qué se me va el dinero" diría que se te fue en algo.

EL BALANCE SIGUE ANCLADO: si mañana apuntas un gasto de 20 €, el balance baja 20.
El cuadre solo tapa la diferencia que no se explica, y se queda quieto.
"""

from __future__ import annotations

from datetime import datetime
from typing import Callable

import flet as ft

from ..datos import ajustes as ajustes_guardados
from ..datos import repositorio_categorias, repositorio_dias, repositorio_movimientos
from ..datos.bd import conectado
from ..dominio.dinero import formatear, parsear_importe
from ..dominio.guardado import disponible
from ..dominio.movimiento import Movimiento, Tipo
from . import componentes
from .estilo import Paleta

LOS_DOS = (Tipo.CUADRE_MAS, Tipo.CUADRE_MENOS)
"""Los dos sentidos del cuadre. Solo puede haber uno de los dos a la vez."""


def balance_sin_cuadre(movimientos, principal) -> int:
    """Lo que diría el balance si no hubiera ningún cuadre.

    ES CONTRA ESTO CONTRA LO QUE SE COMPARA EL BANCO, y no contra el balance que
    se ve en pantalla. Si se comparara con el que ya lleva el cuadre puesto,
    cuadrar dos veces seguidas duplicaría la corrección: dirías "tengo 500", él
    ya habría restado 90, y volvería a restar otros 90.

    ESTA APARTE PARA PODER PROBARLO. Metido dentro de la ventanita solo se podía
    comprobar abriéndola, y era justo la cuenta que más fácil se rompe.
    """
    return disponible(
        [uno for uno in movimientos if uno.tipo not in LOS_DOS],
        principal=principal,
    ).total


def cuadre_guardado(conexion, jornada) -> Movimiento | None:
    """El cuadre que hubiera de ese mes, o None.

    SE MIRA EL MES Y NO TODA LA VIDA porque el balance es del mes: un cuadre de
    marzo no dice nada de cómo va abril.
    """
    primero = jornada.replace(day=1)
    for tipo in LOS_DOS:
        existentes = repositorio_movimientos.listar(
            conexion, desde=primero, hasta=jornada, tipo=tipo
        )
        if existentes:
            return existentes[0]
    return None


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    al_guardar: Callable[[], None],
) -> ft.AlertDialog:
    """Pregunta cuánto hay en el banco. Devuelve la ventanita para probarla."""
    with conectado() as conexion:
        principal = ajustes_guardados.leer_moneda_principal(conexion)
        hoy = repositorio_dias.jornada_abierta(conexion)
        primero = hoy.replace(day=1)
        del_mes = repositorio_movimientos.listar(
            conexion, desde=primero, hasta=hoy
        )
        categorias = {
            tipo: repositorio_categorias.listar(conexion, tipo=tipo)
            for tipo in LOS_DOS
        }

    if not all(categorias.values()):
        componentes.avisar(
            pagina,
            "No hay categoría de cuadre activa. Actívala o crea una antes.",
        )
        return None

    sin_cuadre = balance_sin_cuadre(del_mes, principal)

    campo = componentes.campo_texto(
        paleta,
        f"Lo que tienes de verdad ({principal.codigo})",
        valor=formatear(sin_cuadre, principal, con_simbolo=False),
        ancho=300,
    )
    aviso = ft.Text("", size=12, color=paleta.negativo, visible=False)

    def guardar(_):
        escrito = (campo.value or "").strip()
        with conectado() as conexion:
            viejo = cuadre_guardado(conexion, hoy)

            if not escrito:
                # VACIO QUITA EL CUADRE: es como se dice "olvídalo, que el
                # balance vuelva a ser la cuenta pura".
                if viejo is not None:
                    repositorio_movimientos.borrar(conexion, viejo.id)
                pagina.pop_dialog()
                al_guardar()
                return

            real = parsear_importe(escrito, principal)
            if real is None:
                aviso.value = "No entiendo ese importe. Ejemplo: 1.250,40"
                aviso.visible = True
                pagina.update()
                return

            diferencia = real - sin_cuadre
            if viejo is not None:
                repositorio_movimientos.borrar(conexion, viejo.id)
            if diferencia:
                # EL SIGNO LO DICE EL TIPO, como en todo el programa: el importe
                # que se guarda es siempre positivo.
                tipo = Tipo.CUADRE_MAS if diferencia > 0 else Tipo.CUADRE_MENOS
                repositorio_movimientos.guardar(
                    conexion,
                    Movimiento.nuevo(
                        tipo=tipo,
                        importe=abs(diferencia),
                        categoria_id=categorias[tipo][0].id,
                        momento=datetime.now(),
                        jornada=hoy,
                        moneda=principal,
                        principal=principal,
                        descripcion="Diferencia con lo que hay en el banco",
                    ),
                )
        pagina.pop_dialog()
        al_guardar()

    ventanita = componentes.dialogo(
        paleta,
        "Cuadrar con el banco",
        ft.Column(
            [
                ft.Text(
                    "Escribe lo que tienes de verdad. La diferencia se guarda "
                    "aparte: NO cuenta como gasto ni como ingreso, así que tus "
                    "totales del mes no se tocan.",
                    size=12,
                    color=paleta.muted,
                ),
                ft.Text(
                    f"Ahora la cuenta da {formatear(sin_cuadre, principal)}.",
                    size=12,
                    color=paleta.ink_soft,
                ),
                campo,
                aviso,
            ],
            spacing=12,
            tight=True,
            width=340,
        ),
        pagina=pagina,
        al_aceptar=guardar,
    )
    pagina.show_dialog(ventanita)
    return ventanita
