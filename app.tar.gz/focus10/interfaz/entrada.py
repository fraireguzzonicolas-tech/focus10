"""La puerta: lo primero que se ve si todavía no has entrado en este aparato.

LO PIDIÓ EL USUARIO: sin cuenta no se pasa. La aplicación no se abre hasta que
hay una sesión guardada.

MIRA SI YA ENTRASTE EN ESTE APARATO, NO SI HAY INTERNET. Y esa diferencia es
todo el diseño de esta pantalla. Preguntarle al servidor en cada arranque
dejaría a alguien sin poder mirar lo que apuntó ayer porque el wifi del hotel va
mal, y esta aplicación se usa justo ahí. Así que:

  - La PRIMERA vez hace falta conexión. No hay forma de crear una cuenta sin
    ella, y fingir que la hay sería mentir.
  - A partir de ahí la sesión queda guardada y la aplicación abre sin conexión,
    igual que siempre.
  - Solo se vuelve aquí al pulsar "Cerrar sesión", que es una decisión tuya.

NO REPITE LOS CAMPOS DE CONFIGURACIÓN: usa la MISMA `TarjetaCuenta`. Dos
formularios de entrada en la misma aplicación son dos sitios donde arreglar el
mismo fallo, y el segundo siempre se olvida.
"""

from __future__ import annotations

import flet as ft

from .. import NOMBRE
from . import estilo
from .cuenta import TarjetaCuenta
from .estilo import Paleta

ANCHO = 420
"""Lo que mide la columna del centro.

NO SE ESTIRA CON LA VENTANA a propósito: un campo de texto de mil puntos de
ancho para escribir un correo se ve roto, y en un monitor grande obliga a mover
la cabeza de un lado a otro para leer dos renglones.
"""


class PantallaEntrada:
    """Entrar o crear la cuenta, y nada más.

    NO TIENE MENÚ NI BARRA. Es la única pantalla de toda la aplicación sin
    salida: enseñar los ocho apartados detrás de una puerta cerrada solo sirve
    para que alguien los pulse y no pase nada.
    """

    def __init__(self, pagina: ft.Page, paleta: Paleta, al_entrar) -> None:
        self.pagina = pagina
        self.paleta = paleta
        # LA TARJETA SE CREA UNA VEZ y vive con la puerta, porque guarda dentro
        # el correo escrito. Si se rehiciera en cada repintado, un "esa
        # contraseña es corta" borraría el correo recién tecleado.
        self.tarjeta = TarjetaCuenta(
            pagina, paleta, al_entrar, al_cambiar_sesion=al_entrar
        )

    def control(self, paleta: Paleta) -> ft.Control:
        """La puerta entera, centrada en la ventana."""
        self.paleta = paleta
        self.tarjeta.paleta = paleta

        return ft.Container(
            content=ft.Column(
                [
                    self._marca(paleta),
                    ft.Text(
                        "Entra con tu cuenta para empezar. Si todavía no tienes, "
                        "créala aquí mismo: son un correo y una contraseña.",
                        size=estilo.TEXTO_APOYO,
                        color=paleta.muted,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    ft.Container(height=8),
                    self.tarjeta.control(),
                    ft.Text(
                        "La primera vez hace falta internet. Después la "
                        "aplicación abre sin conexión.",
                        size=estilo.TEXTO_APOYO,
                        color=paleta.muted,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ],
                spacing=12,
                width=ANCHO,
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            alignment=ft.Alignment.CENTER,
            padding=24,
            expand=True,
            bgcolor=paleta.canvas,
        )

    def _marca(self, paleta: Paleta) -> ft.Control:
        """La F y el nombre, en grande.

        SE DIBUJA AQUI Y NO SE SACA DE LA BARRA LATERAL porque no es la misma
        pieza: alli es una etiqueta de 30 puntos en una esquina, y aqui es lo
        unico que hay en la pantalla. Compartirlas obligaria a la de la esquina
        a llevar un tamano por parametro para un solo uso.
        """
        return ft.Column(
            [
                ft.Container(
                    content=ft.Text(
                        "F",
                        size=30,
                        weight=ft.FontWeight.BOLD,
                        color=paleta.acento_ink,
                    ),
                    width=64,
                    height=64,
                    bgcolor=paleta.acento,
                    border_radius=estilo.RADIO_BOTON,
                    alignment=ft.Alignment.CENTER,
                ),
                ft.Text(
                    NOMBRE,
                    size=22,
                    weight=ft.FontWeight.W_600,
                    color=paleta.ink,
                ),
            ],
            spacing=10,
            tight=True,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
