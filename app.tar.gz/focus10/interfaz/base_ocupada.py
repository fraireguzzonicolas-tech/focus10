"""Si la base sigue ocupada, un aviso en vez de la pantalla roja (4 nov 2026).

QUÉ PASA SIN ESTO: cuando un toque falla, Flet manda la pantalla roja de
«The application encountered an error» y la sesión queda muerta: hay que
cerrar y abrir Focus. Por una base ocupada eso es desproporcionado. Las
escrituras ya esperan su turno hasta 5 segundos (ver datos/conexion.py), así
que esto solo salta si ni así se pudo, y lo único perdido es ese toque.

SOLO ESE ERROR. Cualquier otro sigue saliendo como siempre: esconder fallos
de verdad sería mucho peor que la pantalla roja.

POR QUÉ AQUÍ Y NO EN CADA BOTÓN: los toques que escriben son cientos. Flet
pasa todos los errores de los toques por un mismo sitio, session.error, y es
ahí donde se mira.
"""

from __future__ import annotations

import flet as ft

from . import componentes

SENAL = "database is locked"
"""Lo que dice SQLite cuando no le tocó el turno de escritura."""

AVISO = "No se pudo guardar: Focus estaba sincronizando. Tocá de nuevo."


def vigilar(pagina: ft.Page) -> None:
    """Cambia la pantalla roja por un aviso, solo para la base ocupada."""
    sesion = getattr(pagina, "session", None)
    original = getattr(sesion, "error", None)
    # SI FLET CAMBIA POR DENTRO Y YA NO HAY session.error, no se toca nada: la
    # app sigue funcionando igual, solo que sin este aviso más amable.
    if original is None:
        return

    def error(mensaje: str) -> None:
        if SENAL in str(mensaje):
            componentes.avisar(pagina, AVISO)
        else:
            original(mensaje)

    sesion.error = error
