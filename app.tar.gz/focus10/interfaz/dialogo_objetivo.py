"""Las ventanitas de objetivos: crear uno y apartar dinero.

EL "POR QUÉ LO QUIERO" VA GRANDE Y CON SU EXPLICACIÓN. No es un campo de notas al
final del formulario: es lo que se lee en el Dashboard cada mañana, y es la razón
de que el objetivo siga vivo dentro de tres meses. Ponerlo pequeño y el último
sería tratarlo como lo que no es.

EL IMPORTE SOLO APARECE EN LOS OBJETIVOS DE DINERO. Un objetivo libre no tiene
importe —ni cero, ni vacío: no lo tiene— y enseñar una casilla desactivada
invitaría a preguntarse qué poner ahí.
"""

from __future__ import annotations

from datetime import date

import flet as ft

from ..datos import repositorio_objetivos as repo
from ..datos.bd import conectado
from ..dominio.dinero import formatear, parsear_importe
from ..dominio.habito import COLORES
from ..dominio.moneda import EUR
from ..dominio.objetivo import Aportacion, Objetivo, TipoObjetivo
from . import componentes

ANCHO = 420


def abrir(pagina, paleta, al_guardar, objetivo: Objetivo | None = None) -> None:
    _DialogoObjetivo(pagina, paleta, al_guardar, objetivo).mostrar()


def abrir_aportacion(pagina, paleta, objetivo: Objetivo, al_guardar) -> None:
    _DialogoAportacion(pagina, paleta, objetivo, al_guardar).mostrar()


class _DialogoObjetivo:
    def __init__(self, pagina, paleta, al_guardar, objetivo) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.al_guardar = al_guardar
        self.objetivo = objetivo
        self.tipo = objetivo.tipo if objetivo else TipoObjetivo.DINERO
        self.color = objetivo.color if objetivo else COLORES[0]

        self.nombre = componentes.campo_texto(
            paleta, "Nombre", valor=objetivo.nombre if objetivo else "",
            pista="Viaje a Japón",
        )
        self.porque = componentes.campo_texto(
            paleta,
            "Por qué lo quiero",
            valor=objetivo.porque if objetivo else "",
            pista="para irme dos meses sin pedir permiso a nadie",
        )
        self.porque.multiline = True
        self.porque.min_lines = 2
        self.porque.max_lines = 4

        self.importe = componentes.campo_texto(
            paleta,
            "Cuánto quiero juntar (€)",
            valor=formatear(objetivo.importe_objetivo, EUR, con_simbolo=False)
            if objetivo and objetivo.importe_objetivo
            else "",
            pista="6000",
        )
        self.fecha = componentes.campo_texto(
            paleta,
            "Fecha límite (opcional)",
            valor=str(objetivo.fecha_limite) if objetivo and objetivo.fecha_limite else "",
            pista="2026-06-01",
        )
        self.error = ft.Text("", size=12, color=paleta.negativo, visible=False)

    def mostrar(self) -> None:
        self.pagina.show_dialog(self.control)

    def _repintar(self) -> None:
        self.pagina.pop_dialog()
        self.mostrar()

    @property
    def control(self) -> ft.AlertDialog:
        piezas: list[ft.Control] = [
            self.nombre,
            ft.Text("¿De qué tipo?", size=12, color=self.paleta.muted),
            self._elegir_tipo(),
        ]
        # El importe SOLO en los de dinero: una casilla desactivada invitaría a
        # preguntarse qué poner ahí.
        if self.tipo is TipoObjetivo.DINERO:
            piezas.append(self.importe)

        piezas += [
            self.fecha,
            componentes.separador(self.paleta),
            ft.Text(
                "Esto es lo que vas a leer cada mañana en el Dashboard. "
                "«Ahorrar 6000» no mueve a nadie; el motivo de verdad, sí.",
                size=11,
                color=self.paleta.muted,
            ),
            self.porque,
            componentes.separador(self.paleta),
            ft.Text("Color", size=12, color=self.paleta.muted),
            self._elegir_color(),
            self.error,
        ]

        if self.objetivo is not None:
            piezas += [
                ft.Container(height=4),
                componentes.boton(
                    self.paleta,
                    "Borrar el objetivo y sus aportaciones",
                    icono=ft.Icons.DELETE_OUTLINE,
                    al_pulsar=lambda _: self._pedir_borrado(),
                ),
            ]

        return componentes.dialogo(
            self.paleta,
            "Corregir objetivo" if self.objetivo else "Nuevo objetivo",
            ft.Column(piezas, spacing=10, tight=True, width=ANCHO,
                      scroll=ft.ScrollMode.AUTO),
            pagina=self.pagina,
            al_aceptar=lambda _: self._guardar(),
        )

    def _elegir_tipo(self) -> ft.Control:
        textos = {
            TipoObjetivo.DINERO: "De dinero",
            TipoObjetivo.LIBRE: "Libre",
        }
        return ft.Column(
            [
                ft.Row(
                    [
                        ft.Container(
                            content=ft.Text(
                                textos[uno],
                                size=12,
                                color=self.paleta.acento_ink
                                if uno is self.tipo
                                else self.paleta.ink_soft,
                            ),
                            padding=ft.Padding.symmetric(horizontal=12, vertical=7),
                            bgcolor=self.paleta.acento
                            if uno is self.tipo
                            else self.paleta.surface_2,
                            border_radius=8,
                            on_click=lambda _, t=uno: self._cambiar_tipo(t),
                            ink=True,
                        )
                        for uno in TipoObjetivo
                    ],
                    spacing=6,
                ),
                ft.Text(
                    "Avanza con el dinero que vayas apartando."
                    if self.tipo is TipoObjetivo.DINERO
                    else "Avanza con el porcentaje que pongas tú, de diez en diez.",
                    size=11,
                    color=self.paleta.muted,
                ),
            ],
            spacing=4,
            tight=True,
        )

    def _cambiar_tipo(self, tipo: TipoObjetivo) -> None:
        self.tipo = tipo
        self._repintar()

    def _elegir_color(self) -> ft.Control:
        return ft.Row(
            [
                ft.Container(
                    width=28,
                    height=28,
                    bgcolor=self.paleta.color_de(uno),
                    border_radius=14,
                    border=ft.Border.all(
                        3 if uno == self.color else 0, self.paleta.ink
                    )
                    if uno == self.color
                    else None,
                    on_click=lambda _, c=uno: self._cambiar_color(c),
                    ink=True,
                )
                for uno in COLORES
            ],
            spacing=8,
            wrap=True,
        )

    def _cambiar_color(self, color: str) -> None:
        self.color = color
        self._repintar()

    def _avisar(self, texto: str) -> None:
        self.error.value = texto
        self.error.visible = True
        try:
            self.error.update()
        except Exception:  # noqa: BLE001
            self._repintar()

    def _guardar(self) -> None:
        importe = 0
        if self.tipo is TipoObjetivo.DINERO and (self.importe.value or "").strip():
            importe = parsear_importe(self.importe.value, EUR)
            if importe is None or importe < 0:
                self._avisar("No entiendo el importe. Escríbelo como 6000 o 6.000,00.")
                return

        fecha = None
        escrita = (self.fecha.value or "").strip()
        if escrita:
            try:
                fecha = date.fromisoformat(escrita)
            except ValueError:
                self._avisar("La fecha se escribe como 2026-06-01.")
                return

        try:
            objetivo = Objetivo(
                id=self.objetivo.id if self.objetivo else None,
                nombre=self.nombre.value or "",
                color=self.color,
                tipo=self.tipo,
                porque=self.porque.value or "",
                importe_objetivo=importe,
                # Al cambiar de dinero a libre, el avance a mano se queda como
                # estaba; al revés se pone a cero, porque un objetivo de dinero
                # no lo lleva.
                avance_manual=(
                    self.objetivo.avance_manual
                    if (self.objetivo and self.tipo is TipoObjetivo.LIBRE)
                    else 0
                ),
                fecha_limite=fecha,
                cumplido_en=self.objetivo.cumplido_en if self.objetivo else None,
                orden=self.objetivo.orden if self.objetivo else 0,
            )
        except (ValueError, TypeError) as fallo:
            self._avisar(str(fallo))
            return

        with conectado() as conexion:
            if objetivo.id is None:
                repo.crear(conexion, objetivo)
            else:
                repo.actualizar(conexion, objetivo)

        self.pagina.pop_dialog()
        self.al_guardar()

    def _pedir_borrado(self) -> None:
        self.pagina.pop_dialog()
        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo="Borrar el objetivo",
            texto=(
                f"Se borra «{self.objetivo.nombre}» y todo lo que hayas apartado "
                "para él. No se puede deshacer."
            ),
            al_aceptar=lambda _: self._borrar(),
        )

    def _borrar(self) -> None:
        with conectado() as conexion:
            repo.borrar(conexion, self.objetivo.id)
        self.pagina.pop_dialog()
        self.al_guardar()


class _DialogoAportacion:
    """Apartar dinero para un objetivo. NO es un gasto: ver dominio/objetivo.py."""

    def __init__(self, pagina, paleta, objetivo, al_guardar) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.objetivo = objetivo
        self.al_guardar = al_guardar
        self.sacar = False

        self.importe = componentes.campo_texto(paleta, "Cuánto (€)", pista="200")
        self.fecha = componentes.campo_texto(
            paleta, "Fecha", valor=str(date.today()), pista="2025-08-19"
        )
        self.nota = componentes.campo_texto(
            paleta, "Nota (opcional)", pista="paga extra"
        )
        self.error = ft.Text("", size=12, color=paleta.negativo, visible=False)

    def mostrar(self) -> None:
        self.pagina.show_dialog(self.control)

    @property
    def control(self) -> ft.AlertDialog:
        return componentes.dialogo(
            self.paleta,
            self.objetivo.nombre,
            ft.Column(
                [
                    self._elegir_sentido(),
                    self.importe,
                    self.fecha,
                    self.nota,
                    ft.Text(
                        "Apartar dinero para un objetivo NO es un gasto: no aparece "
                        "en Finanzas. Ese dinero lo sigues teniendo, solo que "
                        "reservado.",
                        size=11,
                        color=self.paleta.muted,
                    ),
                    self.error,
                ],
                spacing=10,
                tight=True,
                width=ANCHO,
            ),
            pagina=self.pagina,
            texto_aceptar="Apuntar",
            al_aceptar=lambda _: self._guardar(),
        )

    def _elegir_sentido(self) -> ft.Control:
        return ft.Row(
            [
                ft.Container(
                    content=ft.Text(
                        texto,
                        size=12,
                        color=self.paleta.acento_ink
                        if saca == self.sacar
                        else self.paleta.ink_soft,
                    ),
                    padding=ft.Padding.symmetric(horizontal=12, vertical=7),
                    bgcolor=self.paleta.acento
                    if saca == self.sacar
                    else self.paleta.surface_2,
                    border_radius=8,
                    on_click=lambda _, s=saca: self._cambiar(s),
                    ink=True,
                )
                for texto, saca in (("Apartar", False), ("Sacar", True))
            ],
            spacing=6,
        )

    def _cambiar(self, sacar: bool) -> None:
        self.sacar = sacar
        self.pagina.pop_dialog()
        self.mostrar()

    def _guardar(self) -> None:
        importe = parsear_importe(self.importe.value or "", EUR)
        if importe is None or importe <= 0:
            self._avisar("Escribe cuánto, por ejemplo 200.")
            return
        try:
            fecha = date.fromisoformat((self.fecha.value or "").strip())
        except ValueError:
            self._avisar("La fecha se escribe como 2025-08-19.")
            return

        try:
            aportacion = Aportacion(
                objetivo_id=self.objetivo.id,
                importe=-importe if self.sacar else importe,
                fecha=fecha,
                nota=self.nota.value or "",
            )
        except (ValueError, TypeError) as fallo:
            self._avisar(str(fallo))
            return

        with conectado() as conexion:
            repo.aportar(conexion, aportacion)
            # Si con esto se llega a la meta, se da por conseguido con la fecha
            # de hoy: es lo que lo baja de la lista y lo guarda para siempre.
            todas = repo.aportaciones_de(conexion, self.objetivo.id)
            total = sum(una.importe for una in todas)
            meta = self.objetivo.importe_objetivo
            if meta and total >= meta and self.objetivo.cumplido_en is None:
                repo.marcar_cumplido(conexion, self.objetivo.id, date.today())

        self.pagina.pop_dialog()
        self.al_guardar()

    def _avisar(self, texto: str) -> None:
        self.error.value = texto
        self.error.visible = True
        self.error.update()
