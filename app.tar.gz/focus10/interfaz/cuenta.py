"""La tarjeta de la cuenta: entrar, registrarse y salir.

VIVE APARTE DE configuracion.py A PROPÓSITO. Esa pantalla ya pasaba de las
setecientas líneas, y una tarjeta con dos campos, dos botones, tres estados y
llamadas a la red por medio son otras ciento y pico. Aquí se lee entera de una
sentada; allí dentro habría que ir a buscarla.

LA CUENTA ES LA LLAVE DE LA SINCRONIZACIÓN. Con ella, lo que apuntas viaja
solo entre tus aparatos (ver interfaz/sincronizador.py). Esta tarjeta lo dice
en pantalla porque ya es verdad; antes decía que no se sincronizaba nada, y
también era verdad: un texto de aquí nunca promete lo que el código no hace.
"""

from __future__ import annotations

import asyncio
from datetime import datetime

import flet as ft

from ..datos import ajustes, copias, rutas, sincronia
from ..datos.bd import conectado
from ..datos.migraciones import version_actual
from ..dominio.cuenta import (
    CodigoInvalido,
    ContrasenaInvalida,
    CorreoInvalido,
    exigir_codigo,
    exigir_contrasena,
    exigir_correo,
)
from ..sistema import cuentas
from . import componentes, sincronizador, estilo
from .estilo import Paleta


class TarjetaCuenta:
    """El trozo de Configuración que se ocupa de la cuenta.

    NO ES UNA `Pantalla`: no se monta sola ni ocupa la ventana. Es una pieza que
    otra pantalla coloca entre sus tarjetas y que sabe repintarse pidiéndoselo a
    quien la puso, que es lo que hace `al_cambiar`.
    """

    def __init__(
        self, pagina: ft.Page, paleta: Paleta, al_cambiar, al_cambiar_sesion=None
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.al_cambiar = al_cambiar
        # DOS AVISOS DISTINTOS, Y NO UNO, porque no cuesta lo mismo repintar la
        # tarjeta que rehacer la ventana entera. Un "esa contraseña es corta"
        # solo tiene que repintar la tarjeta; entrar o salir cambia QUÉ se ve en
        # toda la aplicación, porque detrás hay una puerta. Si los dos hicieran
        # lo caro, escribir mal la contraseña reharía la ventana y borraría el
        # correo a medio teclear.
        self.al_cambiar_sesion = al_cambiar_sesion or al_cambiar

        # LOS CAMPOS SE CREAN UNA VEZ Y VIVEN CON LA TARJETA. Si se construyeran
        # en cada repintado, enseñar "esa contraseña es corta" borraría el
        # correo recién escrito, que es justo el peor momento para borrarlo.
        self.campo_correo = componentes.campo_texto(
            paleta, "Correo", pista="el tuyo de siempre"
        )
        self.campo_contrasena = componentes.campo_texto(
            paleta,
            "Contraseña",
            pista="al menos 8 letras",
            secreto=True,
        )

        self.campo_codigo = componentes.campo_texto(
            paleta, "Código", pista="cópialo del correo"
        )
        self.campo_nueva = componentes.campo_texto(
            paleta, "Contraseña nueva", pista="al menos 8 letras", secreto=True
        )

        self._error = ""
        self._trabajando = False
        # EN QUÉ PASO ESTÁS: "entrar", "pedir" (te mando el código) o "poner"
        # (escribe el código y la nueva). Un solo dato en vez de tres banderas
        # sueltas, porque los tres pasos se excluyen entre sí y con banderas
        # sueltas siempre acaba habiendo una combinación imposible en pantalla.
        self._paso = "entrar"

    # ------------------------------------------------------------------

    def control(self) -> ft.Control:
        """La tarjeta, en el estado que toque ahora mismo."""
        with conectado() as conexion:
            sesion = ajustes.leer_sesion(conexion)

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(self.paleta, "👤 Tu cuenta"),
                    *self._cuerpo(sesion),
                ],
                spacing=12,
                tight=True,
            ),
        )

    # ------------------------------------------------------------------

    def _cuerpo(self, sesion) -> list[ft.Control]:
        """Lo que toca enseñar ahora mismo.

        SIN SERVICIO NO SE ENSEÑAN LOS CAMPOS, igual que en los comentarios:
        dejar escribir un correo y una contraseña para contestar después que no
        hay dónde mandarlos es la peor forma de decirlo. Se avisa antes.
        """
        if sesion:
            return self._cuerpo_dentro(sesion)
        if not cuentas.hay_servidor():
            return [
                componentes.aviso_vacio(
                    self.paleta,
                    "Esta versión todavía no tiene servicio de cuentas. "
                    "Estará en la siguiente.",
                )
            ]
        if self._paso == "pedir":
            return self._cuerpo_pedir()
        if self._paso == "poner":
            return self._cuerpo_poner()
        return self._cuerpo_fuera()

    def _cuerpo_fuera(self) -> list[ft.Control]:
        """Cuando no has entrado: la explicación, los campos y los dos botones."""
        return [
            ft.Text(
                "Con tu cuenta, lo que apuntas viaja solo entre tus aparatos: "
                "lo del móvil aparece en la computadora, y al revés.",
                size=estilo.TEXTO_APOYO,
                color=self.paleta.muted,
            ),
            self.campo_correo,
            self.campo_contrasena,
            *self._error_si_lo_hay(),
            ft.Row(
                [
                    componentes.boton(
                        self.paleta,
                        "Entrando..." if self._trabajando else "Entrar",
                        icono=ft.Icons.LOGIN_OUTLINED,
                        principal=True,
                        al_pulsar=lambda _: self._intentar(cuentas.entrar),
                    ),
                    componentes.boton(
                        self.paleta,
                        "Crear cuenta",
                        icono=ft.Icons.PERSON_ADD_OUTLINED,
                        al_pulsar=lambda _: self._intentar(cuentas.registrar),
                    ),
                ],
                spacing=10,
                wrap=True,
            ),
            self._enlace(
                "¿Has olvidado la contraseña?", lambda: self._ir_a("pedir")
            ),
        ]

    def _cuerpo_pedir(self) -> list[ft.Control]:
        """Paso 1: a qué correo mandamos el código."""
        return [
            ft.Text(
                "Te mando un código a tu correo. Con él pones una "
                "contraseña nueva.",
                size=estilo.TEXTO_APOYO,
                color=self.paleta.muted,
            ),
            self.campo_correo,
            *self._error_si_lo_hay(),
            componentes.boton(
                self.paleta,
                "Mandándolo..." if self._trabajando else "Mandarme el código",
                icono=ft.Icons.MAIL_OUTLINE,
                principal=True,
                al_pulsar=lambda _: self._mandar_codigo(),
            ),
            self._enlace("Volver", lambda: self._ir_a("entrar")),
        ]

    def _cuerpo_poner(self) -> list[ft.Control]:
        """Paso 2: el código que ha llegado y la contraseña nueva."""
        return [
            ft.Text(
                f"Te he mandado un código a {self.campo_correo.value}. Si no "
                "aparece en un minuto, mira la carpeta de spam. Si pides otro, "
                "el anterior deja de valer: usa siempre el último que te llegue.",
                size=estilo.TEXTO_APOYO,
                color=self.paleta.muted,
            ),
            self.campo_codigo,
            self.campo_nueva,
            *self._error_si_lo_hay(),
            componentes.boton(
                self.paleta,
                "Cambiando..." if self._trabajando else "Cambiar la contraseña",
                icono=ft.Icons.LOCK_RESET,
                principal=True,
                al_pulsar=lambda _: self._cambiar(),
            ),
            ft.Row(
                [
                    # SIN ESTO HABIA QUE VOLVER ATRAS Y EMPEZAR DE CERO para
                    # pedir otro codigo, que es justo lo que hace falta cuando
                    # el correo tarda o se pierde. Se descubrio usandolo.
                    self._enlace(
                        "Mandándolo..." if self._trabajando
                        else "Mandarme otro código",
                        self._mandar_codigo,
                    ),
                    self._enlace("Volver", lambda: self._ir_a("entrar")),
                ],
                spacing=0,
                wrap=True,
            ),
        ]

    def _enlace(self, texto: str, al_pulsar) -> ft.Control:
        """Un texto que se pulsa. NO es un botón a propósito.

        Con forma de botón competiría con "Entrar", que es lo que hace el 99%
        de la gente el 99% de las veces. Olvidar la contraseña pasa una vez.
        """
        return ft.TextButton(
            # EL TEXTO VA EN UN ft.Text Y NO SUELTO EN EL BOTON: suelto lo pinta
            # Flet con su tipografia y su tamano, que no son los de la
            # aplicacion, y ademas se queda fuera de lo que se puede comprobar.
            content=ft.Text(
                texto, size=estilo.TEXTO_APOYO, color=self.paleta.acento
            ),
            on_click=lambda _: al_pulsar(),
        )

    def _ir_a(self, paso: str) -> None:
        """Cambia de paso y limpia el aviso del paso anterior.

        EL AVISO SE LIMPIA porque es del paso que dejas: "esa contraseña es
        corta" colgando encima de "¿a qué correo te lo mando?" no significa nada.
        """
        self._paso = paso
        self._error = ""
        self.al_cambiar()

    def _cuerpo_dentro(self, sesion) -> list[ft.Control]:
        """Cuando ya has entrado: con qué correo, y el botón de salir."""
        return [
            ft.Text(
                f"Has entrado como {sesion.correo}.",
                size=estilo.TEXTO,
                color=self.paleta.ink,
            ),
            ft.Text(
                "Tus datos se sincronizan solos entre tus aparatos: al abrir la "
                "aplicación y al apuntar algo. La nube de arriba, al lado de la "
                "campana, dice cómo va; tocándola se sincroniza en el acto.",
                size=estilo.TEXTO_APOYO,
                color=self.paleta.muted,
            ),
            *self._error_si_lo_hay(),
            ft.Row(
                [
                    componentes.boton(
                        self.paleta,
                        "Cerrar sesión",
                        icono=ft.Icons.LOGOUT_OUTLINED,
                        al_pulsar=lambda _: self._salir(),
                    ),
                    componentes.boton(
                        self.paleta,
                        "Borrar mi cuenta",
                        icono=ft.Icons.DELETE_FOREVER_OUTLINED,
                        al_pulsar=lambda _: self._preguntar_si_borrar(),
                    ),
                ],
                spacing=10,
                wrap=True,
            ),
        ]

    def _error_si_lo_hay(self) -> list[ft.Control]:
        if not self._error:
            return []
        return [componentes.aviso_error(self.paleta, [self._error])]

    # ------------------------------------------------------------------

    def _intentar(self, que_hacer) -> None:
        """Comprueba lo escrito y lo manda, sin congelar la ventana.

        LO ESCRITO SE COMPRUEBA AQUÍ ANTES DE SALIR A LA RED. Un correo sin
        arroba no hace falta mandarlo a Irlanda para saber que está mal, y la
        respuesta es instantánea en vez de tardar dos segundos.
        """
        if self._trabajando:
            return

        correo = self.campo_correo.value or ""
        contrasena = self.campo_contrasena.value or ""
        try:
            exigir_correo(correo)
            exigir_contrasena(contrasena)
        except (CorreoInvalido, ContrasenaInvalida) as fallo:
            self._error = str(fallo)
            self.al_cambiar()
            return

        self._error = ""
        self._trabajando = True
        self.al_cambiar()
        self.pagina.run_task(self._hablar, que_hacer, correo, contrasena)

    async def _hablar(self, que_hacer, correo: str, contrasena: str) -> None:
        """La llamada de verdad, en otro hilo: urllib bloquea.

        LA CONTRASEÑA SE BORRA DEL CAMPO PASE LO QUE PASE, salga bien o mal. Se
        queda escrita en pantalla, con el ojo de destapar al lado, y lo normal
        es dejar el móvil encima de la mesa sin volver a mirarlo. El correo sí
        se conserva: si te equivocaste de contraseña, no tienes que reescribirlo.
        """
        entrado = False
        try:
            sesion = await asyncio.to_thread(
                que_hacer, correo, contrasena, datetime.now()
            )
        except cuentas.NoSePudoEntrar as fallo:
            self._error = str(fallo)
        else:
            self._error = ""
            with conectado() as conexion:
                ajustes.guardar_sesion(conexion, sesion)
            componentes.avisar(self.pagina, f"Has entrado como {sesion.correo}.")
            entrado = True
        finally:
            self.campo_contrasena.value = ""
            self._trabajando = False
            # SI SE HA ENTRADO, LA VENTANA ENTERA CAMBIA: detrás de la puerta
            # está la aplicación, y repintar solo la tarjeta dejaría a la
            # persona mirando el formulario que acaba de rellenar bien.
            (self.al_cambiar_sesion if entrado else self.al_cambiar)()

    def _mandar_codigo(self) -> None:
        """Paso 1: pide que manden el código, sin congelar la ventana."""
        if self._trabajando:
            return
        correo = self.campo_correo.value or ""
        try:
            exigir_correo(correo)
        except CorreoInvalido as fallo:
            self._error = str(fallo)
            self.al_cambiar()
            return

        self._error = ""
        self._trabajando = True
        self.al_cambiar()
        self.pagina.run_task(self._pedirlo, correo)

    async def _pedirlo(self, correo: str) -> None:
        """SE PASA AL PASO 2 AUNQUE EL CORREO NO TENGA CUENTA, y a propósito.

        El servicio contesta lo mismo tenga cuenta o no, para que nadie pueda ir
        probando direcciones y averiguar quién usa la aplicación. Decir aquí
        "ese correo no existe" tiraría por tierra esa protección. Quien se
        equivoque de correo lo verá igual: el código no llega nunca.
        """
        try:
            await asyncio.to_thread(cuentas.pedir_codigo, correo)
        except cuentas.NoSePudoEntrar as fallo:
            self._error = str(fallo)
        else:
            self._error = ""
            self._paso = "poner"
            # EL CODIGO QUE HUBIERA ESCRITO YA NO VALE: pedir uno nuevo anula
            # los anteriores. Dejarlo en pantalla invita a darle a "Cambiar la
            # contrasena" con un codigo muerto y a no entender por que falla.
            self.campo_codigo.value = ""
            componentes.avisar(self.pagina, "Código enviado. Mira tu correo.")
        finally:
            self._trabajando = False
            self.al_cambiar()

    def _cambiar(self) -> None:
        """Paso 2: comprueba lo escrito y cambia la contraseña."""
        if self._trabajando:
            return
        correo = self.campo_correo.value or ""
        codigo = self.campo_codigo.value or ""
        nueva = self.campo_nueva.value or ""
        try:
            exigir_correo(correo)
            exigir_codigo(codigo)
            exigir_contrasena(nueva)
        except (CorreoInvalido, CodigoInvalido, ContrasenaInvalida) as fallo:
            self._error = str(fallo)
            self.al_cambiar()
            return

        self._error = ""
        self._trabajando = True
        self.al_cambiar()
        self.pagina.run_task(self._cambiarla, correo, codigo, nueva)

    async def _cambiarla(self, correo: str, codigo: str, nueva: str) -> None:
        """QUIEN TERMINA ESTO YA ESTA DENTRO.

        El código abre una sesión, y es esa sesión la que cambia la contraseña.
        Como ya la tenemos, hacerle escribirla otra vez para entrar sería pedirle
        dos veces lo mismo en diez segundos.

        LA CONTRASEÑA NUEVA SE BORRA DEL CAMPO PASE LO QUE PASE, igual que al
        entrar: se queda escrita en pantalla con el ojo de destapar al lado.
        """
        cambiada = False
        try:
            sesion = await asyncio.to_thread(
                cuentas.cambiar_contrasena, correo, codigo, nueva, datetime.now()
            )
        except cuentas.NoSePudoEntrar as fallo:
            self._error = str(fallo)
        else:
            self._error = ""
            with conectado() as conexion:
                ajustes.guardar_sesion(conexion, sesion)
            self._paso = "entrar"
            self.campo_codigo.value = ""
            componentes.avisar(
                self.pagina, "Contraseña cambiada. Ya has entrado."
            )
            cambiada = True
        finally:
            self.campo_nueva.value = ""
            self._trabajando = False
            (self.al_cambiar_sesion if cambiada else self.al_cambiar)()

    def _preguntar_si_borrar(self) -> None:
        """Antes de borrar la cuenta se pregunta, y se dice TODO lo que se va.

        AQUÍ SÍ SE PREGUNTA, al revés que al cerrar sesión: esto no se deshace.
        Se cuenta qué se borra, qué no, y que queda una copia en este aparato.
        """
        self.pagina.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text("Borrar tu cuenta de Focus10"),
                content=ft.Text(
                    "Se borra tu cuenta y TODO lo que tiene guardado en el "
                    "servidor: hábitos, gastos, entrenos, comidas.\n\n"
                    "También se vacía este aparato, y los demás se quedarán "
                    "sin poder entrar.\n\n"
                    "ESTO NO SE PUEDE DESHACER. Antes de borrar nada se guarda "
                    "una copia de seguridad en este ordenador, por si acaso.\n\n"
                    "Tu tema y los ajustes de Focus no se tocan."
                ),
                actions=[
                    ft.TextButton(
                        "No, dejarlo",
                        on_click=lambda _: self.pagina.pop_dialog(),
                    ),
                    ft.FilledButton(
                        "Sí, borrar mi cuenta",
                        on_click=lambda _: self._borrar_de_verdad(),
                    ),
                ],
            )
        )

    def _borrar_de_verdad(self) -> None:
        """Borra en el servidor y deja este aparato limpio."""
        self.pagina.pop_dialog()

        async def hacerlo():
            with conectado() as conexion:
                # LA SESION SE RENUEVA ANTES: el testigo dura una hora, y con
                # uno caducado el servidor contesta 401 y parece que la llave
                # esta mal. Es el mismo cuidado que tiene la sincronizacion.
                try:
                    sesion = sincronizador.sesion_viva(conexion, datetime.now())
                except Exception as fallo:  # noqa: BLE001
                    self._error = str(fallo)
                    self.al_cambiar()
                    return
            if sesion is None:
                return
            try:
                await asyncio.to_thread(cuentas.borrar_cuenta, sesion)
            except RuntimeError as fallo:
                self._error = str(fallo)
                self.al_cambiar()
                return
            except Exception as fallo:  # noqa: BLE001
                self._error = str(fallo)
                self.al_cambiar()
                return
            with conectado() as conexion:
                # LA COPIA ANTES DE VACIAR, como en la sincronización: lo que
                # se borra del servidor ya no vuelve, pero lo de aquí sí.
                try:
                    copias.copiar(conexion, rutas.ruta_bd(), version_actual(conexion))
                except copias.NoSePudoCopiar:
                    # Sin sitio para la copia se sigue igual: la cuenta ya no
                    # existe, y dejar los datos aquí sería peor.
                    pass
                sincronia.vaciar_todo(conexion)
                ajustes.cerrar_sesion(conexion)
            self._error = ""
            self._paso = "entrar"
            componentes.avisar(self.pagina, "Tu cuenta y tus datos se han borrado.")
            self.al_cambiar_sesion()

        self.pagina.run_task(hacerlo)

    def _salir(self) -> None:
        """Cierra la sesión de ESTE aparato. Los datos apuntados no se tocan.

        NO SE PIDE CONFIRMACIÓN porque no se pierde nada: no borra un solo dato,
        y volver a entrar son dos campos. Un "¿seguro?" delante de algo que se
        deshace en diez segundos solo enseña a pulsar "sí" sin leer.
        """
        with conectado() as conexion:
            ajustes.cerrar_sesion(conexion)
        self._error = ""
        # SE VUELVE AL PRIMER PASO: si cerraste sesion a medio recuperar la
        # contrasena, encontrarte el formulario del codigo al volver seria
        # ensenarte un paso de algo que ya no estas haciendo.
        self._paso = "entrar"
        componentes.avisar(self.pagina, "Sesión cerrada en este aparato.")
        self.al_cambiar_sesion()
