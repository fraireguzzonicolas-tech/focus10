"""La tarjeta de la cuenta: entrar, registrarse y salir.

VIVE APARTE DE configuracion.py A PROPÓSITO. Esa pantalla ya pasaba de las
setecientas líneas, y una tarjeta con dos campos, dos botones, tres estados y
llamadas a la red por medio son otras ciento y pico. Aquí se lee entera de una
sentada; allí dentro habría que ir a buscarla.

TENER CUENTA ES OPCIONAL Y ESO SE DICE EN PANTALLA. La aplicación entera
funciona sin registrarse, igual que hasta ahora.

LO QUE ESTA TARJETA **NO** HACE, Y SE AVISA EN PANTALLA: sincronizar. De momento
guarda quién eres y nada más; los datos siguen viviendo en cada aparato. Poner
aquí un "tus datos ya se sincronizan" que no es verdad haría que alguien
formatease el móvil confiando en una copia que no existe.
"""

from __future__ import annotations

import asyncio
from datetime import datetime

import flet as ft

from ..datos import ajustes
from ..datos.bd import conectado
from ..dominio.cuenta import (
    ContrasenaInvalida,
    CorreoInvalido,
    exigir_contrasena,
    exigir_correo,
)
from ..sistema import cuentas
from . import componentes, estilo
from .estilo import Paleta


class TarjetaCuenta:
    """El trozo de Configuración que se ocupa de la cuenta.

    NO ES UNA `Pantalla`: no se monta sola ni ocupa la ventana. Es una pieza que
    otra pantalla coloca entre sus tarjetas y que sabe repintarse pidiéndoselo a
    quien la puso, que es lo que hace `al_cambiar`.
    """

    def __init__(
        self, pagina: ft.Page, paleta: Paleta, al_cambiar, al_cambiar_sesion=None
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.al_cambiar = al_cambiar
        # DOS AVISOS DISTINTOS, Y NO UNO, porque no cuesta lo mismo repintar la
        # tarjeta que rehacer la ventana entera. Un "esa contraseña es corta"
        # solo tiene que repintar la tarjeta; entrar o salir cambia QUÉ se ve en
        # toda la aplicación, porque detrás hay una puerta. Si los dos hicieran
        # lo caro, escribir mal la contraseña reharía la ventana y borraría el
        # correo a medio teclear.
        self.al_cambiar_sesion = al_cambiar_sesion or al_cambiar

        # LOS CAMPOS SE CREAN UNA VEZ Y VIVEN CON LA TARJETA. Si se construyeran
        # en cada repintado, enseñar "esa contraseña es corta" borraría el
        # correo recién escrito, que es justo el peor momento para borrarlo.
        self.campo_correo = componentes.campo_texto(
            paleta, "Correo", pista="el tuyo de siempre"
        )
        self.campo_contrasena = componentes.campo_texto(
            paleta,
            "Contraseña",
            pista="al menos 8 letras",
            secreto=True,
        )

        self._error = ""
        self._trabajando = False

    # ------------------------------------------------------------------

    def control(self) -> ft.Control:
        """La tarjeta, en el estado que toque ahora mismo."""
        with conectado() as conexion:
            sesion = ajustes.leer_sesion(conexion)

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(self.paleta, "👤 Tu cuenta"),
                    *(self._cuerpo_dentro(sesion) if sesion else self._cuerpo_fuera()),
                ],
                spacing=12,
                tight=True,
            ),
        )

    # ------------------------------------------------------------------

    def _cuerpo_fuera(self) -> list[ft.Control]:
        """Cuando no has entrado: la explicación, los campos y los dos botones.

        SIN SERVICIO NO SE ENSEÑAN LOS CAMPOS, igual que en los comentarios:
        dejar escribir un correo y una contraseña para contestar después que no
        hay dónde mandarlos es la peor forma de decirlo. Se avisa antes.
        """
        if not cuentas.hay_servidor():
            return [
                componentes.aviso_vacio(
                    self.paleta,
                    "Esta versión todavía no tiene servicio de cuentas. "
                    "Estará en la siguiente.",
                )
            ]

        return [
            ft.Text(
                "Crear una cuenta es opcional: la aplicación funciona igual sin "
                "ella. De momento solo guarda quién eres; tus datos siguen "
                "estando en este aparato y no viajan todavía.",
                size=estilo.TEXTO_APOYO,
                color=self.paleta.muted,
            ),
            self.campo_correo,
            self.campo_contrasena,
            *self._error_si_lo_hay(),
            ft.Row(
                [
                    componentes.boton(
                        self.paleta,
                        "Entrando..." if self._trabajando else "Entrar",
                        icono=ft.Icons.LOGIN_OUTLINED,
                        principal=True,
                        al_pulsar=lambda _: self._intentar(cuentas.entrar),
                    ),
                    componentes.boton(
                        self.paleta,
                        "Crear cuenta",
                        icono=ft.Icons.PERSON_ADD_OUTLINED,
                        al_pulsar=lambda _: self._intentar(cuentas.registrar),
                    ),
                ],
                spacing=10,
                wrap=True,
            ),
        ]

    def _cuerpo_dentro(self, sesion) -> list[ft.Control]:
        """Cuando ya has entrado: con qué correo, y el botón de salir."""
        return [
            ft.Text(
                f"Has entrado como {sesion.correo}.",
                size=estilo.TEXTO,
                color=self.paleta.ink,
            ),
            ft.Text(
                "Todavía no se sincroniza nada entre aparatos: eso llega en la "
                "siguiente versión. Para pasar tus datos ahora, usa la copia de "
                "más abajo.",
                size=estilo.TEXTO_APOYO,
                color=self.paleta.muted,
            ),
            *self._error_si_lo_hay(),
            componentes.boton(
                self.paleta,
                "Cerrar sesión",
                icono=ft.Icons.LOGOUT_OUTLINED,
                al_pulsar=lambda _: self._salir(),
            ),
        ]

    def _error_si_lo_hay(self) -> list[ft.Control]:
        if not self._error:
            return []
        return [componentes.aviso_error(self.paleta, [self._error])]

    # ------------------------------------------------------------------

    def _intentar(self, que_hacer) -> None:
        """Comprueba lo escrito y lo manda, sin congelar la ventana.

        LO ESCRITO SE COMPRUEBA AQUÍ ANTES DE SALIR A LA RED. Un correo sin
        arroba no hace falta mandarlo a Irlanda para saber que está mal, y la
        respuesta es instantánea en vez de tardar dos segundos.
        """
        if self._trabajando:
            return

        correo = self.campo_correo.value or ""
        contrasena = self.campo_contrasena.value or ""
        try:
            exigir_correo(correo)
            exigir_contrasena(contrasena)
        except (CorreoInvalido, ContrasenaInvalida) as fallo:
            self._error = str(fallo)
            self.al_cambiar()
            return

        self._error = ""
        self._trabajando = True
        self.al_cambiar()
        self.pagina.run_task(self._hablar, que_hacer, correo, contrasena)

    async def _hablar(self, que_hacer, correo: str, contrasena: str) -> None:
        """La llamada de verdad, en otro hilo: urllib bloquea.

        LA CONTRASEÑA SE BORRA DEL CAMPO PASE LO QUE PASE, salga bien o mal. Se
        queda escrita en pantalla, con el ojo de destapar al lado, y lo normal
        es dejar el móvil encima de la mesa sin volver a mirarlo. El correo sí
        se conserva: si te equivocaste de contraseña, no tienes que reescribirlo.
        """
        entrado = False
        try:
            sesion = await asyncio.to_thread(
                que_hacer, correo, contrasena, datetime.now()
            )
        except cuentas.NoSePudoEntrar as fallo:
            self._error = str(fallo)
        else:
            self._error = ""
            with conectado() as conexion:
                ajustes.guardar_sesion(conexion, sesion)
            componentes.avisar(self.pagina, f"Has entrado como {sesion.correo}.")
            entrado = True
        finally:
            self.campo_contrasena.value = ""
            self._trabajando = False
            # SI SE HA ENTRADO, LA VENTANA ENTERA CAMBIA: detrás de la puerta
            # está la aplicación, y repintar solo la tarjeta dejaría a la
            # persona mirando el formulario que acaba de rellenar bien.
            (self.al_cambiar_sesion if entrado else self.al_cambiar)()

    def _salir(self) -> None:
        """Cierra la sesión de ESTE aparato. Los datos apuntados no se tocan.

        NO SE PIDE CONFIRMACIÓN porque no se pierde nada: no borra un solo dato,
        y volver a entrar son dos campos. Un "¿seguro?" delante de algo que se
        deshace en diez segundos solo enseña a pulsar "sí" sin leer.
        """
        with conectado() as conexion:
            ajustes.cerrar_sesion(conexion)
        self._error = ""
        componentes.avisar(self.pagina, "Sesión cerrada en este aparato.")
        self.al_cambiar_sesion()
