"""La franja «Entrenando · 23:14 · Volver», abajo de todo, con el entreno fuera.

LO PIDIÓ EL USUARIO (4 nov 2026): «debo poder salir del entrenamiento para usar
la app, pero el entrenamiento no se pierde: continúa en segundo plano». Salir
ya no lo termina; esta franja es la prueba de que sigue, y la forma de volver
en un toque desde cualquier sección.

NO GUARDA NADA SUYO: el entreno en marcha es el de la base (segundos = 0,
empezado hace poco; ver repositorio_gimnasio.sesion_en_marcha). Ella solo lo
mira al pintarse. Así no hay dos versiones de «hay un entreno abierto» que
puedan contradecirse.

VIVE COMO LA DEL DESCANSO: la ventana la crea una vez y le pide el dibujo en
cada repintado, para que el reloj no se pare ni se duplique al cambiar de
sección.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Callable

import flet as ft

from ..datos import repositorio_gimnasio
from ..datos.bd import conectado
from ..dominio.sesion import Sesion
from . import estilo
from .entreno import texto_reloj
from .estilo import Paleta


def texto(sesion: Sesion, ahora: datetime) -> str:
    """«Entrenando · Pecho · GYM · 23:14»: qué entreno y cuánto lleva."""
    partes = ["Entrenando"]
    if sesion.titulo():
        partes.append(sesion.titulo())
    partes.append(texto_reloj(sesion.duracion(ahora)))
    return " · ".join(partes)


class FranjaEntreno:
    """La franja del entreno en marcha: su dibujo y su reloj."""

    def __init__(self, pagina: ft.Page, al_volver: Callable[[Sesion], None]) -> None:
        self.pagina = pagina
        self.al_volver = al_volver
        self.sesion: Sesion | None = None
        self.letrero = ft.Text("", size=estilo.TEXTO_APOYO, weight=ft.FontWeight.W_600)
        self.caja = ft.Container(visible=False, height=0)
        self._latiendo = False
        self._vivo = True
        # LA HORA, aparte para que los tests puedan adelantarla.
        self._ahora = datetime.now

    def control(self, paleta: Paleta) -> ft.Control:
        """La franja, o una caja vacía si no hay entreno en marcha."""
        with conectado() as conexion:
            self.sesion = repositorio_gimnasio.sesion_en_marcha(conexion, self._ahora())
        if self.sesion is None:
            self.caja.visible = False
            self.caja.height = 0
            self.caja.content = None
            return self.caja
        sesion = self.sesion
        self.letrero.value = texto(sesion, self._ahora())
        self.letrero.color = paleta.acento_ink
        self.caja.visible = True
        self.caja.height = None
        self.caja.bgcolor = paleta.acento
        self.caja.padding = ft.Padding.symmetric(horizontal=16, vertical=10)
        # TODA LA FRANJA SE TOCA, no solo la palabra «Volver»: con una mano y
        # la otra en la mancuerna, un blanco grande es lo que se acierta.
        self.caja.on_click = lambda _: self.al_volver(sesion)
        self.caja.content = ft.Row(
            [
                ft.Icon(ft.Icons.FITNESS_CENTER, size=18, color=paleta.acento_ink),
                ft.Container(self.letrero, expand=True),
                ft.Text(
                    "Volver", size=estilo.TEXTO_APOYO, weight=ft.FontWeight.W_700,
                    color=paleta.acento_ink,
                ),
                ft.Icon(ft.Icons.CHEVRON_RIGHT, size=18, color=paleta.acento_ink),
            ],
            spacing=8,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )
        return self.caja

    def empezar_a_latir(self) -> None:
        """Arranca el reloj UNA vez: cada repintado no suelta otro."""
        if self._latiendo:
            return
        self._latiendo = True
        self.pagina.run_task(self._latir)

    async def _latir(self) -> None:
        while self._vivo:
            await asyncio.sleep(1)
            try:
                self._un_segundo()
            except Exception:  # noqa: BLE001
                # UN LATIDO QUE FALLA NO PARA EL RELOJ: es la lección de la
                # franja del descanso (en segundo plano pintar puede fallar).
                continue

    def _un_segundo(self) -> None:
        """Solo cambia el texto. Sin entreno a la vista, no hace nada."""
        if self.sesion is None or not self.caja.visible:
            return
        nuevo = texto(self.sesion, self._ahora())
        if nuevo != self.letrero.value:
            self.letrero.value = nuevo
            self.letrero.update()
