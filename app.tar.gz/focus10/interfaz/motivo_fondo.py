"""El dibujo de fondo de cada tema. Pequeño y que no estorbe.

LO PIDIÓ EL USUARIO enseñando tres referencias y repartiéndolas: la onda de
puntos para Aurora, la forma abstracta para Minimalista, la línea botánica para
Natural. Y la condición, con sus palabras: «sin que estorben ni que haya
muchas, son pequeños detalles, nada grande».

LAS CUATRO REGLAS, y valen para los trece:

  1. UNO POR PANTALLA. Se dibuja una vez, detrás de todo. Repetido en cada
     tarjeta dejaría de ser un detalle y sería un estampado.
  2. NUNCA DETRÁS DE UN DATO. Esto sale gratis: va debajo de las tarjetas, que
     tienen fondo propio, así que solo asoma por los márgenes.
  3. TOPE DEL 12 % DE OPACIDAD. Si se ve a la primera, está mal puesto.
  4. SE DIBUJA, NO SE CARGA. Con el mismo lienzo que la figura del gimnasio:
     sin archivos, sin peso, y del color del tema.

Y UNA EXCEPCIÓN A PROPÓSITO: Elegante no lleva ninguno. Su identidad es el
espacio vacío, y cualquier dibujo de fondo la contradice.

EL AZAR VA CON SEMILLA FIJA, y eso importa más de lo que parece: la ventana se
vuelve a montar cada vez que cambias de sección. Con estrellas al azar, el cielo
cambiaría entero al pulsar «Hábitos», y eso se ve como un parpadeo.
"""

from __future__ import annotations

import math
import random

import flet as ft
import flet.canvas as cv

from .estilo import Paleta, con_opacidad

# Cuánto se ve cada motivo. Ninguno pasa del 12 %: ver la regla 3.
OPACIDAD = {
    "rejilla": 0.07,
    "arco": 0.11,
    "blob": 0.05,
    "rama": 0.12,
    "sol": 0.08,
    "topografia": 0.07,
    "ola": 0.11,
    "semitono": 0.09,
    "grano": 0.05,
    "puntos": 0.05,
    "cuadricula": 0.06,
    "estrellas": 0.10,
}

DE_TINTA = frozenset({"blob", "grano", "puntos", "rejilla"})
"""Los que van del color del TEXTO y no del acento.

SON LOS QUE SON TEXTURA y no dibujo: un grano de papel o una rejilla de puntos
son el material de la pantalla, y el acento está reservado para lo que hay que
MIRAR. Los que sí son un dibujo reconocible —la rama, la ola, el sol— van del
acento, porque ahí el color es parte de lo que se reconoce.
"""


TOPE_DE_FORMAS = 450
"""Cuantas piezas puede tener un motivo como mucho.

NO ES UN CAPRICHO: esto se vuelve a dibujar en CADA cambio de seccion, y en la
web el codigo corre dentro del navegador. La primera version de la onda de
Aurora tenia ochocientas cuatro circunferencias, que es mas de lo que cuesta
dibujar todo lo demas de la pantalla junto. Los pasos de abajo estan elegidos
para no acercarse a este tope en una ventana grande.
"""

MINIMO = 320
"""Debajo de esto no se dibuja nada.

En una ventana muy pequeña el motivo no cabe en los márgenes y acabaría justo
debajo de un dato, que es la única regla que no se puede romper.
"""


def dibujar(paleta: Paleta, ancho: float | None, alto: float | None) -> ft.Control | None:
    """El fondo del tema, o None si no lleva o no cabe."""
    motivo = paleta.motivo
    if motivo == "nada" or motivo not in _DIBUJOS:
        return None
    if not ancho or not alto or ancho < MINIMO or alto < MINIMO:
        return None

    base = paleta.ink if motivo in DE_TINTA else paleta.acento
    color = con_opacidad(base, OPACIDAD[motivo])
    formas = _DIBUJOS[motivo](float(ancho), float(alto), color, paleta)
    if not formas:
        return None
    return ft.Container(
        content=cv.Canvas(formas, expand=True),
        width=ancho,
        height=alto,
        # NO SE PUEDE PULSAR: es decoración, y un fondo que se traga un clic
        # destinado a una tarjeta es peor que no tener fondo.
        disabled=True,
    )


def _azar(paleta: Paleta) -> random.Random:
    """El mismo azar siempre para el mismo tema. Ver la nota de la cabecera."""
    return random.Random(sum(ord(letra) for letra in paleta.tema) or 7)


# ---------------------------------------------------------------------------
# Un dibujo por tema
# ---------------------------------------------------------------------------


def _paso_de_rejilla(ancho: float, alto: float, minimo: float) -> float:
    """La separacion que hace falta para no pasarse del tope de formas.

    SE CALCULA Y NO SE ELIGE A OJO: un paso fijo que va bien en un portatil
    dibuja el triple de puntos en un monitor grande, y ahi es donde se nota. La
    cuenta es la de siempre: si caben N puntos en un area, el lado de cada
    hueco es la raiz del area entre N.
    """
    cabida = TOPE_DE_FORMAS * 0.85
    return max(minimo, math.sqrt(ancho * alto / cabida))


def _puntos(ancho, alto, color, paleta):
    paso, formas = _paso_de_rejilla(ancho, alto, 46.0), []
    y = paso / 2
    while y < alto:
        x = paso / 2
        while x < ancho:
            formas.append(cv.Circle(x, y, 1.0, paint=ft.Paint(color=color)))
            x += paso
        y += paso
    return formas


def _cuadricula(ancho, alto, color, paleta):
    # LAS RAYAS SON DOS SERIES y no una rejilla, asi que caben mas: se reparte
    # el tope entre las dos y sale el paso de cada una.
    paso = max(22.0, (ancho + alto) / (TOPE_DE_FORMAS * 0.85))
    pincel = ft.Paint(color=color, stroke_width=0.8)
    formas, x = [], 0.0
    while x < ancho:
        formas.append(cv.Line(x, 0, x, alto, paint=pincel))
        x += paso
    y = 0.0
    while y < alto:
        formas.append(cv.Line(0, y, ancho, y, paint=pincel))
        y += paso
    return formas


def _grano(ancho, alto, color, paleta):
    az = _azar(paleta)
    return [
        cv.Circle(az.uniform(0, ancho), az.uniform(0, alto), 0.6,
                  paint=ft.Paint(color=color))
        for _ in range(220)
    ]


def _estrellas(ancho, alto, color, paleta):
    az = _azar(paleta)
    formas = [
        cv.Circle(az.uniform(0, ancho), az.uniform(0, alto),
                  az.choice([0.6, 0.6, 0.9, 1.2, 1.7]), paint=ft.Paint(color=color))
        for _ in range(160)
    ]
    # Cuatro algo mayores, para que el cielo tenga dónde descansar la vista.
    for _ in range(4):
        formas.append(
            cv.Circle(az.uniform(40, ancho - 40), az.uniform(40, alto - 40), 2.6,
                      paint=ft.Paint(color=color))
        )
    return formas


def _semitono(ancho, alto, color, paleta):
    """La onda de puntos: más gordos donde la onda pasa."""
    formas = []
    filas = 4
    # Cuatro puntos por columna, asi que el paso sale de repartir el tope.
    paso = max(16, int(ancho * filas / (TOPE_DE_FORMAS * 0.85)))
    cresta_base = alto * 0.16
    for x in range(0, int(ancho), paso):
        cresta = cresta_base + math.sin(x / 90) * alto * 0.06
        for fila in range(filas):
            radio = max(0.5, 2.8 - fila * 0.6)
            formas.append(
                cv.Circle(x, cresta + fila * 11, radio, paint=ft.Paint(color=color))
            )
    return formas


def _rejilla(ancho, alto, color, paleta):
    """El horizonte en perspectiva, pegado al borde de abajo."""
    pincel = ft.Paint(color=color, stroke_width=0.9)
    fuga_x, horizonte = ancho / 2, alto * 0.72
    # Las radiales barren tres anchos de pantalla, asi que son las que mandan.
    paso = max(60, int(ancho * 3 / (TOPE_DE_FORMAS * 0.75)))
    formas = [
        cv.Line(fuga_x, horizonte, x, alto, paint=pincel)
        for x in range(-int(ancho), int(ancho * 2), paso)
    ]
    y, paso = horizonte + 6, 6.0
    while y < alto:
        formas.append(cv.Line(0, y, ancho, y, paint=pincel))
        paso *= 1.4
        y += paso
    return formas


def _topografia(ancho, alto, color, paleta):
    pincel = ft.Paint(color=color, stroke_width=1.0)
    formas = []
    for i in range(9):
        d = i * 46
        formas.append(
            cv.Path(
                [
                    cv.Path.MoveTo(-40 + d, alto),
                    cv.Path.CubicTo(
                        ancho * 0.2 + d, alto * 0.6,
                        ancho * 0.45 + d, alto * 0.5,
                        ancho * 0.75 + d, -20,
                    ),
                ],
                paint=pincel,
            )
        )
    return formas


def _ola(ancho, alto, color, paleta):
    pincel = ft.Paint(color=color, stroke_width=1.6)
    y = alto * 0.9
    formas = []
    for salto in (0, 14):
        formas.append(
            cv.Path(
                [
                    cv.Path.MoveTo(0, y + salto),
                    cv.Path.CubicTo(ancho * 0.18, y - 18 + salto,
                                    ancho * 0.34, y + 16 + salto,
                                    ancho * 0.5, y + salto),
                    cv.Path.CubicTo(ancho * 0.68, y - 16 + salto,
                                    ancho * 0.84, y + 15 + salto,
                                    ancho, y - 4 + salto),
                ],
                paint=pincel,
            )
        )
    return formas


def _arco(ancho, alto, color, paleta):
    pincel = ft.Paint(color=color, stroke_width=1.2)
    return [
        cv.Path(
            [
                cv.Path.MoveTo(ancho * 0.55, -10),
                cv.Path.CubicTo(ancho * 0.9, alto * 0.05,
                                ancho + 10, alto * 0.2,
                                ancho + 10, alto * 0.45),
            ],
            paint=pincel,
        ),
        cv.Path(
            [
                cv.Path.MoveTo(ancho * 0.72, -10),
                cv.Path.CubicTo(ancho * 0.95, alto * 0.04,
                                ancho + 10, alto * 0.14,
                                ancho + 10, alto * 0.3),
            ],
            paint=pincel,
        ),
    ]


def _blob(ancho, alto, color, paleta):
    x, y = ancho * 0.82, alto * 0.78
    r = min(ancho, alto) * 0.45
    return [
        cv.Path(
            [
                cv.Path.MoveTo(x - r, y),
                cv.Path.CubicTo(x - r, y - r * 0.75, x - r * 0.55, y - r, x, y - r * 0.92),
                cv.Path.CubicTo(x + r * 0.7, y - r * 0.82, x + r, y - r * 0.3,
                                x + r * 0.92, y + r * 0.2),
                cv.Path.CubicTo(x + r * 0.84, y + r * 0.72, x + r * 0.3, y + r,
                                x - r * 0.2, y + r * 0.88),
                cv.Path.CubicTo(x - r * 0.72, y + r * 0.76, x - r, y + r * 0.4, x - r, y),
                cv.Path.Close(),
            ],
            paint=ft.Paint(color=color),
        )
    ]


def _sol(ancho, alto, color, paleta):
    cx, cy, r = ancho * 0.93, alto * 0.08, 48.0
    pincel = ft.Paint(color=color, stroke_width=4)
    formas = [cv.Circle(cx, cy, r, paint=ft.Paint(color=color))]
    for k in range(12):
        a = math.radians(k * 30)
        formas.append(
            cv.Line(cx + math.cos(a) * (r + 10), cy + math.sin(a) * (r + 10),
                    cx + math.cos(a) * (r + 26), cy + math.sin(a) * (r + 26),
                    paint=pincel)
        )
    return formas


def _rama(ancho, alto, color, paleta):
    """Una rama con hojas, saliendo de la esquina de arriba a la derecha."""
    pincel = ft.Paint(color=color, stroke_width=1.6)
    bx, by = ancho * 0.9, 8.0
    largo = min(alto * 0.5, 280)
    formas = [
        cv.Path(
            [
                cv.Path.MoveTo(bx, by),
                cv.Path.CubicTo(bx - 22, by + largo * 0.4,
                                bx - 16, by + largo * 0.7,
                                bx - 58, by + largo),
            ],
            paint=pincel,
        )
    ]
    for i in range(5):
        t = 0.16 + i * 0.17
        hx = bx - 8 - i * 9
        hy = by + largo * t
        lado = -1 if i % 2 else 1
        formas.append(
            cv.Path(
                [
                    cv.Path.MoveTo(hx, hy),
                    cv.Path.CubicTo(hx + 34 * lado, hy - 26,
                                    hx + 54 * lado, hy - 4,
                                    hx + 60 * lado, hy + 16),
                    cv.Path.CubicTo(hx + 38 * lado, hy + 22,
                                    hx + 13 * lado, hy + 13,
                                    hx, hy),
                    cv.Path.Close(),
                ],
                paint=pincel,
            )
        )
    return formas


_DIBUJOS = {
    "puntos": _puntos,
    "cuadricula": _cuadricula,
    "grano": _grano,
    "estrellas": _estrellas,
    "semitono": _semitono,
    "rejilla": _rejilla,
    "topografia": _topografia,
    "ola": _ola,
    "arco": _arco,
    "blob": _blob,
    "sol": _sol,
    "rama": _rama,
}
