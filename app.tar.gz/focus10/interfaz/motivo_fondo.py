"""El dibujo de fondo de cada tema. Pequeño y que no estorbe.

LO PIDIÓ EL USUARIO enseñando tres referencias y repartiéndolas: la onda de
puntos para Aurora, la forma abstracta para Minimalista, la línea botánica para
Natural. Y la condición, con sus palabras: «sin que estorben ni que haya
muchas, son pequeños detalles, nada grande».

LAS CUATRO REGLAS, y valen para los catorce:

  1. UNO POR PANTALLA. Se dibuja una vez, detrás de todo. Repetido en cada
     tarjeta dejaría de ser un detalle y sería un estampado.
  2. NUNCA DETRÁS DE UN DATO. Esto sale gratis: va debajo de las tarjetas, que
     tienen fondo propio, así que solo asoma por los márgenes.
  3. TOPE DEL 12 % DE OPACIDAD. Si se ve a la primera, está mal puesto.
     CON UNA EXCEPCIÓN, Galaxia: allí el fondo ES el tema. Con el 10 % de los
     demás no se veía nada —«el de galaxia no se ve nada»— y un motivo que no
     se ve no es discreto, es que no está. Sus estrellas llegan al 40 %, y aun
     así solo asoman por los márgenes como todos.
  4. SE DIBUJA, NO SE CARGA. Con el mismo lienzo que la figura del gimnasio:
     sin archivos, sin peso, y del color del tema.

Y UNA EXCEPCIÓN A PROPÓSITO: Elegante no lleva ninguno. Su identidad es el
espacio vacío, y cualquier dibujo de fondo la contradice.

EL AZAR VA CON SEMILLA FIJA, y eso importa más de lo que parece: la ventana se
vuelve a montar cada vez que cambias de sección. Con estrellas al azar, el cielo
cambiaría entero al pulsar «Hábitos», y eso se ve como un parpadeo.
"""

from __future__ import annotations

import math
import random

import flet as ft
import flet.canvas as cv

from .estilo import Paleta, con_opacidad

# Cuánto se ve cada motivo. Ninguno pasa del 12 %: ver la regla 3.
OPACIDAD = {
    "rejilla": 0.07,
    "arco": 0.11,
    "blob": 0.05,
    "rama": 0.12,
    "sol": 0.08,
    "topografia": 0.07,
    "ola": 0.11,
    "ondas": 0.12,
    "nubes": 0.09,
    "semitono": 0.09,
    "grano": 0.05,
    "puntos": 0.05,
    "cuadricula": 0.06,
    # Ver la excepción de la regla 3: aquí cada pieza pone su propio brillo
    # y esta cifra solo es el punto de partida.
    "estrellas": 0.10,
}

DE_TINTA = frozenset({"blob", "grano", "puntos", "rejilla"})
"""Los que van del color del TEXTO y no del acento.

SON LOS QUE SON TEXTURA y no dibujo: un grano de papel o una rejilla de puntos
son el material de la pantalla, y el acento está reservado para lo que hay que
MIRAR. Los que sí son un dibujo reconocible —la rama, la ola, el sol— van del
acento, porque ahí el color es parte de lo que se reconoce.
"""


TOPE_DE_FORMAS = 450
"""Cuantas piezas puede tener un motivo como mucho.

NO ES UN CAPRICHO: esto se vuelve a dibujar en CADA cambio de seccion, y en la
web el codigo corre dentro del navegador. La primera version de la onda de
Aurora tenia ochocientas cuatro circunferencias, que es mas de lo que cuesta
dibujar todo lo demas de la pantalla junto. Los pasos de abajo estan elegidos
para no acercarse a este tope en una ventana grande.
"""

MINIMO = 320
"""Debajo de esto no se dibuja nada.

En una ventana muy pequeña el motivo no cabe en los márgenes y acabaría justo
debajo de un dato, que es la única regla que no se puede romper.
"""


def dibujar(paleta: Paleta, ancho: float | None, alto: float | None) -> ft.Control | None:
    """El fondo del tema, o None si no lleva o no cabe."""
    motivo = paleta.motivo
    if motivo == "nada" or motivo not in _DIBUJOS:
        return None
    if not ancho or not alto or ancho < MINIMO or alto < MINIMO:
        return None

    base = paleta.ink if motivo in DE_TINTA else paleta.acento
    color = con_opacidad(base, OPACIDAD[motivo])
    formas = _DIBUJOS[motivo](float(ancho), float(alto), color, paleta)
    if not formas:
        return None
    return ft.Container(
        content=cv.Canvas(formas, expand=True),
        width=ancho,
        height=alto,
        # NO SE PUEDE PULSAR: es decoración, y un fondo que se traga un clic
        # destinado a una tarjeta es peor que no tener fondo.
        disabled=True,
    )


def _azar(paleta: Paleta) -> random.Random:
    """El mismo azar siempre para el mismo tema. Ver la nota de la cabecera."""
    return random.Random(sum(ord(letra) for letra in paleta.tema) or 7)


# ---------------------------------------------------------------------------
# Un dibujo por tema
# ---------------------------------------------------------------------------


def _paso_de_rejilla(ancho: float, alto: float, minimo: float) -> float:
    """La separacion que hace falta para no pasarse del tope de formas.

    SE CALCULA Y NO SE ELIGE A OJO: un paso fijo que va bien en un portatil
    dibuja el triple de puntos en un monitor grande, y ahi es donde se nota. La
    cuenta es la de siempre: si caben N puntos en un area, el lado de cada
    hueco es la raiz del area entre N.
    """
    cabida = TOPE_DE_FORMAS * 0.85
    return max(minimo, math.sqrt(ancho * alto / cabida))


def _puntos(ancho, alto, color, paleta):
    paso, formas = _paso_de_rejilla(ancho, alto, 46.0), []
    y = paso / 2
    while y < alto:
        x = paso / 2
        while x < ancho:
            formas.append(cv.Circle(x, y, 1.0, paint=ft.Paint(color=color)))
            x += paso
        y += paso
    return formas


def _cuadricula(ancho, alto, color, paleta):
    # LAS RAYAS SON DOS SERIES y no una rejilla, asi que caben mas: se reparte
    # el tope entre las dos y sale el paso de cada una.
    paso = max(22.0, (ancho + alto) / (TOPE_DE_FORMAS * 0.85))
    pincel = ft.Paint(color=color, stroke_width=0.8)
    formas, x = [], 0.0
    while x < ancho:
        formas.append(cv.Line(x, 0, x, alto, paint=pincel))
        x += paso
    y = 0.0
    while y < alto:
        formas.append(cv.Line(0, y, ancho, y, paint=pincel))
        y += paso
    return formas


def _grano(ancho, alto, color, paleta):
    az = _azar(paleta)
    return [
        cv.Circle(az.uniform(0, ancho), az.uniform(0, alto), 0.6,
                  paint=ft.Paint(color=color))
        for _ in range(220)
    ]


def _estrellas(ancho, alto, color, paleta):
    """Un cielo: estrellas de varios brillos, cuatro destellos y dos planetas.

    NO USA EL `color` QUE LE LLEGA, y es el único que hace eso: aquí cada pieza
    tiene su propio brillo. Un cielo donde todas las estrellas se ven igual no
    es un cielo, es una trama de puntos —que es exactamente en lo que había
    quedado la primera versión.
    """
    az = _azar(paleta)
    estrella = paleta.acento
    formas: list[cv.Shape] = []

    # LOS PLANETAS PRIMERO, para que las estrellas queden por delante. Van muy
    # apagados: son masa, no luz.
    for cx, cy, radio in (
        (ancho * 0.13, alto * 0.74, min(ancho, alto) * 0.11),
        (ancho * 0.88, alto * 0.2, min(ancho, alto) * 0.07),
    ):
        formas.append(
            cv.Circle(cx, cy, radio, paint=ft.Paint(color=con_opacidad(estrella, 0.07)))
        )
        formas.append(
            cv.Circle(
                cx, cy, radio,
                paint=ft.Paint(
                    color=con_opacidad(estrella, 0.20),
                    stroke_width=1.2,
                    style=ft.PaintingStyle.STROKE,
                ),
            )
        )
    # Y UN ANILLO en el grande, que es lo que hace que se lea como un planeta y
    # no como un círculo cualquiera.
    cx, cy, radio = ancho * 0.13, alto * 0.74, min(ancho, alto) * 0.11
    formas.append(
        cv.Oval(
            cx - radio * 1.9, cy - radio * 0.34, radio * 3.8, radio * 0.68,
            paint=ft.Paint(
                color=con_opacidad(estrella, 0.22),
                stroke_width=1.4,
                style=ft.PaintingStyle.STROKE,
            ),
        )
    )

    # EL POLVO: cuanto más pequeña, más apagada, como se ven de verdad.
    for _ in range(150):
        r = az.choice([0.6, 0.7, 0.9, 1.2, 1.6, 2.2])
        brillo = 0.16 + (r / 2.2) * 0.24
        formas.append(
            cv.Circle(
                az.uniform(0, ancho), az.uniform(0, alto), r,
                paint=ft.Paint(color=con_opacidad(estrella, brillo)),
            )
        )

    # CUATRO DESTELLOS, con sus puntas. Son los que hacen que el ojo lea
    # "estrella" y no "punto".
    pincel = ft.Paint(
        color=con_opacidad(estrella, 0.40), stroke_width=1.1,
        style=ft.PaintingStyle.STROKE,
    )
    for _ in range(4):
        x, y = az.uniform(60, ancho - 60), az.uniform(60, alto - 60)
        brazo = az.uniform(7, 12)
        formas.append(cv.Line(x - brazo, y, x + brazo, y, paint=pincel))
        formas.append(cv.Line(x, y - brazo, x, y + brazo, paint=pincel))
        formas.append(
            cv.Circle(x, y, 1.8, paint=ft.Paint(color=con_opacidad(estrella, 0.45)))
        )
    return formas


def _semitono(ancho, alto, color, paleta):
    """La onda de puntos: más gordos donde la onda pasa."""
    formas = []
    filas = 4
    # Cuatro puntos por columna, asi que el paso sale de repartir el tope.
    paso = max(16, int(ancho * filas / (TOPE_DE_FORMAS * 0.85)))
    cresta_base = alto * 0.16
    for x in range(0, int(ancho), paso):
        cresta = cresta_base + math.sin(x / 90) * alto * 0.06
        for fila in range(filas):
            radio = max(0.5, 2.8 - fila * 0.6)
            formas.append(
                cv.Circle(x, cresta + fila * 11, radio, paint=ft.Paint(color=color))
            )
    return formas


def _rejilla(ancho, alto, color, paleta):
    """El horizonte en perspectiva, pegado al borde de abajo."""
    pincel = ft.Paint(color=color, stroke_width=0.9)
    fuga_x, horizonte = ancho / 2, alto * 0.72
    # Las radiales barren tres anchos de pantalla, asi que son las que mandan.
    paso = max(60, int(ancho * 3 / (TOPE_DE_FORMAS * 0.75)))
    formas = [
        cv.Line(fuga_x, horizonte, x, alto, paint=pincel)
        for x in range(-int(ancho), int(ancho * 2), paso)
    ]
    y, paso = horizonte + 6, 6.0
    while y < alto:
        formas.append(cv.Line(0, y, ancho, y, paint=pincel))
        paso *= 1.4
        y += paso
    return formas


def _topografia(ancho, alto, color, paleta):
    pincel = ft.Paint(color=color, stroke_width=1.0)
    formas = []
    for i in range(9):
        d = i * 46
        formas.append(
            cv.Path(
                [
                    cv.Path.MoveTo(-40 + d, alto),
                    cv.Path.CubicTo(
                        ancho * 0.2 + d, alto * 0.6,
                        ancho * 0.45 + d, alto * 0.5,
                        ancho * 0.75 + d, -20,
                    ),
                ],
                paint=pincel,
            )
        )
    return formas


def _ola(ancho, alto, color, paleta):
    pincel = ft.Paint(color=color, stroke_width=1.6)
    y = alto * 0.9
    formas = []
    for salto in (0, 14):
        formas.append(
            cv.Path(
                [
                    cv.Path.MoveTo(0, y + salto),
                    cv.Path.CubicTo(ancho * 0.18, y - 18 + salto,
                                    ancho * 0.34, y + 16 + salto,
                                    ancho * 0.5, y + salto),
                    cv.Path.CubicTo(ancho * 0.68, y - 16 + salto,
                                    ancho * 0.84, y + 15 + salto,
                                    ancho, y - 4 + salto),
                ],
                paint=pincel,
            )
        )
    return formas


def _ondas(ancho, alto, color, paleta):
    """Circulos concentricos: una piedra que acaba de caer en el agua.

    SUSTITUYO A UNA OLA, y el motivo del cambio dice mas que el dibujo: una ola
    tiene direccion y empuje, y este tema paso de "bienestar en movimiento" a
    calma. Una onda que se abre no va a ninguna parte, que es justo de lo que se
    trata aqui.
    """
    cx, cy = ancho * 0.5, alto * 0.86
    pincel = ft.Paint(
        color=color, stroke_width=1.1, style=ft.PaintingStyle.STROKE
    )
    mayor = max(ancho, alto) * 0.62
    return [
        cv.Circle(cx, cy, mayor * fraccion, paint=pincel)
        for fraccion in (0.18, 0.34, 0.52, 0.72, 0.95)
    ]


def _una_nube(cx, cy, ancho_nube, pincel):
    """Una nube: tres bultos y una base plana.

    ES LA FORMA MAS SIMPLE QUE SE LEE COMO NUBE. Se probo con una curva
    dibujada a mano y a este tamano y a esta opacidad no se distinguia de un
    borron; tres circulos apoyados en un rectangulo, si.
    """
    r = ancho_nube / 3.4
    return [
        cv.Circle(cx - r * 1.05, cy, r * 0.72, paint=pincel),
        cv.Circle(cx, cy - r * 0.42, r, paint=pincel),
        cv.Circle(cx + r * 1.15, cy, r * 0.66, paint=pincel),
        cv.Rect(cx - r * 1.8, cy, r * 3.6, r * 0.75, border_radius=r * 0.4, paint=pincel),
    ]


def _nubes(ancho, alto, color, paleta):
    """Tres nubes por la mitad de arriba, saliendose por los lados.

    SE SALEN A PROPOSITO. Una nube entera y centrada se lee como un dibujo
    puesto ahi; cortada por el borde se lee como cielo, que es lo que este tema
    quiere decir.
    """
    pincel = ft.Paint(color=color)
    formas = []
    for x, y, tamano in (
        (-0.04, 0.12, 0.30),
        (0.72, 0.05, 0.22),
        (1.02, 0.34, 0.26),
    ):
        formas += _una_nube(ancho * x, alto * y, ancho * tamano, pincel)
    return formas


def _arco(ancho, alto, color, paleta):
    pincel = ft.Paint(color=color, stroke_width=1.2)
    return [
        cv.Path(
            [
                cv.Path.MoveTo(ancho * 0.55, -10),
                cv.Path.CubicTo(ancho * 0.9, alto * 0.05,
                                ancho + 10, alto * 0.2,
                                ancho + 10, alto * 0.45),
            ],
            paint=pincel,
        ),
        cv.Path(
            [
                cv.Path.MoveTo(ancho * 0.72, -10),
                cv.Path.CubicTo(ancho * 0.95, alto * 0.04,
                                ancho + 10, alto * 0.14,
                                ancho + 10, alto * 0.3),
            ],
            paint=pincel,
        ),
    ]


def _blob(ancho, alto, color, paleta):
    x, y = ancho * 0.82, alto * 0.78
    r = min(ancho, alto) * 0.45
    return [
        cv.Path(
            [
                cv.Path.MoveTo(x - r, y),
                cv.Path.CubicTo(x - r, y - r * 0.75, x - r * 0.55, y - r, x, y - r * 0.92),
                cv.Path.CubicTo(x + r * 0.7, y - r * 0.82, x + r, y - r * 0.3,
                                x + r * 0.92, y + r * 0.2),
                cv.Path.CubicTo(x + r * 0.84, y + r * 0.72, x + r * 0.3, y + r,
                                x - r * 0.2, y + r * 0.88),
                cv.Path.CubicTo(x - r * 0.72, y + r * 0.76, x - r, y + r * 0.4, x - r, y),
                cv.Path.Close(),
            ],
            paint=ft.Paint(color=color),
        )
    ]


def _sol(ancho, alto, color, paleta):
    cx, cy, r = ancho * 0.93, alto * 0.08, 48.0
    pincel = ft.Paint(color=color, stroke_width=4)
    formas = [cv.Circle(cx, cy, r, paint=ft.Paint(color=color))]
    for k in range(12):
        a = math.radians(k * 30)
        formas.append(
            cv.Line(cx + math.cos(a) * (r + 10), cy + math.sin(a) * (r + 10),
                    cx + math.cos(a) * (r + 26), cy + math.sin(a) * (r + 26),
                    paint=pincel)
        )
    return formas


def _rama(ancho, alto, color, paleta):
    """Una rama con hojas, saliendo de la esquina de arriba a la derecha."""
    pincel = ft.Paint(color=color, stroke_width=1.6)
    bx, by = ancho * 0.9, 8.0
    largo = min(alto * 0.5, 280)
    formas = [
        cv.Path(
            [
                cv.Path.MoveTo(bx, by),
                cv.Path.CubicTo(bx - 22, by + largo * 0.4,
                                bx - 16, by + largo * 0.7,
                                bx - 58, by + largo),
            ],
            paint=pincel,
        )
    ]
    for i in range(5):
        t = 0.16 + i * 0.17
        hx = bx - 8 - i * 9
        hy = by + largo * t
        lado = -1 if i % 2 else 1
        formas.append(
            cv.Path(
                [
                    cv.Path.MoveTo(hx, hy),
                    cv.Path.CubicTo(hx + 34 * lado, hy - 26,
                                    hx + 54 * lado, hy - 4,
                                    hx + 60 * lado, hy + 16),
                    cv.Path.CubicTo(hx + 38 * lado, hy + 22,
                                    hx + 13 * lado, hy + 13,
                                    hx, hy),
                    cv.Path.Close(),
                ],
                paint=pincel,
            )
        )
    return formas


_DIBUJOS = {
    "puntos": _puntos,
    "cuadricula": _cuadricula,
    "grano": _grano,
    "estrellas": _estrellas,
    "semitono": _semitono,
    "rejilla": _rejilla,
    "topografia": _topografia,
    "ola": _ola,
    "ondas": _ondas,
    "nubes": _nubes,
    "arco": _arco,
    "blob": _blob,
    "sol": _sol,
    "rama": _rama,
}
