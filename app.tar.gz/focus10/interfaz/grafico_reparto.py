"""El círculo de gastos del Dashboard: un anillo repartido entre categorías.

POR QUÉ SE DIBUJA A MANO: Flet 0.86 no trae ningún control de gráficas. Se pinta
con flet.canvas, igual que la gráfica de la semana.

POR QUÉ UN ANILLO Y NO UN QUESO MACIZO: el hueco del centro no es decoración, es
donde va el total del día. Con el queso macizo esa cifra habría que ponerla
debajo, y entonces la pieza ocupa más alto para decir lo mismo.

LO QUE NO SE PUEDE CONVERTIR NO SE DIBUJA, SE AVISA: si hay un gasto en dólares
sin tasa, el anillo reparte solo lo convertible y debajo aparece una advertencia.
Repartir el 100 % escondiendo lo que falta sería mentir con una forma bonita.
"""

from __future__ import annotations

import math

import flet as ft
import flet.canvas as cv

from ..dominio.dinero import formatear
from ..dominio.reparto import Reparto
from .estilo import COLORES_HABITO, Paleta, con_opacidad

LADO = 132
GROSOR = 18
"""Lo ancho del anillo. Más fino no se distinguirían las porciones pequeñas."""

HUECO = 0.012
"""La rendija entre porciones, en vueltas. Sin ella, dos categorías de colores
parecidos se leen como una sola porción."""

ARRANQUE = -math.pi / 2
"""Se empieza arriba, a las doce, que es por donde todo el mundo empieza a leer
un círculo. El cero de la máquina está a las tres."""

# Los colores de las porciones, en orden fijo. Son los mismos ocho de los
# hábitos: la app tiene una paleta, no una por pantalla.
ORDEN_COLORES = ("azul", "violeta", "ambar", "verde", "rosa", "cian", "naranja", "rojo")


def color_de_porcion(indice: int) -> str:
    """El color de la porción número N. Da la vuelta si hay más de ocho."""
    return COLORES_HABITO[ORDEN_COLORES[indice % len(ORDEN_COLORES)]]


def anillo(paleta: Paleta, reparto: Reparto) -> ft.Control:
    """El anillo con el total en el centro."""
    if not reparto.hay_algo:
        return _anillo_vacio(paleta)

    formas: list[cv.Shape] = [
        # El aro de fondo: sin él, un día con una sola categoría sería un círculo
        # completo y no se vería que es un anillo repartible.
        cv.Arc(
            x=GROSOR / 2,
            y=GROSOR / 2,
            width=LADO - GROSOR,
            height=LADO - GROSOR,
            start_angle=0,
            sweep_angle=2 * math.pi,
            paint=_pincel(paleta.surface_2),
        )
    ]

    vuelta = 0.0
    for indice, porcion in enumerate(reparto.porciones):
        # La rendija se le quita a la porción, no se le suma al giro: así las
        # porciones siguen sumando la vuelta entera y no se desplazan.
        ancho = max(0.0, porcion.fraccion - HUECO)
        formas.append(
            cv.Arc(
                x=GROSOR / 2,
                y=GROSOR / 2,
                width=LADO - GROSOR,
                height=LADO - GROSOR,
                start_angle=ARRANQUE + vuelta * 2 * math.pi,
                sweep_angle=ancho * 2 * math.pi,
                paint=_pincel(color_de_porcion(indice)),
            )
        )
        vuelta += porcion.fraccion

    return ft.Stack(
        [
            ft.Container(
                content=cv.Canvas(formas, width=LADO, height=LADO),
                width=LADO,
                height=LADO,
            ),
            ft.Container(
                content=ft.Column(
                    [
                        ft.Text(
                            formatear(reparto.total, reparto.principal),
                            size=15,
                            weight=ft.FontWeight.W_700,
                            color=paleta.ink,
                            text_align=ft.TextAlign.CENTER,
                        ),
                        ft.Text("del día", size=10, color=paleta.muted),
                    ],
                    spacing=0,
                    tight=True,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
                width=LADO,
                height=LADO,
                alignment=ft.Alignment.CENTER,
            ),
        ],
        width=LADO,
        height=LADO,
    )


def leyenda(paleta: Paleta, reparto: Reparto) -> ft.Control:
    """Qué categoría es cada color, con su importe.

    Va al lado del anillo y no dentro: los nombres no caben en las porciones, y
    escribirlos torcidos alrededor no se lee.
    """
    filas = [
        ft.Row(
            [
                ft.Container(
                    width=10,
                    height=10,
                    bgcolor=color_de_porcion(indice),
                    border_radius=3,
                ),
                ft.Text(porcion.categoria, size=12, color=paleta.ink, expand=True),
                ft.Text(
                    formatear(porcion.importe, reparto.principal),
                    size=12,
                    weight=ft.FontWeight.W_600,
                    color=paleta.ink_soft,
                ),
                ft.Text(
                    f"{round(100 * porcion.fraccion)}%",
                    size=11,
                    color=paleta.muted,
                    width=38,
                    text_align=ft.TextAlign.RIGHT,
                ),
            ],
            spacing=8,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )
        for indice, porcion in enumerate(reparto.porciones)
    ]
    return ft.Column(filas, spacing=7, tight=True)


def aviso_de_pendientes(paleta: Paleta, reparto: Reparto) -> ft.Control | None:
    """La advertencia de lo que no entró en el círculo, o None si entró todo."""
    if not reparto.hay_pendientes:
        return None
    cuantos = len(reparto.pendientes)
    cosa = "movimiento" if cuantos == 1 else "movimientos"
    return ft.Row(
        [
            ft.Icon(ft.Icons.WARNING_AMBER_ROUNDED, size=15, color=paleta.aviso),
            ft.Text(
                f"{cuantos} {cosa} sin tipo de cambio: no están en el círculo.",
                size=11,
                color=paleta.aviso,
                expand=True,
            ),
        ],
        spacing=6,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )


def _anillo_vacio(paleta: Paleta) -> ft.Control:
    """Un día sin gastos no es un día de cero euros: se dice con palabras."""
    return ft.Stack(
        [
            ft.Container(
                content=cv.Canvas(
                    [
                        cv.Arc(
                            x=GROSOR / 2,
                            y=GROSOR / 2,
                            width=LADO - GROSOR,
                            height=LADO - GROSOR,
                            start_angle=0,
                            sweep_angle=2 * math.pi,
                            paint=_pincel(con_opacidad(paleta.borde, 0.6)),
                        )
                    ],
                    width=LADO,
                    height=LADO,
                ),
                width=LADO,
                height=LADO,
            ),
            ft.Container(
                content=ft.Text(
                    "Sin gastos\nhoy",
                    size=12,
                    color=paleta.muted,
                    text_align=ft.TextAlign.CENTER,
                ),
                width=LADO,
                height=LADO,
                alignment=ft.Alignment.CENTER,
            ),
        ],
        width=LADO,
        height=LADO,
    )


def _pincel(color: str) -> ft.Paint:
    return ft.Paint(
        color=color,
        stroke_width=GROSOR,
        style=ft.PaintingStyle.STROKE,
        stroke_cap=ft.StrokeCap.BUTT,
    )
