"""Los emojis que se ofrecen al crear un hábito, agrupados por tema.

POR QUÉ UNA LISTA Y NO UN CAMPO DE TEXTO: escribir un emoji en Windows exige
acordarse de una combinación de teclas, y encima se puede acabar con uno que el
sistema no sabe dibujar. Con la lista, elegir uno son dos segundos y todos se ven.
El campo de escribir sigue estando, para el caso raro.

EL DETALLE QUE ROMPÍA LOS EMOJIS: algunos símbolos tienen dos versiones, la de
texto (en blanco y negro, como un carácter cualquiera) y la de emoji (en color).
Cuál sale depende de un carácter invisible que va detrás, el U+FE0F. Sin él,
"☀" se dibuja como un solecito de texto o directamente como un cuadrado vacío;
con él, "☀️" sale en color. Aquí van todos con su modificador donde hace falta,
escrito como \\ufe0f para que se vea en el código, porque de otro modo es
invisible y nadie podría revisar esta lista.
"""

from __future__ import annotations

MODIFICADOR = "️"
"""El carácter invisible que convierte un símbolo de texto en emoji de color."""

# Cada tema con sus emojis. El orden es el que se ve en la cuadrícula.
POR_TEMA: dict[str, tuple[str, ...]] = {
    "Dinero": ("\U0001f4b0", "\U0001f4b5", "\U0001f4b3", "\U0001f3e6", "\U0001f4c8"),
    "Estudio": ("\U0001f4da", "\U0001f393", "\U0001f4bb", "\U0001f9e0", "\U0001f4dd"),
    "Salud": ("\U0001f4a7", "\U0001f48a", "\U0001f634", "\U0001faa5", "\U0001f9b7"),
    "Deporte": (
        "\U0001f3cb" + MODIFICADOR,
        "\U0001f3c3",
        "\U0001f6b4",
        "\U0001f9d8",
        "⚽",  # este ya sale en color sin modificador
    ),
    "Comida": ("\U0001f34e", "\U0001f957", "\U0001f373", "\U0001f95b", "\U0001f372"),
    "Casa": ("\U0001f9f9", "\U0001f9fa", "\U0001fab4", "\U0001f6cf" + MODIFICADOR, "\U0001f415"),
    "Ocio": ("\U0001f3b8", "\U0001f3ae", "\U0001f4d6", "\U0001f3a7", "✈" + MODIFICADOR),
    "Otros": (
        "☀" + MODIFICADOR,
        "✅",
        "⭐",
        "\U0001f525",
        "⏰",
    ),
}

POR_OMISION = "✅"
"""El de la marca verde: sirve para cualquier cosa y siempre se dibuja."""


def todos() -> tuple[str, ...]:
    """Todos los emojis de la lista, sin agrupar."""
    return tuple(uno for grupo in POR_TEMA.values() for uno in grupo)
