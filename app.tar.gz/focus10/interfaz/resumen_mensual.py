"""El calendario del mes: cómo fue cada día, de un vistazo.

LO PIDIÓ EL USUARIO: "un calendario mensual visual donde pueda ver de forma
rápida cómo fue cada día... con iconos, checks, colores y pequeños indicadores
en lugar de textos largos", y "que se sienta como un diario de progreso, pero
organizado automáticamente a partir de los datos que ya fui registrando".

AQUÍ NO SE APUNTA NADA, SOLO SE MIRA. Todo lo que sale ya se escribió en su
sección: la comida en Alimentación, los pesos en Gimnasio, la nota al finalizar
el día. Esta pantalla no añade un dato nuevo que haya que mantener al día.

EL MES SE LEE EN SEIS CONSULTAS Y NO EN TREINTA. Se pide cada cosa por rango
—las marcas de hábitos, los totales por jornada, las sesiones— y luego se reparte
por días en memoria. Pedirlo día a día serían casi doscientas consultas para
pintar una pantalla que se abre y se cierra en dos segundos.

LOS DÍAS QUE NO HAN PASADO SE DEJAN VACÍOS. Es la misma regla del calendario de
la comida y por el mismo motivo: pintar de rojo veinte días que no has vivido es
acusarte de fallar en el futuro.
"""

from __future__ import annotations

import sqlite3
from datetime import date, timedelta
from typing import Callable

import flet as ft

from ..datos import (
    ajustes,
    repositorio_alimentacion,
    repositorio_dias,
    repositorio_gimnasio,
    repositorio_habitos,
    repositorio_movimientos,
    repositorio_tareas,
)
from ..datos.bd import conectado
from ..dominio.agua import total as total_agua
from ..dominio.cumplimiento import Cumplimiento, ResumenDeDia, cumplimiento_de
from ..dominio.moneda import Moneda
from ..dominio.nutricion import sumar
from ..dominio.resumen_comida import mes_de, por_dia
from ..dominio.semana import LETRAS, texto_mes
from ..dominio.resumen_diario import DiaResumido
from . import calendario_comida, componentes, dialogo_dia, estilo
from .estilo import Paleta

ANCHO = 46
ALTO = 54
"""Lo que mide cada día, como mucho. EN EL MÓVIL SE ACHICA para que entren los
siete (estilo.lado_de_casilla): fijo en 46 no cabía en la ventanita, que
tiene sus márgenes, y el sábado y el domingo quedaban cortados (lo mandó el
usuario en una captura del celular, el 15 nov 2026)."""

ESPACIO = 4
"""Entre día y día."""

VENTANA_MARGEN_MOVIL = 8
"""Lo que la ventanita del mes deja hasta el borde del celular, por lado. La
de serie (40) se comía casi un cuarto de la pantalla."""

VENTANA_RELLENO_MOVIL = 12
"""El relleno de dentro de la ventanita del mes en el celular, por lado."""

MARGEN_VENTANA_MOVIL = 2 * VENTANA_MARGEN_MOVIL + 2 * VENTANA_RELLENO_MOVIL + 8
"""Lo que no es calendario en la ventanita del mes: sus márgenes, su relleno y
8 de holgura para que una barra de desplazamiento no empuje el domingo fuera."""


def del_mes(
    conexion: sqlite3.Connection, desde: date, hasta: date, hoy: date
) -> dict[date, DiaResumido]:
    """Cómo fue cada día del tramo. Un DiaResumido por fecha, incluidos los vacíos.

    TODOS LOS DÍAS ESTÁN, también los que no tienen nada: el calendario necesita
    la casilla para dibujar la rejilla, y un día vacío se dibuja vacío.
    """
    objetivos = repositorio_alimentacion.leer_objetivos(conexion)
    comida = {
        uno.jornada: cumplimiento_de(uno, objetivos, hoy)
        for uno in por_dia(
            repositorio_alimentacion.listar_entre(conexion, desde, hasta), desde, hasta
        )
    }

    habitos = repositorio_habitos.listar(conexion)
    cantidades = repositorio_habitos.cantidades_de_todos(conexion, desde, hasta)

    # ABRIR EL ENTRENO Y NO HACER NADA NO CUENTA COMO ENTRENAR: es la regla que
    # ya tiene la propia sesión (`entrenado`), y usarla aquí evita que el
    # calendario se llene de pesas de días que solo se miraron.
    #
    # HAY COMO MUCHO UN ENTRENO POR DÍA: la tabla lo obliga (fecha UNIQUE).
    sesiones = {
        sesion.fecha: sesion
        for sesion in repositorio_gimnasio.sesiones_entre(conexion, desde, hasta)
        if sesion.entrenado
    }

    gastos = {
        uno.jornada: uno.gastos
        for uno in repositorio_movimientos.totales_por_jornada(conexion, desde, hasta)
    }

    tareas: dict[date, list[str]] = {}
    for tarea in repositorio_tareas.hechas_entre(conexion, desde, hasta):
        tareas.setdefault(tarea.hecha_en, []).append(tarea.titulo)

    notas = {
        uno.jornada: uno for uno in repositorio_dias.entre(conexion, desde, hasta)
    }

    mes: dict[date, DiaResumido] = {}
    jornada = desde
    while jornada <= hasta:
        cerrado = notas.get(jornada)
        sesion = sesiones.get(jornada)
        mes[jornada] = DiaResumido(
            jornada=jornada,
            comida=comida.get(jornada, Cumplimiento.SIN_OBJETIVO),
            entreno=sesion is not None,
            entreno_nombre=sesion.nombre if sesion else "",
            ejercicios=(
                tuple(uno.nombre for uno in sesion.ejercicios if uno.hechas)
                if sesion
                else ()
            ),
            mejor_peso=sesion.mejor_peso if sesion else 0,
            habitos=_habitos_de(habitos, cantidades, jornada),
            tareas=tuple(tareas.get(jornada, ())),
            gasto=gastos.get(jornada, 0),
            nota="" if cerrado is None else cerrado.reflexion,
            valoracion=None if cerrado is None else cerrado.valoracion,
        )
        jornada += timedelta(days=1)
    return mes


def _habitos_de(habitos, cantidades, jornada: date) -> tuple[tuple[str, bool], ...]:
    """Los hábitos que tocaban ese día, con si se cumplieron.

    SE PREGUNTA AL PROPIO HÁBITO —`toca_en` y `cumplido_con`— que es lo mismo que
    hace el recuento de las rachas. Repetir aquí la regla de "cuándo toca" sería
    tener dos verdades que algún día no coincidirían.
    """
    return tuple(
        (
            # SOLO EL NOMBRE: esto devuelve texto, y un icono es un
            # dibujo. Antes iba el emoji pegado delante.
            uno.nombre,
            uno.cumplido_con(cantidades.get((uno.id, jornada), 0)),
        )
        for uno in habitos
        if uno.toca_en(jornada)
    )


def rejilla(
    paleta: Paleta,
    mes: dict[date, DiaResumido],
    hoy: date,
    *,
    al_tocar: Callable[[date], None],
    margen: int | None = None,
) -> ft.Control:
    """El mes entero, de lunes a domingo.

    `margen`: lo que no es calendario alrededor, en el móvil. Por omisión, el
    de una tarjeta de una sección (la pestaña de Horario); la ventanita del
    Dashboard pasa el suyo (MARGEN_VENTANA_MOVIL).
    """
    if not mes:
        return componentes.aviso_vacio(paleta, "No hay días que enseñar.")

    ancho = estilo.lado_de_casilla(ANCHO, espacio=ESPACIO, margen=margen)
    dias = sorted(mes)
    filas: list[ft.Control] = [
        ft.Row(
            [
                ft.Container(
                    content=ft.Text(
                        letra,
                        size=estilo.ROTULO,
                        color=paleta.muted,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    width=ancho,
                    alignment=ft.Alignment.CENTER,
                )
                for letra in LETRAS
            ],
            spacing=ESPACIO,
        )
    ]

    fila: list[ft.Control] = [
        ft.Container(width=ancho, height=ALTO) for _ in range(dias[0].weekday())
    ]
    for jornada in dias:
        fila.append(_casilla(paleta, mes[jornada], hoy, al_tocar, ancho))
        if len(fila) == 7:
            filas.append(ft.Row(fila, spacing=ESPACIO))
            fila = []
    if fila:
        filas.append(ft.Row(fila, spacing=ESPACIO))

    return ft.Column(filas, spacing=ESPACIO, tight=True)


def iconos_de(dia: DiaResumido) -> str:
    """Los avisos del día en una tira corta: "🏋️💰📝".

    SON LOS QUE PIDIÓ EL USUARIO, y solo salen los que hay: una casilla con tres
    iconos en gris de "esto no pasó" ocupa lo mismo y no dice nada.
    """
    tira = ""
    if dia.entreno:
        tira += "🏋️"
    if dia.tareas:
        tira += "✅"
    if dia.gasto:
        tira += "💰"
    if dia.nota:
        tira += "📝"
    return tira


def _color_habitos(paleta: Paleta, dia: DiaResumido) -> str:
    """Verde si salieron todos, ámbar si algunos, rojo si ninguno."""
    if dia.habitos_cumplidos == dia.habitos_programados:
        return paleta.positivo
    if dia.habitos_cumplidos:
        return paleta.aviso
    return paleta.negativo


def _casilla(
    paleta: Paleta,
    dia: DiaResumido,
    hoy: date,
    al_tocar: Callable[[date], None],
    ancho: int = ANCHO,
) -> ft.Control:
    """Un día: el número, cómo fueron los hábitos y los iconos de lo que hubo.

    EL FONDO ES EL COLOR DE LA COMIDA, igual que en el calendario de
    Alimentación: es el dato que se mira desde lejos, y así los dos calendarios
    se leen con la misma regla en vez de con dos.
    """
    futuro = dia.jornada > hoy
    es_hoy = dia.jornada == hoy
    fondo = (
        calendario_comida.color_de(paleta, Cumplimiento.FUTURO)
        if futuro
        else calendario_comida.color_de(paleta, dia.comida)
    )

    arriba: list[ft.Control] = [
        ft.Text(
            str(dia.jornada.day),
            size=estilo.ROTULO,
            color=paleta.muted if futuro else paleta.ink,
            expand=True,
        )
    ]
    if not futuro and dia.hubo_habitos:
        arriba.append(
            ft.Text(
                dia.texto_habitos(),
                size=estilo.ROTULO,
                weight=ft.FontWeight.W_600,
                color=_color_habitos(paleta, dia),
            )
        )

    return ft.Container(
        content=ft.Column(
            [
                ft.Row(arriba, spacing=2),
                ft.Text("" if futuro else iconos_de(dia), size=10),
            ],
            spacing=2,
            tight=True,
        ),
        width=ancho,
        height=ALTO,
        # MENOS RELLENO SI LA CASILLA SE ACHICÓ: en el móvil, el número y los
        # «3/5» necesitan cada punto para no partirse en dos líneas.
        padding=ft.Padding.symmetric(horizontal=4 if ancho >= ANCHO else 2, vertical=3),
        bgcolor=fondo,
        # EL DÍA EN EL QUE ESTÁS VA CON CONTORNO, lo pidió el usuario. Se marca
        # con el borde y no con el fondo porque el fondo ya está diciendo cómo
        # fue la comida, y dos cosas en el mismo sitio no se pueden leer.
        border=ft.Border.all(
            2 if es_hoy else 1, paleta.aviso if es_hoy else paleta.borde
        ),
        border_radius=estilo.RADIO_CAMPO,
        tooltip=_ayuda(dia, futuro, es_hoy),
        # UN DÍA QUE NO HA PASADO NO SE ABRE: no hay nada dentro que enseñar.
        on_click=None if futuro else (lambda _, d=dia.jornada: al_tocar(d)),
    )


def _ayuda(dia: DiaResumido, futuro: bool, es_hoy: bool = False) -> str:
    """Lo que se lee al pasar el ratón. Un renglón, sin adornos."""
    if futuro:
        return f"{dia.jornada.day}: todavía no ha pasado"
    cabeza = f"{dia.jornada.day}" + (" (hoy)" if es_hoy else "")
    if not dia.hay_algo:
        return f"{cabeza}: no apuntaste nada"
    partes = [calendario_comida.texto_de(dia.comida)]
    if dia.hubo_habitos:
        partes.append(f"hábitos {dia.texto_habitos()}")
    if dia.entreno:
        partes.append("entrenaste")
    if dia.tareas:
        partes.append(f"{len(dia.tareas)} hechas")
    return f"{cabeza}: " + ", ".join(partes)


def leyenda(paleta: Paleta) -> ft.Control:
    """Qué quiere decir cada cosa de la casilla.

    HACE FALTA porque el fondo habla de la comida y el número de arriba a la
    derecha habla de los hábitos: son dos cosas distintas en el mismo cuadradito
    y sin decirlo cada uno entendería una.
    """
    return ft.Column(
        [
            calendario_comida.leyenda(paleta),
            ft.Text(
                "El color es la alimentación · el número, los hábitos "
                "cumplidos · 🏋️ entreno · ✅ tareas · 💰 gastos · 📝 nota",
                size=estilo.ROTULO,
                color=paleta.muted,
            ),
        ],
        spacing=8,
        tight=True,
    )


def abrir(pagina: ft.Page, paleta: Paleta) -> ft.AlertDialog:
    """La ventana con el mes entero. Se abre desde el Dashboard.

    LO PIDIÓ EL USUARIO ASÍ: "que sea como un pop up, aparezca y que te ponga
    todo". Se abre encima de donde estabas y se cierra volviendo al mismo sitio.

    SOLO EL MES EN CURSO. También lo pidió él —"cuando cambia el mes se
    reinicia... tampoco quiero que sea tan pesado"—. Los días viejos siguen
    guardados: lo que no se hace es traérselos todos a esta ventana.
    """
    with conectado() as conexion:
        jornada = repositorio_dias.jornada_abierta(conexion)
        desde, hasta = mes_de(jornada)
        mes = del_mes(conexion, desde, hasta, jornada)
        moneda = ajustes.leer_moneda_principal(conexion)

    # EN EL CELULAR LA VENTANITA VA CASI DE BORDE A BORDE: con sus márgenes de
    # serie y un ancho fijo de 360, en una pantalla de 384 el sábado quedaba
    # cortado y el domingo ni se veía (captura del usuario, 15 nov 2026).
    estrecha = estilo.pantalla_estrecha()
    relleno = VENTANA_RELLENO_MOVIL
    ventanita = ft.AlertDialog(
        modal=True,
        inset_padding=(
            ft.Padding.symmetric(horizontal=VENTANA_MARGEN_MOVIL, vertical=24) if estrecha else None
        ),
        title_padding=ft.Padding.only(left=relleno, right=relleno, top=20) if estrecha else None,
        content_padding=(
            ft.Padding.only(left=relleno, right=relleno, top=16, bottom=8) if estrecha else None
        ),
        title=ft.Text(
            texto_mes(jornada),
            size=15,
            weight=ft.FontWeight.W_600,
            color=paleta.ink,
        ),
        content=ft.Container(
            content=ft.Column(
                [
                    ft.Text(
                        "Toca un día para ver cómo fue.",
                        size=estilo.TEXTO_APOYO,
                        color=paleta.muted,
                    ),
                    rejilla(
                        paleta,
                        mes,
                        jornada,
                        al_tocar=lambda cual: abrir_dia(
                            pagina, paleta, mes[cual], moneda
                        ),
                        margen=MARGEN_VENTANA_MOVIL,
                    ),
                    leyenda(paleta),
                ],
                spacing=12,
                tight=True,
                scroll=ft.ScrollMode.AUTO,
            ),
            # En el celular, lo que pidan los siete días; en la PC, fijo.
            width=None if estrecha else 360,
        ),
        bgcolor=paleta.surface,
        actions=[ft.TextButton("Cerrar", on_click=lambda _: pagina.pop_dialog())],
        actions_alignment=ft.MainAxisAlignment.END,
    )
    pagina.show_dialog(ventanita)
    return ventanita


def abrir_dia(
    pagina: ft.Page, paleta: Paleta, dia: DiaResumido, moneda: Moneda
) -> ft.AlertDialog:
    """La ficha de un día: la nota, la comida, el agua, el entreno, los hábitos.

    SE VUELVE A LA BASE A POR LAS COMIDAS Y LOS TRAGOS porque el resumen del mes
    solo guarda SI cumpliste, no QUÉ comiste, y aquí se quiere el detalle.

    ES LA VENTANA DEL CALENDARIO DE ALIMENTACIÓN con el resto del día añadido, y
    la usan los dos sitios desde los que se llega al mes —la ventana del
    Dashboard y la pestaña de Horario—. Una segunda ficha del mismo día acabaría
    contando otra cosa.
    """
    with conectado() as conexion:
        registros = repositorio_alimentacion.listar_del_dia(conexion, dia.jornada)
        tragos = repositorio_alimentacion.tragos_del_dia(conexion, dia.jornada)
        objetivos = repositorio_alimentacion.leer_objetivos(conexion)
        objetivo_agua = repositorio_alimentacion.leer_objetivo_agua(conexion)

    return dialogo_dia.abrir(
        pagina,
        paleta,
        ResumenDeDia(
            jornada=dia.jornada,
            totales=sumar(registros),
            objetivos=objetivos,
            registros=tuple(registros),
            agua_ml=total_agua(tragos),
            objetivo_agua=objetivo_agua,
        ),
        extra=dia,
        moneda=moneda,
    )
