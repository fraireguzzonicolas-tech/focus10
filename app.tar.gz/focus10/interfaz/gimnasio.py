"""El apartado del gimnasio: las vistas de mirar y planear.

  RUTINA      el plan de la semana. Los siete días, y el botón de empezar.
  CALENDARIO  el mes, con los días que se entrenó de verdad.
  PROGRESO    lo que se ha hecho. Sin estimaciones de ninguna clase.

AQUÍ NO SE ENTRENA. Había una vista «Hoy» con el entreno del día dentro. La
quitó el usuario: «eso ya se ve en el dashboard». Entrenar se fue a su propia
pantalla (interfaz/entreno.py), que se abre encima de todo al pulsar «Empezar
entreno» y que no lleva menú: con las manos ocupadas, media pantalla de un móvil
en enlaces que no vas a pulsar no vale para nada.

Y AQUÍ TAMPOCO SE ADMINISTRA LA BIBLIOTECA. Había una vista «Ejercicios» solo
para crear, corregir y borrar fichas; se quitó por lo mismo, y eso vive ahora
dentro de la ventanita de añadir un ejercicio: es el momento en que te das
cuenta de que te falta uno.

CADA VISTA EN SU ARCHIVO: este solo tiene el armazón, y las vistas están en
gimnasio_*.py. Todo junto serían mil y pico líneas en las que no se encuentra
nada.

LA SEPARACIÓN PLAN / EJECUTADO SIGUE MANDANDO: la vista de RUTINA escribe en la
rutina, y la pantalla de entrenar escribe en la sesión. Ninguna de las dos toca
la tabla de la otra, así que cambiar el peso un mal día no reescribe el plan.
"""

from __future__ import annotations

from datetime import date, timedelta
from enum import StrEnum

import flet as ft

from ..datos import repositorio_dias, repositorio_ejercicios, repositorio_gimnasio
from ..datos.bd import conectado
from ..dominio.semana import texto_mes
from . import componentes, estilo
from .estilo import Paleta
from .franja_descanso import FranjaDescanso

VISTAS = (
    ("rutina", "Rutina"),
    ("calendario", "Calendario"),
    ("progreso", "Progreso"),
)


class Vista(StrEnum):
    RUTINA = "rutina"
    CALENDARIO = "calendario"
    PROGRESO = "progreso"


class PantallaGimnasio(componentes.Pantalla):
    def __init__(
        self,
        pagina: ft.Page,
        paleta: Paleta,
        franja: FranjaDescanso | None = None,
        al_entrenar=None,
    ) -> None:
        super().__init__(pagina, paleta)
        self.franja = franja
        # ABRIR LA PANTALLA DE ENTRENAR NO LO SABE HACER ESTA PANTALLA: sustituye
        # la ventana entera, y eso solo lo puede hacer quien la montó. Por eso se
        # recibe de fuera, igual que el cambio de tema.
        self.al_entrenar = al_entrenar
        self.vista = Vista.RUTINA
        self.mes_mirado = 0
        """Meses hacia atrás en el calendario."""

        self.contenido = ft.Column(spacing=estilo.DENSIDAD, scroll=ft.ScrollMode.AUTO,
                                   expand=True)
        self.refrescar()

    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            self.hoy = repositorio_dias.jornada_abierta(conexion)
            self.rutina = repositorio_gimnasio.leer_rutina(conexion)
            self.ejercicios = repositorio_ejercicios.listar(conexion)

        piezas: list[ft.Control] = [self._cabecera(), self._selector()]
        piezas += self._vista_actual()

        self.pintar(piezas)

    def _cabecera(self) -> ft.Control:
        return componentes.titulo_pagina(self.paleta, "Gimnasio", self._subtitulo())

    def _subtitulo(self) -> str:
        if self.vista is Vista.CALENDARIO:
            mes = self._primero_del_mes()
            return texto_mes(mes)
        return dict(VISTAS)[self.vista.value]

    def _selector(self) -> ft.Control:
        return componentes.segmentado(
            self.paleta, VISTAS, self.vista.value, self._cambiar_vista
        )

    def _cambiar_vista(self, clave: str) -> None:
        nueva = Vista(clave)
        if nueva is self.vista:
            return
        self.vista = nueva
        self.refrescar()

    def _vista_actual(self) -> list[ft.Control]:
        # Los import van aquí y no arriba a propósito: gimnasio_calendario
        # necesita llamar a esta pantalla para abrir un día, y con los import
        # arriba los dos archivos se pedirían el uno al otro en círculo.
        if self.vista is Vista.CALENDARIO:
            from . import gimnasio_calendario

            return gimnasio_calendario.vista(self)
        if self.vista is Vista.RUTINA:
            from . import gimnasio_rutina

            return gimnasio_rutina.vista(self)
        from . import gimnasio_progreso

        return gimnasio_progreso.vista(self)

    # ----------------------------------------------------------------------
    # Utilidades que usan las demás vistas
    # ----------------------------------------------------------------------

    def _primero_del_mes(self) -> date:
        primero = self.hoy.replace(day=1)
        for _ in range(self.mes_mirado):
            primero = (primero - timedelta(days=1)).replace(day=1)
        return primero

    def abrir_dia(self, dia: date) -> None:
        """Abre el entreno de un día. Lo llama el calendario al tocar una casilla.

        SOLO SI YA HAY ENTRENO ESE DÍA. Tocar un martes de hace tres semanas en
        el calendario es querer VER lo que hiciste, no empezar un entreno con
        fecha de hace tres semanas.
        """
        if self.al_entrenar is None:
            return
        with conectado() as conexion:
            if repositorio_gimnasio.sesion_de(conexion, dia) is None:
                return
        self.al_entrenar(dia)

    # ----------------------------------------------------------------------
    # HOY: el entreno del día
    # ----------------------------------------------------------------------
