"""El apartado del gimnasio: cinco vistas dentro de una pantalla.

  HOY         el entreno del día. Es a lo que se viene el 90 % de las veces, y
              por eso es la vista de entrada.
  CALENDARIO  el mes, con los días que se entrenó de verdad.
  RUTINA      el plan de la semana. Los siete días.
  EJERCICIOS  la biblioteca.
  PROGRESO    lo que se ha hecho. Sin estimaciones de ninguna clase.

CADA VISTA EN SU ARCHIVO. Este solo tiene el armazón y la de HOY, que es la que
más manda: las otras están en gimnasio_*.py. Todo junto serían mil y pico líneas
en las que no se encuentra nada.

LA SEPARACIÓN PLAN / EJECUTADO SE NOTA AQUÍ: la vista de RUTINA escribe en la
rutina y la de HOY escribe en la sesión, y ninguna de las dos toca la tabla de
la otra. Cambiar el peso un mal día no reescribe el plan.
"""

from __future__ import annotations

from datetime import date, timedelta
from enum import StrEnum

import flet as ft

from ..datos import repositorio_ejercicios, repositorio_gimnasio
from ..datos.ajustes import leer_horario
from ..datos.bd import conectado
from ..dominio.descanso import (
    parsear_descanso,
    parsear_duracion,
    texto_descanso,
    texto_duracion,
)
from ..dominio.ejercicio import Medida
from ..dominio.jornada import jornada_actual
from ..dominio.rutina import dia_de, texto_peso
from ..dominio.sesion import (
    EjercicioDeSesion,
    Sesion,
    anadir_serie,
    con_serie,
    desde_rutina,
    quitar_serie,
    texto_volumen,
)
from . import componentes, estilo
from .estilo import Paleta
from .franja_descanso import FranjaDescanso

VISTAS = (
    ("hoy", "Hoy"),
    ("calendario", "Calendario"),
    ("rutina", "Rutina"),
    ("ejercicios", "Ejercicios"),
    ("progreso", "Progreso"),
)

MESES = (
    "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
)


class Vista(StrEnum):
    HOY = "hoy"
    CALENDARIO = "calendario"
    RUTINA = "rutina"
    EJERCICIOS = "ejercicios"
    PROGRESO = "progreso"


class PantallaGimnasio:
    def __init__(
        self,
        pagina: ft.Page,
        paleta: Paleta,
        franja: FranjaDescanso | None = None,
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.franja = franja
        self.vista = Vista.HOY
        self.dia_mirado: date | None = None
        """Qué día se está mirando en la vista de HOY. None quiere decir hoy.

        Existe para poder entrar a un día desde el calendario sin inventar una
        sexta vista: es el mismo entreno, otro día."""

        self.mes_mirado = 0
        """Meses hacia atrás en el calendario."""

        self.contenido = ft.Column(spacing=estilo.DENSIDAD, scroll=ft.ScrollMode.AUTO,
                                   expand=True)
        self._en_pagina = False
        self.refrescar()

    @property
    def control(self) -> ft.Control:
        return self.contenido

    def montada(self) -> None:
        self._en_pagina = True

    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            self.hoy = jornada_actual(leer_horario(conexion))
            self.rutina = repositorio_gimnasio.leer_rutina(conexion)
            self.ejercicios = repositorio_ejercicios.listar(conexion)

        piezas: list[ft.Control] = [self._cabecera(), self._selector()]
        piezas += self._vista_actual()

        self.contenido.controls = piezas
        if self._en_pagina:
            self.contenido.update()

    def _cabecera(self) -> ft.Control:
        return componentes.titulo_pagina(self.paleta, "Gimnasio", self._subtitulo())

    def _subtitulo(self) -> str:
        if self.vista is Vista.HOY:
            dia = self._dia()
            if dia == self.hoy:
                return "Hoy"
            return f"{dia.day} de {MESES[dia.month - 1]}"
        if self.vista is Vista.CALENDARIO:
            mes = self._primero_del_mes()
            return f"{MESES[mes.month - 1].capitalize()} {mes.year}"
        return dict(VISTAS)[self.vista.value]

    def _selector(self) -> ft.Control:
        return componentes.segmentado(
            self.paleta, VISTAS, self.vista.value, self._cambiar_vista
        )

    def _cambiar_vista(self, clave: str) -> None:
        nueva = Vista(clave)
        if nueva is self.vista:
            return
        self.vista = nueva
        # Al salir de HOY se olvida el día que se estaba mirando: si no, volver
        # a "Hoy" desde el calendario te dejaría en un martes de hace tres
        # semanas sin que se vea por qué.
        if nueva is not Vista.HOY:
            self.dia_mirado = None
        self.refrescar()

    def _vista_actual(self) -> list[ft.Control]:
        # Los import van aquí y no arriba a propósito: gimnasio_calendario
        # necesita llamar a esta pantalla para abrir un día, y con los import
        # arriba los dos archivos se pedirían el uno al otro en círculo.
        if self.vista is Vista.HOY:
            return self._vista_hoy()
        if self.vista is Vista.CALENDARIO:
            from . import gimnasio_calendario

            return gimnasio_calendario.vista(self)
        if self.vista is Vista.RUTINA:
            from . import gimnasio_rutina

            return gimnasio_rutina.vista(self)
        if self.vista is Vista.EJERCICIOS:
            from . import gimnasio_ejercicios

            return gimnasio_ejercicios.vista(self)
        from . import gimnasio_progreso

        return gimnasio_progreso.vista(self)

    # ----------------------------------------------------------------------
    # Utilidades que usan las demás vistas
    # ----------------------------------------------------------------------

    def _dia(self) -> date:
        return self.dia_mirado or self.hoy

    def _primero_del_mes(self) -> date:
        primero = self.hoy.replace(day=1)
        for _ in range(self.mes_mirado):
            primero = (primero - timedelta(days=1)).replace(day=1)
        return primero

    def abrir_dia(self, dia: date) -> None:
        """Entra al entreno de un día. Lo llama el calendario."""
        self.dia_mirado = None if dia == self.hoy else dia
        self.vista = Vista.HOY
        self.refrescar()

    # ----------------------------------------------------------------------
    # HOY: el entreno del día
    # ----------------------------------------------------------------------

    def _vista_hoy(self) -> list[ft.Control]:
        dia = self._dia()

        # UNA SOLA CONEXION PARA TODO, y esto importa mas de lo que parece: esta
        # pantalla se repinta entera cada vez que sales de una casilla de peso,
        # o sea decenas de veces por entreno. Con una conexion por ejercicio
        # —que es como estaba escrito primero— seis ejercicios eran siete
        # aperturas de la base por cada tecla, y de pie en el gimnasio eso se
        # nota como que la aplicacion va a tirones.
        with conectado() as conexion:
            sesion = repositorio_gimnasio.sesion_de(conexion, dia)
            anteriores: dict[int, EjercicioDeSesion] = {}
            if sesion is not None:
                for uno in sesion.ejercicios:
                    if uno.ejercicio_id is None:
                        continue
                    vieja = repositorio_gimnasio.ultima_vez(
                        conexion, uno.ejercicio_id, dia
                    )
                    if vieja is not None:
                        anteriores[uno.ejercicio_id] = vieja

        planeado = dia_de(dia, self.rutina)

        if sesion is None:
            return self._sin_empezar(dia, planeado)

        piezas: list[ft.Control] = [self._resumen_del_entreno(sesion)]
        piezas += [
            self._tarjeta_ejercicio(sesion, uno, anteriores.get(uno.ejercicio_id))
            for uno in sesion.ejercicios
        ]
        piezas.append(self._pie_del_entreno(sesion))
        return piezas

    def _sin_empezar(self, dia: date, planeado) -> list[ft.Control]:
        """Lo que se ve antes de empezar: qué toca, y el botón de arrancar."""
        if planeado.es_descanso:
            texto = "Hoy toca descansar. Descansar también es entrenar."
        elif not planeado.hay_entreno:
            texto = (
                "Este día no tiene nada asignado. Ponle ejercicios en la vista "
                "de Rutina, o empieza un entreno suelto."
            )
        else:
            texto = f"Toca «{planeado.titulo()}», {len(planeado.ejercicios)} ejercicios."

        detalle: list[ft.Control] = [
            ft.Text(texto, size=estilo.TEXTO_TARJETA, color=self.paleta.ink)
        ]
        if planeado.hay_entreno:
            detalle += [
                ft.Container(height=6),
                *[
                    ft.Text(
                        f"{uno.nombre} · {uno.texto_objetivo()}",
                        size=estilo.TEXTO,
                        color=self.paleta.ink_soft,
                    )
                    for uno in sorted(planeado.ejercicios, key=lambda x: x.orden)
                ],
            ]

        detalle += [
            ft.Container(height=14),
            componentes.boton(
                self.paleta,
                "Empezar entreno" if planeado.hay_entreno else "Entrenar igualmente",
                icono=ft.Icons.PLAY_ARROW,
                principal=True,
                al_pulsar=lambda _: self._empezar(dia, planeado),
            ),
        ]
        return [componentes.tarjeta(self.paleta, ft.Column(detalle, spacing=2, tight=True))]

    def _empezar(self, dia: date, planeado) -> None:
        """Crea la sesión del día COPIANDO la rutina. No al revés, nunca.

        Un entreno suelto —sin nada planeado— se crea vacío y se le añaden
        ejercicios a mano. Sirve para el día que apareces y haces otra cosa, que
        pasa, y que no debería obligarte a cambiar el plan de la semana.
        """
        sesion = desde_rutina(planeado, dia)
        with conectado() as conexion:
            repositorio_gimnasio.guardar_sesion(conexion, sesion)
        self.refrescar()

    def _resumen_del_entreno(self, sesion: Sesion) -> ft.Control:
        return componentes.tarjeta(
            self.paleta,
            ft.Row(
                [
                    componentes.cifra(
                        self.paleta, "Series hechas", str(sesion.series_hechas)
                    ),
                    componentes.cifra(
                        self.paleta, "Volumen", texto_volumen(sesion.volumen)
                    ),
                    componentes.cifra(
                        self.paleta, "Ejercicios", str(len(sesion.ejercicios))
                    ),
                    ft.Container(expand=True),
                    ft.Text(
                        sesion.titulo(),
                        size=estilo.TITULAR,
                        color=self.paleta.ink,
                        font_family=self.paleta.titular,
                    ),
                ],
                spacing=30,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )

    def _tarjeta_ejercicio(
        self,
        sesion: Sesion,
        ejercicio: EjercicioDeSesion,
        anterior: EjercicioDeSesion | None,
    ) -> ft.Control:
        filas = [
            self._fila_de_serie(sesion, ejercicio, serie, anterior)
            for serie in ejercicio.series
        ]

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        ejercicio.nombre,
                        f"{ejercicio.hechas} de {len(ejercicio.series)} series",
                        ft.Row(
                            [
                                self._campo_descanso(sesion, ejercicio),
                                componentes.boton(
                                    self.paleta,
                                    "+ serie",
                                    al_pulsar=lambda _, e=ejercicio: (
                                        self._anadir_serie(sesion, e)
                                    ),
                                ),
                            ],
                            spacing=10,
                            tight=True,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                    ),
                    componentes.tabla(
                        self.paleta,
                        [
                            ("SERIE", 56),
                            ("LA VEZ ANTERIOR", 150),
                            ("DURACIÓN", 130),
                            ("", None),
                        ]
                        if self._es_de_tiempo(ejercicio)
                        else [
                            ("SERIE", 56),
                            ("LA VEZ ANTERIOR", 150),
                            ("PESO", 130),
                            ("REPS", 110),
                            ("", None),
                        ],
                        filas,
                    ),
                ],
                spacing=12,
            ),
        )

    def _fila_de_serie(
        self,
        sesion: Sesion,
        ejercicio: EjercicioDeSesion,
        serie,
        anterior: EjercicioDeSesion | None,
    ) -> list[ft.Control]:
        paleta = self.paleta

        # "LO QUE HICE LA VEZ ANTERIOR", en gris. Es el dato que de verdad decide
        # qué peso poner hoy, y por eso está en la misma fila y no en una nota
        # aparte que habría que ir a buscar.
        vieja = anterior.serie(serie.numero) if anterior else None
        texto_anterior = vieja.texto() if vieja else "—"

        if self._es_de_tiempo(ejercicio):
            # UN EJERCICIO DE TIEMPO NO TIENE KILOS NI REPETICIONES. Enseñar
            # esas casillas a cero no es neutral: invita a rellenarlas con algo
            # que luego no quiere decir nada, y de paso ensucia el volumen.
            campo_tiempo = componentes.campo_texto(
                paleta, "", valor=texto_duracion(serie.segundos), ancho=118
            )
            campo_tiempo.tooltip = "30min, 30:00, 45s, 1h30... como quieras"
            campo_tiempo.on_blur = (
                lambda _, n=serie.numero, c=campo_tiempo: self._guardar_tiempo(
                    sesion, ejercicio, n, c
                )
            )
            return [
                ft.Text(str(serie.numero), size=estilo.TEXTO, color=paleta.ink),
                ft.Text(texto_anterior, size=estilo.TEXTO, color=paleta.muted),
                campo_tiempo,
                self._acciones_de_serie(sesion, ejercicio, serie),
            ]

        campo_peso = componentes.campo_texto(
            paleta, "", valor=_kilos(serie.peso), ancho=118
        )
        campo_peso.on_blur = lambda _, n=serie.numero, c=campo_peso: self._guardar_peso(
            sesion, ejercicio, n, c
        )
        campo_reps = componentes.campo_texto(
            paleta, "", valor=str(serie.repeticiones), ancho=98
        )
        campo_reps.on_blur = lambda _, n=serie.numero, c=campo_reps: self._guardar_reps(
            sesion, ejercicio, n, c
        )

        return [
            ft.Text(str(serie.numero), size=estilo.TEXTO, color=paleta.ink),
            ft.Text(texto_anterior, size=estilo.TEXTO, color=paleta.muted),
            campo_peso,
            campo_reps,
            self._acciones_de_serie(sesion, ejercicio, serie),
        ]

    def _acciones_de_serie(self, sesion, ejercicio, serie) -> ft.Control:
        """El check de marcar y la equis de quitar. Los usan las dos formas de
        fila, la de peso y la de tiempo."""
        paleta = self.paleta
        marcar = ft.Container(
            content=ft.Icon(
                ft.Icons.CHECK_ROUNDED,
                size=18,
                color=paleta.canvas if serie.hecha else paleta.muted,
            ),
            width=36,
            height=36,
            bgcolor=paleta.acento if serie.hecha else None,
            border=None if serie.hecha else ft.Border.all(1, paleta.borde_fuerte),
            border_radius=999,
            alignment=ft.Alignment.CENTER,
            tooltip="Marcar la serie y arrancar el descanso",
            on_click=lambda _, n=serie.numero: self._marcar(sesion, ejercicio, n),
            ink=True,
        )
        return ft.Row(
            [
                marcar,
                componentes.boton_icono(
                    paleta,
                    ft.Icons.CLOSE,
                    ayuda="Quitar esta serie",
                    al_pulsar=lambda _, n=serie.numero: self._quitar_serie(
                        sesion, ejercicio, n
                    ),
                ),
            ],
            spacing=4,
            tight=True,
        )

    def _es_de_tiempo(self, ejercicio: EjercicioDeSesion) -> bool:
        """Si este ejercicio se mide en tiempo, segun su ficha.

        Un ejercicio borrado de la biblioteca se trata como de peso, que es lo
        que era la mayoria: cambiarle la forma a un entreno viejo seria peor que
        ensenar una columna de mas.
        """
        for uno in self.ejercicios:
            if uno.id == ejercicio.ejercicio_id:
                return uno.medida is Medida.TIEMPO
        return False

    def _guardar_tiempo(self, sesion, ejercicio, numero: int, campo) -> None:
        escrito = (campo.value or "").strip()
        segundos = parsear_duracion(escrito) if escrito else 0
        if segundos is None:
            serie = ejercicio.serie(numero)
            campo.value = texto_duracion(serie.segundos if serie else 0)
            campo.update()
            componentes.avisar(
                self.pagina,
                "No he entendido esa duración. Vale 30min, 30:00, 45s o 1h30.",
            )
            return
        self._guardar(sesion, con_serie(ejercicio, numero, segundos=segundos))

    def _campo_descanso(
        self, sesion: Sesion, ejercicio: EjercicioDeSesion
    ) -> ft.Control:
        """El descanso de este ejercicio, cambiable en mitad del entreno.

        POR QUÉ SE PUEDE CAMBIAR AQUÍ Y NO SOLO EN EL PLAN: hay días que llegas
        cansado y necesitas dos minutos donde el plan dice noventa segundos.
        Obligarte a ir a la Rutina para eso te haría cambiar el PLAN por lo que
        pasó un martes, que es justo lo que la separación evita.
        """
        campo = componentes.campo_texto(
            self.paleta,
            "Descanso",
            valor=texto_descanso(self._descanso_de(ejercicio)),
            ancho=120,
        )
        campo.tooltip = "90, 1:30, 1.30, 1.3, 1m30, 30s... como quieras"
        campo.on_blur = lambda _, e=ejercicio, c=campo: self._guardar_descanso(
            sesion, e, c
        )
        return campo

    def _guardar_descanso(
        self, sesion: Sesion, ejercicio: EjercicioDeSesion, campo
    ) -> None:
        from dataclasses import replace

        segundos = parsear_descanso(campo.value or "")
        if segundos is None:
            campo.value = texto_descanso(self._descanso_de(ejercicio))
            campo.update()
            componentes.avisar(
                self.pagina,
                "No he entendido ese descanso. Vale 90, 1:30, 1.30, 1.3, 1m30 o 30s.",
            )
            return
        self._guardar(sesion, replace(ejercicio, descanso=segundos))

    # ----------------------------------------------------------------------
    # Cambios sobre la sesión
    # ----------------------------------------------------------------------

    def _marcar(self, sesion: Sesion, ejercicio: EjercicioDeSesion, numero: int) -> None:
        """Marca o desmarca una serie. Al marcarla arranca el descanso SOLO.

        Que arranque solo es media función: nadie se acuerda de darle a un botón
        con las manos ocupadas. Al DESmarcar no se toca el cronómetro: quitar una
        marca es corregir un error, no acabar una serie.
        """
        serie = ejercicio.serie(numero)
        if serie is None:
            return
        ahora_hecha = not serie.hecha
        self._guardar(
            sesion, con_serie(ejercicio, numero, hecha=ahora_hecha)
        )
        if ahora_hecha and self.franja is not None:
            self.franja.arrancar(
                self._descanso_de(ejercicio),
                ejercicio=ejercicio.nombre,
                serie=numero,
            )

    def _descanso_de(self, ejercicio: EjercicioDeSesion) -> int:
        """Los segundos de descanso de ese ejercicio. En este orden y no en otro:

          1. EL DEL ENTRENO, que se copió del plan al empezar y que puedes
             cambiar aquí mismo. Manda siempre que esté puesto, porque es lo que
             tú elegiste para este ejercicio.
          2. El de la ficha de la biblioteca, si en el entreno no se dijo nada.
          3. El de por omisión, si el ejercicio ya no está en la biblioteca.

        NINGÚN PASO SE SALTA HACIA ARRIBA: un cero en el entreno es un cero
        elegido a propósito (el cardio no lleva descanso), no un hueco. Tratarlo
        como hueco haría que el cronómetro arrancara donde tú dijiste que no.
        """
        from ..dominio.ejercicio import DESCANSO_POR_OMISION

        if ejercicio.descanso is not None:
            return ejercicio.descanso
        for uno in self.ejercicios:
            if uno.id == ejercicio.ejercicio_id:
                return uno.descanso
        return DESCANSO_POR_OMISION

    def _guardar_peso(self, sesion, ejercicio, numero: int, campo) -> None:
        from ..dominio.rutina import parsear_peso

        peso = parsear_peso(campo.value or "")
        if peso is None:
            # NO SE ADIVINA: se devuelve el campo a lo que había. Un peso
            # inventado en el historial es peor que un campo que no se deja
            # escribir, porque el inventado no se nota.
            serie = ejercicio.serie(numero)
            campo.value = _kilos(serie.peso) if serie else "0"
            campo.update()
            componentes.avisar(self.pagina, "El peso no se entiende. Ejemplo: 62,5")
            return
        self._guardar(sesion, con_serie(ejercicio, numero, peso=peso))

    def _guardar_reps(self, sesion, ejercicio, numero: int, campo) -> None:
        texto = (campo.value or "").strip()
        if not texto.isdigit():
            serie = ejercicio.serie(numero)
            campo.value = str(serie.repeticiones) if serie else "0"
            campo.update()
            componentes.avisar(self.pagina, "Las repeticiones son un número entero.")
            return
        self._guardar(sesion, con_serie(ejercicio, numero, repeticiones=int(texto)))

    def _anadir_serie(self, sesion: Sesion, ejercicio: EjercicioDeSesion) -> None:
        self._guardar(sesion, anadir_serie(ejercicio))

    def _quitar_serie(
        self, sesion: Sesion, ejercicio: EjercicioDeSesion, numero: int
    ) -> None:
        self._guardar(sesion, quitar_serie(ejercicio, numero))

    def _guardar(self, sesion: Sesion, ejercicio: EjercicioDeSesion) -> None:
        """Mete el ejercicio cambiado en la sesión y la guarda entera.

        SE GUARDA EN CADA CAMBIO y no al final con un botón. En el gimnasio la
        aplicación se cierra sola, se apaga la pantalla, suena el teléfono; un
        entreno que se pierde por no haber dado a "Guardar" no vuelve.
        """
        from dataclasses import replace

        nuevos = tuple(
            ejercicio if uno.orden == ejercicio.orden else uno
            for uno in sesion.ejercicios
        )
        with conectado() as conexion:
            repositorio_gimnasio.guardar_sesion(
                conexion, replace(sesion, ejercicios=nuevos)
            )
        self.refrescar()

    def _pie_del_entreno(self, sesion: Sesion) -> ft.Control:
        return ft.Row(
            [
                componentes.boton(
                    self.paleta,
                    "Añadir ejercicio",
                    icono=ft.Icons.ADD,
                    al_pulsar=lambda _: self._elegir_ejercicio(sesion),
                ),
                ft.Container(expand=True),
                componentes.boton(
                    self.paleta,
                    "Borrar este entreno",
                    al_pulsar=lambda _: self._borrar_entreno(sesion),
                ),
            ]
        )

    def _elegir_ejercicio(self, sesion: Sesion) -> None:
        from . import dialogo_anadir_ejercicio

        dialogo_anadir_ejercicio.abrir(
            self.pagina,
            self.paleta,
            self.ejercicios,
            lambda elegido: self._anadir_a_la_sesion(sesion, elegido),
        )

    def _anadir_a_la_sesion(self, sesion: Sesion, elegido) -> None:
        from dataclasses import replace

        from ..dominio.sesion import Serie

        nuevo = EjercicioDeSesion(
            ejercicio_id=elegido.id,
            nombre=elegido.nombre,
            orden=len(sesion.ejercicios),
            series=(Serie(numero=1),),
        )
        with conectado() as conexion:
            repositorio_gimnasio.guardar_sesion(
                conexion,
                replace(sesion, ejercicios=(*sesion.ejercicios, nuevo)),
            )
        self.refrescar()

    def _borrar_entreno(self, sesion: Sesion) -> None:
        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo="Borrar el entreno",
            texto=(
                "Se pierden las series de este día. El plan de la semana no se "
                "toca."
            ),
            al_aceptar=lambda _: self._borrar_de_verdad(sesion),
        )

    def _borrar_de_verdad(self, sesion: Sesion) -> None:
        with conectado() as conexion:
            repositorio_gimnasio.borrar_sesion(conexion, sesion.fecha)
        self.pagina.pop_dialog()
        if self.franja is not None:
            self.franja.parar()
        self.refrescar()


def _kilos(centesimas: int) -> str:
    """El peso para meter en un campo: "62,5", sin el "kg"."""
    return texto_peso(centesimas).removesuffix(" kg")
