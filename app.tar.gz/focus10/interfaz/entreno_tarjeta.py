"""La tarjeta de UN ejercicio en el entreno: su nombre, sus mandos y sus series.

LA FORMA LA PIDIÓ EL USUARIO CON UNA CAPTURA de otra aplicación: el dibujo en
un círculo y el nombre en el color del tema, un menú «⋮» con lo que se usa
poco (mover, reemplazar, eliminar), el descanso como un botón, y las series
en filas con el número en un cuadrado, las casillas centradas y el ✓ al final.
Sin recuadro alrededor: los ejercicios se separan por el aire, como en la foto.

SOLO DIBUJA. Lo que pasa al tocar algo lo decide la pantalla (entreno.py), que
es la que tiene el entreno en memoria y lo guarda. Aquí cada casilla y cada
botón se ata a QUÉ ejercicio y QUÉ serie es (su «orden» y su número), nunca a
una copia del ejercicio tal como estaba al dibujarse.

ESA ERA LA CAUSA DE QUE EL 10 VOLVIERA: cada botón se quedaba con una foto del
ejercicio del último repintado. Escribías 8, tocabas ✓, y el ✓ guardaba su foto,
que todavía decía 10. Atado al número de serie, el ✓ lee lo que hay AHORA.
"""

from __future__ import annotations

import flet as ft

from ..dominio.descanso import texto_descanso, texto_duracion
from ..dominio.ejercicio import Unidad
from ..dominio.rutina import EjercicioPlaneado, texto_peso
from ..dominio.sesion import NOTA_MAXIMA, EjercicioDeSesion, Serie, TipoSerie
from ..dominio.zona_musculo import zona_de
from . import componentes, dibujo_musculo, estilo

ALTO_DIBUJO = 40
"""La silueta dentro del círculo de al lado del nombre."""
LADO_CIRCULO = 52
ALTO_PLEGADA = 34
TAMANO_NOMBRE = 17
LADO_CUADRADO = 38
"""El cuadrado del número de serie y el del ✓: iguales, como en la foto."""
ANCHO_ANTERIOR = 110

NUMERO_DE_SERIE = "numero_de_serie"
"""Marca (en `data`) del cuadrado del número: lo buscan las pruebas."""

PESO = "peso"
REPS = "reps"
TIEMPO = "tiempo"
METROS = "metros"
"""Qué casilla de la serie es: la pantalla las lee y las guarda distinto."""

ROTULO_DE_UNIDAD = {Unidad.REPS: "REPS", Unidad.SEGUNDOS: "SEGUNDOS", Unidad.METROS: "METROS"}
NOMBRE_DE_UNIDAD = {
    Unidad.REPS: "Repeticiones", Unidad.SEGUNDOS: "Segundos", Unidad.METROS: "Metros",
}
ROTULO_DE_UNIDAD_MARCA = "rotulo_de_unidad"
"""Marca (en `data`) del rótulo que abre el menú: lo buscan las pruebas."""

ORDEN_DEL_MENU = (
    TipoSerie.CALENTAMIENTO, TipoSerie.NORMAL, TipoSerie.FALLO,
    TipoSerie.RECUPERACION, TipoSerie.DROP,
)
"""Como en la captura del usuario: calentamiento arriba, la normal después."""

NOMBRE_EN_EL_MENU = {
    TipoSerie.CALENTAMIENTO: "Serie de calentamiento",
    TipoSerie.NORMAL: "Serie normal",
    TipoSerie.FALLO: "Serie al fallo",
    TipoSerie.RECUPERACION: "Serie de recuperación",
    TipoSerie.DROP: "Serie drop",
}

COLOR_DE_TIPO = {
    TipoSerie.FALLO: "rojo",
    TipoSerie.RECUPERACION: "azul",
    TipoSerie.DROP: "violeta",
    TipoSerie.CALENTAMIENTO: "ambar",
}
"""Un color del tema por tipo, para distinguirlas de lejos."""


def kilos(centesimas: int) -> str:
    """El peso para meter en un campo: "62,5", sin el "kg"."""
    return texto_peso(centesimas).removesuffix(" kg")


def texto_descanso_largo(segundos: int) -> str:
    """«1min 30s», «2min», «45s»: como en la foto, para leerlo de un vistazo."""
    if segundos <= 0:
        return "sin descanso"
    minutos, resto = divmod(segundos, 60)
    if not minutos:
        return f"{resto}s"
    return f"{minutos}min {resto}s" if resto else f"{minutos}min"


def texto_plan(plan: EjercicioPlaneado | None, de_tiempo: bool,
               unidad: Unidad | None = Unidad.REPS) -> str:
    """«Plan: 3 × 10 · 20 kg», para distinguir lo planeado de lo que hacés.

    LO PIDIÓ EL USUARIO: «diferenciar entre los valores planificados y los
    resultados reales». Las casillas tienen lo real (lo de la última vez o lo de
    hoy); el plan va en chiquito al lado del nombre. Vacío si no estaba en la
    rutina de hoy (lo añadiste a mano).
    """
    if plan is None or not plan.series:
        return ""
    cuantas = len(plan.series)
    if de_tiempo:
        return f"Plan: {cuantas} × {texto_duracion(plan.series[0].segundos or 0)}"
    pesos = {una.peso for una in plan.series}
    if unidad not in (None, Unidad.REPS):
        # EL PLAN SE ESCRIBE EN REPETICIONES: en metros o segundos no dicen
        # nada, así que solo cuántas series y los kilos.
        de_peso = f" · {texto_peso(pesos.pop())}" if len(pesos) == 1 and plan.series[0].peso else ""
        return f"Plan: {cuantas} series{de_peso}"
    reps = [una.repeticiones for una in plan.series]
    de_reps = f"{cuantas} × {reps[0]}" if len(set(reps)) == 1 else "/".join(map(str, reps))
    de_peso = f" · {texto_peso(pesos.pop())}" if len(pesos) == 1 and plan.series[0].peso else ""
    return f"Plan: {de_reps}{de_peso}"


def tarjeta(
    pantalla,
    ejercicio: EjercicioDeSesion,
    anterior: EjercicioDeSesion | None,
    plan: EjercicioPlaneado | None,
    *,
    primero: bool,
    ultimo: bool,
) -> ft.Control:
    """El ejercicio entero. `pantalla` es la PantallaEntreno que recibe los toques."""
    if pantalla.plegado(ejercicio):
        return _plegada(pantalla, ejercicio)
    de_tiempo = pantalla._es_de_tiempo(ejercicio)
    unidad = pantalla._unidad_de(ejercicio)
    orden = ejercicio.orden
    return componentes.guardar_tambien_al_confirmar(ft.Container(
        content=ft.Column(
            [
                _cabeza(pantalla, ejercicio, texto_plan(plan, de_tiempo, unidad), primero, ultimo),
                _botones(pantalla, ejercicio),
                _series(pantalla, ejercicio, anterior, de_tiempo, unidad),
                # DEBAJO DE LAS SERIES Y A TODO LO ANCHO, como en la foto
                # que mandó el usuario: cierra el ejercicio.
                componentes.boton_ancho(
                    pantalla.paleta,
                    "Agregar serie",
                    icono=ft.Icons.ADD,
                    al_pulsar=lambda _: pantalla._anadir_serie(orden),
                ),
            ],
            spacing=12,
        ),
        padding=ft.Padding.symmetric(vertical=10),
    ))


# ------------------------------------------------------------------ arriba


def _dibujo(pantalla, ejercicio: EjercicioDeSesion, alto: int) -> ft.Control | None:
    """La silueta con el músculo que trabaja, como en la rutina.

    LO PIDIÓ EL USUARIO: «no aparecen los dibujos, deben aparecer también». Sin
    ficha (un ejercicio borrado de la biblioteca) no hay grupo que pintar, y no
    se inventa uno: no se dibuja nada.
    """
    ficha = pantalla.ficha_de(ejercicio)
    if ficha is None:
        return None
    return dibujo_musculo.silueta(
        pantalla.paleta, ficha.grupo, secundarios=ficha.secundarios,
        zona=zona_de(ficha.nombre, ficha.grupo), alto=alto,
    )


def _en_circulo(pantalla, ejercicio: EjercicioDeSesion) -> ft.Control | None:
    """El dibujo dentro de un círculo, como la foto de cada ejercicio de la captura."""
    dibujo = _dibujo(pantalla, ejercicio, ALTO_DIBUJO)
    if dibujo is None:
        return None
    return ft.Container(
        content=dibujo,
        width=LADO_CIRCULO,
        height=LADO_CIRCULO,
        border_radius=LADO_CIRCULO / 2,
        bgcolor=pantalla.paleta.surface_2,
        alignment=ft.Alignment.CENTER,
    )


def _icono_medalla(paleta) -> ft.Control:
    """Una medalla de línea, no un emoji: el emoji lo dibuja cada aparato a su
    manera e ignora los colores del tema (ver la migración 32)."""
    return ft.Icon(ft.Icons.MILITARY_TECH, size=22, color=paleta.color_de("ambar"),
                   tooltip="Récord")


def _medalla(pantalla, ejercicio: EjercicioDeSesion) -> list[ft.Control]:
    """«Récord: 61 kg × 10 (antes 59 kg × 10)», si hoy superaste tu mejor marca."""
    marcas = pantalla.records_de(ejercicio)
    if not marcas:
        return []
    numero = max(marcas)
    serie = ejercicio.serie(numero)
    return [ft.Row(
        [
            _icono_medalla(pantalla.paleta),
            ft.Text(
                f"Récord: {serie.texto()} (antes {marcas[numero].texto()})",
                size=estilo.TEXTO_APOYO,
                weight=ft.FontWeight.W_600,
                color=pantalla.paleta.ink,
                expand=True,
            ),
        ],
        spacing=4,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )]


def _plegada(pantalla, ejercicio: EjercicioDeSesion) -> ft.Control:
    """Un ejercicio terminado: su nombre y un ✅, en una línea.

    LO PIDIÓ EL USUARIO: «se debe entender más cuando el ejercicio está
    finalizado: que se comprima y aparezca un ✅». Tocándola se vuelve a abrir
    para corregir algo.
    """
    paleta = pantalla.paleta
    dibujo = _dibujo(pantalla, ejercicio, ALTO_PLEGADA)
    return componentes.tarjeta(
        paleta,
        ft.Row(
            [
                *([dibujo] if dibujo else []),
                ft.Text(
                    ejercicio.nombre,
                    size=estilo.TEXTO,
                    weight=ft.FontWeight.W_600,
                    color=paleta.ink,
                    expand=True,
                ),
                *([_icono_medalla(paleta)] if pantalla.records_de(ejercicio) else []),
                ft.Icon(ft.Icons.CHECK_CIRCLE, size=24, color=paleta.acento),
            ],
            spacing=12,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        relleno=12,
        al_pulsar=lambda _: pantalla._abrir(ejercicio.orden),
    )


def _cabeza(pantalla, ejercicio: EjercicioDeSesion, plan: str, primero: bool, ultimo: bool) -> ft.Control:
    """El círculo con el dibujo, el nombre en el color del tema y el menú «⋮».

    El nombre va grande porque el móvil está en el suelo o en un banco y vos de
    pie: es el único sitio de la aplicación que se mira de lejos.
    """
    paleta = pantalla.paleta
    debajo = f"{ejercicio.hechas} de {len(ejercicio.series)} series"
    if plan:
        debajo += f" · {plan}"
    textos = ft.Column(
        [
            # ENTERO Y MÁS CHICO: lo pidió el usuario («cambiá el tamaño de la
            # letra y que se vea completo el nombre»). Cortado con «…»,
            # «Press de banca plano…» y «Press de banca plano en…» eran iguales.
            ft.Text(
                ejercicio.nombre,
                size=TAMANO_NOMBRE,
                weight=ft.FontWeight.W_600,
                color=paleta.acento,
                font_family=paleta.titular,
            ),
            ft.Text(debajo, size=estilo.TEXTO_APOYO, color=paleta.muted),
            *_medalla(pantalla, ejercicio),
        ],
        spacing=2,
        tight=True,
        expand=True,
    )
    circulo = _en_circulo(pantalla, ejercicio)
    return ft.Row(
        [*([circulo] if circulo else []), textos, _menu(pantalla, ejercicio, primero, ultimo)],
        spacing=12,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )


def _menu(pantalla, ejercicio: EjercicioDeSesion, primero: bool, ultimo: bool) -> ft.Control:
    """El «⋮» de la captura, con lo que se usa de vez en cuando.

    LO PIDIÓ EL USUARIO: «añadir, eliminar, sustituir o reordenar» entrenando.
    Están aquí y no como botones sueltos porque los íconos solos no se
    entendían, y con su nombre al lado no cabían en el móvil.
    """
    orden = ejercicio.orden
    opciones: list[ft.PopupMenuItem] = []
    if not primero:
        opciones.append(ft.PopupMenuItem(
            "Subir", icon=ft.Icons.ARROW_UPWARD, on_click=lambda _: pantalla._mover(orden, -1)))
    if not ultimo:
        opciones.append(ft.PopupMenuItem(
            "Bajar", icon=ft.Icons.ARROW_DOWNWARD, on_click=lambda _: pantalla._mover(orden, 1)))
    opciones.append(ft.PopupMenuItem(
        "Reemplazar", icon=ft.Icons.SWAP_HORIZ, on_click=lambda _: pantalla._sustituir(orden)))
    if len(ejercicio.series) > 1:
        opciones.append(ft.PopupMenuItem(
            "Quitar la última serie", icon=ft.Icons.REMOVE,
            on_click=lambda _: pantalla._quitar_serie(orden, len(ejercicio.series))))
    # ELIMINAR EL EJERCICIO, sin preguntar: ver dominio/sesion.sin_ejercicio.
    opciones.append(ft.PopupMenuItem(
        "Eliminar", icon=ft.Icons.DELETE_OUTLINE, on_click=lambda _: pantalla._quitar_ejercicio(orden)))
    return ft.PopupMenuButton(
        icon=ft.Icons.MORE_VERT, icon_color=pantalla.paleta.ink, items=opciones,
        tooltip="Más",
    )


def _botones(pantalla, ejercicio: EjercicioDeSesion) -> ft.Control:
    """«Descanso: 1min 30s» y «Nota» como botones, como en la captura. Si hay
    nota, se lee debajo: está para acordarse, no para buscarla."""
    paleta = pantalla.paleta
    fila = ft.Row(
        [
            _pastilla(
                paleta, ft.Icons.TIMER_OUTLINED,
                f"Descanso: {texto_descanso_largo(pantalla._descanso_de(ejercicio))}",
                lambda _: _pedir_descanso(pantalla, ejercicio),
            ),
            _pastilla(
                paleta, ft.Icons.EDIT_NOTE, "Nota",
                lambda _: _pedir_nota(pantalla, ejercicio),
            ),
        ],
        spacing=8,
        run_spacing=8,
        wrap=True,
    )
    if not ejercicio.nota:
        return fila
    return ft.Column(
        [fila, ft.Text(ejercicio.nota, size=estilo.TEXTO_APOYO, italic=True, color=paleta.ink_soft)],
        spacing=8,
        tight=True,
    )


def _pedir_nota(pantalla, ejercicio: EjercicioDeSesion) -> None:
    """La nota de este ejercicio. LO PIDIÓ EL USUARIO: que se vea la próxima vez."""
    orden = ejercicio.orden
    campo = componentes.campo_texto(pantalla.paleta, "Nota", valor=ejercicio.nota)
    campo.multiline = True
    campo.max_length = NOTA_MAXIMA
    campo.autofocus = True

    def guardar(_):
        pantalla.pagina.pop_dialog()
        pantalla._guardar_nota(orden, campo.value or "")

    pantalla.pagina.show_dialog(ft.AlertDialog(
        title=ft.Text(f"Nota de {ejercicio.nombre}"),
        content=ft.Column(
            [ft.Text("La vas a ver la próxima vez que hagas este ejercicio.", size=13), campo],
            tight=True,
            spacing=10,
        ),
        actions=[
            ft.TextButton("Cancelar", on_click=lambda _: pantalla.pagina.pop_dialog()),
            ft.FilledButton("Guardar", on_click=guardar),
        ],
    ))


def _pastilla(paleta, icono, texto: str, al_pulsar) -> ft.Control:
    return ft.Container(
        content=ft.Row(
            [ft.Icon(icono, size=18, color=paleta.ink), ft.Text(texto, size=14, color=paleta.ink)],
            spacing=6,
            tight=True,
        ),
        bgcolor=paleta.surface_2,
        border_radius=10,
        padding=ft.Padding.symmetric(horizontal=12, vertical=8),
        on_click=al_pulsar,
        ink=True,
    )


def _pedir_descanso(pantalla, ejercicio: EjercicioDeSesion) -> None:
    """La ventanita para cambiar el descanso de ESTE ejercicio, hoy.

    Hay días que el pecho pide tres minutos aunque la rutina diga dos.
    """
    orden = ejercicio.orden
    campo = componentes.campo_texto(
        pantalla.paleta, "Descanso", valor=texto_descanso(pantalla._descanso_de(ejercicio)), ancho=160
    )
    campo.tooltip = "90, 1:30, 1.30, 1.3, 1m30, 30s... como quieras"
    campo.autofocus = True

    def guardar(_):
        pantalla.pagina.pop_dialog()
        pantalla._al_dejar_descanso(orden, campo)

    campo.on_submit = guardar
    pantalla.pagina.show_dialog(ft.AlertDialog(
        title=ft.Text(f"Descanso de {ejercicio.nombre}"),
        content=ft.Column(
            [ft.Text("90, 1:30, 1m30 o 30s: como quieras.", size=13), campo],
            tight=True,
            spacing=10,
        ),
        actions=[
            ft.TextButton("Cancelar", on_click=lambda _: pantalla.pagina.pop_dialog()),
            ft.FilledButton("Guardar", on_click=guardar),
        ],
    ))


# ------------------------------------------------------------------ las series


def _series(pantalla, ejercicio: EjercicioDeSesion, anterior: EjercicioDeSesion | None,
            de_tiempo: bool, unidad: Unidad | None) -> ft.Control:
    """Los rótulos una vez arriba y una serie por línea.

    EN EL MÓVIL NO VA «ANTERIOR»: lo eligió el usuario (dos veces), casi no la
    mira y las casillas ya traen lo de la última vez. En la PC sí, que sobra sitio.

    `unidad` None = no hay qué elegir (de tiempo, o sin ficha): «REPS» quieto.
    """
    paleta = pantalla.paleta
    con_anterior = not estilo.pantalla_estrecha()

    def rotulo(texto, **como):
        return ft.Container(
            content=ft.Text(texto, size=11, weight=ft.FontWeight.W_600, color=paleta.muted),
            alignment=ft.Alignment.CENTER,
            **como,
        )

    if de_tiempo:
        medidas = [rotulo("DURACIÓN", expand=True)]
    elif unidad is None:
        medidas = [rotulo("KG", expand=True), rotulo("REPS", expand=True)]
    else:
        medidas = [rotulo("KG", expand=True), _rotulo_de_unidad(pantalla, ejercicio, unidad)]

    rotulos = ft.Row(
        [
            rotulo("SERIE", width=LADO_CUADRADO),
            *([rotulo("ANTERIOR", width=ANCHO_ANTERIOR)] if con_anterior else []),
            *medidas,
            rotulo("✓", width=LADO_CUADRADO),
        ],
        spacing=8,
    )
    filas = [_fila_de_serie(pantalla, ejercicio, serie, anterior, de_tiempo, con_anterior,
                            unidad or Unidad.REPS)
             for serie in ejercicio.series]
    return ft.Column([rotulos, *filas], spacing=8, tight=True)


def _rotulo_de_unidad(pantalla, ejercicio: EjercicioDeSesion, unidad: Unidad) -> ft.Control:
    """«REPS ▾»: tocándolo se elige reps, segundos o metros.

    LO PIDIÓ EL USUARIO con el paseo del granjero, «como lo del tipo de serie:
    toco y se abren las opciones». La flechita dice que se puede tocar.
    """
    paleta = pantalla.paleta
    return ft.Container(
        content=ft.Row(
            [
                ft.Text(ROTULO_DE_UNIDAD[unidad], size=11, weight=ft.FontWeight.W_600,
                        color=paleta.muted),
                ft.Icon(ft.Icons.ARROW_DROP_DOWN, size=16, color=paleta.muted),
            ],
            spacing=0,
            tight=True,
            alignment=ft.MainAxisAlignment.CENTER,
        ),
        alignment=ft.Alignment.CENTER,
        expand=True,
        border_radius=6,
        tooltip="Tocá para contar repeticiones, segundos o metros",
        on_click=lambda _: _elegir_unidad(pantalla, ejercicio.orden, ejercicio.nombre, unidad),
        ink=True,
        data=ROTULO_DE_UNIDAD_MARCA,
    )


def _elegir_unidad(pantalla, orden: int, nombre: str, actual: Unidad) -> None:
    """El menú del rótulo: una línea por unidad, con ✓ en la de ahora. Igual
    que el del número de serie, para que se use sin pensarlo."""
    paleta = pantalla.paleta

    def elegir(unidad):
        pantalla.pagina.pop_dialog()
        pantalla._poner_unidad(orden, unidad)

    lineas = [
        ft.Container(
            content=ft.Row(
                [
                    ft.Text(NOMBRE_DE_UNIDAD[unidad], size=16, color=paleta.ink, expand=True),
                    *([ft.Icon(ft.Icons.CHECK, size=18, color=paleta.acento)]
                      if unidad is actual else []),
                ],
                spacing=14,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=8, vertical=12),
            border=ft.Border.only(bottom=ft.BorderSide(1, paleta.borde)),
            on_click=lambda _, u=unidad: elegir(u),
            ink=True,
            data=unidad,
        )
        for unidad in Unidad
    ]
    pantalla.pagina.show_dialog(ft.AlertDialog(
        title=ft.Text(nombre, size=15, weight=ft.FontWeight.W_600, color=paleta.ink),
        content=ft.Column(
            [
                ft.Text("Se recuerda para la próxima vez.", size=13, color=paleta.ink_soft),
                *lineas,
            ],
            spacing=0,
            tight=True,
        ),
        bgcolor=paleta.surface,
        actions=[ft.TextButton("Cancelar", on_click=lambda _: pantalla.pagina.pop_dialog())],
    ))


def _fila_de_serie(
    pantalla, ejercicio: EjercicioDeSesion, serie: Serie, anterior: EjercicioDeSesion | None,
    de_tiempo: bool, con_anterior: bool, unidad: Unidad = Unidad.REPS,
) -> ft.Control:
    """Una serie: su número, sus casillas y el ✓.

    LAS CASILLAS GUARDAN MIENTRAS ESCRIBÍS (on_change), y al salir solo se
    corrige lo que no se entiende. Guardar solo al salir era la otra mitad del
    fallo: en Android cerrar el teclado a veces no cuenta como salir, y lo
    escrito no llegaba a ningún lado.
    """
    paleta = pantalla.paleta
    orden, numero = ejercicio.orden, serie.numero

    def casilla(que: str, valor: str) -> ft.Control:
        campo = componentes.campo_texto(paleta, "", valor=valor)
        campo.text_align = ft.TextAlign.CENTER
        campo.on_change = lambda _: pantalla._al_escribir(orden, numero, que, campo)
        campo.on_blur = lambda _: pantalla._al_dejar(orden, numero, que, campo)
        return ft.Container(content=campo, expand=True)

    if de_tiempo:
        # UN EJERCICIO DE TIEMPO NO TIENE KILOS NI REPETICIONES: casillas a cero
        # invitarían a rellenarlas con algo que no quiere decir nada.
        campos = [casilla(TIEMPO, texto_duracion(serie.segundos))]
        campos[0].content.tooltip = "30min, 30:00, 45s, 1h30... como quieras"
    elif unidad is Unidad.SEGUNDOS:
        campos = [casilla(PESO, kilos(serie.peso)), casilla(TIEMPO, texto_duracion(serie.segundos))]
        campos[1].content.tooltip = "45, 0:45, 1:30, 45s... como quieras"
    elif unidad is Unidad.METROS:
        campos = [casilla(PESO, kilos(serie.peso)), casilla(METROS, str(serie.metros))]
    else:
        campos = [casilla(PESO, kilos(serie.peso)), casilla(REPS, str(serie.repeticiones))]

    celdas: list[ft.Control] = [_numero(pantalla, orden, serie)]
    if con_anterior:
        vieja = anterior.serie(numero) if anterior else None
        celdas.append(ft.Container(
            content=ft.Text(vieja.texto() if vieja else "—", size=14, color=paleta.muted),
            width=ANCHO_ANTERIOR,
            alignment=ft.Alignment.CENTER,
        ))
    celdas += [*campos, _marcar(pantalla, orden, serie)]
    return ft.Row(celdas, spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER)


def _numero(pantalla, orden: int, serie: Serie) -> ft.Control:
    """El número de la serie, que al tocarlo cambia de tipo.

    LO PIDIÓ EL USUARIO: «al tocar el número de la serie se debe poder cambiar
    a fallo, recuperación, drop set, calentamiento, todas con una letra
    representativa y un color». Como en la captura: el cuadrado es siempre del
    mismo tono y lo que cambia es la letra, en su color.
    """
    paleta = pantalla.paleta
    tipo = serie.tipo
    if tipo is TipoSerie.NORMAL:
        letra, tinta = str(serie.numero), paleta.ink
    else:
        letra, tinta = tipo.letra, paleta.color_de(COLOR_DE_TIPO[tipo])
    return ft.Container(
        content=ft.Text(letra, size=estilo.TEXTO, weight=ft.FontWeight.W_700, color=tinta),
        width=LADO_CUADRADO,
        height=LADO_CUADRADO,
        bgcolor=paleta.surface_2,
        border_radius=8,
        alignment=ft.Alignment.CENTER,
        tooltip=f"{tipo.nombre}. Tocá para cambiar el tipo",
        on_click=lambda _: _elegir_tipo(pantalla, orden, serie),
        ink=True,
        data=NUMERO_DE_SERIE,
    )


def _letra_de(pantalla, tipo: TipoSerie, numero: int) -> ft.Control:
    """La letra de un tipo en su color (la normal, su número), como en el menú."""
    paleta = pantalla.paleta
    if tipo is TipoSerie.NORMAL:
        return ft.Text(str(numero), size=18, weight=ft.FontWeight.W_700, color=paleta.ink)
    return ft.Text(tipo.letra, size=18, weight=ft.FontWeight.W_700,
                   color=paleta.color_de(COLOR_DE_TIPO[tipo]))


def _elegir_tipo(pantalla, orden: int, serie: Serie) -> None:
    """El menú del número, como en la captura del usuario: una línea por tipo.

    SIN «ELIMINAR SERIE» Y SIN EL «?» de la captura: lo pidió así («la de
    eliminar no se usa, el signo de pregunta no lo pongas»). Quitar una serie
    sigue en el «⋮» del ejercicio.
    """
    paleta = pantalla.paleta

    def elegir(tipo):
        pantalla.pagina.pop_dialog()
        pantalla._poner_tipo(orden, serie.numero, tipo)

    lineas = [
        ft.Container(
            content=ft.Row(
                [
                    ft.Container(_letra_de(pantalla, tipo, serie.numero), width=32,
                                 alignment=ft.Alignment.CENTER),
                    ft.Text(NOMBRE_EN_EL_MENU[tipo], size=16, color=paleta.ink, expand=True),
                    *([ft.Icon(ft.Icons.CHECK, size=18, color=paleta.acento)]
                      if tipo is serie.tipo else []),
                ],
                spacing=14,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=8, vertical=12),
            border=ft.Border.only(bottom=ft.BorderSide(1, paleta.borde)),
            on_click=lambda _, t=tipo: elegir(t),
            ink=True,
            data=tipo,
        )
        for tipo in ORDEN_DEL_MENU
    ]
    pantalla.pagina.show_dialog(ft.AlertDialog(
        title=ft.Text(f"Serie {serie.numero}", size=15, weight=ft.FontWeight.W_600, color=paleta.ink),
        content=ft.Column(lineas, spacing=0, tight=True),
        bgcolor=paleta.surface,
        actions=[ft.TextButton("Cancelar", on_click=lambda _: pantalla.pagina.pop_dialog())],
    ))


def _marcar(pantalla, orden: int, serie: Serie) -> ft.Control:
    """El ✓: sin hacer, apagado; hecha, lleno del color del tema. Se ve de lejos."""
    paleta = pantalla.paleta
    return ft.Container(
        content=ft.Icon(
            ft.Icons.CHECK_ROUNDED,
            size=20,
            color=paleta.acento_ink if serie.hecha else paleta.muted,
        ),
        width=LADO_CUADRADO,
        height=LADO_CUADRADO,
        bgcolor=paleta.acento if serie.hecha else paleta.surface_2,
        border_radius=8,
        alignment=ft.Alignment.CENTER,
        tooltip="Marcar la serie y arrancar el descanso",
        on_click=lambda _: pantalla._marcar(orden, serie.numero),
        ink=True,
    )
