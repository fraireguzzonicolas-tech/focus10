"""La pantalla del horario semanal: la rejilla de horas × días.

CÓMO SE USA: tocas una casilla y se abre su apartado, donde eliges el color,
escribes la tarea (con emojis si quieres) y puedes dejar una nota. La rejilla
solo enseña el resultado.

POR QUÉ LA CASILLA YA NO SE ESCRIBE AQUÍ DENTRO: antes cada casilla era un campo
de escribir y se guardaba al salir de él. Lo cambió el usuario —"que cuando
seleccione el cuadrado parezca un apartado"— y el motivo aguanta solo: una
casilla que es a la vez botón y campo de escribir no te deja saber si un clic va
a abrir algo o a poner el cursor, y con siete días por diecisiete horas delante
eso se nota. Además, en una casilla de ese tamaño no cabían ni el color, ni la
nota, ni los emojis.

LA COLUMNA DE HOY VA MARCADA, porque es la que miras el 90% de las veces y
contarlas desde el lunes cada vez es un peaje tonto.

LO QUE ESTA PANTALLA NO HACE, y es a propósito: no propone horarios, no avisa de
huecos, no reordena nada y no calcula cuántas horas libres te quedan. Es la hoja
de papel del usuario, y en una hoja de papel no aparece nada que no hayas
escrito.
"""

from __future__ import annotations

from datetime import date
from enum import StrEnum

import flet as ft

from ..datos import ajustes
from ..datos import repositorio_horario as repo
from ..datos import repositorio_dias
from ..datos.bd import conectado
from ..dominio.resumen_comida import mes_de
from ..dominio.semana import DIAS, FranjaHoraria, texto_hora
from . import componentes, dialogo_casilla, estilo, resumen_mensual
from .estilo import Paleta

ANCHO_HORA = 46
"""Lo que ocupa la columna de las horas. Cabe "07:00" y no sobra sitio."""

ALTO_CASILLA = 36

HORAS = tuple((str(h), texto_hora(h)) for h in range(24))
"""Las 24 horas para los dos desplegables de la franja."""


class Vista(StrEnum):
    """Las dos formas de mirar el horario.

    SEMANA es para planear —la rejilla de horas por días— y MES es para mirar
    atrás. Son dos preguntas distintas y por eso no caben en la misma pantalla;
    es la misma decisión que ya se tomó en Alimentación.
    """

    SEMANA = "semana"
    MES = "mes"


class PantallaHorario(componentes.Pantalla):
    def __init__(self, pagina: ft.Page, paleta: Paleta) -> None:
        super().__init__(pagina, paleta)
        self.vista = Vista.SEMANA
        self.refrescar()

    # ------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            self.jornada = repositorio_dias.jornada_abierta(conexion)
            self.horario = repo.leer_horario(conexion)

            # EL MES SOLO SE LEE SI SE ESTÁ MIRANDO: en la vista de la semana
            # sería traerse treinta días de comidas, pesos y gastos para no
            # enseñar ninguno.
            self.mes = {}
            if self.vista is Vista.MES:
                desde, hasta = mes_de(self.jornada)
                self.mes = resumen_mensual.del_mes(
                    conexion, desde, hasta, self.jornada
                )
                self.moneda = ajustes.leer_moneda_principal(conexion)

        self.hoy = self.jornada.weekday()

        piezas: list[ft.Control] = [self._cabecera(), self._pestanas()]

        if self.vista is Vista.MES:
            piezas.append(self._tarjeta_mes())
        else:
            fuera = self.horario.fuera_de_franja()
            if fuera:
                piezas.append(self._aviso_de_lo_escondido(fuera))
            piezas.append(self._rejilla())

        self.pintar(piezas)

    # ------------------------------------------------------------------

    def _cabecera(self) -> ft.Control:
        franja = self.horario.franja
        escritas = self.horario.cuantas_escritas()
        return componentes.titulo_pagina(
            self.paleta,
            "Horario",
            f"{DIAS[self.hoy].upper()} · {escritas} casillas escritas",
            acciones=[
                componentes.selector(
                    self.paleta,
                    "Desde",
                    HORAS,
                    valor=str(franja.desde),
                    ancho=104,
                    al_elegir=lambda e: self._cambiar_franja(desde=e),
                ),
                componentes.selector(
                    self.paleta,
                    "Hasta",
                    HORAS,
                    valor=str(franja.hasta),
                    ancho=104,
                    al_elegir=lambda e: self._cambiar_franja(hasta=e),
                ),
            ],
        )

    def _pestanas(self) -> ft.Control:
        return componentes.segmentado(
            self.paleta,
            [(Vista.SEMANA, "Semana"), (Vista.MES, "Resumen mensual")],
            self.vista,
            self._cambiar_vista,
        )

    def _cambiar_vista(self, cual: str) -> None:
        self.vista = Vista(cual)
        self.refrescar()

    def _tarjeta_mes(self) -> ft.Control:
        """El calendario del mes con su leyenda."""
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Resumen mensual",
                        "Toca un día para ver cómo fue",
                    ),
                    resumen_mensual.rejilla(
                        self.paleta,
                        self.mes,
                        self.jornada,
                        al_tocar=self._abrir_dia,
                    ),
                    resumen_mensual.leyenda(self.paleta),
                ],
                spacing=12,
                tight=True,
            ),
        )

    def _abrir_dia(self, jornada: date):
        """La ficha del día. Es la misma que abre la ventana del Dashboard."""
        return resumen_mensual.abrir_dia(
            self.pagina, self.paleta, self.mes[jornada], self.moneda
        )

    def _cambiar_franja(self, *, desde=None, hasta=None) -> None:
        """Cambia la primera o la última hora de la rejilla.

        SI LA HORA DE FIN ES MENOR QUE LA DE INICIO, la franja cruza la
        medianoche y se dibuja del tirón (21, 22, 23, 0, 1...). No hace falta
        marcar nada: no hay otra forma de interpretar "de 21 a 5".
        """
        actual = self.horario.franja
        nueva = FranjaHoraria(
            desde=int(desde.data) if desde is not None else actual.desde,
            hasta=int(hasta.data) if hasta is not None else actual.hasta,
        )
        with conectado() as conexion:
            repo.guardar_franja(conexion, nueva)
        self.refrescar()

    def _aviso_de_lo_escondido(self, fuera) -> ft.Control:
        """Avisa de lo que hay escrito fuera de la franja, sin borrarlo.

        Callarlo sería hacerle creer al usuario que se ha perdido. Se dice
        cuántas casillas son y a qué horas, que es lo que hace falta para
        recuperarlas ensanchando la franja.
        """
        horas = sorted({texto_hora(una.hora) for una in fuera})
        return componentes.aviso(
            self.paleta,
            [
                f"Tienes {len(fuera)} casillas escritas fuera de la franja que "
                f"estás viendo, a las {', '.join(horas)}.",
                "No se han borrado. Ensancha la franja de arriba para verlas.",
            ],
        )

    # ------------------------------------------------------------------

    def _rejilla(self) -> ft.Control:
        filas: list[ft.Control] = [self._fila_de_dias()]
        for hora in self.horario.franja.horas():
            filas.append(self._fila_de_hora(hora))

        # SIN SCROLL A LO ANCHO: ya no hace falta, porque las columnas se
        # encogen hasta caber. Y quitarlo es parte del arreglo: mientras estuvo,
        # era él quien escondía el lunes.
        return componentes.tarjeta(
            self.paleta, ft.Column(filas, spacing=3, tight=True)
        )

    def _fila_de_dias(self) -> ft.Control:
        celdas: list[ft.Control] = [ft.Container(width=ANCHO_HORA)]
        for numero, nombre in enumerate(DIAS):
            es_hoy = numero == self.hoy
            celdas.append(
                ft.Container(
                    content=ft.Text(
                        nombre.capitalize(),
                        size=estilo.ROTULO,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.acento_ink if es_hoy else self.paleta.muted,
                    ),
                    expand=True,
                    alignment=ft.Alignment.CENTER,
                    padding=ft.Padding.symmetric(horizontal=4, vertical=6),
                    bgcolor=self.paleta.acento if es_hoy else None,
                    border_radius=6,
                )
            )
        return ft.Row(celdas, spacing=3, tight=True)

    def _fila_de_hora(self, hora: int) -> ft.Control:
        celdas: list[ft.Control] = [
            ft.Container(
                content=ft.Text(
                    texto_hora(hora),
                    size=estilo.TEXTO_APOYO,
                    color=self.paleta.muted,
                ),
                width=ANCHO_HORA,
                height=ALTO_CASILLA,
                alignment=ft.Alignment.CENTER_RIGHT,
                padding=ft.Padding.only(right=8),
            )
        ]
        for dia in range(7):
            celdas.append(self._casilla(dia, hora))
        return ft.Row(celdas, spacing=3, tight=True)

    def _casilla(self, dia: int, hora: int) -> ft.Control:
        """Un cuadrado que se toca y abre su ventanita.

        ANTES ERA UN CAMPO DE ESCRIBIR y ahora no, y lo eligió el usuario: "que
        cuando seleccione el cuadrado parezca un apartado". La razón de fondo es
        buena: una casilla que es a la vez botón y campo de escribir no te deja
        saber si un clic va a abrir algo o a poner el cursor, y con siete días
        por diecisiete horas delante eso se nota.

        LA NOTA SE VE AL PASAR EL RATÓN. En la rejilla solo caben el texto y el
        color, que es lo que se pidió, pero una nota que no se puede ni intuir
        es una nota perdida. Esto no ocupa ni un punto de pantalla.
        """
        casilla = self.horario.casilla_de(dia, hora)
        color = casilla.color if casilla else None
        pintada = color is not None

        fondo = estilo.pastel(color, self.paleta) if pintada else self.paleta.surface_2
        tinta = (
            estilo.tinta_sobre_pastel(self.paleta) if pintada else self.paleta.ink
        )

        texto = casilla.texto if casilla else ""
        nota = casilla.nota if casilla else ""

        if nota:
            ayuda = nota
        elif texto:
            ayuda = texto
        else:
            ayuda = f"{DIAS[dia].capitalize()} a las {texto_hora(hora)}"

        return ft.Container(
            content=ft.Text(
                texto,
                size=11,
                color=tinta,
                max_lines=2,
                overflow=ft.TextOverflow.ELLIPSIS,
            ),
            expand=True,
            height=ALTO_CASILLA,
            bgcolor=fondo,
            border=ft.Border.all(1, self.paleta.borde),
            border_radius=6,
            padding=ft.Padding.symmetric(horizontal=5, vertical=3),
            alignment=ft.Alignment.CENTER_LEFT,
            tooltip=ayuda,
            on_click=lambda _, d=dia, h=hora: self._abrir_casilla(d, h),
            ink=True,
        )

    def _abrir_casilla(self, dia: int, hora: int) -> None:
        """Abre el apartado de esa hora: color, tarea, emojis y nota."""
        dialogo_casilla.abrir(self.pagina, self.paleta, dia, hora, self.refrescar)
