"""La ventanita de crear o corregir un ejercicio de la biblioteca.

Sirve para las dos cosas, como la de los hábitos: con un ejercicio lo corrige,
sin él crea uno nuevo.

EL DESCANSO SE PONE AQUÍ, en la ficha del ejercicio y no en la rutina. Es una
propiedad del movimiento: una serie pesada de sentadilla pide tres minutos
siempre, la haga el lunes o el jueves. Ponerlo en la rutina obligaría a repetir
el mismo número en cada día donde apareciera.
"""

from __future__ import annotations

from collections.abc import Callable

import flet as ft

from ..datos import repositorio_ejercicios
from ..datos.bd import conectado
from ..dominio.ejercicio import (
    DESCANSO_MAXIMO,
    DESCANSO_MINIMO,
    LARGO_MAXIMO_NOMBRE,
    LARGO_MAXIMO_NOTAS,
    Ejercicio,
    Grupo,
    Material,
    Medida,
)
from . import componentes
from .estilo import Paleta


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    al_guardar: Callable[[], None],
    ejercicio: Ejercicio | None = None,
) -> None:
    """Abre la ventanita. Sin `ejercicio`, crea uno nuevo."""
    pagina.show_dialog(_Dialogo(pagina, paleta, ejercicio, al_guardar).control)


class _Dialogo:
    def __init__(
        self,
        pagina: ft.Page,
        paleta: Paleta,
        ejercicio: Ejercicio | None,
        al_guardar: Callable[[], None],
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.ejercicio = ejercicio
        self.al_guardar = al_guardar

        # Se guardan los desplegables y se leen al guardar, como en el resto de
        # las ventanitas de la aplicacion. Escuchar el evento de cada uno seria
        # tres veces mas codigo para saber lo mismo al final.
        self.grupo = componentes.selector(
            paleta,
            "Grupo",
            [(uno.value, uno.value.capitalize()) for uno in Grupo],
            valor=(ejercicio.grupo if ejercicio else Grupo.PECHO).value,
            ancho=200,
        )
        self.material = componentes.selector(
            paleta,
            "Material",
            [(uno.value, uno.value.capitalize()) for uno in Material],
            valor=(ejercicio.material if ejercicio else Material.BARRA).value,
            ancho=200,
        )
        self.medida = componentes.selector(
            paleta,
            "Como se mide",
            [(uno.value, uno.value.capitalize()) for uno in Medida],
            valor=(
                ejercicio.medida if ejercicio else Medida.PESO_REPETICIONES
            ).value,
            ancho=410,
        )

        self.campo_nombre = componentes.campo_texto(
            paleta,
            "Nombre",
            valor=ejercicio.nombre if ejercicio else "",
            largo_maximo=LARGO_MAXIMO_NOMBRE,
        )
        self.campo_descanso = componentes.campo_texto(
            paleta,
            "Descanso entre series (segundos)",
            valor=str(ejercicio.descanso) if ejercicio else "90",
            ancho=240,
        )
        self.campo_notas = componentes.campo_texto(
            paleta,
            "Notas (técnica, altura del asiento...)",
            valor=ejercicio.notas if ejercicio else "",
            largo_maximo=LARGO_MAXIMO_NOTAS,
        )
        self.campo_notas.multiline = True
        self.campo_notas.min_lines = 2

        self.error = ft.Text("", size=12, color=paleta.negativo, visible=False)

    @property
    def control(self) -> ft.AlertDialog:
        return componentes.dialogo(
            self.paleta,
            "Corregir ejercicio" if self.ejercicio else "Nuevo ejercicio",
            ft.Column(
                [
                    self.campo_nombre,
                    ft.Row([self.grupo, self.material], spacing=10),
                    self.medida,
                    self.campo_descanso,
                    self.campo_notas,
                    self.error,
                ],
                spacing=14,
                tight=True,
                width=430,
                scroll=ft.ScrollMode.AUTO,
            ),
            pagina=self.pagina,
            al_aceptar=lambda _: self._guardar(),
        )

    # ------------------------------------------------------------------

    def _guardar(self) -> None:
        nombre = (self.campo_nombre.value or "").strip()
        if not nombre:
            self._fallar("Ponle un nombre.")
            return

        descanso = self._leer_descanso()
        if descanso is None:
            return

        try:
            nuevo = Ejercicio(
                nombre=nombre,
                grupo=Grupo(self.grupo.value),
                material=Material(self.material.value),
                medida=Medida(self.medida.value),
                descanso=descanso,
                notas=(self.campo_notas.value or "").strip(),
                # Los secundarios se conservan tal cual: no se editan en esta
                # ventana todavía, y perderlos al corregir el nombre sería un
                # dato borrado sin que nadie lo pidiera.
                secundarios=self.ejercicio.secundarios if self.ejercicio else frozenset(),
                id=self.ejercicio.id if self.ejercicio else None,
            )
        except (TypeError, ValueError) as fallo:
            self._fallar(str(fallo))
            return

        with conectado() as conexion:
            if nuevo.id is None:
                repositorio_ejercicios.crear(conexion, nuevo)
            else:
                repositorio_ejercicios.actualizar(conexion, nuevo)

        self.pagina.pop_dialog()
        self.al_guardar()

    def _leer_descanso(self) -> int | None:
        """El descanso, o None con el error ya puesto en pantalla.

        SE AVISA EN VEZ DE ADIVINAR: si alguien escribe "minuto y medio", esto no
        intenta interpretarlo. Un número inventado en el descanso significa un
        cronómetro que suena cuando no toca, y de eso uno no se entera hasta
        estar en el gimnasio.
        """
        texto = (self.campo_descanso.value or "").strip()
        if not texto.isdigit():
            self._fallar("El descanso son segundos, en números. Por ejemplo: 90")
            return None
        segundos = int(texto)
        if not DESCANSO_MINIMO <= segundos <= DESCANSO_MAXIMO:
            self._fallar(
                f"El descanso va de {DESCANSO_MINIMO} a {DESCANSO_MAXIMO} segundos."
            )
            return None
        return segundos

    def _fallar(self, texto: str) -> None:
        self.error.value = texto
        self.error.visible = True
        self.error.update()
