"""La franja del cronómetro de descanso, pegada abajo de la ventana.

POR QUÉ NO VIVE DENTRO DE LA PANTALLA DEL GIMNASIO: porque el descanso es del
entreno, no de la pantalla. Entre serie y serie uno mira el móvil, se va a
Alimentación a apuntar el batido, o cambia de sección sin pensar. Si el
cronómetro muriera ahí, sería inútil justo en el minuto y medio para el que
existe.

CÓMO SE CONSIGUE: este objeto lo crea la ventana UNA vez y lo guarda. Al cambiar
de sección, la ventana se repinta entera —pantalla nueva, controles nuevos— pero
este objeto es el mismo, con su cuenta atrás intacta. Lo que se vuelve a pedir
es solo el dibujo, con `control`.

LO QUE PASA CUANDO SE ACABA: pita, salta el aviso de Windows y la franja se
queda unos segundos más en pantalla. Esos segundos de cortesía no son un adorno:
si desapareciera al llegar a cero y tú estuvieras en otra sección, no verías
nunca por qué ha sonado.
"""

from __future__ import annotations

import asyncio

import flet as ft

from ..dominio.descanso import (
    PASO,
    SEGUNDOS_DE_CORTESIA,
    Descanso,
    ajustar,
    con_aviso_dado,
    correr,
    empezar,
    saltar,
    toca_avisar,
)
from .. import NOMBRE
from ..sistema import avisos
from . import componentes, estilo
from .estilo import Paleta

ALTO = 58
SEGUNDOS_POR_VUELTA = 1


class FranjaDescanso:
    """El cronómetro de descanso: su estado, su cuenta atrás y su dibujo."""

    def __init__(self, pagina: ft.Page) -> None:
        self.pagina = pagina
        self.paleta: Paleta | None = None
        self.descanso: Descanso | None = None

        self.cortesia = 0
        """Segundos que le quedan a la franja en pantalla después de terminar."""

        self.caja = ft.Container(visible=False, height=0)
        self._latiendo = False
        self._vivo = True

    # ------------------------------------------------------------------
    # Lo que usa el gimnasio
    # ------------------------------------------------------------------

    def arrancar(self, segundos: int, *, ejercicio: str = "", serie: int = 0) -> None:
        """Empieza un descanso. Se llama al MARCAR una serie, no con un botón.

        Si ya había uno corriendo, lo sustituye: has marcado otra serie, el
        descanso viejo ya no significa nada.
        """
        self.descanso = empezar(segundos, ejercicio=ejercicio, serie=serie)
        self.cortesia = 0
        self._repintar()

    def parar(self) -> None:
        """Quita la franja del todo. Al cerrar el entreno, por ejemplo."""
        self.descanso = None
        self.cortesia = 0
        self._repintar()

    def cerrar(self) -> None:
        """Al cerrar la aplicación: se para la cuenta para no dejar tareas vivas."""
        self._vivo = False

    @property
    def corriendo(self) -> bool:
        return self.descanso is not None and self.descanso.corriendo

    # ------------------------------------------------------------------
    # El dibujo
    # ------------------------------------------------------------------

    def control(self, paleta: Paleta) -> ft.Control:
        """La franja, lista para meter en la ventana. Se pide en cada repintado.

        La paleta llega aquí y no al constructor porque puede cambiar en marcha:
        si Windows pasa a modo oscuro con un descanso corriendo, la franja tiene
        que cambiar con todo lo demás.
        """
        self.paleta = paleta
        self._pintar()
        return self.caja

    def empezar_a_latir(self) -> None:
        """Arranca la cuenta atrás. La ventana lo llama UNA vez, al montarse.

        Con la guarda de `_latiendo`: sin ella, cada cambio de sección dejaría
        otra cuenta atrás dando vueltas y el reloj bajaría de dos en dos, luego
        de tres en tres.
        """
        if self._latiendo:
            return
        self._latiendo = True
        self.pagina.run_task(self._latir)

    # ------------------------------------------------------------------

    async def _latir(self) -> None:
        while self._vivo:
            await asyncio.sleep(SEGUNDOS_POR_VUELTA)
            if not self._vivo:
                return
            try:
                self._un_segundo()
            except Exception:  # noqa: BLE001
                # Un fallo pintando no puede dejar la aplicación con una tarea
                # muerta que ya no cuenta pero sigue viva.
                self._latiendo = False
                return

    def _un_segundo(self) -> None:
        if self.descanso is None:
            return

        # ESTE «return» ES EL QUE IMPIDE QUE EL PITIDO SUENE EN BUCLE. Un
        # descanso ya terminado sigue recibiendo tics durante los segundos de
        # cortesia; si siguieran de largo, cada uno volveria a ver «terminado» y
        # pitaria otra vez, una vez por segundo. Aqui se va a contar la cortesia
        # y no se toca nada mas.
        if self.descanso.terminado:
            self._contar_cortesia()
            return

        # A partir de aqui el descanso NO estaba terminado: lo garantiza el
        # return de arriba. Por eso llegar a terminado en esta vuelta significa
        # siempre que se acaba de cruzar el cero, y no hace falta guardarse como
        # estaba antes. La primera version lo guardaba en una variable
        # `antes_terminado` que valia False siempre: no protegia de nada, y al
        # romperla a proposito ningun test podia fallar, que es como se
        # descubrio que sobraba.
        self.descanso = correr(self.descanso, 1)

        if toca_avisar(self.descanso):
            avisos.sonar(avisos.TONOS_AVISO)
            self.descanso = con_aviso_dado(self.descanso)

        if self.descanso.terminado:
            self._se_acabo()

        self._repintar()

    def _se_acabo(self) -> None:
        """Pita y saca el aviso de Windows. Solo una vez, al cruzar el cero."""
        avisos.sonar()
        avisos.notificar(
            f"{NOMBRE} · se acabó el descanso",
            self.descanso.titulo() if self.descanso else "Siguiente serie",
        )
        self.cortesia = SEGUNDOS_DE_CORTESIA

    def _contar_cortesia(self) -> None:
        if self.cortesia <= 0:
            return
        self.cortesia -= 1
        if self.cortesia <= 0:
            self.descanso = None
        self._repintar()

    def _repintar(self) -> None:
        if self.paleta is None:
            return
        self._pintar()
        try:
            self.caja.update()
        except Exception:  # noqa: BLE001
            # La franja todavía no está en la página (pasa en el primer
            # repintado, antes de que la ventana la coloque). No es un fallo.
            pass

    def _pintar(self) -> None:
        paleta = self.paleta
        if paleta is None or self.descanso is None:
            self.caja.visible = False
            self.caja.height = 0
            self.caja.content = None
            return

        self.caja.visible = True
        self.caja.height = ALTO
        self.caja.bgcolor = paleta.surface
        self.caja.border = ft.Border.only(top=ft.BorderSide(1, paleta.borde))
        self.caja.padding = ft.Padding.symmetric(horizontal=20)
        self.caja.content = ft.Row(
            self._piezas(paleta),
            spacing=14,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _piezas(self, paleta: Paleta) -> list[ft.Control]:
        descanso = self.descanso
        # ESTE assert NO ES UNA COMPROBACION, es una afirmacion para quien lea:
        # aqui `descanso` no puede ser None porque el unico que llama a esto es
        # _pintar, que se va antes si lo es. Se deja escrito porque el metodo se
        # lee solo y sin esta linea parece que le falta una guarda.
        #
        # Y por eso da igual que python -O lo borre: si desapareciera, el
        # comportamiento seria exactamente el mismo, porque nunca se cumple.
        assert descanso is not None
        terminado = descanso.terminado

        reloj = ft.Text(
            "¡Vamos!" if terminado else descanso.texto(),
            size=estilo.CIFRA,
            color=paleta.acento if terminado else paleta.ink,
            font_family=paleta.titular,
        )

        etiqueta = ft.Column(
            [
                ft.Text(
                    "DESCANSO" if not terminado else "SE ACABÓ",
                    size=estilo.ROTULO,
                    weight=ft.FontWeight.W_600,
                    color=paleta.muted,
                ),
                ft.Text(descanso.titulo(), size=estilo.TEXTO, color=paleta.ink_soft),
            ],
            spacing=0,
            tight=True,
        )

        piezas: list[ft.Control] = [
            ft.Container(content=reloj, width=96),
            etiqueta,
            ft.Container(
                content=componentes.barra_de_avance(
                    paleta, color=paleta.acento, fraccion=descanso.fraccion, alto=6
                ),
                expand=True,
            ),
        ]

        if not terminado:
            piezas += [
                componentes.boton(
                    paleta, f"−{PASO} s", al_pulsar=lambda _: self._ajustar(-PASO)
                ),
                componentes.boton(
                    paleta, f"+{PASO} s", al_pulsar=lambda _: self._ajustar(PASO)
                ),
            ]

        piezas.append(
            componentes.boton_icono(
                paleta,
                ft.Icons.CLOSE,
                ayuda="Saltar el descanso",
                al_pulsar=lambda _: self._saltar(),
            )
        )
        return piezas

    def _ajustar(self, segundos: int) -> None:
        if self.descanso is None:
            return
        self.descanso = ajustar(self.descanso, segundos)
        if self.descanso.terminado:
            # Lo has cortado tú con el "−15": ya lo sabes, no hace falta pitar.
            self.cortesia = SEGUNDOS_DE_CORTESIA
        self._repintar()

    def _saltar(self) -> None:
        if self.descanso is None:
            return
        if self.descanso.terminado:
            self.parar()
            return
        self.descanso = saltar(self.descanso)
        self.cortesia = 0
        self.parar()
