"""La franja del cronómetro de descanso, pegada abajo de la ventana.

POR QUÉ NO VIVE DENTRO DE LA PANTALLA DEL GIMNASIO: porque el descanso es del
entreno, no de la pantalla. Entre serie y serie uno mira el móvil, se va a
Alimentación a apuntar el batido, o cambia de sección sin pensar. Si el
cronómetro muriera ahí, sería inútil justo en el minuto y medio para el que
existe.

CÓMO SE CONSIGUE: este objeto lo crea la ventana UNA vez y lo guarda. Al cambiar
de sección, la ventana se repinta entera —pantalla nueva, controles nuevos— pero
este objeto es el mismo, con su cuenta atrás intacta. Lo que se vuelve a pedir
es solo el dibujo, con `control`.

LO QUE PASA CUANDO SE ACABA: pita, salta el aviso de Windows y la franja se
queda unos segundos más en pantalla. EN EL CELULAR avisa Android (ver
`telefono` y extensiones/focus10_avisos/DescansoAlarma.java), porque con la
app en segundo plano Python no corre y no podría pitar. Esos segundos de cortesía no son un adorno:
si desapareciera al llegar a cero y tú estuvieras en otra sección, no verías
nunca por qué ha sonado.
"""

from __future__ import annotations

import asyncio

import json
import time

import flet as ft

from ..datos import ajustes
from ..datos.bd import conectado

from ..dominio.descanso import (
    PASO,
    SEGUNDOS_DE_CORTESIA,
    Descanso,
    ajustar,
    con_aviso_dado,
    correr,
    empezar,
    saltar,
    toca_avisar,
)
from .. import NOMBRE
from ..sistema import avisos
from . import componentes, estilo
from .estilo import Paleta

ALTO = 58
SEGUNDOS_POR_VUELTA = 1


class FranjaDescanso:
    """El cronómetro de descanso: su estado, su cuenta atrás y su dibujo."""

    def __init__(self, pagina: ft.Page) -> None:
        self.pagina = pagina
        self.paleta: Paleta | None = None
        self.descanso: Descanso | None = None

        self.cortesia = 0
        """Segundos que le quedan a la franja en pantalla después de terminar."""

        self.caja = ft.Container(visible=False, height=0)
        self.telefono = None
        """La pieza de Android (focus10_avisos.Avisos), o None en la PC y la
        web. Si está, el final del descanso lo avisa Android con una alarma."""
        self._permisos_mirados = False
        self._latiendo = False
        self._vivo = True
        # LA HORA REAL, y aparte para que los tests puedan adelantarla sin
        # esperar de verdad noventa segundos por cada descanso.
        self._ahora = time.time
        # CUÁNDO SE CONTÓ POR ÚLTIMA VEZ, en hora real. Ver `_un_segundo`.
        self._reloj = self._ahora()

    # ------------------------------------------------------------------
    # Lo que usa el gimnasio
    # ------------------------------------------------------------------

    def arrancar(self, segundos: int, *, ejercicio: str = "", serie: int = 0) -> None:
        """Empieza un descanso. Se llama al MARCAR una serie, no con un botón.

        Si ya había uno corriendo, lo sustituye: has marcado otra serie, el
        descanso viejo ya no significa nada.
        """
        self.descanso = empezar(segundos, ejercicio=ejercicio, serie=serie)
        self.cortesia = 0
        self._reloj = self._ahora()
        self._recordar()
        self._repintar()

    def parar(self) -> None:
        """Quita la franja del todo. Al cerrar el entreno, por ejemplo."""
        self.descanso = None
        self.cortesia = 0
        self._olvidar()
        self._repintar()

    # ------------------------------------------------------------------
    # Que el descanso sobreviva a salir de la aplicación
    # ------------------------------------------------------------------
    #
    # LO PIDIÓ EL USUARIO: «cuando salga de la app, bloquee el teléfono o
    # cambie a otra aplicación, la rutina debe continuar y conservar todo:
    # tiempo, series, descansos». El reloj del entreno ya lo hacía, porque
    # cuenta desde la hora en que empezó. El descanso NO: descontaba un
    # segundo por latido, y con la aplicación en segundo plano no hay latidos,
    # así que al volver seguía donde lo dejaste.
    #
    # DOS ARREGLOS, uno para cada forma de irse:
    #  - Si solo sales un rato, al volver se descuenta el tiempo REAL que pasó
    #    (`_un_segundo` mira el reloj, no cuenta latidos).
    #  - Si Android cierra la aplicación del todo, se pierde la memoria. Por
    #    eso se guarda en la base CUÁNDO termina el descanso, y al volver a
    #    abrir se retoma lo que quede (`retomar`).
    #
    # time.time() Y NO time.monotonic(): el monotónico de Android se para
    # mientras el teléfono duerme, que es justo el rato que hay que contar.

    def _recordar(self) -> None:
        if self.descanso is None:
            return
        fin = self._ahora() + self.descanso.restante
        self._al_telefono(
            "programar_descanso", fin, f"{NOMBRE} · se acabó el descanso", self.descanso.titulo()
        )
        valor = json.dumps(
            {
                "fin": fin,
                "ejercicio": self.descanso.ejercicio,
                "serie": self.descanso.serie,
            }
        )
        try:
            with conectado() as conexion:
                ajustes.escribir(conexion, ajustes.CLAVE_DESCANSO_EN_MARCHA, valor)
        except Exception:  # noqa: BLE001
            # No poder guardarlo no puede parar el descanso que está en marcha.
            pass

    def _olvidar(self, *, y_el_aviso_del_telefono: bool = True) -> None:
        """Ya no hay descanso que retomar.

        `y_el_aviso_del_telefono=False` CUANDO SE ACABÓ SOLO: a esa misma hora
        Android saca el aviso del final, y quitarlo aquí lo borraría justo
        cuando tiene que verse.
        """
        if y_el_aviso_del_telefono:
            self._al_telefono("cancelar_descanso")
        try:
            with conectado() as conexion:
                ajustes.escribir(conexion, ajustes.CLAVE_DESCANSO_EN_MARCHA, "")
        except Exception:  # noqa: BLE001
            pass

    def retomar(self) -> None:
        """Si al cerrarse la aplicación quedaba un descanso, sigue con lo que quede.

        SI YA SE ACABÓ MIENTRAS NO ESTABAS, NO SE ENSEÑA: un cartel de «se acabó
        el descanso» de hace diez minutos no le sirve a nadie.
        """
        try:
            with conectado() as conexion:
                guardado = ajustes.leer(conexion, ajustes.CLAVE_DESCANSO_EN_MARCHA)
            datos = json.loads(guardado) if guardado else None
        except Exception:  # noqa: BLE001
            return
        if not datos:
            return
        quedan = int(float(datos.get("fin", 0)) - self._ahora())
        if quedan <= 0:
            self._olvidar(y_el_aviso_del_telefono=False)
            return
        self.arrancar(
            quedan,
            ejercicio=str(datos.get("ejercicio") or ""),
            serie=int(datos.get("serie") or 0),
        )

    def al_volver(self) -> None:
        """Al volver a la app: se pone al día YA, y si la cuenta se murió, renace.

        «SE CORTA AL SALIR DE LA APP», dijo el usuario. Con la app en segundo
        plano un latido puede fallar al pintar, y antes eso terminaba la cuenta
        para siempre: al volver, la franja se quedaba quieta. Ahora un latido
        fallido no la mata (ver `_latir`), y además aquí se vuelve a arrancar.
        """
        try:
            self._un_segundo()
        except Exception:  # noqa: BLE001
            pass
        self.empezar_a_latir()

    def _al_telefono(self, que: str, *datos) -> None:
        """Le pasa algo a la pieza de Android, sin esperar y sin poder romper nada."""
        if self.telefono is None:
            return

        async def hacerlo():
            try:
                await getattr(self.telefono, que)(*datos)
                if que == "programar_descanso" and not self._permisos_mirados:
                    self._permisos_mirados = True
                    await self._mirar_permisos()
            except Exception:  # noqa: BLE001
                # Si el teléfono no contesta, el descanso sigue en la pantalla.
                pass

        try:
            self.pagina.run_task(hacerlo)
        except Exception:  # noqa: BLE001
            pass

    async def _mirar_permisos(self) -> None:
        """La primera vez, si Android no deja avisar (o no a la hora justa), se dice.

        SIN ESTO NO SE ENTERA NADIE: Android no da error, simplemente no suena,
        que es exactamente el fallo que se está arreglando.
        """
        avisa = await self.telefono.puede_avisar()
        exacta = await self.telefono.puede_alarma_exacta()
        if avisa and exacta:
            return
        falta = "Notificaciones" if not avisa else "Alarmas y recordatorios"
        abrir = self.telefono.abrir_ajustes_avisos if not avisa else self.telefono.abrir_ajustes_alarmas

        async def ir(_):
            self.pagina.pop_dialog()
            await abrir()

        self.pagina.show_dialog(ft.AlertDialog(
            title=ft.Text("Para que el descanso suene"),
            content=ft.Text(
                f"Con la app cerrada, el aviso del final del descanso lo da Android. "
                f"Para eso, permití «{falta}» para {NOMBRE} en los ajustes."
            ),
            actions=[
                ft.TextButton("Ahora no", on_click=lambda _: self.pagina.pop_dialog()),
                ft.FilledButton("Abrir ajustes", on_click=ir),
            ],
        ))

    def cerrar(self) -> None:
        """Al cerrar la aplicación: se para la cuenta para no dejar tareas vivas."""
        self._vivo = False

    @property
    def corriendo(self) -> bool:
        return self.descanso is not None and self.descanso.corriendo

    # ------------------------------------------------------------------
    # El dibujo
    # ------------------------------------------------------------------

    def control(self, paleta: Paleta) -> ft.Control:
        """La franja, lista para meter en la ventana. Se pide en cada repintado.

        La paleta llega aquí y no al constructor porque puede cambiar en marcha:
        si Windows pasa a modo oscuro con un descanso corriendo, la franja tiene
        que cambiar con todo lo demás.
        """
        self.paleta = paleta
        self._pintar()
        return self.caja

    def empezar_a_latir(self) -> None:
        """Arranca la cuenta atrás. La ventana lo llama UNA vez, al montarse.

        Con la guarda de `_latiendo`: sin ella, cada cambio de sección dejaría
        otra cuenta atrás dando vueltas y el reloj bajaría de dos en dos, luego
        de tres en tres.
        """
        if self._latiendo:
            return
        self._latiendo = True
        self.pagina.run_task(self._latir)

    # ------------------------------------------------------------------

    async def _latir(self) -> None:
        while self._vivo:
            await asyncio.sleep(SEGUNDOS_POR_VUELTA)
            if not self._vivo:
                return
            try:
                self._un_segundo()
            except Exception:  # noqa: BLE001
                # UN LATIDO QUE FALLA NO TERMINA LA CUENTA. Antes sí, y era el
                # «se corta al salir de la app»: en segundo plano pintar puede
                # fallar, y la cuenta moría. El siguiente latido lo vuelve a
                # intentar con la hora real, así que no se pierde nada.
                continue

    def _un_segundo(self) -> None:
        if self.descanso is None:
            return

        # ESTE «return» ES EL QUE IMPIDE QUE EL PITIDO SUENE EN BUCLE. Un
        # descanso ya terminado sigue recibiendo tics durante los segundos de
        # cortesia; si siguieran de largo, cada uno volveria a ver «terminado» y
        # pitaria otra vez, una vez por segundo. Aqui se va a contar la cortesia
        # y no se toca nada mas.
        if self.descanso.terminado:
            self._contar_cortesia()
            return

        # A partir de aqui el descanso NO estaba terminado: lo garantiza el
        # return de arriba. Por eso llegar a terminado en esta vuelta significa
        # siempre que se acaba de cruzar el cero, y no hace falta guardarse como
        # estaba antes. La primera version lo guardaba en una variable
        # `antes_terminado` que valia False siempre: no protegia de nada, y al
        # romperla a proposito ningun test podia fallar, que es como se
        # descubrio que sobraba.
        # EL TIEMPO QUE HA PASADO DE VERDAD, no «un segundo»: si la aplicación
        # estuvo en segundo plano, este latido llega tarde y trae de golpe
        # todo lo que no se contó. Ver el bloque de arriba.
        ahora = self._ahora()
        pasados = int(ahora - self._reloj)
        if pasados < 1:
            return
        self._reloj += pasados
        self.descanso = correr(self.descanso, pasados)

        if self.descanso.terminado:
            self._se_acabo()
        elif toca_avisar(self.descanso):
            # SOLO SI NO SE ACABÓ YA: volviendo de segundo plano puede saltarse
            # los diez segundos de golpe, y pitar «quedan diez» junto al «se
            # acabó» serían dos pitidos para una sola noticia.
            avisos.sonar(avisos.TONOS_AVISO)
            self.descanso = con_aviso_dado(self.descanso)

        self._repintar()

    def _se_acabo(self) -> None:
        """Pita y saca el aviso de Windows. Solo una vez, al cruzar el cero."""
        avisos.sonar()
        avisos.notificar(
            f"{NOMBRE} · se acabó el descanso",
            self.descanso.titulo() if self.descanso else "Siguiente serie",
        )
        self.cortesia = SEGUNDOS_DE_CORTESIA
        self._olvidar(y_el_aviso_del_telefono=False)

    def _contar_cortesia(self) -> None:
        if self.cortesia <= 0:
            return
        self.cortesia -= 1
        if self.cortesia <= 0:
            self.descanso = None
        self._repintar()

    def _repintar(self) -> None:
        if self.paleta is None:
            return
        self._pintar()
        try:
            self.caja.update()
        except Exception:  # noqa: BLE001
            # La franja todavía no está en la página (pasa en el primer
            # repintado, antes de que la ventana la coloque). No es un fallo.
            pass

    def _pintar(self) -> None:
        paleta = self.paleta
        if paleta is None or self.descanso is None:
            self.caja.visible = False
            self.caja.height = 0
            self.caja.content = None
            return

        self.caja.visible = True
        self.caja.bgcolor = paleta.surface
        if estilo.pantalla_estrecha():
            self._pintar_panel(paleta)
            return
        self.caja.height = ALTO
        self.caja.border = ft.Border.only(top=ft.BorderSide(1, paleta.borde))
        self.caja.padding = ft.Padding.symmetric(horizontal=20)
        self.caja.content = ft.Row(
            self._piezas(paleta),
            spacing=14,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _pintar_panel(self, paleta: Paleta) -> None:
        """En el celular: un panel grande, ENCIMA de los botones de Android.

        LO PIDIÓ EL USUARIO con una captura: la franja fina quedaba debajo de
        los botones del teléfono (atrás, inicio) y no se veía ni se podía tocar.
        El SafeArea es lo que la sube por encima de ellos; y en grande, porque
        se mira con el teléfono en el banco, de lejos.
        """
        descanso = self.descanso
        terminado = descanso.terminado
        self.caja.height = None
        self.caja.border = ft.Border.only(top=ft.BorderSide(3, paleta.acento))
        self.caja.padding = ft.Padding.only(left=20, right=20, top=12, bottom=8)
        botones: list[ft.Control] = []
        if not terminado:
            botones = [
                ft.Container(componentes.boton(
                    paleta, f"−{PASO} s", al_pulsar=lambda _: self._ajustar(-PASO)), expand=True),
                ft.Container(componentes.boton(
                    paleta, f"+{PASO} s", al_pulsar=lambda _: self._ajustar(PASO)), expand=True),
            ]
        botones.append(ft.Container(componentes.boton(
            paleta, "Saltar" if not terminado else "Cerrar", icono=ft.Icons.SKIP_NEXT,
            principal=True, al_pulsar=lambda _: self._saltar()), expand=True))
        self.caja.content = ft.SafeArea(
            ft.Column(
                [
                    ft.Text(
                        ("SE ACABÓ · " if terminado else "DESCANSO · ") + descanso.titulo(),
                        size=estilo.ROTULO, weight=ft.FontWeight.W_600, color=paleta.muted,
                        max_lines=1, overflow=ft.TextOverflow.ELLIPSIS,
                    ),
                    ft.Text(
                        "¡Vamos!" if terminado else descanso.texto(),
                        size=estilo.CIFRA_GRANDE,
                        color=paleta.acento if terminado else paleta.ink,
                        font_family=paleta.titular,
                    ),
                    componentes.barra_de_avance(
                        paleta, color=paleta.acento, fraccion=descanso.fraccion, alto=8
                    ),
                    ft.Row(botones, spacing=8),
                ],
                spacing=8,
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            avoid_intrusions_top=False,
            avoid_intrusions_left=False,
            avoid_intrusions_right=False,
        )

    def _piezas(self, paleta: Paleta) -> list[ft.Control]:
        descanso = self.descanso
        # ESTE assert NO ES UNA COMPROBACION, es una afirmacion para quien lea:
        # aqui `descanso` no puede ser None porque el unico que llama a esto es
        # _pintar, que se va antes si lo es. Se deja escrito porque el metodo se
        # lee solo y sin esta linea parece que le falta una guarda.
        #
        # Y por eso da igual que python -O lo borre: si desapareciera, el
        # comportamiento seria exactamente el mismo, porque nunca se cumple.
        assert descanso is not None
        terminado = descanso.terminado

        reloj = ft.Text(
            "¡Vamos!" if terminado else descanso.texto(),
            size=estilo.CIFRA,
            color=paleta.acento if terminado else paleta.ink,
            font_family=paleta.titular,
        )

        etiqueta = ft.Column(
            [
                ft.Text(
                    "DESCANSO" if not terminado else "SE ACABÓ",
                    size=estilo.ROTULO,
                    weight=ft.FontWeight.W_600,
                    color=paleta.muted,
                ),
                ft.Text(descanso.titulo(), size=estilo.TEXTO, color=paleta.ink_soft),
            ],
            spacing=0,
            tight=True,
        )

        piezas: list[ft.Control] = [
            ft.Container(content=reloj, width=96),
            etiqueta,
            ft.Container(
                content=componentes.barra_de_avance(
                    paleta, color=paleta.acento, fraccion=descanso.fraccion, alto=6
                ),
                expand=True,
            ),
        ]

        if not terminado:
            piezas += [
                componentes.boton(
                    paleta, f"−{PASO} s", al_pulsar=lambda _: self._ajustar(-PASO)
                ),
                componentes.boton(
                    paleta, f"+{PASO} s", al_pulsar=lambda _: self._ajustar(PASO)
                ),
            ]

        piezas.append(
            componentes.boton_icono(
                paleta,
                ft.Icons.CLOSE,
                ayuda="Saltar el descanso",
                al_pulsar=lambda _: self._saltar(),
            )
        )
        return piezas

    def _ajustar(self, segundos: int) -> None:
        if self.descanso is None:
            return
        self.descanso = ajustar(self.descanso, segundos)
        if self.descanso.terminado:
            # Lo has cortado tú con el "−15": ya lo sabes, no hace falta pitar.
            self.cortesia = SEGUNDOS_DE_CORTESIA
            self._olvidar()
        else:
            self._recordar()
        self._repintar()

    def _saltar(self) -> None:
        if self.descanso is None:
            return
        if self.descanso.terminado:
            self.parar()
            return
        self.descanso = saltar(self.descanso)
        self.cortesia = 0
        self.parar()
