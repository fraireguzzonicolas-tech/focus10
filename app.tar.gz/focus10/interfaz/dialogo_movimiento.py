"""La ventanita para apuntar un gasto o un ingreso.

POR QUÉ NO SE CIERRA SI EL IMPORTE NO SE ENTIENDE: el campo se pone en rojo con
el motivo y la ventana sigue abierta. Cerrarla y avisar después haría perder lo
escrito; guardar un importe adivinado sería peor todavía.

Todo lo que se ve aquí sale de componentes.py: ni un campo ni un botón hecho a
mano, para que esta ventanita y la de los saldos se comporten igual.
"""

from __future__ import annotations

from collections.abc import Callable

import flet as ft

from ..datos import repositorio_categorias, repositorio_movimientos
from ..datos import ajustes
from ..datos import memoria_gastos as memoria_guardada
from ..datos.bd import conectado
from ..dominio import dinero, memoria_gastos
from ..dominio.categoria import Categoria, Memoria
from ..dominio.moneda import Moneda
from ..dominio.movimiento import LARGO_MAXIMO_DESCRIPCION, Tipo
from . import componentes, dialogo_categoria
from .estilo import Paleta

NUEVA = "nueva"
"""La clave de «+ Nueva categoría…» en el desplegable. No choca con ninguna
categoría: las de verdad tienen un número de clave."""

AVISO_MONEDA_EXTRANJERA = (
    "El tipo de cambio todavía no se consulta (esa parte no está hecha), así que "
    "este movimiento quedará marcado como pendiente y no entrará en los totales "
    "hasta que se resuelva. El importe se guarda intacto."
)


def abrir(
    pagina: ft.Page,
    tipo: Tipo,
    paleta: Paleta,
    al_guardar: Callable[[], None],
) -> None:
    """Abre la ventanita. `al_guardar` se llama tras guardar, para refrescar."""
    with conectado() as conexion:
        categorias = repositorio_categorias.listar(conexion, tipo=tipo)
        # LA MONEDA PRINCIPAL SE LEE DEL AJUSTE, no de la constante del catálogo.
        # Era un fallo de verdad: el campo salía SIEMPRE en euros aunque hubieras
        # puesto dólares en Configuración, así que cambiar la moneda principal no
        # cambiaba nada de lo que apuntabas a partir de entonces, que es
        # exactamente para lo que sirve ese ajuste.
        principal = ajustes.leer_moneda_principal(conexion)

    # SIN NINGUNA CATEGORÍA, PRIMERO SE CREA UNA y después se abre lo de
    # apuntar. Antes esto solo avisaba «créala», pero no había dónde.
    if not categorias:
        dialogo_categoria.crear(
            pagina, paleta, tipo, lambda _: abrir(pagina, tipo, paleta, al_guardar)
        )
        return

    pagina.show_dialog(
        _DialogoMovimiento(
            pagina, tipo, paleta, categorias, al_guardar, principal
        ).control
    )


TITULOS = {
    Tipo.GASTO: "Nuevo gasto",
    Tipo.INGRESO: "Nuevo ingreso",
    Tipo.AHORRO: "Apartar para ahorrar",
    Tipo.RETIRADA_AHORRO: "Sacar del ahorro",
    Tipo.INVERSION: "Mandar a invertir",
    Tipo.RETIRADA_INVERSION: "Sacar de la inversión",
}
"""Cómo se llama la ventanita según lo que se apunte.

SON SEIS FRASES Y NO "Nuevo {lo que sea}", y es a propósito: "Nuevo ahorro" no
dice lo que estás haciendo. Apartar dinero y sacarlo son acciones, y en la
ventana donde se escribe el importe es donde más importa que se entienda cuál de
las dos es.
"""


class _DialogoMovimiento:
    """Guarda el estado de la ventanita: los campos y lo que hace cada botón."""

    def __init__(
        self,
        pagina: ft.Page,
        tipo: Tipo,
        paleta: Paleta,
        categorias: list[Categoria],
        al_guardar: Callable[[], None],
        principal: Moneda,
    ) -> None:
        self.pagina = pagina
        self.tipo = tipo
        self.paleta = paleta
        self.al_guardar = al_guardar
        self.principal = principal
        self.categorias = {una.id: una for una in categorias}

        self.dinero = componentes.CampoDinero(
            paleta,
            "Importe",
            moneda=principal,
            al_enviar=lambda _: self._guardar(),
            al_cambiar_moneda=lambda _: self._revisar_moneda(),
        )
        # CREAR UNA CATEGORÍA DESDE AQUÍ MISMO: es donde te das cuenta de que
        # te falta («esto va a Proyecto IA»). Mandarte a Configuración haría
        # perder lo que ya escribiste.
        self.categoria = componentes.selector(
            paleta,
            "Categoría",
            self._opciones(),
            valor=str(categorias[0].id),
            ancho=330,
            al_elegir=lambda _: self._al_elegir_categoria(),
        )
        self.elegida = self.categoria.value
        # LA NOTA, que la pidió el usuario para "aclarar diferentes motivos o
        # incluso poner ahí la conversión". Es el sitio donde escribir a mano lo
        # que la aplicación no calcula: a cuánto estaba el cambio ese día, por
        # qué fue ese gasto, o cualquier cosa que quieras acordarte de leer
        # dentro de un año. De varias líneas porque una nota de una línea acaba
        # sin escribirse.
        self.descripcion = componentes.campo_texto(
            paleta,
            "Nota (opcional)",
            pista="Uber al gimnasio · el cambio estaba a 1 EUR = 1,08 US$",
            ancho=330,
            largo_maximo=LARGO_MAXIMO_DESCRIPCION,
        )
        self.descripcion.multiline = True
        self.descripcion.min_lines = 2
        # El aviso vive dentro de un contenedor que se enseña o se esconde, en
        # vez de crearse y destruirse: así basta con cambiar "visible".
        self.aviso = ft.Container(
            content=componentes.aviso(paleta, [AVISO_MONEDA_EXTRANJERA]),
            visible=False,
            width=340,
        )

        self.control = componentes.dialogo(
            paleta,
            TITULOS[tipo],
            ft.Column(
                [self.dinero.control, self.categoria, self.descripcion, self.aviso],
                spacing=12,
                tight=True,
                width=350,
            ),
            pagina=pagina,
            al_aceptar=lambda _: self._guardar(),
        )

    # ----------------------------------------------------------------------

    def _opciones(self) -> list[tuple[str, str]]:
        return [(str(id_), una.nombre) for id_, una in self.categorias.items()] + [
            (NUEVA, "+ Nueva categoría…")
        ]

    def _al_elegir_categoria(self) -> None:
        if self.categoria.value != NUEVA:
            self.elegida = self.categoria.value
            return
        # Mientras se crea, el desplegable vuelve a la que estaba: si se
        # cancela, no se queda marcada una opción que no es una categoría.
        self.categoria.value = self.elegida
        self.pagina.update()
        dialogo_categoria.crear(
            self.pagina, self.paleta, self.tipo, self._categoria_creada
        )

    def _categoria_creada(self, nueva: Categoria) -> None:
        self.categorias[nueva.id] = nueva
        self.categoria.options = [
            ft.DropdownOption(key=clave, text=texto) for clave, texto in self._opciones()
        ]
        self.categoria.value = self.elegida = str(nueva.id)
        self.pagina.update()

    def _revisar_moneda(self) -> None:
        """Enseña el aviso solo cuando la moneda no es la principal."""
        self.aviso.visible = self.dinero.moneda_elegida() != self.principal
        self.dinero.limpiar_error()
        self.pagina.update()

    def _guardar(self) -> None:
        moneda = self.dinero.moneda_elegida()
        unidades = self.dinero.unidades()

        if unidades is None:
            self.dinero.marcar_error("No entiendo ese importe")
            self.pagina.update()
            return
        if unidades <= 0:
            # El signo lo dice el tipo, así que aquí un importe negativo o cero
            # no significa nada.
            self.dinero.marcar_error("Tiene que ser mayor que cero")
            self.pagina.update()
            return

        categoria = self.categorias[int(self.categoria.value)]
        if self.tipo is Tipo.GASTO and categoria.memoria is Memoria.PREGUNTAR:
            dialogo_categoria.preguntar(
                self.pagina, self.paleta, categoria, self._con_respuesta
            )
            return
        self._mirar_la_memoria(categoria, moneda, unidades)

    def _con_respuesta(self, categoria: Categoria) -> None:
        """Ya respondió la pregunta pendiente: se sigue con lo que eligió."""
        self.categorias[categoria.id] = categoria
        self._mirar_la_memoria(
            categoria, self.dinero.moneda_elegida(), self.dinero.unidades()
        )

    def _mirar_la_memoria(self, categoria: Categoria, moneda: Moneda, unidades: int) -> None:
        """Si la categoría se recuerda y ya hay algo parecido, se pregunta antes.

        SOLO EN LAS CATEGORÍAS QUE RECUERDAN, y en todas ellas: lo eligió el
        usuario. Un almuerzo en «Comida» nunca dispara el aviso.
        """
        if self.tipo is Tipo.GASTO and categoria.memoria is Memoria.SI:
            with conectado() as conexion:
                memoria = memoria_guardada.recordados(conexion)
            pregunta = memoria_gastos.aviso(
                unidades, moneda,
                memoria_gastos.parecidos(self.descripcion.value or "", memoria),
            )
            if pregunta:
                dialogo_categoria.avisar_repetido(
                    self.pagina, self.paleta, pregunta,
                    lambda: self._apuntar(moneda, unidades),
                )
                return
        self._apuntar(moneda, unidades)

    def _apuntar(self, moneda: Moneda, unidades: int) -> None:
        with conectado() as conexion:
            movimiento = repositorio_movimientos.apuntar_ahora(
                conexion, self.tipo, unidades, moneda,
                int(self.categoria.value), self.descripcion.value or "",
            )

        self.pagina.pop_dialog()
        componentes.avisar(
            self.pagina,
            f"Apuntado: {dinero.formatear(unidades, moneda)}"
            + (" (pendiente de convertir)" if movimiento.pendiente_de_cambio else ""),
        )
        self.al_guardar()
