"""La ventanita para apuntar un gasto o un ingreso.

POR QUÉ NO SE CIERRA SI EL IMPORTE NO SE ENTIENDE: el campo se pone en rojo con
el motivo y la ventana sigue abierta. Cerrarla y avisar después haría perder lo
escrito; guardar un importe adivinado sería peor todavía.

Todo lo que se ve aquí sale de componentes.py: ni un campo ni un botón hecho a
mano, para que esta ventanita y la de los saldos se comporten igual.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime

import flet as ft

from ..datos import repositorio_categorias, repositorio_movimientos
from ..datos import ajustes
from ..datos.ajustes import leer_horario
from ..datos.bd import conectado
from ..dominio import dinero
from ..dominio.categoria import Categoria
from ..dominio.moneda import Moneda
from ..dominio.movimiento import LARGO_MAXIMO_DESCRIPCION, Movimiento, Tipo
from . import componentes
from .estilo import Paleta

AVISO_MONEDA_EXTRANJERA = (
    "El tipo de cambio todavía no se consulta (esa parte no está hecha), así que "
    "este movimiento quedará marcado como pendiente y no entrará en los totales "
    "hasta que se resuelva. El importe se guarda intacto."
)


def abrir(
    pagina: ft.Page,
    tipo: Tipo,
    paleta: Paleta,
    al_guardar: Callable[[], None],
) -> None:
    """Abre la ventanita. `al_guardar` se llama tras guardar, para refrescar."""
    with conectado() as conexion:
        categorias = repositorio_categorias.listar(conexion, tipo=tipo)
        # LA MONEDA PRINCIPAL SE LEE DEL AJUSTE, no de la constante del catálogo.
        # Era un fallo de verdad: el campo salía SIEMPRE en euros aunque hubieras
        # puesto dólares en Configuración, así que cambiar la moneda principal no
        # cambiaba nada de lo que apuntabas a partir de entonces, que es
        # exactamente para lo que sirve ese ajuste.
        principal = ajustes.leer_moneda_principal(conexion)

    if not categorias:
        componentes.avisar(
            pagina,
            f"No hay ninguna categoría de {tipo.value} activa. Actívala o crea "
            "una antes de apuntar.",
        )
        return

    pagina.show_dialog(
        _DialogoMovimiento(
            pagina, tipo, paleta, categorias, al_guardar, principal
        ).control
    )


class _DialogoMovimiento:
    """Guarda el estado de la ventanita: los campos y lo que hace cada botón."""

    def __init__(
        self,
        pagina: ft.Page,
        tipo: Tipo,
        paleta: Paleta,
        categorias: list[Categoria],
        al_guardar: Callable[[], None],
        principal: Moneda,
    ) -> None:
        self.pagina = pagina
        self.tipo = tipo
        self.paleta = paleta
        self.al_guardar = al_guardar
        self.principal = principal

        self.dinero = componentes.CampoDinero(
            paleta,
            "Importe",
            moneda=principal,
            al_enviar=lambda _: self._guardar(),
            al_cambiar_moneda=lambda _: self._revisar_moneda(),
        )
        self.categoria = componentes.selector(
            paleta,
            "Categoría",
            [(str(una.id), una.nombre) for una in categorias],
            valor=str(categorias[0].id),
            ancho=330,
        )
        # LA NOTA, que la pidió el usuario para "aclarar diferentes motivos o
        # incluso poner ahí la conversión". Es el sitio donde escribir a mano lo
        # que la aplicación no calcula: a cuánto estaba el cambio ese día, por
        # qué fue ese gasto, o cualquier cosa que quieras acordarte de leer
        # dentro de un año. De varias líneas porque una nota de una línea acaba
        # sin escribirse.
        self.descripcion = componentes.campo_texto(
            paleta,
            "Nota (opcional)",
            pista="Uber al gimnasio · el cambio estaba a 1 EUR = 1,08 US$",
            ancho=330,
            largo_maximo=LARGO_MAXIMO_DESCRIPCION,
        )
        self.descripcion.multiline = True
        self.descripcion.min_lines = 2
        # El aviso vive dentro de un contenedor que se enseña o se esconde, en
        # vez de crearse y destruirse: así basta con cambiar "visible".
        self.aviso = ft.Container(
            content=componentes.aviso(paleta, [AVISO_MONEDA_EXTRANJERA]),
            visible=False,
            width=340,
        )

        self.control = componentes.dialogo(
            paleta,
            "Nuevo gasto" if tipo is Tipo.GASTO else "Nuevo ingreso",
            ft.Column(
                [self.dinero.control, self.categoria, self.descripcion, self.aviso],
                spacing=12,
                tight=True,
                width=350,
            ),
            pagina=pagina,
            al_aceptar=lambda _: self._guardar(),
        )

    # ----------------------------------------------------------------------

    def _revisar_moneda(self) -> None:
        """Enseña el aviso solo cuando la moneda no es la principal."""
        self.aviso.visible = self.dinero.moneda_elegida() != self.principal
        self.dinero.limpiar_error()
        self.pagina.update()

    def _guardar(self) -> None:
        moneda = self.dinero.moneda_elegida()
        unidades = self.dinero.unidades()

        if unidades is None:
            self.dinero.marcar_error("No entiendo ese importe")
            self.pagina.update()
            return
        if unidades <= 0:
            # El signo lo dice el tipo, así que aquí un importe negativo o cero
            # no significa nada.
            self.dinero.marcar_error("Tiene que ser mayor que cero")
            self.pagina.update()
            return

        with conectado() as conexion:
            horario = leer_horario(conexion)
            movimiento = Movimiento.nuevo(
                tipo=self.tipo,
                importe=unidades,
                categoria_id=int(self.categoria.value),
                momento=datetime.now(),
                horario=horario,
                moneda=moneda,
                descripcion=self.descripcion.value or "",
                # Sin tasa a propósito: el tipo de cambio todavía no se
                # consulta. Si la moneda es la principal, Movimiento.nuevo pone
                # tasa 1 solo; si es otra, queda pendiente, que es lo honesto.
                tasa=None,
            )
            repositorio_movimientos.guardar(conexion, movimiento)

        self.pagina.pop_dialog()
        componentes.avisar(
            self.pagina,
            f"Apuntado: {dinero.formatear(unidades, moneda)}"
            + (" (pendiente de convertir)" if movimiento.pendiente_de_cambio else ""),
        )
        self.al_guardar()
