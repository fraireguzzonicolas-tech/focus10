"""La tarjeta de Configuración para usar Focus1% desde WhatsApp.

TRES COSAS Y NADA MÁS: ver si tu WhatsApp está vinculado, agregar a FOCUS1%
(lo mismo que se ofrece al abrir la app: ver sumar_whatsapp.py) y
desvincularlo. Cómo funciona la vinculación está en sistema/whatsapp.py.

MIENTRAS NO ESTÉ ACTIVADO EN EL SERVIDOR, LO DICE: sin el número del bot no
hay a quién escribir, y un botón que abre un WhatsApp a nadie no sirve.
"""

from __future__ import annotations

import asyncio

import flet as ft

from ..sistema import whatsapp
from ..sistema.sincronizacion import ServidorDijoQueNo, SinConexion
from . import componentes
from .con_sesion import con_la_sesion
from .estilo import Paleta
from .sumar_whatsapp import NOMBRE_DEL_CONTACTO, sumar

SIN_ACTIVAR = (
    "Todavía no está activado: falta conectar el número del bot (ver "
    "servidor/WHATSAPP.md). Cuando esté, desde aquí vinculás tu WhatsApp."
)


class TarjetaWhatsapp:
    def __init__(self, pagina: ft.Page, paleta: Paleta, avisos=None) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.avisos = avisos
        """La pieza de Android, para guardar el contacto. None en la PC."""
        self.estado = "sin_activar" if not whatsapp.NUMERO_DEL_BOT else "cargando"
        self.codigo = ""
        self.error = ""
        self._hueco = ft.Container()

    def control(self) -> ft.Control:
        self._hueco.content = self._dibujo()
        return self._hueco

    def cargar(self) -> None:
        if self.estado == "cargando":
            self.pagina.run_task(self._mirar)

    # ------------------------------------------------------------ la red

    async def _mirar(self) -> None:
        await self._con_red(lambda testigo: "vinculado" if whatsapp.vinculado(testigo) else "libre")

    async def _vincular(self) -> None:
        async def agregar():
            self.codigo = await sumar(self.pagina, self.avisos)
            return "codigo"

        await self._con_red(agregar)

    async def _desvincular(self) -> None:
        def soltar(testigo):
            whatsapp.desvincular(testigo)
            return "libre"

        await self._con_red(soltar)

    async def _con_red(self, que_hacer) -> None:
        """`que_hacer`: algo para hacer con la sesión (en otro hilo), o una
        corrutina sin argumentos que ya se encarga de la sesión (sumar)."""
        try:
            if asyncio.iscoroutinefunction(que_hacer):
                self.estado = await que_hacer()
            else:
                self.estado = await con_la_sesion(que_hacer)
            self.error = ""
        except SinConexion:
            self.error = "No hay conexión. Esto necesita internet."
        except ServidorDijoQueNo as fallo:
            self.error = (
                "Hace falta entrar con tu cuenta." if "cuenta" in str(fallo)
                else "WhatsApp todavía no está activado en el servidor."
            )
        self._repintar()

    def _repintar(self) -> None:
        self._hueco.content = self._dibujo()
        try:
            self._hueco.update()
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------ el dibujo

    def _dibujo(self) -> ft.Control:
        paleta = self.paleta
        partes: list[ft.Control] = [componentes.cabecera_tarjeta(
            paleta, "WhatsApp", "apuntá y preguntá escribiéndole a Focus1%"
        )]
        if self.estado == "sin_activar":
            partes.append(componentes.aviso(paleta, [SIN_ACTIVAR]))
        elif self.error:
            partes.append(componentes.aviso_error(paleta, [self.error]))
        elif self.estado == "cargando":
            partes.append(ft.Text("Mirando…", size=13, color=paleta.muted))
        elif self.estado == "vinculado":
            partes += [
                ft.Text("✓ Tu WhatsApp está vinculado.", size=13, color=paleta.ink),
                componentes.boton(
                    paleta, "Desvincular", icono=ft.Icons.LINK_OFF,
                    al_pulsar=lambda _: self.pagina.run_task(self._desvincular),
                ),
            ]
        elif self.estado == "codigo":
            partes += [
                ft.Text("Mandá este mensaje desde tu WhatsApp (vence en 10 minutos):",
                        size=13, color=paleta.ink_soft),
                ft.Text(f"FOCUS {self.codigo}", size=22, weight=ft.FontWeight.W_600,
                        color=paleta.acento, selectable=True),
                componentes.boton(
                    paleta, "Abrir WhatsApp", icono=ft.Icons.OPEN_IN_NEW, principal=True,
                    al_pulsar=lambda _: self.pagina.launch_url(whatsapp.enlace(self.codigo)),
                ),
                componentes.boton(
                    paleta, "Ya lo mandé", icono=ft.Icons.CHECK,
                    al_pulsar=lambda _: self.pagina.run_task(self._mirar),
                ),
            ]
        else:
            partes += [
                ft.Text(
                    f"Agregá a {NOMBRE_DEL_CONTACTO} en WhatsApp y escribile como a "
                    "cualquier contacto: apunta gastos, comidas y hábitos, y te dice "
                    "cómo vas. Solo te responde a vos.",
                    size=13, color=paleta.ink_soft,
                ),
                componentes.boton(
                    paleta, f"Agregar a {NOMBRE_DEL_CONTACTO}", icono=ft.Icons.PERSON_ADD,
                    principal=True, al_pulsar=lambda _: self.pagina.run_task(self._vincular),
                ),
            ]
        return componentes.tarjeta(paleta, ft.Column(partes, spacing=12))
