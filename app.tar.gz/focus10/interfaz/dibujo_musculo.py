"""Una silueta con el músculo que trabaja cada ejercicio, pintado.

LO PIDIÓ EL USUARIO ASÍ: "haz imágenes para cada ejercicio, pero muy básicas, y
con un color de la parte que se está esforzando; ejemplo: press pecho = pecho".

SE DIBUJA A MANO SOBRE UN LIENZO Y NO SON IMÁGENES. Doscientos ochenta y cinco
dibujos serían doscientos ochenta y cinco archivos que pesan, que hay que
mantener, y de los que habría que responder de dónde salen. Aquí no hay archivos:
hay diez recetas —una por grupo— y una silueta hecha de unas cuantas piezas.
Pesa cero, se ve igual en el móvil, y cambia de color con el tema.

SOLO SE PINTA EL GRUPO PRINCIPAL, y lo eligió el usuario: "se muestra el grupo
muscular que más trabaja; el resto es comentario, tipo peso muerto trabaja
espalda baja y pierna: aparece pintada la pierna, pero en información dice que
también trabaja la espalda baja". Los secundarios van en el texto de ayuda, no en
el dibujo.

SE VE DE FRENTE O DE ESPALDAS SEGÚN EL GRUPO, y eso hizo falta: sin distinguirlo,
el press de banca y el remo salían con EXACTAMENTE el mismo dibujo —los dos
pintan el torso de arriba—, y lo mismo el curl y el press francés. Un dibujo que
no distingue el pecho de la espalda no sirve para lo que se pidió.

LA MARCA DE "DE ESPALDAS" ES LA COLUMNA: una raya fina por el centro del torso.
Es lo que se reconoce sin explicación y no obliga a dibujar una cara por delante,
que a este tamaño sería una mancha.
"""

from __future__ import annotations

import flet as ft
import flet.canvas as cv

from ..dominio.ejercicio import Grupo
from ..dominio.zona_musculo import COMO_SE_LEE
from .estilo import Paleta, con_opacidad

ANCHO = 44
ALTO = 68
"""El lienzo en el que están pensadas las piezas de abajo.

Se dibuja a esta escala y luego se encoge al tamaño que pida quien lo use, así
que las medidas de aquí no son píxeles de pantalla: son proporciones.
"""

# LAS PIEZAS DEL CUERPO, cada una (x, y, ancho, alto) dentro del lienzo.
#
# SON RECTÁNGULOS REDONDEADOS Y NO UN DIBUJO. A este tamaño —cuarenta puntos de
# alto en una fila de la rutina— un contorno detallado se convierte en una
# mancha; unas cuantas piezas separadas se leen mejor.
CABEZA = (17.0, 1.0, 10.0, 11.0)
CUELLO = (20.0, 11.0, 4.0, 4.0)
TORSO_ALTO = (13.0, 14.0, 18.0, 12.0)
TORSO_BAJO = (14.0, 26.0, 16.0, 10.0)
HOMBRO_IZQUIERDO = (5.0, 14.0, 8.0, 8.0)
HOMBRO_DERECHO = (31.0, 14.0, 8.0, 8.0)
BRAZO_IZQUIERDO = (6.0, 21.0, 6.0, 12.0)
BRAZO_DERECHO = (32.0, 21.0, 6.0, 12.0)
ANTEBRAZO_IZQUIERDO = (6.0, 33.0, 6.0, 11.0)
ANTEBRAZO_DERECHO = (32.0, 33.0, 6.0, 11.0)
CADERA = (14.0, 36.0, 16.0, 6.0)
MUSLO_IZQUIERDO = (14.0, 42.0, 7.0, 14.0)
MUSLO_DERECHO = (23.0, 42.0, 7.0, 14.0)
GEMELO_IZQUIERDO = (15.0, 56.0, 6.0, 11.0)
GEMELO_DERECHO = (23.0, 56.0, 6.0, 11.0)

COLUMNA = (21.0, 15.0, 2.0, 21.0)
"""La raya del centro de la espalda. Solo se dibuja en los grupos que se ven por
detrás, y es lo único que diferencia esa vista de la de frente."""

CUERPO = (
    CABEZA,
    CUELLO,
    TORSO_ALTO,
    TORSO_BAJO,
    HOMBRO_IZQUIERDO,
    HOMBRO_DERECHO,
    BRAZO_IZQUIERDO,
    BRAZO_DERECHO,
    ANTEBRAZO_IZQUIERDO,
    ANTEBRAZO_DERECHO,
    CADERA,
    MUSLO_IZQUIERDO,
    MUSLO_DERECHO,
    GEMELO_IZQUIERDO,
    GEMELO_DERECHO,
)

# LAS ZONAS DE DENTRO DE UN MÚSCULO, que es lo que pidió el usuario: "press
# inclinado trabaja pecho sí, pero trabaja más pecho superior; ponlo de un color
# parecido pero otro tono".
#
# SON TROZOS DE LAS PIEZAS DE ARRIBA, no piezas nuevas: el pecho superior es la
# mitad de arriba del torso alto. Por eso las medidas se solapan con las del
# cuerpo a propósito, y se pintan encima.
PECHO_SUPERIOR = (13.0, 14.0, 18.0, 5.5)
PECHO_INFERIOR = (13.0, 20.5, 18.0, 5.5)
ESPALDA_ALTA = (13.0, 14.0, 18.0, 5.0)
DORSAL = (13.0, 19.0, 18.0, 7.0)
LUMBAR = (14.0, 30.0, 16.0, 6.0)
ABDOMEN = (14.0, 26.0, 16.0, 6.0)
OBLICUO_IZQUIERDO = (14.0, 26.0, 4.0, 10.0)
OBLICUO_DERECHO = (26.0, 26.0, 4.0, 10.0)
HOMBRO_LATERAL_IZQUIERDO = (5.0, 14.0, 4.0, 8.0)
HOMBRO_LATERAL_DERECHO = (35.0, 14.0, 4.0, 8.0)
HOMBRO_INTERIOR_IZQUIERDO = (9.0, 14.0, 4.0, 8.0)
HOMBRO_INTERIOR_DERECHO = (31.0, 14.0, 4.0, 8.0)

ZONAS: dict[str, tuple[tuple[float, float, float, float], ...]] = {
    "pecho superior": (PECHO_SUPERIOR,),
    "pecho inferior": (PECHO_INFERIOR,),
    "espalda alta": (ESPALDA_ALTA,),
    "dorsal": (DORSAL,),
    "lumbar": (LUMBAR,),
    "abdomen": (ABDOMEN,),
    "oblicuos": (OBLICUO_IZQUIERDO, OBLICUO_DERECHO),
    "cuadriceps": (MUSLO_IZQUIERDO, MUSLO_DERECHO),
    "isquiotibiales": (MUSLO_IZQUIERDO, MUSLO_DERECHO),
    "gluteo": (CADERA,),
    "gemelo": (GEMELO_IZQUIERDO, GEMELO_DERECHO),
    "hombro lateral": (HOMBRO_LATERAL_IZQUIERDO, HOMBRO_LATERAL_DERECHO),
    "hombro anterior": (HOMBRO_INTERIOR_IZQUIERDO, HOMBRO_INTERIOR_DERECHO),
    "hombro posterior": (HOMBRO_INTERIOR_IZQUIERDO, HOMBRO_INTERIOR_DERECHO),
}

ZONAS_DE_ESPALDAS = frozenset(
    {"isquiotibiales", "gluteo", "hombro posterior", "dorsal", "espalda alta", "lumbar"}
)
"""Zonas que SE VEN POR DETRÁS aunque su grupo se vea de frente.

HACEN FALTA porque si no, el curl femoral y la extensión de cuádriceps pintarían
exactamente el mismo muslo —los dos son "pierna"— y el dibujo diría que son el
mismo ejercicio. La raya de la columna los separa igual que separa el pecho de
la espalda.
"""

DE_ESPALDAS = frozenset({Grupo.ESPALDA, Grupo.TRICEPS})
"""Los grupos que se ven por detrás.

SON JUSTO LOS QUE CHOCABAN: la espalda pinta el mismo torso que el pecho, y el
tríceps el mismo brazo que el bíceps. Los demás no necesitan la marca porque no
se confunden con nada.
"""

# QUÉ SE PINTA DE CADA GRUPO.
#
# CARDIO Y MOVILIDAD SE PINTAN ENTEROS a propósito, y no es pereza: no son un
# músculo, son el cuerpo entero haciendo algo. Pintarles un trozo cualquiera
# sería decir una cosa que no es.
PARTES: dict[Grupo, tuple[tuple[float, float, float, float], ...]] = {
    Grupo.PECHO: (TORSO_ALTO,),
    Grupo.ESPALDA: (TORSO_ALTO,),
    Grupo.HOMBRO: (HOMBRO_IZQUIERDO, HOMBRO_DERECHO),
    Grupo.BICEPS: (BRAZO_IZQUIERDO, BRAZO_DERECHO),
    Grupo.TRICEPS: (BRAZO_IZQUIERDO, BRAZO_DERECHO),
    Grupo.ANTEBRAZO: (ANTEBRAZO_IZQUIERDO, ANTEBRAZO_DERECHO),
    Grupo.CORE: (TORSO_BAJO,),
    Grupo.PIERNA: (
        MUSLO_IZQUIERDO,
        MUSLO_DERECHO,
        GEMELO_IZQUIERDO,
        GEMELO_DERECHO,
    ),
    Grupo.CARDIO: CUERPO,
    Grupo.MOVILIDAD: CUERPO,
}


ALTO_EN_FILA = 34
"""Lo que mide el dibujo en una fila de la rutina.

Ni tan grande que empuje el nombre del ejercicio contra el borde en un móvil, ni
tan pequeño que la parte pintada deje de distinguirse.
"""

ANCHO_EN_FILA = ALTO_EN_FILA * ANCHO / ALTO


def partes_de(grupo: Grupo) -> tuple[tuple[float, float, float, float], ...]:
    """Las piezas que se pintan de ese grupo.

    FALLA SI FALTA UNO, y esa es toda la gracia: el día que se añada el grupo
    número once, esto se para en seco en vez de dibujar un cuerpo apagado que
    nadie relacionaría con un grupo sin receta.
    """
    if grupo not in PARTES:
        raise KeyError(f"no hay dibujo para el grupo «{grupo.value}»")
    return PARTES[grupo]


def piezas_de_zona(zona: str | None) -> tuple[tuple[float, float, float, float], ...]:
    """Los trozos que se pintan a tono pleno, o ninguno si no hay zona.

    UNA ZONA QUE NO SE CONOCE NO SE DIBUJA, y no revienta: el que la adivina por
    el nombre puede devolver algo que aquí no esté, y quedarse sin marcar es
    mejor que dejar la pantalla en blanco.
    """
    if zona is None:
        return ()
    return ZONAS.get(zona, ())


def texto_de(grupo: Grupo, secundarios=(), zona: str | None = None) -> str:
    """Lo que se lee al pasar el ratón: el grupo, la zona, y los otros si los hay.

    LA ZONA SE DICE CON PALABRAS y no solo con el color, porque el color se
    adivina del nombre del ejercicio: si alguna vez se equivoca, se tiene que
    poder ver que se equivoca.
    """
    principal = grupo.value.capitalize()
    detalle = COMO_SE_LEE.get(zona or "")
    if detalle:
        principal = f"{principal}, {detalle}"
    otros = sorted(uno.value for uno in secundarios)
    if not otros:
        return principal
    return f"{principal}. También trabaja: {', '.join(otros)}."


def silueta(
    paleta: Paleta,
    grupo: Grupo,
    *,
    secundarios=(),
    zona: str | None = None,
    alto: int = 40,
) -> ft.Control:
    """El dibujo listo para meter en una fila.

    EL CUERPO EN GRIS Y LA PARTE EN COLOR: sin el cuerpo alrededor, unas piezas
    sueltas no se leen como un hombro; y sin el color, no habría dibujo que
    valiera para nada.
    """
    encendidas = partes_de(grupo)
    apagado = con_opacidad(paleta.muted, 0.30)

    # LA ESCALA SE APLICA A MANO. El lienzo de Flet dibuja en puntos de pantalla
    # de verdad: no encoge lo que le pintas dentro para que quepa. Sin esta
    # cuenta, pedir un dibujo de 40 puntos recortaba un cuerpo de 68 y salían
    # media cabeza y un hombro.
    escala = alto / ALTO

    def _pieza(pieza, color: str) -> cv.Shape:
        x, y, ancho, largo = pieza
        return cv.Rect(
            x * escala,
            y * escala,
            ancho * escala,
            largo * escala,
            border_radius=3 * escala,
            paint=ft.Paint(color=color),
        )

    # TRES INTENSIDADES DEL MISMO COLOR, que es lo que pidió el usuario: "un
    # color parecido pero otro tono". El cuerpo casi apagado, el músculo a medio
    # tono y la parte que más trabaja a tono pleno. Sin un color nuevo: uno más
    # habría que revisarlo en el tema oscuro y en los cinco estilos.
    de_zona = piezas_de_zona(zona)
    tono_musculo = paleta.acento if not de_zona else con_opacidad(paleta.acento, 0.45)

    formas: list[cv.Shape] = [
        _pieza(pieza, apagado) for pieza in CUERPO if pieza not in encendidas
    ]
    formas += [_pieza(pieza, tono_musculo) for pieza in encendidas]
    formas += [_pieza(pieza, paleta.acento) for pieza in de_zona]
    if grupo in DE_ESPALDAS or zona in ZONAS_DE_ESPALDAS:
        # LA COLUMNA VA LA ÚLTIMA para que se vea encima del torso pintado; si
        # fuera antes, el relleno del grupo la taparía y no marcaría nada.
        formas.append(_pieza(COLUMNA, con_opacidad(paleta.canvas, 0.85)))

    return ft.Container(
        content=cv.Canvas(formas, expand=True),
        width=alto * ANCHO / ALTO,
        height=alto,
        tooltip=texto_de(grupo, secundarios, zona),
    )
