"""La pantalla de las áreas que todavía no existen.

POR QUÉ ESTA PANTALLA EXISTE: se decidió enseñar desde el principio las seis
áreas de Focus10, aunque cinco estén vacías. Una entrada que al pulsarla no hace
nada, o que enseña una pantalla que aparenta funcionar, es justo lo que no se
quiere. Así que dice la verdad, con todas las letras: esto no está hecho.
"""

from __future__ import annotations

import flet as ft

from . import componentes
from .estilo import Paleta


def pantalla(
    paleta: Paleta, titulo: str, explicacion: str, nota: str | None = None
) -> ft.Control:
    """Una pantalla que dice honestamente que su área no está construida."""
    dentro: list[ft.Control] = [
        ft.Icon(ft.Icons.CONSTRUCTION_OUTLINED, size=34, color=paleta.muted),
        ft.Text(
            "Todavía no está hecho",
            size=15,
            weight=ft.FontWeight.W_600,
            color=paleta.ink,
        ),
        ft.Text(explicacion, size=13, color=paleta.muted),
    ]
    if nota is not None:
        dentro.append(ft.Container(height=4))
        dentro.append(componentes.aviso(paleta, [nota]))

    return ft.Column(
        [
            componentes.titulo_pagina(paleta, titulo),
            componentes.tarjeta(
                paleta,
                ft.Column(
                    dentro,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=10,
                    tight=True,
                ),
                relleno=40,
            ),
        ],
        spacing=16,
    )


# Cada sección que aún no existe, con su explicación. Ninguna finge tener nada:
# dicen "aquí irá", no enseñan botones muertos.
# VACIO A PROPOSITO: ya no queda ninguna seccion sin hacer. Este archivo se
# queda porque la proxima que se empiece tiene que poder decir "aqui ira" en vez
# de ensenar botones muertos, y porque app.py sigue teniendo su camino de
# respaldo: si alguien anade una seccion a SECCIONES y se olvida de escribirla,
# lo que sale es un cartel honesto y no una ventana en blanco.
SECCIONES_PENDIENTES: dict[str, tuple[str, str | None]] = {}
