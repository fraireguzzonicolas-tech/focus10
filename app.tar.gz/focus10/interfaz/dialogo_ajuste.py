"""El lápiz de las cifras de Finanzas: escribís el total y Focus ajusta.

LO PIDIÓ EL USUARIO (30 oct 2026): «tengo que poder modificar los gastos, el
ahorro con el lapicito; no me deja borrar lo que está y poner algo
completamente nuevo». Antes el lápiz preguntaba «lo que ya tenías antes de
Focus» y lo SUMABA a lo apuntado: la casilla salía vacía y escribir 300 sobre
un ahorro de 500 daba 800. Ahora la casilla trae la cifra que ves; la cambiás
y esa pasa a ser la cifra. Es lo mismo que ya hacía el lápiz del Balance
(«cuadrar con el banco»).

CÓMO, SIN TOCAR TUS MOVIMIENTOS: la diferencia entre lo que escribís y lo
apuntado se guarda como UN ajuste (un movimiento de tipo «ajuste de…»). Hay uno
solo por cosa —por mes, en ingresos y gastos—, y escribir otra cifra lo
sustituye. No sale en la lista de movimientos (decisión suya: la lista es para
dinero que se movió de verdad); por eso el lápiz está en la propia cifra.

NO SE PUEDE BAJAR DE LO APUNTADO: un ajuste solo suma. Si escribís menos de lo
que ya apuntaste, se dice cuánto es y qué hacer, en vez de inventar un
movimiento en negativo que nadie hizo.

VACÍO = SIN AJUSTE: la cifra vuelve a ser lo apuntado y nada más.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Callable

import flet as ft

from ..datos import ajustes as ajustes_guardados
from ..datos import repositorio_categorias, repositorio_dias, repositorio_movimientos
from ..datos.bd import conectado
from ..dominio.dinero import formatear, parsear_importe
from ..dominio.movimiento import NEUTRALES_EN_CAJA, Movimiento, Tipo
from . import componentes
from .estilo import Paleta


class MenosDeLoApuntado(ValueError):
    """La cifra escrita es menor que lo apuntado: un ajuste no puede restar."""


def ajuste_guardado(
    conexion, tipo: Tipo, desde: date | None = None, hasta: date | None = None
) -> Movimiento | None:
    """El ajuste que ya hubiera (en ese mes, si se dice), o None.

    SE BUSCA POR TIPO Y NO SE GUARDA SU id EN NINGÚN AJUSTE APARTE: el ajuste ES
    su movimiento, y tener además una referencia suelta sería una segunda
    versión de la verdad que puede quedarse vieja.
    """
    existentes = repositorio_movimientos.listar(conexion, tipo=tipo, desde=desde, hasta=hasta)
    return existentes[0] if existentes else None


def ajuste_para(deseado: int, total: int, ajuste_actual: int) -> int:
    """Cuánto tiene que valer el ajuste para que la cifra sea `deseado`.

    `total` es la cifra de ahora (con el ajuste dentro). Cero = sin ajuste.
    """
    apuntado = total - ajuste_actual
    if deseado < apuntado:
        raise MenosDeLoApuntado(apuntado)
    return deseado - apuntado


def abrir(
    pagina: ft.Page,
    tipo: Tipo,
    titulo: str,
    paleta: Paleta,
    al_guardar: Callable[[], None],
    *,
    total: int,
    desde: date | None = None,
    hasta: date | None = None,
) -> ft.AlertDialog | None:
    """Pregunta la cifra. Devuelve la ventanita para poder probarla.

    `total`: la cifra que se ve ahora. `desde`/`hasta`: el mes, en ingresos y
    gastos (su ajuste es de ese mes); sin ellos, de siempre (ahorro, inversión).
    """
    with conectado() as conexion:
        anterior = ajuste_guardado(conexion, tipo, desde, hasta)
        categorias = repositorio_categorias.listar(conexion, tipo=tipo)
        principal = ajustes_guardados.leer_moneda_principal(conexion)

    if not categorias:
        componentes.avisar(
            pagina,
            f"No hay ninguna categoría de «{tipo.value}» activa. "
            "Actívala o crea una antes de apuntar.",
        )
        return None

    campo = componentes.campo_texto(
        paleta,
        f"Total ({principal.codigo})",
        valor=formatear(total, principal, con_simbolo=False) if total else "",
        ancho=300,
    )
    aviso = ft.Text("", size=12, color=paleta.negativo, visible=False)

    def decir(texto: str) -> None:
        aviso.value = texto
        aviso.visible = True
        pagina.update()

    def guardar(_):
        escrito = (campo.value or "").strip()
        deseado = parsear_importe(escrito, principal) if escrito else None
        if escrito and (deseado is None or deseado < 0):
            decir("No entiendo ese importe. Ejemplo: 3.000 o 2500,50")
            return
        try:
            # VACÍO = SIN AJUSTE (no «cero euros», que estaría por debajo de lo apuntado).
            nuevo = 0 if not escrito else ajuste_para(deseado, total, anterior.importe if anterior else 0)
        except MenosDeLoApuntado as fallo:
            apuntado = formatear(fallo.args[0], principal)
            decir(
                f"No puede ser menos de {apuntado}: es lo que ya apuntaste. "
                "Para bajarlo, borrá o cambiá algún movimiento de la lista."
            )
            return

        with conectado() as conexion:
            # SE SUSTITUYE EL ANTERIOR, no se suma otro: es un número, no una
            # lista. Se borra primero y se escribe después, dentro de la misma
            # conexión, para no quedarse con los dos ni con ninguno.
            viejo = ajuste_guardado(conexion, tipo, desde, hasta)
            if viejo is not None:
                repositorio_movimientos.borrar(conexion, viejo.id)
            if nuevo:
                hoy = repositorio_dias.jornada_abierta(conexion)
                # EN SU MES: si estás mirando otro mes, el ajuste es de ese.
                if desde is not None and hasta is not None and not desde <= hoy <= hasta:
                    hoy = hasta
                repositorio_movimientos.guardar(
                    conexion,
                    Movimiento.nuevo(
                        tipo=tipo,
                        importe=nuevo,
                        categoria_id=categorias[0].id,
                        momento=datetime.now(),
                        jornada=hoy,
                        moneda=principal,
                        principal=principal,
                        descripcion=titulo,
                    ),
                )
        pagina.pop_dialog()
        al_guardar()

    balance = (
        "El balance no se mueve." if tipo in NEUTRALES_EN_CAJA
        else "Cuenta en el balance del mes, como lo que apuntás."
    )
    ventanita = componentes.dialogo(
        paleta,
        titulo,
        ft.Column(
            [
                ft.Text(
                    "Escribí el total que querés ver. Focus guarda la diferencia "
                    f"como un ajuste: tus movimientos no se tocan. {balance}",
                    size=12,
                    color=paleta.muted,
                ),
                campo,
                aviso,
            ],
            spacing=12,
            tight=True,
            width=320,
        ),
        pagina=pagina,
        al_aceptar=guardar,
    )
    pagina.show_dialog(ventanita)
    return ventanita
