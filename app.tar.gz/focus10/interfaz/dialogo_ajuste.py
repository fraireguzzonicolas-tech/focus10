"""Poner lo que YA tenías ahorrado o invertido, sin tocar el balance.

LO PIDIÓ EL USUARIO: "tengo plata ahorrada que quiero poner, pero si la pongo se
me pone en negativo". Y tenía razón: apuntar 3.000 € como ahorro normal es decir
que este mes han salido 3.000 € de tu cuenta, y el balance —lo que te queda para
gastar— se hunde. Ese dinero no ha salido de ningún sitio: ya estaba ahorrado.

ES UN NÚMERO, NO UNA LISTA. Aquí no se van acumulando apuntes: hay UN ajuste por
cada cosa, y escribir otro sustituye al anterior. Es lo que eligió el usuario
—"corregirlo editando ese mismo apunte"— y es lo que hace que la pregunta que
contesta sea siempre la misma: "¿cuánto tenías ya?".

NO SALE EN LA LISTA DE MOVIMIENTOS, también decisión suya: la lista es para
dinero que se ha movido de verdad. Por eso el lápiz está en la propia cifra; si
no, un ajuste mal puesto sería invisible y no habría dónde ir a corregirlo.

VACÍO BORRA EL AJUSTE. Es la forma de decir "no tenía nada de antes" sin dejar
un cero que parece un dato.
"""

from __future__ import annotations

from datetime import datetime
from typing import Callable

import flet as ft

from ..datos import ajustes as ajustes_guardados
from ..datos import repositorio_categorias, repositorio_dias, repositorio_movimientos
from ..datos.bd import conectado
from ..dominio.dinero import formatear, parsear_importe
from ..dominio.movimiento import Movimiento, Tipo
from . import componentes
from .estilo import Paleta


def ajuste_guardado(conexion, tipo: Tipo) -> Movimiento | None:
    """El ajuste que ya hubiera, o None.

    SE BUSCA POR TIPO Y NO SE GUARDA SU id EN NINGÚN AJUSTE APARTE: el ajuste ES
    su movimiento, y tener además una referencia suelta sería una segunda
    versión de la verdad que puede quedarse vieja.
    """
    existentes = repositorio_movimientos.listar(conexion, tipo=tipo)
    return existentes[0] if existentes else None


def abrir(
    pagina: ft.Page,
    tipo: Tipo,
    titulo: str,
    paleta: Paleta,
    al_guardar: Callable[[], None],
) -> ft.AlertDialog:
    """Pregunta la cifra. Devuelve la ventanita para poder probarla.

    EL TITULO VIENE DE FUERA porque cada lápiz pregunta otra cosa: "lo que ya
    tenías en ahorro", "ingresos que no apuntaste uno a uno". Antes se armaba
    aquí a partir del sitio donde se guarda el dinero, y en cuanto hubo lápices
    que no cuelgan de ningún sitio dejó de poder armarse.
    """
    with conectado() as conexion:
        anterior = ajuste_guardado(conexion, tipo)
        categorias = repositorio_categorias.listar(conexion, tipo=tipo)
        principal = ajustes_guardados.leer_moneda_principal(conexion)

    if not categorias:
        componentes.avisar(
            pagina,
            f"No hay ninguna categoría de «{tipo.value}» activa. "
            "Actívala o crea una antes de apuntar.",
        )
        return None

    campo = componentes.campo_texto(
        paleta,
        f"Importe ({principal.codigo})",
        valor=(
            formatear(anterior.importe, anterior.moneda, con_simbolo=False)
            if anterior
            else ""
        ),
        ancho=300,
    )
    aviso = ft.Text("", size=12, color=paleta.negativo, visible=False)

    def guardar(_):
        escrito = (campo.value or "").strip()
        with conectado() as conexion:
            viejo = ajuste_guardado(conexion, tipo)

            if not escrito:
                # VACÍO BORRA: es como se dice "no tenía nada de antes".
                if viejo is not None:
                    repositorio_movimientos.borrar(conexion, viejo.id)
                pagina.pop_dialog()
                al_guardar()
                return

            importe = parsear_importe(escrito, principal)
            if importe is None or importe <= 0:
                aviso.value = "No entiendo ese importe. Ejemplo: 3.000 o 2500,50"
                aviso.visible = True
                pagina.update()
                return

            # SE SUSTITUYE EL ANTERIOR, no se suma otro: es un número, no una
            # lista. Se borra primero y se escribe después, dentro de la misma
            # conexión, para no quedarse con los dos ni con ninguno.
            if viejo is not None:
                repositorio_movimientos.borrar(conexion, viejo.id)
            repositorio_movimientos.guardar(
                conexion,
                Movimiento.nuevo(
                    tipo=tipo,
                    importe=importe,
                    categoria_id=categorias[0].id,
                    momento=datetime.now(),
                    jornada=repositorio_dias.jornada_abierta(conexion),
                    moneda=principal,
                    principal=principal,
                    descripcion=titulo,
                ),
            )
        pagina.pop_dialog()
        al_guardar()

    ventanita = componentes.dialogo(
        paleta,
        titulo,
        ft.Column(
            [
                ft.Text(
                    "Esto NO cuenta como dinero gastado ni ahorrado este mes: "
                    "solo pone al día la cifra. El balance no se mueve.",
                    size=12,
                    color=paleta.muted,
                ),
                campo,
                aviso,
            ],
            spacing=12,
            tight=True,
            width=320,
        ),
        pagina=pagina,
        al_aceptar=guardar,
    )
    pagina.show_dialog(ventanita)
    return ventanita
