"""El cartel de la semana: cómo te fue, qué hiciste bien, y la recompensa.

LO PIDIÓ EL USUARIO ASÍ: "el domingo te tiene que aparecer un cartel diciendo
esta semana tuviste tal nota; si es 70, 80, 90, 100 hay recompensa, si es menor
no hay. Hiciste muy bien francés, pero gimnasio no hiciste nada: tenés que
mejorar ahí. Como que te da una especie de feedback todos los domingos".

ANTES SOLO SALÍA CON PREMIO Y SIN COMENTARIO, y por eso "no andaba": una semana
por debajo del 70 % no enseñaba nada, ni el porcentaje ni por qué. Ahora sale
siempre, una vez por semana, con o sin premio.

CUÁNDO: el domingo desde las 18:00, con la semana que está terminando. Si ese
domingo no abriste la aplicación, sale la próxima vez que la abras, con la
semana que ya cerró. Las dos cosas las eligió él.

EL COMENTARIO SALE DE TUS NÚMEROS, no de frases hechas: el hábito que mejor
llevaste y el que peor, con su porcentaje. Nada de IA ni de consejos inventados.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Callable

import flet as ft

from ..datos import repositorio_dias, repositorio_habitos, repositorio_recompensas
from ..datos.bd import conectado
from ..dominio.rachas import cumplimiento_de_varios
from ..dominio.recompensa import (
    MINIMO_PARA_PREMIO,
    Balance,
    Recompensa,
    lo_mejor_y_lo_peor,
    mensaje_de,
    nivel_de,
    porcentaje_de,
    semana_a_revisar,
)
from . import componentes, estilo
from .estilo import Paleta


@dataclass(frozen=True)
class Pendiente:
    """Una semana cerrada cuyo cartel todavía no se enseñó."""

    domingo: date
    porcentaje: int
    nivel: int | None
    """None si no llegó al 70 %: hay cartel, pero no hay recompensa."""

    recompensas: tuple[Recompensa, ...]
    mejor: Balance | None
    peor: Balance | None


def pendiente(conexion, ahora: datetime | None = None) -> Pendiente | None:
    """El cartel que toca enseñar, o None si no toca ninguno.

    None SOLO EN TRES CASOS: ese cartel ya se vio, no tienes hábitos, o esa
    semana no tocaba ninguno (sin nada programado no hay porcentaje que dar, y
    un 0 % sería mentira).
    """
    ahora = ahora or datetime.now()
    hoy = repositorio_dias.jornada_abierta(conexion)
    lunes, domingo = semana_a_revisar(hoy, ahora.hour)
    if repositorio_recompensas.cartel_visto(conexion, domingo):
        return None
    if repositorio_recompensas.semana_resuelta(conexion, domingo):
        return None

    habitos = repositorio_habitos.listar(conexion)
    if not habitos:
        return None

    cantidades = repositorio_habitos.cantidades_de_todos(conexion, lunes, domingo)
    dias = [lunes + timedelta(days=cual) for cual in range(7)]
    cuanto = porcentaje_de(cumplimiento_de_varios(habitos, cantidades, dias))
    if cuanto is None:
        return None

    balances = []
    for uno in habitos:
        suyo = porcentaje_de(cumplimiento_de_varios([uno], cantidades, dias))
        if suyo is not None:
            balances.append(Balance(uno.nombre, suyo))
    mejor, peor = lo_mejor_y_lo_peor(balances)

    return Pendiente(
        domingo=domingo,
        porcentaje=cuanto,
        nivel=nivel_de(cuanto),
        recompensas=tuple(repositorio_recompensas.listar(conexion)),
        mejor=mejor,
        peor=peor,
    )


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    premio: Pendiente,
    al_cerrar: Callable[[], None] | None = None,
) -> ft.AlertDialog:
    """Enseña el cartel. Devuelve la ventanita para poder probarla."""

    def cerrar(elegida: str) -> None:
        with conectado() as conexion:
            # SE MARCA VISTO SIEMPRE, se elija algo o no: un cartel que vuelve a
            # salir mañana deja de ser un resumen y pasa a ser un reproche.
            repositorio_recompensas.marcar_cartel_visto(conexion, premio.domingo)
            if premio.nivel is not None:
                repositorio_recompensas.resolver(
                    conexion,
                    domingo=premio.domingo,
                    porcentaje=premio.porcentaje,
                    nivel=premio.nivel,
                    elegida=elegida,
                    ahora=datetime.now(),
                )
        pagina.pop_dialog()
        if elegida:
            componentes.avisar(pagina, "¡Recompensa elegida! Disfrútala, te la has ganado.")
        if al_cerrar is not None:
            al_cerrar()

    if premio.nivel is not None:
        titulo, frase = mensaje_de(premio.nivel)
        icono, color = ft.Icons.EMOJI_EVENTS_OUTLINED, paleta.positivo
    else:
        titulo = f"Esta semana: {premio.porcentaje} %"
        frase = (
            f"Esta vez no hay recompensa: hace falta llegar al "
            f"{MINIMO_PARA_PREMIO} %."
        )
        icono, color = ft.Icons.INSIGHTS_OUTLINED, paleta.muted

    piezas: list[ft.Control] = [
        ft.Text(
            f"Completaste el {premio.porcentaje} % de tus hábitos.",
            size=estilo.TEXTO,
            color=paleta.ink_soft,
        ),
        ft.Text(frase, size=estilo.TEXTO_APOYO, color=paleta.muted),
        *_comentario(paleta, premio),
    ]

    acciones: list[ft.Control]
    if premio.nivel is not None and premio.recompensas:
        piezas.append(
            ft.Text(
                "Elige una:",
                size=estilo.ROTULO,
                weight=ft.FontWeight.W_600,
                color=paleta.muted,
            )
        )
        piezas += [_opcion(paleta, una, cerrar) for una in premio.recompensas]
        acciones = [ft.TextButton("Ahora no", on_click=lambda _: cerrar(""))]
    else:
        acciones = [ft.TextButton("Cerrar", on_click=lambda _: cerrar(""))]

    ventanita = ft.AlertDialog(
        modal=True,
        title=ft.Row(
            [
                ft.Icon(icono, size=20, color=color),
                ft.Text(titulo, size=16, weight=ft.FontWeight.W_600, color=paleta.ink,
                        expand=True),
            ],
            spacing=8,
        ),
        content=ft.Container(
            content=ft.Column(piezas, spacing=10, tight=True, scroll=ft.ScrollMode.AUTO),
            width=340,
        ),
        bgcolor=paleta.surface,
        actions=acciones,
        actions_alignment=ft.MainAxisAlignment.END,
    )
    pagina.show_dialog(ventanita)
    return ventanita


def _comentario(paleta: Paleta, premio: Pendiente) -> list[ft.Control]:
    """Lo que hiciste mejor y lo que tienes que mejorar, con sus números."""
    lineas: list[ft.Control] = []
    if premio.mejor is not None:
        lineas.append(
            _linea(paleta, ft.Icons.THUMB_UP_OUTLINED, paleta.positivo,
                   f"Lo mejor: {premio.mejor.nombre} ({premio.mejor.porcentaje} %)")
        )
    if premio.peor is not None:
        lineas.append(
            _linea(paleta, ft.Icons.TRENDING_UP, paleta.aviso,
                   f"A mejorar: {premio.peor.nombre} ({premio.peor.porcentaje} %)")
        )
    return lineas


def _linea(paleta: Paleta, icono: str, color: str, texto: str) -> ft.Control:
    return ft.Row(
        [
            ft.Icon(icono, size=16, color=color),
            ft.Text(texto, size=estilo.TEXTO_APOYO, color=paleta.ink, expand=True),
        ],
        spacing=8,
    )


def _opcion(
    paleta: Paleta, recompensa: Recompensa, al_elegir: Callable[[str], None]
) -> ft.Control:
    """Una de las recompensas. Un clic y listo, como se pidió."""
    return ft.Container(
        content=ft.Text(recompensa.nombre, size=estilo.TEXTO, color=paleta.ink),
        padding=ft.Padding.symmetric(horizontal=12, vertical=12),
        border=ft.Border.all(1, paleta.borde),
        border_radius=estilo.RADIO_CAMPO,
        on_click=lambda _, n=recompensa.nombre: al_elegir(n),
    )
