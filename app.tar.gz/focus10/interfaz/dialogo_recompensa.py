"""El aviso de la recompensa semanal, y quién decide si toca enseñarlo.

LO PIDIÓ EL USUARIO PEQUEÑO Y SECUNDARIO, y así está: una ventana que sale una
vez por semana, si llegaste al 70%, y que se cierra eligiendo una de tus cosas.

NO SE REINVENTA NADA DE LOS HÁBITOS. El porcentaje sale de `cumplimiento_de_varios`,
la misma pieza que pinta el calendario y las rachas, y la semana es la misma de
lunes a domingo que ya usa esa sección.

SI NO HAY RECOMPENSAS CONFIGURADAS NO SE ENSEÑA NADA. Felicitar a alguien y
ofrecerle una lista vacía es peor que no felicitarle.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Callable

import flet as ft

from ..datos import repositorio_dias, repositorio_habitos, repositorio_recompensas
from ..datos.bd import conectado
from ..dominio.rachas import cumplimiento_de_varios
from ..dominio.recompensa import (
    Recompensa,
    mensaje_de,
    nivel_de,
    porcentaje_de,
    semana_anterior,
)
from . import componentes, estilo
from .estilo import Paleta


@dataclass(frozen=True)
class Pendiente:
    """Una semana ganada y todavía sin resolver."""

    domingo: date
    porcentaje: int
    nivel: int
    recompensas: tuple[Recompensa, ...]


def pendiente(conexion) -> Pendiente | None:
    """La recompensa que toca enseñar, o None si no toca ninguna.

    None ES LA RESPUESTA HABITUAL: no llegaste al 70%, o ya se preguntó por esa
    semana, o no tienes recompensas puestas. Ninguna de las tres es un fallo.
    """
    recompensas = repositorio_recompensas.listar(conexion)
    if not recompensas:
        return None

    hoy = repositorio_dias.jornada_abierta(conexion)
    lunes, domingo = semana_anterior(hoy)
    if repositorio_recompensas.semana_resuelta(conexion, domingo):
        return None

    habitos = repositorio_habitos.listar(conexion)
    if not habitos:
        return None

    cantidades = repositorio_habitos.cantidades_de_todos(conexion, lunes, domingo)
    dias = [lunes + timedelta(days=cual) for cual in range(7)]
    cuanto = porcentaje_de(cumplimiento_de_varios(habitos, cantidades, dias))

    nivel = nivel_de(cuanto)
    if nivel is None:
        return None

    return Pendiente(
        domingo=domingo,
        porcentaje=cuanto,
        nivel=nivel,
        recompensas=tuple(recompensas),
    )


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    premio: Pendiente,
    al_cerrar: Callable[[], None] | None = None,
) -> ft.AlertDialog:
    """Felicita y deja elegir. Devuelve la ventanita para poder probarla."""
    titulo, frase = mensaje_de(premio.nivel)

    def resolver(elegida: str) -> None:
        with conectado() as conexion:
            repositorio_recompensas.resolver(
                conexion,
                domingo=premio.domingo,
                porcentaje=premio.porcentaje,
                nivel=premio.nivel,
                elegida=elegida,
                ahora=datetime.now(),
            )
        pagina.pop_dialog()
        if elegida:
            componentes.avisar(
                pagina, "🎉 ¡Recompensa elegida! Disfrútala, te la has ganado."
            )
        if al_cerrar is not None:
            al_cerrar()

    ventanita = ft.AlertDialog(
        modal=True,
        title=ft.Text(
            titulo, size=16, weight=ft.FontWeight.W_600, color=paleta.ink
        ),
        content=ft.Container(
            content=ft.Column(
                [
                    ft.Text(
                        f"Esta semana completaste el {premio.porcentaje}% "
                        "de tus hábitos.",
                        size=estilo.TEXTO,
                        color=paleta.ink_soft,
                    ),
                    ft.Text(frase, size=estilo.TEXTO_APOYO, color=paleta.muted),
                    ft.Text(
                        "Elige una:",
                        size=estilo.ROTULO,
                        weight=ft.FontWeight.W_600,
                        color=paleta.muted,
                    ),
                    *[
                        _opcion(paleta, una, resolver)
                        for una in premio.recompensas
                    ],
                ],
                spacing=10,
                tight=True,
                scroll=ft.ScrollMode.AUTO,
            ),
            width=340,
        ),
        bgcolor=paleta.surface,
        # CERRAR SIN ELEGIR TAMBIÉN RESUELVE LA SEMANA: si no, la ventana
        # volvería a salir mañana y pasado, y un premio que insiste deja de ser
        # un premio.
        actions=[ft.TextButton("Ahora no", on_click=lambda _: resolver(""))],
        actions_alignment=ft.MainAxisAlignment.END,
    )
    pagina.show_dialog(ventanita)
    return ventanita


def _opcion(
    paleta: Paleta, recompensa: Recompensa, al_elegir: Callable[[str], None]
) -> ft.Control:
    """Una de las recompensas. Un clic y listo, como se pidió."""
    return ft.Container(
        content=ft.Text(recompensa.nombre, size=estilo.TEXTO, color=paleta.ink),
        padding=ft.Padding.symmetric(horizontal=12, vertical=12),
        border=ft.Border.all(1, paleta.borde),
        border_radius=estilo.RADIO_CAMPO,
        on_click=lambda _, n=recompensa.nombre: al_elegir(n),
    )
