"""La ventanita de apuntar o corregir una tarea suelta.

POR QUÉ ES TAN CORTA: una tarea son un título y un día. Todo lo demás —repetir,
prioridades, etiquetas— o no se pidió o es un hábito disfrazado. Si apuntar algo
cuesta más que hacerlo, se deja de apuntar.
"""

from __future__ import annotations

from datetime import date, timedelta

import flet as ft

from ..datos import repositorio_tareas
from ..datos.bd import conectado
from ..dominio.tarea import LARGO_MAXIMO_TITULO, Tarea
from . import componentes
from .estilo import Paleta

UN_DIA = timedelta(days=1)


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    hoy: date,
    al_guardar,
    tarea: Tarea | None = None,
) -> None:
    pagina.show_dialog(_DialogoTarea(pagina, paleta, hoy, al_guardar, tarea).control)


class _DialogoTarea:
    def __init__(self, pagina, paleta, hoy, al_guardar, tarea) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.hoy = hoy
        self.al_guardar = al_guardar
        self.tarea = tarea
        self.dia = tarea.jornada if tarea else hoy

        self.titulo = componentes.campo_texto(
            paleta,
            "Qué hay que hacer",
            valor=tarea.titulo if tarea else "",
            pista="Llamar al banco",
            largo_maximo=LARGO_MAXIMO_TITULO,
            al_enviar=lambda _: self._guardar(),
        )
        self.nota = componentes.campo_texto(
            paleta,
            "Nota (opcional)",
            valor=tarea.nota if tarea else "",
        )
        self.error = ft.Text("", size=12, color=paleta.negativo, visible=False)
        self.etiqueta_dia = ft.Text("", size=13, color=paleta.ink)
        self._pintar_dia()

    @property
    def control(self) -> ft.AlertDialog:
        piezas: list[ft.Control] = [
            self.titulo,
            self.nota,
            ft.Container(height=4),
            ft.Text("Para qué día", size=12, color=self.paleta.muted),
            self._elegir_dia(),
            self.error,
        ]

        # Solo al corregir: borrar. Al apuntar una nueva no hay nada que borrar.
        if self.tarea is not None:
            piezas += [
                ft.Container(height=4),
                componentes.boton(
                    self.paleta,
                    "Borrar esta tarea",
                    icono=ft.Icons.DELETE_OUTLINE,
                    al_pulsar=lambda _: self._pedir_borrado(),
                ),
            ]

        return componentes.dialogo(
            self.paleta,
            "Corregir tarea" if self.tarea else "Nueva tarea",
            ft.Column(piezas, spacing=10, tight=True, width=340),
            pagina=self.pagina,
            al_aceptar=lambda _: self._guardar(),
        )

    # ----------------------------------------------------------------------

    def _elegir_dia(self) -> ft.Control:
        """Hoy, mañana o las flechas. Sin calendario: el 95 % de lo que se apunta
        es para hoy o para mañana, y abrir un calendario para eso es un estorbo."""
        return ft.Row(
            [
                componentes.boton(
                    self.paleta, "Hoy", al_pulsar=lambda _: self._poner(self.hoy)
                ),
                componentes.boton(
                    self.paleta,
                    "Mañana",
                    al_pulsar=lambda _: self._poner(self.hoy + UN_DIA),
                ),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.CHEVRON_LEFT,
                    ayuda="Un día antes",
                    al_pulsar=lambda _: self._poner(self.dia - UN_DIA),
                ),
                self.etiqueta_dia,
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.CHEVRON_RIGHT,
                    ayuda="Un día después",
                    al_pulsar=lambda _: self._poner(self.dia + UN_DIA),
                ),
            ],
            spacing=6,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _poner(self, dia: date) -> None:
        self.dia = dia
        self._pintar_dia()
        self.etiqueta_dia.update()

    def _pintar_dia(self) -> None:
        if self.dia == self.hoy:
            self.etiqueta_dia.value = "hoy"
        elif self.dia == self.hoy + UN_DIA:
            self.etiqueta_dia.value = "mañana"
        elif self.dia == self.hoy - UN_DIA:
            self.etiqueta_dia.value = "ayer"
        else:
            self.etiqueta_dia.value = f"{self.dia.day}/{self.dia.month}"

    # ----------------------------------------------------------------------

    def _guardar(self) -> None:
        try:
            tarea = Tarea(
                id=self.tarea.id if self.tarea else None,
                titulo=self.titulo.value or "",
                jornada=self.dia,
                hecha_en=self.tarea.hecha_en if self.tarea else None,
                nota=self.nota.value or "",
                orden=self.tarea.orden if self.tarea else 0,
            )
        except (ValueError, TypeError) as fallo:
            # El mensaje del dominio se enseña tal cual: ya está escrito para que
            # lo lea una persona, y traducirlo aquí sería tener el mismo texto
            # en dos sitios que se despistan.
            self.error.value = str(fallo)
            self.error.visible = True
            self.error.update()
            return

        with conectado() as conexion:
            if self.tarea:
                repositorio_tareas.actualizar(conexion, tarea)
            else:
                repositorio_tareas.crear(conexion, tarea)

        self.pagina.pop_dialog()
        self.al_guardar()

    def _pedir_borrado(self) -> None:
        # Se cierra la ventanita de edición antes de preguntar: dos diálogos
        # apilados dejan el de atrás sin poder tocarse y parece que se ha colgado.
        self.pagina.pop_dialog()
        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo="Borrar la tarea",
            texto=f"Se borra «{self.tarea.titulo}». No se puede deshacer.",
            al_aceptar=lambda _: self._borrar(),
        )

    def _borrar(self) -> None:
        with conectado() as conexion:
            repositorio_tareas.borrar(conexion, self.tarea.id)
        self.pagina.pop_dialog()
        self.al_guardar()
