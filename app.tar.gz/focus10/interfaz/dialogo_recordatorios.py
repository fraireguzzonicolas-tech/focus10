"""Lo que tienes pendiente, al tocar la campana.

LO PIDIÓ EL USUARIO: "si yo toco esa campanita se debe abrir un apartado que
muestre el recordatorio y botón de agregar recordatorio".

SALEN TODOS LOS PENDIENTES, SEAN DE CUANDO SEAN, que es lo mismo que cuenta la
campana. Si la campana dijera 3 y aquí salieran 2 —porque uno es de anteayer—,
el número de arriba dejaría de poder creerse, que es lo único que tiene que
hacer.

SE PUEDEN MARCAR DESDE AQUÍ. Abrir la lista de lo que falta y tener que ir a
otro sitio para tacharlo sería enseñar el problema y esconder la solución.

CADA DÍA SALE ESCRITO cuando la tarea no es de hoy ("del lunes"): un pendiente
de hace cinco días no es lo mismo que uno de esta mañana, y el color solo no lo
dice.
"""

from __future__ import annotations

from datetime import date
from typing import Callable

import flet as ft

from ..datos import repositorio_dias, repositorio_tareas
from ..datos.bd import conectado
from ..dominio.semana import DIAS
from . import componentes, dialogo_tarea, estilo
from .estilo import Paleta


def texto_del_dia(jornada: date, hoy: date) -> str:
    """"del lunes", o vacío si es de hoy.

    VACÍO PARA LO DE HOY a propósito: escribir "de hoy" en todas las líneas es
    ruido, y lo que hay que señalar es justo lo contrario, lo que se arrastra.
    """
    if jornada == hoy:
        return ""
    dias = (hoy - jornada).days
    if 0 < dias <= 6:
        return f"del {DIAS[jornada.weekday()]}"
    return f"del {jornada.day}/{jornada.month}"


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    al_cambiar: Callable[[], None],
) -> ft.AlertDialog:
    """Enseña los recordatorios. Devuelve la ventanita para poder probarla."""
    with conectado() as conexion:
        hoy = repositorio_dias.jornada_abierta(conexion)
        pendientes = sorted(
            repositorio_tareas.listar_pendientes(conexion),
            key=lambda una: (una.jornada, una.orden, una.id or 0),
        )

    lista = ft.Column(spacing=8, tight=True)

    def cerrar_y_avisar() -> None:
        pagina.pop_dialog()
        al_cambiar()

    def marcar(tarea) -> None:
        with conectado() as conexion:
            repositorio_tareas.marcar(conexion, tarea.id, hoy)
        # SE CIERRA AL TACHAR, y no se repinta la lista: el número de la campana
        # se calcula al montar la ventana, así que quedarse aquí dejaría la
        # campana diciendo una cosa y la lista otra.
        cerrar_y_avisar()

    def anadir(_) -> None:
        pagina.pop_dialog()
        dialogo_tarea.abrir(pagina, paleta, hoy, al_cambiar)

    if not pendientes:
        lista.controls.append(
            componentes.aviso_vacio(paleta, "No tienes nada pendiente.")
        )
    else:
        lista.controls += [_fila(paleta, una, hoy, marcar) for una in pendientes]

    ventanita = ft.AlertDialog(
        modal=True,
        title=ft.Text(
            "Recordatorios" if pendientes else "Nada pendiente",
            size=15,
            weight=ft.FontWeight.W_600,
            color=paleta.ink,
        ),
        content=ft.Container(
            content=ft.Column(
                [
                    lista,
                    componentes.boton(
                        paleta,
                        "Añadir recordatorio",
                        icono=ft.Icons.ADD,
                        principal=True,
                        al_pulsar=anadir,
                    ),
                ],
                spacing=16,
                tight=True,
                scroll=ft.ScrollMode.AUTO,
            ),
            width=340,
        ),
        bgcolor=paleta.surface,
        actions=[ft.TextButton("Cerrar", on_click=lambda _: pagina.pop_dialog())],
        actions_alignment=ft.MainAxisAlignment.END,
    )
    pagina.show_dialog(ventanita)
    return ventanita


def _fila(paleta: Paleta, tarea, hoy: date, al_marcar) -> ft.Control:
    """Un recordatorio, con su cuadrito para darlo por hecho."""
    de_cuando = texto_del_dia(tarea.jornada, hoy)

    texto: list[ft.Control] = [
        ft.Text(tarea.titulo, size=estilo.TEXTO, color=paleta.ink)
    ]
    if de_cuando:
        texto.append(
            ft.Text(de_cuando, size=estilo.ROTULO, color=paleta.aviso)
        )
    if tarea.nota:
        texto.append(
            ft.Text(tarea.nota, size=estilo.ROTULO, color=paleta.muted)
        )

    return ft.Row(
        [
            ft.Container(
                width=22,
                height=22,
                border=ft.Border.all(2, paleta.aviso),
                border_radius=6,
                tooltip=f"Dar «{tarea.titulo}» por hecha",
                on_click=lambda _, t=tarea: al_marcar(t),
            ),
            ft.Column(texto, spacing=0, tight=True, expand=True),
        ],
        spacing=10,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )
