"""Los colores y las medidas de Focus10.

POR QUÉ ESTÁN TODOS AQUÍ: si cada pantalla eligiera sus colores a mano, en tres
pantallas habría cinco grises distintos y nadie sabría cuál es el bueno. Aquí
está la lista completa, y las pantallas solo piden "el color del texto apagado".
Es también lo que ha permitido cambiar el aspecto de las nueve pantallas de una
vez, tocando solo este archivo y componentes.py.

DE DÓNDE SALE ESTA PALETA: del rediseño que aprobó el usuario. Se diseñó en
oklch —que reparte la claridad como la ve el ojo, no como la calcula la
pantalla— y se convirtió a hexadecimal aquí, porque es lo que entiende Flet. Por
eso los grises son CÁLIDOS y no azulados: comparten el mismo tono que el papel
del fondo, y eso es lo que hace que la pantalla se lea como una página y no como
un panel de control.

LAS TRES REGLAS DE COLOR QUE SOSTIENEN EL DISEÑO:

  1. El verde del acento manda. Los dos acentos —el verde y el barro— comparten
     claridad y croma, y solo cambian de tono: por eso nunca compiten.
  2. El verde y el rojo son SOLO para cifras y detalles pequeños, nunca para
     fondos grandes. Dos botones enormes de color pleno gritan y no dejan ver lo
     importante, que son los números.
  3. Separar por TONO y por ESPACIO antes que por línea. Un borde de un píxel en
     cada tarjeta se ve barato; una sombra muy suave y aire alrededor, no.

EL ACENTO NO SE PERSONALIZA por ahora, por decisión del usuario: la aplicación es
bonita porque está decidida, no porque se pueda tocar. Los otros cuatro estilos
del rediseño —Formal, Natural, Minimal, Personal— caben aquí como cuatro paletas
más el día que se quieran; nada de lo demás habría que tocarlo.

AQUÍ SOLO HAY COLORES Y MEDIDAS. Las piezas que los usan (tarjetas, botones,
campos) están en componentes.py.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import flet as ft


FUENTE = "Schibsted"
"""La de la interfaz. Todo lo que se lee de corrido, en todos los estilos."""

FUENTE_SUPLENTE = "Segoe UI"
"""Lo que se usa si las de arriba no cargan. Está en cualquier Windows."""


@dataclass(frozen=True)
class Paleta:
    """Un juego completo de colores. Hay dos: la clara y la oscura."""

    modo: ft.ThemeMode

    canvas: str
    """El fondo de la ventana, detrás de las tarjetas."""

    surface: str
    """El fondo de una tarjeta."""

    surface_2: str
    """Un escalón más marcado: botones secundarios, cabeceras de tabla."""

    surface_3: str
    borde: str
    borde_fuerte: str

    ink: str
    """El texto principal."""

    ink_soft: str
    muted: str
    """Texto de apoyo: etiquetas, ayudas, lo que no hay que leer."""

    acento: str
    acento_suave: str
    acento_ink: str

    positivo: str
    negativo: str
    aviso: str

    titular: str = "Instrument"
    """La tipografía de los titulares y las cifras de ESTE estilo.

    VA EN LA PALETA Y NO EN UNA CONSTANTE DEL MÓDULO, y ese es todo el truco que
    permite cambiar de estilo: cada pantalla ya recibe una paleta para saber de
    qué color pintar, así que ahora también sabe con qué letra escribir. Sin
    esto, cambiar la tipografía habría obligado a que cada control consultara un
    ajuste por su cuenta.
    """

    fuente: str = FUENTE
    """La del texto normal. ES LA MISMA EN LOS CINCO ESTILOS a propósito.

    El texto de la interfaz se lee durante horas y su trabajo es no llamar la
    atención; lo que le da carácter a un estilo son los titulares y el color.
    Cambiar también la letra pequeña haría cinco aplicaciones distintas de leer
    en vez de una aplicación con cinco trajes.
    """


CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f9f7f3",
    surface="#ffffff",
    surface_2="#f3f0ea",
    surface_3="#eae7e2",
    borde="#e0deda",
    borde_fuerte="#c7c4be",
    ink="#221c16",
    ink_soft="#57514c",
    muted="#8a8580",
    acento="#367855",
    acento_suave="#dff0e5",
    acento_ink="#ffffff",
    positivo="#357950",
    negativo="#a85550",
    aviso="#9b6142",
)

OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#110e0a",
    surface="#1d1913",
    surface_2="#26221c",
    surface_3="#302c25",
    borde="#2f2b25",
    borde_fuerte="#49443d",
    ink="#efece7",
    ink_soft="#b4b1aa",
    muted="#7d7a74",
    acento="#6cb78d",
    acento_suave="#1a3124",
    acento_ink="#110e0a",
    positivo="#78c192",
    negativo="#df7f78",
    aviso="#dfa36d",
)

POR_NOMBRE = {"claro": CLARA, "oscuro": OSCURA}

# Los tres valores que puede tener el ajuste del tema, en el orden en que se
# enseñan en Configuración.
TEMAS = (
    ("sistema", "Seguir a Windows"),
    ("claro", "Claro"),
    ("oscuro", "Oscuro"),
)

# Los ocho colores de los hábitos. Las claves son las del dominio
# (dominio/habito.py), que guarda "azul" y no un color: así la paleta se puede
# cambiar sin tocar un solo dato guardado.
#
# LOS OCHO COMPARTEN CLARIDAD Y CROMA y solo cambian de tono. No es un detalle:
# con claridades distintas, un hábito parecería más importante que otro sin que
# nadie lo haya decidido. Y al ser tonos medios se leen igual sobre el fondo
# claro y sobre el oscuro.
COLORES_HABITO = {
    "azul": "#2e9dd3",
    "verde": "#53a768",
    "ambar": "#b58b22",
    "rosa": "#ca709d",
    "violeta": "#9e7fd3",
    "cian": "#00a8b0",
    "naranja": "#cc7c40",
    "rojo": "#d4716b",
}


def color_de_habito(nombre: str) -> str:
    """El color de un hábito por su nombre. Si no se conoce, el azul.

    No falla a propósito: un color raro guardado solo debe costar un hábito de
    otro color, nunca impedir que la pantalla se dibuje.
    """
    return COLORES_HABITO.get(nombre, COLORES_HABITO["azul"])


def con_opacidad(color: str, fraccion: float) -> str:
    """El mismo color, más o menos transparente. De 0 a 1.

    Está aquí y no en los componentes porque es una operación sobre colores, y
    los colores viven en este archivo. Se usa para rellenar el círculo de un
    hábito según lo que lleves hecho.
    """
    return ft.Colors.with_opacity(max(0.0, min(1.0, fraccion)), color)


# Blanco puro. No va dentro de la Paleta porque no cambia con el tema: es el
# texto que se pone ENCIMA de un color fuerte (el rojo de un boton de borrar),
# donde el color del tema no serviria.
BLANCO = "#ffffff"


# ---------------------------------------------------------------------------
# Tipografía
# ---------------------------------------------------------------------------

# Las fuentes viven DENTRO del proyecto y no se piden a internet. Dos razones:
# la aplicación funciona sin conexión (solo Inversiones sale fuera, y con
# permiso), y así PyInstaller las puede empaquetar en la última fase. Son de
# licencia abierta (SIL OFL), así que se pueden distribuir con el programa.
CARPETA_FUENTES = Path(__file__).resolve().parents[3] / "assets" / "fuentes"

ARCHIVOS_DE_FUENTE = {
    # La del texto, común a todos los estilos.
    FUENTE: CARPETA_FUENTES / "SchibstedGrotesk.ttf",
    # Y una titular por estilo. SE REGISTRAN TODAS AL ABRIR, no solo la del
    # estilo elegido: cambiar de estilo tiene que ser instantáneo, y bajar una
    # fuente a mitad de sesión sería un parpadeo raro. Entre las seis suman
    # menos de un megabyte.
    "Instrument": CARPETA_FUENTES / "InstrumentSerif-Regular.ttf",
    "Poppins": CARPETA_FUENTES / "Poppins.ttf",
    "Jost": CARPETA_FUENTES / "Jost.ttf",
    "Outfit": CARPETA_FUENTES / "Outfit.ttf",
    "BarlowCondensed": CARPETA_FUENTES / "BarlowCondensed.ttf",
}


def fuentes_disponibles() -> dict[str, str]:
    """Las fuentes que de verdad están en el disco, listas para registrarlas.

    Se comprueba que el archivo exista en vez de darlo por hecho: si alguien
    mueve la carpeta o el empaquetado se deja un archivo, la aplicación tiene
    que abrir igual con la fuente suplente, no quedarse en negro por una tilde
    tipográfica.
    """
    return {
        nombre: str(ruta)
        for nombre, ruta in ARCHIVOS_DE_FUENTE.items()
        if ruta.is_file()
    }


# La escala. Son los tamaños del rediseño, y son POCOS a propósito: con quince
# tamaños distintos no hay jerarquía, hay ruido.
TITULAR_GRANDE = 40
"""El nombre de la pantalla. En serif."""

TITULAR = 30
CIFRA_GRANDE = 44
"""Los números que son el motivo de abrir la pantalla. En serif."""

CIFRA = 26
TEXTO_TARJETA = 16
"""El título de una tarjeta."""

TEXTO = 14
TEXTO_APOYO = 12.5
ROTULO = 11
"""Los rótulos en mayúsculas pequeñas, con mucho espaciado entre letras."""

ESPACIADO_ROTULO = 1.1
"""El aire entre letras de un rótulo, en píxeles. Sin él, las mayúsculas
pequeñas se apelmazan y dejan de leerse."""


# ---------------------------------------------------------------------------
# Medidas
# ---------------------------------------------------------------------------

RADIO_TARJETA = 16
RADIO_BOTON = 999
"""Los botones son cápsulas. Es lo que más cambia el aire de la aplicación con
menos código, y separa de un vistazo lo que se pulsa de lo que se lee."""

RADIO_CAMPO = 10
RELLENO_TARJETA = 24
ALTO_BOTON = 38
_ancho_de_la_pantalla: float | None = None
"""Lo ancha que es la ventana ahora mismo, o None si aún no se sabe.

POR QUÉ UN DATO GLOBAL, que normalmente es mala idea: porque esto SÍ es global.
La aplicación tiene una ventana y una sola, y su ancho es el mismo para todo lo
que se dibuje dentro. La alternativa era pasar el ancho como parámetro por los
veinticinco archivos de interfaz hasta llegar a la tabla, y eso son veinticinco
sitios donde olvidarse de pasarlo.

LO PONE app.py EN CADA MONTAJE, que es el único sitio que habla con la ventana.

SI VALE None SE DIBUJA COMO EN UN ORDENADOR: al arrancar, Flet puede no haber
medido todavía, y dar por hecho "móvil" haría parpadear la aplicación de
escritorio en cada apertura.
"""


def fijar_ancho(ancho: float | None) -> None:
    """Lo llama app.py al montar la ventana. Nadie más debería."""
    global _ancho_de_la_pantalla
    _ancho_de_la_pantalla = ancho


def pantalla_estrecha() -> bool:
    """Si hay que dibujar como en un móvil."""
    return bool(_ancho_de_la_pantalla) and _ancho_de_la_pantalla < ANCHO_ESTRECHO


def ancho_de_grafico(maximo: int, *, margenes: int = 64) -> int:
    """Lo ancho que puede dibujarse un gráfico sin salirse de la pantalla.

    LOS GRÁFICOS DE ESTA APLICACIÓN SE DIBUJAN A MANO sobre un lienzo, y un
    lienzo necesita un ancho concreto: no puede "estirarse hasta lo que haya"
    como una caja normal, porque tiene que saber dónde cae cada punto.

    Así que se le da el mejor ancho posible: el que pidió, o lo que quepa si es
    menos. El suelo de 240 evita que en una ventana absurdamente estrecha el
    gráfico se quede en una raya.
    """
    if not _ancho_de_la_pantalla:
        return maximo
    return max(240, min(maximo, int(_ancho_de_la_pantalla) - margenes))


ANCHO_ESTRECHO = 600
"""Por debajo de este ancho, la aplicación se dibuja como en un móvil.

POR QUÉ 600 Y NO 375: 375 es lo que mide un móvil, pero el corte no debe estar
en el caso justo. Una tableta en vertical, o media ventana en un portátil, están
más cerca de un móvil que de un escritorio: ahí la barra lateral ya estorba más
de lo que ayuda. 600 es donde deja de compensar gastar 236 puntos en un menú.

NO ES UNA MEDIDA DE APARATO, es una medida de sitio disponible. La misma ventana
cruza este número al hacerla pequeña, y la aplicación se recoloca.
"""

ANCHO_LATERAL = 236
DENSIDAD = 26
"""La separación vertical entre bloques de una pantalla."""


def sombra_tarjeta(paleta: Paleta) -> ft.BoxShadow | None:
    """La sombra de una tarjeta. Muy suave, y ninguna en el tema oscuro.

    En oscuro no se pone: una sombra negra sobre un fondo casi negro no se ve, y
    lo que separa ahí es el escalón de tono entre el lienzo y la superficie. Es
    la misma decisión que en el rediseño.
    """
    if paleta.modo is ft.ThemeMode.DARK:
        return None
    return ft.BoxShadow(
        blur_radius=20,
        spread_radius=-4,
        color=ft.Colors.with_opacity(0.07, "#221c16"),
        offset=ft.Offset(0, 6),
    )


# ---------------------------------------------------------------------------
# Los cinco estilos
# ---------------------------------------------------------------------------
#
# DE DONDE SALEN: de cuatro referencias que dio el usuario, mas el que ya tenia.
# Cada uno es una paleta clara, una oscura y una tipografia de titulares. Lo
# demas —las medidas, las esquinas, las sombras— NO cambia entre estilos, y esa
# fue su decision: "colores y tipografia, sin tocar formas". Se agradece al
# mantenerlo, porque significa que un estilo nuevo son dos paletas y una linea.
#
# LAS TRES REGLAS QUE CUMPLEN LOS CINCO, y que hay tests para cada una:
#   1. El texto se lee sobre su fondo. Un estilo bonito e ilegible no vale.
#   2. El claro es claro y el oscuro es oscuro, en los cinco.
#   3. Ningun color se repite entre la version clara y la oscura del mismo
#      estilo; si se repitiera, esa parte no cambiaria al cambiar de tema.


@dataclass(frozen=True)
class Estilo:
    """Un traje completo: como se ve la aplicacion de arriba abajo."""

    clave: str
    """Lo que se guarda en los ajustes. No cambia nunca."""

    nombre: str
    """Como se llama en la pantalla de Configuracion."""

    descripcion: str
    """Una linea que dice a que suena, para poder elegir sin probarlos todos."""

    clara: Paleta
    oscura: Paleta

    def paleta(self, *, oscuro: bool) -> Paleta:
        return self.oscura if oscuro else self.clara


# --------------------------------------------------------------- 1. ELEGANTE
# La referencia: PaceFuel. Negro puro contra blanco puro, sin colores. Todo el
# peso lo lleva la tipografia condensada y el contraste. Es el de por omision
# porque es el que menos se cansa de mirar y el que mejor deja ver los datos:
# cuando no hay color, los numeros son lo unico que hay.
ELEGANTE_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#000000", surface="#0b0b0b", surface_2="#161616", surface_3="#222222",
    borde="#242424", borde_fuerte="#3d3d3d",
    ink="#ffffff", ink_soft="#b0b0b0", muted="#6e6e6e",
    acento="#ffffff", acento_suave="#1c1c1c", acento_ink="#000000",
    positivo="#7ee08a", negativo="#ff6b6b", aviso="#ffc266",
    titular="BarlowCondensed",
)
ELEGANTE_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#ffffff", surface="#fafafa", surface_2="#f0f0f0", surface_3="#e4e4e4",
    borde="#e6e6e6", borde_fuerte="#c2c2c2",
    ink="#000000", ink_soft="#4a4a4a", muted="#8c8c8c",
    acento="#111111", acento_suave="#ededed", acento_ink="#ffffff",
    positivo="#1f7a35", negativo="#c02626", aviso="#9a6208",
    titular="BarlowCondensed",
)

# ------------------------------------------------------------------- 2. RETO
# La referencia: WeTalk. Casi negro violaceo y un morado electrico que empuja.
# Es el mas "de aplicacion movil": mucho contraste de color, todo redondo, y el
# acento gritando desde el otro lado de la mesa.
RETO_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#0d0b14", surface="#171326", surface_2="#211c33", surface_3="#2c2542",
    borde="#2a2440", borde_fuerte="#453a63",
    ink="#f4f1ff", ink_soft="#b7aede", muted="#7d739e",
    acento="#a855f7", acento_suave="#2a1a45", acento_ink="#ffffff",
    positivo="#5ee0a0", negativo="#ff6b8a", aviso="#ffb347",
    titular="Poppins",
)
RETO_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f8f6ff", surface="#ffffff", surface_2="#f1ecfd", surface_3="#e6def8",
    borde="#e4dcf7", borde_fuerte="#c3b2e8",
    ink="#1b1430", ink_soft="#4f4470", muted="#8579a5",
    acento="#7c3aed", acento_suave="#ede4ff", acento_ink="#ffffff",
    positivo="#12805a", negativo="#c9265a", aviso="#96590c",
    titular="Poppins",
)

# ---------------------------------------------------------------- 3. PREMIUM
# La referencia: Global Connect. Verde bosque profundo y cobre. Es el unico con
# dos colores que se reparten el trabajo: el verde manda en el fondo y el cobre
# se guarda para lo que hay que mirar. Da sensacion de cosa cara.
PREMIUM_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#08201a", surface="#0e2f25", surface_2="#153c30", surface_3="#1d4a3c",
    borde="#1a4436", borde_fuerte="#2e6653",
    ink="#f2ede3", ink_soft="#c3b9a4", muted="#8b9c92",
    acento="#c9a227", acento_suave="#173d2f", acento_ink="#08201a",
    positivo="#5fc08a", negativo="#e08c7a", aviso="#e0b45f",
    titular="Jost",
)
PREMIUM_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f6f3ec", surface="#ffffff", surface_2="#eeeade", surface_3="#e2dccb",
    borde="#e0dacb", borde_fuerte="#bdb49c",
    ink="#0f2b22", ink_soft="#3f5850", muted="#7d8a82",
    acento="#8a6d1f", acento_suave="#f0e7cc", acento_ink="#ffffff",
    positivo="#1c6b45", negativo="#a34a35", aviso="#8a6415",
    titular="Jost",
)

# ------------------------------------------------------------ 4. MINIMALISTA
# La referencia: twinkle. Azul pizarra apagado y arena calida, sin un solo color
# saturado. Todo susurra. Es el que menos molesta de noche y el que mas espacio
# aparenta, porque nada tira de la vista.
MINIMALISTA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#191d28", surface="#212635", surface_2="#2a3040", surface_3="#343b4d",
    borde="#2e3444", borde_fuerte="#454d61",
    ink="#e8e4dc", ink_soft="#a9a498", muted="#767c8b",
    acento="#d6b98c", acento_suave="#2b2b31", acento_ink="#191d28",
    positivo="#8fbf9f", negativo="#c98f8f", aviso="#d6b98c",
    titular="Outfit",
)
MINIMALISTA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f7f5f1", surface="#ffffff", surface_2="#eeece7", surface_3="#e2dfd8",
    borde="#e5e2db", borde_fuerte="#c0bcb1",
    ink="#242833", ink_soft="#565b68", muted="#8b8f9a",
    acento="#a07a45", acento_suave="#f0e8dc", acento_ink="#ffffff",
    positivo="#3d7a52", negativo="#a35555", aviso="#8a6a2e",
    titular="Outfit",
)

# ----------------------------------------------------------------- 5. NATURAL
# El que ya tenia la aplicacion, del rediseno que se aprobo: grises calidos que
# comparten tono con el papel del fondo, verde de acento y la serif de los
# titulares. Se queda porque es el unico pensado desde cero para esta
# aplicacion, y no copiado de una referencia de otra.
NATURAL_CLARA = CLARA
NATURAL_OSCURA = OSCURA


ESTILOS: tuple[Estilo, ...] = (
    Estilo(
        clave="elegante",
        nombre="Elegante",
        descripcion="Blanco y negro, sin colores. Los números son lo único que hay.",
        clara=ELEGANTE_CLARA,
        oscura=ELEGANTE_OSCURA,
    ),
    Estilo(
        clave="reto",
        nombre="Reto",
        descripcion="Morado eléctrico sobre casi negro. El que más empuja.",
        clara=RETO_CLARA,
        oscura=RETO_OSCURA,
    ),
    Estilo(
        clave="premium",
        nombre="Premium",
        descripcion="Verde bosque y cobre. Sensación de cosa cara.",
        clara=PREMIUM_CLARA,
        oscura=PREMIUM_OSCURA,
    ),
    Estilo(
        clave="minimalista",
        nombre="Minimalista",
        descripcion="Pizarra y arena, sin un color saturado. Todo susurra.",
        clara=MINIMALISTA_CLARA,
        oscura=MINIMALISTA_OSCURA,
    ),
    Estilo(
        clave="natural",
        nombre="Natural",
        descripcion="Papel cálido, verde y letra serif. El de siempre.",
        clara=NATURAL_CLARA,
        oscura=NATURAL_OSCURA,
    ),
)

POR_CLAVE: dict[str, Estilo] = {uno.clave: uno for uno in ESTILOS}

ESTILO_POR_OMISION = "elegante"
"""El que sale si nunca tocas el ajuste. Lo eligio el usuario."""


def estilo_por_clave(clave: str) -> Estilo:
    """El estilo guardado, o el de por omision si el ajuste esta raro.

    NO FALLA A PROPOSITO, al reves que las monedas: equivocarse aqui solo cuesta
    ver la aplicacion de otro color, nunca un dato mal. Y una aplicacion que no
    abre porque el ajuste del tema esta corrupto seria mucho peor que una que
    abre en blanco y negro.
    """
    if not isinstance(clave, str):
        return POR_CLAVE[ESTILO_POR_OMISION]
    return POR_CLAVE.get(clave.strip().lower(), POR_CLAVE[ESTILO_POR_OMISION])


# ----------------------------------------------------------------------------
# Los seis pasteles del horario semanal
# ----------------------------------------------------------------------------
#
# LOS PIDIÓ EL USUARIO para el horario: "cuadrados de colores y/o las letras,
# para que sea más visible; colores pasteles, no muy fuertes". Sirven para
# marcar bloques de un vistazo sin tener que leer lo que pone en cada casilla.
#
# SON LOS MISMOS EN LOS CINCO ESTILOS, y es a propósito: aquí el color no es
# decoración, es una MARCA que tú le pones a una hora. Que el verde cambiara de
# tono al cambiar de estilo obligaría a reaprender la rejilla cada vez.
#
# HAY DOS JUEGOS, claro y oscuro, y esa es la parte que no se ve venir: un
# pastel suave sobre blanco es precioso, y ese mismo pastel sobre un fondo casi
# negro es una mancha que deslumbra. En oscuro se usan los mismos seis tonos
# pero apagados y profundos, con el texto claro encima. Así el color significa
# lo mismo en los dos modos sin hacer daño a la vista en ninguno.

_PASTELES_CLARO = {
    "verde": "#cfe8d5",
    "azul": "#cfe0f2",
    "lila": "#ddd6ef",
    "rosa": "#f3d7e0",
    "melocoton": "#fadfc9",
    "amarillo": "#f6ecc4",
}

_PASTELES_OSCURO = {
    "verde": "#2f4a39",
    "azul": "#2c4055",
    "lila": "#3d3752",
    "rosa": "#4e3340",
    "melocoton": "#543c2c",
    "amarillo": "#4c452a",
}

_TINTA_SOBRE_PASTEL_CLARO = "#2b2a28"
_TINTA_SOBRE_PASTEL_OSCURO = "#eceae5"


def pastel(nombre: str, paleta: Paleta) -> str:
    """El color de ese pastel, en la versión clara u oscura que toque.

    Se le pasa la paleta y no un booleano para que quien llame no tenga que
    saber si está en claro o en oscuro: ya lleva una paleta en la mano.
    """
    juego = _PASTELES_OSCURO if paleta.modo is ft.ThemeMode.DARK else _PASTELES_CLARO
    if nombre not in juego:
        raise KeyError(
            f"«{nombre}» no es uno de los pasteles del horario; "
            f"están en interfaz/estilo.py"
        )
    return juego[nombre]


def tinta_sobre_pastel(paleta: Paleta) -> str:
    """El color del texto que va ENCIMA de una casilla pintada.

    No vale el `ink` de la paleta: en oscuro es casi blanco y sobre un pastel
    claro no se leería, y en claro es oscuro y sobre un pastel oscuro tampoco.
    """
    if paleta.modo is ft.ThemeMode.DARK:
        return _TINTA_SOBRE_PASTEL_OSCURO
    return _TINTA_SOBRE_PASTEL_CLARO


def paleta_para(
    nombre: str, *, sistema_oscuro: bool, estilo: str = ESTILO_POR_OMISION
) -> Paleta:
    """La paleta que toca: la del ESTILO elegido, en su versión clara u oscura.

    SON DOS AJUSTES INDEPENDIENTES y funcionan como uno espera: el estilo dice
    de qué colores es la aplicación, y el tema dice si esos colores van en su
    versión clara o en la oscura. Los cinco estilos tienen las dos.

    "sistema" (y cualquier valor raro, por si el ajuste estuviera corrupto) sigue
    a Windows: es lo que el usuario ya decidió una vez para todo su ordenador, y
    equivocarse ahí solo cuesta un tema feo, no un dato mal guardado.
    """
    elegido = estilo_por_clave(estilo)
    if nombre == "claro":
        return elegido.clara
    if nombre == "oscuro":
        return elegido.oscura
    return elegido.paleta(oscuro=sistema_oscuro)
