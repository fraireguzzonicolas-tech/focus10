"""Los colores y las medidas de Focus10.

POR QUÉ ESTÁN TODOS AQUÍ: si cada pantalla eligiera sus colores a mano, en tres
pantallas habría cinco grises distintos y nadie sabría cuál es el bueno. Aquí
está la lista completa, y las pantallas solo piden "el color del texto apagado".
Es también lo que ha permitido cambiar el aspecto de las nueve pantallas de una
vez, tocando solo este archivo y componentes.py.

DE DÓNDE SALE ESTA PALETA: del rediseño que aprobó el usuario. Se diseñó en
oklch —que reparte la claridad como la ve el ojo, no como la calcula la
pantalla— y se convirtió a hexadecimal aquí, porque es lo que entiende Flet. Por
eso los grises son CÁLIDOS y no azulados: comparten el mismo tono que el papel
del fondo, y eso es lo que hace que la pantalla se lea como una página y no como
un panel de control.

LAS TRES REGLAS DE COLOR QUE SOSTIENEN EL DISEÑO:

  1. El verde del acento manda. Los dos acentos —el verde y el barro— comparten
     claridad y croma, y solo cambian de tono: por eso nunca compiten.
  2. El verde y el rojo son SOLO para cifras y detalles pequeños, nunca para
     fondos grandes. Dos botones enormes de color pleno gritan y no dejan ver lo
     importante, que son los números.
  3. Separar por TONO y por ESPACIO antes que por línea. Un borde de un píxel en
     cada tarjeta se ve barato; una sombra muy suave y aire alrededor, no.

EL ACENTO NO SE PERSONALIZA por ahora, por decisión del usuario: la aplicación es
bonita porque está decidida, no porque se pueda tocar. Los otros cuatro estilos
del rediseño —Formal, Natural, Minimal, Personal— caben aquí como cuatro paletas
más el día que se quieran; nada de lo demás habría que tocarlo.

AQUÍ SOLO HAY COLORES Y MEDIDAS. Las piezas que los usan (tarjetas, botones,
campos) están en componentes.py.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import flet as ft

from ..dominio.habito import COLORES


FUENTE = "Schibsted"
"""La de la interfaz. Todo lo que se lee de corrido, en todos los estilos."""

FUENTE_SUPLENTE = "Segoe UI"
"""Lo que se usa si las de arriba no cargan. Está en cualquier Windows."""


@dataclass(frozen=True)
class Paleta:
    """Un juego completo de colores. Hay dos: la clara y la oscura."""

    modo: ft.ThemeMode

    canvas: str
    """El fondo de la ventana, detrás de las tarjetas."""

    surface: str
    """El fondo de una tarjeta."""

    surface_2: str
    """Un escalón más marcado: botones secundarios, cabeceras de tabla."""

    surface_3: str
    borde: str
    borde_fuerte: str

    ink: str
    """El texto principal."""

    ink_soft: str
    muted: str
    """Texto de apoyo: etiquetas, ayudas, lo que no hay que leer."""

    acento: str
    acento_suave: str
    acento_ink: str

    positivo: str
    negativo: str
    aviso: str

    titular: str = "Instrument"
    """La tipografía de los titulares y las cifras de ESTE estilo.

    VA EN LA PALETA Y NO EN UNA CONSTANTE DEL MÓDULO, y ese es todo el truco que
    permite cambiar de estilo: cada pantalla ya recibe una paleta para saber de
    qué color pintar, así que ahora también sabe con qué letra escribir. Sin
    esto, cambiar la tipografía habría obligado a que cada control consultara un
    ajuste por su cuenta.
    """

    categorias: tuple[str, ...] = ()
    """Los ocho colores de categoría de ESTE tema, en el orden de dominio.COLORES.

    ANTES ERAN GLOBALES: un solo diccionario con el mismo azul para todos los
    estilos. Lo pidió el usuario al rediseñar los temas —«categorías
    diferenciables, pero adaptadas a la paleta»— y tiene razón: un azul de
    hábito pensado para papel crema chirría sobre un fondo synthwave.

    VACÍO CAE A LOS DE SIEMPRE. Un tema a medio escribir no puede dejar los
    hábitos sin color: se dibujarían todos iguales y no se sabría cuál es cuál.
    """

    tema: str = ""
    """La clave del tema al que pertenece esta paleta.

    HACE FALTA PARA LOS PASTELES DEL HORARIO, que se calculan a partir del
    carácter del tema en vez de escribirse uno a uno. Sin esto habría que
    pasarle la clave a cada sitio que dibuja una casilla.
    """

    motivo: str = "nada"
    """El dibujo de fondo del tema. Ver interfaz/motivo_fondo.py.

    UNO POR TEMA Y PEQUEÑO. Las reglas están en ese archivo; aquí solo se dice
    cuál toca. "nada" es una respuesta legítima: Elegante no lleva ninguno, y
    eso es parte de lo que lo hace Elegante.
    """

    fuente: str = FUENTE
    """La del texto normal. ES LA MISMA EN TODOS LOS TEMAS a propósito.

    El texto de la interfaz se lee durante horas y su trabajo es no llamar la
    atención; lo que le da carácter a un estilo son los titulares y el color.
    Cambiar también la letra pequeña haría cinco aplicaciones distintas de leer
    en vez de una aplicación con cinco trajes.
    """


# ---------------------------------------------------------------------------


def _color_de_categoria(paleta: "Paleta", nombre: str) -> str:
    """El color de una categoría en ESTE tema.

    Se escribe fuera de la clase porque necesita COLORES_DE_PARTIDA, que se
    define más abajo; dentro quedaría una referencia hacia adelante.
    """
    orden = COLORES
    if paleta.categorias and nombre in orden:
        return paleta.categorias[orden.index(nombre)]
    # NO FALLA A PROPÓSITO: un color raro guardado solo debe costar un hábito de
    # otro color, nunca impedir que la pantalla se dibuje.
    return COLORES_DE_PARTIDA.get(nombre, COLORES_DE_PARTIDA["azul"])


Paleta.color_de = _color_de_categoria


CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f9f7f3",
    surface="#ffffff",
    surface_2="#f3f0ea",
    surface_3="#eae7e2",
    borde="#e0deda",
    borde_fuerte="#c7c4be",
    ink="#221c16",
    ink_soft="#57514c",
    muted="#8a8580",
    acento="#367855",
    acento_suave="#dff0e5",
    acento_ink="#ffffff",
    positivo="#357950",
    negativo="#a85550",
    aviso="#9b6142",
)

OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#110e0a",
    surface="#1d1913",
    surface_2="#26221c",
    surface_3="#302c25",
    borde="#2f2b25",
    borde_fuerte="#49443d",
    ink="#efece7",
    ink_soft="#b4b1aa",
    muted="#7d7a74",
    acento="#6cb78d",
    acento_suave="#1a3124",
    acento_ink="#110e0a",
    positivo="#78c192",
    negativo="#df7f78",
    aviso="#dfa36d",
)

POR_NOMBRE = {"claro": CLARA, "oscuro": OSCURA}

# Los tres valores que puede tener el ajuste del tema, en el orden en que se
# enseñan en Configuración.
TEMAS = (
    ("sistema", "Seguir a Windows"),
    ("claro", "Claro"),
    ("oscuro", "Oscuro"),
)

# LOS OCHO COLORES DE RESPALDO. Cada tema trae los suyos (ver Paleta.categorias);
# éstos son los que se usan si un tema no los define, y los que se usaban antes
# de que los temas los tuvieran.
#
# Las claves son las del dominio
# (dominio/habito.py), que guarda "azul" y no un color: así la paleta se puede
# cambiar sin tocar un solo dato guardado.
#
# LOS OCHO COMPARTEN CLARIDAD Y CROMA y solo cambian de tono. No es un detalle:
# con claridades distintas, un hábito parecería más importante que otro sin que
# nadie lo haya decidido. Y al ser tonos medios se leen igual sobre el fondo
# claro y sobre el oscuro.
COLORES_DE_PARTIDA = {
    "azul": "#2e9dd3",
    "verde": "#53a768",
    "ambar": "#b58b22",
    "rosa": "#ca709d",
    "violeta": "#9e7fd3",
    "cian": "#00a8b0",
    "naranja": "#cc7c40",
    "rojo": "#d4716b",
}


def color_de_habito(nombre: str) -> str:
    """El color de respaldo de una categoría, SIN tema.

    QUEDA PARA LOS SITIOS QUE NO TIENEN PALETA A MANO. Donde la haya, lo
    correcto es `paleta.color_de(nombre)`: es lo que hace que un hábito azul se
    vea distinto en Galaxia que en Natural.
    """
    return COLORES_DE_PARTIDA.get(nombre, COLORES_DE_PARTIDA["azul"])


def con_opacidad(color: str, fraccion: float) -> str:
    """El mismo color, más o menos transparente. De 0 a 1.

    Está aquí y no en los componentes porque es una operación sobre colores, y
    los colores viven en este archivo. Se usa para rellenar el círculo de un
    hábito según lo que lleves hecho.
    """
    return ft.Colors.with_opacity(max(0.0, min(1.0, fraccion)), color)


# Blanco puro. No va dentro de la Paleta porque no cambia con el tema: es el
# texto que se pone ENCIMA de un color fuerte (el rojo de un boton de borrar),
# donde el color del tema no serviria.
BLANCO = "#ffffff"


# ---------------------------------------------------------------------------
# Tipografía
# ---------------------------------------------------------------------------

# Las fuentes viven DENTRO del proyecto y no se piden a internet. Dos razones:
# la aplicación funciona sin conexión (solo Inversiones sale fuera, y con
# permiso), y así PyInstaller las puede empaquetar en la última fase. Son de
# licencia abierta (SIL OFL), así que se pueden distribuir con el programa.
CARPETA_FUENTES = Path(__file__).resolve().parents[3] / "assets" / "fuentes"

ARCHIVOS_DE_FUENTE = {
    # La del texto, común a todos los estilos.
    FUENTE: CARPETA_FUENTES / "SchibstedGrotesk.ttf",
    # Y una titular por estilo. SE REGISTRAN TODAS AL ABRIR, no solo la del
    # estilo elegido: cambiar de estilo tiene que ser instantáneo, y bajar una
    # fuente a mitad de sesión sería un parpadeo raro. Entre las doce suman
    # 1,3 MB.
    "Instrument": CARPETA_FUENTES / "InstrumentSerif-Regular.ttf",
    "Poppins": CARPETA_FUENTES / "Poppins.ttf",
    "Jost": CARPETA_FUENTES / "Jost.ttf",
    "Outfit": CARPETA_FUENTES / "Outfit.ttf",
    "BarlowCondensed": CARPETA_FUENTES / "BarlowCondensed.ttf",
    # Las seis del rediseno de los trece temas. Todas de licencia abierta y
    # ligeras: entre las doce del proyecto suman 1,3 MB.
    "Orbitron": CARPETA_FUENTES / "Orbitron.ttf",
    "CormorantGaramond": CARPETA_FUENTES / "CormorantGaramond.ttf",
    "Fraunces": CARPETA_FUENTES / "Fraunces.ttf",
    "Sora": CARPETA_FUENTES / "Sora.ttf",
    "Archivo": CARPETA_FUENTES / "Archivo.ttf",
    "Marcellus": CARPETA_FUENTES / "Marcellus.ttf",
}


def fuentes_disponibles() -> dict[str, str]:
    """Las fuentes que de verdad están en el disco, listas para registrarlas.

    Se comprueba que el archivo exista en vez de darlo por hecho: si alguien
    mueve la carpeta o el empaquetado se deja un archivo, la aplicación tiene
    que abrir igual con la fuente suplente, no quedarse en negro por una tilde
    tipográfica.
    """
    return {
        nombre: str(ruta)
        for nombre, ruta in ARCHIVOS_DE_FUENTE.items()
        if ruta.is_file()
    }


# La escala. Son los tamaños del rediseño, y son POCOS a propósito: con quince
# tamaños distintos no hay jerarquía, hay ruido.
TITULAR_GRANDE = 40
"""El nombre de la pantalla. En serif."""

TITULAR = 30
CIFRA_GRANDE = 44
"""Los números que son el motivo de abrir la pantalla. En serif."""

CIFRA = 26
SUBTITULAR = 20
"""El escalón que faltaba entre el título de una tarjeta (16) y el de una
pantalla (30).

HACÍA FALTA PARA ENTRENAR: el nombre del ejercicio es lo que buscas con la vista
cuando levantas la cabeza entre serie y serie, con el móvil en el suelo o en un
banco. A 16 no se lee desde ahí, y a 30 seis tarjetas seguidas se comen la
pantalla y hay que hacer scroll para nada."""

TEXTO_TARJETA = 16
"""El título de una tarjeta."""

TEXTO = 14
TEXTO_APOYO = 12.5
ROTULO = 11
"""Los rótulos en mayúsculas pequeñas, con mucho espaciado entre letras."""

ESPACIADO_ROTULO = 1.1
"""El aire entre letras de un rótulo, en píxeles. Sin él, las mayúsculas
pequeñas se apelmazan y dejan de leerse."""


# ---------------------------------------------------------------------------
# Medidas
# ---------------------------------------------------------------------------

RADIO_TARJETA = 16
RADIO_BOTON = 999
"""Los botones son cápsulas. Es lo que más cambia el aire de la aplicación con
menos código, y separa de un vistazo lo que se pulsa de lo que se lee."""

RADIO_CAMPO = 10
RELLENO_TARJETA = 24
ALTO_BOTON = 38
_ancho_de_la_pantalla: float | None = None
"""Lo ancha que es la ventana ahora mismo, o None si aún no se sabe.

POR QUÉ UN DATO GLOBAL, que normalmente es mala idea: porque esto SÍ es global.
La aplicación tiene una ventana y una sola, y su ancho es el mismo para todo lo
que se dibuje dentro. La alternativa era pasar el ancho como parámetro por los
veinticinco archivos de interfaz hasta llegar a la tabla, y eso son veinticinco
sitios donde olvidarse de pasarlo.

LO PONE app.py EN CADA MONTAJE, que es el único sitio que habla con la ventana.

SI VALE None SE DIBUJA COMO EN UN ORDENADOR: al arrancar, Flet puede no haber
medido todavía, y dar por hecho "móvil" haría parpadear la aplicación de
escritorio en cada apertura.
"""


def fijar_ancho(ancho: float | None) -> None:
    """Lo llama app.py al montar la ventana. Nadie más debería."""
    global _ancho_de_la_pantalla
    _ancho_de_la_pantalla = ancho


def pantalla_estrecha() -> bool:
    """Si hay que dibujar como en un móvil."""
    return bool(_ancho_de_la_pantalla) and _ancho_de_la_pantalla < ANCHO_ESTRECHO


def ancho_de_grafico(maximo: int, *, margenes: int = 64) -> int:
    """Lo ancho que puede dibujarse un gráfico sin salirse de la pantalla.

    LOS GRÁFICOS DE ESTA APLICACIÓN SE DIBUJAN A MANO sobre un lienzo, y un
    lienzo necesita un ancho concreto: no puede "estirarse hasta lo que haya"
    como una caja normal, porque tiene que saber dónde cae cada punto.

    Así que se le da el mejor ancho posible: el que pidió, o lo que quepa si es
    menos. El suelo de 240 evita que en una ventana absurdamente estrecha el
    gráfico se quede en una raya.
    """
    if not _ancho_de_la_pantalla:
        return maximo
    return max(240, min(maximo, int(_ancho_de_la_pantalla) - margenes))


ANCHO_ESTRECHO = 600
"""Por debajo de este ancho, la aplicación se dibuja como en un móvil.

POR QUÉ 600 Y NO 375: 375 es lo que mide un móvil, pero el corte no debe estar
en el caso justo. Una tableta en vertical, o media ventana en un portátil, están
más cerca de un móvil que de un escritorio: ahí la barra lateral ya estorba más
de lo que ayuda. 600 es donde deja de compensar gastar 236 puntos en un menú.

NO ES UNA MEDIDA DE APARATO, es una medida de sitio disponible. La misma ventana
cruza este número al hacerla pequeña, y la aplicación se recoloca.
"""

ANCHO_LATERAL = 236
DENSIDAD = 26
"""La separación vertical entre bloques de una pantalla."""


def sombra_tarjeta(paleta: Paleta) -> ft.BoxShadow | None:
    """La sombra de una tarjeta. Muy suave, y ninguna en el tema oscuro.

    En oscuro no se pone: una sombra negra sobre un fondo casi negro no se ve, y
    lo que separa ahí es el escalón de tono entre el lienzo y la superficie. Es
    la misma decisión que en el rediseño.
    """
    if paleta.modo is ft.ThemeMode.DARK:
        return None
    return ft.BoxShadow(
        blur_radius=20,
        spread_radius=-4,
        color=ft.Colors.with_opacity(0.07, "#221c16"),
        offset=ft.Offset(0, 6),
    )


# ---------------------------------------------------------------------------
# Los cinco estilos
# ---------------------------------------------------------------------------
#
# DE DONDE SALEN: de cuatro referencias que dio el usuario, mas el que ya tenia.
# Cada uno es una paleta clara, una oscura y una tipografia de titulares. Lo
# demas —las medidas, las esquinas, las sombras— NO cambia entre estilos, y esa
# fue su decision: "colores y tipografia, sin tocar formas". Se agradece al
# mantenerlo, porque significa que un estilo nuevo son dos paletas y una linea.
#
# LAS TRES REGLAS QUE CUMPLEN LOS CINCO, y que hay tests para cada una:
#   1. El texto se lee sobre su fondo. Un estilo bonito e ilegible no vale.
#   2. El claro es claro y el oscuro es oscuro, en los cinco.
#   3. Ningun color se repite entre la version clara y la oscura del mismo
#      estilo; si se repitiera, esa parte no cambiaria al cambiar de tema.


@dataclass(frozen=True)
class Estilo:
    """Un traje completo: como se ve la aplicacion de arriba abajo."""

    clave: str
    """Lo que se guarda en los ajustes. No cambia nunca."""

    nombre: str
    """Como se llama en la pantalla de Configuracion."""

    descripcion: str
    """Una linea que dice a que suena, para poder elegir sin probarlos todos."""

    clara: Paleta
    oscura: Paleta

    def paleta(self, *, oscuro: bool) -> Paleta:
        return self.oscura if oscuro else self.clara


# -------------------------------------------------- 1. ELEGANTE
# Editorial y silencioso. El único color es la tinta; todo lo demás es aire.
# Fondo: ninguno, y es la decisión.
ELEGANTE_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f7f5f1", surface="#fffefc", surface_2="#efece6",
    surface_3="#e7e3db", borde="#e2ded7", borde_fuerte="#c3bdb2",
    ink="#14110e", ink_soft="#4a453f", muted="#8b857d",
    acento="#14110e", acento_suave="#e8e4dd", acento_ink="#fffefc",
    positivo="#3d6b4f", negativo="#9c4a44", aviso="#8a6a2f",
    titular="Instrument",
    categorias=("#6b7f8c", "#6e8a70", "#99855c", "#9c7684", "#7f7793", "#63878a", "#a1815f", "#a0706c"),
    motivo="nada",
    tema="elegante",
)
ELEGANTE_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#0e0d0b", surface="#171512", surface_2="#201d19",
    surface_3="#282420", borde="#2a2621", borde_fuerte="#494339",
    ink="#f4f1eb", ink_soft="#b3ada4", muted="#7c766e",
    acento="#f4f1eb", acento_suave="#262320", acento_ink="#0e0d0b",
    positivo="#7fae8e", negativo="#d18b85", aviso="#c5a05f",
    titular="Instrument",
    categorias=("#6b7f8c", "#6e8a70", "#99855c", "#9c7684", "#7f7793", "#63878a", "#a1815f", "#a0706c"),
    motivo="nada",
    tema="elegante",
)

# -------------------------------------------------- 2. OCHENTAS
# Synthwave de gama alta: noche profunda, magenta eléctrico y cian. Brillo, nunca juguete.
# Fondo: horizonte en perspectiva.
OCHENTAS_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f4f0ff", surface="#ffffff", surface_2="#ece5ff",
    surface_3="#e2d9fb", borde="#d9cdf5", borde_fuerte="#b9a6e8",
    ink="#1a0f3d", ink_soft="#4b3d7a", muted="#7c72a8",
    acento="#c81ea6", acento_suave="#fbe3f6", acento_ink="#ffffff",
    positivo="#0d9c96", negativo="#d63a58", aviso="#c99310",
    titular="Orbitron",
    categorias=("#ff2fd0", "#2ff0d0", "#ffd23f", "#ff6ec7", "#9d5cff", "#35d6ff", "#ff8a3d", "#ff4f6d"),
    motivo="rejilla",
    tema="ochentas",
)
OCHENTAS_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#0b0720", surface="#150e33", surface_2="#1e1447",
    surface_3="#271a58", borde="#2c1f63", borde_fuerte="#4a34a0",
    ink="#f0ecff", ink_soft="#b9b0e8", muted="#7e75b5",
    acento="#ff2fd0", acento_suave="#3a0f4a", acento_ink="#0b0720",
    positivo="#2ff0d0", negativo="#ff5470", aviso="#ffd23f",
    titular="Orbitron",
    categorias=("#ff2fd0", "#2ff0d0", "#ffd23f", "#ff6ec7", "#9d5cff", "#35d6ff", "#ff8a3d", "#ff4f6d"),
    motivo="rejilla",
    tema="ochentas",
)

# --------------------------------------------------- 3. PREMIUM
# Borgoña sobre carbón y marfil, con un filo dorado. Sobrio, preciso, caro sin gritarlo.
# Fondo: arco dorado.
PREMIUM_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f7f3ec", surface="#ffffff", surface_2="#efe8dd",
    surface_3="#e6ddce", borde="#e0d7c8", borde_fuerte="#b99f63",
    ink="#1b1416", ink_soft="#4e4348", muted="#8a7f7a",
    acento="#8c2634", acento_suave="#f6e4e5", acento_ink="#ffffff",
    positivo="#43714a", negativo="#a8443c", aviso="#9c7c2c",
    titular="CormorantGaramond",
    categorias=("#7a5a66", "#5e7360", "#9b7b3c", "#96606f", "#6d5f86", "#4f7377", "#a06a45", "#9c4c48"),
    motivo="arco",
    tema="premium",
)
PREMIUM_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#100c0d", surface="#1a1416", surface_2="#241a1d",
    surface_3="#2c2024", borde="#2b2124", borde_fuerte="#6b5733",
    ink="#f5efe6", ink_soft="#bcb0a3", muted="#8a7f74",
    acento="#a33241", acento_suave="#2c1418", acento_ink="#f8f3ec",
    positivo="#6f9b6e", negativo="#c25a52", aviso="#c8a961",
    titular="CormorantGaramond",
    categorias=("#7a5a66", "#5e7360", "#9b7b3c", "#96606f", "#6d5f86", "#4f7377", "#a06a45", "#9c4c48"),
    motivo="arco",
    tema="premium",
)

# ----------------------------------------------- 4. MINIMALISTA
# Blanco cálido, niebla y grafito con un único acento salvia. Calmo y legible por encima de todo.
# Fondo: forma abstracta.
MINIMALISTA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#fbfaf8", surface="#ffffff", surface_2="#f2f0ec",
    surface_3="#eae7e1", borde="#e6e3dd", borde_fuerte="#cbc7c0",
    ink="#23211e", ink_soft="#55524d", muted="#8d8983",
    acento="#6f8a86", acento_suave="#e6edeb", acento_ink="#ffffff",
    positivo="#5d8168", negativo="#a9635c", aviso="#9a7f4e",
    titular="Jost",
    categorias=("#6f8a86", "#7d8a6f", "#8a8470", "#8a707d", "#7a7590", "#6b8790", "#97836a", "#98716c"),
    motivo="blob",
    tema="minimalista",
)
MINIMALISTA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#131312", surface="#1c1c1a", surface_2="#242422",
    surface_3="#2b2b28", borde="#2c2c29", borde_fuerte="#474743",
    ink="#eeece8", ink_soft="#b0ada7", muted="#7d7a75",
    acento="#8fada8", acento_suave="#1f2827", acento_ink="#131312",
    positivo="#82a88c", negativo="#c4837c", aviso="#bfa06a",
    titular="Jost",
    categorias=("#6f8a86", "#7d8a6f", "#8a8470", "#8a707d", "#7a7590", "#6b8790", "#97836a", "#98716c"),
    motivo="blob",
    tema="minimalista",
)

# --------------------------------------------------- 5. NATURAL
# Bosque, salvia y miel sobre crema. Cálido y orgánico; los hábitos cumplidos se sienten como algo que crece.
# Fondo: rama a línea.
NATURAL_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f8f4ea", surface="#fffdf7", surface_2="#efe9da",
    surface_3="#e6dfcd", borde="#ded5c2", borde_fuerte="#bfb298",
    ink="#1f2a20", ink_soft="#4a5749", muted="#857f70",
    acento="#2f5d3a", acento_suave="#e0ecdd", acento_ink="#fffdf7",
    positivo="#3f7a4a", negativo="#a3583f", aviso="#b8892b",
    titular="Fraunces",
    categorias=("#4a7c59", "#86a05a", "#c19a3f", "#a2673f", "#7d6a94", "#4f8892", "#c2743c", "#a24f43"),
    motivo="rama",
    tema="natural",
)
NATURAL_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#0e130e", surface="#171d16", surface_2="#1f271e",
    surface_3="#262f25", borde="#2a332a", borde_fuerte="#44513f",
    ink="#eef2e6", ink_soft="#b2bda9", muted="#7f8a78",
    acento="#6fae74", acento_suave="#16251a", acento_ink="#0e130e",
    positivo="#77b47c", negativo="#cf8158", aviso="#d8ad4a",
    titular="Fraunces",
    categorias=("#4a7c59", "#86a05a", "#c19a3f", "#a2673f", "#7d6a94", "#4f8892", "#c2743c", "#a24f43"),
    motivo="rama",
    tema="natural",
)

# ----------------------------------------------------- 6. SOLAR
# Coral, mango y menta sobre crema. Optimista y con recompensa: completar algo tiene que sentirse bien.
# Fondo: sol de rayos.
SOLAR_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#fff8ef", surface="#ffffff", surface_2="#ffeedd",
    surface_3="#ffe4cb", borde="#ffdcc0", borde_fuerte="#f4b98c",
    ink="#2a1a12", ink_soft="#5c4437", muted="#927a68",
    acento="#ff5a4e", acento_suave="#ffe3df", acento_ink="#ffffff",
    positivo="#17b891", negativo="#e03c4a", aviso="#ffb02e",
    titular="Outfit",
    categorias=("#ff5a4e", "#ffb02e", "#17b891", "#ff8fa3", "#a06bff", "#3ec6e0", "#ff7f3f", "#e0464f"),
    motivo="sol",
    tema="solar",
)
SOLAR_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#191009", surface="#23180f", surface_2="#2e2014",
    surface_3="#38271a", borde="#3b2a1a", borde_fuerte="#5e422a",
    ink="#fff2e4", ink_soft="#d0b49b", muted="#9c8672",
    acento="#ff6f5e", acento_suave="#3a1c17", acento_ink="#191009",
    positivo="#3ad0a6", negativo="#ff6b6b", aviso="#ffc457",
    titular="Outfit",
    categorias=("#ff5a4e", "#ffb02e", "#17b891", "#ff8fa3", "#a06bff", "#3ec6e0", "#ff7f3f", "#e0464f"),
    motivo="sol",
    tema="solar",
)

# -------------------------------------------------- 7. ELECTRIC
# Violeta eléctrico y azul neón sobre azul noche. Para empujar objetivos, inversión y progreso.
# Fondo: curvas de nivel.
ELECTRIC_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f5f5ff", surface="#ffffff", surface_2="#eceafe",
    surface_3="#e2defb", borde="#d8d4f7", borde_fuerte="#b5aeee",
    ink="#14173a", ink_soft="#454a7d", muted="#7a7fae",
    acento="#6a2fe0", acento_suave="#eee6ff", acento_ink="#ffffff",
    positivo="#0f9d7e", negativo="#d62c5c", aviso="#c48a10",
    titular="Sora",
    categorias=("#8b5cff", "#2f8bff", "#ff4fa3", "#2fe0b0", "#ffc63f", "#ff7a45", "#4fd8ff", "#ff4d7d"),
    motivo="topografia",
    tema="electric",
)
ELECTRIC_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#080b1f", surface="#101433", surface_2="#171c45",
    surface_3="#1e2455", borde="#232a5e", borde_fuerte="#3d4794",
    ink="#eef0ff", ink_soft="#b0b5e6", muted="#7b81b3",
    acento="#8b5cff", acento_suave="#241a52", acento_ink="#f5f3ff",
    positivo="#2fe0b0", negativo="#ff4d7d", aviso="#ffc63f",
    titular="Sora",
    categorias=("#8b5cff", "#2f8bff", "#ff4fa3", "#2fe0b0", "#ffc63f", "#ff7a45", "#4fd8ff", "#ff4d7d"),
    motivo="topografia",
    tema="electric",
)

# ------------------------------------------------------ 8. ISLA
# Turquesa, menta y mango sobre blanco cálido. Bienestar en movimiento, no zen de spa.
# Fondo: ola a línea.
ISLA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f6fbf9", surface="#ffffff", surface_2="#e6f5f1",
    surface_3="#daeee9", borde="#cfe8e1", borde_fuerte="#a4d3c9",
    ink="#12262a", ink_soft="#3f5a5c", muted="#7b9490",
    acento="#0f9e9a", acento_suave="#d9f2ee", acento_ink="#ffffff",
    positivo="#34ab72", negativo="#d9563f", aviso="#f2921e",
    titular="Poppins",
    categorias=("#0f9e9a", "#34ab72", "#f2921e", "#4fc3d6", "#7ec46b", "#e0663f", "#3f9bd6", "#d84f6a"),
    motivo="ola",
    tema="isla",
)
ISLA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#071614", surface="#0e211f", surface_2="#142b28",
    surface_3="#1a3532", borde="#1d3733", borde_fuerte="#2f5751",
    ink="#e6f6f2", ink_soft="#a3c4bd", muted="#74928c",
    acento="#29c3ba", acento_suave="#0d2b28", acento_ink="#071614",
    positivo="#4fd08c", negativo="#ff7a5c", aviso="#ffab3d",
    titular="Poppins",
    categorias=("#0f9e9a", "#34ab72", "#f2921e", "#4fc3d6", "#7ec46b", "#e0663f", "#3f9bd6", "#d84f6a"),
    motivo="ola",
    tema="isla",
)

# ---------------------------------------------------- 9. AURORA
# Noche azul, cian y lavanda con luz suave. Futurista pero sereno; los datos se leen sin esfuerzo.
# Fondo: onda de puntos.
AURORA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f5f8fc", surface="#ffffff", surface_2="#e9eff8",
    surface_3="#dee7f4", borde="#d4dfee", borde_fuerte="#adbfdb",
    ink="#101a2b", ink_soft="#40506b", muted="#78889f",
    acento="#1e91a8", acento_suave="#ddf0f4", acento_ink="#ffffff",
    positivo="#17997a", negativo="#cf4a63", aviso="#c1902f",
    titular="Sora",
    categorias=("#4fd6e8", "#a89bf0", "#7fb2f0", "#5fe0b4", "#c9d3e6", "#f0a3c8", "#ffd070", "#ff8fa0"),
    motivo="semitono",
    tema="aurora",
)
AURORA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#070c18", surface="#101728", surface_2="#172037",
    surface_3="#1d2842", borde="#223049", borde_fuerte="#39506f",
    ink="#eef3fb", ink_soft="#adbcd4", muted="#77879f",
    acento="#4fd6e8", acento_suave="#102b33", acento_ink="#070c18",
    positivo="#5fe0b4", negativo="#ff6b83", aviso="#ffd070",
    titular="Sora",
    categorias=("#4fd6e8", "#a89bf0", "#7fb2f0", "#5fe0b4", "#c9d3e6", "#f0a3c8", "#ffd070", "#ff8fa0"),
    motivo="semitono",
    tema="aurora",
)

# ---------------------------------------------------- 10. TERRA
# Terracota, bosque y mostaza sobre crema. Una libreta premium contemporánea, con carácter.
# Fondo: grano de papel.
TERRA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#faf4e9", surface="#fffdf8", surface_2="#f0e6d6",
    surface_3="#e8dcc7", borde="#ddd0ba", borde_fuerte="#c0ac8d",
    ink="#241a12", ink_soft="#56463a", muted="#8d7c6b",
    acento="#b8532f", acento_suave="#f7e2d8", acento_ink="#fffdf8",
    positivo="#3d6b40", negativo="#a83a2c", aviso="#c39320",
    titular="Fraunces",
    categorias=("#b8532f", "#3d6b40", "#c39320", "#8a5a7a", "#6b6f9c", "#44807e", "#d1863c", "#a83a2c"),
    motivo="grano",
    tema="terra",
)
TERRA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#14100b", surface="#1e1811", surface_2="#282017",
    surface_3="#31281d", borde="#342b20", borde_fuerte="#544636",
    ink="#f4ece0", ink_soft="#bdae9b", muted="#8b7f6e",
    acento="#d9714a", acento_suave="#33190f", acento_ink="#14100b",
    positivo="#6fa06f", negativo="#d4614c", aviso="#dcae44",
    titular="Fraunces",
    categorias=("#b8532f", "#3d6b40", "#c39320", "#8a5a7a", "#6b6f9c", "#44807e", "#d1863c", "#a83a2c"),
    motivo="grano",
    tema="terra",
)

# ------------------------------------------------------- 11. IA
# Blanco roto o negro profundo con jade y azul grisáceo. Ordenado, inteligente, sin ruido.
# Fondo: rejilla de puntos.
IA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f8f9f8", surface="#ffffff", surface_2="#eff2f1",
    surface_3="#e6eae9", borde="#e0e5e3", borde_fuerte="#c2cac7",
    ink="#161c1a", ink_soft="#48534f", muted="#7e8a86",
    acento="#14806a", acento_suave="#dcefe9", acento_ink="#ffffff",
    positivo="#14806a", negativo="#b04a44", aviso="#a8802c",
    titular="Archivo",
    categorias=("#14806a", "#5b7f96", "#8a7fa8", "#a8794f", "#4f8a7a", "#7a8a4f", "#96666f", "#56708a"),
    motivo="puntos",
    tema="ia",
)
IA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#0a0d0c", surface="#121716", surface_2="#1a201e",
    surface_3="#212826", borde="#232b29", borde_fuerte="#3a4442",
    ink="#eef2f0", ink_soft="#aeb8b4", muted="#7b8481",
    acento="#35b894", acento_suave="#0e2620", acento_ink="#0a0d0c",
    positivo="#35b894", negativo="#d0736c", aviso="#c9a24f",
    titular="Archivo",
    categorias=("#14806a", "#5b7f96", "#8a7fa8", "#a8794f", "#4f8a7a", "#7a8a4f", "#96666f", "#56708a"),
    motivo="puntos",
    tema="ia",
)

# ---------------------------------------------------- 12. FOCUS
# Azul tinta, lavanda y celeste sobre blanco. Un estudio personal para construir proyectos y rutinas.
# Fondo: cuadrícula de cuaderno.
FOCUS_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f7f8fc", surface="#ffffff", surface_2="#edf0f9",
    surface_3="#e4e9f5", borde="#dbe1f0", borde_fuerte="#b8c2de",
    ink="#131a33", ink_soft="#414a6b", muted="#7a83a3",
    acento="#2b3f8f", acento_suave="#e3e8fa", acento_ink="#ffffff",
    positivo="#2e8f6f", negativo="#c04a5e", aviso="#b98a26",
    titular="Archivo",
    categorias=("#2b3f8f", "#8f8ae0", "#4fa8e0", "#59c39c", "#e0b45c", "#e8788a", "#6f7fb5", "#45c0c0"),
    motivo="cuadricula",
    tema="focus",
)
FOCUS_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#0a0d1a", surface="#131829", surface_2="#1a2036",
    surface_3="#202742", borde="#252d47", borde_fuerte="#3d4869",
    ink="#eceff8", ink_soft="#adb4cc", muted="#79809b",
    acento="#7f8fe8", acento_suave="#171d3a", acento_ink="#0a0d1a",
    positivo="#59c39c", negativo="#e8788a", aviso="#e0b45c",
    titular="Archivo",
    categorias=("#2b3f8f", "#8f8ae0", "#4fa8e0", "#59c39c", "#e0b45c", "#e8788a", "#6f7fb5", "#45c0c0"),
    motivo="cuadricula",
    tema="focus",
)

# -------------------------------------------------- 13. GALAXIA
# Vacío profundo y luz de estrella. La racha no es un número: es una constelación que se va encendiendo.
# Fondo: polvo de estrellas.
GALAXIA_CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f6f5fb", surface="#ffffff", surface_2="#ecebf7",
    surface_3="#e2e0f2", borde="#dedcf0", borde_fuerte="#b6b2dd",
    ink="#14162e", ink_soft="#43476f", muted="#7b7fa3",
    acento="#3b3a8f", acento_suave="#e6e5f9", acento_ink="#ffffff",
    positivo="#17998a", negativo="#cf4a63", aviso="#b8862a",
    titular="Marcellus",
    categorias=("#6f8fe8", "#5fd3a8", "#ffc978", "#ff8fc0", "#a97fe8", "#66d8f0", "#ff9d5c", "#f0616f"),
    motivo="estrellas",
    tema="galaxia",
)
GALAXIA_OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#05060f", surface="#0c0f22", surface_2="#131735",
    surface_3="#1a1f45", borde="#1e2450", borde_fuerte="#38408a",
    ink="#eef0ff", ink_soft="#aeb3dd", muted="#767ba8",
    acento="#ffc978", acento_suave="#2a2038", acento_ink="#05060f",
    positivo="#6fe0c0", negativo="#ff7a92", aviso="#ffd98a",
    titular="Marcellus",
    categorias=("#6f8fe8", "#5fd3a8", "#ffc978", "#ff8fc0", "#a97fe8", "#66d8f0", "#ff9d5c", "#f0616f"),
    motivo="estrellas",
    tema="galaxia",
)


ESTILOS: tuple[Estilo, ...] = (
    Estilo(
        clave="elegante",
        nombre="Elegante",
        descripcion="Blanco roto, negro tinta y mucho aire. Sin un solo color.",
        clara=ELEGANTE_CLARA,
        oscura=ELEGANTE_OSCURA,
    ),
    Estilo(
        clave="ochentas",
        nombre="80s",
        descripcion="Synthwave: noche, magenta electrico y cian. Brilla sin ser un juguete.",
        clara=OCHENTAS_CLARA,
        oscura=OCHENTAS_OSCURA,
    ),
    Estilo(
        clave="premium",
        nombre="Premium",
        descripcion="Borgona sobre carbon, con un filo dorado. Caro sin gritarlo.",
        clara=PREMIUM_CLARA,
        oscura=PREMIUM_OSCURA,
    ),
    Estilo(
        clave="minimalista",
        nombre="Minimalista",
        descripcion="Blanco calido, niebla y un unico acento salvia. Todo susurra.",
        clara=MINIMALISTA_CLARA,
        oscura=MINIMALISTA_OSCURA,
    ),
    Estilo(
        clave="natural",
        nombre="Natural",
        descripcion="Bosque, salvia y miel sobre crema. Los habitos crecen.",
        clara=NATURAL_CLARA,
        oscura=NATURAL_OSCURA,
    ),
    Estilo(
        clave="solar",
        nombre="Solar Pop",
        descripcion="Coral, mango y menta. Cumplir algo se siente bien.",
        clara=SOLAR_CLARA,
        oscura=SOLAR_OSCURA,
    ),
    Estilo(
        clave="electric",
        nombre="Electric Studio",
        descripcion="Violeta y neon sobre azul noche. Para empujar objetivos.",
        clara=ELECTRIC_CLARA,
        oscura=ELECTRIC_OSCURA,
    ),
    Estilo(
        clave="isla",
        nombre="Isla Activa",
        descripcion="Turquesa, menta y mango. Bienestar en movimiento.",
        clara=ISLA_CLARA,
        oscura=ISLA_OSCURA,
    ),
    Estilo(
        clave="aurora",
        nombre="Aurora",
        descripcion="Noche, cian y lavanda. Futurista y tranquilo.",
        clara=AURORA_CLARA,
        oscura=AURORA_OSCURA,
    ),
    Estilo(
        clave="terra",
        nombre="Terra Bold",
        descripcion="Terracota, bosque y mostaza. Una libreta premium.",
        clara=TERRA_CLARA,
        oscura=TERRA_OSCURA,
    ),
    Estilo(
        clave="ia",
        nombre="AI Workspace",
        descripcion="Jade y grafito, muy ordenado. Cabe mas en cada pantalla.",
        clara=IA_CLARA,
        oscura=IA_OSCURA,
    ),
    Estilo(
        clave="focus",
        nombre="Focus Studio",
        descripcion="Azul tinta y lavanda. Un estudio para construir cosas.",
        clara=FOCUS_CLARA,
        oscura=FOCUS_OSCURA,
    ),
    Estilo(
        clave="galaxia",
        nombre="Galaxia",
        descripcion="Vacio y luz de estrella. Las rachas son constelaciones.",
        clara=GALAXIA_CLARA,
        oscura=GALAXIA_OSCURA,
    ),
)

POR_CLAVE: dict[str, Estilo] = {uno.clave: uno for uno in ESTILOS}

ESTILO_POR_OMISION = "elegante"
"""El que sale si nunca tocas el ajuste. Lo eligio el usuario."""


ANTIGUOS = {
    # "reto" se llamaba asi antes del rediseno de los trece temas; ahora es
    # "80s", con otra paleta pero la misma idea.
    #
    # ESTO NO SE BORRA NUNCA. La clave vive en el archivo de ajustes de cada
    # persona: sin el alias, quien tuviera "reto" guardado abriria un dia la
    # aplicacion en blanco y negro sin entender por que. Cuesta dos lineas y
    # evita un "se me ha cambiado solo" que nadie sabria explicar.
    "reto": "ochentas",
}


def estilo_por_clave(clave: str) -> Estilo:
    """El estilo guardado, o el de por omision si el ajuste esta raro.

    NO FALLA A PROPOSITO, al reves que las monedas: equivocarse aqui solo cuesta
    ver la aplicacion de otro color, nunca un dato mal. Y una aplicacion que no
    abre porque el ajuste del tema esta corrupto seria mucho peor que una que
    abre en blanco y negro.
    """
    if not isinstance(clave, str):
        return POR_CLAVE[ESTILO_POR_OMISION]
    limpia = clave.strip().lower()
    limpia = ANTIGUOS.get(limpia, limpia)
    return POR_CLAVE.get(limpia, POR_CLAVE[ESTILO_POR_OMISION])


# ----------------------------------------------------------------------------
# Los seis pasteles del horario semanal
# ----------------------------------------------------------------------------
#
# LOS PIDIÓ EL USUARIO para el horario: "cuadrados de colores y/o las letras,
# para que sea más visible; colores pasteles, no muy fuertes". Sirven para
# marcar bloques de un vistazo sin tener que leer lo que pone en cada casilla.
#
# EL TONO NO CAMBIA NUNCA; LO QUE CAMBIA ES EL CARÁCTER. El verde es verde en
# los trece temas, porque el color aquí no es decoración: es una MARCA que tú le
# pones a una hora, y si cambiara de tono habría que reaprender la rejilla cada
# vez. Lo que sí cambia de un tema a otro es cuánta saturación y cuánta luz
# tienen: apagados y casi grises en Elegante, encendidos en 80s.
#
# LO PIDIÓ ÉL AL VERLO ROTO: los seis eran los mismos en todos los estilos, y
# estaban calibrados para fondos neutros cálidos. Sobre el azul noche de Galaxia
# se volvían barro. Sus palabras: "de verdad son horribles; para cada tema
# deberían ser diferentes".
#
# SE CALCULAN Y NO SE ESCRIBEN A MANO. Serían ciento cincuenta y seis colores
# sueltos, y nadie podría decir por qué uno vale y el de al lado no. Así son
# cuatro números por tema —saturación y luz, en claro y en oscuro— que se leen
# como lo que son: el carácter del tema aplicado a seis tonos fijos.

_TONOS_DEL_HORARIO = {
    "verde": 145,
    "azul": 210,
    "lila": 265,
    "rosa": 335,
    "melocoton": 25,
    "amarillo": 48,
}

# Por tema: (saturación y luz en claro, saturación y luz en oscuro), en %.
_CARACTER = {
    "elegante": (10, 91, 8, 24),
    "ochentas": (72, 84, 58, 34),
    "premium": (22, 89, 22, 26),
    "minimalista": (14, 92, 10, 25),
    "natural": (34, 87, 26, 26),
    "solar": (62, 86, 46, 32),
    "electric": (66, 85, 52, 33),
    "isla": (48, 88, 40, 30),
    "aurora": (44, 88, 40, 31),
    "terra": (40, 86, 32, 28),
    "ia": (20, 91, 16, 25),
    "focus": (38, 89, 34, 30),
    "galaxia": (52, 87, 44, 30),
}
_CARACTER_POR_OMISION = (30, 88, 26, 28)


def _de_hsl(tono: int, saturacion: int, luz: int) -> str:
    """Un color en hexadecimal, a partir de tono, saturación y luz."""
    s, l = saturacion / 100, luz / 100
    c = (1 - abs(2 * l - 1)) * s
    x = c * (1 - abs((tono / 60) % 2 - 1))
    m = l - c / 2
    trozos = [
        (c, x, 0.0), (x, c, 0.0), (0.0, c, x),
        (0.0, x, c), (x, 0.0, c), (c, 0.0, x),
    ][int(tono // 60) % 6]
    return "#" + "".join(f"{round((uno + m) * 255):02x}" for uno in trozos)


def pasteles_de(clave: str, *, oscuro: bool) -> dict[str, str]:
    """Los seis pasteles de un tema, en su versión clara u oscura."""
    s_claro, l_claro, s_oscuro, l_oscuro = _CARACTER.get(clave, _CARACTER_POR_OMISION)
    s, l = (s_oscuro, l_oscuro) if oscuro else (s_claro, l_claro)
    return {nombre: _de_hsl(tono, s, l) for nombre, tono in _TONOS_DEL_HORARIO.items()}


PASTELES = tuple(_TONOS_DEL_HORARIO)
"""Los seis nombres, que es lo que se guarda en la base y no cambia nunca."""

_TINTA_SOBRE_PASTEL_CLARO = "#2b2a28"
_TINTA_SOBRE_PASTEL_OSCURO = "#eceae5"


def pastel(nombre: str, paleta: Paleta) -> str:
    """El color de ese pastel, en el tema y la versión que toquen.

    REVIENTA SI EL NOMBRE NO EXISTE, al revés que los colores de categoría: un
    pastel desconocido en el horario significa que alguien escribió mal una
    clave en el código, no que haya un dato raro guardado.
    """
    if nombre not in _TONOS_DEL_HORARIO:
        raise ValueError(
            f"«{nombre}» no es uno de los pasteles del horario; "
            f"están en interfaz/estilo.py"
        )
    oscuro = paleta.modo is ft.ThemeMode.DARK
    return pasteles_de(paleta.tema, oscuro=oscuro)[nombre]


def tinta_sobre_pastel(paleta: Paleta) -> str:
    """El color del texto que va ENCIMA de una casilla pintada.

    No vale el `ink` de la paleta: en oscuro es casi blanco y sobre un pastel
    claro no se leería, y en claro es oscuro y sobre un pastel oscuro tampoco.
    """
    if paleta.modo is ft.ThemeMode.DARK:
        return _TINTA_SOBRE_PASTEL_OSCURO
    return _TINTA_SOBRE_PASTEL_CLARO


def paleta_para(
    nombre: str, *, sistema_oscuro: bool, estilo: str = ESTILO_POR_OMISION
) -> Paleta:
    """La paleta que toca: la del ESTILO elegido, en su versión clara u oscura.

    SON DOS AJUSTES INDEPENDIENTES y funcionan como uno espera: el estilo dice
    de qué colores es la aplicación, y el tema dice si esos colores van en su
    versión clara o en la oscura. Los cinco estilos tienen las dos.

    "sistema" (y cualquier valor raro, por si el ajuste estuviera corrupto) sigue
    a Windows: es lo que el usuario ya decidió una vez para todo su ordenador, y
    equivocarse ahí solo cuesta un tema feo, no un dato mal guardado.
    """
    elegido = estilo_por_clave(estilo)
    if nombre == "claro":
        return elegido.clara
    if nombre == "oscuro":
        return elegido.oscura
    return elegido.paleta(oscuro=sistema_oscuro)
