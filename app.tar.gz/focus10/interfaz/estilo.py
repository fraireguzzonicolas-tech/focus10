"""Los colores y las medidas de Focus10.

POR QUÉ ESTÁN TODOS AQUÍ: si cada pantalla eligiera sus colores a mano, en tres
pantallas habría cinco grises distintos y nadie sabría cuál es el bueno. Aquí
está la lista completa, y las pantallas solo piden "el color del texto apagado".
Es también lo que ha permitido cambiar el aspecto de las nueve pantallas de una
vez, tocando solo este archivo y componentes.py.

DE DÓNDE SALE ESTA PALETA: del rediseño que aprobó el usuario. Se diseñó en
oklch —que reparte la claridad como la ve el ojo, no como la calcula la
pantalla— y se convirtió a hexadecimal aquí, porque es lo que entiende Flet. Por
eso los grises son CÁLIDOS y no azulados: comparten el mismo tono que el papel
del fondo, y eso es lo que hace que la pantalla se lea como una página y no como
un panel de control.

LAS TRES REGLAS DE COLOR QUE SOSTIENEN EL DISEÑO:

  1. El verde del acento manda. Los dos acentos —el verde y el barro— comparten
     claridad y croma, y solo cambian de tono: por eso nunca compiten.
  2. El verde y el rojo son SOLO para cifras y detalles pequeños, nunca para
     fondos grandes. Dos botones enormes de color pleno gritan y no dejan ver lo
     importante, que son los números.
  3. Separar por TONO y por ESPACIO antes que por línea. Un borde de un píxel en
     cada tarjeta se ve barato; una sombra muy suave y aire alrededor, no.

EL ACENTO NO SE PERSONALIZA por ahora, por decisión del usuario: la aplicación es
bonita porque está decidida, no porque se pueda tocar. Los colores de cada
tema (los catorce) están en temas.py; aquí, la forma de una Paleta y lo que es
igual en todos.

AQUÍ SOLO HAY COLORES Y MEDIDAS. Las piezas que los usan (tarjetas, botones,
campos) están en componentes.py.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import flet as ft

from ..dominio.habito import COLORES


FUENTE = "Schibsted"
"""La de la interfaz. Todo lo que se lee de corrido, en todos los estilos."""


@dataclass(frozen=True)
class Paleta:
    """Un juego completo de colores. Hay dos: la clara y la oscura."""

    modo: ft.ThemeMode

    canvas: str
    """El fondo de la ventana, detrás de las tarjetas."""

    surface: str
    """El fondo de una tarjeta."""

    surface_2: str
    """Un escalón más marcado: botones secundarios, cabeceras de tabla."""

    surface_3: str
    borde: str
    borde_fuerte: str

    ink: str
    """El texto principal."""

    ink_soft: str
    muted: str
    """Texto de apoyo: etiquetas, ayudas, lo que no hay que leer."""

    acento: str
    acento_suave: str
    acento_ink: str

    positivo: str
    negativo: str
    aviso: str

    titular: str = "Instrument"
    """La tipografía de los titulares y las cifras de ESTE estilo.

    VA EN LA PALETA Y NO EN UNA CONSTANTE DEL MÓDULO, y ese es todo el truco que
    permite cambiar de estilo: cada pantalla ya recibe una paleta para saber de
    qué color pintar, así que ahora también sabe con qué letra escribir. Sin
    esto, cambiar la tipografía habría obligado a que cada control consultara un
    ajuste por su cuenta.
    """

    categorias: tuple[str, ...] = ()
    """Los ocho colores de categoría de ESTE tema, en el orden de dominio.COLORES.

    ANTES ERAN GLOBALES: un solo diccionario con el mismo azul para todos los
    estilos. Lo pidió el usuario al rediseñar los temas —«categorías
    diferenciables, pero adaptadas a la paleta»— y tiene razón: un azul de
    hábito pensado para papel crema chirría sobre un fondo synthwave.

    VACÍO CAE A LOS DE SIEMPRE. Un tema a medio escribir no puede dejar los
    hábitos sin color: se dibujarían todos iguales y no se sabría cuál es cuál.
    """

    tema: str = ""
    """La clave del tema al que pertenece esta paleta.

    HACE FALTA PARA LOS PASTELES DEL HORARIO, que se calculan a partir del
    carácter del tema en vez de escribirse uno a uno. Sin esto habría que
    pasarle la clave a cada sitio que dibuja una casilla.
    """

    motivo: str = "nada"
    """El dibujo de fondo del tema. Ver interfaz/motivo_fondo.py.

    UNO POR TEMA Y PEQUEÑO. Las reglas están en ese archivo; aquí solo se dice
    cuál toca. "nada" es una respuesta legítima: Elegante no lleva ninguno, y
    eso es parte de lo que lo hace Elegante.
    """

    radio: int = 16
    """Lo redondeada que es una tarjeta en ESTE tema.

    LOS TRES CAMPOS DE ABAJO SON DE FORMA Y NO DE COLOR, y por eso estan aqui y
    no en una constante del modulo: sin ellos, Terra Bold y Minimalista solo se
    distinguian por el tono y la letra, aunque su ficha dijera que uno lleva una
    cinta de 2 px y el otro nada. Un tema es tambien una forma.
    """

    filete: int = 0
    """El grosor del borde de la tarjeta, en pixeles. 0 es SIN BORDE.

    CERO NO ES UN BORDE TRANSPARENTE: se deja de poner borde. Un borde de cero
    pixeles sigue contando en la medida en algunos motores y descoloca el
    contenido un pelo, que es justo lo que no se ve hasta que esta puesto.
    """

    sombra: bool = True
    """Si las tarjetas de este tema llevan sombra.

    EN EL TEMA OSCURO NO SE PONE NUNCA, diga lo que diga esto: una sombra negra
    sobre un fondo casi negro no se ve. Ver sombra_tarjeta.
    """

    sombra_de_color: bool = False
    """Si la sombra sale del acento del tema en vez de ser gris.

    SOLO LA LLEVA SOLAR POP, y es de lo que más lo define: una sombra coral hace
    que la tarjeta parezca iluminada por un sol, no apoyada sobre una mesa. En
    un tema sobrio quedaría a juguete, por eso los demás siguen en gris.
    """

    fuente: str = FUENTE
    """La del texto normal. ES LA MISMA EN TODOS LOS TEMAS a propósito.

    El texto de la interfaz se lee durante horas y su trabajo es no llamar la
    atención; lo que le da carácter a un estilo son los titulares y el color.
    Cambiar también la letra pequeña haría cinco aplicaciones distintas de leer
    en vez de una aplicación con cinco trajes.
    """


# ---------------------------------------------------------------------------


def _color_de_categoria(paleta: "Paleta", nombre: str) -> str:
    """El color de una categoría en ESTE tema.

    Se escribe fuera de la clase porque necesita COLORES_DE_PARTIDA, que se
    define más abajo; dentro quedaría una referencia hacia adelante.
    """
    orden = COLORES
    if paleta.categorias and nombre in orden:
        return paleta.categorias[orden.index(nombre)]
    # NO FALLA A PROPÓSITO: un color raro guardado solo debe costar un hábito de
    # otro color, nunca impedir que la pantalla se dibuje.
    return COLORES_DE_PARTIDA.get(nombre, COLORES_DE_PARTIDA["azul"])


Paleta.color_de = _color_de_categoria


# LAS PALETAS DE MUESTRA, clara y oscura. LA APLICACIÓN NO LAS USA: elige la
# suya con temas.paleta_para (tema y estilo). Estas dos son una paleta fija que usan
# los tests y las herramientas de revisión, para que un cambio de colores en un
# tema no mueva lo que se está probando.
CLARA = Paleta(
    modo=ft.ThemeMode.LIGHT,
    canvas="#f9f7f3",
    surface="#ffffff",
    surface_2="#f3f0ea",
    surface_3="#eae7e2",
    borde="#e0deda",
    borde_fuerte="#c7c4be",
    ink="#221c16",
    ink_soft="#57514c",
    muted="#8a8580",
    acento="#367855",
    acento_suave="#dff0e5",
    acento_ink="#ffffff",
    positivo="#357950",
    negativo="#a85550",
    aviso="#9b6142",
)

OSCURA = Paleta(
    modo=ft.ThemeMode.DARK,
    canvas="#110e0a",
    surface="#1d1913",
    surface_2="#26221c",
    surface_3="#302c25",
    borde="#2f2b25",
    borde_fuerte="#49443d",
    ink="#efece7",
    ink_soft="#b4b1aa",
    muted="#7d7a74",
    acento="#6cb78d",
    acento_suave="#1a3124",
    acento_ink="#110e0a",
    positivo="#78c192",
    negativo="#df7f78",
    aviso="#dfa36d",
)


# Los tres valores que puede tener el ajuste del tema, en el orden en que se
# enseñan en Configuración.
TEMAS = (
    ("sistema", "Seguir a Windows"),
    ("claro", "Claro"),
    ("oscuro", "Oscuro"),
)

# LOS OCHO COLORES DE RESPALDO. Cada tema trae los suyos (ver Paleta.categorias);
# éstos son los que se usan si un tema no los define, y los que se usaban antes
# de que los temas los tuvieran.
#
# Las claves son las del dominio
# (dominio/habito.py), que guarda "azul" y no un color: así la paleta se puede
# cambiar sin tocar un solo dato guardado.
#
# LOS OCHO COMPARTEN CLARIDAD Y CROMA y solo cambian de tono. No es un detalle:
# con claridades distintas, un hábito parecería más importante que otro sin que
# nadie lo haya decidido. Y al ser tonos medios se leen igual sobre el fondo
# claro y sobre el oscuro.
COLORES_DE_PARTIDA = {
    "azul": "#2e9dd3",
    "verde": "#53a768",
    "ambar": "#b58b22",
    "rosa": "#ca709d",
    "violeta": "#9e7fd3",
    "cian": "#00a8b0",
    "naranja": "#cc7c40",
    "rojo": "#d4716b",
}


def con_opacidad(color: str, fraccion: float) -> str:
    """El mismo color, más o menos transparente. De 0 a 1.

    Está aquí y no en los componentes porque es una operación sobre colores, y
    los colores viven en este archivo. Se usa para rellenar el círculo de un
    hábito según lo que lleves hecho.
    """
    return ft.Colors.with_opacity(max(0.0, min(1.0, fraccion)), color)


# Blanco puro. No va dentro de la Paleta porque no cambia con el tema: es el
# texto que se pone ENCIMA de un color fuerte (el rojo de un boton de borrar),
# donde el color del tema no serviria.
BLANCO = "#ffffff"


# ---------------------------------------------------------------------------
# Tipografía
# ---------------------------------------------------------------------------

# Las fuentes viven DENTRO del proyecto y no se piden a internet. Dos razones:
# la aplicación funciona sin conexión (solo Inversiones sale fuera, y con
# permiso), y así PyInstaller las puede empaquetar en la última fase. Son de
# licencia abierta (SIL OFL), así que se pueden distribuir con el programa.
CARPETA_FUENTES = Path(__file__).resolve().parents[3] / "assets" / "fuentes"

RUTA_LOGO = CARPETA_FUENTES.parent / "icon.png"
"""El logo de Focus1%, el mismo del icono de la aplicación. Lo usa la imagen
para compartir fuera; si faltara, esa imagen lleva el nombre escrito."""

RUTA_ICONO_WINDOWS = CARPETA_FUENTES.parent / "focus10.ico"
"""El mismo logo en .ico, que es lo único que acepta Windows para la ventana y
la barra de tareas. Lo hace herramientas/hacer_iconos.py."""

RUTA_LANZADOR = CARPETA_FUENTES.parents[1] / "abrir.py"
"""El archivo que abre Focus en la PC. El ícono anclado lo vuelve a ejecutar."""

ARCHIVOS_DE_FUENTE = {
    # La del texto, común a todos los estilos.
    FUENTE: CARPETA_FUENTES / "SchibstedGrotesk.ttf",
    # Y una titular por estilo. SE REGISTRAN TODAS AL ABRIR, no solo la del
    # estilo elegido: cambiar de estilo tiene que ser instantáneo, y bajar una
    # fuente a mitad de sesión sería un parpadeo raro. Entre las doce suman
    # 1,3 MB.
    "Instrument": CARPETA_FUENTES / "InstrumentSerif-Regular.ttf",
    "Poppins": CARPETA_FUENTES / "Poppins.ttf",
    "Jost": CARPETA_FUENTES / "Jost.ttf",
    "Outfit": CARPETA_FUENTES / "Outfit.ttf",
    "BarlowCondensed": CARPETA_FUENTES / "BarlowCondensed.ttf",
    # Las seis del rediseno de los trece temas. Todas de licencia abierta y
    # ligeras: entre las doce del proyecto suman 1,3 MB.
    "Orbitron": CARPETA_FUENTES / "Orbitron.ttf",
    "CormorantGaramond": CARPETA_FUENTES / "CormorantGaramond.ttf",
    "Fraunces": CARPETA_FUENTES / "Fraunces.ttf",
    "Sora": CARPETA_FUENTES / "Sora.ttf",
    "Archivo": CARPETA_FUENTES / "Archivo.ttf",
    "Marcellus": CARPETA_FUENTES / "Marcellus.ttf",
}


def fuentes_disponibles() -> dict[str, str]:
    """Las fuentes que de verdad están en el disco, listas para registrarlas.

    Se comprueba que el archivo exista en vez de darlo por hecho: si alguien
    mueve la carpeta o el empaquetado se deja un archivo, la aplicación tiene
    que abrir igual con la fuente suplente, no quedarse en negro por una tilde
    tipográfica.
    """
    return {
        nombre: str(ruta)
        for nombre, ruta in ARCHIVOS_DE_FUENTE.items()
        if ruta.is_file()
    }


# La escala. Son los tamaños del rediseño, y son POCOS a propósito: con quince
# tamaños distintos no hay jerarquía, hay ruido.
TITULAR_GRANDE = 40
"""El nombre de la pantalla. En serif."""

TITULAR = 30
CIFRA_GRANDE = 44
"""Los números que son el motivo de abrir la pantalla. En serif."""

CIFRA = 26
SUBTITULAR = 20
"""El escalón que faltaba entre el título de una tarjeta (16) y el de una
pantalla (30).

HACÍA FALTA PARA ENTRENAR: el nombre del ejercicio es lo que buscas con la vista
cuando levantas la cabeza entre serie y serie, con el móvil en el suelo o en un
banco. A 16 no se lee desde ahí, y a 30 seis tarjetas seguidas se comen la
pantalla y hay que hacer scroll para nada."""

TEXTO_TARJETA = 16
"""El título de una tarjeta."""

TEXTO = 14
TEXTO_APOYO = 12.5
ROTULO = 11
"""Los rótulos en mayúsculas pequeñas, con mucho espaciado entre letras."""


# ---------------------------------------------------------------------------
# Medidas
# ---------------------------------------------------------------------------

RADIO_BOTON = 999
"""Los botones son cápsulas. Es lo que más cambia el aire de la aplicación con
menos código, y separa de un vistazo lo que se pulsa de lo que se lee."""

RADIO_CAMPO = 10
RELLENO_TARJETA = 24
ALTO_BOTON = 38
_ancho_de_la_pantalla: float | None = None
"""Lo ancha que es la ventana ahora mismo, o None si aún no se sabe.

POR QUÉ UN DATO GLOBAL, que normalmente es mala idea: porque esto SÍ es global.
La aplicación tiene una ventana y una sola, y su ancho es el mismo para todo lo
que se dibuje dentro. La alternativa era pasar el ancho como parámetro por los
veinticinco archivos de interfaz hasta llegar a la tabla, y eso son veinticinco
sitios donde olvidarse de pasarlo.

LO PONE app.py EN CADA MONTAJE, que es el único sitio que habla con la ventana.

SI VALE None SE DIBUJA COMO EN UN ORDENADOR: al arrancar, Flet puede no haber
medido todavía, y dar por hecho "móvil" haría parpadear la aplicación de
escritorio en cada apertura.
"""


ANCHO_SUPUESTO_DE_MOVIL = 375
"""Con qué ancho se dibuja un móvil mientras Flet no dice el de verdad.

375 es el de un teléfono pequeño: si el real es mayor, todo entra igual; al
revés —dar por hecho una pantalla grande— es lo que rompía el dibujo.
"""

MOVILES = (ft.PagePlatform.ANDROID, ft.PagePlatform.IOS)


def ancho_de(pagina) -> float | None:
    """El ancho con el que hay que dibujar. En un teléfono, el de un teléfono.

    ESTE ES EL ARREGLO DE UN FALLO QUE DURÓ SEMANAS EN EL MÓVIL: la aplicación
    se dibujaba en el teléfono con la versión de escritorio —el nombre del
    ejercicio salía escrito letra por letra, de arriba abajo— y por eso NADA de
    lo escrito para móviles llegaba a ejecutarse.

    LA CAUSA, MEDIDA EN EL TELÉFONO DEL USUARIO: su pantalla mide 1080 píxeles
    físicos y 384 puntos (densidad 450). 384 está muy por debajo del corte de
    ANCHO_ESTRECHO, así que el corte tendría que haberse cumplido siempre, y no
    se cumplía nunca. El ancho que llega en Android no viene en las mismas
    unidades en las que se decide, y la aplicación acababa creyendo que tenía
    una pantalla de escritorio.

    POR ESO NO SE MIRA EL NÚMERO EN UN TELÉFONO: un teléfono es un teléfono,
    lo diga la medida o no. En el escritorio sí manda la medida, porque ahí es
    fiable y ahí sí hay ventanas de todos los tamaños. Mientras Windows no haya
    medido se responde que no se sabe, para que la ventana no arranque estrecha
    y pegue un salto al primer dibujado.

    LO QUE ESTO CUESTA: una tablet Android se dibujará como un teléfono. Es un
    aparato que el usuario no tiene y que nadie ha probado; entre dibujarla
    algo angosta y dejar rotos todos los teléfonos, se elige esto.
    """
    if getattr(pagina, "platform", None) in MOVILES:
        return ANCHO_SUPUESTO_DE_MOVIL
    return getattr(pagina, "width", None) or None


def fijar_ancho(ancho: float | None) -> None:
    """Lo llama app.py al montar la ventana. Nadie más debería."""
    global _ancho_de_la_pantalla
    _ancho_de_la_pantalla = ancho


def pantalla_estrecha() -> bool:
    """Si hay que dibujar como en un móvil."""
    return bool(_ancho_de_la_pantalla) and _ancho_de_la_pantalla < ANCHO_ESTRECHO


def lado_de_casilla(maximo: int, *, espacio: int = 6, margen: int | None = None) -> int:
    """El lado de una casilla de un calendario de siete columnas.

    EN EL MÓVIL LOS SIETE DÍAS TIENEN QUE CABER SIN DESLIZAR, y lo pidió así el
    usuario. Con casillas fijas de 82 u 88 puntos se veían tres días y medio y
    el resto quedaba cortado. Se reparte entre los siete lo que queda de
    pantalla, quitando el relleno de la ventana y el de la tarjeta.

    `margen`: lo que no es calendario, si no es una tarjeta de una sección
    (MARGEN_CALENDARIO_MOVIL). Una ventanita tiene otros márgenes: ver
    resumen_mensual.MARGEN_VENTANA_MOVIL.

    UNA SOLA CUENTA PARA TODOS LOS CALENDARIOS: si cada uno la hiciera a su
    manera, arreglar un margen dejaría otro calendario cortado.
    """
    if not pantalla_estrecha():
        return maximo
    if margen is None:
        margen = MARGEN_CALENDARIO_MOVIL
    sitio = _ancho_de_la_pantalla - margen - espacio * 6
    return max(28, min(maximo, int(sitio // 7)))


MARGEN_CALENDARIO_MOVIL = 2 * 12 + 2 * RELLENO_TARJETA + 8
"""Lo que no es calendario: el relleno de la ventana en el móvil (12 por lado),
el de la tarjeta, y 8 de holgura para que una barra de desplazamiento no
empuje el domingo fuera."""


def ancho_de_grafico(maximo: int, *, margenes: int = 64) -> int:
    """Lo ancho que puede dibujarse un gráfico sin salirse de la pantalla.

    LOS GRÁFICOS DE ESTA APLICACIÓN SE DIBUJAN A MANO sobre un lienzo, y un
    lienzo necesita un ancho concreto: no puede "estirarse hasta lo que haya"
    como una caja normal, porque tiene que saber dónde cae cada punto.

    Así que se le da el mejor ancho posible: el que pidió, o lo que quepa si es
    menos. El suelo de 240 evita que en una ventana absurdamente estrecha el
    gráfico se quede en una raya.
    """
    if not _ancho_de_la_pantalla:
        return maximo
    return max(240, min(maximo, int(_ancho_de_la_pantalla) - margenes))


ANCHO_ESTRECHO = 600
"""Por debajo de este ancho, la aplicación se dibuja como en un móvil.

POR QUÉ 600 Y NO 375: 375 es lo que mide un móvil, pero el corte no debe estar
en el caso justo. Una tableta en vertical, o media ventana en un portátil, están
más cerca de un móvil que de un escritorio: ahí la barra lateral ya estorba más
de lo que ayuda. 600 es donde deja de compensar gastar 236 puntos en un menú.

NO ES UNA MEDIDA DE APARATO, es una medida de sitio disponible. La misma ventana
cruza este número al hacerla pequeña, y la aplicación se recoloca.
"""

ANCHO_LATERAL = 236
DENSIDAD = 26
"""La separación vertical entre bloques de una pantalla."""


def sombra_tarjeta(paleta: Paleta) -> ft.BoxShadow | None:
    """La sombra de una tarjeta. Muy suave, y ninguna en el tema oscuro.

    En oscuro no se pone: una sombra negra sobre un fondo casi negro no se ve, y
    lo que separa ahí es el escalón de tono entre el lienzo y la superficie. Es
    la misma decisión que en el rediseño.
    """
    if paleta.modo is ft.ThemeMode.DARK or not paleta.sombra:
        return None
    return ft.BoxShadow(
        blur_radius=20,
        spread_radius=-4,
        # EL COLOR VA AL 16 % Y EL GRIS AL 7 %, y no es un descuido: con la
        # misma opacidad, un coral se ve mucho menos que un casi negro, y una
        # sombra de color que no se nota es una sombra gris con otro nombre.
        color=(
            ft.Colors.with_opacity(0.16, paleta.acento)
            if paleta.sombra_de_color
            else ft.Colors.with_opacity(0.07, "#221c16")
        ),
        offset=ft.Offset(0, 6),
    )


# ----------------------------------------------------------------------------
# Los seis pasteles del horario semanal
# ----------------------------------------------------------------------------
#
# LOS PIDIÓ EL USUARIO para el horario: "cuadrados de colores y/o las letras,
# para que sea más visible; colores pasteles, no muy fuertes". Sirven para
# marcar bloques de un vistazo sin tener que leer lo que pone en cada casilla.
#
# EL TONO NO CAMBIA NUNCA; LO QUE CAMBIA ES EL CARÁCTER. El verde es verde en
# los catorce temas, porque el color aquí no es decoración: es una MARCA que tú le
# pones a una hora, y si cambiara de tono habría que reaprender la rejilla cada
# vez. Lo que sí cambia de un tema a otro es cuánta saturación y cuánta luz
# tienen: apagados y casi grises en Elegante, encendidos en 80s.
#
# LO PIDIÓ ÉL AL VERLO ROTO: los seis eran los mismos en todos los estilos, y
# estaban calibrados para fondos neutros cálidos. Sobre el azul noche de Galaxia
# se volvían barro. Sus palabras: "de verdad son horribles; para cada tema
# deberían ser diferentes".
#
# SE CALCULAN Y NO SE ESCRIBEN A MANO. Serían ciento cincuenta y seis colores
# sueltos, y nadie podría decir por qué uno vale y el de al lado no. Así son
# cuatro números por tema —saturación y luz, en claro y en oscuro— que se leen
# como lo que son: el carácter del tema aplicado a seis tonos fijos.

_TONOS_DEL_HORARIO = {
    "verde": 145,
    "azul": 210,
    "lila": 265,
    "rosa": 335,
    "melocoton": 25,
    "amarillo": 48,
}

# Por tema: (saturación y luz en claro, saturación y luz en oscuro), en %.
_CARACTER = {
    "elegante": (10, 91, 8, 24),
    "ochentas": (72, 84, 58, 34),
    "premium": (22, 89, 22, 26),
    "minimalista": (14, 92, 10, 25),
    "natural": (34, 87, 26, 26),
    "solar": (62, 86, 46, 32),
    "electric": (66, 85, 52, 33),
    "isla": (30, 90, 24, 27),
    "aurora": (44, 88, 40, 31),
    "terra": (40, 86, 32, 28),
    "ia": (20, 91, 16, 25),
    "focus": (38, 89, 34, 30),
    "cielo": (36, 90, 28, 27),
    "galaxia": (52, 87, 44, 30),
}
_CARACTER_POR_OMISION = (30, 88, 26, 28)


def _de_hsl(tono: int, saturacion: int, luz: int) -> str:
    """Un color en hexadecimal, a partir de tono, saturación y luz."""
    s, l = saturacion / 100, luz / 100
    c = (1 - abs(2 * l - 1)) * s
    x = c * (1 - abs((tono / 60) % 2 - 1))
    m = l - c / 2
    trozos = [
        (c, x, 0.0), (x, c, 0.0), (0.0, c, x),
        (0.0, x, c), (x, 0.0, c), (c, 0.0, x),
    ][int(tono // 60) % 6]
    return "#" + "".join(f"{round((uno + m) * 255):02x}" for uno in trozos)


def pasteles_de(clave: str, *, oscuro: bool) -> dict[str, str]:
    """Los seis pasteles de un tema, en su versión clara u oscura."""
    s_claro, l_claro, s_oscuro, l_oscuro = _CARACTER.get(clave, _CARACTER_POR_OMISION)
    s, l = (s_oscuro, l_oscuro) if oscuro else (s_claro, l_claro)
    return {nombre: _de_hsl(tono, s, l) for nombre, tono in _TONOS_DEL_HORARIO.items()}


_TINTA_SOBRE_PASTEL_CLARO = "#2b2a28"
_TINTA_SOBRE_PASTEL_OSCURO = "#eceae5"


def pastel(nombre: str, paleta: Paleta) -> str:
    """El color de ese pastel, en el tema y la versión que toquen.

    REVIENTA SI EL NOMBRE NO EXISTE, al revés que los colores de categoría: un
    pastel desconocido en el horario significa que alguien escribió mal una
    clave en el código, no que haya un dato raro guardado.
    """
    if nombre not in _TONOS_DEL_HORARIO:
        raise ValueError(
            f"«{nombre}» no es uno de los pasteles del horario; "
            f"están en interfaz/estilo.py"
        )
    oscuro = paleta.modo is ft.ThemeMode.DARK
    return pasteles_de(paleta.tema, oscuro=oscuro)[nombre]


def tinta_sobre_pastel(paleta: Paleta) -> str:
    """El color del texto que va ENCIMA de una casilla pintada.

    No vale el `ink` de la paleta: en oscuro es casi blanco y sobre un pastel
    claro no se leería, y en claro es oscuro y sobre un pastel oscuro tampoco.
    """
    if paleta.modo is ft.ThemeMode.DARK:
        return _TINTA_SOBRE_PASTEL_OSCURO
    return _TINTA_SOBRE_PASTEL_CLARO


METALES = {
    "bronce": "#b87333",
    "plata": "#b8bcc2",
    "oro": "#e3b341",
    "platino": "#8fd3d1",
    "diamante": "#9ab8ff",
}
"""El color de cada medalla de la Comunidad.

NO DEPENDEN DEL TEMA, a propósito: una medalla es un objeto, y el bronce es
bronce en cualquier pantalla, como una medalla de verdad. Por eso no están en
la Paleta sino aquí, junto a los demás colores fijos."""

TINTA_MEDALLA = "#1a1a1a"
"""El número de dentro de la medalla. Oscuro sobre los cinco metales, que son
todos claros: así se lee igual en el tema claro y en el oscuro."""

BRILLO_MEDALLA = "#59ffffff"
"""El filo claro del borde, que es lo que hace que el disco parezca de metal.
Blanco al 35 % (el «59» del principio es la transparencia): encima de cualquier
metal se ve como un reflejo, no como una raya blanca."""
