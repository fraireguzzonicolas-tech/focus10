"""Las imágenes de la pizarra, del lado de Focus: pegar, elegir, subir, bajar.

LO PIDIÓ EL USUARIO (12 nov 2026): «hago una captura y con Ctrl C, Ctrl V la
pueda pegar en la pizarra». Decidió también un botón «Imagen» (elegir un
archivo, y en el celular, donde no hay Ctrl V, pegar la copiada) y que se
pueda mover y agrandar desde las esquinas (eso es de la pizarra, en Dart).

EL CAMINO DE UNA IMAGEN:
1. Ctrl V en la pizarra → ella avisa dónde estaba el ratón (on_pegar).
2. Aquí se lee el portapapeles, se prepara (achicada, WebP, sin lo oculto:
   datos/pizarra_imagenes.py) y se guarda en la carpeta de este aparato.
3. Se le dice a la pizarra que la ponga (poner_imagen): queda en el
   documento solo su nombre y su lugar.
4. Se sube a la nube DE FONDO, sin trabar nada. Sin internet o sin cuenta,
   queda anotada y se sube la próxima vez que se abra la pizarra.
5. En otro aparato, la pizarra la muestra «Cargando imagen…» mientras se
   baja; al llegar, aparece.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Callable

import flet as ft

from ..datos import pizarra_imagenes as imagenes
from ..datos.bd import conectado
from ..sistema import pizarra_nube as nube
from ..sistema.sincronizacion import ServidorDijoQueNo
from . import componentes
from .con_sesion import con_la_sesion

EXTENSIONES = ("png", "jpg", "jpeg", "webp", "gif", "bmp")
"""Las que se pueden elegir o pegar como archivo."""


async def _de_fondo(funcion, *argumentos):
    """Lo pesado (Pillow, el disco) en otro hilo, para no congelar la ventana.

    EN LA WEB NO HAY HILOS: ahí se hace directo (como en con_sesion.py).
    """
    try:
        return await asyncio.to_thread(funcion, *argumentos)
    except RuntimeError as fallo:
        if "thread" not in str(fallo).lower():
            raise
        return funcion(*argumentos)


class ImagenesDePizarra:
    def __init__(
        self,
        pagina: ft.Page,
        lienzo: Callable[[], ft.Control | None],
        documento: Callable[[], dict | None],
        *,
        portapapeles: ft.Clipboard | None = None,
        selector: ft.FilePicker | None = None,
        base: Path | None = None,
        lanzar: Callable | None = None,
        nube_subir=nube.subir,
        nube_bajar=nube.bajar,
    ) -> None:
        self.pagina = pagina
        self._lienzo = lienzo
        self._documento = documento
        self.portapapeles = portapapeles
        self.selector = selector
        self.base = base
        # LO QUE VA DE FONDO (subir, bajar) se lanza con esto: la página de
        # Flet en la app; en las pruebas, una lista que se corre a mano.
        self._lanzar = lanzar or self._con_la_pagina
        self._subir = nube_subir
        self._bajar = nube_bajar
        self._bajando: set[str] = set()
        self._subiendo = False
        self._mirar_otra_vez = False

    # ------------------------------------------------------------ lo que ve la pizarra

    def carpeta(self) -> str:
        return str(imagenes.carpeta(self.base))

    def disponibles(self, documento: dict | None) -> str:
        """Las imágenes del documento que ya están en este aparato, en JSON."""
        return json.dumps([n for n in imagenes.nombres_en(documento) if imagenes.hay(n, self.base)])

    def _avisar_disponibles(self) -> None:
        """Con el documento DE AHORA (no el de cuando empezó a bajar): mientras
        bajaba se pudo pegar otra."""
        lienzo = self._lienzo()
        if lienzo is None:
            return
        lienzo.imagenes = self.disponibles(self._documento())
        try:
            lienzo.update()
        except Exception:  # noqa: BLE001  (todavía no está en la ventana)
            pass

    # ------------------------------------------------------------ pegar y elegir

    async def pegar(self, punto: tuple[float, float] | None = None) -> None:
        """Ctrl V (con el punto donde estaba el ratón) o «Pegar» del botón."""
        crudo = await self._del_portapapeles()
        if crudo is None:
            componentes.avisar(
                self.pagina,
                "No hay una imagen copiada. Sacá una captura (Windows + Mayús + S) o copiá una imagen, y pegala.",
            )
            return
        await self.poner(crudo, punto)

    async def elegir(self, _=None) -> None:
        """El botón «Elegir un archivo»: una imagen de la PC o la galería."""
        if self.selector is None:
            return
        elegidos = await self.selector.pick_files(
            dialog_title="Elegí una imagen",
            allow_multiple=False,
            file_type=ft.FilePickerFileType.CUSTOM,
            allowed_extensions=list(EXTENSIONES),
            # EN LA WEB NO HAY RUTA: llegan los bytes.
            with_data=self.pagina.web,
        )
        if not elegidos:
            return
        elegido = elegidos[0]
        try:
            crudo = elegido.bytes if elegido.bytes else await _de_fondo(Path(elegido.path or "").read_bytes)
        except OSError:
            componentes.avisar(self.pagina, "No se pudo leer esa imagen.")
            return
        await self.poner(crudo, None)

    async def _del_portapapeles(self) -> bytes | None:
        if self.portapapeles is None:
            return None
        try:
            crudo = await self.portapapeles.get_image()
        except Exception:  # noqa: BLE001  (el sistema no la dio: no hay imagen)
            crudo = None
        if crudo:
            return bytes(crudo)
        # UN ARCHIVO DE IMAGEN COPIADO desde una carpeta (Ctrl C en el
        # explorador): en el portapapeles hay su ruta, no la imagen.
        try:
            archivos = await self.portapapeles.get_files()
        except Exception:  # noqa: BLE001  (este sistema no lo permite)
            return None
        for ruta in archivos or []:
            if str(ruta).lower().rsplit(".", 1)[-1] in EXTENSIONES:
                try:
                    return await _de_fondo(Path(ruta).read_bytes)
                except OSError:
                    return None
        return None

    async def poner(self, crudo: bytes, punto: tuple[float, float] | None) -> None:
        """Prepara, guarda aquí, la pone en la pizarra y la sube de fondo."""
        lienzo = self._lienzo()
        if lienzo is None:
            return
        try:
            lista = await _de_fondo(imagenes.preparar, crudo)
            await _de_fondo(imagenes.guardar, lista, self.base)
        except imagenes.ImagenNoValida:
            componentes.avisar(self.pagina, "Eso no es una imagen que se pueda abrir.")
            return
        except OSError:
            componentes.avisar(self.pagina, "No se pudo guardar la imagen en esta PC.")
            return
        with conectado() as conexion:
            imagenes.anotar_por_subir(conexion, lista.nombre)
        # PRIMERO QUE LA PIZARRA SEPA QUE YA ESTÁ, después que la ponga.
        disponibles = json.loads(lienzo.imagenes or "[]")
        if lista.nombre not in disponibles:
            lienzo.imagenes = json.dumps([*disponibles, lista.nombre])
            try:
                lienzo.update()
            except Exception:  # noqa: BLE001
                pass
        x, y = punto if punto is not None else (None, None)
        await lienzo.poner_imagen(lista.nombre, lista.ancho, lista.alto, x, y)
        self._lanzar(self.subir_pendientes)

    def _con_la_pagina(self, tarea, *argumentos) -> None:
        correr = getattr(self.pagina, "run_task", None)
        if correr is not None:
            correr(tarea, *argumentos)

    # ------------------------------------------------------------ la nube

    def subir_si_quedaron(self) -> None:
        """Si quedaron imágenes sin subir, las sube de fondo."""
        with conectado() as conexion:
            quedan = imagenes.por_subir(conexion)
        if quedan:
            self._lanzar(self.subir_pendientes)

    async def subir_pendientes(self) -> None:
        """Sube las que quedaron sin subir. Lo que falla se intenta otra vez
        la próxima vez; NO SE AVISA: sin internet no hay nada que hacer, y sin
        el almacén puesto (servidor/pizarra_imagenes.sql) tampoco.

        UNA SUBIDA A LA VEZ: pegar dos imágenes seguidas lanzaba dos, y las dos
        subían las mismas. La que llega mientras otra sube no sube nada: le
        avisa a la que sube que, al terminar, mire la lista otra vez (ahí está
        la imagen recién pegada).
        """
        if self._subiendo:
            self._mirar_otra_vez = True
            return
        self._subiendo = True
        try:
            seguir = True
            while seguir:
                self._mirar_otra_vez = False
                seguir = await self._subir_lo_anotado() and self._mirar_otra_vez
        finally:
            self._subiendo = False

    async def _subir_lo_anotado(self) -> bool:
        """Sube lo anotado. False si se cortó (sin internet, sin sesión)."""
        with conectado() as conexion:
            pendientes = imagenes.por_subir(conexion)
        for nombre in pendientes:
            try:
                datos = await _de_fondo(imagenes.leer, nombre, self.base)
            except (OSError, imagenes.ImagenNoValida):
                # SE BORRÓ DE LA CARPETA: no hay nada que subir.
                with conectado() as conexion:
                    imagenes.quitar_por_subir(conexion, nombre)
                continue
            try:
                await con_la_sesion(lambda testigo, n=nombre, d=datos: self._subir(testigo, n, d))
            except (nube.SinConexion, nube.ServidorDijoQueNo, ServidorDijoQueNo):
                return False
            with conectado() as conexion:
                imagenes.quitar_por_subir(conexion, nombre)
        return True

    def traer(self, documento: dict | None) -> None:
        """Baja de fondo las imágenes de este documento que no están aquí."""
        faltan = [
            n for n in imagenes.nombres_en(documento)
            if not imagenes.hay(n, self.base) and n not in self._bajando
        ]
        if faltan:
            self._bajando.update(faltan)
            self._lanzar(self._bajar_faltantes, faltan)

    async def _bajar_faltantes(self, faltan: list[str]) -> None:
        llego = False
        try:
            for nombre in faltan:
                try:
                    datos = await con_la_sesion(lambda testigo, n=nombre: self._bajar(testigo, n))
                    await _de_fondo(imagenes.guardar_bajada, nombre, datos, self.base)
                    llego = True
                except (nube.NoEsta, imagenes.ImagenNoValida, OSError):
                    # TODAVÍA NO LA SUBIÓ EL OTRO APARATO (o llegó mal): queda
                    # esperando y se prueba otra vez al volver a abrir.
                    continue
                except (nube.SinConexion, nube.ServidorDijoQueNo, ServidorDijoQueNo):
                    break
        finally:
            self._bajando.difference_update(faltan)
        if llego:
            self._avisar_disponibles()
