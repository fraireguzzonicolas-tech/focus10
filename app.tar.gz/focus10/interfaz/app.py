"""La ventana de Focus10: barra lateral y contenido.

FORMA, copiada de Nexo: navegación en una barra lateral izquierda fija, no en
pestañas arriba. Cabe el nombre completo de cada sección, se lee de arriba abajo
y deja todo el ancho de la ventana para el contenido.

De las nueve secciones solo tres están construidas (Finanzas, Configuración y lo
que se ve en cada una). Las demás aparecen a propósito, para ver la forma que
tendrá la aplicación, pero ninguna finge funcionar: dicen abiertamente que
todavía no están hechas (ver en_construccion.py).
"""

from __future__ import annotations

import flet as ft

from .. import __version__
from ..datos import ajustes, repositorio_tareas, rutas
from ..datos.bd import conectado
from ..datos.migraciones import version_actual
from . import en_construccion, estilo
from .configuracion import PantallaConfiguracion
from .estilo import Paleta
from .finanzas import PantallaFinanzas
from .franja_descanso import FranjaDescanso
from .gimnasio import PantallaGimnasio
from .alimentacion import PantallaAlimentacion
from .dashboard import PantallaDashboard
from .focus import PantallaFocus
from .inversiones import PantallaInversiones
from . import (
    componentes,
    dialogo_recompensa,
    dialogo_recordatorios,
    guardado_web,
)
from .horario import PantallaHorario
from .objetivos import PantallaObjetivos
from .habitos import PantallaHabitos

TITULO = "Focus10"
ANCHO_MINIMO = 980
ALTO_MINIMO = 660

# Las secciones, en el orden en que se enseñan, con su icono.
SECCIONES = (
    ("Dashboard", ft.Icons.SPACE_DASHBOARD_OUTLINED),
    ("Horario", ft.Icons.GRID_ON_OUTLINED),
    ("Finanzas", ft.Icons.ACCOUNT_BALANCE_WALLET_OUTLINED),
    ("Objetivos", ft.Icons.FLAG_OUTLINED),
    ("Inversiones", ft.Icons.TRENDING_UP),
    ("Hábitos", ft.Icons.REPEAT),
    ("Gimnasio", ft.Icons.FITNESS_CENTER),
    ("Alimentación", ft.Icons.RESTAURANT_OUTLINED),
    ("Focus", ft.Icons.CENTER_FOCUS_STRONG_OUTLINED),
    ("Configuración", ft.Icons.SETTINGS_OUTLINED),
)

NOMBRE_SECCION_INICIAL = "Dashboard"
"""Por dónde se abre la aplicación.

EL DASHBOARD, y lo pidió el usuario. Antes se abría en Finanzas, con el
razonamiento de que era "la única que hace algo a diario". Ese razonamiento se
quedó viejo: desde que el Dashboard resume el día entero —los hábitos, las
tareas, el horario de hoy y los gastos— es la pantalla que contesta "¿qué tengo
que hacer ahora?", que es justo la pregunta con la que se abre una aplicación
así.

SE GUARDA EL NOMBRE Y NO EL NÚMERO a propósito. Antes era un 1 a pelo, y al
meter "Horario" en segundo lugar la aplicación habría arrancado en el horario
sin que nadie lo pidiera. Un número que hay que acordarse de mover cada vez que
cambia una lista se acaba quedando atrás.
"""

SECCION_INICIAL = SECCIONES.index(
    next(uno for uno in SECCIONES if uno[0] == NOMBRE_SECCION_INICIAL)
)


class Ventana:
    """La ventana entera: barra lateral, contenido y tema."""

    def __init__(self, pagina: ft.Page) -> None:
        self.pagina = pagina
        self.seleccionada = SECCION_INICIAL
        self.pantalla = None
        self._era_estrecha = False

        # EL CRONOMETRO DE DESCANSO VIVE AQUI, en la ventana, y no dentro del
        # gimnasio. Cambiar de seccion tira la pantalla entera y construye otra;
        # si el cronometro viviera alli, se moriria al ir a mirar otra cosa,
        # que es justo el minuto y medio para el que existe.
        self.franja = FranjaDescanso(pagina)
        # LA PANTALLA DE FOCUS VIVE AQUI Y NO EN _contenido: su reloj sigue
        # contando mientras estas en otra seccion, asi que no puede morirse
        # cada vez que cambias de sitio.
        self.focus: PantallaFocus | None = None
        # EL PREMIO DE LA SEMANA SE MIRA UNA VEZ POR ARRANQUE. Montar la
        # ventana pasa en cada cambio de seccion, y una felicitacion que
        # sale diez veces al dia deja de felicitar.
        self._premio_mirado = False

        with conectado() as conexion:
            # Abrir la base aquí, antes de dibujar nada, aplica las migraciones
            # que falten; y si algo va mal, el error sale antes de enseñar una
            # ventana que no funcionaría.
            self.esquema = version_actual(conexion)

    # ----------------------------------------------------------------------

    def _paleta(self) -> Paleta:
        """La paleta de ahora: la del ajuste, o la de Windows si toca seguirlo."""
        with conectado() as conexion:
            tema = ajustes.leer(conexion, ajustes.CLAVE_TEMA)
            cual = ajustes.leer_estilo(conexion)
        return estilo.paleta_para(
            tema, sistema_oscuro=self._windows_en_oscuro(), estilo=cual
        )

    def _windows_en_oscuro(self) -> bool:
        """Cómo tiene Windows el tema. Si el cliente aún no lo ha dicho, oscuro:
        es lo que menos molesta si la aplicación se abre de madrugada."""
        return self.pagina.platform_brightness is not ft.Brightness.LIGHT

    # ----------------------------------------------------------------------

    def montar(self) -> None:
        """Dibuja la ventana desde cero. Se repite al cambiar de sección o tema."""
        pagina = self.pagina
        # LO PRIMERO DE TODO: decirle al resto del dibujo cuánto sitio hay. Las
        # tablas y los gráficos lo consultan para decidir cómo se pintan, y si
        # se hiciera después ya se habrían dibujado con el ancho de antes.
        estilo.fijar_ancho(getattr(pagina, "width", None))
        self.paleta = self._paleta()

        pagina.title = TITULO
        # EL MINIMO SOLO VALE PARA UNA VENTANA DE ESCRITORIO. En un navegador no
        # hay ventana que redimensionar —el tamaño lo manda el móvil— y exigir
        # 980 puntos allí no significa nada. Se intenta y si no se puede, se
        # sigue: no es motivo para no abrir la aplicación.
        try:
            pagina.window.min_width = ANCHO_MINIMO
            pagina.window.min_height = ALTO_MINIMO
        except Exception:
            pass
        pagina.padding = 0
        pagina.spacing = 0

        # LAS FUENTES, ANTES QUE NADA. Van dentro del proyecto y no se piden a
        # internet: la aplicación funciona sin conexión, y así se podrán
        # empaquetar con PyInstaller. Si algún archivo faltara, `fuentes_
        # disponibles` no lo devuelve y Flet usa la suplente en vez de dejar la
        # ventana en blanco por una tilde tipográfica.
        pagina.fonts = estilo.fuentes_disponibles()
        # La fuente de TODO lo que no pide otra cosa. Los titulares y las cifras
        # piden la serif ellos mismos, uno a uno, porque es una excepción y las
        # excepciones se escriben donde pasan.
        pagina.theme = ft.Theme(font_family=self.paleta.fuente)
        pagina.dark_theme = ft.Theme(font_family=self.paleta.fuente)

        # theme_mode manda sobre los controles que trae Flet (los campos de
        # texto, los diálogos); los colores propios los pone la paleta.
        pagina.theme_mode = self.paleta.modo
        pagina.bgcolor = self.paleta.canvas
        # Si Windows cambia de tema con la aplicación abierta, se entera.
        pagina.on_platform_brightness_change = lambda _: self.montar()
        # Y si la ventana cruza el ancho de "esto ya es un movil", se recoloca.
        self._vigilar_el_ancho()

        # Avisar a la pantalla que se va ANTES de tirarla: el Dashboard tiene un
        # reloj corriendo por detrás y hay que pararlo. Sin esto, cada visita al
        # Dashboard dejaria uno más dando vueltas para siempre.
        if self.pantalla is not None and hasattr(self.pantalla, "cerrar"):
            self.pantalla.cerrar()

        pagina.controls.clear()
        # UNA COLUMNA Y NO SOLO LA FILA: debajo de todo va la franja del
        # descanso. Se pide su dibujo en cada montaje —la paleta puede haber
        # cambiado— pero el objeto es siempre el mismo, con su cuenta atras
        # intacta. Cuando no hay descanso mide cero y no se ve.
        # EN ESTRECHO EL MENU VA ARRIBA Y NO AL LADO. El lateral mide 236
        # puntos y un móvil tiene 375: dejaba 139 para la aplicación entera.
        # Y el relleno baja de 24 a 12, que a lo ancho son 48 puntos menos
        # perdidos, un 13% de la pantalla de un móvil.
        # LOS RECORDATORIOS SE CUENTAN AL MONTAR, que es cuando se dibuja la
        # barra: al cambiar de seccion se vuelve a montar, asi que el numero se
        # pone al dia solo sin ningun temporizador de por medio.
        with conectado() as conexion:
            self.pendientes = len(repositorio_tareas.listar_pendientes(conexion))

        estrecha = self.es_estrecha()
        relleno = 12 if estrecha else 24
        cuerpo = ft.Container(
            content=self._contenido(), expand=True, padding=relleno
        )
        if estrecha:
            principal = ft.Column(
                [self._barra_de_arriba(), cuerpo], spacing=0, expand=True
            )
        else:
            principal = ft.Row(
                [self._lateral(), cuerpo],
                spacing=0,
                expand=True,
                vertical_alignment=ft.CrossAxisAlignment.START,
            )

        pagina.add(
            ft.Column(
                [principal, self.franja.control(self.paleta)],
                spacing=0,
                expand=True,
            )
        )
        pagina.update()
        # Despues del update: la cuenta atras necesita que la franja este ya en
        # la pagina para poder repintarse. Solo arranca la primera vez.
        self.franja.empezar_a_latir()
        self._mirar_el_premio()

        if self.pantalla is not None:
            self.pantalla.montada()

    # ----------------------------------------------------------------------

    def _contenido(self) -> ft.Control:
        nombre = SECCIONES[self.seleccionada][0]

        if nombre == "Dashboard":
            self.pantalla = PantallaDashboard(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Alimentación":
            self.pantalla = PantallaAlimentacion(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Horario":
            self.pantalla = PantallaHorario(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Objetivos":
            self.pantalla = PantallaObjetivos(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Inversiones":
            self.pantalla = PantallaInversiones(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Focus":
            # LA DE FOCUS SE CREA UNA VEZ Y SE REUTILIZA, igual que la franja
            # del descanso: su reloj tiene que seguir andando aunque te vayas a
            # otra sección. Crear una nueva cada vez era lo que lo paraba.
            if self.focus is None:
                self.focus = PantallaFocus(self.pagina, self.paleta)
            else:
                self.focus.cambiar_paleta(self.paleta)
            self.pantalla = self.focus
            return self.pantalla.control
        if nombre == "Finanzas":
            self.pantalla = PantallaFinanzas(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Hábitos":
            self.pantalla = PantallaHabitos(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Gimnasio":
            # La franja se le pasa para que marcar una serie pueda arrancar el
            # descanso. La pantalla no la crea ni la destruye: solo la usa.
            self.pantalla = PantallaGimnasio(self.pagina, self.paleta, self.franja)
            return self.pantalla.control
        if nombre == "Configuración":
            self.pantalla = PantallaConfiguracion(
                self.pagina, self.paleta, self.montar
            )
            return self.pantalla.control

        self.pantalla = None
        explicacion, nota = en_construccion.SECCIONES_PENDIENTES[nombre]
        return en_construccion.pantalla(self.paleta, nombre, explicacion, nota)

    def es_estrecha(self) -> bool:
        """Si la ventana es tan estrecha que hay que dibujar como en un móvil.

        SI FLET NO SABE EL ANCHO TODAVIA se responde que no: al arrancar puede
        no estar medida aún, y dar por hecho "móvil" haría que la aplicación de
        escritorio parpadeara al primer dibujado.
        """
        ancho = getattr(self.pagina, "width", None)
        return bool(ancho) and ancho < estilo.ANCHO_ESTRECHO

    def _vigilar_el_ancho(self) -> None:
        """Vuelve a dibujar SOLO al cruzar el corte, no en cada arrastre.

        Redibujar en cada píxel de un arrastre de ventana rehace las diez
        secciones cientos de veces y te saca el cursor de donde estuvieras
        escribiendo. Solo importa el momento en que se pasa de ancho a estrecho.
        """

        def al_cambiar(_):
            ahora = self.es_estrecha()
            if ahora != self._era_estrecha:
                self._era_estrecha = ahora
                self.montar()

        self.pagina.on_resize = al_cambiar

    def _barra_de_arriba(self) -> ft.Control:
        """El menú de un móvil: un botón, el nombre de la sección y nada más.

        POR QUÉ ARRIBA Y NO A UN LADO: la barra lateral se lleva 236 puntos de
        los 375 que tiene un móvil. Quedaban 139 para la aplicación entera, que
        no da ni para una tarjeta.

        POR QUÉ UNA VENTANITA Y NO UN CAJÓN LATERAL: Flet trae un cajón hecho,
        pero las ventanitas ya están usadas y probadas en toda la aplicación.
        Con diez secciones y una prueba con amigos por delante, prefiero lo que
        sé que funciona a lo que parece más elegante.
        """
        nombre = SECCIONES[self.seleccionada][0]
        return ft.Container(
            content=ft.Row(
                [
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.MENU,
                        ayuda="Ir a otra sección",
                        al_pulsar=lambda _: self._pedir_seccion(),
                    ),
                    ft.Text(
                        nombre,
                        size=15,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.ink,
                        expand=True,
                    ),
                    self._campana(),
                ],
                spacing=6,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=10, vertical=8),
            bgcolor=self.paleta.surface,
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
        )

    def _pedir_seccion(self) -> None:
        """La lista de secciones, para elegir a dónde ir."""
        self.pagina.show_dialog(
            componentes.dialogo(
                self.paleta,
                "Ir a",
                ft.Column(
                    [
                        self._enlace(indice, nombre, icono)
                        for indice, (nombre, icono) in enumerate(SECCIONES)
                    ],
                    spacing=2,
                    tight=True,
                    width=260,
                    scroll=ft.ScrollMode.AUTO,
                ),
                pagina=self.pagina,
                texto_aceptar="Cerrar",
                al_aceptar=lambda _: self.pagina.pop_dialog(),
            )
        )

    def _mirar_el_premio(self) -> None:
        """Si la semana pasada llego al 70%, felicita. Una vez y se acabo.

        SE MIRA AL MONTAR Y NO CON UN TEMPORIZADOR: la aplicacion se abre, se
        monta, y ahi se pregunta. Un extra secundario no merece un reloj propio.
        """
        if self._premio_mirado:
            return
        self._premio_mirado = True

        with conectado() as conexion:
            premio = dialogo_recompensa.pendiente(conexion)
        if premio is None:
            return
        dialogo_recompensa.abrir(self.pagina, self.paleta, premio)

    def _campana(self) -> ft.Control:
        """La campanita, con lo que pasa al tocarla.

        VA EN LA BARRA DE LA APLICACION Y NO EN LA CABECERA DEL DASHBOARD, y
        merece explicacion porque el usuario dijo "al lado del reloj": el reloj
        solo existe en el Dashboard, y una campana que solo se ve estando ya en
        el Dashboard no recuerda nada. Aqui se ve desde cualquier seccion, que
        es lo que se le pide a un recordatorio.

        AL TOCARLA SE ABRE LA LISTA de lo que tienes pendiente, con su boton de
        anadir. Antes llevaba al Dashboard, y no era lo mismo: te dejaba en la
        pantalla donde estan las tareas, pero teniendo que buscarlas.
        """
        return componentes.campana(
            self.paleta,
            self.pendientes,
            al_pulsar=lambda _: dialogo_recordatorios.abrir(
                self.pagina, self.paleta, self.montar
            ),
        )

    def _lateral(self) -> ft.Control:
        piezas: list[ft.Control] = [self._marca(), ft.Container(height=6)]
        piezas += [
            self._enlace(indice, nombre, icono)
            for indice, (nombre, icono) in enumerate(SECCIONES)
        ]
        piezas += [ft.Container(expand=True), self._pie()]

        return ft.Container(
            content=ft.Column(piezas, spacing=2, expand=True),
            width=estilo.ANCHO_LATERAL,
            padding=ft.Padding.symmetric(horizontal=10, vertical=12),
            bgcolor=self.paleta.surface,
            border=ft.Border.only(right=ft.BorderSide(1, self.paleta.borde)),
        )

    def _marca(self) -> ft.Control:
        paleta = self.paleta
        with conectado() as conexion:
            nombre = ajustes.leer(conexion, ajustes.CLAVE_NOMBRE)

        return ft.Container(
            content=ft.Row(
                [
                    ft.Container(
                        content=ft.Text(
                            "F",
                            size=14,
                            weight=ft.FontWeight.BOLD,
                            color=paleta.acento_ink,
                        ),
                        width=30,
                        height=30,
                        bgcolor=paleta.acento,
                        border_radius=estilo.RADIO_BOTON,
                        alignment=ft.Alignment.CENTER,
                    ),
                    ft.Column(
                        [
                            ft.Text(
                                "Focus10",
                                size=13,
                                weight=ft.FontWeight.W_600,
                                color=paleta.ink,
                            ),
                            # Si has puesto tu nombre, aquí sale; si no, la
                            # aplicación no se inventa nada.
                            ft.Text(
                                nombre or "Centro personal", size=10, color=paleta.muted
                            ),
                        ],
                        spacing=0,
                        tight=True,
                        expand=True,
                    ),
                    # LA CAMPANA, ARRIBA DEL TODO Y EN TODAS LAS SECCIONES.
                    self._campana(),
                ],
                spacing=9,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=6, vertical=8),
        )

    def _enlace(self, indice: int, nombre: str, icono: str) -> ft.Control:
        """Una entrada de la barra lateral. La elegida se marca con el acento."""
        paleta = self.paleta
        elegida = indice == self.seleccionada
        return ft.Container(
            content=ft.Row(
                [
                    ft.Icon(
                        icono, size=17, color=paleta.acento if elegida else paleta.muted
                    ),
                    ft.Text(
                        nombre,
                        size=13,
                        weight=ft.FontWeight.W_500 if elegida else ft.FontWeight.NORMAL,
                        color=paleta.acento if elegida else paleta.ink_soft,
                    ),
                ],
                spacing=10,
            ),
            padding=ft.Padding.symmetric(horizontal=10, vertical=9),
            bgcolor=paleta.acento_suave if elegida else None,
            border_radius=estilo.RADIO_BOTON,
            on_click=lambda _, i=indice: self._seleccionar(i),
            ink=True,
        )

    def _pie(self) -> ft.Control:
        """Versión y esquema. No es adorno: cuando algo va raro, lo primero que
        hay que saber es qué archivo está usando la aplicación (va en el aviso
        emergente, para no ocupar sitio)."""
        return ft.Container(
            content=ft.Text(
                f"v{__version__} · esquema {self.esquema}",
                size=10,
                color=self.paleta.muted,
            ),
            padding=ft.Padding.symmetric(horizontal=10, vertical=6),
            tooltip=str(rutas.ruta_bd()),
        )

    # ----------------------------------------------------------------------

    def _seleccionar(self, indice: int) -> None:
        # SE CIERRA LA VENTANITA SIEMPRE, incluso al tocar la sección en la que
        # ya estás: si no, tocarla parecería que la aplicación se ha colgado.
        if self.es_estrecha():
            self.pagina.pop_dialog()
        if indice == self.seleccionada:
            return
        self.seleccionada = indice
        self.montar()


async def construir(pagina: ft.Page) -> None:
    """Monta la ventana entera. Es lo que recibe Flet al arrancar.

    ES ASINCRONA POR EL NAVEGADOR: ahi hay que recuperar el archivo de datos del
    almacen ANTES de montar nada, y eso se espera. En el ordenador esas dos
    lineas no hacen nada y todo sigue igual.

    EL ORDEN NO ES UN DETALLE: montar la ventana lee ajustes —el tema, el
    estilo, la jornada— nada mas empezar. Si eso pasara antes de recuperar, se
    encontraria una base vacia, la crearia de cero y machacaria lo guardado.
    """
    await guardado_web.restaurar()
    Ventana(pagina).montar()
    guardado_web.arrancar(pagina)


def ejecutar() -> None:
    """Arranca la aplicación. Es lo que llama abrir.py."""
    ft.run(construir)
