"""La ventana de Focus10: barra lateral y contenido.

FORMA, copiada de Nexo: navegación en una barra lateral izquierda fija, no en
pestañas arriba. Cabe el nombre completo de cada sección, se lee de arriba abajo
y deja todo el ancho de la ventana para el contenido.

LA VENTANA ESTÁ EN CUATRO ARCHIVOS (desde la auditoría del 13 nov 2026, cuando
este pasaba de las mil trescientas líneas): aquí montarla y cambiar de sección;
en app_entreno.py el entreno y su resumen; en app_marco.py las barras, la marca
y la campana; y en secciones.py la lista del menú. Ventana hereda las dos clases.
"""

from __future__ import annotations

from datetime import date, datetime

import asyncio
import time

import flet as ft

from .. import NOMBRE
from ..sistema import cuentas
from ..datos import (
    ajustes,
    aviso_pendientes,
    medallas,
    repositorio_dias,
    repositorio_gimnasio,
    repositorio_tareas,
    sincronia,
)
from ..datos.bd import conectado
from ..datos.migraciones import version_actual
from . import base_ocupada, estilo, sumar_whatsapp, temas
from .configuracion import PantallaConfiguracion
from . import motivo_fondo
from .entrada import PantallaEntrada
from .entreno import PantallaEntreno
from .resumen_entreno import PantallaResumen
from .estilo import Paleta
from .finanzas import PantallaFinanzas
from .franja_descanso import FranjaDescanso
from .franja_entreno import FranjaEntreno
from .gimnasio import PantallaGimnasio
from .alimentacion import PantallaAlimentacion
from .dashboard import PantallaDashboard
from .aviso_version import AvisoVersion
from .sincronizador import AL_VOLVER, Sincronizador
from .focus import PantallaFocus
from .inversiones import PantallaInversiones
from .educacion import PantallaEducacion
from .comunidad import PantallaComunidad
from .finanzas import Vista as VistaFinanzas
from . import (
    componentes,
    dialogo_medalla,
    dialogo_recompensa,
    dialogo_recordatorios,
    guardado_web,
)
from .horario import PantallaHorario
from .objetivos import PantallaObjetivos
from .pizarra import PantallaPizarra
from .habitos import PantallaHabitos
from .app_entreno import EntrenoEnLaVentana
from .app_marco import MarcoDeLaVentana
from .secciones import SECCION_INICIAL, SECCIONES

TITULO = NOMBRE
ESPERA_MAXIMA = 8
"""Cuántos segundos se espera, como mucho, a la primera sincronización.

SIN INTERNET LA PETICIÓN TARDA EN RENDIRSE, y la aplicación no puede quedarse
sin abrir por eso. Pasado este rato se abre con lo que hay en este aparato y
la sincronización sigue por su cuenta.
"""

ANCHO_MINIMO = 980
ALTO_MINIMO = 660


class Ventana(EntrenoEnLaVentana, MarcoDeLaVentana):
    """La ventana entera: barra lateral, contenido y tema."""

    def __init__(self, pagina: ft.Page) -> None:
        self.pagina = pagina
        self.seleccionada = SECCION_INICIAL
        self.pantalla = None
        # LA PESTAÑA DE FINANZAS LA RECUERDA LA VENTANA, no la pantalla: la
        # pantalla se tira y se rehace al cambiar de sección o de tema, y sin
        # esto volver a Finanzas te devolvería siempre a Movimientos.
        self.vista_finanzas = VistaFinanzas.MOVIMIENTOS
        self._era_estrecha = False

        # EL CRONOMETRO DE DESCANSO VIVE AQUI, en la ventana, y no dentro del
        # gimnasio. Cambiar de seccion tira la pantalla entera y construye otra;
        # si el cronometro viviera alli, se moriria al ir a mirar otra cosa,
        # que es justo el minuto y medio para el que existe.
        self.franja = FranjaDescanso(pagina)
        # Y LA DEL ENTRENO EN MARCHA, por lo mismo: con el entreno fuera su
        # reloj tiene que seguir andando en cualquier sección.
        self.franja_entreno = FranjaEntreno(pagina, self._volver_al_entreno)
        # EL SELECTOR DE ARCHIVOS TAMBIEN VIVE AQUI, y por un motivo
        # distinto: es un SERVICIO, y los servicios hay que registrarlos
        # en la pagina al montarla. Creado al entrar en Configuracion
        # llegaba tarde: el boton se pintaba y al pulsarlo no pasaba nada,
        # sin ningun error. Ademas asi hay UNO, y no otro por cada visita.
        self.selector = ft.FilePicker()
        pagina.services.append(self.selector)
        # EL PORTAPAPELES, también un servicio y por lo mismo: lo usa la
        # pizarra para pegar imágenes (Ctrl V).
        self.portapapeles = ft.Clipboard()
        pagina.services.append(self.portapapeles)
        # EL MENÚ DE COMPARTIR DEL TELÉFONO, también un servicio y por lo mismo:
        # registrado al abrir, no al tocar «Compartir», o llegaría tarde. Lo
        # usa imagen_logro.py para mandar un logro a Instagram o WhatsApp.
        pagina.services.append(ft.Share())
        # LA PIEZA DE LOS AVISOS DE WHATSAPP, también un servicio, y solo en
        # la app instalada en Android. En la web abierta desde un Android la
        # plataforma también dice "android" pero la pieza no existe: por eso
        # se comprueba que se pueda importar, no solo la plataforma.
        self.avisos = None
        if pagina.platform == ft.PagePlatform.ANDROID:
            try:
                from focus10_avisos import Avisos
            except ImportError:
                pass
            else:
                self.avisos = Avisos()
                pagina.services.append(self.avisos)
        # EL FINAL DEL DESCANSO LO AVISA ANDROID, con la app cerrada o no.
        self.franja.telefono = self.avisos
        self._whatsapp_ofrecido = False
        # LA PANTALLA DE FOCUS VIVE AQUI Y NO EN _contenido: su reloj sigue
        # contando mientras estas en otra seccion, asi que no puede morirse
        # cada vez que cambias de sitio.
        self.focus: PantallaFocus | None = None
        # LA PUERTA VIVE AQUI Y NO SE REHACE EN CADA MONTAJE, porque
        # guarda dentro el correo escrito: montar la ventana pasa tambien
        # al equivocarse de contrasena, y ahi borrarlo seria lo peor.
        self.puerta = None
        # PANTALLA COMPLETA (la pide la pizarra): lo que se esconde y si está.
        self._marco: tuple | None = None
        self.en_pantalla_completa = False
        # QUÉ DÍA SE ESTÁ ENTRENANDO, o None si no se está entrenando. Cuando
        # tiene fecha, la pantalla de entrenar SUSTITUYE la ventana entera: no
        # es una sección más, es lo único que estás haciendo durante una hora.
        self.entrenando: date | None = None
        self.entrenando_bloque: str | None = None
        """Y QUÉ ENTRENO de ese día: un día puede tener varios (uno por bloque
        de la rutina, migración 39), y se entrena uno por vez."""
        self.resumiendo_bloque: str | None = None
        self.pantalla_entreno: PantallaEntreno | None = None
        # QUE DIA SE ESTA MIRANDO EN EL RESUMEN, o None. Sale al terminar un
        # entreno y al tocar un dia en el calendario.
        self.resumiendo: date | None = None
        # EL PREMIO DE LA SEMANA SE MIRA UNA VEZ POR ARRANQUE. Montar la
        # ventana pasa en cada cambio de seccion, y una felicitacion que
        # sale diez veces al dia deja de felicitar.
        self._premio_abierto = False
        # LA SINCRONIZACIÓN VIVE AQUÍ, como la franja del descanso: tiene un
        # latido que no puede morirse en cada cambio de sección.
        self.sinc = Sincronizador(pagina, self._llego_algo, self._ya_esta_al_dia)
        # EL AVISO DE VERSION NUEVA, solo util en la web. Vive aqui por lo
        # mismo que la franja del descanso: tiene que sobrevivir a los
        # cambios de seccion.
        self.aviso_version = AvisoVersion(pagina)
        self._esperando_al_arranque = False

        with conectado() as conexion:
            # Abrir la base aquí, antes de dibujar nada, aplica las migraciones
            # que falten; y si algo va mal, el error sale antes de enseñar una
            # ventana que no funcionaría.
            self.esquema = version_actual(conexion)

        # SI ANDROID CERRÓ LA APLICACIÓN ENTRENANDO, SE VUELVE AL ENTRENO. Lo
        # pidió el usuario: bloquear el teléfono o cambiar de aplicación no
        # puede sacarte del entreno. Todo lo marcado ya estaba guardado —se
        # guarda en cada cambio—; lo que se perdía era DÓNDE estabas, porque
        # vivía solo en memoria, y la aplicación reabría en el Dashboard.
        # También el descanso que corría: ver franja_descanso.retomar.
        self._retomar_lo_que_quedo_a_medias()

    # ----------------------------------------------------------------------

    def _paleta(self) -> Paleta:
        """La paleta de ahora: la del ajuste, o la de Windows si toca seguirlo."""
        with conectado() as conexion:
            tema = ajustes.leer(conexion, ajustes.CLAVE_TEMA)
            cual = ajustes.leer_estilo(conexion)
        return temas.paleta_para(
            tema, sistema_oscuro=self._windows_en_oscuro(), estilo=cual
        )

    def _windows_en_oscuro(self) -> bool:
        """Cómo tiene Windows el tema. Si el cliente aún no lo ha dicho, oscuro:
        es lo que menos molesta si la aplicación se abre de madrugada."""
        return self.pagina.platform_brightness is not ft.Brightness.LIGHT

    # ----------------------------------------------------------------------

    def montar(self) -> None:
        """Dibuja la ventana desde cero. Se repite al cambiar de sección o tema.

        LA RED DE SEGURIDAD ESTA AQUI ARRIBA, Y NO MAS ADENTRO, POR ALGO: el
        dibujado se lanza a veces desde una tarea en segundo plano (al acabarse
        la espera de la primera sincronizacion, por ejemplo). Si revienta ahi,
        el error no se ve en ninguna parte y la aplicacion se queda con el
        cartel de "Poniendo al dia tus datos" girando para siempre. Le paso al
        usuario. Cubriendo el dibujado entero, cualquier camino que se tope con
        una base sin dia abierto acaba en una pantalla que lo explica y se
        arregla de un toque, y nunca en una rueda eterna.
        """
        try:
            self._montar_la_ventana()
        except repositorio_dias.NoHayDiaAbierto:
            self._montar_sin_dia()

    def _montar_sin_dia(self) -> None:
        """La ventana minima: el aviso de que falta el dia y el boton."""
        self._esperando_al_arranque = False
        self.pagina.controls.clear()
        self.pagina.add(
            ft.Container(
                content=self._pantalla_sin_dia(),
                expand=True,
                padding=24,
                alignment=ft.Alignment.CENTER,
                bgcolor=self.paleta.canvas,
            )
        )
        self.pagina.update()

    def _montar_la_ventana(self) -> None:
        pagina = self.pagina
        # LO PRIMERO DE TODO: decirle al resto del dibujo cuánto sitio hay. Las
        # tablas y los gráficos lo consultan para decidir cómo se pintan, y si
        # se hiciera después ya se habrían dibujado con el ancho de antes.
        estilo.fijar_ancho(estilo.ancho_de(pagina))
        self.paleta = self._paleta()

        pagina.title = TITULO
        # EL MINIMO SOLO VALE PARA UNA VENTANA DE ESCRITORIO. En un navegador no
        # hay ventana que redimensionar —el tamaño lo manda el móvil— y exigir
        # 980 puntos allí no significa nada. Se intenta y si no se puede, se
        # sigue: no es motivo para no abrir la aplicación.
        try:
            pagina.window.min_width = ANCHO_MINIMO
            pagina.window.min_height = ALTO_MINIMO
        except Exception:
            pass
        pagina.padding = 0
        pagina.spacing = 0

        # LAS FUENTES, ANTES QUE NADA. Van dentro del proyecto y no se piden a
        # internet: la aplicación funciona sin conexión, y así se podrán
        # empaquetar con PyInstaller. Si algún archivo faltara, `fuentes_
        # disponibles` no lo devuelve y Flet usa la suplente en vez de dejar la
        # ventana en blanco por una tilde tipográfica.
        pagina.fonts = estilo.fuentes_disponibles()
        # La fuente de TODO lo que no pide otra cosa. Los titulares y las cifras
        # piden la serif ellos mismos, uno a uno, porque es una excepción y las
        # excepciones se escriben donde pasan.
        pagina.theme = ft.Theme(font_family=self.paleta.fuente)
        pagina.dark_theme = ft.Theme(font_family=self.paleta.fuente)

        # theme_mode manda sobre los controles que trae Flet (los campos de
        # texto, los diálogos); los colores propios los pone la paleta.
        pagina.theme_mode = self.paleta.modo
        pagina.bgcolor = self.paleta.canvas
        # Si Windows cambia de tema con la aplicación abierta, se entera.
        pagina.on_platform_brightness_change = lambda _: self.montar()
        # AL VOLVER A LA VENTANA, PONERSE AL DÍA. Ver AL_VOLVER en
        # sincronizador.py: es la vez que más importa estar al día.
        pagina.on_app_lifecycle_state_change = lambda e: self._al_volver(
            getattr(e, 'state', None)
        )
        # Y si la ventana cruza el ancho de "esto ya es un movil", se recoloca.
        self._vigilar_el_ancho()

        # Avisar a la pantalla que se va ANTES de tirarla: el Dashboard tiene un
        # reloj corriendo por detrás y hay que pararlo. Sin esto, cada visita al
        # Dashboard dejaria uno más dando vueltas para siempre.
        if self.pantalla is not None and hasattr(self.pantalla, "cerrar"):
            self.pantalla.cerrar()
        # REARMAR LA VENTANA SALE DE PANTALLA COMPLETA: la pantalla nueva puede
        # no saber volver, y se quedaría todo el monitor sin menú.
        if self.en_pantalla_completa:
            self.en_pantalla_completa = False
            pagina.window.full_screen = False

        pagina.controls.clear()
        self._atras_del_celular()

        # LA PUERTA, ANTES QUE NADA. Si no has entrado en este aparato, no se
        # monta la aplicacion: ni menu, ni secciones, ni la franja del descanso.
        #
        # SE MIRA LA SESION GUARDADA, NO SI HAY INTERNET. Preguntarle al
        # servidor en cada arranque dejaria a alguien sin poder mirar lo que
        # apunto ayer porque el wifi del hotel va mal, y esta aplicacion se usa
        # justo ahi. La primera vez si hace falta conexion —no hay forma de
        # crear una cuenta sin ella—; a partir de ahi, no.
        if self._hace_falta_entrar():
            self._montar_la_puerta()
            return

        # SOLO SE ESPERA CUANDO ESTE APARATO NO TIENE NADA QUE ENSEÑAR.
        #
        # ANTES SE ESPERABA SIEMPRE, hasta ocho segundos, con este argumento:
        # abrir con los números de ayer y que cambien solos medio segundo
        # después es peor que esperar. El argumento vale para el primer
        # arranque —cuando la pantalla estaría vacía del todo— y NO VALE para
        # todos los demás: el usuario lo dijo con todas las letras, «cada vez
        # que cierro la app debo volver a cargar los datos, tiene que ser algo
        # rápido». Y tiene razón: los datos ya están aquí, guardados; hacerle
        # mirar una rueda para enseñarle lo que ya tiene es cobrarle el precio
        # de la sincronización en cada apertura.
        #
        # Asi que se abre con lo de aquí y la sincronización sigue por detrás;
        # cuando llega algo, la pantalla se repinta sola (al_llegar).
        if (
            not self.sinc.primera_hecha
            and not self._esperando_al_arranque
            and self._aparato_sin_estrenar()
        ):
            self._montar_la_espera()
            return

        # LA SINCRONIZACIÓN ARRANCA IGUAL, solo que sin que nadie la espere.
        self.sinc.empezar()

        # ENTRENANDO NO SE PINTA EL MENU. Con las manos ocupadas, media pantalla
        # de un movil en enlaces que no vas a pulsar no vale para nada.
        if self.entrenando is not None:
            self._montar_el_entreno()
            return

        if self.resumiendo is not None:
            self.pagina.add(
                PantallaResumen(
                    self.pagina,
                    self.paleta,
                    self.resumiendo,
                    self._cerrar_resumen,
                    self.montar,
                    bloque=self.resumiendo_bloque,
                    al_elegir=self._ver_otro_entreno_del_dia,
                ).control(self.paleta)
            )
            self.pagina.update()
            return

        # UNA COLUMNA Y NO SOLO LA FILA: debajo de todo va la franja del
        # descanso. Se pide su dibujo en cada montaje —la paleta puede haber
        # cambiado— pero el objeto es siempre el mismo, con su cuenta atras
        # intacta. Cuando no hay descanso mide cero y no se ve.
        # EN ESTRECHO EL MENU VA ARRIBA Y NO AL LADO. El lateral mide 236
        # puntos y un móvil tiene 375: dejaba 139 para la aplicación entera.
        # Y el relleno baja de 24 a 12, que a lo ancho son 48 puntos menos
        # perdidos, un 13% de la pantalla de un móvil.
        # LOS RECORDATORIOS SE CUENTAN AL MONTAR, que es cuando se dibuja la
        # barra: al cambiar de seccion se vuelve a montar, asi que el numero se
        # pone al dia solo sin ningun temporizador de por medio.
        with conectado() as conexion:
            self.pendientes = len(repositorio_tareas.listar_pendientes(conexion))

        estrecha = self.es_estrecha()
        relleno = 12 if estrecha else 24
        cuerpo = ft.Container(
            content=self._contenido(), expand=True, padding=relleno
        )
        menu = self._barra_de_arriba() if estrecha else self._lateral()
        if estrecha:
            principal = ft.Column([menu, cuerpo], spacing=0, expand=True)
        else:
            principal = ft.Row(
                [menu, cuerpo],
                spacing=0,
                expand=True,
                vertical_alignment=ft.CrossAxisAlignment.START,
            )
        franjas = [
            self.franja_entreno.control(self.paleta),
            self.franja.control(self.paleta),
            self.aviso_version.control(self.paleta),
        ]
        # LO QUE SE ESCONDE EN PANTALLA COMPLETA (ver pantalla_completa).
        self._marco = (menu, cuerpo, relleno, franjas)

        pagina.add(self._con_el_fondo(
            ft.Column([principal, *franjas], spacing=0, expand=True)
        ))
        pagina.update()
        # Despues del update: la cuenta atras necesita que la franja este ya en
        # la pagina para poder repintarse. Solo arranca la primera vez.
        self.franja.empezar_a_latir()
        self.franja_entreno.empezar_a_latir()
        self.sinc.empezar()
        self.aviso_version.empezar()
        self._mirar_el_premio()
        if not self._mirar_las_medallas():
            self._mirar_los_pendientes()
        if not self._whatsapp_ofrecido:
            # UNA VEZ POR APERTURA como mucho, no en cada montaje (que pasa al
            # cambiar de tema o de ancho). La de una vez para siempre la lleva
            # el ajuste: ver sumar_whatsapp.
            self._whatsapp_ofrecido = True
            sumar_whatsapp.ofrecer_si_toca(pagina, self.paleta, self.avisos)

        if self.pantalla is not None:
            self.pantalla.montada()

    # ----------------------------------------------------------------------

    def _hace_falta_entrar(self) -> bool:
        """Si hay que ensenar la puerta.

        SIN SERVICIO DE CUENTAS NO SE CIERRA LA PUERTA, y eso no es una
        concesion: una version compilada sin DIRECCION dejaria una puerta que
        NADIE puede abrir, con la aplicacion y los datos detras. Mejor abierta
        que rota.
        """
        if not cuentas.hay_servidor():
            return False
        with conectado() as conexion:
            return ajustes.leer_sesion(conexion) is None

    def _con_el_fondo(self, contenido: ft.Control) -> ft.Control:
        """El contenido, con el dibujo del tema detras.

        UNA PILA Y NO UN FONDO DE CONTENEDOR, porque no es un color: es un
        dibujo. Va debajo del todo, y como las tarjetas llevan fondo propio,
        solo asoma por los margenes. Eso cumple sola la regla que importa: el
        motivo nunca queda detras de un dato.

        SI EL TEMA NO LLEVA MOTIVO se devuelve el contenido tal cual, sin la
        pila: una capa de mas que no dibuja nada es una capa de mas.
        """
        fondo = motivo_fondo.dibujar(
            self.paleta,
            getattr(self.pagina, "width", None),
            getattr(self.pagina, "height", None),
        )
        if fondo is None:
            return contenido
        return ft.Stack([fondo, contenido], expand=True)

    def _aparato_sin_estrenar(self) -> bool:
        """Si en este aparato todavia no hay nada que enseñar.

        QUE SE MIRA: si ya se ha sincronizado alguna vez con una cuenta. Es la
        señal de «aqui ya hay cosas»: la primera sincronizacion es justo la que
        trae el historial. Mirar tabla por tabla si hay datos seria mas exacto
        y costaria una consulta por cada una en cada arranque, para contestar
        lo mismo.

        SI FALLA AL MIRARLO se responde que NO hay que esperar. Entre abrir sin
        estar al dia y no abrir, se abre: los datos estan en este aparato.
        """
        try:
            with conectado() as conexion:
                return sincronia.cuenta_sincronizada(conexion) is None
        except Exception:  # noqa: BLE001
            return False

    def _montar_la_espera(self) -> None:
        """Un cartel mientras se baja lo del otro aparato, y nada más.

        SE CORTA SOLA A LOS ESPERA_MAXIMA SEGUNDOS. Sin internet la petición
        tarda lo que tarde en rendirse, y la aplicación no puede quedarse sin
        abrir por eso: pasado ese rato se abre con lo que hay aquí y la
        sincronización sigue por su cuenta.
        """
        self._esperando_al_arranque = True
        self.pagina.add(
            ft.Container(
                content=ft.Column(
                    [
                        ft.ProgressRing(color=self.paleta.acento, width=28, height=28),
                        ft.Text(
                            "Poniendo al día tus datos…",
                            size=estilo.TEXTO,
                            color=self.paleta.ink_soft,
                        ),
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=14,
                    expand=True,
                ),
                expand=True,
                bgcolor=self.paleta.canvas,
            )
        )
        self.pagina.update()
        self.sinc.empezar()
        self.pagina.run_task(self._no_esperar_de_mas)

    async def _no_esperar_de_mas(self) -> None:
        await asyncio.sleep(ESPERA_MAXIMA)
        if not self.sinc.primera_hecha:
            self.sinc.primera_hecha = True
            self._ya_esta_al_dia()

    def _ya_esta_al_dia(self) -> None:
        """La primera sincronización terminó (o se acabó la espera): a dibujar."""
        if self._esperando_al_arranque:
            self._esperando_al_arranque = False
            self.montar()

    def _montar_la_puerta(self) -> None:
        """Dibuja solo la puerta y se acaba el montaje aqui."""
        if self.puerta is None:
            self.puerta = PantallaEntrada(self.pagina, self.paleta, self.montar)
        self.pagina.add(self.puerta.control(self.paleta))
        self.pagina.update()

    def _pantalla_sin_dia(self) -> ft.Control:
        """Que se ve cuando la base se quedo sin ningun dia abierto.

        POR QUE UN BOTON Y NO ARREGLARLO SOLO: abrir un dia a escondidas
        taparia el motivo por el que falto —normalmente la sincronizacion a
        medias— y dejaria dias que nadie ha vivido metidos en el historial.
        Asi el usuario ve que paso, lo arregla en un toque y sabe que ese dia
        esta ahi porque lo abrio el.
        """
        return ft.Column(
            [
                componentes.aviso_vacio(
                    self.paleta,
                    "No hay ningun dia abierto.\n\n"
                    "Todo lo que apuntas (comidas, gastos, habitos) se guarda "
                    "en el dia que tengas abierto, y ahora mismo no hay "
                    "ninguno. Suele pasar cuando se cierra el dia en otro "
                    "aparato y la sincronizacion aun no ha traido el nuevo.\n\n"
                    "Nada de lo que ya tienes guardado se ha perdido.",
                ),
                componentes.boton(
                    self.paleta,
                    "Abrir un dia ahora",
                    icono=ft.Icons.TODAY,
                    al_pulsar=lambda _: self._abrir_un_dia(),
                    principal=True,
                ),
            ],
            spacing=16,
            tight=True,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _abrir_un_dia(self) -> None:
        """Abre el dia que falta y vuelve a dibujar la ventana."""
        from datetime import datetime

        with conectado() as conexion:
            repositorio_dias.reabrir(conexion, ahora=datetime.now())
        self.montar()

    def _contenido(self) -> ft.Control:
        nombre = SECCIONES[self.seleccionada][0]

        if nombre == "Dashboard":
            self.pantalla = PantallaDashboard(self.pagina, self.paleta, self._abrir_entreno)
            return self.pantalla.control
        if nombre == "Alimentación":
            self.pantalla = PantallaAlimentacion(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Horario":
            self.pantalla = PantallaHorario(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Educación":
            self.pantalla = PantallaEducacion(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Comunidad":
            self.pantalla = PantallaComunidad(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Objetivos":
            self.pantalla = PantallaObjetivos(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Focus":
            # LA DE FOCUS SE CREA UNA VEZ Y SE REUTILIZA, igual que la franja
            # del descanso: su reloj tiene que seguir andando aunque te vayas a
            # otra sección. Crear una nueva cada vez era lo que lo paraba.
            if self.focus is None:
                self.focus = PantallaFocus(self.pagina, self.paleta)
            else:
                self.focus.cambiar_paleta(self.paleta)
            self.pantalla = self.focus
            return self.pantalla.control
        if nombre == "Finanzas":
            if self.vista_finanzas is VistaFinanzas.INVERSIONES:
                self.pantalla = PantallaInversiones(
                    self.pagina, self.paleta, self._cambiar_vista_finanzas
                )
            else:
                self.pantalla = PantallaFinanzas(
                    self.pagina, self.paleta, self._cambiar_vista_finanzas
                )
            return self.pantalla.control
        if nombre == "Hábitos":
            self.pantalla = PantallaHabitos(self.pagina, self.paleta)
            return self.pantalla.control
        if nombre == "Gimnasio":
            # La franja se le pasa para que marcar una serie pueda arrancar el
            # descanso. La pantalla no la crea ni la destruye: solo la usa.
            self.pantalla = PantallaGimnasio(
                self.pagina,
                self.paleta,
                self.franja,
                self._abrir_entreno,
                self._abrir_resumen,
            )
            return self.pantalla.control
        if nombre == "Pizarra":
            self.pantalla = PantallaPizarra(
                self.pagina, self.paleta, al_pantalla_completa=self.pantalla_completa,
                portapapeles=self.portapapeles, selector=self.selector,
            )
            return self.pantalla.control
        if nombre == "Configuración":
            self.pantalla = PantallaConfiguracion(
                self.pagina, self.paleta, self.montar, self.selector, self.avisos
            )
            return self.pantalla.control

        raise ValueError(f"la sección «{nombre}» no tiene pantalla")

    def es_estrecha(self) -> bool:
        """Si la ventana es tan estrecha que hay que dibujar como en un móvil.

        QUIEN DECIDE ES estilo.ancho_de: en el escritorio, mientras Flet no
        haya medido la ventana se responde que no (así no parpadea al primer
        dibujado), pero en un teléfono se da por hecho un teléfono, porque allí
        la medida puede no llegar nunca.
        """
        ancho = estilo.ancho_de(self.pagina)
        return bool(ancho) and ancho < estilo.ANCHO_ESTRECHO

    def _vigilar_el_ancho(self) -> None:
        """Vuelve a dibujar SOLO al cruzar el corte, no en cada arrastre.

        Redibujar en cada píxel de un arrastre de ventana rehace las diez
        secciones cientos de veces y te saca el cursor de donde estuvieras
        escribiendo. Solo importa el momento en que se pasa de ancho a estrecho.
        """

        # DE QUÉ SE PARTE: de lo que se acaba de dibujar, no de "ancha". Si se
        # partiera de un valor fijo, el primer aviso de tamaño en un móvil
        # parecería un cambio y rehacía la ventana entera sin motivo.
        self._era_estrecha = self.es_estrecha()

        def al_cambiar(_):
            ahora = self.es_estrecha()
            if ahora != self._era_estrecha:
                self._era_estrecha = ahora
                self.montar()

        self.pagina.on_resize = al_cambiar

    def _mirar_el_premio(self) -> None:
        """Si toca el cartel de la semana, lo enseña. Una vez por semana.

        SE MIRA AL MONTAR Y AL VOLVER A LA VENTANA, y no con un temporizador:
        si tienes la aplicación abierta desde el domingo a mediodía, a las 18:00
        no saldría nada hasta cerrarla. Al volver a ella, sí.

        QUE NO SALGA DOS VECES a la vez lo cuida `_premio_abierto`; que no
        salga dos semanas seguidas lo cuida la base (cartel_visto).
        """
        if self._premio_abierto:
            return
        with conectado() as conexion:
            premio = dialogo_recompensa.pendiente(conexion)
        if premio is None:
            return
        self._premio_abierto = True

        def cerrado() -> None:
            self._premio_abierto = False

        dialogo_recompensa.abrir(self.pagina, self.paleta, premio, cerrado)

    def _mirar_las_medallas(self) -> bool:
        """Si ganaste una medalla nueva, te la enseña. Una vez cada una.
        Devuelve si la enseñó (para no abrir otro cartel encima).

        LO PIDIÓ EL USUARIO: «si hacés 7 días seguidos de racha, la app te da
        una medallita». Aquí es donde «te da»: sale un cartel con la medalla.

        NO SALE ENCIMA DE OTRO CARTEL NI ENTRENANDO: dos ventanitas a la vez
        se pisan, y con las manos en la barra no es el momento.

        SI HAY VARIAS NUEVAS SE ENSEÑA LA MAYOR y se cuentan las demás: la
        primera vez, quien ya tenía rachas largas ganaría cinco de golpe, y
        cinco carteles seguidos no felicitan, molestan.
        """
        if self._premio_abierto or self.entrenando is not None:
            return False
        try:
            with conectado() as conexion:
                jornada = repositorio_dias.jornada_abierta(conexion)
                nuevas = medallas.nuevas(conexion, medallas.todas(conexion, jornada))
                if not nuevas:
                    return False
                medallas.marcar_vistas(conexion, nuevas)
        except Exception:  # noqa: BLE001
            # UNA MEDALLA NO PUEDE IMPEDIR ABRIR LA APLICACIÓN.
            return False
        dialogo_medalla.abrir(self.pagina, self.paleta, nuevas)
        return True

    def _mirar_los_pendientes(self) -> None:
        """Si tenés tareas pendientes y pasaron 8 horas desde el último aviso,
        abre la lista de la campana. La regla está en datos/aviso_pendientes.py.

        SE MIRA AL MONTAR Y AL VOLVER A LA VENTANA, como el premio: lo eligió
        el usuario, porque en el celular Focus casi nunca se cierra del todo.

        NO SALE ENCIMA DE OTRO CARTEL NI ENTRENANDO, igual que las medallas.
        Si no sale ahora, sale la próxima vez que entres: la hora del aviso
        solo se apunta cuando de verdad se abrió.
        """
        if self._premio_abierto or self.entrenando is not None or self.resumiendo is not None:
            return
        ahora = datetime.now()
        try:
            # CON LA PUERTA DE ENTRAR PUESTA, NO: al volver a la app sin
            # sesión, la lista saldría encima del formulario.
            if self._hace_falta_entrar():
                return
            with conectado() as conexion:
                if not aviso_pendientes.toca_avisar(conexion, ahora):
                    return
                aviso_pendientes.apuntar_aviso(conexion, ahora)
        except Exception:  # noqa: BLE001
            # UN AVISO NO PUEDE IMPEDIR ABRIR LA APLICACIÓN.
            return
        dialogo_recordatorios.abrir(self.pagina, self.paleta, self._poner_al_dia_sin_moverse)

    def _al_volver(self, estado) -> None:
        """Al volver a la ventana: ponerse al dia y mirar si hay version nueva."""
        self.sinc.al_volver_a_la_ventana(estado)
        self.aviso_version.mirar_ahora()
        # FLET MANDA UN ENUM, NO UN TEXTO: comparado tal cual con "resume" no
        # coincidía nunca, y lo de aquí abajo no corría al volver. Igual que
        # en sincronizador.al_volver_a_la_ventana.
        if getattr(estado, "value", estado) in AL_VOLVER:
            self._mirar_el_premio()
            self._mirar_los_pendientes()
            self.franja.al_volver()

    def _llego_algo(self) -> None:
        """Otro aparato cambió algo y ya está aquí: se enseña.

        SOLO SE REPINTA SOLO EL DASHBOARD. Es la pantalla de mirar, donde
        esperas ver aparecer el agua que apuntaste en el móvil. En las demás
        puede que estés escribiendo en un campo, y repintar te lo borraría a
        media palabra; ahí lo nuevo aparece al cambiar de sección.
        """
        if (
            self.entrenando is None
            and self.resumiendo is None
            and isinstance(self.pantalla, PantallaDashboard)
        ):
            # POR DENTRO Y NO ENTERA: si estabas abajo del todo mirando los
            # gastos, que llegue algo del móvil no puede subirte arriba.
            self._poner_al_dia_sin_moverse()

    def _poner_al_dia_sin_moverse(self) -> None:
        """Enseña lo que cambió SIN rehacer la ventana: te quedas donde estabas.

        LO PIDIÓ EL USUARIO: «cada vez que asigno o modifico un valor, la página
        se recarga y vuelve al principio». Se midió la causa en una ventana de
        verdad: rehacer la ventana entera (`montar`) crea listas nuevas, y una
        lista nueva empieza arriba; cambiar las piezas DE LA MISMA lista deja
        la posición donde estaba. Así que aquí se cambia solo lo necesario:

          - el número de la campana, en su hueco;
          - la pantalla de la sección, que se repinta por dentro de su lista.

        SI NO SE PUEDE POR DENTRO (la ventana aún no está puesta), se rehace
        entera: mejor subir arriba que enseñar algo viejo.
        """
        with conectado() as conexion:
            self.pendientes = len(repositorio_tareas.listar_pendientes(conexion))
        hueco = getattr(self, "_hueco_campana", None)
        try:
            if hueco is not None:
                hueco.content = self._dibujo_campana()
                hueco.update()
            if self.entrenando is not None and self.pantalla_entreno is not None:
                self.pantalla_entreno.refrescar()
            elif self.resumiendo is None and hasattr(self.pantalla, "refrescar"):
                self.pantalla.refrescar()
        except Exception:  # noqa: BLE001
            self.montar()


    # ----------------------------------------------------------------------

    def pantalla_completa(self, activar: bool) -> None:
        """La sección ocupa TODO el monitor: sin el menú de Focus, sin las
        franjas de abajo, sin la barra de tareas ni la del título de Windows.

        LO PIDIÓ EL USUARIO PARA LA PIZARRA (12 nov 2026). SE ESCONDE, NO SE
        REARMA: rearmar la ventana crearía la pantalla de nuevo, y la pizarra
        perdería lo que se puede deshacer y dónde estaba mirando.
        """
        if self._marco is None or activar == self.en_pantalla_completa:
            return
        menu, cuerpo, relleno, franjas = self._marco
        self.en_pantalla_completa = activar
        for pieza in (menu, *franjas):
            pieza.visible = not activar
        cuerpo.padding = 0 if activar else relleno
        self.pagina.window.full_screen = activar
        self.pagina.update()

    def _seleccionar(self, indice: int) -> None:
        # SE CIERRA LA VENTANITA SIEMPRE, incluso al tocar la sección en la que
        # ya estás: si no, tocarla parecería que la aplicación se ha colgado.
        if self.es_estrecha():
            self.pagina.pop_dialog()
        # GIMNASIO CON UN ENTRENO EN MARCHA ENTRA DIRECTO AL ENTRENO: lo pidió
        # el usuario, «cuando vuelvo al apartado de entrenamiento lo retoma».
        # Se mira aunque ya estés en Gimnasio: tocarlo es querer entrenar.
        if SECCIONES[indice][0] == "Gimnasio":
            with conectado() as conexion:
                en_marcha = repositorio_gimnasio.sesion_en_marcha(conexion, datetime.now())
            if en_marcha is not None:
                self.seleccionada = indice
                self._abrir_entreno(en_marcha.fecha, en_marcha.bloque)
                return
        if indice == self.seleccionada:
            return
        self.seleccionada = indice
        self.montar()

    def _cambiar_vista_finanzas(self, cual: VistaFinanzas) -> None:
        """Pasa de Movimientos a Inversiones o al revés, dentro de Finanzas."""
        if cual is self.vista_finanzas:
            return
        self.vista_finanzas = cual
        self.montar()


async def construir(pagina: ft.Page) -> None:
    """Monta la ventana entera. Es lo que recibe Flet al arrancar.

    ES ASINCRONA POR EL NAVEGADOR: ahi hay que recuperar el archivo de datos del
    almacen ANTES de montar nada, y eso se espera. En el ordenador esas dos
    lineas no hacen nada y todo sigue igual.

    EL ORDEN NO ES UN DETALLE: montar la ventana lee ajustes —el tema, el
    estilo, la jornada— nada mas empezar. Si eso pasara antes de recuperar, se
    encontraria una base vacia, la crearia de cero y machacaria lo guardado.
    """
    await guardado_web.restaurar()
    base_ocupada.vigilar(pagina)
    Ventana(pagina).montar()
    guardado_web.arrancar(pagina)
    if not pagina.web and pagina.platform == ft.PagePlatform.WINDOWS:
        _presentarse_en_windows(pagina)


def _presentarse_en_windows(pagina: ft.Page) -> None:
    """Que la barra de tareas muestre Focus1% y no «Flet». Ver ventana_windows.py.

    DOS COSAS DISTINTAS: el ícono de la ventana se lo dice Flet, y la
    identidad (que la junta con el ícono anclado) se la pone Windows. La
    segunda va en un hilo aparte y reintenta unos segundos: la ventana de Flet
    puede tardar un poco en existir del todo, y esperar aquí retrasaría el
    arranque por algo que no es urgente.
    """
    # SE IMPORTA AQUÍ, SOLO EN WINDOWS: habla con Windows por ctypes, y en el
    # navegador (Pyodide) o en Android esas piezas no existen o no sirven.
    from ..sistema import ventana_windows

    if estilo.RUTA_ICONO_WINDOWS.is_file():
        pagina.window.icon = str(estilo.RUTA_ICONO_WINDOWS)
        pagina.update()

    def intentar() -> None:
        for _ in range(20):
            if ventana_windows.presentarse(
                TITULO, estilo.RUTA_ICONO_WINDOWS, estilo.RUTA_LANZADOR
            ):
                return
            time.sleep(0.5)

    pagina.run_thread(intentar)


def ejecutar() -> None:
    """Arranca la aplicación. Es lo que llama abrir.py."""
    ft.run(construir)
