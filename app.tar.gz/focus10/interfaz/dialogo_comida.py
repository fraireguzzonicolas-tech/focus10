"""La ventanita de apuntar o corregir algo que has comido.

AL ESCRIBIR, SE OFRECE, PERO NADA SE RELLENA NI SE GUARDA SOLO. Salen dos tipos
de ayuda debajo del nombre, y hay que tocarlas:

  1. LO QUE YA APUNTASTE, con TUS números de la última vez. Van primero: si
     sueles comer la milanesa con puré, "mila" te ofrece la tuya, no la de una
     tabla. Así la aplicación aprende de ti sin inventar nada.
  2. SI NO HAY NADA TUYO QUE ENCAJE y es una cosa normal ("2 huevos con
     tostadas"), una estimación con "≈" y los gramos que se supusieron.

LO QUE NO SE ENTIENDE NO SE ESTIMA. "Napolitana con berenjena" la escribes tú
una vez, y desde ahí sale en la ayuda número 1. Por qué tanto cuidado: una
versión muy anterior le puso 29 kcal a 300 gramos de fideos.
"""

from __future__ import annotations

from datetime import date, datetime

import flet as ft

from ..datos import repositorio_alimentacion
from ..datos.bd import conectado
from ..dominio.alimento import (
    Registro,
    parsear_gramos,
    parsear_kcal,
    texto_gramos,
)
from ..dominio.estimar_comida import Estimacion, estimar
from ..dominio.palabras import encaja, mismo_nombre
from . import componentes
from .estilo import Paleta

ANCHO_NUMERO = 96


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    jornada: date,
    al_guardar,
    registro: Registro | None = None,
) -> _DialogoComida:
    """Abre la ventanita: vacía para apuntar, o con un registro para corregirlo."""
    ventanita = _DialogoComida(pagina, paleta, jornada, al_guardar, registro)
    pagina.show_dialog(ventanita.control)
    # SE DEVUELVE PARA PODER PROBARLA. Quien la abre normalmente no necesita
    # nada de vuelta y puede ignorarlo; los tests, en cambio, necesitan escribir
    # en sus campos, y buscarla rebuscando en la memoria del programa era
    # frágil: cogía la de otro test porque ese orden no es el de creación.
    return ventanita


CUANTAS_SUGERENCIAS = 4
"""Cuantas comidas se ofrecen al escribir.

Cuatro caben sin empujar los campos fuera de la pantalla de un movil, y con mas
la lista deja de leerse de un vistazo: hay que ponerse a buscar, que es
exactamente el trabajo que esto viene a quitar.
"""


class _DialogoComida:
    def __init__(self, pagina, paleta, jornada, al_guardar, registro) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.jornada = jornada
        self.al_guardar = al_guardar
        self.registro = registro

        with conectado() as conexion:
            self.conocidas = repositorio_alimentacion.mas_repetidos(conexion)

        self.nombre = componentes.campo_texto(
            paleta, "Qué has comido", valor=registro.nombre if registro else "",
            pista="2 huevos con tostadas",
        )
        self.nombre.on_change = lambda _: self._pintar_sugerencias()

        self.sugerencias = ft.Column(spacing=2, tight=True)
        self.kcal = componentes.campo_texto(
            paleta, "Calorías", valor=str(registro.kcal) if registro else "",
            pista="0", ancho=ANCHO_NUMERO,
        )
        self.proteinas = self._campo_gramos("Proteínas", "proteinas")
        self.carbohidratos = self._campo_gramos("Carbohidratos", "carbohidratos")
        self.grasas = self._campo_gramos("Grasas", "grasas")

        self.aviso = ft.Text("", size=11, color=paleta.muted, visible=False)
        """Qué se supuso al usar una estimación. Se queda a la vista mientras
        corriges: si ves "tostada 50 g" y fueron tres, sabes qué tocar."""

        self.error = ft.Text("", size=12, color=paleta.negativo, visible=False)
        self.nota = componentes.campo_texto(
            self.paleta,
            "Nota (opcional)",
            valor=(registro.nota if registro else ""),
            pista="lo que quieras acordarte",
        )
        self.nota.multiline = True
        self.nota.min_lines = 2

    def _campo_gramos(self, etiqueta: str, campo: str) -> ft.TextField:
        valor = ""
        if self.registro:
            valor = texto_gramos(getattr(self.registro, campo))
        return componentes.campo_texto(
            self.paleta, f"{etiqueta} (g)", valor=valor, pista="0", ancho=ANCHO_NUMERO
        )

    @property
    def control(self) -> ft.AlertDialog:
        piezas: list[ft.Control] = [
            self.nombre,
            self.sugerencias,
            componentes.separador(self.paleta),
            ft.Text(
                "Toca una sugerencia para rellenar los números. Lo que lleva ≈ "
                "es una estimación: revísala. Lo que dejes vacío cuenta como cero.",
                size=11,
                color=self.paleta.muted,
            ),
            ft.Row([self.kcal, self.proteinas], spacing=8),
            ft.Row([self.carbohidratos, self.grasas], spacing=8),
            self.aviso,
            self.nota,
            self.error,
        ]

        if self.registro is not None:
            piezas += [
                ft.Container(height=4),
                componentes.boton(
                    self.paleta,
                    "Borrar este registro",
                    icono=ft.Icons.DELETE_OUTLINE,
                    al_pulsar=lambda _: self._pedir_borrado(),
                ),
            ]

        return componentes.dialogo(
            self.paleta,
            "Corregir" if self.registro else "Apuntar comida",
            ft.Column(piezas, spacing=10, tight=True, width=380,
                      scroll=ft.ScrollMode.AUTO),
            pagina=self.pagina,
            al_aceptar=lambda _: self._guardar(),
        )

    def _pintar_sugerencias(self) -> None:
        """Lo tuyo primero; la estimación, solo si no hay nada tuyo que encaje.

        SOLO SALEN CON DOS LETRAS O MAS: con una sola coincidiria medio historial
        y la lista seria ruido, que es justo lo que se queria quitar.
        """
        escrito = (self.nombre.value or "").strip()
        if len(escrito) < 2:
            self.sugerencias.controls = []
            self.pagina.update()
            return

        encajan = [
            (uno, veces)
            for uno, veces in self.conocidas
            if encaja(escrito, uno.nombre) and not mismo_nombre(escrito, uno.nombre)
        ][:CUANTAS_SUGERENCIAS]

        fichas = [self._sugerencia_tuya(uno, veces) for uno, veces in encajan]
        # SI YA LO HAS COMIDO, LA TABLA NO OPINA: tus números valen más que los
        # de una porción estándar, también cuando lo escribes igual que la otra
        # vez.
        ya_lo_conozco = any(mismo_nombre(escrito, uno.nombre) for uno, _ in self.conocidas)
        if not encajan and not ya_lo_conozco and (estimada := estimar(escrito)):
            fichas.append(self._sugerencia_estimada(estimada))

        self.sugerencias.controls = fichas
        self.pagina.update()

    def _ficha(self, titulo: str, numeros: str, lado: str, al_tocar) -> ft.Control:
        """Una sugerencia, con sus numeros a la vista.

        SE ENSENAN LOS NUMEROS ANTES DE ELEGIRLA: si te ofreciera solo el nombre
        tendrias que pulsarla para ver que trae, y a veces no es la que querias.
        """
        return ft.Container(
            content=ft.Row(
                [
                    ft.Column(
                        [
                            ft.Text(titulo, size=13, color=self.paleta.ink),
                            ft.Text(numeros, size=11, color=self.paleta.muted),
                        ],
                        spacing=1,
                        tight=True,
                        expand=True,
                    ),
                    ft.Text(lado, size=11, color=self.paleta.muted),
                ],
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=10, vertical=7),
            bgcolor=self.paleta.surface_2,
            border_radius=8,
            on_click=lambda _: al_tocar(),
            ink=True,
        )

    def _sugerencia_tuya(self, registro: Registro, veces: int) -> ft.Control:
        return self._ficha(
            registro.nombre,
            _numeros(registro.kcal, registro.proteinas,
                     registro.carbohidratos, registro.grasas),
            f"{veces}x",
            lambda: self._usar(registro),
        )

    def _sugerencia_estimada(self, estimada: Estimacion) -> ft.Control:
        return self._ficha(
            estimada.detalle(),
            "≈ " + _numeros(estimada.kcal, estimada.proteinas,
                            estimada.carbohidratos, estimada.grasas),
            "estimado",
            lambda: self._usar_estimacion(estimada),
        )

    def _rellenar(self, kcal: int, proteinas: int, carbohidratos: int, grasas: int) -> None:
        self.kcal.value = str(kcal)
        self.proteinas.value = texto_gramos(proteinas)
        self.carbohidratos.value = texto_gramos(carbohidratos)
        self.grasas.value = texto_gramos(grasas)
        self.sugerencias.controls = []

    def _usar(self, registro: Registro) -> None:
        """Rellena con tu comida de la última vez. NO la guarda.

        SE RELLENA Y SE PARA AHI: si hoy te has comido media racion, cambias las
        calorias y ya. Guardar directamente seria decidir por ti.
        """
        self.nombre.value = registro.nombre
        self._rellenar(registro.kcal, registro.proteinas,
                       registro.carbohidratos, registro.grasas)
        self.aviso.visible = False
        self.pagina.update()

    def _usar_estimacion(self, estimada: Estimacion) -> None:
        """Rellena con la estimación y deja escrito qué se supuso. NO la guarda.

        EL NOMBRE SE QUEDA COMO LO ESCRIBISTE: "2 huevos con tostadas" dice más
        que "huevo + tostada", y es lo que buscarás la próxima vez.
        """
        self._rellenar(estimada.kcal, estimada.proteinas,
                       estimada.carbohidratos, estimada.grasas)
        self.aviso.value = (
            f"≈ Estimado con porciones estándar: {estimada.detalle()}. "
            "Si comiste otra cantidad, cambia los números."
        )
        self.aviso.visible = True
        self.pagina.update()

    def _guardar(self) -> None:
        try:
            registro = Registro(
                id=self.registro.id if self.registro else None,
                nombre=self.nombre.value or "",
                # LA ETIQUETA YA NO SE PIDE, pero si el registro la traia se
                # respeta: corregir una comida de hace meses no puede borrarle
                # el "desayuno" que el usuario escribio en su dia solo porque el
                # campo ya no se ensena. Lo nuevo se guarda sin ella.
                comida=self.registro.comida if self.registro else "",
                nota=(self.nota.value or "").strip(),
                jornada=self.jornada,
                momento=self.registro.momento
                if self.registro
                else datetime.now().replace(microsecond=0),
                # SE CONSERVA LO QUE YA TUVIERA: al corregir una comida
                # apuntada hace meses, sus valores viejos siguen ahí. Ponerlos
                # en blanco borraría algo que el usuario escribió, y solo porque
                # el campo ya no se enseña.
                cantidad=self.registro.cantidad if self.registro else "",
                unidad=self.registro.unidad if self.registro else "",
                kcal=parsear_kcal(self.kcal.value or ""),
                proteinas=parsear_gramos(self.proteinas.value or ""),
                carbohidratos=parsear_gramos(self.carbohidratos.value or ""),
                grasas=parsear_gramos(self.grasas.value or ""),
            )
        except (ValueError, TypeError) as fallo:
            self.error.value = str(fallo)
            self.error.visible = True
            self.pagina.update()
            return

        with conectado() as conexion:
            if registro.id is None:
                repositorio_alimentacion.crear(conexion, registro)
            else:
                repositorio_alimentacion.actualizar(conexion, registro)

        self.pagina.pop_dialog()
        self.al_guardar()

    def _pedir_borrado(self) -> None:
        # Se cierra esta ventanita antes de preguntar: dos diálogos apilados
        # dejan el de atrás sin poder tocarse y parece que se ha colgado.
        self.pagina.pop_dialog()
        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo="Borrar el registro",
            texto=f"Se borra «{self.registro.nombre}». No se puede deshacer.",
            al_aceptar=lambda _: self._borrar(),
        )

    def _borrar(self) -> None:
        with conectado() as conexion:
            repositorio_alimentacion.borrar(conexion, self.registro.id)
        self.pagina.pop_dialog()
        self.al_guardar()


def _numeros(kcal: int, proteinas: int, carbohidratos: int, grasas: int) -> str:
    return (
        f"{kcal} kcal · {texto_gramos(proteinas)} P · "
        f"{texto_gramos(carbohidratos)} C · {texto_gramos(grasas)} G"
    )
