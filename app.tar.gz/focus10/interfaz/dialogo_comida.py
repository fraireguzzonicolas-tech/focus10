"""La ventanita de apuntar o corregir algo que has comido.

TODOS LOS CAMPOS ESTÁN VACÍOS AL EMPEZAR, y ninguno se rellena solo. Escribir
"Manzana" no trae 52 kcal de ninguna parte. Una versión anterior de esto
analizaba el texto y calculaba las calorías: le puso 29 a 300 gramos de fideos.
Aquí no hay analizador que arreglar porque no hay analizador.

LO ÚNICO QUE VIENE RELLENO es cuando abres esto desde "repetir": entonces trae
los números QUE ESCRIBISTE TÚ la última vez, y puedes cambiarlos antes de
añadirlo. Eso no es la aplicación adivinando: es la aplicación acordándose.
"""

from __future__ import annotations

from datetime import date, datetime

import flet as ft

from ..datos import repositorio_alimentacion
from ..datos.bd import conectado
from ..dominio.alimento import (
    Registro,
    parsear_gramos,
    parsear_kcal,
    texto_gramos,
)
from . import componentes
from .estilo import Paleta

ANCHO_NUMERO = 96


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    jornada: date,
    al_guardar,
    registro: Registro | None = None,
    *,
    copiando: bool = False,
) -> _DialogoComida:
    """Abre la ventanita.

    `copiando` es lo que distingue "corregir esto" de "repetir esto": con
    copiando, los valores vienen puestos pero se crea un registro NUEVO. Sin él,
    se está editando el que ya había. Confundirlos haría que repetir la comida de
    ayer machacara la de ayer.
    """
    ventanita = _DialogoComida(
        pagina, paleta, jornada, al_guardar, registro, copiando
    )
    pagina.show_dialog(ventanita.control)
    # SE DEVUELVE PARA PODER PROBARLA. Quien la abre normalmente no necesita
    # nada de vuelta y puede ignorarlo; los tests, en cambio, necesitan escribir
    # en sus campos, y buscarla rebuscando en la memoria del programa era
    # frágil: cogía la de otro test porque ese orden no es el de creación.
    return ventanita


CUANTAS_SUGERENCIAS = 4
"""Cuantas comidas se ofrecen al escribir.

Cuatro caben sin empujar los campos fuera de la pantalla de un movil, y con mas
la lista deja de leerse de un vistazo: hay que ponerse a buscar, que es
exactamente el trabajo que esto viene a quitar.
"""


class _DialogoComida:
    def __init__(
        self, pagina, paleta, jornada, al_guardar, registro, copiando
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.jornada = jornada
        self.al_guardar = al_guardar
        self.registro = registro
        self.copiando = copiando

        # LO QUE YA HAS APUNTADO OTRAS VECES, con TUS numeros de la ultima vez.
        # No es una base de datos de alimentos ni una estimacion: son las
        # comidas que tu escribiste, tal y como las escribiste.
        with conectado() as conexion:
            self.conocidas = repositorio_alimentacion.mas_repetidos(conexion)

        self.nombre = componentes.campo_texto(
            paleta, "Qué has comido", valor=registro.nombre if registro else "",
            pista="Fideos",
        )
        self.nombre.on_change = lambda _: self._pintar_sugerencias()

        self.sugerencias = ft.Column(spacing=2, tight=True)
        self.kcal = componentes.campo_texto(
            paleta, "Calorías", valor=str(registro.kcal) if registro else "",
            pista="0", ancho=ANCHO_NUMERO,
        )
        self.proteinas = self._campo_gramos("Proteínas", "proteinas")
        self.carbohidratos = self._campo_gramos("Carbohidratos", "carbohidratos")
        self.grasas = self._campo_gramos("Grasas", "grasas")

        self.error = ft.Text("", size=12, color=paleta.negativo, visible=False)

        # LA FILA DE COMIDAS SE CREA UNA SOLA VEZ y luego solo se le cambian los
        # hijos. Antes, elegir una comida rehacia la ventanita entera, y eso
        # desconectaba los campos de texto: seguian viendose en pantalla pero lo
        # que escribias ya no llegaba a Python.
        self.anadiendo = False
        self.nota = componentes.campo_texto(
            self.paleta,
            "Nota (opcional)",
            valor=(registro.nota if registro else ""),
            pista="lo que quieras acordarte",
        )
        self.nota.multiline = True
        self.nota.min_lines = 2


    def _campo_gramos(self, etiqueta: str, campo: str) -> ft.TextField:
        valor = ""
        if self.registro:
            valor = texto_gramos(getattr(self.registro, campo))
        return componentes.campo_texto(
            self.paleta, f"{etiqueta} (g)", valor=valor, pista="0", ancho=ANCHO_NUMERO
        )

    @property
    def control(self) -> ft.AlertDialog:
        piezas: list[ft.Control] = [
            self.nombre,
            self.sugerencias,
            componentes.separador(self.paleta),
            ft.Text(
                "Los números los escribes tú: la aplicación no calcula ni estima "
                "nada. Lo que dejes vacío cuenta como cero.",
                size=11,
                color=self.paleta.muted,
            ),
            ft.Row([self.kcal, self.proteinas], spacing=8),
            ft.Row([self.carbohidratos, self.grasas], spacing=8),
            self.nota,
            self.error,
        ]

        if self.registro is not None and not self.copiando:
            piezas += [
                ft.Container(height=4),
                componentes.boton(
                    self.paleta,
                    "Borrar este registro",
                    icono=ft.Icons.DELETE_OUTLINE,
                    al_pulsar=lambda _: self._pedir_borrado(),
                ),
            ]

        return componentes.dialogo(
            self.paleta,
            self._titulo(),
            ft.Column(piezas, spacing=10, tight=True, width=380,
                      scroll=ft.ScrollMode.AUTO),
            pagina=self.pagina,
            al_aceptar=lambda _: self._guardar(),
        )

    def _titulo(self) -> str:
        if self.copiando:
            return "Repetir"
        return "Corregir" if self.registro else "Apuntar comida"

    def _pintar_sugerencias(self) -> None:
        """Ensena las comidas que ya apuntaste y encajan con lo que escribes.

        POR QUE ESTO Y NO CALCULAR LAS CALORIAS SOLO: el usuario pidio poder
        escribir "comi dos tostadas con huevos" y que la aplicacion sacara los
        macros. Eso no se puede hacer sin inventar numeros —cuantas tostadas, de
        que pan, huevos de que tamano— y esta aplicacion existe justamente
        porque otra le dio un numero falso.

        Esto resuelve el mismo problema por el otro lado: la primera vez lo
        escribes tu; a partir de ahi lo eliges. Cero invencion y una sola vez de
        trabajo.

        SOLO SALEN CON DOS LETRAS O MAS: con una sola coincidiria medio historial
        y la lista seria ruido, que es justo lo que se queria quitar.
        """
        escrito = (self.nombre.value or "").strip().lower()
        if len(escrito) < 2:
            self.sugerencias.controls = []
            self.pagina.update()
            return

        encajan = [
            (uno, veces)
            for uno, veces in self.conocidas
            if escrito in uno.nombre.lower() and uno.nombre.lower() != escrito
        ][:CUANTAS_SUGERENCIAS]

        self.sugerencias.controls = [
            self._una_sugerencia(uno, veces) for uno, veces in encajan
        ]
        self.pagina.update()

    def _una_sugerencia(self, registro: Registro, veces: int) -> ft.Control:
        """Una comida de las tuyas, con sus numeros a la vista.

        SE ENSENAN LOS NUMEROS ANTES DE ELEGIRLA: si te ofreciera solo el nombre
        tendrias que pulsarla para ver que trae, y a veces no es la que querias.
        Viendolos, eliges bien a la primera.
        """
        return ft.Container(
            content=ft.Row(
                [
                    ft.Column(
                        [
                            ft.Text(registro.nombre, size=13, color=self.paleta.ink),
                            ft.Text(
                                f"{registro.kcal} kcal · "
                                f"{texto_gramos(registro.proteinas)} P · "
                                f"{texto_gramos(registro.carbohidratos)} C · "
                                f"{texto_gramos(registro.grasas)} G",
                                size=11,
                                color=self.paleta.muted,
                            ),
                        ],
                        spacing=1,
                        tight=True,
                        expand=True,
                    ),
                    ft.Text(
                        f"{veces}x", size=11, color=self.paleta.muted
                    ),
                ],
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=10, vertical=7),
            bgcolor=self.paleta.surface_2,
            border_radius=8,
            on_click=lambda _, r=registro: self._usar(r),
            ink=True,
        )

    def _usar(self, registro: Registro) -> None:
        """Rellena los campos con los de esa comida. NO la guarda.

        SE RELLENA Y SE PARA AHI: puedes cambiar cualquier numero antes de dar a
        guardar. Si hoy te has comido media racion, cambias las calorias y ya.
        Guardar directamente seria decidir por ti.
        """
        self.nombre.value = registro.nombre
        self.kcal.value = str(registro.kcal)
        self.proteinas.value = texto_gramos(registro.proteinas)
        self.carbohidratos.value = texto_gramos(registro.carbohidratos)
        self.grasas.value = texto_gramos(registro.grasas)
        self.sugerencias.controls = []
        self.pagina.update()

    def _guardar(self) -> None:
        try:
            registro = Registro(
                # Al repetir se crea uno NUEVO: sin esto, repetir la comida de
                # ayer machacaría la de ayer.
                id=None if self.copiando else (self.registro.id if self.registro else None),
                nombre=self.nombre.value or "",
                # LA ETIQUETA YA NO SE PIDE, pero si el registro la traia se
                # respeta: corregir una comida de hace meses no puede borrarle
                # el "desayuno" que el usuario escribio en su dia solo porque el
                # campo ya no se ensena. Lo nuevo se guarda sin ella.
                comida=self.registro.comida if self.registro else "",
                nota=(self.nota.value or "").strip(),
                jornada=self.jornada,
                momento=self.registro.momento
                if (self.registro and not self.copiando)
                else datetime.now().replace(microsecond=0),
                # SE CONSERVA LO QUE YA TUVIERA: al corregir una comida
                # apuntada hace meses, sus valores viejos siguen ahí. Ponerlos
                # en blanco borraría algo que el usuario escribió, y solo porque
                # el campo ya no se enseña.
                cantidad=self.registro.cantidad if self.registro else "",
                unidad=self.registro.unidad if self.registro else "",
                kcal=parsear_kcal(self.kcal.value or ""),
                proteinas=parsear_gramos(self.proteinas.value or ""),
                carbohidratos=parsear_gramos(self.carbohidratos.value or ""),
                grasas=parsear_gramos(self.grasas.value or ""),
            )
        except (ValueError, TypeError) as fallo:
            self.error.value = str(fallo)
            self.error.visible = True
            self.pagina.update()
            return

        with conectado() as conexion:
            if registro.id is None:
                repositorio_alimentacion.crear(conexion, registro)
            else:
                repositorio_alimentacion.actualizar(conexion, registro)

        self.pagina.pop_dialog()
        self.al_guardar()

    def _pedir_borrado(self) -> None:
        # Se cierra esta ventanita antes de preguntar: dos diálogos apilados
        # dejan el de atrás sin poder tocarse y parece que se ha colgado.
        self.pagina.pop_dialog()
        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo="Borrar el registro",
            texto=f"Se borra «{self.registro.nombre}». No se puede deshacer.",
            al_aceptar=lambda _: self._borrar(),
        )

    def _borrar(self) -> None:
        with conectado() as conexion:
            repositorio_alimentacion.borrar(conexion, self.registro.id)
        self.pagina.pop_dialog()
        self.al_guardar()
