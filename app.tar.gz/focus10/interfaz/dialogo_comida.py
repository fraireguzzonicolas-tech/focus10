"""La ventanita de apuntar o corregir algo que has comido.

TODOS LOS CAMPOS ESTÁN VACÍOS AL EMPEZAR, y ninguno se rellena solo. Escribir
"Manzana" no trae 52 kcal de ninguna parte. Una versión anterior de esto
analizaba el texto y calculaba las calorías: le puso 29 a 300 gramos de fideos.
Aquí no hay analizador que arreglar porque no hay analizador.

LO ÚNICO QUE VIENE RELLENO es cuando abres esto desde "repetir": entonces trae
los números QUE ESCRIBISTE TÚ la última vez, y puedes cambiarlos antes de
añadirlo. Eso no es la aplicación adivinando: es la aplicación acordándose.
"""

from __future__ import annotations

from datetime import date, datetime

import flet as ft

from ..datos import repositorio_alimentacion
from ..datos.bd import conectado
from ..dominio.alimento import (
    LARGO_MAXIMO_COMIDA,
    Registro,
    parsear_gramos,
    parsear_kcal,
    texto_gramos,
)
from . import componentes
from .estilo import Paleta

ANCHO_NUMERO = 96


def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    jornada: date,
    al_guardar,
    registro: Registro | None = None,
    *,
    copiando: bool = False,
) -> None:
    """Abre la ventanita.

    `copiando` es lo que distingue "corregir esto" de "repetir esto": con
    copiando, los valores vienen puestos pero se crea un registro NUEVO. Sin él,
    se está editando el que ya había. Confundirlos haría que repetir la comida de
    ayer machacara la de ayer.
    """
    # LAS COMIDAS SE LEEN AQUI, no se dan por sabidas: desde que las pone el
    # usuario, la lista de "desayuno, comida, cena" ya no esta en el codigo.
    with conectado() as conexion:
        comidas = [una.nombre for una in repositorio_alimentacion.listar_comidas(conexion)]

    pagina.show_dialog(
        _DialogoComida(
            pagina, paleta, jornada, al_guardar, registro, copiando, comidas
        ).control
    )


class _DialogoComida:
    def __init__(
        self, pagina, paleta, jornada, al_guardar, registro, copiando, comidas
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.jornada = jornada
        self.al_guardar = al_guardar
        self.registro = registro
        self.copiando = copiando
        self.comidas = comidas
        # LA PRIMERA DEL DIA por omision, no "desayuno" a secas: si el usuario
        # renombro sus comidas, un "desayuno" clavado aqui no existiria. Y si
        # borro todas, se queda en blanco y el guardado avisa, en vez de
        # inventarse una.
        self.comida = registro.comida if registro else (comidas[0] if comidas else "")

        self.nombre = componentes.campo_texto(
            paleta, "Qué has comido", valor=registro.nombre if registro else "",
            pista="Fideos",
        )
        self.cantidad = componentes.campo_texto(
            paleta, "Cantidad", valor=registro.cantidad if registro else "",
            pista="300", ancho=ANCHO_NUMERO,
        )
        self.unidad = componentes.campo_texto(
            paleta, "Unidad", valor=registro.unidad if registro else "",
            pista="g", ancho=ANCHO_NUMERO,
        )
        self.kcal = componentes.campo_texto(
            paleta, "Calorías", valor=str(registro.kcal) if registro else "",
            pista="0", ancho=ANCHO_NUMERO,
        )
        self.proteinas = self._campo_gramos("Proteínas", "proteinas")
        self.carbohidratos = self._campo_gramos("Carbohidratos", "carbohidratos")
        self.grasas = self._campo_gramos("Grasas", "grasas")

        self.error = ft.Text("", size=12, color=paleta.negativo, visible=False)

        # LA FILA DE COMIDAS SE CREA UNA SOLA VEZ y luego solo se le cambian los
        # hijos. Antes, elegir una comida rehacia la ventanita entera, y eso
        # desconectaba los campos de texto: seguian viendose en pantalla pero lo
        # que escribias ya no llegaba a Python.
        self.anadiendo = False
        self.campo_comida = None
        self.fila_comidas = ft.Row(spacing=6, wrap=True, run_spacing=6)
        self._pintar_comidas()

    def _campo_gramos(self, etiqueta: str, campo: str) -> ft.TextField:
        valor = ""
        if self.registro:
            valor = texto_gramos(getattr(self.registro, campo))
        return componentes.campo_texto(
            self.paleta, f"{etiqueta} (g)", valor=valor, pista="0", ancho=ANCHO_NUMERO
        )

    @property
    def control(self) -> ft.AlertDialog:
        piezas: list[ft.Control] = [
            self.nombre,
            ft.Text("Momento del día", size=12, color=self.paleta.muted),
            self.fila_comidas,
            ft.Row([self.cantidad, self.unidad], spacing=8),
            componentes.separador(self.paleta),
            ft.Text(
                "Los números los escribes tú: la aplicación no calcula ni estima "
                "nada. Lo que dejes vacío cuenta como cero.",
                size=11,
                color=self.paleta.muted,
            ),
            ft.Row([self.kcal, self.proteinas], spacing=8),
            ft.Row([self.carbohidratos, self.grasas], spacing=8),
            self.error,
        ]

        if self.registro is not None and not self.copiando:
            piezas += [
                ft.Container(height=4),
                componentes.boton(
                    self.paleta,
                    "Borrar este registro",
                    icono=ft.Icons.DELETE_OUTLINE,
                    al_pulsar=lambda _: self._pedir_borrado(),
                ),
            ]

        return componentes.dialogo(
            self.paleta,
            self._titulo(),
            ft.Column(piezas, spacing=10, tight=True, width=380,
                      scroll=ft.ScrollMode.AUTO),
            pagina=self.pagina,
            al_aceptar=lambda _: self._guardar(),
        )

    def _titulo(self) -> str:
        if self.copiando:
            return "Repetir"
        return "Corregir" if self.registro else "Apuntar comida"

    def _pintar_comidas(self) -> None:
        """Rellena la fila de comidas: las fichas y el botón de añadir."""
        fichas: list[ft.Control] = [
            ft.Container(
                content=ft.Text(
                    uno.capitalize(),
                    size=12,
                    color=self.paleta.acento_ink
                    if uno == self.comida
                    else self.paleta.ink_soft,
                ),
                padding=ft.Padding.symmetric(horizontal=12, vertical=7),
                bgcolor=self.paleta.acento
                if uno == self.comida
                else self.paleta.surface_2,
                border_radius=8,
                on_click=lambda _, c=uno: self._cambiar_comida(c),
                ink=True,
            )
            for uno in self.comidas
        ]
        fichas += self._anadir_o_campo()
        self.fila_comidas.controls = fichas

    def _anadir_o_campo(self) -> list[ft.Control]:
        """El botón de añadir, o el campo para escribir el nombre.

        SE ESCRIBE AQUÍ MISMO, EN LA FILA, y no en una segunda ventanita. Dos
        ventanitas apiladas dejan la de atrás sin poder tocarse, y para
        esquivarlo había que cerrar esta y volver a abrirla: justo lo que
        desconectaba los campos de texto y hacía que "fideos" no llegara a
        guardarse. Escribiendo en la fila no se cierra nada.
        """
        if not self.anadiendo:
            return [
                ft.Container(
                    content=ft.Row(
                        [
                            ft.Icon(ft.Icons.ADD, size=14, color=self.paleta.ink_soft),
                            ft.Text("Comida", size=12, color=self.paleta.ink_soft),
                        ],
                        spacing=4,
                        tight=True,
                    ),
                    padding=ft.Padding.symmetric(horizontal=12, vertical=7),
                    border=ft.Border.all(1, self.paleta.borde_fuerte),
                    border_radius=8,
                    tooltip="Añadir un momento del día nuevo",
                    on_click=lambda _: self._empezar_a_anadir(),
                    ink=True,
                )
            ]

        self.campo_comida = componentes.campo_texto(
            self.paleta,
            "Nombre",
            pista="segundo desayuno",
            ancho=180,
            largo_maximo=LARGO_MAXIMO_COMIDA,
            al_enviar=lambda _: self._crear_comida(),
        )
        return [
            self.campo_comida,
            ft.Container(
                content=ft.Text("Añadir", size=12, color=self.paleta.acento_ink),
                padding=ft.Padding.symmetric(horizontal=12, vertical=7),
                bgcolor=self.paleta.acento,
                border_radius=8,
                on_click=lambda _: self._crear_comida(),
                ink=True,
            ),
            ft.Container(
                content=ft.Text("Cancelar", size=12, color=self.paleta.muted),
                padding=ft.Padding.symmetric(horizontal=12, vertical=7),
                border_radius=8,
                on_click=lambda _: self._dejar_de_anadir(),
                ink=True,
            ),
        ]

    def _empezar_a_anadir(self) -> None:
        self.anadiendo = True
        self._pintar_comidas()
        self.pagina.update()

    def _dejar_de_anadir(self) -> None:
        self.anadiendo = False
        self.campo_comida = None
        self.error.visible = False
        self._pintar_comidas()
        self.pagina.update()

    def _crear_comida(self) -> None:
        """Crea la comida y la deja elegida, sin cerrar nada."""
        nombre = (self.campo_comida.value or "") if self.campo_comida else ""
        try:
            with conectado() as conexion:
                nueva = repositorio_alimentacion.crear_comida(conexion, nombre)
        except (ValueError, TypeError) as fallo:
            self.error.value = str(fallo)
            self.error.visible = True
            self.pagina.update()
            return

        with conectado() as conexion:
            self.comidas = [
                una.nombre
                for una in repositorio_alimentacion.listar_comidas(conexion)
            ]
        # Se deja elegida la que acabas de crear: es a la que ibas.
        self.comida = nueva.nombre
        self.anadiendo = False
        self.campo_comida = None
        self.error.visible = False
        self._pintar_comidas()
        self.pagina.update()

    def _cambiar_comida(self, comida: str) -> None:
        """Marca otra comida SIN rehacer la ventanita.

        Antes esto cerraba y volvía a abrir el diálogo, y con eso se llevaba por
        delante lo que hubieras escrito: los campos seguían en pantalla pero
        Python ya no recibía lo tecleado.
        """
        self.comida = comida
        self._pintar_comidas()
        self.pagina.update()

    # ----------------------------------------------------------------------

    def _guardar(self) -> None:
        try:
            registro = Registro(
                # Al repetir se crea uno NUEVO: sin esto, repetir la comida de
                # ayer machacaría la de ayer.
                id=None if self.copiando else (self.registro.id if self.registro else None),
                nombre=self.nombre.value or "",
                comida=self.comida,
                jornada=self.jornada,
                momento=self.registro.momento
                if (self.registro and not self.copiando)
                else datetime.now().replace(microsecond=0),
                cantidad=(self.cantidad.value or "").strip(),
                unidad=(self.unidad.value or "").strip(),
                kcal=parsear_kcal(self.kcal.value or ""),
                proteinas=parsear_gramos(self.proteinas.value or ""),
                carbohidratos=parsear_gramos(self.carbohidratos.value or ""),
                grasas=parsear_gramos(self.grasas.value or ""),
            )
        except (ValueError, TypeError) as fallo:
            self.error.value = str(fallo)
            self.error.visible = True
            self.pagina.update()
            return

        with conectado() as conexion:
            if registro.id is None:
                repositorio_alimentacion.crear(conexion, registro)
            else:
                repositorio_alimentacion.actualizar(conexion, registro)

        self.pagina.pop_dialog()
        self.al_guardar()

    def _pedir_borrado(self) -> None:
        # Se cierra esta ventanita antes de preguntar: dos diálogos apilados
        # dejan el de atrás sin poder tocarse y parece que se ha colgado.
        self.pagina.pop_dialog()
        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo="Borrar el registro",
            texto=f"Se borra «{self.registro.nombre}». No se puede deshacer.",
            al_aceptar=lambda _: self._borrar(),
        )

    def _borrar(self) -> None:
        with conectado() as conexion:
            repositorio_alimentacion.borrar(conexion, self.registro.id)
        self.pagina.pop_dialog()
        self.al_guardar()
