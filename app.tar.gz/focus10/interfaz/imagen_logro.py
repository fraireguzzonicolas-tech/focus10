"""Compartir un logro FUERA de la app: Instagram, WhatsApp, lo que tengas.

LA TARJETA SE CONVIERTE EN UNA IMAGEN y se le da al menú de compartir del
propio teléfono. Ahí aparece lo que tengas instalado: historias o chats de
Instagram, estados o chats de WhatsApp, Telegram... Elegir a dónde va es
cosa tuya, y por eso no hay que conectar ninguna cuenta ni pedirle permiso a
nadie: es lo mismo que mandar una foto.

LO QUE LLEVA LA IMAGEN, lo decidió el usuario: el logo de Focus1%, el logro y
tu @alias. VERTICAL, tipo historia: es el tamaño de las historias de Instagram
y de los estados de WhatsApp, y en un chat se ve igual de bien.

SIN CUENTA TAMBIÉN: es una imagen hecha en tu teléfono que no pasa por ningún
servidor. Si no tienes perfil de Comunidad, sale sin alias.

EN LA PC NO HAY MENÚ DE COMPARTIR como en el móvil: la imagen se guarda en tu
carpeta de Imágenes y se dice dónde, para que la subas tú.
"""

from __future__ import annotations

from pathlib import Path

import flet as ft

from ..datos import ajustes
from ..datos.bd import conectado
from ..sistema import imagenes
from ..dominio import logros
from . import componentes, estilo, medalla_vista
from .estilo import Paleta

ANCHO, ALTO = 270, 480
"""El tamaño de la tarjeta en la pantalla: 9:16, como una historia."""

NITIDEZ = 4.0
"""Por cuánto se multiplica al hacer la imagen: 270×480 por 4 es 1080×1920,
el tamaño exacto de una historia de Instagram. Más, pesaría sin verse mejor.

«4.0» Y NO «4», Y NO ES MANÍA: el motor de Flet exige un número con decimales,
y con un entero la captura falla con «type 'int' is not a subtype of type
'double?'». Se descubrió probando la captura en una ventana de verdad; los
tests sin ventana no podían verlo."""

MOVILES = (ft.PagePlatform.ANDROID, ft.PagePlatform.IOS)


def _logo(paleta: Paleta) -> ft.Control:
    """El logo, leído del mismo archivo que el icono de la app.

    SE PASA COMO BYTES Y NO COMO RUTA: una ruta del ordenador no existe en el
    teléfono, y los bytes valen igual en los dos. Si el archivo faltara, sale
    el nombre escrito en vez de un hueco.
    """
    try:
        return ft.Image(src=Path(estilo.RUTA_LOGO).read_bytes(), width=40, height=40,
                        border_radius=10)
    except OSError:
        return ft.Text("F1%", size=18, weight=ft.FontWeight.W_700, color=paleta.ink)


def tarjeta(paleta: Paleta, tipo: str, datos: dict, alias: str) -> ft.Control:
    """La imagen tal como se compartirá: logo arriba, logro en medio, alias abajo.

    LOS COLORES SON LOS DE TU TEMA: la imagen que compartes se parece a tu app,
    no a una plantilla genérica. La medalla, en cambio, lleva su metal.
    """
    titulo, renglones = logros.lectura(tipo, datos)
    if tipo == "medalla":
        dias = int(datos.get("dias") or 0)
        centro: list[ft.Control] = [
            medalla_vista.medalla(paleta, dias, "", lado=128),
            ft.Text(logros.nombre_del_hito(dias), size=26, weight=ft.FontWeight.W_700,
                    color=paleta.ink, font_family=paleta.titular, text_align=ft.TextAlign.CENTER),
            ft.Text(f"{dias} días seguidos de «{datos.get('habito', '')}»", size=14,
                    color=paleta.ink_soft, text_align=ft.TextAlign.CENTER),
        ]
    else:
        centro = [
            ft.Text(titulo, size=22, weight=ft.FontWeight.W_700, color=paleta.acento,
                    font_family=paleta.titular, text_align=ft.TextAlign.CENTER),
            *[
                ft.Text(uno, size=13, color=paleta.ink_soft, text_align=ft.TextAlign.CENTER,
                        max_lines=6, overflow=ft.TextOverflow.ELLIPSIS)
                for uno in renglones
            ],
        ]

    return ft.Container(
        content=ft.Column(
            [
                ft.Row(
                    [_logo(paleta), ft.Text("Focus1%", size=16, weight=ft.FontWeight.W_600,
                                            color=paleta.ink)],
                    spacing=8,
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
                ft.Column(
                    centro,
                    spacing=10,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    alignment=ft.MainAxisAlignment.CENTER,
                    expand=True,
                ),
                ft.Column(
                    [
                        *([ft.Text(f"@{alias}", size=15, weight=ft.FontWeight.W_600,
                                   color=paleta.acento)] if alias else []),
                        ft.Text("Comunidad para mejorar 1% cada día", size=11,
                                color=paleta.muted),
                    ],
                    spacing=2,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        width=ANCHO,
        height=ALTO,
        padding=20,
        border_radius=18,
        bgcolor=paleta.canvas,
        border=ft.Border.all(1, paleta.borde),
    )


def _servicio_compartir(pagina: ft.Page) -> ft.Share | None:
    """El servicio de compartir que la ventana registró al abrirse (ver app.py)."""
    return next((s for s in pagina.services if isinstance(s, ft.Share)), None)


def abrir(pagina: ft.Page, paleta: Paleta, tipo: str, datos: dict) -> None:
    """Enseña la imagen y, al tocar «Compartir», la pasa al menú del teléfono."""
    with conectado() as conexion:
        alias = ajustes.leer(conexion, ajustes.CLAVE_ALIAS_COMUNIDAD)
    captura = ft.Screenshot(content=tarjeta(paleta, tipo, datos, alias))
    nombre = f"focus1-{tipo}.png"

    async def compartir(_):
        try:
            imagen = await captura.capture(pixel_ratio=NITIDEZ)
        except Exception as fallo:  # noqa: BLE001
            componentes.avisar(pagina, f"No se pudo hacer la imagen: {fallo}")
            return
        if pagina.platform in MOVILES and _servicio_compartir(pagina) is not None:
            pagina.pop_dialog()
            await _servicio_compartir(pagina).share_files(
                [ft.ShareFile.from_bytes(imagen, mime_type="image/png", name=nombre)],
                text="Mejorando 1% cada día con Focus1%",
            )
            return
        destino = imagenes.guardar(imagen, nombre)
        pagina.pop_dialog()
        componentes.avisar(pagina, f"Imagen guardada en {destino}. Súbela desde ahí.")

    pagina.show_dialog(
        ft.AlertDialog(
            modal=True,
            scrollable=True,
            title=ft.Text("Compartir fuera de la app", size=15, weight=ft.FontWeight.W_600),
            content=ft.Column(
                [
                    ft.Text("Instagram, WhatsApp o lo que tengas:", size=estilo.TEXTO_APOYO,
                            color=paleta.muted),
                    captura,
                ],
                spacing=12,
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            actions=[
                ft.TextButton("Cerrar", on_click=lambda _: pagina.pop_dialog()),
                ft.FilledButton("Compartir", icon=ft.Icons.IOS_SHARE, on_click=compartir),
            ],
        )
    )

