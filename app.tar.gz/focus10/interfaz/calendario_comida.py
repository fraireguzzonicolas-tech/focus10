"""La rejilla del mes: qué días cumpliste y qué días no.

LO PIDIÓ EL USUARIO: "un gráfico tipo qué días cumplí y qué días no, en el
apartado mensual, que yo pueda entrar a cada día".

CUADRADITOS Y NO BARRAS, y lo eligió él. Treinta barras en un móvil de 375
puntos salen de once puntos de ancho: no se lee ninguna etiqueta y acertar con el
dedo en la del día 17 es imposible. Una rejilla de siete columnas cabe entera,
cada día es un botón de tamaño decente, y de un vistazo se ve la racha.

EL COLOR NO DICE CUÁNTO COMISTE, dice si cumpliste. Es otra pregunta que la del
gráfico de barras que ya hay debajo, y por eso están las dos cosas y no una: el
calendario responde "¿fui constante?" y las barras responden "¿cuánto?".

LOS DÍAS QUE NO HAN PASADO SE DIBUJAN VACÍOS. Pintarlos del color de "no
cumplido" diría que fallaste veinte días que todavía no has vivido, que es la
clase de mentira que hace que una aplicación así se desinstale.
"""

from __future__ import annotations

from datetime import date
from typing import Callable

import flet as ft

from ..dominio.cumplimiento import Cumplimiento
from ..dominio.semana import LETRAS
from . import componentes, estilo
from .estilo import Paleta, con_opacidad

LADO = 38
"""Lo que mide cada cuadradito. Siete de estos más los huecos caben en un móvil
de 375 puntos, que es la medida contra la que se comprueba todo aquí."""


def color_de(paleta: Paleta, estado: Cumplimiento) -> str:
    """De qué color va un día.

    LOS CUATRO ESTADOS TIENEN COLOR PROPIO a propósito, incluido el de "no se
    puede saber": si "sin objetivo" se pintara igual que "no cumplido", la
    aplicación estaría diciendo que fallaste cuando lo que pasa es que nunca le
    dijiste a qué apuntabas.
    """
    if estado is Cumplimiento.CUMPLIDO:
        return paleta.positivo
    if estado is Cumplimiento.CERCA:
        return paleta.aviso
    if estado is Cumplimiento.NO_CUMPLIDO:
        return con_opacidad(paleta.negativo, 0.75)
    # Sin objetivo y futuro: los dos son "aquí no hay nada que decir", y se
    # distinguen por el borde, no por el relleno.
    return con_opacidad(paleta.muted, 0.15)


def texto_de(estado: Cumplimiento) -> str:
    """Lo que se lee al pasar el ratón por encima del día."""
    return {
        Cumplimiento.CUMPLIDO: "Cumpliste",
        Cumplimiento.CERCA: "Te faltó poco",
        Cumplimiento.NO_CUMPLIDO: "No llegaste",
        Cumplimiento.SIN_OBJETIVO: "Sin objetivo puesto: no se puede saber",
        Cumplimiento.FUTURO: "Todavía no ha pasado",
    }[estado]


def rejilla(
    paleta: Paleta,
    estados: dict[date, Cumplimiento],
    *,
    al_tocar: Callable[[date], None],
) -> ft.Control:
    """El mes entero, de lunes a domingo.

    SE COLOCAN LOS DÍAS DEBAJO DE SU DÍA DE LA SEMANA. Sin los huecos del
    principio, el día 1 caería siempre en el lunes y la rejilla no coincidiría
    con ningún calendario del mundo.
    """
    if not estados:
        return componentes.aviso_vacio(paleta, "No hay días que enseñar.")

    dias = sorted(estados)
    primero = dias[0]

    filas: list[ft.Control] = [
        ft.Row(
            [
                ft.Container(
                    content=ft.Text(
                        letra,
                        size=estilo.ROTULO,
                        color=paleta.muted,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    width=LADO,
                    alignment=ft.Alignment.CENTER,
                )
                for letra in LETRAS
            ],
            spacing=4,
        )
    ]

    fila: list[ft.Control] = [
        ft.Container(width=LADO, height=LADO) for _ in range(primero.weekday())
    ]
    for dia in dias:
        fila.append(_cuadradito(paleta, dia, estados[dia], al_tocar))
        if len(fila) == 7:
            filas.append(ft.Row(fila, spacing=4))
            fila = []
    if fila:
        filas.append(ft.Row(fila, spacing=4))

    return ft.Column(filas, spacing=4, tight=True)


def _cuadradito(
    paleta: Paleta,
    dia: date,
    estado: Cumplimiento,
    al_tocar: Callable[[date], None],
) -> ft.Control:
    """Un día. Se puede tocar salvo que no haya pasado todavía."""
    futuro = estado is Cumplimiento.FUTURO
    return ft.Container(
        content=ft.Text(
            str(dia.day),
            size=estilo.TEXTO_APOYO,
            color=paleta.muted if futuro else paleta.ink,
            text_align=ft.TextAlign.CENTER,
        ),
        width=LADO,
        height=LADO,
        alignment=ft.Alignment.CENTER,
        bgcolor=color_de(paleta, estado),
        border=ft.Border.all(1, paleta.borde),
        border_radius=estilo.RADIO_CAMPO,
        tooltip=f"{dia.day}: {texto_de(estado)}",
        # UN DÍA QUE NO HA PASADO NO SE ABRE: no hay nada dentro, y abrir una
        # ventana vacía se siente como que algo falla.
        on_click=None if futuro else (lambda _, d=dia: al_tocar(d)),
    )


def leyenda(paleta: Paleta) -> ft.Control:
    """Qué significa cada color.

    HACE FALTA porque el verde y el naranja son evidentes, pero "cumplí" aquí
    quiere decir algo concreto —calorías y proteína— y sin decirlo cada uno
    entendería una cosa.
    """
    piezas: list[ft.Control] = []
    for estado in (
        Cumplimiento.CUMPLIDO,
        Cumplimiento.CERCA,
        Cumplimiento.NO_CUMPLIDO,
    ):
        piezas.append(
            ft.Row(
                [
                    ft.Container(
                        width=12,
                        height=12,
                        bgcolor=color_de(paleta, estado),
                        border_radius=3,
                    ),
                    ft.Text(texto_de(estado), size=estilo.ROTULO, color=paleta.muted),
                ],
                spacing=5,
                tight=True,
            )
        )
    return ft.Row(piezas, spacing=14, wrap=True)
