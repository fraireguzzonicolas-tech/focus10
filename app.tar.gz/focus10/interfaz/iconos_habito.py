"""Los iconos que puede llevar un hábito, agrupados por tema.

SUSTITUYEN A LOS EMOJIS, y el motivo no es de gusto: el emoji lo dibuja el
SISTEMA OPERATIVO. El mismo hábito se veía de una forma en Windows, de otra en
Android y de otra en el navegador, y en los tres ignoraba los colores del tema.
Era lo único de la aplicación que no obedecía. Lo dijo él, más corto: «los
emojis de los hábitos son muy feos».

UN ICONO A TRAZO SÍ OBEDECE: es un dibujo vectorial que toma el color del
hábito y del tema, y se ve IGUAL en los tres sitios.

LA LISTA ESTÁ ORDENADA COMO LA DE EMOJIS QUE HABÍA ANTES —los mismos ocho
temas, cinco de cada uno— y en el mismo orden, porque así la migración 32 pudo
convertir cada emoji en el icono que ocupaba su sitio: el hábito que tenía la
pesa sigue teniendo una pesa, sin que nadie tenga que volver a elegir.

EN LA BASE SE GUARDA LA CLAVE ("pesa"), NO EL ICONO. Si algún día se cambia qué
dibujo usa "pesa", los hábitos no se enteran; y una clave que ya no exista se
dibuja con la de omisión en vez de dejar un hueco.
"""

from __future__ import annotations

import flet as ft

# Cada tema con sus iconos, en el orden en que se ven en la cuadrícula.
# clave -> icono. La clave es lo que se guarda; el icono, lo que se dibuja.
POR_TEMA: dict[str, dict[str, str]] = {
    "Dinero": {
        "moneda": ft.Icons.SAVINGS_OUTLINED,
        "billete": ft.Icons.PAYMENTS_OUTLINED,
        "tarjeta": ft.Icons.CREDIT_CARD_OUTLINED,
        "banco": ft.Icons.ACCOUNT_BALANCE_OUTLINED,
        "grafico": ft.Icons.TRENDING_UP_OUTLINED,
    },
    "Estudio": {
        "libro": ft.Icons.MENU_BOOK_OUTLINED,
        "estudiar": ft.Icons.SCHOOL_OUTLINED,
        "ordenador": ft.Icons.LAPTOP_OUTLINED,
        "idea": ft.Icons.LIGHTBULB_OUTLINE,
        "escribir": ft.Icons.EDIT_NOTE_OUTLINED,
    },
    "Salud": {
        "agua": ft.Icons.WATER_DROP_OUTLINED,
        "pastilla": ft.Icons.MEDICATION_OUTLINED,
        "dormir": ft.Icons.BEDTIME_OUTLINED,
        "cuidarse": ft.Icons.HEALING_OUTLINED,
        "estirar": ft.Icons.SELF_IMPROVEMENT_OUTLINED,
    },
    "Deporte": {
        "pesa": ft.Icons.FITNESS_CENTER_OUTLINED,
        "correr": ft.Icons.DIRECTIONS_RUN_OUTLINED,
        "bici": ft.Icons.DIRECTIONS_BIKE_OUTLINED,
        "yoga": ft.Icons.SPORTS_GYMNASTICS_OUTLINED,
        "futbol": ft.Icons.SPORTS_SOCCER_OUTLINED,
    },
    "Comida": {
        "fruta": ft.Icons.APPLE_OUTLINED,
        "ensalada": ft.Icons.LOCAL_DINING_OUTLINED,
        "cocinar": ft.Icons.SOUP_KITCHEN_OUTLINED,
        "pan": ft.Icons.BAKERY_DINING_OUTLINED,
        "sopa": ft.Icons.RAMEN_DINING_OUTLINED,
    },
    "Casa": {
        "limpiar": ft.Icons.CLEANING_SERVICES_OUTLINED,
        "lavar": ft.Icons.LOCAL_LAUNDRY_SERVICE_OUTLINED,
        "planta": ft.Icons.LOCAL_FLORIST_OUTLINED,
        "cama": ft.Icons.BED_OUTLINED,
        "mascota": ft.Icons.PETS_OUTLINED,
    },
    "Ocio": {
        "guitarra": ft.Icons.MUSIC_NOTE_OUTLINED,
        "juego": ft.Icons.SPORTS_ESPORTS_OUTLINED,
        "leer": ft.Icons.AUTO_STORIES_OUTLINED,
        "musica": ft.Icons.HEADPHONES_OUTLINED,
        "viajar": ft.Icons.FLIGHT_OUTLINED,
    },
    "Otros": {
        "sol": ft.Icons.WB_SUNNY_OUTLINED,
        "hecho": ft.Icons.CHECK_CIRCLE_OUTLINE,
        "estrella": ft.Icons.STAR_OUTLINE,
        "racha": ft.Icons.LOCAL_FIRE_DEPARTMENT_OUTLINED,
        "corazon": ft.Icons.FAVORITE_OUTLINE,
    },
    "Idiomas y código": {
        "idioma": ft.Icons.TRANSLATE_OUTLINED,
        "codigo": ft.Icons.TERMINAL_OUTLINED,
        "hablar": ft.Icons.RECORD_VOICE_OVER_OUTLINED,
        "escuchar": ft.Icons.HEARING_OUTLINED,
        "repasar": ft.Icons.REPLAY_OUTLINED,
    },
}
"""OCHO TEMAS COMO ANTES, MÁS UNO: «Idiomas y código», que no estaba y son tres
de sus cinco hábitos (Francés, Alemán, Italiano, Programación). La lista se hace
para lo que uno apunta, no para quedar bonita."""

POR_OMISION = "estrella"
"""El de un hábito sin icono, o con uno que ya no existe.

NUNCA SE DEJA EL HUECO: un círculo vacío en la lista parece un hábito roto.
"""


def todas() -> tuple[str, ...]:
    """Todas las claves, en el orden de la cuadrícula."""
    return tuple(clave for grupo in POR_TEMA.values() for clave in grupo)


def icono_de(clave: str) -> str:
    """El dibujo de esa clave, o el de omisión si no se conoce."""
    for grupo in POR_TEMA.values():
        if clave in grupo:
            return grupo[clave]
    return POR_TEMA["Otros"][POR_OMISION]
