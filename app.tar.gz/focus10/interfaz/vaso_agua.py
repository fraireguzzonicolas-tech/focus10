"""El vaso de agua que se llena, con dos ondas que se mueven de verdad.

POR QUÉ DOS ONDAS Y NO UNA: lo pidió el usuario y tiene razón. Una sola onda
subiendo y bajando parece una barra de progreso con el borde ondulado. Dos ondas
a distinta velocidad y en sentidos contrarios se cruzan constantemente, y ese
cruce es lo que el ojo lee como "agua" en vez de como "gráfico".

POR QUÉ EL NIVEL SUBE CON RETRASO: también lo pidió. Si el agua saltara al sitio
nuevo, pulsar Enter y ver el vaso ya lleno no se siente como haber bebido. Con
medio segundo largo de subida, se ve SUBIR, que es la mitad de la gracia.

CÓMO SE ANIMA SIN ANIMACIONES DE FLET: el `animate` de Flet sirve para
propiedades de un contenedor (alto, color, posición), pero aquí lo que cambia es
un dibujo entero. Así que la animación se hace a mano: alguien de fuera llama a
`avanzar()` unas veinte veces por segundo, eso mueve las fases y acerca el nivel
al objetivo, y se vuelve a pintar. Es más código, pero es el único camino que da
ondas de verdad.

EL RECORTE LO HACE EL CONTENEDOR, no el dibujo. Las ondas se pintan más anchas
que el vaso y el `clip_behavior` del contenedor las corta con el borde
redondeado. Calcular a mano dónde cortar cada onda contra una esquina redonda
sería mucho trabajo para el mismo resultado.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import flet as ft
import flet.canvas as cv

from ..dominio.agua import Vaso, texto_litros
from .estilo import Paleta, con_opacidad

ANCHO = 150
ALTO = 200
PUNTOS = 44
"""En cuántos trozos se parte cada onda. Con menos se ven las esquinas; con más
no se nota la diferencia y hay que dibujar más."""

SEGUNDOS_DE_SUBIDA = 0.6
"""Lo que tarda el agua en llegar al nivel nuevo. Medio segundo largo, como pidió
el usuario: lo justo para verla subir sin que parezca que la app va lenta."""

FOTOGRAMAS_POR_SEGUNDO = 20
SEGUNDOS_POR_FOTOGRAMA = 1 / FOTOGRAMAS_POR_SEGUNDO

# Las dos ondas. Velocidades distintas y de signo contrario: es lo que hace que
# se crucen y parezca agua.
VELOCIDAD_PRIMERA = 1.1
VELOCIDAD_SEGUNDA = -0.7
AMPLITUD_PRIMERA = 6.0
AMPLITUD_SEGUNDA = 4.0
LARGO_PRIMERA = 1.0
"""Ondas por vaso de ancho."""
LARGO_SEGUNDA = 1.6


@dataclass
class Animacion:
    """El estado del dibujo. Cambia veinte veces por segundo; no es del dominio."""

    nivel: float = 0.0
    """Dónde está el agua AHORA, de 0 a 1. Va de `origen` a `destino`."""

    origen: float = 0.0
    destino: float = 0.0
    transcurrido: float = SEGUNDOS_DE_SUBIDA
    """Cuánto llevamos de la subida actual. Empieza acabada: sin nada pendiente."""

    fase_primera: float = 0.0
    fase_segunda: float = math.pi
    """Empiezan desfasadas para que en el primer fotograma ya se crucen."""

    def apuntar_a(self, fraccion: float) -> None:
        """Manda el agua a un nivel nuevo, arrancando la subida desde donde esté."""
        nuevo = min(1.0, max(0.0, fraccion))
        if abs(nuevo - self.destino) < 0.0005:
            return  # ya iba ahí: no se reinicia la subida a medias
        self.origen = self.nivel
        self.destino = nuevo
        self.transcurrido = 0.0

    def colocar_en(self, fraccion: float) -> None:
        """Sin animación: al abrir la pantalla el agua ya está donde toca.

        Verla subir desde cero cada vez que entras sería una animación bonita
        contando una mentira: no acabas de beberte todo eso.
        """
        self.origen = self.destino = self.nivel = min(1.0, max(0.0, fraccion))
        self.transcurrido = SEGUNDOS_DE_SUBIDA

    def avanzar(self, segundos: float = SEGUNDOS_POR_FOTOGRAMA) -> bool:
        """Un fotograma. Devuelve si hay algo de agua que dibujar.

        Las ondas se mueven SIEMPRE, aunque el nivel no cambie: un agua quieta
        parece un dibujo, no agua.

        LA SUBIDA DURA LO MISMO SUBA MUCHO O POCO, y esto importa. La primera
        versión avanzaba un trozo fijo por fotograma, así que la duración salía
        proporcional a la distancia: un trago de 250 ml sobre un objetivo de 2 L
        movía el agua un 12 % y se hacía en menos de una décima, o sea que no se
        veía subir. Y verlo subir es media gracia del vaso. Ahora se interpola en
        SEGUNDOS_DE_SUBIDA pase lo que pase.
        """
        self.fase_primera = (
            self.fase_primera + VELOCIDAD_PRIMERA * segundos
        ) % (2 * math.pi)
        self.fase_segunda = (
            self.fase_segunda + VELOCIDAD_SEGUNDA * segundos
        ) % (2 * math.pi)

        if self.transcurrido < SEGUNDOS_DE_SUBIDA:
            self.transcurrido = min(SEGUNDOS_DE_SUBIDA, self.transcurrido + segundos)
            avance = _suavizar(self.transcurrido / SEGUNDOS_DE_SUBIDA)
            self.nivel = self.origen + (self.destino - self.origen) * avance

        return self.nivel > 0 or self.destino > 0


def _suavizar(t: float) -> float:
    """Frena al final en vez de pararse en seco.

    El agua de verdad no llega a su sitio a la misma velocidad a la que salió.
    Con avance lineal el movimiento parece mecánico; frenando al final parece
    que pesa.
    """
    return 1 - (1 - t) * (1 - t)


def dibujar(paleta: Paleta, animacion: Animacion, vaso: Vaso) -> ft.Control:
    """El vaso entero: cristal, agua y la cifra encima."""
    tono = paleta.acento
    alto_agua = ALTO * animacion.nivel
    superficie = ALTO - alto_agua

    formas: list[cv.Shape] = []
    if animacion.nivel > 0:
        formas.append(
            _onda(
                superficie,
                animacion.fase_primera,
                AMPLITUD_SEGUNDA,
                LARGO_SEGUNDA,
                con_opacidad(tono, 0.35),
            )
        )
        formas.append(
            _onda(
                superficie,
                animacion.fase_segunda,
                AMPLITUD_PRIMERA,
                LARGO_PRIMERA,
                con_opacidad(tono, 0.75),
            )
        )

    agua = ft.Container(
        content=cv.Canvas(formas, width=ANCHO, height=ALTO),
        width=ANCHO,
        height=ALTO,
        bgcolor=paleta.surface_2,
        border_radius=18,
        # Las ondas se pintan más anchas que el vaso; esto las corta contra el
        # borde redondeado sin tener que calcularlo a mano.
        clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
    )

    return ft.Stack(
        [
            agua,
            ft.Container(
                width=ANCHO,
                height=ALTO,
                border=ft.Border.all(2, paleta.borde_fuerte),
                border_radius=18,
            ),
            ft.Container(
                content=ft.Column(
                    [
                        ft.Text(
                            vaso.texto(),
                            size=15,
                            weight=ft.FontWeight.W_700,
                            color=paleta.ink,
                            text_align=ft.TextAlign.CENTER,
                        ),
                        ft.Text(
                            _pie(vaso),
                            size=11,
                            color=paleta.muted,
                            text_align=ft.TextAlign.CENTER,
                        ),
                    ],
                    spacing=2,
                    tight=True,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
                width=ANCHO,
                height=ALTO,
                alignment=ft.Alignment.CENTER,
            ),
        ],
        width=ANCHO,
        height=ALTO,
    )


def _pie(vaso: Vaso) -> str:
    """Lo que va debajo de la cifra. Nunca un número inventado."""
    if vaso.objetivo is None:
        return "sin objetivo"
    if vaso.cumplido:
        return "objetivo cumplido"
    return f"faltan {texto_litros(vaso.falta)}"


def _onda(
    superficie: float, fase: float, amplitud: float, largo: float, color: str
) -> cv.Shape:
    """Una onda rellena desde su línea hasta el fondo del vaso.

    Se dibuja un poco más ancha que el vaso (de -10 a ANCHO+10) para que al
    moverse no se vea aparecer el borde por los lados; lo que sobra lo corta el
    contenedor.
    """
    elementos: list = []
    desde, hasta = -10.0, ANCHO + 10.0
    for indice in range(PUNTOS + 1):
        x = desde + (hasta - desde) * indice / PUNTOS
        y = superficie + amplitud * math.sin(
            2 * math.pi * largo * (x / ANCHO) + fase * 2 * math.pi
        )
        elementos.append(
            cv.Path.MoveTo(x, y) if indice == 0 else cv.Path.LineTo(x, y)
        )
    elementos.append(cv.Path.LineTo(hasta, ALTO + 10))
    elementos.append(cv.Path.LineTo(desde, ALTO + 10))
    elementos.append(cv.Path.Close())
    return cv.Path(elementos, paint=ft.Paint(color=color, style=ft.PaintingStyle.FILL))
