"""Las ventanitas de inversiones: crear una posición y apuntarle operaciones.

LO MÁS IMPORTANTE DE ESTE ARCHIVO ES LA VISTA PREVIA. Va debajo del formulario,
SIEMPRE visible, y se recalcula con cada tecla. Dice en palabras lo que se va a
guardar: "se comprarán 0,913796 unidades a 832,79 € cada una = 761,00 € en
total".

Existe por un fallo que costó caro: con una columna llamada solo "Cantidad", el
usuario metió ahí los euros invertidos en vez de las participaciones y la
aplicación le dijo que tenía 49.959 € invertidos cuando eran 761 €. Con esta
frase delante, el "633.753,19 €" salta a la vista antes de pulsar Guardar.

Por lo mismo hay DOS FORMAS de apuntar una compra, con un selector, y cada
casilla dice exactamente qué espera. Ninguna se llama "cantidad".
"""

from __future__ import annotations

from datetime import date

import flet as ft

from ..datos import repositorio_inversiones as repo
from ..datos.bd import conectado
from ..dominio.dinero import formatear, parsear_importe
from ..dominio.inversion import (
    Operacion,
    Posicion,
    TipoActivo,
    TipoOperacion,
    compra_por_dinero,
    compra_por_unidades,
    parsear_unidades,
    vista_previa,
)
from ..dominio.moneda import EUR
from . import componentes

ANCHO = 420
from ..dominio.inversion import texto_unidades


class Modo:
    """Las dos formas de decir lo mismo. Los nombres son los del usuario."""

    DINERO = "Puse dinero"
    UNIDADES = "Compré unidades"


def abrir_posicion(pagina, paleta, al_guardar, posicion: Posicion | None = None) -> None:
    """Crear una posición nueva, o corregir el nombre/símbolo/tipo de una."""
    pagina.show_dialog(_DialogoPosicion(pagina, paleta, al_guardar, posicion).control)


def abrir_operacion(
    pagina,
    paleta,
    id_posicion: int,
    al_guardar,
    operacion: Operacion | None = None,
) -> None:
    """Apuntar una compra, una venta o un dividendo. O corregir una ya apuntada."""
    pagina.show_dialog(
        _DialogoOperacion(pagina, paleta, id_posicion, al_guardar, operacion).control
    )


class _DialogoPosicion:
    def __init__(self, pagina, paleta, al_guardar, posicion) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.al_guardar = al_guardar
        self.posicion = posicion
        self.tipo = posicion.tipo if posicion else TipoActivo.ETF

        self.nombre = componentes.campo_texto(
            paleta, "Nombre", valor=posicion.nombre if posicion else "",
            pista="iShares Core S&P 500",
        )
        self.ticker = componentes.campo_texto(
            paleta, "Símbolo", valor=posicion.ticker if posicion else "",
            pista="CSPX.L",
        )
        self.error = ft.Text("", size=12, color=paleta.negativo, visible=False)

    @property
    def control(self) -> ft.AlertDialog:
        piezas: list[ft.Control] = [
            self.nombre,
            ft.Row(
                [
                    ft.Container(content=self.ticker, expand=True),
                    componentes.boton(
                        self.paleta,
                        "Buscar",
                        icono=ft.Icons.SEARCH,
                        al_pulsar=lambda _: self._buscar_simbolo(),
                    ),
                ],
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            ft.Text("Tipo de activo", size=12, color=self.paleta.muted),
            self._elegir_tipo(),
            self.error,
        ]
        if self.posicion is not None:
            piezas += [
                ft.Container(height=4),
                componentes.boton(
                    self.paleta,
                    "Borrar la posición y sus operaciones",
                    icono=ft.Icons.DELETE_OUTLINE,
                    al_pulsar=lambda _: self._pedir_borrado(),
                ),
            ]
        return componentes.dialogo(
            self.paleta,
            "Corregir posición" if self.posicion else "Nueva posición",
            ft.Column(piezas, spacing=10, tight=True, width=ANCHO),
            pagina=self.pagina,
            al_aceptar=lambda _: self._guardar(),
        )

    def _elegir_tipo(self) -> ft.Control:
        return ft.Row(
            [
                ft.Container(
                    content=ft.Text(
                        uno.value.capitalize(),
                        size=12,
                        color=self.paleta.acento_ink
                        if uno is self.tipo
                        else self.paleta.ink_soft,
                    ),
                    padding=ft.Padding.symmetric(horizontal=11, vertical=7),
                    bgcolor=self.paleta.acento
                    if uno is self.tipo
                    else self.paleta.surface_2,
                    border_radius=8,
                    on_click=lambda _, t=uno: self._cambiar_tipo(t),
                    ink=True,
                )
                for uno in TipoActivo
            ],
            spacing=6,
            wrap=True,
        )

    def _cambiar_tipo(self, tipo: TipoActivo) -> None:
        self.tipo = tipo
        self.pagina.pop_dialog()
        self.pagina.show_dialog(self.control)

    def _buscar_simbolo(self) -> None:
        """El buscador de Yahoo. Existe porque nadie se sabe que el S&P 500 es
        CSPX.L en Londres y SXR8.DE en Fráncfort."""
        from ..sistema import mercado

        with conectado() as conexion:
            if not repo.leer_precios_de_mercado(conexion):
                self._avisar(
                    "Para buscar símbolos hay que encender los precios de mercado, "
                    "en el interruptor de arriba de la pantalla."
                )
                return

        texto = (self.nombre.value or self.ticker.value or "").strip()
        if not texto:
            self._avisar("Escribe primero el nombre o parte del símbolo.")
            return
        try:
            resultados = mercado.buscar(texto)
        except mercado.MercadoNoDisponible as fallo:
            self._avisar(str(fallo))
            return
        if not resultados:
            self._avisar(f"No he encontrado nada con «{texto}».")
            return

        self.pagina.pop_dialog()
        self.pagina.show_dialog(
            componentes.dialogo(
                self.paleta,
                "¿Cuál de estos?",
                ft.Container(
                    content=ft.Column(
                        [self._fila_resultado(uno) for uno in resultados],
                        spacing=0,
                        scroll=ft.ScrollMode.AUTO,
                        height=340,
                    ),
                    width=ANCHO,
                ),
                pagina=self.pagina,
                texto_aceptar="Cancelar",
                al_aceptar=lambda _: self._volver(),
            )
        )

    def _fila_resultado(self, uno: dict) -> ft.Control:
        return ft.Container(
            content=ft.Row(
                [
                    ft.Column(
                        [
                            ft.Text(uno["simbolo"], size=13, color=self.paleta.ink),
                            ft.Text(uno["nombre"], size=11, color=self.paleta.muted),
                        ],
                        spacing=1,
                        tight=True,
                        expand=True,
                    ),
                    # La bolsa, porque el mismo fondo en dos bolsas es justo lo
                    # que hay que distinguir.
                    ft.Text(uno["bolsa"], size=11, color=self.paleta.muted),
                ],
                spacing=10,
            ),
            padding=ft.Padding.symmetric(vertical=7, horizontal=6),
            on_click=lambda _, u=uno: self._elegir_resultado(u),
            ink=True,
        )

    def _elegir_resultado(self, uno: dict) -> None:
        self.ticker.value = uno["simbolo"]
        if not (self.nombre.value or "").strip():
            self.nombre.value = uno["nombre"]
        self._volver()

    def _volver(self) -> None:
        self.pagina.pop_dialog()
        self.pagina.show_dialog(self.control)

    def _avisar(self, texto: str) -> None:
        self.error.value = texto
        self.error.visible = True
        self.error.update()

    def _guardar(self) -> None:
        try:
            posicion = Posicion(
                id=self.posicion.id if self.posicion else None,
                nombre=self.nombre.value or "",
                ticker=self.ticker.value or "",
                tipo=self.tipo,
            )
            with conectado() as conexion:
                if posicion.id is None:
                    posicion = repo.crear(conexion, posicion)
                else:
                    repo.actualizar(conexion, posicion)
        except (ValueError, TypeError) as fallo:
            self._avisar(str(fallo))
            return

        self.pagina.pop_dialog()
        self.al_guardar()
        # Recién creada, lo siguiente que quiere cualquiera es apuntar la compra.
        if self.posicion is None:
            abrir_operacion(self.pagina, self.paleta, posicion.id, self.al_guardar)

    def _pedir_borrado(self) -> None:
        self.pagina.pop_dialog()
        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo="Borrar la posición",
            texto=(
                f"Se borra «{self.posicion.nombre}» y todas sus operaciones. "
                "No se puede deshacer."
            ),
            al_aceptar=lambda _: self._borrar(),
        )

    def _borrar(self) -> None:
        with conectado() as conexion:
            repo.borrar(conexion, self.posicion.id)
        self.pagina.pop_dialog()
        self.al_guardar()


class _DialogoOperacion:
    def __init__(self, pagina, paleta, id_posicion, al_guardar, operacion) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.id_posicion = id_posicion
        self.al_guardar = al_guardar
        self.operacion = operacion
        self.tipo = operacion.tipo if operacion else TipoOperacion.COMPRA
        self.modo = Modo.DINERO

        self.previa = ft.Text("", size=12, color=paleta.ink, selectable=True)
        self.error = ft.Text("", size=12, color=paleta.negativo, visible=False)

        self.dinero = self._campo("Euros invertidos", "761")
        self.unidades = self._campo("Unidades compradas", "0,913796")
        self.precio = self._campo("Precio de cada unidad (€)", "832,79")
        self.importe = self._campo("Euros cobrados", "84")
        self.fecha = self._campo("Fecha (AAAA-MM-DD)", str(date.today()))

        if operacion is not None:
            self.modo = Modo.UNIDADES
            self.unidades.value = _texto(operacion.unidades, 6)
            self.precio.value = formatear(operacion.precio, EUR, con_simbolo=False)
            self.importe.value = formatear(operacion.importe, EUR, con_simbolo=False)
            self.fecha.value = str(operacion.fecha)

        self._recalcular()

    def _campo(self, etiqueta: str, pista: str) -> ft.TextField:
        campo = componentes.campo_texto(self.paleta, etiqueta, pista=pista)
        # Con CADA TECLA: la vista previa solo sirve si va por delante del dedo
        # que pulsa Guardar.
        campo.on_change = lambda _: self._recalcular()
        return campo

    @property
    def control(self) -> ft.AlertDialog:
        piezas: list[ft.Control] = [
            self._elegir_tipo(),
            *self._campos_del_tipo(),
            self.fecha,
            componentes.separador(self.paleta),
            # LA VISTA PREVIA, siempre visible y debajo del formulario.
            ft.Container(
                content=ft.Row(
                    [
                        ft.Icon(
                            ft.Icons.FACT_CHECK_OUTLINED,
                            size=16,
                            color=self.paleta.acento,
                        ),
                        ft.Container(content=self.previa, expand=True),
                    ],
                    spacing=8,
                ),
                padding=10,
                bgcolor=self.paleta.surface_2,
                border_radius=8,
            ),
            self.error,
        ]
        if self.operacion is not None:
            piezas += [
                ft.Container(height=4),
                componentes.boton(
                    self.paleta,
                    "Borrar esta operación",
                    icono=ft.Icons.DELETE_OUTLINE,
                    al_pulsar=lambda _: self._borrar(),
                ),
            ]
        return componentes.dialogo(
            self.paleta,
            "Corregir operación" if self.operacion else "Apuntar operación",
            ft.Column(piezas, spacing=10, tight=True, width=ANCHO,
                      scroll=ft.ScrollMode.AUTO),
            pagina=self.pagina,
            al_aceptar=lambda _: self._guardar(),
        )

    def _elegir_tipo(self) -> ft.Control:
        return ft.Row(
            [
                ft.Container(
                    content=ft.Text(
                        uno.value.capitalize(),
                        size=12,
                        color=self.paleta.acento_ink
                        if uno is self.tipo
                        else self.paleta.ink_soft,
                    ),
                    padding=ft.Padding.symmetric(horizontal=12, vertical=7),
                    bgcolor=self.paleta.acento
                    if uno is self.tipo
                    else self.paleta.surface_2,
                    border_radius=8,
                    on_click=lambda _, t=uno: self._cambiar(tipo=t),
                    ink=True,
                )
                for uno in TipoOperacion
            ],
            spacing=6,
        )

    def _campos_del_tipo(self) -> list[ft.Control]:
        if self.tipo is TipoOperacion.DIVIDENDO:
            return [self.importe]
        if self.tipo is TipoOperacion.VENTA:
            return [self.unidades, self.precio]

        # Compra: el selector de las dos formas de decir lo mismo.
        return [
            ft.Text("¿Cómo lo apuntas?", size=12, color=self.paleta.muted),
            ft.Row(
                [
                    ft.Container(
                        content=ft.Text(
                            texto,
                            size=12,
                            color=self.paleta.acento_ink
                            if texto == self.modo
                            else self.paleta.ink_soft,
                        ),
                        padding=ft.Padding.symmetric(horizontal=12, vertical=7),
                        bgcolor=self.paleta.acento
                        if texto == self.modo
                        else self.paleta.surface_2,
                        border_radius=8,
                        on_click=lambda _, m=texto: self._cambiar(modo=m),
                        ink=True,
                    )
                    for texto in (Modo.DINERO, Modo.UNIDADES)
                ],
                spacing=6,
            ),
            self.dinero if self.modo == Modo.DINERO else self.unidades,
            self.precio,
        ]

    def _cambiar(self, *, tipo=None, modo=None) -> None:
        if tipo is not None:
            self.tipo = tipo
        if modo is not None:
            self.modo = modo
        self._recalcular()
        self.pagina.pop_dialog()
        self.pagina.show_dialog(self.control)

    # ----------------------------------------------------------------------

    def _construir(self) -> Operacion:
        """Lo que se guardaría con lo que hay escrito ahora. Puede lanzar."""
        try:
            fecha = date.fromisoformat((self.fecha.value or "").strip())
        except ValueError as fallo:
            raise ValueError("la fecha se escribe como 2025-08-19") from fallo

        if self.tipo is TipoOperacion.DIVIDENDO:
            importe = parsear_importe(self.importe.value or "", EUR)
            if importe is None:
                raise ValueError("no entiendo los euros cobrados")
            return Operacion(
                tipo=TipoOperacion.DIVIDENDO, importe=importe, fecha=fecha
            )

        precio = parsear_importe(self.precio.value or "", EUR)
        if precio is None:
            raise ValueError("no entiendo el precio de cada unidad")

        if self.tipo is TipoOperacion.COMPRA and self.modo == Modo.DINERO:
            dinero = parsear_importe(self.dinero.value or "", EUR)
            if dinero is None:
                raise ValueError("no entiendo los euros invertidos")
            return compra_por_dinero(dinero, precio, fecha)

        unidades = parsear_unidades(self.unidades.value or "")
        if unidades is None:
            raise ValueError("no entiendo las unidades")
        if self.tipo is TipoOperacion.COMPRA:
            return compra_por_unidades(unidades, precio, fecha)
        return Operacion(
            tipo=TipoOperacion.VENTA, unidades=unidades, precio=precio, fecha=fecha
        )

    def _recalcular(self) -> None:
        """La vista previa. Se llama con cada tecla."""
        try:
            self.previa.value = vista_previa(self._construir(), EUR)
            self.previa.color = self.paleta.ink
        except (ValueError, TypeError) as fallo:
            # Mientras falta algo por escribir se dice qué falta, en gris. No es
            # un error todavía: es que aún no has terminado.
            self.previa.value = str(fallo)
            self.previa.color = self.paleta.muted
        try:
            self.previa.update()
        except Exception:  # noqa: BLE001
            pass  # todavía no está en la ventana

    def _guardar(self) -> None:
        try:
            operacion = self._construir()
        except (ValueError, TypeError) as fallo:
            self.error.value = str(fallo)
            self.error.visible = True
            self.error.update()
            return

        with conectado() as conexion:
            if self.operacion is None:
                repo.anadir_operacion(conexion, self.id_posicion, operacion)
            else:
                from dataclasses import replace

                repo.actualizar_operacion(
                    conexion, replace(operacion, id=self.operacion.id)
                )
        self.pagina.pop_dialog()
        self.al_guardar()

    def _borrar(self) -> None:
        with conectado() as conexion:
            repo.borrar_operacion(conexion, self.operacion.id)
        self.pagina.pop_dialog()
        self.al_guardar()


def _texto(millonesimas: int, decimales: int) -> str:

    return texto_unidades(millonesimas)
