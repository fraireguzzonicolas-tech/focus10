"""El gráfico del ahorro acumulado: cuánto llevas apartado y desde cuándo.

POR QUÉ SE DIBUJA A MANO: Flet 0.86 no trae ningún control de gráficas. Se pinta
con flet.canvas, igual que el resto de gráficos de la aplicación.

QUÉ ENSEÑA Y QUÉ NO: la línea sube con cada aportación y baja si sacas dinero. NO
dibuja una recta hasta la meta ni una previsión de cuándo llegarás. Una línea de
puntos hacia el futuro es una promesa que nadie ha hecho, y esta aplicación no
enseña números que no existan.

CON UNA SOLA APORTACIÓN NO HAY LÍNEA, hay un punto. Se dibuja el punto y ya:
unir un punto consigo mismo no es una línea, y fingir una recta desde cero
inventaría un pasado que no pasó.
"""

from __future__ import annotations

from datetime import date

import flet as ft
import flet.canvas as cv

from ..dominio.dinero import formatear
from ..dominio.moneda import EUR
from . import estilo
from .estilo import Paleta, con_opacidad

ALTO = 150
MARGEN_ARRIBA = 12
MARGEN_ABAJO = 22
GROSOR = 2
RADIO_PUNTO = 3


def grafico(
    paleta: Paleta,
    puntos: list[tuple[date, int]],
    *,
    color: str,
    meta: int | None = None,
    ancho: int | None = None,
) -> ft.Control:
    """La línea del ahorro. `meta` dibuja la raya del objetivo, si la hay."""
    # EL ANCHO SE CALCULA SI NO LO DAN: un lienzo necesita un numero concreto
    # —tiene que saber donde cae cada punto— asi que no puede "estirarse hasta
    # lo que haya" como una caja normal. Se le da 520 si cabe, y lo que
    # quepa si no. En un movil eran 520 puntos sobre una pantalla de 375.
    if ancho is None:
        ancho = estilo.ancho_de_grafico(520)
    if not puntos:
        return _vacio(paleta)

    tono = paleta.color_de(color)
    alto_util = ALTO - MARGEN_ARRIBA - MARGEN_ABAJO

    # El techo del gráfico: la meta o el máximo ahorrado, lo que sea mayor. Con
    # solo el máximo, llegar al 30 % de la meta se vería como una línea llena.
    techo = max([total for _, total in puntos] + [meta or 0]) or 1
    suelo = min([total for _, total in puntos] + [0])
    recorrido = max(1, techo - suelo)

    def x_de(indice: int) -> float:
        if len(puntos) == 1:
            return ancho / 2
        return indice * (ancho - 2 * RADIO_PUNTO) / (len(puntos) - 1) + RADIO_PUNTO

    def y_de(total: int) -> float:
        return MARGEN_ARRIBA + alto_util * (1 - (total - suelo) / recorrido)

    formas: list[cv.Shape] = []

    if meta:
        # La raya de la meta, punteada para que no se confunda con la línea del
        # ahorro: una raya entera parecería otro dato medido.
        y_meta = y_de(meta)
        rayita = ft.Paint(color=paleta.borde_fuerte, stroke_width=1)
        trozo = 6
        x = 0.0
        while x < ancho:
            formas.append(cv.Line(x, y_meta, min(ancho, x + trozo), y_meta, paint=rayita))
            x += trozo * 2

    coordenadas = [(x_de(i), y_de(total)) for i, (_, total) in enumerate(puntos)]

    if len(coordenadas) > 1:
        linea = ft.Paint(
            color=tono, stroke_width=GROSOR, style=ft.PaintingStyle.STROKE
        )
        for antes, despues in zip(coordenadas, coordenadas[1:]):
            formas.append(
                cv.Line(antes[0], antes[1], despues[0], despues[1], paint=linea)
            )

    relleno = ft.Paint(color=tono)
    formas += [cv.Circle(x, y, RADIO_PUNTO, paint=relleno) for x, y in coordenadas]

    return ft.Column(
        [
            ft.Container(
                content=cv.Canvas(formas, width=ancho, height=ALTO),
                width=ancho,
                height=ALTO,
                bgcolor=con_opacidad(tono, 0.06),
                border_radius=10,
            ),
            ft.Row(
                [
                    ft.Text(
                        _fecha_corta(puntos[0][0]), size=10, color=paleta.muted
                    ),
                    ft.Container(expand=True),
                    ft.Text(
                        f"{formatear(puntos[-1][1], EUR)} apartados",
                        size=11,
                        weight=ft.FontWeight.W_600,
                        color=paleta.ink,
                    ),
                    ft.Container(expand=True),
                    ft.Text(
                        _fecha_corta(puntos[-1][0]), size=10, color=paleta.muted
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        ],
        spacing=6,
        tight=True,
    )


def _vacio(paleta: Paleta) -> ft.Control:
    """Sin aportaciones no se dibuja una línea plana: se dice que no hay nada.

    Una línea en cero parece un dato medido —"llevas mucho tiempo sin ahorrar"—
    cuando lo que pasa es que todavía no has empezado.
    """
    return ft.Container(
        content=ft.Text(
            "Todavía no has apartado nada para este objetivo.",
            size=12,
            color=paleta.muted,
        ),
        height=ALTO,
        bgcolor=paleta.surface_2,
        border_radius=10,
        alignment=ft.Alignment.CENTER,
    )


def _fecha_corta(dia: date) -> str:
    return f"{dia.day}/{dia.month}/{dia.year % 100:02d}"
