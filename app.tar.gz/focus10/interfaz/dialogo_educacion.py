"""Las ventanitas de Educación: tema, evento, objetivo y «ya lo estudié».

LA REGLA QUE LAS ORDENA A TODAS, y es lo que pidió el usuario: lo obligatorio
cabe en una línea y lo demás es opcional. Crear un tema es escribir "Derivadas";
planificar es elegir el día y los minutos. Quince campos por cada cosa es lo que
hace que una aplicación de estudio se abandone en tres días.

NO HAY VENTANITA DE MATERIA, y también lo pidió él: "el apartado de materias es
inútil, ya que está el objetivo". La materia se escribe donde hace falta —en el
objetivo o en la sesión— y se crea sola; cuando se queda sin nada colgando, se
barre sola. Una pantalla entera para escribir "Matemáticas" era una pantalla de
más.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import date

import flet as ft

from ..datos import repositorio_educacion as repo
from ..datos.bd import conectado
from ..dominio.educacion import (
    PALABRAS_DE_DOMINIO,
    Dificultad,
    Evento,
    Materia,
    Meta,
    Prioridad,
    Tema,
    TipoEvento,
    repetir,
)
from ..dominio.habito import COLORES
from . import componentes
from .educacion_calendario import texto_de
from .estilo import Paleta

ANCHO = 380
ANCHO_CORTO = 120


def _fecha_a_texto(dia: date) -> str:
    return dia.strftime("%d/%m/%Y")


def _fecha_desde_texto(texto: str, hoy: date) -> date:
    """"16/09" o "16/09/2026". Vacío es hoy.

    SE ADMITE SIN AÑO porque casi todo lo que se apunta es de este curso, y
    escribir el año cuatro veces al día sobra. Lo que no se entiende NO se
    adivina: se avisa y no se guarda.
    """
    limpio = (texto or "").strip()
    if not limpio:
        return hoy
    partes = limpio.replace("-", "/").split("/")
    if len(partes) == 2:
        partes.append(str(hoy.year))
    if len(partes) != 3 or not all(p.isdigit() for p in partes):
        raise ValueError(f"no entiendo la fecha «{limpio}»: se escribe 16/09")
    dia, mes, ano = (int(p) for p in partes)
    if ano < 100:
        ano += 2000
    return date(ano, mes, dia)


def _minutos_desde_texto(texto: str) -> int | None:
    limpio = (texto or "").strip()
    if not limpio:
        return None
    if not limpio.isdigit():
        raise ValueError(f"no entiendo «{limpio}» en los minutos")
    return int(limpio)


def _campo_materia(
    paleta: Paleta, materias: list[Materia], id_puesta: int | None
) -> ft.TextField:
    """Dónde se escribe la materia. Es un campo y no un desplegable a propósito:
    así la primera vez no hay que ir a crearla a otro sitio."""
    nombre = next((una.nombre for una in materias if una.id == id_puesta), "")
    sugeridas = ", ".join(una.nombre for una in materias[:3])
    return componentes.campo_texto(
        paleta,
        "Materia",
        valor=nombre,
        pista=sugeridas or "Matemáticas",
    )


def _guardar_materia(conexion, escrito: str) -> int | None:
    """El id de esa materia, creándola si hace falta. Vacío es None."""
    limpio = (escrito or "").strip()
    if not limpio:
        return None
    return repo.materia_por_nombre(conexion, limpio, _color_libre(conexion)).id


def _color_libre(conexion) -> str:
    """Un color que no tenga ya otra materia, para que se distingan de un golpe."""
    usados = {una.color for una in repo.listar_materias(conexion)}
    for color in COLORES:
        if color not in usados:
            return color
    return COLORES[0]


# ---------------------------------------------------------------------------
# Tema
# ---------------------------------------------------------------------------


def abrir_tema(
    pagina: ft.Page,
    paleta: Paleta,
    hoy: date,
    al_guardar,
    materia_id: int,
    tema: Tema | None = None,
) -> None:
    """Crear o corregir un tema dentro de su materia. Solo el nombre es obligatorio."""
    nombre = componentes.campo_texto(
        paleta, "Tema", valor=tema.nombre if tema else "", pista="Derivadas"
    )
    dominio = componentes.selector(
        paleta,
        "Cómo lo llevas",
        [(str(valor), palabra) for valor, palabra in PALABRAS_DE_DOMINIO.items()],
        valor=str(tema.dominio if tema else 0),
    )
    notas = componentes.campo_texto(
        paleta, "Notas (opcional)", valor=tema.notas if tema else "",
        pista="lo que quieras acordarte", lineas=2,
    )
    error = ft.Text("", size=12, color=paleta.negativo, visible=False)

    def guardar(_):
        try:
            uno = Tema(
                id=tema.id if tema else None,
                materia_id=tema.materia_id if tema else materia_id,
                nombre=nombre.value or "",
                descripcion=tema.descripcion if tema else "",
                dominio=int(dominio.value or 0),
                notas=notas.value or "",
                creado_en=tema.creado_en if tema else hoy,
            )
            with conectado() as conexion:
                if uno.id is None:
                    repo.crear_tema(conexion, uno, hoy)
                else:
                    repo.actualizar_tema(conexion, uno)
        except Exception as fallo:  # noqa: BLE001
            error.value = _texto_de_error(
                fallo, "Esa materia ya tiene un tema con ese nombre."
            )
            error.visible = True
            pagina.update()
            return
        pagina.pop_dialog()
        al_guardar()

    piezas: list[ft.Control] = [nombre, dominio, notas, error]
    if tema is not None:
        piezas += [
            ft.Container(height=4),
            componentes.boton(
                paleta,
                "Borrar este tema",
                icono=ft.Icons.DELETE_OUTLINE,
                al_pulsar=lambda _: _borrar_tema(pagina, paleta, tema, al_guardar),
            ),
        ]

    pagina.show_dialog(
        componentes.dialogo(
            paleta,
            "Corregir tema" if tema else "Nuevo tema",
            ft.Column(piezas, spacing=10, tight=True, width=ANCHO,
                      scroll=ft.ScrollMode.AUTO),
            pagina=pagina,
            al_aceptar=guardar,
        )
    )


def _borrar_tema(pagina: ft.Page, paleta: Paleta, tema: Tema, al_guardar) -> None:
    # Se cierra esta ventanita antes de preguntar: dos diálogos apilados dejan
    # el de atrás sin poder tocarse y parece que se ha colgado.
    pagina.pop_dialog()

    def borrar(_):
        with conectado() as conexion:
            repo.borrar_tema(conexion, tema.id)
            repo.limpiar_materias_sueltas(conexion)
        pagina.pop_dialog()
        al_guardar()

    componentes.confirmar(
        paleta,
        pagina,
        titulo="Borrar el tema",
        texto=(
            f"Se borra «{tema.nombre}». Lo que ya estudiaste se queda en tu "
            "historial. No se puede deshacer."
        ),
        al_aceptar=borrar,
    )


# ---------------------------------------------------------------------------
# Evento del calendario (sesión, tarea, examen, trabajo, importante)
# ---------------------------------------------------------------------------


def abrir_evento(
    pagina: ft.Page,
    paleta: Paleta,
    materias: list[Materia],
    temas: list[Tema],
    hoy: date,
    al_guardar,
    evento: Evento | None = None,
    fecha: date | None = None,
    tipo: TipoEvento = TipoEvento.SESION,
) -> None:
    """Planificar o corregir algo del calendario.

    LO MÍNIMO ES TIPO, DÍA Y MATERIA. El título solo hace falta cuando no es una
    sesión de estudio —"examen" a secas no se distingue de otro examen—, y el
    resto son opcionales.
    """
    tipo_actual = evento.tipo if evento else tipo
    elegido = componentes.selector(
        paleta,
        "Qué es",
        [(uno.value, texto_de(uno)) for uno in TipoEvento],
        valor=tipo_actual.value,
    )
    titulo = componentes.campo_texto(
        paleta, "Título", valor=evento.titulo if evento else "",
        pista="Entrega de Historia",
    )
    dia = componentes.campo_texto(
        paleta,
        "Día",
        valor=_fecha_a_texto(evento.fecha if evento else (fecha or hoy)),
        pista="16/09",
        ancho=ANCHO_CORTO,
    )
    hora = componentes.campo_texto(
        paleta, "Hora (opcional)", valor=evento.hora if evento else "",
        pista="18:00", ancho=ANCHO_CORTO,
    )
    minutos = componentes.campo_texto(
        paleta,
        "Minutos (opcional)",
        valor=str(evento.minutos) if evento and evento.minutos else "",
        pista="45",
        ancho=ANCHO_CORTO,
    )
    veces = componentes.campo_texto(
        paleta, "Repetir (semanas)", valor="", pista="1", ancho=ANCHO_CORTO
    )
    materia = _campo_materia(paleta, materias, evento.materia_id if evento else None)
    de_tema = componentes.selector(
        paleta,
        "Tema (opcional)",
        [("", "Ninguno")] + [(str(uno.id), uno.nombre) for uno in temas],
        valor=str(evento.tema_id) if evento and evento.tema_id else "",
    )
    prioridad = componentes.selector(
        paleta,
        "Prioridad",
        [(Prioridad.ALTA, "Alta"), (Prioridad.MEDIA, "Media"), (Prioridad.BAJA, "Baja")],
        valor=(evento.prioridad if evento else Prioridad.MEDIA).value,
    )
    notas = componentes.campo_texto(
        paleta, "Notas (opcional)", valor=evento.notas if evento else "", lineas=2
    )
    error = ft.Text("", size=12, color=paleta.negativo, visible=False)

    def guardar(_):
        try:
            cuando = _fecha_desde_texto(dia.value or "", hoy)
            cuantas = _minutos_desde_texto(veces.value or "") or 1
            with conectado() as conexion:
                base = Evento(
                    id=evento.id if evento else None,
                    tipo=TipoEvento(elegido.value),
                    titulo=titulo.value or "",
                    fecha=cuando,
                    hora=hora.value or "",
                    minutos=_minutos_desde_texto(minutos.value or ""),
                    materia_id=_guardar_materia(conexion, materia.value),
                    tema_id=int(de_tema.value) if de_tema.value else None,
                    notas=notas.value or "",
                    prioridad=Prioridad(prioridad.value),
                    hecho_en=evento.hecho_en if evento else None,
                    minutos_reales=evento.minutos_reales if evento else None,
                    dificultad=evento.dificultad if evento else None,
                )
                if base.id is not None:
                    repo.actualizar_evento(conexion, base)
                else:
                    # SE CREA UNA FILA POR SEMANA, de verdad: así puedes mover
                    # o borrar la del jueves que viene sin tocar las demás.
                    for cuando_uno in repetir(cuando, veces=cuantas):
                        repo.crear_evento(conexion, replace(base, fecha=cuando_uno))
                repo.limpiar_materias_sueltas(conexion)
        except Exception as fallo:  # noqa: BLE001
            error.value = _texto_de_error(fallo, "No se ha podido guardar.")
            error.visible = True
            pagina.update()
            return
        pagina.pop_dialog()
        al_guardar()

    piezas: list[ft.Control] = [
        elegido,
        titulo,
        ft.Row([dia, hora], spacing=8, wrap=True, run_spacing=8),
        ft.Row([minutos, veces], spacing=8, wrap=True, run_spacing=8),
        materia,
        de_tema,
        prioridad,
        notas,
        error,
    ]
    if evento is not None:
        piezas += [
            ft.Container(height=4),
            componentes.boton(
                paleta,
                "Borrar esto",
                icono=ft.Icons.DELETE_OUTLINE,
                al_pulsar=lambda _: _borrar_evento(pagina, paleta, evento, al_guardar),
            ),
        ]

    pagina.show_dialog(
        componentes.dialogo(
            paleta,
            "Corregir" if evento else "Añadir al calendario",
            ft.Column(piezas, spacing=10, tight=True, width=ANCHO,
                      scroll=ft.ScrollMode.AUTO),
            pagina=pagina,
            al_aceptar=guardar,
        )
    )


def _borrar_evento(pagina: ft.Page, paleta: Paleta, evento: Evento, al_guardar) -> None:
    pagina.pop_dialog()

    def borrar(_):
        with conectado() as conexion:
            repo.borrar_evento(conexion, evento.id)
            repo.limpiar_materias_sueltas(conexion)
        pagina.pop_dialog()
        al_guardar()

    componentes.confirmar(
        paleta,
        pagina,
        titulo="Borrar del calendario",
        texto="Se borra de tu calendario. No se puede deshacer.",
        al_aceptar=borrar,
    )


# ---------------------------------------------------------------------------
# «Ya lo estudié»
# ---------------------------------------------------------------------------


def abrir_registro(
    pagina: ft.Page, paleta: Paleta, evento: Evento, hoy: date, al_guardar
) -> None:
    """Marcar una sesión como hecha: cuántos minutos y cómo fue.

    LOS MINUTOS VIENEN PUESTOS CON LO QUE PLANEASTE, para que lo normal sea dar
    a guardar sin escribir nada. Si estudiaste menos, lo cambias.
    """
    minutos = componentes.campo_texto(
        paleta,
        "Minutos",
        valor=str(evento.minutos_reales or evento.minutos or ""),
        pista="45",
        ancho=ANCHO_CORTO,
    )
    dificultad = componentes.selector(
        paleta,
        "¿Cómo te fue?",
        [
            (Dificultad.FACIL, "Fácil"),
            (Dificultad.NORMAL, "Normal"),
            (Dificultad.DIFICIL, "Difícil"),
        ],
        valor=(evento.dificultad or Dificultad.NORMAL).value,
    )
    notas = componentes.campo_texto(
        paleta,
        "Notas (opcional)",
        valor=evento.notas,
        pista="entiendo la teoría pero me cuesta hacer ejercicios",
        lineas=2,
    )
    error = ft.Text("", size=12, color=paleta.negativo, visible=False)

    def guardar(_):
        try:
            with conectado() as conexion:
                repo.actualizar_evento(
                    conexion, replace(evento, notas=notas.value or "")
                )
                repo.marcar_hecho(
                    conexion,
                    evento.id,
                    hoy,
                    _minutos_desde_texto(minutos.value or ""),
                    Dificultad(dificultad.value),
                )
        except Exception as fallo:  # noqa: BLE001
            error.value = _texto_de_error(fallo, "No se ha podido guardar.")
            error.visible = True
            pagina.update()
            return
        pagina.pop_dialog()
        al_guardar()

    pagina.show_dialog(
        componentes.dialogo(
            paleta,
            "Ya lo estudié",
            ft.Column([minutos, dificultad, notas, error], spacing=10,
                      tight=True, width=ANCHO),
            pagina=pagina,
            al_aceptar=guardar,
        )
    )


# ---------------------------------------------------------------------------
# Objetivo
# ---------------------------------------------------------------------------


def abrir_meta(
    pagina: ft.Page,
    paleta: Paleta,
    materias: list[Materia],
    temas: list[Tema],
    hoy: date,
    al_guardar,
    meta: Meta | None = None,
) -> None:
    """Crear o corregir un objetivo de estudio, con los temas que lo forman.

    LA MATERIA SE ESCRIBE AQUÍ Y NACE AQUÍ: es la puerta por la que entra todo
    lo demás, desde que Materias dejó de tener pantalla propia.
    """
    nombre = componentes.campo_texto(
        paleta, "Objetivo", valor=meta.nombre if meta else "",
        pista="Aprobar Matemáticas",
    )
    materia = _campo_materia(paleta, materias, meta.materia_id if meta else None)
    limite = componentes.campo_texto(
        paleta,
        "Para cuándo (opcional)",
        valor=_fecha_a_texto(meta.fecha_limite) if meta and meta.fecha_limite else "",
        pista="22/09",
        ancho=ANCHO_CORTO,
    )
    prioridad = componentes.selector(
        paleta,
        "Prioridad",
        [(Prioridad.ALTA, "Alta"), (Prioridad.MEDIA, "Media"), (Prioridad.BAJA, "Baja")],
        valor=(meta.prioridad if meta else Prioridad.MEDIA).value,
        ancho=ANCHO_CORTO,
    )
    descripcion = componentes.campo_texto(
        paleta, "Notas (opcional)", valor=meta.descripcion if meta else "", lineas=2
    )

    # LOS TEMAS SE MARCAN CON CASILLAS Y NO CON UN DESPLEGABLE: un objetivo
    # suele llevar varios, y un desplegable solo deja elegir uno.
    ya_puestos: set[int] = set()
    if meta is not None:
        with conectado() as conexion:
            ya_puestos = {uno.id for uno in repo.temas_de_meta(conexion, meta.id)}
    casillas = {
        uno.id: ft.Checkbox(
            label=uno.nombre, value=uno.id in ya_puestos, active_color=paleta.acento
        )
        for uno in temas
    }
    error = ft.Text("", size=12, color=paleta.negativo, visible=False)

    def guardar(_):
        try:
            with conectado() as conexion:
                una = Meta(
                    id=meta.id if meta else None,
                    nombre=nombre.value or "",
                    descripcion=descripcion.value or "",
                    materia_id=_guardar_materia(conexion, materia.value),
                    fecha_limite=(
                        _fecha_desde_texto(limite.value, hoy)
                        if limite.value.strip()
                        else None
                    ),
                    prioridad=Prioridad(prioridad.value),
                    cumplida_en=meta.cumplida_en if meta else None,
                    orden=meta.orden if meta else 0,
                )
                guardada = (
                    repo.actualizar_meta(conexion, una)
                    if una.id is not None
                    else repo.crear_meta(conexion, una)
                )
                repo.poner_temas_de_meta(
                    conexion,
                    guardada.id,
                    [id_tema for id_tema, casilla in casillas.items() if casilla.value],
                )
                repo.limpiar_materias_sueltas(conexion)
        except Exception as fallo:  # noqa: BLE001
            error.value = _texto_de_error(fallo, "No se ha podido guardar.")
            error.visible = True
            pagina.update()
            return
        pagina.pop_dialog()
        al_guardar()

    piezas: list[ft.Control] = [
        nombre,
        materia,
        ft.Row([limite, prioridad], spacing=8, wrap=True, run_spacing=8),
        descripcion,
    ]
    if casillas:
        piezas += [
            componentes.separador(paleta),
            ft.Text("Temas que lo forman", size=12, color=paleta.muted),
            ft.Column(list(casillas.values()), spacing=0, tight=True),
        ]
    piezas.append(error)

    pagina.show_dialog(
        componentes.dialogo(
            paleta,
            "Corregir objetivo" if meta else "Nuevo objetivo",
            ft.Column(piezas, spacing=10, tight=True, width=ANCHO,
                      scroll=ft.ScrollMode.AUTO),
            pagina=pagina,
            al_aceptar=guardar,
        )
    )


def _texto_de_error(fallo: Exception, si_choca: str) -> str:
    """Lo que se le enseña al usuario.

    UN CHOQUE DE NOMBRE REPETIDO SE EXPLICA EN CRISTIANO: el mensaje que suelta
    SQLite ("UNIQUE constraint failed") no le dice nada a nadie.
    """
    texto = str(fallo)
    if "UNIQUE" in texto or "constraint failed" in texto:
        return si_choca
    return texto
