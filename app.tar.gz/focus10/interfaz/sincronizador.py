"""El que sincroniza solo: al abrir, al apuntar algo, y cada rato por si acaso.

JUNTA LAS DOS MITADES. datos/sincronia.py sabe qué subir y cómo aplicar lo que
llega; sistema/sincronizacion.py sabe hablar con el servidor. Este archivo las
engancha con la sesión de tu cuenta y con la pantalla, y es lo único de la
sincronización que la ventana conoce.

CUÁNDO: decisión suya, «sola, al abrir y al apuntar algo». Al abrir se hace una
vez; después se mira cada LATIDO segundos si hay algo esperando, y si no lo hay
se pregunta igual cada cierto rato, por si otro aparato cambió algo.

SE VE EN UNA NUBE AL LADO DE LA CAMPANA, también decisión suya: al día,
sincronizando, sin internet. Tocándola se sincroniza en el acto.

SIN INTERNET NO PASA NADA MALO: lo apuntado se queda en la cola y sube cuando
vuelva la red. La nube lo dice, y nada se bloquea ni se pierde.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from datetime import datetime

import flet as ft

from ..datos import ajustes, copias, rutas, sincronia
from ..datos.bd import conectado
from ..datos.migraciones import version_actual
from ..sistema import cuentas
from ..sistema import sincronizacion as red
from .estilo import Paleta

LATIDO = 15
"""Cada cuántos segundos se mira si hay algo esperando para subir."""

CADA_RATO = 20
"""Cada cuántos segundos se pregunta al servidor aunque aquí no haya nada,
por si otro aparato cambió algo.

EMPEZÓ EN DOS MINUTOS Y ÉL LO PROBÓ: «si en el celular pongo que hice el
gimnasio, en la computadora tiene que aparecer al mismo tiempo». Dos minutos no
es «al mismo tiempo»: se acaba tocando la nube, y entonces de automático no
tiene nada.

LO QUE CUESTA, QUE ES POCO: una pregunta al servidor que casi siempre vuelve
vacía, unos cientos de bytes. Menos que abrir una página web, cada veinte
segundos y solo con la aplicación abierta."""

AL_VOLVER = ("resume", "show")
"""Y además se sincroniza al volver a la ventana. Si dejaste la aplicación
abierta toda la noche, lo primero que haces por la mañana es mirarla: esa es la
vez que más importa estar al día, y no puede depender de esperar veinte
segundos más."""


@dataclass(frozen=True)
class Estado:
    icono: str
    texto: str
    llama: bool = False
    """Si va del color de aviso: solo cuando hace falta que hagas algo."""

    reintentar: bool = False
    """Si conviene volver a intentarlo en cada latido.

    SOLO LOS QUE SE ARREGLAN SOLOS: sin red y los fallos del servidor. Los que
    esperan una decisión tuya NO: preguntar al servidor cada quince segundos
    algo que solo cambia cuando toques un botón es gastar batería y datos.
    """


AL_DIA = Estado(ft.Icons.CLOUD_DONE_OUTLINED, "Todo al día en tus aparatos.")
SUBIENDO = Estado(ft.Icons.SYNC, "Sincronizando…")
SIN_RED = Estado(
    ft.Icons.CLOUD_OFF_OUTLINED,
    "Sin internet. Lo que apuntes se guarda aquí y sube solo cuando vuelva la red.",
    reintentar=True,
)
FALTA_CONFIRMAR = Estado(
    ft.Icons.CLOUD_DOWNLOAD_OUTLINED,
    "Tu cuenta ya tiene datos de otro aparato. Tocá para traerlos.",
    llama=True,
)
OTRA_CUENTA = Estado(
    ft.Icons.CLOUD_OFF_OUTLINED,
    "Los datos de este aparato son de otra cuenta. Tocá para decidir qué hacer.",
    llama=True,
)
ADOPTAR = Estado(
    ft.Icons.CLOUD_UPLOAD_OUTLINED,
    "Los datos de este aparato son de otra cuenta, y la tuya está vacía. "
    "Tocá para subirlos a la tuya.",
    llama=True,
)
FALLO = Estado(ft.Icons.SYNC_PROBLEM, "No se pudo sincronizar.", llama=True, reintentar=True)
HAY_QUE_ENTRAR = Estado(
    ft.Icons.NO_ACCOUNTS_OUTLINED,
    "Tu sesión ha caducado. Entra otra vez para volver a sincronizar.",
    llama=True,
)


def sesion_viva(conexion, ahora: datetime, renovar=cuentas.renovar):
    """La sesión guardada, renovada si hacía falta. None si no has entrado.

    ANTES DE ESTO NADIE LA RENOVABA: la función existía en sistema/cuentas.py
    pero no la llamaba nadie, y el testigo caduca en una hora. Para entrar no
    importaba —la puerta mira si HAY sesión, no si sirve—, pero para hablar con
    el servidor sí: sin esto, la sincronización dejaría de funcionar a la hora.
    """
    sesion = ajustes.leer_sesion(conexion)
    if sesion is None or sesion.esta_viva(ahora):
        return sesion
    try:
        nueva = renovar(sesion, ahora)
    except cuentas.SesionCaducada:
        # LA SESION MUERTA SE BORRA AQUI MISMO. Guardada no sirve para nada:
        # cada latido volveria a intentar renovarla, volveria a fallar y la
        # aplicacion se pasaria los dias diciendo "no se pudo sincronizar" sin
        # que haya nada que reintentar. Borrandola, la puerta vuelve a salir y
        # entrar otra vez lo arregla. Los datos apuntados no se tocan.
        ajustes.cerrar_sesion(conexion)
        raise
    ajustes.guardar_sesion(conexion, nueva)
    return nueva


def paso(
    conexion, ahora: datetime, *, confirmado: bool = False, servidor=red, renovar=cuentas.renovar
) -> tuple[Estado, sincronia.Informe | None]:
    """Una sincronización entera. Sin pantalla, para poder probarla.

    `servidor` es el módulo de red; en los tests se cambia por uno de mentira.
    """
    try:
        sesion = sesion_viva(conexion, ahora, renovar)
        if sesion is None:
            return AL_DIA, None
        testigo = sesion.testigo

        # DE QUIÉN SON LOS DATOS DE ESTE APARATO. Si no es de quien está
        # dentro ahora, hay que decidir, y la decisión es suya: puede que los
        # datos sean suyos y quiera subirlos, o puede que quiera los de esta
        # cuenta. Antes esto solo se bloqueaba, sin salida, y quedarse
        # bloqueado para siempre no es proteger nada.
        de_quien = sincronia.cuenta_sincronizada(conexion)
        if de_quien != sesion.correo:
            if not servidor.hay_algo(testigo):
                # La cuenta está vacía: subir lo de aquí no pisa nada de
                # nadie. Se pregunta igual si los datos eran de otra cuenta.
                if de_quien is not None and not confirmado:
                    return ADOPTAR, None
                sincronia.mandar(conexion, sesion.correo)
            elif not confirmado:
                return (OTRA_CUENTA if de_quien is not None else FALTA_CONFIRMAR), None
            else:
                # PRIMERO SE BAJA, DESPUÉS LA COPIA, Y SOLO ENTONCES SE VACÍA.
                # Si la bajada falla, no se ha tocado nada; si la copia falla,
                # tampoco: NoSePudoCopiar para todo antes de vaciar.
                llegados = servidor.bajar(testigo, 0)
                copias.copiar(conexion, rutas.ruta_bd(), version_actual(conexion))
                informe = sincronia.vaciar_y_recibir(conexion, sesion.correo, llegados)
                return AL_DIA, informe

        informe = sincronia.sincronizar(
            conexion,
            lambda paquetes: servidor.subir(testigo, paquetes),
            lambda desde: servidor.bajar(testigo, desde),
        )

        return AL_DIA, informe
    except cuentas.SesionCaducada:
        # NO SE REINTENTA: no hay nada que reintentar hasta que la persona
        # vuelva a entrar. `sesion_viva` ya ha borrado la sesion muerta.
        return HAY_QUE_ENTRAR, None
    except red.SinConexion:
        return SIN_RED, None
    except (red.ServidorDijoQueNo, cuentas.NoSePudoEntrar, copias.NoSePudoCopiar) as fallo:
        return Estado(
            FALLO.icono, f"No se pudo sincronizar: {fallo}", llama=True, reintentar=True
        ), None
    except Exception as fallo:  # noqa: BLE001
        # CUALQUIER OTRA COSA TAMBIEN SE CUENTA, y esto no es pereza: lo de
        # arriba son los cuatro fallos PREVISTOS, y un imprevisto —una fila que
        # no encaja en una tabla, un dato con una forma rara— se escapaba de
        # aqui, mataba la tarea del latido y dejaba la nube girando para
        # siempre. Peor aun: a partir de ahi la aplicacion ya no volvia a
        # sincronizar sola hasta reiniciarla, y eso no se ve por ninguna parte.
        # Le paso al usuario. Un imprevisto tiene que poder leerse, que para
        # eso se escribe el mensaje con la causa detras.
        return Estado(
            FALLO.icono,
            f"No se pudo sincronizar: {type(fallo).__name__}: {fallo}",
            llama=True,
            reintentar=False,
        ), None


def _hay_esperando(conexion) -> bool:
    return conexion.execute("SELECT 1 FROM sinc_pendientes LIMIT 1").fetchone() is not None


class Sincronizador:
    """La nube de la barra y el latido que la mantiene al día."""

    def __init__(self, pagina: ft.Page, al_llegar, al_terminar_la_primera=None) -> None:
        self.pagina = pagina
        self.al_llegar = al_llegar
        self.al_terminar_la_primera = al_terminar_la_primera
        # LA PRIMERA SINCRONIZACIÓN SE ESPERA ANTES DE ENSEÑAR NADA, y lo pidió
        # él con sus palabras: «cuando la computadora abre la aplicación, antes
        # de mostrarte las cosas, toma los datos del celular». Si se pintara
        # primero, verías los números de ayer y cambiarían solos delante de tus
        # ojos, que es peor que esperar un segundo.
        self.primera_hecha = False
        self.estado = SUBIENDO
        self._latiendo = False
        self._ocupado = False
        self._ultima = 0.0
        # CUANDO EMPEZO LA QUE ESTA EN MARCHA. Sirve para poder contestar
        # «lleva dos minutos» en vez de dejar una rueda muda, que es
        # indistinguible de una aplicacion colgada.
        self._empezo = 0.0
        # LA NUBE SE CREA UNA VEZ, igual que el reloj del entreno: la ventana
        # se vuelve a montar en cada cambio de sección, y así el estado se
        # cambia sin tener que repintar nada más.
        self.nube = ft.IconButton(icon_size=20, on_click=self._al_pulsar)
        self._paleta: Paleta | None = None

    # ------------------------------------------------------------ la nube

    def control(self, paleta: Paleta) -> ft.Control:
        self._paleta = paleta
        self._pintar()
        return self.nube

    def _pintar(self) -> None:
        if self._paleta is None:
            return
        self.nube.icon = self.estado.icono
        self.nube.icon_color = self._paleta.aviso if self.estado.llama else self._paleta.ink
        self.nube.tooltip = self.estado.texto
        try:
            self.nube.update()
        except Exception:  # noqa: BLE001
            # Todavía no está en la ventana: se pintará al montarla.
            pass

    def _cambiar(self, estado: Estado) -> None:
        self.estado = estado
        self._pintar()

    # ------------------------------------------------------------ el latido

    def empezar(self) -> None:
        """Arranca el latido. La ventana lo llama en cada montaje; solo cuenta
        la primera vez, por lo mismo que el reloj del entreno."""
        if self._latiendo:
            return
        self._latiendo = True
        self.pagina.run_task(self._latir)

    def _toca_ya(self, esperando: bool) -> bool:
        """Si hay que intentarlo en este latido.

        SIN CONEXIÓN SE REINTENTA CADA LATIDO, y eso lo pidió él con su caso:
        «en el celular anoto todo el tiempo con datos móviles, y cuando mi PC
        se conecta a un wifi se actualiza». Esperar dos minutos después de
        enganchar el wifi es esperar dos minutos de más. Un intento que falla
        sin red no llega a salir del aparato: no cuesta nada.
        """
        if self.estado.reintentar:
            return True
        return esperando or time.monotonic() - self._ultima >= CADA_RATO

    async def _latir(self) -> None:
        await self._una_vez()
        while True:
            await asyncio.sleep(LATIDO)
            with conectado() as conexion:
                esperando = _hay_esperando(conexion)
            if self._toca_ya(esperando):
                await self._una_vez()

    def al_volver_a_la_ventana(self, estado) -> None:
        """Cuando la ventana vuelve a primer plano, ponerse al día ya."""
        # LOS DOS NOMBRES: Windows manda unas veces "resume" y otras "show"
        # (volver de minimizada, cambiar de escritorio). Quedarse con uno solo
        # haría que funcionara a veces, que es lo peor que puede pasar.
        if getattr(estado, "value", estado) in AL_VOLVER:
            self.pagina.run_task(self._una_vez)

    async def _una_vez(self, confirmado: bool = False) -> None:
        # UNA A LA VEZ: tocar la nube mientras late no puede lanzar dos
        # sincronizaciones sobre la misma base.
        if self._ocupado:
            return
        self._ocupado = True
        self._empezo = time.monotonic()
        try:
            self._cambiar(SUBIENDO)
            try:
                estado, informe = await self._en_segundo_plano(confirmado)
            except Exception as fallo:  # noqa: BLE001
                # LA SEGUNDA RED, para lo que ocurra FUERA de `paso` (al pedir
                # un hilo, por ejemplo). Sin esto, la nube se queda girando y
                # el latido se muere: ni sincroniza ni lo dice.
                estado, informe = Estado(
                    FALLO.icono,
                    f"No se pudo sincronizar: {type(fallo).__name__}: {fallo}",
                    llama=True,
                ), None
            self._ultima = time.monotonic()
            self._cambiar(self._con_el_resumen(estado, informe))
            if informe is not None and informe.aplicados:
                try:
                    self.al_llegar()
                except Exception:  # noqa: BLE001
                    # UN FALLO PINTANDO NO PUEDE MATAR EL LATIDO. Si esta
                    # tarea revienta, se acaba la sincronización automática
                    # hasta reiniciar, y eso no se ve: parece que «a veces no
                    # sincroniza». Es la misma lección del reloj del entreno.
                    pass
        finally:
            self._ocupado = False
            # PASE LO QUE PASE: si no hay internet o el servidor falla, la
            # aplicación se abre igual con lo que hay aquí. Quedarse esperando
            # a una red que no está sería dejar la aplicación sin abrir.
            if not self.primera_hecha:
                self.primera_hecha = True
                if self.al_terminar_la_primera is not None:
                    self.al_terminar_la_primera()

    async def _en_segundo_plano(self, confirmado: bool):
        """Lo lento (la red) fuera del hilo de la ventana, si se puede.

        EN LA WEB NO HAY HILOS: el Python del navegador corre en uno solo, y
        pedir otro da error. Ahí se hace en el mismo, que congela la ventana lo
        que tarde la petición —normalmente menos de un segundo—. Es el precio
        de que la misma aplicación funcione en el navegador.
        """
        def trabajo():
            with conectado() as conexion:
                return paso(conexion, datetime.now(), confirmado=confirmado)

        try:
            return await asyncio.to_thread(trabajo)
        except RuntimeError:
            return trabajo()

    # ------------------------------------------------------------ al tocarla

    def _con_el_resumen(self, estado: Estado, informe) -> Estado:
        """Le pega al estado lo que trajo la ultima vuelta.

        LO SALTADO SE DICE, Y ESTO ES LO IMPORTANTE. Cuando una fila que baja
        no se puede poner aqui —le falta su padre, choca con algo que ya
        existe— se anotaba en un informe QUE NADIE ENSENABA NUNCA. La
        aplicacion decia «todo al dia» mientras tiraba cambios a la basura en
        silencio. Si algo no llego, tiene que poder leerse.
        """
        if informe is None or estado.llama:
            return estado
        partes = []
        if informe.aplicados:
            partes.append(f"{informe.aplicados} cambios recibidos")
        if informe.subidos:
            partes.append(f"{informe.subidos} enviados")
        if informe.saltados:
            partes.append(
                f"{len(informe.saltados)} sin poder aplicar "
                f"({informe.saltados[0]})"
            )
        if not partes:
            return estado
        return Estado(
            estado.icono,
            estado.texto + "\n" + ", ".join(partes) + ".",
            llama=bool(informe.saltados),
            reintentar=estado.reintentar,
        )

    def _al_pulsar(self, _evento) -> None:
        if self.estado in (FALTA_CONFIRMAR, OTRA_CUENTA, ADOPTAR):
            self._preguntar()
        elif self._ocupado:
            # UNA RUEDA MUDA NO SE DISTINGUE DE UNA APLICACION COLGADA. El
            # usuario la miro girar sin saber si hacia algo; lo minimo es
            # decirle que sigue viva y desde cuando.
            segundos = int(time.monotonic() - self._empezo)
            self._contar_que_pasa(
                "Sincronizando desde hace "
                f"{segundos // 60} min {segundos % 60} s.\n\n"
                "La primera vez con mucho historial tarda: se baja entero "
                "antes de guardarlo, para no dejar datos a medias.",
                con_reintento=False,
            )
        elif self.estado.llama:
            # ALGO VA MAL: LO PRIMERO ES PODER LEERLO. El mensaje estaba solo
            # como tooltip, y en un movil no hay raton que pasar por encima:
            # el usuario tenia un fallo delante y NO HABIA MANERA de saber cual
            # era. Un aviso que solo se puede leer con raton no es un aviso en
            # un telefono.
            self._contar_que_pasa()
        else:
            self.pagina.run_task(self._una_vez)

    def _contar_que_pasa(self, texto: str | None = None, *, con_reintento=True) -> None:
        """Ensena el estado escrito, con un boton para volver a intentarlo."""
        acciones = [ft.TextButton("Cerrar", on_click=lambda _: self.pagina.pop_dialog())]
        if con_reintento:
            acciones.append(
                ft.FilledButton("Intentar ahora", on_click=lambda _: self._reintentar())
            )
        self.pagina.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text("Sincronizacion"),
                content=ft.Text(texto or self.estado.texto, selectable=True),
                actions=acciones,
            )
        )

    def _reintentar(self) -> None:
        self.pagina.pop_dialog()
        self.pagina.run_task(self._una_vez)

    def _quienes(self) -> tuple[str, str]:
        """(de quién son los datos de aquí, quién está dentro ahora)."""
        with conectado() as conexion:
            sesion = ajustes.leer_sesion(conexion)
            return (
                sincronia.cuenta_sincronizada(conexion) or "",
                sesion.correo if sesion else "",
            )

    def _preguntar(self) -> None:
        """Las únicas veces que se pide permiso: antes de vaciar este aparato,
        o antes de subir a una cuenta datos que eran de otra.

        SE ENSEÑAN LOS DOS CORREOS cuando los hay. «Otra cuenta» sin decir cuál
        no se puede ni comprobar; con los dos delante se ve de un vistazo si es
        lo que uno cree.
        """
        antes, ahora = self._quienes()

        def seguir(_):
            self.pagina.pop_dialog()
            self.pagina.run_task(self._una_vez, True)

        if self.estado is ADOPTAR:
            titulo = "Subir los datos de este aparato"
            texto = (
                f"Lo que hay en este aparato se sincronizó con {antes}, y ahora "
                f"estás dentro con {ahora}.\n\n"
                f"Tu cuenta {ahora} está vacía, así que se pueden subir estos "
                "datos sin pisar nada.\n\n"
                "No se borra nada de este aparato."
            )
            boton = "Subir estos datos"
        else:
            titulo = "Traer los datos de tu cuenta"
            de_quien = (
                f"Lo que hay en este aparato se sincronizó con {antes}, y ahora "
                f"estás dentro con {ahora}.\n\n"
                if antes
                else "Tu cuenta ya tiene datos de otro aparato.\n\n"
            )
            texto = (
                de_quien
                + "Para no mezclar ni repetir nada, este aparato se VACÍA y se "
                f"queda con los datos de {ahora}.\n\n"
                "Antes se guarda una copia de seguridad de lo que hay aquí, "
                "por si acaso.\n\n"
                "Tu tema y tu sesión no se tocan."
            )
            boton = "Traer mis datos"

        self.pagina.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text(titulo),
                content=ft.Text(texto),
                actions=[
                    ft.TextButton("Ahora no", on_click=lambda _: self.pagina.pop_dialog()),
                    ft.FilledButton(boton, on_click=seguir),
                ],
            )
        )
