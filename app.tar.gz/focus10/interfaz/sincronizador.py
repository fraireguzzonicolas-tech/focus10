"""El que sincroniza solo: al abrir, al apuntar algo, y cada rato por si acaso.

JUNTA LAS DOS MITADES. datos/sincronia.py sabe qué subir y cómo aplicar lo que
llega; sistema/sincronizacion.py sabe hablar con el servidor. Este archivo las
engancha con la sesión de tu cuenta y con la pantalla, y es lo único de la
sincronización que la ventana conoce.

CUÁNDO: decisión suya, «sola, al abrir y al apuntar algo». Al abrir se hace una
vez; después se mira cada LATIDO segundos si hay algo esperando, y si no lo hay
se pregunta igual cada cierto rato, por si otro aparato cambió algo.

SE VE EN UNA NUBE AL LADO DE LA CAMPANA, también decisión suya: al día,
sincronizando, sin internet. Tocándola se sincroniza en el acto.

SIN INTERNET NO PASA NADA MALO: lo apuntado se queda en la cola y sube cuando
vuelva la red. La nube lo dice, y nada se bloquea ni se pierde.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from datetime import datetime

import flet as ft

from ..datos import ajustes, copias, rutas, sincronia
from ..datos.bd import conectado
from ..datos.migraciones import version_actual
from ..sistema import cuentas
from ..sistema import sincronizacion as red
from .estilo import Paleta

LATIDO = 15
"""Cada cuántos segundos se mira si hay algo esperando para subir."""

CADA_RATO = 120
"""Cada cuántos segundos se pregunta al servidor aunque aquí no haya nada,
por si otro aparato cambió algo. Más a menudo sería gastar batería y datos
del móvil para enterarse medio minuto antes."""


@dataclass(frozen=True)
class Estado:
    icono: str
    texto: str
    llama: bool = False
    """Si va del color de aviso: solo cuando hace falta que hagas algo."""

    reintentar: bool = False
    """Si conviene volver a intentarlo en cada latido.

    SOLO LOS QUE SE ARREGLAN SOLOS: sin red y los fallos del servidor. Los que
    esperan una decisión tuya NO: preguntar al servidor cada quince segundos
    algo que solo cambia cuando toques un botón es gastar batería y datos.
    """


AL_DIA = Estado(ft.Icons.CLOUD_DONE_OUTLINED, "Todo al día en tus aparatos.")
SUBIENDO = Estado(ft.Icons.SYNC, "Sincronizando…")
SIN_RED = Estado(
    ft.Icons.CLOUD_OFF_OUTLINED,
    "Sin internet. Lo que apuntes se guarda aquí y sube solo cuando vuelva la red.",
    reintentar=True,
)
FALTA_CONFIRMAR = Estado(
    ft.Icons.CLOUD_DOWNLOAD_OUTLINED,
    "Tu cuenta ya tiene datos de otro aparato. Tocá para traerlos.",
    llama=True,
)
OTRA_CUENTA = Estado(
    ft.Icons.CLOUD_OFF_OUTLINED,
    "Los datos de este aparato son de otra cuenta. Tocá para decidir qué hacer.",
    llama=True,
)
ADOPTAR = Estado(
    ft.Icons.CLOUD_UPLOAD_OUTLINED,
    "Los datos de este aparato son de otra cuenta, y la tuya está vacía. "
    "Tocá para subirlos a la tuya.",
    llama=True,
)
FALLO = Estado(ft.Icons.SYNC_PROBLEM, "No se pudo sincronizar.", llama=True, reintentar=True)


def sesion_viva(conexion, ahora: datetime, renovar=cuentas.renovar):
    """La sesión guardada, renovada si hacía falta. None si no has entrado.

    ANTES DE ESTO NADIE LA RENOVABA: la función existía en sistema/cuentas.py
    pero no la llamaba nadie, y el testigo caduca en una hora. Para entrar no
    importaba —la puerta mira si HAY sesión, no si sirve—, pero para hablar con
    el servidor sí: sin esto, la sincronización dejaría de funcionar a la hora.
    """
    sesion = ajustes.leer_sesion(conexion)
    if sesion is None or sesion.esta_viva(ahora):
        return sesion
    nueva = renovar(sesion, ahora)
    ajustes.guardar_sesion(conexion, nueva)
    return nueva


def paso(
    conexion, ahora: datetime, *, confirmado: bool = False, servidor=red, renovar=cuentas.renovar
) -> tuple[Estado, sincronia.Informe | None]:
    """Una sincronización entera. Sin pantalla, para poder probarla.

    `servidor` es el módulo de red; en los tests se cambia por uno de mentira.
    """
    try:
        sesion = sesion_viva(conexion, ahora, renovar)
        if sesion is None:
            return AL_DIA, None
        testigo = sesion.testigo

        # DE QUIÉN SON LOS DATOS DE ESTE APARATO. Si no es de quien está
        # dentro ahora, hay que decidir, y la decisión es suya: puede que los
        # datos sean suyos y quiera subirlos, o puede que quiera los de esta
        # cuenta. Antes esto solo se bloqueaba, sin salida, y quedarse
        # bloqueado para siempre no es proteger nada.
        de_quien = sincronia.cuenta_sincronizada(conexion)
        if de_quien != sesion.correo:
            if not servidor.hay_algo(testigo):
                # La cuenta está vacía: subir lo de aquí no pisa nada de
                # nadie. Se pregunta igual si los datos eran de otra cuenta.
                if de_quien is not None and not confirmado:
                    return ADOPTAR, None
                sincronia.mandar(conexion, sesion.correo)
            elif not confirmado:
                return (OTRA_CUENTA if de_quien is not None else FALTA_CONFIRMAR), None
            else:
                # PRIMERO SE BAJA, DESPUÉS LA COPIA, Y SOLO ENTONCES SE VACÍA.
                # Si la bajada falla, no se ha tocado nada; si la copia falla,
                # tampoco: NoSePudoCopiar para todo antes de vaciar.
                llegados = servidor.bajar(testigo, 0)
                copias.copiar(conexion, rutas.ruta_bd(), version_actual(conexion))
                informe = sincronia.vaciar_y_recibir(conexion, sesion.correo, llegados)
                return AL_DIA, informe

        informe = sincronia.sincronizar(
            conexion,
            lambda paquetes: servidor.subir(testigo, paquetes),
            lambda desde: servidor.bajar(testigo, desde),
        )
        return AL_DIA, informe
    except red.SinConexion:
        return SIN_RED, None
    except (red.ServidorDijoQueNo, cuentas.NoSePudoEntrar, copias.NoSePudoCopiar) as fallo:
        return Estado(
            FALLO.icono, f"No se pudo sincronizar: {fallo}", llama=True, reintentar=True
        ), None


def _hay_esperando(conexion) -> bool:
    return conexion.execute("SELECT 1 FROM sinc_pendientes LIMIT 1").fetchone() is not None


class Sincronizador:
    """La nube de la barra y el latido que la mantiene al día."""

    def __init__(self, pagina: ft.Page, al_llegar) -> None:
        self.pagina = pagina
        self.al_llegar = al_llegar
        self.estado = SUBIENDO
        self._latiendo = False
        self._ocupado = False
        self._ultima = 0.0
        # LA NUBE SE CREA UNA VEZ, igual que el reloj del entreno: la ventana
        # se vuelve a montar en cada cambio de sección, y así el estado se
        # cambia sin tener que repintar nada más.
        self.nube = ft.IconButton(icon_size=20, on_click=self._al_pulsar)
        self._paleta: Paleta | None = None

    # ------------------------------------------------------------ la nube

    def control(self, paleta: Paleta) -> ft.Control:
        self._paleta = paleta
        self._pintar()
        return self.nube

    def _pintar(self) -> None:
        if self._paleta is None:
            return
        self.nube.icon = self.estado.icono
        self.nube.icon_color = self._paleta.aviso if self.estado.llama else self._paleta.ink
        self.nube.tooltip = self.estado.texto
        try:
            self.nube.update()
        except Exception:  # noqa: BLE001
            # Todavía no está en la ventana: se pintará al montarla.
            pass

    def _cambiar(self, estado: Estado) -> None:
        self.estado = estado
        self._pintar()

    # ------------------------------------------------------------ el latido

    def empezar(self) -> None:
        """Arranca el latido. La ventana lo llama en cada montaje; solo cuenta
        la primera vez, por lo mismo que el reloj del entreno."""
        if self._latiendo:
            return
        self._latiendo = True
        self.pagina.run_task(self._latir)

    def _toca_ya(self, esperando: bool) -> bool:
        """Si hay que intentarlo en este latido.

        SIN CONEXIÓN SE REINTENTA CADA LATIDO, y eso lo pidió él con su caso:
        «en el celular anoto todo el tiempo con datos móviles, y cuando mi PC
        se conecta a un wifi se actualiza». Esperar dos minutos después de
        enganchar el wifi es esperar dos minutos de más. Un intento que falla
        sin red no llega a salir del aparato: no cuesta nada.
        """
        if self.estado.reintentar:
            return True
        return esperando or time.monotonic() - self._ultima >= CADA_RATO

    async def _latir(self) -> None:
        await self._una_vez()
        while True:
            await asyncio.sleep(LATIDO)
            with conectado() as conexion:
                esperando = _hay_esperando(conexion)
            if self._toca_ya(esperando):
                await self._una_vez()

    async def _una_vez(self, confirmado: bool = False) -> None:
        # UNA A LA VEZ: tocar la nube mientras late no puede lanzar dos
        # sincronizaciones sobre la misma base.
        if self._ocupado:
            return
        self._ocupado = True
        try:
            self._cambiar(SUBIENDO)
            estado, informe = await self._en_segundo_plano(confirmado)
            self._ultima = time.monotonic()
            self._cambiar(estado)
            if informe is not None and informe.aplicados:
                self.al_llegar()
        finally:
            self._ocupado = False

    async def _en_segundo_plano(self, confirmado: bool):
        """Lo lento (la red) fuera del hilo de la ventana, si se puede.

        EN LA WEB NO HAY HILOS: el Python del navegador corre en uno solo, y
        pedir otro da error. Ahí se hace en el mismo, que congela la ventana lo
        que tarde la petición —normalmente menos de un segundo—. Es el precio
        de que la misma aplicación funcione en el navegador.
        """
        def trabajo():
            with conectado() as conexion:
                return paso(conexion, datetime.now(), confirmado=confirmado)

        try:
            return await asyncio.to_thread(trabajo)
        except RuntimeError:
            return trabajo()

    # ------------------------------------------------------------ al tocarla

    def _al_pulsar(self, _evento) -> None:
        if self.estado in (FALTA_CONFIRMAR, OTRA_CUENTA, ADOPTAR):
            self._preguntar()
        else:
            self.pagina.run_task(self._una_vez)

    def _quienes(self) -> tuple[str, str]:
        """(de quién son los datos de aquí, quién está dentro ahora)."""
        with conectado() as conexion:
            sesion = ajustes.leer_sesion(conexion)
            return (
                sincronia.cuenta_sincronizada(conexion) or "",
                sesion.correo if sesion else "",
            )

    def _preguntar(self) -> None:
        """Las únicas veces que se pide permiso: antes de vaciar este aparato,
        o antes de subir a una cuenta datos que eran de otra.

        SE ENSEÑAN LOS DOS CORREOS cuando los hay. «Otra cuenta» sin decir cuál
        no se puede ni comprobar; con los dos delante se ve de un vistazo si es
        lo que uno cree.
        """
        antes, ahora = self._quienes()

        def seguir(_):
            self.pagina.pop_dialog()
            self.pagina.run_task(self._una_vez, True)

        if self.estado is ADOPTAR:
            titulo = "Subir los datos de este aparato"
            texto = (
                f"Lo que hay en este aparato se sincronizó con {antes}, y ahora "
                f"estás dentro con {ahora}.\n\n"
                f"Tu cuenta {ahora} está vacía, así que se pueden subir estos "
                "datos sin pisar nada.\n\n"
                "No se borra nada de este aparato."
            )
            boton = "Subir estos datos"
        else:
            titulo = "Traer los datos de tu cuenta"
            de_quien = (
                f"Lo que hay en este aparato se sincronizó con {antes}, y ahora "
                f"estás dentro con {ahora}.\n\n"
                if antes
                else "Tu cuenta ya tiene datos de otro aparato.\n\n"
            )
            texto = (
                de_quien
                + "Para no mezclar ni repetir nada, este aparato se VACÍA y se "
                f"queda con los datos de {ahora}.\n\n"
                "Antes se guarda una copia de seguridad de lo que hay aquí, "
                "por si acaso.\n\n"
                "Tu tema y tu sesión no se tocan."
            )
            boton = "Traer mis datos"

        self.pagina.show_dialog(
            ft.AlertDialog(
                modal=True,
                title=ft.Text(titulo),
                content=ft.Text(texto),
                actions=[
                    ft.TextButton("Ahora no", on_click=lambda _: self.pagina.pop_dialog()),
                    ft.FilledButton(boton, on_click=seguir),
                ],
            )
        )
