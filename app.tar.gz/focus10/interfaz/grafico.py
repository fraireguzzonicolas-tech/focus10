"""El gráfico diario de ingresos y gastos, dibujado a mano.

POR QUÉ A MANO Y NO CON UNA LIBRERÍA DE GRÁFICOS: Flet 0.86 ya no trae control
de gráficos, y no hay paquete instalado que lo aporte. Antes que añadir una
dependencia externa desconocida para pintar treinta parejas de barras, se
dibujan con rectángulos: son cuatro cuentas, no puede romperse al actualizar
nada, y el resultado se controla al detalle.

QUÉ ENSEÑA: una columna por jornada del mes, con dos barras (ingresos y gastos).
La altura es proporcional al valor más alto del mes, así que el gráfico compara
días entre sí; no es una escala absoluta.
"""

from __future__ import annotations

from datetime import date

import flet as ft

from ..datos.repositorio_movimientos import TotalDeJornada
from ..dominio import dinero
from ..dominio.moneda import Moneda
from .estilo import Paleta

ALTO_BARRAS = 120
ANCHO_BARRA = 7
ANCHO_MINIMO_COLUMNA = 22


def grafico_diario(
    totales: list[TotalDeJornada],
    dias: list[date],
    principal: Moneda,
    paleta: Paleta,
) -> ft.Control:
    """El gráfico del mes. `dias` son TODOS los días del mes, con o sin datos.

    Los días vacíos se dibujan igual, sin barra: si se saltaran, un mes con
    gastos solo los fines de semana parecería un mes seguido.
    """
    por_dia = {total.jornada: total for total in totales}
    tope = max((max(total.gastos, total.ingresos) for total in totales), default=0)

    if tope == 0:
        return _sin_datos(bool(totales), paleta)

    columnas = [_columna(dia, por_dia.get(dia), tope, paleta) for dia in dias]

    return ft.Column(
        [
            ft.Row(columnas, spacing=2, scroll=ft.ScrollMode.AUTO),
            _leyenda(tope, principal, paleta),
        ],
        spacing=10,
    )


def _columna(
    dia: date, total: TotalDeJornada | None, tope: int, paleta: Paleta
) -> ft.Control:
    """Un día: sus dos barras y el número debajo."""
    ingresos = total.ingresos if total else 0
    gastos = total.gastos if total else 0
    pendientes = total.pendientes if total else 0

    barras = ft.Row(
        [
            _barra(ingresos, tope, paleta.positivo),
            _barra(gastos, tope, paleta.negativo),
        ],
        spacing=2,
        alignment=ft.MainAxisAlignment.CENTER,
        vertical_alignment=ft.CrossAxisAlignment.END,
    )

    # Un asterisco encima del día avisa de que ese día tiene algo sin convertir,
    # o sea que sus barras se quedan cortas. Sin esto, el gráfico mentiría.
    etiqueta = f"{dia.day}*" if pendientes else str(dia.day)

    return ft.Column(
        [
            ft.Container(
                content=ft.Column(
                    [barras],
                    alignment=ft.MainAxisAlignment.END,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                height=ALTO_BARRAS,
                width=ANCHO_MINIMO_COLUMNA,
            ),
            ft.Text(
                etiqueta,
                size=9,
                color=paleta.aviso if pendientes else paleta.muted,
            ),
        ],
        spacing=3,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        tight=True,
    )


def _barra(valor: int, tope: int, color: str) -> ft.Control:
    """Una barra. Un valor de cero no dibuja nada, para no confundir un día sin
    gastos con un gasto minúsculo."""
    if valor <= 0:
        return ft.Container(width=ANCHO_BARRA, height=0)
    # Mínimo de 2 píxeles: un gasto pequeñísimo tiene que verse, o parecería
    # que ese día no hubo nada.
    alto = max(2, round(valor / tope * ALTO_BARRAS))
    return ft.Container(width=ANCHO_BARRA, height=alto, bgcolor=color, border_radius=3)


def _leyenda(tope: int, principal: Moneda, paleta: Paleta) -> ft.Control:
    return ft.Row(
        [
            _muestra(paleta.positivo, "ingresos", paleta),
            _muestra(paleta.negativo, "gastos", paleta),
            ft.Container(expand=True),
            ft.Text(
                f"barra más alta = {dinero.formatear(tope, principal)}",
                size=11,
                color=paleta.muted,
            ),
        ],
        spacing=14,
    )


def _muestra(color: str, texto: str, paleta: Paleta) -> ft.Control:
    return ft.Row(
        [
            ft.Container(width=9, height=9, bgcolor=color, border_radius=2),
            ft.Text(texto, size=11, color=paleta.muted),
        ],
        spacing=6,
        tight=True,
    )


def _sin_datos(hay_movimientos: bool, paleta: Paleta) -> ft.Control:
    """Cuando no hay nada que dibujar se dice, en vez de enseñar un gráfico
    vacío que parece roto."""
    texto = (
        "Este mes solo tiene movimientos sin convertir, así que todavía no hay "
        "nada que dibujar."
        if hay_movimientos
        else "Aún no hay movimientos este mes."
    )
    return ft.Container(
        content=ft.Text(texto, size=13, color=paleta.muted),
        height=ALTO_BARRAS,
        alignment=ft.Alignment.CENTER,
    )
