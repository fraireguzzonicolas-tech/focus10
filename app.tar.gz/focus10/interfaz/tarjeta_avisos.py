"""La tarjeta de «Avisos importantes»: quién puede avisarte de WhatsApp e Instagram.

SOLO EXISTE EN LA APP INSTALADA EN ANDROID. En Windows y en la web no se crea:
allí no hay avisos de WhatsApp que escuchar.

LA LISTA NO VA A LA BASE DE DATOS, se guarda en Android. Quien decide si suena
un aviso es la pieza de Java, y corre con la aplicación CERRADA: no puede abrir
la base de datos para preguntar. Así que esta tarjeta lee y escribe justo lo que
lee Java, y no hay dos copias que puedan contradecirse. La consecuencia, dicha a
propósito: la lista no viaja en las copias ni se sincroniza; es de este móvil.

CÓMO FUNCIONA (la forma A que se eligió): WhatsApp e Instagram se silencian en
los Ajustes de Android y Focus1% vuelve a avisar con sonido. Con el filtro
encendido y en su horario, solo de la gente de la lista; fuera del horario o
con el filtro apagado, de todos.
"""

from __future__ import annotations

from dataclasses import replace

import flet as ft

from ..dominio.filtro_avisos import (
    LARGO_MAXIMO_NOMBRE,
    FiltroAvisos,
    a_texto,
    con_horario,
    con_nombre,
    desde_texto,
    sin_nombre,
)
from . import componentes, estilo
from .estilo import Paleta

CUANTOS_VISTOS = 8
"""Los últimos nombres que te escribieron, para copiarlos tal cual."""


class TarjetaAvisos:
    def __init__(self, pagina: ft.Page, paleta: Paleta, avisos) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.avisos = avisos

        self.filtro = FiltroAvisos()
        self.permiso = False
        self.puede_avisar = False
        self.vistos: list[str] = []
        self.error = ""
        # HASTA QUE NO SE LEE EL MÓVIL NO SE ENSEÑA NADA QUE SE PUEDA TOCAR:
        # guardar antes pisaría la lista de verdad con una vacía.
        self.cargado = False

        # LOS CAMPOS SE CREAN UNA VEZ: repintar la tarjeta al guardar no puede
        # borrar lo que estás escribiendo.
        self.campo_nombre = componentes.campo_texto(
            paleta,
            "Nombre o número",
            pista="exactamente como sale en WhatsApp",
            largo_maximo=LARGO_MAXIMO_NOMBRE,
            al_enviar=self._anadir,
        )
        self.campo_nombre.expand = True
        self.campo_desde = componentes.campo_texto(
            paleta, "Desde", pista="22:00", ancho=120, al_enviar=self._cambiar_horario
        )
        self.campo_hasta = componentes.campo_texto(
            paleta, "Hasta", pista="07:00", ancho=120, al_enviar=self._cambiar_horario
        )
        # También al salir del campo: nadie pulsa Intro en un campo de texto.
        self.campo_desde.on_blur = self._cambiar_horario
        self.campo_hasta.on_blur = self._cambiar_horario

        self.cuerpo = ft.Column(spacing=14, tight=True)
        self._pintar()

    def control(self) -> ft.Control:
        return componentes.tarjeta(self.paleta, self.cuerpo)

    # ----------------------------------------------------------------------

    def cargar(self, _=None) -> None:
        self.pagina.run_task(self._cargar)

    async def _cargar(self) -> None:
        try:
            permiso = await self.avisos.tiene_permiso()
            puede_avisar = await self.avisos.puede_avisar()
            filtro = desde_texto(await self.avisos.filtro())
            vistos = await self.avisos.vistos()
        except Exception as fallo:  # noqa: BLE001
            self.error = f"La pieza de Android no respondió: {fallo}"
            self._pintar()
            return

        self.error = ""
        self.permiso, self.puede_avisar, self.filtro = permiso, puede_avisar, filtro
        # SIN REPETIDOS Y EN ORDEN: un mensaje llega como varios avisos.
        self.vistos = list(dict.fromkeys(f"{uno.nombre}  ·  {uno.app}" for uno in vistos))[
            :CUANTOS_VISTOS
        ]
        self.campo_desde.value = filtro.desde
        self.campo_hasta.value = filtro.hasta
        self.cargado = True
        self._pintar()

    def _guardar(self, nuevo: FiltroAvisos, aviso: str) -> None:
        self.filtro = nuevo
        self._pintar()
        self.pagina.run_task(self._mandar, nuevo, aviso)

    async def _mandar(self, nuevo: FiltroAvisos, aviso: str) -> None:
        try:
            await self.avisos.guardar_filtro(a_texto(nuevo))
        except Exception as fallo:  # noqa: BLE001
            componentes.avisar(self.pagina, f"No se pudo guardar en el móvil: {fallo}")
            return
        componentes.avisar(self.pagina, aviso)

    def _anadir(self, _=None) -> None:
        try:
            nuevo = con_nombre(self.filtro, self.campo_nombre.value or "")
        except ValueError as fallo:
            componentes.avisar(self.pagina, str(fallo))
            return
        self.campo_nombre.value = ""
        self._guardar(nuevo, "Añadido a la lista.")

    def _quitar(self, nombre: str) -> None:
        self._guardar(sin_nombre(self.filtro, nombre), f"«{nombre}» quitado de la lista.")

    def _activar(self, evento) -> None:
        encendido = bool(evento.control.value)
        self._guardar(
            replace(self.filtro, activo=encendido),
            "Filtro encendido." if encendido else "Filtro apagado: te avisa de todos.",
        )

    def _cambiar_horario(self, _=None) -> None:
        try:
            nuevo = con_horario(
                self.filtro, self.campo_desde.value or "", self.campo_hasta.value or ""
            )
        except ValueError as fallo:
            componentes.avisar(self.pagina, str(fallo))
            return
        self.campo_desde.value, self.campo_hasta.value = nuevo.desde, nuevo.hasta
        # SALIR DE UN CAMPO SIN CAMBIAR NADA NO ES GUARDAR: sin esto, pasar de
        # «Desde» a «Hasta» sacaría «Horario guardado» dos veces.
        if nuevo == self.filtro:
            self._pintar()
            return
        self._guardar(nuevo, "Horario guardado.")

    # ----------------------------------------------------------------------

    def _pintar(self) -> None:
        p = self.paleta
        piezas: list[ft.Control] = [
            componentes.cabecera_tarjeta(
                p, "Avisos importantes", "WhatsApp e Instagram, solo en este móvil"
            )
        ]
        if self.error:
            piezas.append(componentes.aviso_error(p, [self.error]))
            piezas.append(self._boton_comprobar())
        elif not self.cargado:
            piezas.append(self._apoyo("Mirando cómo está el móvil…"))
        else:
            piezas += self._piezas()
        self.cuerpo.controls = piezas
        try:
            self.cuerpo.update()
        except RuntimeError:
            # TODAVÍA NO ESTÁ EN LA PÁGINA: se verá tal cual al ponerla.
            pass

    def _piezas(self) -> list[ft.Control]:
        p = self.paleta
        piezas: list[ft.Control] = [
            self._estado(
                "Acceso a las notificaciones", self.permiso, "Dar acceso", self.avisos.abrir_ajustes
            ),
            self._estado(
                "Permiso para avisarte", self.puede_avisar, "Permitir", self.avisos.abrir_ajustes_avisos
            ),
            self._apoyo(
                "Antes de nada, silencia WhatsApp e Instagram en los Ajustes de Android. "
                "Con el filtro encendido y dentro de su horario, Focus1% te vuelve a avisar "
                "con sonido solo de la gente de esta lista. Fuera del horario, o con el "
                "filtro apagado, te avisa de todos, como siempre."
            ),
            componentes.interruptor(
                p, "Filtro encendido", valor=self.filtro.activo, al_cambiar=self._activar
            ),
            ft.Row([self.campo_desde, self.campo_hasta], spacing=10),
            self._apoyo(
                "Igual en los dos es todo el día. Puede cruzar la medianoche: de 22:00 a 07:00."
            ),
            componentes.aviso(
                p,
                [
                    "El nombre tiene que ser EXACTAMENTE el que sale en el aviso de WhatsApp "
                    "o Instagram: el que tú tienes guardado en tus contactos, no el que la "
                    "persona se puso. Si no coincide, no sonará.",
                    "Si no la tienes guardada, escribe su número tal como sale, por ejemplo "
                    "+34 612 345 678 (los espacios y el prefijo dan igual).",
                    "Para un grupo, el nombre del grupo. En Instagram, el nombre de usuario. "
                    "Las mayúsculas no importan.",
                ],
            ),
            ft.Row(
                [
                    self.campo_nombre,
                    componentes.boton(p, "Añadir", al_pulsar=self._anadir, principal=True),
                ],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        ]

        if self.filtro.nombres:
            piezas += [self._fila_nombre(nombre) for nombre in self.filtro.nombres]
        else:
            piezas.append(
                componentes.aviso_vacio(
                    p, "Nadie en la lista todavía.", icono=ft.Icons.PERSON_ADD_OUTLINED, alto=70
                )
            )

        if self.vistos:
            piezas += [
                self._apoyo("Así llama el móvil a los últimos que te escribieron. Cópialos tal cual:"),
                # SELECCIONABLE para copiar el nombre exacto, con sus tildes y
                # emojis, en vez de escribirlo de memoria y fallar una letra.
                ft.Text("\n".join(self.vistos), size=13, color=p.ink, selectable=True),
            ]

        piezas.append(self._boton_comprobar())
        return piezas

    def _estado(self, texto: str, bien: bool, boton: str, abrir) -> ft.Control:
        p = self.paleta
        fila: list[ft.Control] = [
            ft.Icon(
                ft.Icons.CHECK_CIRCLE_OUTLINE if bien else ft.Icons.ERROR_OUTLINE,
                size=18,
                color=p.positivo if bien else p.negativo,
            ),
            ft.Text(texto, size=13, color=p.ink, expand=True),
        ]
        if not bien:
            fila.append(
                componentes.boton(p, boton, al_pulsar=lambda _: self.pagina.run_task(abrir))
            )
        return ft.Row(fila, spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER)

    def _fila_nombre(self, nombre: str) -> ft.Control:
        return ft.Row(
            [
                ft.Text(nombre, size=14, color=self.paleta.ink, expand=True),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.DELETE_OUTLINE,
                    al_pulsar=lambda _: self._quitar(nombre),
                    ayuda="Quitar de la lista",
                ),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _boton_comprobar(self) -> ft.Control:
        # AL VOLVER DE LOS AJUSTES DE ANDROID la tarjeta no se entera sola de
        # que ya diste el permiso: este botón vuelve a mirar.
        return componentes.boton(
            self.paleta, "Comprobar de nuevo", al_pulsar=self.cargar, icono=ft.Icons.REFRESH
        )

    def _apoyo(self, texto: str) -> ft.Text:
        return ft.Text(texto, size=estilo.TEXTO_APOYO, color=self.paleta.muted)
