"""El marco de la ventana: la barra lateral (PC), la de arriba (celular),
la marca, la campana, el asistente y la versión al pie.

ESTABA DENTRO DE app.py, que pasaba de las mil trescientas líneas; se separó
en la auditoría del 13 nov 2026. Es parte de Ventana, que hereda esta clase.
"""

from __future__ import annotations

import flet as ft

from .. import NOMBRE, __version__
from ..datos import ajustes, rutas
from ..datos.bd import conectado
from ..sello import SELLO
from . import asistente, componentes, dialogo_recordatorios, dibujo_lateral, estilo
from .secciones import SECCIONES


class MarcoDeLaVentana:
    """Las barras y el menú que rodean a la sección."""

    def _barra_de_arriba(self) -> ft.Control:
        """El menú de un móvil: un botón, el nombre de la sección y nada más.

        POR QUÉ ARRIBA Y NO A UN LADO: la barra lateral se lleva 236 puntos de
        los 375 que tiene un móvil. Quedaban 139 para la aplicación entera, que
        no da ni para una tarjeta.

        POR QUÉ UNA VENTANITA Y NO UN CAJÓN LATERAL: Flet trae un cajón hecho,
        pero las ventanitas ya están usadas y probadas en toda la aplicación.
        Con diez secciones y una prueba con amigos por delante, prefiero lo que
        sé que funciona a lo que parece más elegante.
        """
        nombre = SECCIONES[self.seleccionada][0]
        return ft.Container(
            content=ft.Row(
                [
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.MENU,
                        ayuda="Ir a otra sección",
                        al_pulsar=lambda _: self._pedir_seccion(),
                    ),
                    ft.Text(
                        nombre,
                        size=15,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.ink,
                        expand=True,
                    ),
                    self._boton_asistente(),
                    self.sinc.control(self.paleta),
                    self._campana(),
                ],
                spacing=6,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=10, vertical=8),
            bgcolor=self.paleta.surface,
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
        )

    def _pedir_seccion(self) -> None:
        """La lista de secciones, para elegir a dónde ir."""
        self.pagina.show_dialog(
            componentes.dialogo(
                self.paleta,
                "Ir a",
                ft.Column(
                    [
                        *(
                            self._enlace(indice, nombre, icono)
                            for indice, (nombre, icono) in enumerate(SECCIONES)
                        ),
                        # LA VERSION, AQUI, PORQUE EN UN MOVIL NO HAY OTRO
                        # SITIO: vive al pie de la barra lateral, y en un móvil
                        # no hay barra lateral. El usuario preguntó dónde verla
                        # y la respuesta era "en ninguna parte".
                        #
                        # VA EL SELLO Y NO SOLO EL NUMERO: la versión dice
                        # 1.0.0 en todas las compilaciones, así que no sirve
                        # para saber si tienes la de hace un rato o la de ayer.
                        # El sello lleva la fecha y la hora en que se construyó.
                        self._pie(),
                    ],
                    spacing=2,
                    tight=True,
                    width=260,
                    scroll=ft.ScrollMode.AUTO,
                ),
                pagina=self.pagina,
                texto_aceptar="Cerrar",
                al_aceptar=lambda _: self.pagina.pop_dialog(),
            )
        )

    def _boton_asistente(self) -> ft.Control:
        """El asistente en la barra de arriba del MÓVIL, al lado de la
        campana. En la PC va en la barra lateral (ver _entrada_asistente)."""
        return componentes.boton_icono(
            self.paleta,
            ft.Icons.ASSISTANT_OUTLINED,
            ayuda="Asistente",
            al_pulsar=lambda _: self._abrir_asistente(),
        )

    def _entrada_asistente(self) -> ft.Control:
        """El asistente en la barra lateral de la PC: como una entrada más, con
        su texto, porque ahí sobra alto y falta ancho."""
        paleta = self.paleta
        return ft.Container(
            content=ft.Row(
                [
                    ft.Icon(ft.Icons.ASSISTANT_OUTLINED, size=17, color=paleta.muted),
                    ft.Text("Asistente", size=13, color=paleta.ink_soft),
                ],
                spacing=10,
            ),
            padding=ft.Padding.symmetric(horizontal=10, vertical=9),
            border_radius=estilo.RADIO_BOTON,
            on_click=lambda _: self._abrir_asistente(),
            ink=True,
        )

    def _abrir_asistente(self) -> None:
        asistente.abrir(
            self.pagina, self.paleta, self._poner_al_dia_sin_moverse, self.avisos
        )

    def _campana(self) -> ft.Control:
        """La campanita, con lo que pasa al tocarla.

        VA EN LA BARRA DE LA APLICACION Y NO EN LA CABECERA DEL DASHBOARD, y
        merece explicacion porque el usuario dijo "al lado del reloj": el reloj
        solo existe en el Dashboard, y una campana que solo se ve estando ya en
        el Dashboard no recuerda nada. Aqui se ve desde cualquier seccion, que
        es lo que se le pide a un recordatorio.

        AL TOCARLA SE ABRE LA LISTA de lo que tienes pendiente, con su boton de
        anadir. Antes llevaba al Dashboard, y no era lo mismo: te dejaba en la
        pantalla donde estan las tareas, pero teniendo que buscarlas.
        """
        # EN UN HUECO PROPIO, para poder cambiar su número sin tocar nada más
        # (ver _poner_al_dia_sin_moverse). Al guardar un recordatorio ya no se
        # rehace la ventana: antes eso te devolvía al principio de la pantalla.
        self._hueco_campana = ft.Container(content=self._dibujo_campana())
        return self._hueco_campana

    def _dibujo_campana(self) -> ft.Control:
        return componentes.campana(
            self.paleta,
            self.pendientes,
            al_pulsar=lambda _: dialogo_recordatorios.abrir(
                self.pagina, self.paleta, self._poner_al_dia_sin_moverse
            ),
        )

    def _lateral(self) -> ft.Control:
        # EL ASISTENTE VA DEBAJO DE LA MARCA, EN SU PROPIA ENTRADA, y no al
        # lado de la nube y la campana: la barra mide 236 puntos y con un
        # tercer botón al nombre «Focus1%» no le quedaba sitio y se escribía
        # letra por letra, de arriba abajo. Lo vio el usuario en una captura.
        piezas: list[ft.Control] = [
            self._marca(), ft.Container(height=6), self._entrada_asistente(),
        ]
        piezas += [
            self._enlace(indice, nombre, icono)
            for indice, (nombre, icono) in enumerate(SECCIONES)
        ]
        piezas += [self._hueco(), self._pie()]

        return ft.Container(
            content=ft.Column(piezas, spacing=2, expand=True),
            width=estilo.ANCHO_LATERAL,
            padding=ft.Padding.symmetric(horizontal=10, vertical=12),
            bgcolor=self.paleta.surface,
            border=ft.Border.only(right=ft.BorderSide(1, self.paleta.borde)),
        )

    def _marca(self) -> ft.Control:
        paleta = self.paleta
        with conectado() as conexion:
            nombre = ajustes.leer(conexion, ajustes.CLAVE_NOMBRE)

        return ft.Container(
            content=ft.Row(
                [
                    ft.Container(
                        content=ft.Text(
                            "F",
                            size=14,
                            weight=ft.FontWeight.BOLD,
                            color=paleta.acento_ink,
                        ),
                        width=30,
                        height=30,
                        bgcolor=paleta.acento,
                        border_radius=estilo.RADIO_BOTON,
                        alignment=ft.Alignment.CENTER,
                    ),
                    # EN UNA SOLA LÍNEA SIEMPRE. Si no cabe, termina en «…»;
                    # sin esto, un nombre apretado se escribía letra por letra,
                    # de arriba abajo (lo vio el usuario en una captura).
                    ft.Column(
                        [
                            ft.Text(
                                NOMBRE,
                                size=13,
                                weight=ft.FontWeight.W_600,
                                color=paleta.ink,
                                max_lines=1,
                                overflow=ft.TextOverflow.ELLIPSIS,
                            ),
                            # Si has puesto tu nombre, aquí sale; si no, la
                            # aplicación no se inventa nada.
                            ft.Text(
                                nombre or "Centro personal", size=10, color=paleta.muted,
                                max_lines=1,
                                overflow=ft.TextOverflow.ELLIPSIS,
                            ),
                        ],
                        spacing=0,
                        tight=True,
                        expand=True,
                    ),
                    # LA CAMPANA, ARRIBA DEL TODO Y EN TODAS LAS SECCIONES.
                    self.sinc.control(self.paleta),
                    self._campana(),
                ],
                # CUATRO Y NO NUEVE: medido con la fuente de verdad, «Focus1%»
                # pide unos 55 puntos, y con la campana con su número al lado
                # le quedaban 47. Con este hueco le quedan 62.
                spacing=4,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=6, vertical=8),
        )

    def _enlace(self, indice: int, nombre: str, icono: str) -> ft.Control:
        """Una entrada de la barra lateral. La elegida se marca con el acento."""
        paleta = self.paleta
        elegida = indice == self.seleccionada
        return ft.Container(
            content=ft.Row(
                [
                    ft.Icon(
                        icono, size=17, color=paleta.acento if elegida else paleta.muted
                    ),
                    ft.Text(
                        nombre,
                        size=13,
                        weight=ft.FontWeight.W_500 if elegida else ft.FontWeight.NORMAL,
                        color=paleta.acento if elegida else paleta.ink_soft,
                    ),
                ],
                spacing=10,
            ),
            padding=ft.Padding.symmetric(horizontal=10, vertical=9),
            bgcolor=paleta.acento_suave if elegida else None,
            border_radius=estilo.RADIO_BOTON,
            on_click=lambda _, i=indice: self._seleccionar(i),
            ink=True,
        )

    def _hueco(self) -> ft.Control:
        """El espacio entre los enlaces y la versión, con el dibujo del tema.

        SIGUE SIENDO EL MISMO HUECO QUE EMPUJA LA VERSIÓN ABAJO: el dibujo va
        centrado dentro, no ocupa un sitio fijo. Y SE RECORTA si la ventana es
        muy baja, en vez de empujar la versión fuera de la pantalla: la versión
        es un dato, el dibujo es adorno.
        """
        return ft.Container(
            content=dibujo_lateral.dibujar(self.paleta),
            expand=True,
            alignment=ft.Alignment.CENTER,
            clip_behavior=ft.ClipBehavior.HARD_EDGE,
        )

    def _pie(self) -> ft.Control:
        """Versión y esquema. No es adorno: cuando algo va raro, lo primero que
        hay que saber es qué archivo está usando la aplicación (va en el aviso
        emergente, para no ocupar sitio)."""
        return ft.Container(
            content=ft.Text(
                f"v{__version__} · {SELLO} · esquema {self.esquema}",
                size=10,
                color=self.paleta.muted,
            ),
            padding=ft.Padding.symmetric(horizontal=10, vertical=6),
            tooltip=str(rutas.ruta_bd()),
        )
