"""Entrenar: la pantalla que se abre encima de todo al pulsar «Empezar».

LO PIDIÓ EL USUARIO: quitar la pestaña «Hoy» del gimnasio —«eso ya se ve en el
dashboard»— y poner en su lugar un botón de empezar que arranque un cronómetro.

NO ES UNA PESTAÑA, ES UNA PANTALLA ENTERA: entrenar no es «mirar una sección
más» del gimnasio, es lo único que estás haciendo durante una hora.

EL ENTRENO VIVE EN MEMORIA MIENTRAS ESTÁS EN ESTA PANTALLA (`self.sesion`), y
cada cambio hace TRES cosas pequeñas: cambia la memoria, guarda SOLO su fila
(datos/repositorio_entreno.py) y repinta SOLO lo que cambió (una tarjeta, la
cabecera). Antes cada número releía todo de la base, reescribía el entreno
entero y redibujaba todas las tarjetas: era lento, perdía el foco del teclado y
—lo peor— los botones guardaban una copia vieja del ejercicio y pisaban lo que
acababas de escribir (el 8 que volvía a 10).

EL CRONÓMETRO NO SE CUENTA AQUÍ. La pantalla le pregunta a la sesión cuánto
lleva (`Sesion.duracion`), que es una resta de horas: cerrar la aplicación a
mitad del entreno no pierde nada.
"""

from __future__ import annotations

import asyncio
from dataclasses import replace
from datetime import date, datetime

import flet as ft

from ..datos import repositorio_ejercicios, repositorio_entreno, repositorio_gimnasio
from ..datos.bd import conectado
from ..dominio.descanso import parsear_descanso, parsear_duracion, texto_descanso, texto_duracion
from ..dominio.ejercicio import DESCANSO_POR_OMISION, Medida, Unidad
from ..dominio.rutina import EjercicioPlaneado, dia_de, parsear_peso
from ..dominio.semana import texto_dia
from ..dominio.sesion import (
    EjercicioDeSesion,
    Marca,
    Sesion,
    anadir_serie,
    con_serie,
    en_unidad,
    mover,
    ordenados,
    quitar_serie,
    records,
    series_para_anadir,
    sin_ejercicio,
    texto_volumen,
)
from . import componentes, estilo
from .entreno_tarjeta import METROS, PESO, REPS, TIEMPO, kilos, tarjeta
from .estilo import Paleta
from .franja_descanso import FranjaDescanso


def texto_reloj(segundos: int) -> str:
    """El cronómetro, siempre en h:mm:ss.

    LAS TRES CIFRAS SIEMPRE, aunque no haya horas todavía. Antes se escondían
    mientras valieran cero, y el usuario leyó «00:00» como horas y minutos.
    """
    segundos = max(0, int(segundos))
    horas, resto = divmod(segundos, 3600)
    minutos, segundos = divmod(resto, 60)
    return f"{horas}:{minutos:02d}:{segundos:02d}"


class PantallaEntreno:
    """El entreno en marcha: el reloj arriba y una tarjeta por ejercicio.

    NO HEREDA DE `Pantalla` a propósito: las demás se montan DENTRO del armazón
    de la ventana, con su menú y su barra. Ésta lo sustituye entero.
    """

    def __init__(
        self,
        pagina: ft.Page,
        paleta: Paleta,
        dia: date,
        al_salir,
        al_repintar,
        al_terminar,
        franja: FranjaDescanso | None = None,
        bloque: str | None = None,
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.dia = dia
        self.bloque = bloque
        """Qué entreno del día (su bloque). None = «el» del día: ver
        repositorio_gimnasio.sesion_de."""
        # DOS AVISOS DISTINTOS: repintar deja la pantalla donde está, y salir
        # devuelve a la aplicación. Los dos los hace la ventana.
        self.al_salir = al_salir
        self.al_repintar = al_repintar
        # TERMINAR NO ES SALIR: lleva al resumen del día, que es otra pantalla.
        self.al_terminar = al_terminar
        self.franja = franja

        self.sesion: Sesion | None = None
        """El entreno, en memoria. Ver la cabecera del archivo."""
        self.ejercicios = []
        """La biblioteca: de ahí salen la medida (peso o tiempo) y el descanso."""
        self.anteriores: dict[int, EjercicioDeSesion] = {}
        """Lo de la vez anterior de cada ejercicio, para la columna gris."""
        self.plan: dict[int, EjercicioPlaneado] = {}
        """Lo que dice la rutina de hoy de cada ejercicio, para «Plan: …»."""
        self._previas: dict[int, Marca | None] = {}
        """La mejor marca de antes de hoy de cada ejercicio: la de la medalla."""

        # EL RELOJ ES UN CONTROL QUE VIVE: cada segundo se le cambia el texto A
        # ÉL, sin repintar la pantalla, que borraría lo que estás escribiendo.
        self.reloj = ft.Text(
            texto_reloj(0),
            size=estilo.CIFRA_GRANDE,
            color=paleta.acento,
            font_family=paleta.titular,
        )
        self._lista: ft.Column | None = None
        """La lista con desplazamiento que está en pantalla."""
        self._cabecera_hueco = ft.Container()
        self._huecos: dict[int, ft.Container] = {}
        """Una caja por ejercicio (por su «orden»): repintar uno es cambiar lo
        de dentro de SU caja, sin tocar las demás ni mover la pantalla."""
        self._abiertos: set[int] = set()
        """Los ejercicios terminados que volviste a abrir (por su «orden»). Los
        demás terminados se ven plegados: nombre y ✅, como pidió el usuario."""
        self._vivo = True
        self._latiendo = False

    # ------------------------------------------------------------ leer y pintar

    def _cargar(self) -> bool:
        """Lee el entreno y lo que lo acompaña. Devuelve si hay entreno.

        SE LEE AL ABRIR, y no en cada cambio: los cambios ya están en memoria.
        """
        with conectado() as conexion:
            self.sesion = repositorio_gimnasio.sesion_de(conexion, self.dia, self.bloque)
            self.ejercicios = repositorio_ejercicios.listar(conexion)
            rutina = repositorio_gimnasio.leer_rutina(conexion)
            if self.sesion is not None:
                self._en_su_unidad(conexion)
                self.anteriores = self._leer_anteriores(conexion, self.sesion.ejercicios)
                self._previas = {
                    uno.ejercicio_id: self._marca_antes(conexion, uno)
                    for uno in self.sesion.ejercicios if uno.ejercicio_id is not None
                }
        self.plan = {uno.ejercicio_id: uno for uno in dia_de(self.dia, rutina).ejercicios}
        return self.sesion is not None

    def _en_su_unidad(self, conexion) -> None:
        """Deja cada ejercicio de peso en la unidad de su ficha (ver
        dominio/sesion.en_unidad). Se guardan SOLO las series que cambian, y
        casi siempre no cambia ninguna."""
        cambiados = []
        for uno in self.sesion.ejercicios:
            unidad = self._unidad_de(uno)
            if unidad is None:
                continue
            series = tuple(en_unidad(una, unidad) for una in uno.series)
            if series == uno.series:
                continue
            for una in series:
                repositorio_entreno.actualizar_serie(conexion, una)
            cambiados.append(replace(uno, series=series))
        if cambiados:
            self._poner(*cambiados)

    def _marca_antes(self, conexion, ejercicio: EjercicioDeSesion) -> Marca | None:
        return repositorio_gimnasio.marca_antes(
            conexion, ejercicio.ejercicio_id, self.dia, self._unidad_de(ejercicio) or Unidad.REPS
        )

    def _leer_anteriores(self, conexion, ejercicios) -> dict[int, EjercicioDeSesion]:
        anteriores = {}
        for uno in ejercicios:
            if uno.ejercicio_id is None:
                continue
            vieja = repositorio_gimnasio.ultima_vez(conexion, uno.ejercicio_id, self.dia)
            if vieja is not None:
                anteriores[uno.ejercicio_id] = vieja
        return anteriores

    def control(self, paleta: Paleta) -> ft.Control:
        """La pantalla entera, la primera vez. Después se repinta por dentro."""
        self.paleta = paleta
        if not self._cargar():
            # NO DEBERÍA PASAR: aquí se llega después de crear la sesión. Pero
            # si la borras desde otro sitio, mejor una salida que una pantalla
            # en blanco sin explicación.
            self._lista = None
            return self._nada_que_entrenar()
        self._lista = ft.Column(
            self._piezas(), spacing=estilo.DENSIDAD, scroll=ft.ScrollMode.AUTO, expand=True
        )
        return ft.Container(
            content=self._lista,
            padding=estilo.RELLENO_TARJETA,
            expand=True,
            bgcolor=paleta.canvas,
        )

    def _piezas(self) -> list[ft.Control]:
        """Todo lo que se ve, armado DESDE LA MEMORIA (sin leer la base)."""
        self._cabecera_hueco.content = self._cabecera()
        lista = ordenados(self.sesion)
        self._huecos = {}
        for indice, uno in enumerate(lista):
            hueco = ft.Container(
                content=self._tarjeta(uno, primero=indice == 0, ultimo=indice == len(lista) - 1)
            )
            self._huecos[uno.orden] = hueco
        return [self._cabecera_hueco, *self._huecos.values(), self._pie()]

    def _tarjeta(self, ejercicio: EjercicioDeSesion, *, primero: bool, ultimo: bool) -> ft.Control:
        return tarjeta(
            self, ejercicio,
            self.anteriores.get(ejercicio.ejercicio_id),
            self.plan.get(ejercicio.ejercicio_id),
            primero=primero, ultimo=ultimo,
        )

    def refrescar(self) -> None:
        """Vuelve a leer de la base y repinta, DENTRO DE LA LISTA QUE YA ESTÁ.

        YA NO SE LLAMA EN CADA CAMBIO (para eso están los repintados chicos de
        abajo): solo cuando la ventana lo pide, por ejemplo al llegar datos de
        otro aparato. Repintar en la misma lista no te sube arriba de la pantalla.
        """
        if self._lista is None or not self._cargar():
            self.al_repintar()
            return
        self._repintar_todo()

    def _repintar_todo(self) -> None:
        """Toda la lista, desde la memoria. Para lo que cambia el orden o la cantidad
        de ejercicios (añadir, quitar, mover, cambiar uno por otro)."""
        self._lista.controls = self._piezas()
        self._actualizar(self._lista)

    def _repintar_ejercicio(self, orden: int) -> None:
        """SOLO la tarjeta de ese ejercicio, y la cabecera (series y volumen)."""
        hueco = self._huecos.get(orden)
        lista = ordenados(self.sesion)
        ejercicio = next((uno for uno in lista if uno.orden == orden), None)
        if hueco is None or ejercicio is None:
            self._repintar_todo()
            return
        indice = lista.index(ejercicio)
        hueco.content = self._tarjeta(
            ejercicio, primero=indice == 0, ultimo=indice == len(lista) - 1
        )
        self._actualizar(hueco)
        self._repintar_cabecera()

    def _repintar_cabecera(self) -> None:
        self._cabecera_hueco.content = self._cabecera()
        self._actualizar(self._cabecera_hueco)

    def _actualizar(self, control: ft.Control) -> None:
        try:
            control.update()
        except Exception:  # noqa: BLE001
            # Todavía no está en la página: se verá al montarse.
            pass

    # ------------------------------------------------------------------

    def _cabecera(self) -> ft.Control:
        """La barra de arriba de la captura: salir, el reloj y «Terminar».

        LA FORMA LA PIDIÓ EL USUARIO CON UNA CAPTURA de otra aplicación. EL
        RELOJ VA ARRIBA Y EN EL COLOR DEL TEMA: es lo único que cambia solo.
        «Descartar», que casi no se usa y no tiene vuelta atrás, va en el «⋮».
        Debajo, el nombre del entreno y las cifras, en chico: son para consultar.
        """
        sesion = self.sesion
        paleta = self.paleta
        self.reloj.size = 20
        # LA FLECHA «←» SALE SIN TERMINAR (4 nov 2026). Antes no estaba: el
        # usuario había elegido que solo se saliera terminando o descartando, y
        # lo cambió —«debo poder salir para usar la app, pero el entreno no se
        # pierde»—. Las series ya están guardadas tecla a tecla, el reloj se
        # calcula desde la hora de inicio y el descanso vive en la ventana, así
        # que salir no para nada: abajo queda la franja «Entrenando · Volver».
        barra = ft.Row(
            [
                ft.IconButton(
                    icon=ft.Icons.ARROW_BACK, icon_color=paleta.ink,
                    tooltip="Salir sin terminar: el entreno sigue",
                    on_click=lambda _: self.al_salir(),
                ),
                self._reloj_al_dia(sesion),
                ft.Container(expand=True),
                ft.PopupMenuButton(
                    icon=ft.Icons.MORE_VERT, icon_color=paleta.ink, tooltip="Más",
                    items=[ft.PopupMenuItem(
                        "Descartar entreno", icon=ft.Icons.DELETE_OUTLINE,
                        on_click=lambda _: self._descartar(),
                    )],
                ),
                componentes.boton(
                    paleta, "Terminar", principal=True, al_pulsar=lambda _: self._terminar(),
                ),
            ],
            spacing=4,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )
        cifras = (
            f"{texto_dia(self.dia)} · {sesion.series_hechas} series · "
            f"{texto_volumen(sesion.volumen)}"
        )
        return ft.Column(
            [
                barra,
                ft.Text(
                    sesion.titulo() or texto_dia(self.dia),
                    # EN GRANDE, como siempre: se mira desde el suelo (lo vigila
                    # probar_interfaz). La captura no lo cambia.
                    size=estilo.TITULAR_GRANDE,
                    weight=ft.FontWeight.W_600,
                    color=paleta.ink,
                    font_family=paleta.titular,
                    max_lines=2,
                    overflow=ft.TextOverflow.ELLIPSIS,
                ),
                ft.Text(cifras, size=estilo.TEXTO_APOYO, color=paleta.muted),
                ft.Divider(height=1, color=paleta.borde),
            ],
            spacing=4,
            tight=True,
        )

    def _pie(self) -> ft.Control:
        return ft.Row([
            componentes.boton(
                self.paleta, "Añadir ejercicio", icono=ft.Icons.ADD,
                al_pulsar=lambda _: self._elegir_ejercicio(self._anadir_a_la_sesion),
            ),
        ])

    def _nada_que_entrenar(self) -> ft.Control:
        return ft.Container(
            content=ft.Column(
                [
                    componentes.aviso_vacio(self.paleta, "Este entreno ya no existe."),
                    componentes.boton(
                        self.paleta, "Volver", icono=ft.Icons.ARROW_BACK,
                        al_pulsar=lambda _: self.al_salir(),
                    ),
                ],
                spacing=14,
                tight=True,
            ),
            padding=estilo.RELLENO_TARJETA,
            alignment=ft.Alignment.CENTER,
            expand=True,
            bgcolor=self.paleta.canvas,
        )

    # ------------------------------------------------------------ el reloj

    def _reloj_al_dia(self, sesion: Sesion) -> ft.Control:
        """El mismo control de siempre, con la hora de ahora y el color de ahora."""
        self.reloj.value = texto_reloj(sesion.duracion(datetime.now()))
        # EL COLOR Y LA FUENTE SE VUELVEN A PONER EN CADA PINTADO porque el
        # control sobrevive a los cambios de tema, y la paleta no.
        self.reloj.color = self.paleta.acento
        self.reloj.font_family = self.paleta.titular
        return self.reloj

    def empezar_a_latir(self) -> None:
        """Arranca la cuenta. Con la guarda de `_latiendo`, para que cada
        repintado no suelte otra cuenta y el reloj salte de dos en dos."""
        if self._latiendo:
            return
        self._latiendo = True
        self.pagina.run_task(self._latir)

    async def _latir(self) -> None:
        while self._vivo:
            await asyncio.sleep(1)
            if not self._vivo:
                return
            try:
                self._un_segundo()
            except Exception:  # noqa: BLE001
                self._latiendo = False
                return

    def _un_segundo(self) -> None:
        """Cambia el texto del reloj, y NADA más. Terminado, no se toca."""
        sesion = self.sesion
        if sesion is None or sesion.segundos or sesion.empezada_en is None:
            return
        nuevo = texto_reloj(sesion.duracion(datetime.now()))
        if nuevo == self.reloj.value:
            return
        self.reloj.value = nuevo
        self._actualizar(self.reloj)

    def parar(self) -> None:
        """Se acabó el latido. Lo llama la ventana al salir de entrenar."""
        self._vivo = False
        self._latiendo = False

    # ------------------------------------------------------------ buscar

    def _ejercicio(self, orden: int) -> EjercicioDeSesion | None:
        """El ejercicio TAL COMO ESTÁ AHORA en memoria. Nunca una copia vieja."""
        return next((uno for uno in self.sesion.ejercicios if uno.orden == orden), None)

    def _poner(self, *cambiados: EjercicioDeSesion) -> None:
        """Mete en la memoria los ejercicios cambiados, por su id."""
        por_id = {uno.id: uno for uno in cambiados}
        self.sesion = replace(
            self.sesion,
            ejercicios=tuple(por_id.get(uno.id, uno) for uno in self.sesion.ejercicios),
        )

    def ficha_de(self, ejercicio: EjercicioDeSesion):
        """La ficha de la biblioteca, o None si ese ejercicio ya no está en ella."""
        return next((uno for uno in self.ejercicios if uno.id == ejercicio.ejercicio_id), None)

    def _es_de_tiempo(self, ejercicio: EjercicioDeSesion) -> bool:
        """Si se mide en tiempo, según su ficha. Uno borrado de la biblioteca se
        trata como de peso, que es lo que era la mayoría."""
        ficha = self.ficha_de(ejercicio)
        return ficha is not None and ficha.medida is Medida.TIEMPO

    def _unidad_de(self, ejercicio: EjercicioDeSesion) -> Unidad | None:
        """Reps, segundos o metros al lado de los kilos, según su ficha.

        None SI NO HAY QUÉ ELEGIR: uno de tiempo (una sola casilla) o uno
        borrado de la biblioteca (sin ficha donde recordarlo).
        """
        ficha = self.ficha_de(ejercicio)
        if ficha is None or ficha.medida is Medida.TIEMPO:
            return None
        return ficha.unidad

    def _descanso_de(self, ejercicio: EjercicioDeSesion) -> int:
        """Los segundos de descanso: el del entreno, si no el de la ficha, si no
        el de por omisión. Un cero en el entreno es un cero elegido (el cardio)."""
        if ejercicio.descanso is not None:
            return ejercicio.descanso
        ficha = self.ficha_de(ejercicio)
        return ficha.descanso if ficha is not None else DESCANSO_POR_OMISION

    def records_de(self, ejercicio: EjercicioDeSesion) -> dict[int, Marca]:
        """Las series de hoy con medalla (ver dominio/sesion.records).

        LA MARCA DE ANTES SE LEE UNA VEZ por ejercicio: la de los que había se
        lee al abrir, y la de uno añadido, la primera vez que se pinta.
        """
        if ejercicio.ejercicio_id is None:
            return {}
        if ejercicio.ejercicio_id not in self._previas:
            with conectado() as conexion:
                self._previas[ejercicio.ejercicio_id] = self._marca_antes(conexion, ejercicio)
        return records(ejercicio, self._previas[ejercicio.ejercicio_id], self.dia)

    def plegado(self, ejercicio: EjercicioDeSesion) -> bool:
        """Terminado y sin volver a abrir: se ve como una línea con ✅."""
        return ejercicio.esta_completo and ejercicio.orden not in self._abiertos

    def _abrir(self, orden: int) -> None:
        """Vuelve a abrir uno terminado, para corregir algo."""
        self._abiertos.add(orden)
        self._repintar_ejercicio(orden)

    # ------------------------------------------------------------ las casillas

    def _leer(self, que: str, texto: str):
        """Lo escrito en una casilla, o None si todavía no se entiende."""
        texto = (texto or "").strip()
        if que == PESO:
            return parsear_peso(texto)
        if que in (REPS, METROS):
            return int(texto) if texto.isdigit() else None
        return parsear_duracion(texto) if texto else 0

    def _al_escribir(self, orden: int, numero: int, que: str, campo) -> None:
        """Mientras escribís: si lo escrito ya se entiende, queda guardado.

        NO SE REPINTA NADA: la casilla ya muestra lo que escribiste, y repintar
        te sacaría el teclado. Si es una serie marcada, cambia el volumen: se
        repinta solo la cabecera. A medio escribir («62,») no se toca nada.
        """
        valor = self._leer(que, campo.value)
        ejercicio = self._ejercicio(orden)
        serie = ejercicio.serie(numero) if ejercicio else None
        if valor is None or serie is None:
            return
        campos = {PESO: "peso", REPS: "repeticiones", TIEMPO: "segundos", METROS: "metros"}[que]
        if getattr(serie, campos) == valor:
            return
        try:
            nueva = replace(serie, **{campos: valor})
        except ValueError:
            return  # fuera de rango (2.000 reps): se corrige al salir
        with conectado() as conexion:
            repositorio_entreno.actualizar_serie(conexion, nueva)
        self._poner(con_serie(ejercicio, numero, **{campos: valor}))
        if nueva.hecha:
            self._repintar_cabecera()

    def _al_dejar(self, orden: int, numero: int, que: str, campo) -> None:
        """Al salir de la casilla (o «Listo»): si quedó algo que no se entiende,
        vuelve a lo que hay guardado y se dice por qué. NO SE ADIVINA."""
        self._al_escribir(orden, numero, que, campo)
        ejercicio = self._ejercicio(orden)
        serie = ejercicio.serie(numero) if ejercicio else None
        if serie is None:
            return
        # SI LO ESCRITO YA ES LO GUARDADO, está bien. Si no, es que no se
        # entendió o se pasó de rango (y _al_escribir no lo guardó).
        guardado = {PESO: serie.peso, REPS: serie.repeticiones, TIEMPO: serie.segundos,
                    METROS: serie.metros}[que]
        if self._leer(que, campo.value) == guardado:
            return
        campo.value = {PESO: kilos(serie.peso), REPS: str(serie.repeticiones),
                       TIEMPO: texto_duracion(serie.segundos), METROS: str(serie.metros)}[que]
        self._actualizar(campo)
        componentes.avisar(self.pagina, {
            PESO: "El peso no se entiende. Ejemplo: 62,5",
            REPS: "Las repeticiones son un número entero.",
            TIEMPO: "No he entendido esa duración. Vale 30min, 30:00, 45s o 1h30.",
            METROS: "Los metros son un número entero, hasta 100000.",
        }[que])

    def _al_dejar_descanso(self, orden: int, campo) -> None:
        """El descanso de este ejercicio, cambiable en mitad del entreno: hay días
        que llegás cansado y necesitás dos minutos donde el plan dice noventa."""
        ejercicio = self._ejercicio(orden)
        if ejercicio is None:
            return
        segundos = parsear_descanso(campo.value or "")
        if segundos is None:
            campo.value = texto_descanso(self._descanso_de(ejercicio))
            self._actualizar(campo)
            componentes.avisar(
                self.pagina,
                "No he entendido ese descanso. Vale 90, 1:30, 1.30, 1.3, 1m30 o 30s.",
            )
            return
        if segundos == ejercicio.descanso:
            return
        nuevo = replace(ejercicio, descanso=segundos)
        with conectado() as conexion:
            repositorio_entreno.actualizar_ejercicio(conexion, nuevo)
        self._poner(nuevo)

    # ------------------------------------------------------------ las series

    def _marcar(self, orden: int, numero: int) -> None:
        """Marca o desmarca una serie. Al marcarla arranca el descanso SOLO.

        Al DESmarcar no se toca el cronómetro: quitar una marca es corregir un
        error, no acabar una serie.
        """
        ejercicio = self._ejercicio(orden)
        serie = ejercicio.serie(numero) if ejercicio else None
        if serie is None:
            return
        nueva = replace(serie, hecha=not serie.hecha)
        with conectado() as conexion:
            repositorio_entreno.actualizar_serie(conexion, nueva)
        antes = self.records_de(ejercicio)
        self._poner(con_serie(ejercicio, numero, hecha=nueva.hecha))
        superada = self.records_de(self._ejercicio(orden)).get(numero)
        if nueva.hecha and superada is not None and numero not in antes:
            componentes.avisar(
                self.pagina,
                f"Nuevo récord en {ejercicio.nombre}: {nueva.texto()} (antes {superada.texto()})",
            )
        if self._ejercicio(orden).esta_completo:
            # LA ÚLTIMA SERIE LO PLIEGA, aunque lo hubieras abierto antes:
            # terminarlo es el momento en que se pidió que se achique.
            self._abiertos.discard(orden)
        self._repintar_ejercicio(orden)
        if nueva.hecha and self.franja is not None:
            self.franja.arrancar(self._descanso_de(ejercicio), ejercicio=ejercicio.nombre, serie=numero)

    def _guardar_nota(self, orden: int, texto: str) -> None:
        """La nota de este ejercicio. Se verá la próxima vez que lo hagas."""
        ejercicio = self._ejercicio(orden)
        if ejercicio is None:
            return
        try:
            nuevo = replace(ejercicio, nota=texto)
        except ValueError as fallo:
            componentes.avisar(self.pagina, str(fallo))
            return
        with conectado() as conexion:
            repositorio_entreno.actualizar_ejercicio(conexion, nuevo)
        self._poner(nuevo)
        self._repintar_ejercicio(orden)

    def _poner_tipo(self, orden: int, numero: int, tipo) -> None:
        """El tipo elegido en el menú del número (normal, fallo, drop set...)."""
        ejercicio = self._ejercicio(orden)
        serie = ejercicio.serie(numero) if ejercicio else None
        if serie is None or serie.tipo is tipo:
            return
        nueva = replace(serie, tipo=tipo)
        with conectado() as conexion:
            repositorio_entreno.actualizar_serie(conexion, nueva)
        self._poner(con_serie(ejercicio, numero, tipo=nueva.tipo))
        self._repintar_ejercicio(orden)

    def _poner_unidad(self, orden: int, unidad: Unidad) -> None:
        """Reps, segundos o metros, elegido tocando el rótulo de la columna.

        LO PIDIÓ EL USUARIO, y que SE RECUERDE: se guarda en la ficha del
        ejercicio, así la próxima vez ya sale en metros. Las series de HOY de
        ese ejercicio pasan a la unidad nueva con su cantidad a cero (los kilos
        se quedan): 10 repeticiones no son 10 metros, y dejarlas escondidas
        seguiría sumando volumen. Los entrenos de otros días no se tocan.
        """
        ejercicio = self._ejercicio(orden)
        ficha = self.ficha_de(ejercicio) if ejercicio else None
        if ficha is None or ficha.unidad is unidad:
            return
        series = tuple(en_unidad(una, unidad) for una in ejercicio.series)
        with conectado() as conexion:
            repositorio_ejercicios.poner_unidad(conexion, ficha.id, unidad)
            for una in series:
                repositorio_entreno.actualizar_serie(conexion, una)
            nueva_ficha = replace(ficha, unidad=unidad)
            self.ejercicios = [nueva_ficha if uno.id == ficha.id else uno for uno in self.ejercicios]
            # LA MEDALLA SE MIDE EN LA UNIDAD NUEVA: se vuelve a leer la marca.
            nuevo = replace(ejercicio, series=series)
            self._previas[ejercicio.ejercicio_id] = self._marca_antes(conexion, nuevo)
        self._poner(nuevo)
        self._repintar_ejercicio(orden)

    def _anadir_serie(self, orden: int) -> None:
        """Una serie más, copiando la última (casi siempre es «otra igual»)."""
        ejercicio = self._ejercicio(orden)
        if ejercicio is None:
            return
        con_otra = anadir_serie(ejercicio)
        if len(con_otra.series) == len(ejercicio.series):
            return  # ya está en el máximo de series
        with conectado() as conexion:
            nueva = repositorio_entreno.anadir_serie(conexion, ejercicio.id, con_otra.series[-1])
        self._poner(replace(ejercicio, series=(*ejercicio.series, nueva)))
        self._repintar_ejercicio(orden)

    def _quitar_serie(self, orden: int, numero: int) -> None:
        ejercicio = self._ejercicio(orden)
        if ejercicio is None or ejercicio.serie(numero) is None:
            return
        with conectado() as conexion:
            repositorio_entreno.quitar_serie(conexion, ejercicio.id, numero)
        self._poner(quitar_serie(ejercicio, numero))
        self._repintar_ejercicio(orden)

    # ------------------------------------------------------------ los ejercicios

    def _quitar_ejercicio(self, orden: int) -> None:
        """Sin preguntar, como pidió el usuario: ver dominio/sesion.sin_ejercicio."""
        ejercicio = self._ejercicio(orden)
        if ejercicio is None:
            return
        with conectado() as conexion:
            repositorio_entreno.quitar_ejercicio(conexion, ejercicio.id)
        self.sesion = sin_ejercicio(self.sesion, orden)
        self._repintar_todo()

    def _mover(self, orden: int, hacia: int) -> None:
        """Sube (-1) o baja (+1) un ejercicio: se guardan las DOS filas que cambian."""
        cambiados = mover(self.sesion, orden, hacia)
        if not cambiados:
            return
        with conectado() as conexion:
            for uno in cambiados:
                repositorio_entreno.actualizar_ejercicio(conexion, uno)
        self._poner(*cambiados)
        self._repintar_todo()

    def _elegir_ejercicio(self, al_elegir) -> None:
        from . import dialogo_anadir_ejercicio

        dialogo_anadir_ejercicio.abrir(self.pagina, self.paleta, al_elegir)

    def _series_de(self, conexion, id_ejercicio: int):
        """Las de la última vez, EN LA UNIDAD DE HOY (ver dominio/sesion.en_unidad)."""
        reales = repositorio_entreno.ultimas_reales(conexion, [id_ejercicio], self.dia)
        series = series_para_anadir(reales.get(id_ejercicio))
        ficha = next((uno for uno in self.ejercicios if uno.id == id_ejercicio), None)
        if ficha is None or ficha.medida is Medida.TIEMPO:
            return series
        return tuple(en_unidad(una, ficha.unidad) for una in series)

    def _anadir_a_la_sesion(self, elegido) -> None:
        """Al final, con las series de la última vez que lo hiciste."""
        orden = max((uno.orden for uno in self.sesion.ejercicios), default=-1) + 1
        with conectado() as conexion:
            nuevo = repositorio_entreno.anadir_ejercicio(conexion, self.sesion.id, EjercicioDeSesion(
                ejercicio_id=elegido.id, nombre=elegido.nombre, orden=orden,
                series=self._series_de(conexion, elegido.id),
                nota=repositorio_entreno.ultima_nota(conexion, elegido.id, self.dia),
            ))
            self.anteriores.update(self._leer_anteriores(conexion, [nuevo]))
        self.sesion = replace(self.sesion, ejercicios=(*self.sesion.ejercicios, nuevo))
        self._repintar_todo()

    def _sustituir(self, orden: int) -> None:
        """Cambiar un ejercicio por otro de la biblioteca, en el mismo sitio."""
        self._elegir_ejercicio(lambda elegido: self._sustituir_por(orden, elegido))

    def _sustituir_por(self, orden: int, elegido) -> None:
        """LO HECHO NO SE PIERDE: si ya marcaste series, se pregunta qué hacer
        con ellas. Sin nada marcado, el nuevo entra con SUS valores de la última
        vez (o los del viejo, si nunca lo hiciste)."""
        viejo = self._ejercicio(orden)
        if viejo is None or elegido.id == viejo.ejercicio_id:
            return
        if not viejo.hechas:
            with conectado() as conexion:
                series = (
                    self._series_de(conexion, elegido.id)
                    if repositorio_entreno.ultimas_reales(conexion, [elegido.id], self.dia)
                    else tuple(replace(una, id=None, hecha=False) for una in viejo.series)
                )
                repositorio_entreno.quitar_ejercicio(conexion, viejo.id)
                nuevo = repositorio_entreno.anadir_ejercicio(
                    conexion, self.sesion.id,
                    EjercicioDeSesion(ejercicio_id=elegido.id, nombre=elegido.nombre,
                                      orden=orden, series=series,
                                      nota=repositorio_entreno.ultima_nota(conexion, elegido.id, self.dia)),
                )
                self.anteriores.update(self._leer_anteriores(conexion, [nuevo]))
            self.sesion = replace(self.sesion, ejercicios=tuple(
                nuevo if uno.orden == orden else uno for uno in self.sesion.ejercicios
            ))
            self._repintar_todo()
            return
        self._preguntar_que_hacer_con_lo_hecho(viejo, elegido)

    def _preguntar_que_hacer_con_lo_hecho(self, viejo: EjercicioDeSesion, elegido) -> None:
        def pasarlas(_):
            self.pagina.pop_dialog()
            with conectado() as conexion:
                # LA NOTA ES DEL EJERCICIO, no del sitio: la del nuevo, no la del viejo.
                nuevo = replace(viejo, ejercicio_id=elegido.id, nombre=elegido.nombre,
                                nota=repositorio_entreno.ultima_nota(conexion, elegido.id, self.dia))
                repositorio_entreno.actualizar_ejercicio(conexion, nuevo)
                self.anteriores.update(self._leer_anteriores(conexion, [nuevo]))
            self._poner(nuevo)
            self._repintar_todo()

        def dejarlas(_):
            self.pagina.pop_dialog()
            self._dejar_lo_hecho_y_anadir_detras(viejo, elegido)

        self.pagina.show_dialog(ft.AlertDialog(
            modal=True,
            title=ft.Text(f"Ya marcaste series en «{viejo.nombre}»", size=15,
                          weight=ft.FontWeight.W_600, color=self.paleta.ink),
            content=ft.Text(
                f"¿Las pasás a «{elegido.nombre}» o se quedan en «{viejo.nombre}»? Si se "
                f"quedan, «{elegido.nombre}» entra justo después.",
                size=13, color=self.paleta.ink_soft,
            ),
            bgcolor=self.paleta.surface,
            actions=[
                ft.TextButton("Cancelar", on_click=lambda _: self.pagina.pop_dialog()),
                ft.TextButton(f"Dejarlas en «{viejo.nombre}»", on_click=dejarlas),
                ft.FilledButton("Pasarlas", on_click=pasarlas,
                                bgcolor=self.paleta.acento, color=self.paleta.acento_ink),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        ))

    def _dejar_lo_hecho_y_anadir_detras(self, viejo: EjercicioDeSesion, elegido) -> None:
        """El viejo se queda solo con lo marcado; el nuevo entra justo detrás,
        corriendo un puesto los que venían después."""
        sin_hacer = [una.numero for una in viejo.series if not una.hecha]
        with conectado() as conexion:
            # De atrás para adelante: así quitar una no renumera las que faltan quitar.
            for numero in sorted(sin_hacer, reverse=True):
                repositorio_entreno.quitar_serie(conexion, viejo.id, numero)
            corridos = [replace(uno, orden=uno.orden + 1)
                        for uno in self.sesion.ejercicios if uno.orden > viejo.orden]
            for uno in corridos:
                repositorio_entreno.actualizar_ejercicio(conexion, uno)
            nuevo = repositorio_entreno.anadir_ejercicio(
                conexion, self.sesion.id,
                EjercicioDeSesion(ejercicio_id=elegido.id, nombre=elegido.nombre,
                                  orden=viejo.orden + 1, series=self._series_de(conexion, elegido.id),
                                  nota=repositorio_entreno.ultima_nota(conexion, elegido.id, self.dia)),
            )
            self.anteriores.update(self._leer_anteriores(conexion, [nuevo]))
        recortado = viejo
        for numero in sorted(sin_hacer, reverse=True):
            recortado = quitar_serie(recortado, numero)
        self._poner(recortado, *corridos)
        self.sesion = replace(self.sesion, ejercicios=(*self.sesion.ejercicios, nuevo))
        self._repintar_todo()

    # ------------------------------------------------------------ terminar

    def _terminar(self) -> None:
        """Congela el tiempo y va al resumen.

        UN SEGUNDO COMO MÍNIMO: `segundos = 0` quiere decir «sin terminar», y un
        entreno cerrado en el mismo segundo se quedaría abierto para siempre.
        UN ENTRENO SIN HORA DE INICIO SIGUE SIN DURACIÓN, que es la verdad.

        SOLO SE GUARDA LA DURACIÓN: las series ya están guardadas, una por una,
        al escribirlas. Antes se guardaba el entreno entero tal como estaba en el
        último repintado, y lo escrito justo antes de tocar «Terminar» se perdía.
        """
        sesion = self.sesion
        duracion = sesion.duracion(datetime.now())
        segundos = max(1, duracion) if sesion.empezada_en else 0
        with conectado() as conexion:
            repositorio_entreno.terminar(conexion, sesion.id, segundos)
        self.sesion = replace(sesion, segundos=segundos)
        if self.franja is not None:
            self.franja.parar()
        # SE VA AL RESUMEN Y NO A LA APLICACIÓN: lo que querés ver justo
        # después es qué hiciste.
        self.al_terminar(self.dia, self.sesion.bloque)

    def _descartar(self) -> None:
        """Como si no hubieras entrenado. SE PREGUNTA ANTES, y aquí sí: es lo
        único de la pantalla que no se puede deshacer."""
        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo="Descartar el entreno",
            texto=(
                "Se pierde TODO lo de hoy: las series marcadas, el volumen y el "
                "tiempo. El día vuelve a salir como pendiente, igual que si no "
                "hubieras entrenado. El plan de la semana no se toca."
            ),
            al_aceptar=lambda _: self._descartar_de_verdad(),
        )

    def _descartar_de_verdad(self) -> None:
        with conectado() as conexion:
            repositorio_gimnasio.borrar_sesion(conexion, self.dia, self.sesion.bloque)
        self.pagina.pop_dialog()
        if self.franja is not None:
            self.franja.parar()
        componentes.avisar(self.pagina, "Entreno descartado.")
        self.al_salir()
