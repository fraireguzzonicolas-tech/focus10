"""Entrenar: la pantalla que se abre encima de todo al pulsar «Empezar».

LO PIDIÓ EL USUARIO: quitar la pestaña «Hoy» del gimnasio —«eso ya se ve en el
dashboard»— y poner en su lugar un botón de empezar que arranque un cronómetro.

NO ES UNA PESTAÑA, ES UNA PANTALLA ENTERA, y esa es la diferencia que importa:
entrenar no es «mirar una sección más» del gimnasio, es lo único que estás
haciendo durante una hora. Con el menú delante, la mitad de la pantalla de un
móvil se va en enlaces que no vas a pulsar con las manos ocupadas.

EL CRONÓMETRO NO SE CUENTA AQUÍ. Lo único que hace esta pantalla es preguntarle
a la sesión cuánto lleva (`Sesion.duracion`), y eso se calcula restando dos
horas. Por eso cerrar la aplicación a mitad del entreno no pierde nada: no hay
ningún número corriendo que se pueda parar.

EL DESCANSO ENTRE SERIES ES OTRO CRONÓMETRO DISTINTO, el de la franja de abajo,
y sigue funcionando igual que antes. Uno mide la hora que llevas en el gimnasio;
el otro, el minuto y medio entre dos series.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import date, datetime

import flet as ft

from ..datos import repositorio_ejercicios, repositorio_gimnasio
from ..datos.bd import conectado
from ..dominio.descanso import (
    parsear_descanso,
    parsear_duracion,
    texto_descanso,
    texto_duracion,
)
from ..dominio.ejercicio import DESCANSO_POR_OMISION, Medida
from ..dominio.rutina import parsear_peso, texto_peso
from ..dominio.semana import texto_dia
from ..dominio.sesion import (
    EjercicioDeSesion,
    Serie,
    Sesion,
    anadir_serie,
    con_serie,
    quitar_serie,
    texto_volumen,
)
from . import componentes, estilo
from .estilo import Paleta
from .franja_descanso import FranjaDescanso


def texto_reloj(segundos: int) -> str:
    """El cronómetro, en h:mm:ss o mm:ss.

    SIN HORAS MIENTRAS NO LAS HAYA: «1:04:07» y «04:07» dicen lo mismo con la
    misma claridad, pero un entreno de cuatro minutos no tiene por qué enseñar
    un cero delante que nunca cambia.
    """
    segundos = max(0, int(segundos))
    horas, resto = divmod(segundos, 3600)
    minutos, segundos = divmod(resto, 60)
    if horas:
        return f"{horas}:{minutos:02d}:{segundos:02d}"
    return f"{minutos:02d}:{segundos:02d}"


class PantallaEntreno:
    """El entreno en marcha: el reloj arriba y una tarjeta por ejercicio.

    NO HEREDA DE `Pantalla` a propósito: las demás se montan DENTRO del armazón
    de la ventana, con su menú y su barra. Ésta lo sustituye entero.
    """

    def __init__(
        self,
        pagina: ft.Page,
        paleta: Paleta,
        dia: date,
        al_salir,
        al_repintar,
        franja: FranjaDescanso | None = None,
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.dia = dia
        # DOS AVISOS DISTINTOS, como en la tarjeta de la cuenta: repintar deja
        # la pantalla donde está, y salir devuelve a la aplicación. Los dos los
        # hace la ventana, que es la única que puede cambiar lo que se ve.
        self.al_salir = al_salir
        self.al_repintar = al_repintar
        self.franja = franja
        self.ejercicios = []

    # ------------------------------------------------------------------

    def control(self, paleta: Paleta) -> ft.Control:
        """La pantalla entera. Se pide de nuevo en cada repintado."""
        self.paleta = paleta

        with conectado() as conexion:
            sesion = repositorio_gimnasio.sesion_de(conexion, self.dia)
            self.ejercicios = repositorio_ejercicios.listar(conexion)
            anteriores: dict[int, EjercicioDeSesion] = {}
            if sesion is not None:
                for uno in sesion.ejercicios:
                    if uno.ejercicio_id is None:
                        continue
                    vieja = repositorio_gimnasio.ultima_vez(
                        conexion, uno.ejercicio_id, self.dia
                    )
                    if vieja is not None:
                        anteriores[uno.ejercicio_id] = vieja

        if sesion is None:
            # NO DEBERÍA PASAR: aquí se llega después de crear la sesión. Pero
            # si la borras desde otro sitio, mejor una salida que una pantalla
            # en blanco sin explicación.
            return self._nada_que_entrenar()

        piezas: list[ft.Control] = [self._cabecera(sesion)]
        piezas += [
            self._tarjeta_ejercicio(sesion, uno, anteriores.get(uno.ejercicio_id))
            for uno in sesion.ejercicios
        ]
        piezas.append(self._pie(sesion))

        return ft.Container(
            content=ft.Column(
                piezas, spacing=estilo.DENSIDAD, scroll=ft.ScrollMode.AUTO, expand=True
            ),
            padding=estilo.RELLENO_TARJETA,
            expand=True,
            bgcolor=paleta.canvas,
        )

    def refrescar(self) -> None:
        """Repinta. Lo hace la ventana, que es quien tiene la página.

        SE LLAMA MUCHÍSIMO: cada vez que sales de una casilla de peso, cada vez
        que marcas una serie. Por eso los métodos movidos aquí abren UNA sola
        conexión por repintado y no una por ejercicio.
        """
        self.al_repintar()

    # ------------------------------------------------------------------

    def _cabecera(self, sesion: Sesion) -> ft.Control:
        """El reloj, el nombre del entreno y las dos salidas."""
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    ft.Row(
                        [
                            ft.Text(
                                texto_reloj(sesion.duracion(datetime.now())),
                                size=estilo.CIFRA_GRANDE,
                                color=self.paleta.ink,
                                font_family=self.paleta.titular,
                            ),
                            ft.Container(expand=True),
                            ft.Text(
                                sesion.titulo() or texto_dia(self.dia),
                                size=estilo.TITULAR,
                                color=self.paleta.ink_soft,
                                font_family=self.paleta.titular,
                            ),
                        ],
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    ft.Row(
                        [
                            componentes.cifra(
                                self.paleta, "Series", str(sesion.series_hechas)
                            ),
                            componentes.cifra(
                                self.paleta, "Volumen", texto_volumen(sesion.volumen)
                            ),
                            componentes.cifra(
                                self.paleta,
                                "Ejercicios",
                                str(len(sesion.ejercicios)),
                            ),
                        ],
                        spacing=30,
                    ),
                    ft.Row(
                        [
                            componentes.boton(
                                self.paleta,
                                "Terminar entreno",
                                icono=ft.Icons.CHECK,
                                principal=True,
                                al_pulsar=lambda _: self._terminar(sesion),
                            ),
                            componentes.boton(
                                self.paleta,
                                "Dejarlo para luego",
                                icono=ft.Icons.ARROW_BACK,
                                al_pulsar=lambda _: self.al_salir(),
                            ),
                        ],
                        spacing=10,
                        wrap=True,
                    ),
                ],
                spacing=14,
                tight=True,
            ),
        )

    def _pie(self, sesion: Sesion) -> ft.Control:
        return ft.Row(
            [
                componentes.boton(
                    self.paleta,
                    "Añadir ejercicio",
                    icono=ft.Icons.ADD,
                    al_pulsar=lambda _: self._elegir_ejercicio(sesion),
                ),
                ft.Container(expand=True),
                componentes.boton(
                    self.paleta,
                    "Borrar este entreno",
                    al_pulsar=lambda _: self._borrar_entreno(sesion),
                ),
            ]
        )

    def _nada_que_entrenar(self) -> ft.Control:
        return ft.Container(
            content=ft.Column(
                [
                    componentes.aviso_vacio(
                        self.paleta, "Este entreno ya no existe."
                    ),
                    componentes.boton(
                        self.paleta,
                        "Volver",
                        icono=ft.Icons.ARROW_BACK,
                        al_pulsar=lambda _: self.al_salir(),
                    ),
                ],
                spacing=14,
                tight=True,
            ),
            padding=estilo.RELLENO_TARJETA,
            alignment=ft.Alignment.CENTER,
            expand=True,
            bgcolor=self.paleta.canvas,
        )

    # ------------------------------------------------------------------

    def _terminar(self, sesion: Sesion) -> None:
        """Congela el tiempo y sale.

        SE CONGELA AQUÍ Y NO AL MIRARLO: si no se guardara la duración, el
        entreno de hoy seguiría creciendo mañana y pasado, porque el tiempo se
        calcula desde la hora de inicio.

        UN ENTRENO SIN HORA DE INICIO NO SE INVENTA UNA: los de antes del
        cronómetro se pueden abrir y terminar igual, y siguen sin decir cuánto
        duraron, que es la verdad.
        """
        # UN SEGUNDO COMO MINIMO, y no es un capricho: `segundos = 0` es lo que
        # quiere decir "sin terminar". Un entreno abierto y cerrado dentro del
        # mismo segundo —un toque sin querer— se guardaria con cero y se
        # quedaria abierto para siempre, pidiendote terminarlo cada vez que
        # abrieras la aplicacion. Decir que duro un segundo es mas cierto que
        # decir que sigue en marcha.
        #
        # UN ENTRENO SIN HORA DE INICIO SIGUE SIN DURACION: los de antes del
        # cronometro dan cero aqui y se quedan en cero, que es la verdad. Para
        # esos, "terminar" es solo cerrar la pantalla.
        duracion = sesion.duracion(datetime.now())
        with conectado() as conexion:
            repositorio_gimnasio.guardar_sesion(
                conexion,
                replace(
                    sesion,
                    segundos=max(1, duracion) if sesion.empezada_en else 0,
                ),
            )
        if self.franja is not None:
            self.franja.parar()
        componentes.avisar(
            self.pagina,
            f"Entreno guardado. {texto_reloj(duracion)}."
            if duracion
            else "Entreno guardado.",
        )
        self.al_salir()


    def _tarjeta_ejercicio(
        self,
        sesion: Sesion,
        ejercicio: EjercicioDeSesion,
        anterior: EjercicioDeSesion | None,
    ) -> ft.Control:
        filas = [
            self._fila_de_serie(sesion, ejercicio, serie, anterior)
            for serie in ejercicio.series
        ]

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        ejercicio.nombre,
                        f"{ejercicio.hechas} de {len(ejercicio.series)} series",
                        ft.Row(
                            [
                                self._campo_descanso(sesion, ejercicio),
                                componentes.boton(
                                    self.paleta,
                                    "+ serie",
                                    al_pulsar=lambda _, e=ejercicio: (
                                        self._anadir_serie(sesion, e)
                                    ),
                                ),
                            ],
                            spacing=10,
                            tight=True,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                    ),
                    componentes.tabla(
                        self.paleta,
                        [
                            ("SERIE", 56),
                            ("LA VEZ ANTERIOR", 150),
                            ("DURACIÓN", 130),
                            ("", None),
                        ]
                        if self._es_de_tiempo(ejercicio)
                        else [
                            ("SERIE", 56),
                            ("LA VEZ ANTERIOR", 150),
                            ("PESO", 130),
                            ("REPS", 110),
                            ("", None),
                        ],
                        filas,
                    ),
                ],
                spacing=12,
            ),
        )

    def _fila_de_serie(
        self,
        sesion: Sesion,
        ejercicio: EjercicioDeSesion,
        serie,
        anterior: EjercicioDeSesion | None,
    ) -> list[ft.Control]:
        paleta = self.paleta

        # "LO QUE HICE LA VEZ ANTERIOR", en gris. Es el dato que de verdad decide
        # qué peso poner hoy, y por eso está en la misma fila y no en una nota
        # aparte que habría que ir a buscar.
        vieja = anterior.serie(serie.numero) if anterior else None
        texto_anterior = vieja.texto() if vieja else "—"

        if self._es_de_tiempo(ejercicio):
            # UN EJERCICIO DE TIEMPO NO TIENE KILOS NI REPETICIONES. Enseñar
            # esas casillas a cero no es neutral: invita a rellenarlas con algo
            # que luego no quiere decir nada, y de paso ensucia el volumen.
            campo_tiempo = componentes.campo_texto(
                paleta, "", valor=texto_duracion(serie.segundos), ancho=118
            )
            campo_tiempo.tooltip = "30min, 30:00, 45s, 1h30... como quieras"
            campo_tiempo.on_blur = (
                lambda _, n=serie.numero, c=campo_tiempo: self._guardar_tiempo(
                    sesion, ejercicio, n, c
                )
            )
            return [
                ft.Text(str(serie.numero), size=estilo.TEXTO, color=paleta.ink),
                ft.Text(texto_anterior, size=estilo.TEXTO, color=paleta.muted),
                campo_tiempo,
                self._acciones_de_serie(sesion, ejercicio, serie),
            ]

        campo_peso = componentes.campo_texto(
            paleta, "", valor=_kilos(serie.peso), ancho=118
        )
        campo_peso.on_blur = lambda _, n=serie.numero, c=campo_peso: self._guardar_peso(
            sesion, ejercicio, n, c
        )
        campo_reps = componentes.campo_texto(
            paleta, "", valor=str(serie.repeticiones), ancho=98
        )
        campo_reps.on_blur = lambda _, n=serie.numero, c=campo_reps: self._guardar_reps(
            sesion, ejercicio, n, c
        )

        return [
            ft.Text(str(serie.numero), size=estilo.TEXTO, color=paleta.ink),
            ft.Text(texto_anterior, size=estilo.TEXTO, color=paleta.muted),
            campo_peso,
            campo_reps,
            self._acciones_de_serie(sesion, ejercicio, serie),
        ]

    def _acciones_de_serie(self, sesion, ejercicio, serie) -> ft.Control:
        """El check de marcar y la equis de quitar. Los usan las dos formas de
        fila, la de peso y la de tiempo."""
        paleta = self.paleta
        marcar = ft.Container(
            content=ft.Icon(
                ft.Icons.CHECK_ROUNDED,
                size=18,
                color=paleta.canvas if serie.hecha else paleta.muted,
            ),
            width=36,
            height=36,
            bgcolor=paleta.acento if serie.hecha else None,
            border=None if serie.hecha else ft.Border.all(1, paleta.borde_fuerte),
            border_radius=999,
            alignment=ft.Alignment.CENTER,
            tooltip="Marcar la serie y arrancar el descanso",
            on_click=lambda _, n=serie.numero: self._marcar(sesion, ejercicio, n),
            ink=True,
        )
        return ft.Row(
            [
                marcar,
                componentes.boton_icono(
                    paleta,
                    ft.Icons.CLOSE,
                    ayuda="Quitar esta serie",
                    al_pulsar=lambda _, n=serie.numero: self._quitar_serie(
                        sesion, ejercicio, n
                    ),
                ),
            ],
            spacing=4,
            tight=True,
        )

    def _es_de_tiempo(self, ejercicio: EjercicioDeSesion) -> bool:
        """Si este ejercicio se mide en tiempo, segun su ficha.

        Un ejercicio borrado de la biblioteca se trata como de peso, que es lo
        que era la mayoria: cambiarle la forma a un entreno viejo seria peor que
        ensenar una columna de mas.
        """
        for uno in self.ejercicios:
            if uno.id == ejercicio.ejercicio_id:
                return uno.medida is Medida.TIEMPO
        return False

    def _guardar_tiempo(self, sesion, ejercicio, numero: int, campo) -> None:
        escrito = (campo.value or "").strip()
        segundos = parsear_duracion(escrito) if escrito else 0
        if segundos is None:
            serie = ejercicio.serie(numero)
            campo.value = texto_duracion(serie.segundos if serie else 0)
            campo.update()
            componentes.avisar(
                self.pagina,
                "No he entendido esa duración. Vale 30min, 30:00, 45s o 1h30.",
            )
            return
        self._guardar(sesion, con_serie(ejercicio, numero, segundos=segundos))

    def _campo_descanso(
        self, sesion: Sesion, ejercicio: EjercicioDeSesion
    ) -> ft.Control:
        """El descanso de este ejercicio, cambiable en mitad del entreno.

        POR QUÉ SE PUEDE CAMBIAR AQUÍ Y NO SOLO EN EL PLAN: hay días que llegas
        cansado y necesitas dos minutos donde el plan dice noventa segundos.
        Obligarte a ir a la Rutina para eso te haría cambiar el PLAN por lo que
        pasó un martes, que es justo lo que la separación evita.
        """
        campo = componentes.campo_texto(
            self.paleta,
            "Descanso",
            valor=texto_descanso(self._descanso_de(ejercicio)),
            ancho=120,
        )
        campo.tooltip = "90, 1:30, 1.30, 1.3, 1m30, 30s... como quieras"
        campo.on_blur = lambda _, e=ejercicio, c=campo: self._guardar_descanso(
            sesion, e, c
        )
        return campo

    def _guardar_descanso(
        self, sesion: Sesion, ejercicio: EjercicioDeSesion, campo
    ) -> None:

        segundos = parsear_descanso(campo.value or "")
        if segundos is None:
            campo.value = texto_descanso(self._descanso_de(ejercicio))
            campo.update()
            componentes.avisar(
                self.pagina,
                "No he entendido ese descanso. Vale 90, 1:30, 1.30, 1.3, 1m30 o 30s.",
            )
            return
        self._guardar(sesion, replace(ejercicio, descanso=segundos))

    def _marcar(self, sesion: Sesion, ejercicio: EjercicioDeSesion, numero: int) -> None:
        """Marca o desmarca una serie. Al marcarla arranca el descanso SOLO.

        Que arranque solo es media función: nadie se acuerda de darle a un botón
        con las manos ocupadas. Al DESmarcar no se toca el cronómetro: quitar una
        marca es corregir un error, no acabar una serie.
        """
        serie = ejercicio.serie(numero)
        if serie is None:
            return
        ahora_hecha = not serie.hecha
        self._guardar(
            sesion, con_serie(ejercicio, numero, hecha=ahora_hecha)
        )
        if ahora_hecha and self.franja is not None:
            self.franja.arrancar(
                self._descanso_de(ejercicio),
                ejercicio=ejercicio.nombre,
                serie=numero,
            )

    def _descanso_de(self, ejercicio: EjercicioDeSesion) -> int:
        """Los segundos de descanso de ese ejercicio. En este orden y no en otro:

          1. EL DEL ENTRENO, que se copió del plan al empezar y que puedes
             cambiar aquí mismo. Manda siempre que esté puesto, porque es lo que
             tú elegiste para este ejercicio.
          2. El de la ficha de la biblioteca, si en el entreno no se dijo nada.
          3. El de por omisión, si el ejercicio ya no está en la biblioteca.

        NINGÚN PASO SE SALTA HACIA ARRIBA: un cero en el entreno es un cero
        elegido a propósito (el cardio no lleva descanso), no un hueco. Tratarlo
        como hueco haría que el cronómetro arrancara donde tú dijiste que no.
        """

        if ejercicio.descanso is not None:
            return ejercicio.descanso
        for uno in self.ejercicios:
            if uno.id == ejercicio.ejercicio_id:
                return uno.descanso
        return DESCANSO_POR_OMISION

    def _guardar_peso(self, sesion, ejercicio, numero: int, campo) -> None:

        peso = parsear_peso(campo.value or "")
        if peso is None:
            # NO SE ADIVINA: se devuelve el campo a lo que había. Un peso
            # inventado en el historial es peor que un campo que no se deja
            # escribir, porque el inventado no se nota.
            serie = ejercicio.serie(numero)
            campo.value = _kilos(serie.peso) if serie else "0"
            campo.update()
            componentes.avisar(self.pagina, "El peso no se entiende. Ejemplo: 62,5")
            return
        self._guardar(sesion, con_serie(ejercicio, numero, peso=peso))

    def _guardar_reps(self, sesion, ejercicio, numero: int, campo) -> None:
        texto = (campo.value or "").strip()
        if not texto.isdigit():
            serie = ejercicio.serie(numero)
            campo.value = str(serie.repeticiones) if serie else "0"
            campo.update()
            componentes.avisar(self.pagina, "Las repeticiones son un número entero.")
            return
        self._guardar(sesion, con_serie(ejercicio, numero, repeticiones=int(texto)))

    def _anadir_serie(self, sesion: Sesion, ejercicio: EjercicioDeSesion) -> None:
        self._guardar(sesion, anadir_serie(ejercicio))

    def _quitar_serie(
        self, sesion: Sesion, ejercicio: EjercicioDeSesion, numero: int
    ) -> None:
        self._guardar(sesion, quitar_serie(ejercicio, numero))

    def _guardar(self, sesion: Sesion, ejercicio: EjercicioDeSesion) -> None:
        """Mete el ejercicio cambiado en la sesión y la guarda entera.

        SE GUARDA EN CADA CAMBIO y no al final con un botón. En el gimnasio la
        aplicación se cierra sola, se apaga la pantalla, suena el teléfono; un
        entreno que se pierde por no haber dado a "Guardar" no vuelve.
        """

        nuevos = tuple(
            ejercicio if uno.orden == ejercicio.orden else uno
            for uno in sesion.ejercicios
        )
        with conectado() as conexion:
            repositorio_gimnasio.guardar_sesion(
                conexion, replace(sesion, ejercicios=nuevos)
            )
        self.refrescar()

    def _elegir_ejercicio(self, sesion: Sesion) -> None:
        from . import dialogo_anadir_ejercicio

        dialogo_anadir_ejercicio.abrir(
            self.pagina,
            self.paleta,
            self.ejercicios,
            lambda elegido: self._anadir_a_la_sesion(sesion, elegido),
        )

    def _anadir_a_la_sesion(self, sesion: Sesion, elegido) -> None:


        nuevo = EjercicioDeSesion(
            ejercicio_id=elegido.id,
            nombre=elegido.nombre,
            orden=len(sesion.ejercicios),
            series=(Serie(numero=1),),
        )
        with conectado() as conexion:
            repositorio_gimnasio.guardar_sesion(
                conexion,
                replace(sesion, ejercicios=(*sesion.ejercicios, nuevo)),
            )
        self.refrescar()

    def _borrar_entreno(self, sesion: Sesion) -> None:
        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo="Borrar el entreno",
            texto=(
                "Se pierden las series de este día. El plan de la semana no se "
                "toca."
            ),
            al_aceptar=lambda _: self._borrar_de_verdad(sesion),
        )

    def _borrar_de_verdad(self, sesion: Sesion) -> None:
        with conectado() as conexion:
            repositorio_gimnasio.borrar_sesion(conexion, sesion.fecha)
        self.pagina.pop_dialog()
        if self.franja is not None:
            self.franja.parar()
        self.refrescar()


def _kilos(centesimas: int) -> str:
    """El peso para meter en un campo: "62,5", sin el "kg"."""
    return texto_peso(centesimas).removesuffix(" kg")
