"""Añadir una inversión escribiendo lo que sea: "S&P 500", "IPF", "Apple".

CÓMO ERA ANTES Y POR QUÉ SE CAMBIÓ: había que saberse el símbolo exacto —CSPX.L
en Londres, SXR8.DE en Fráncfort— y escribirlo a mano. Eso es pedirle al usuario
el dato técnico que precisamente viene a buscar. Ahora se escribe el nombre como
uno lo diga y salen las opciones debajo, con su bolsa al lado para poder elegir.

SE BUSCA SOLA, 400 ms DESPUÉS DE DEJAR DE TECLEAR. Ni con cada letra —serían diez
peticiones para escribir "Apple" y Yahoo acabaría contestando 429— ni con un
botón, que obliga a un gesto de más cada vez.

LA BÚSQUEDA VA EN OTRO HILO. urllib bloquea, y bloquear el hilo de la ventana
significa que la aplicación se queda congelada hasta doce segundos si Yahoo va
lento. Con asyncio.to_thread, la ventana sigue viva y se puede seguir escribiendo.

LO QUE NO ESTÁ EN YAHOO SE PUEDE APUNTAR IGUAL. Un fondo de tu banco no aparece
en ningún buscador, y dejarlo fuera sería que la cartera dejara de ser tu cartera.
"""

from __future__ import annotations

import asyncio
from datetime import date

import flet as ft

from ..datos import repositorio_inversiones as repo
from ..datos.bd import conectado
from ..dominio.dinero import parsear_importe
from ..dominio.inversion import (
    Posicion,
    TipoActivo,
    compra_por_dinero,
    compra_por_unidades,
    parsear_unidades,
    vista_previa,
)
from ..dominio.moneda import EUR
from ..sistema import mercado
from . import componentes
from .estilo import Paleta

ANCHO = 460
LETRAS_MINIMAS = 2
"""Con una sola letra, Yahoo devuelve cualquier cosa y la lista no ayuda."""

ESPERA_ANTES_DE_BUSCAR = 0.4
"""Segundos desde la última tecla. Es lo que usaba Nexo y funcionaba bien."""


class Modo:
    """Las dos formas de decir lo mismo. Los nombres son los del usuario."""

    DINERO = "Puse dinero"
    UNIDADES = "Compré unidades"


def abrir(pagina: ft.Page, paleta: Paleta, al_guardar) -> None:
    _DialogoNuevaInversion(pagina, paleta, al_guardar).mostrar()


class _DialogoNuevaInversion:
    def __init__(self, pagina, paleta, al_guardar) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.al_guardar = al_guardar

        self.elegido: dict | None = None
        self.a_mano = False
        self.modo = Modo.DINERO
        self.tipo = TipoActivo.ETF
        self._peticion = 0
        """Un contador para saber si la respuesta que llega es de la última
        búsqueda o de una anterior. Sin él, escribir rápido puede dejar en
        pantalla los resultados de "App" después de haber escrito "Apple"."""

        self.busqueda = componentes.campo_texto(
            paleta,
            "¿Qué has comprado?",
            pista="S&P 500, Apple, bitcoin, IPF...",
        )
        self.busqueda.on_change = lambda _: self._teclear()

        self.resultados = ft.Column(spacing=0, tight=True)
        self.estado = ft.Text("", size=11, color=paleta.muted)

        self.nombre = componentes.campo_texto(paleta, "Nombre", pista="Fondo indexado")
        self.ticker = componentes.campo_texto(paleta, "Símbolo", pista="MI-FONDO")

        self.dinero = self._campo("Euros que puse", "761")
        self.unidades = self._campo("Unidades que tengo", "0,913796")
        self.precio = self._campo("Precio al que compré (€ por unidad)", "832,79")
        self.fecha = self._campo("Fecha de la compra", str(date.today()))

        self.previa = ft.Text("", size=12, color=paleta.ink, selectable=True)
        self.error = ft.Text("", size=12, color=paleta.negativo, visible=False)
        self._recalcular()

    def _campo(self, etiqueta: str, pista: str) -> ft.TextField:
        campo = componentes.campo_texto(self.paleta, etiqueta, pista=pista)
        campo.on_change = lambda _: self._recalcular()
        return campo

    def mostrar(self) -> None:
        self.dialogo = componentes.dialogo(
            self.paleta,
            "Nueva inversión",
            ft.Column(self._piezas(), spacing=10, tight=True, width=ANCHO,
                      scroll=ft.ScrollMode.AUTO),
            pagina=self.pagina,
            texto_aceptar="Guardar",
            al_aceptar=lambda _: self._guardar(),
        )
        self.pagina.show_dialog(self.dialogo)

    def _repintar(self) -> None:
        self.pagina.pop_dialog()
        self.mostrar()

    # ----------------------------------------------------------------------
    # El buscador
    # ----------------------------------------------------------------------

    def _piezas(self) -> list[ft.Control]:
        if self.elegido is not None:
            arriba = [self._elegido()]
        elif self.a_mano:
            arriba = [
                ft.Text(
                    "No está en Yahoo, así que el precio lo escribirás tú en la "
                    "tabla. Todo lo demás funciona igual.",
                    size=11,
                    color=self.paleta.muted,
                ),
                self.nombre,
                self.ticker,
                self._elegir_tipo(),
                componentes.boton(
                    self.paleta,
                    "Volver a buscar",
                    icono=ft.Icons.SEARCH,
                    al_pulsar=lambda _: self._volver_a_buscar(),
                ),
            ]
        else:
            arriba = [
                self.busqueda,
                self.estado,
                self.resultados,
                componentes.boton(
                    self.paleta,
                    "No aparece: lo pongo a mano",
                    icono=ft.Icons.EDIT_OUTLINED,
                    al_pulsar=lambda _: self._poner_a_mano(),
                ),
            ]

        return [
            *arriba,
            componentes.separador(self.paleta),
            ft.Text("¿Cómo lo apuntas?", size=12, color=self.paleta.muted),
            self._elegir_modo(),
            self.dinero if self.modo == Modo.DINERO else self.unidades,
            self.precio,
            self.fecha,
            componentes.separador(self.paleta),
            ft.Container(
                content=ft.Row(
                    [
                        ft.Icon(
                            ft.Icons.FACT_CHECK_OUTLINED, size=16, color=self.paleta.acento
                        ),
                        ft.Container(content=self.previa, expand=True),
                    ],
                    spacing=8,
                ),
                padding=10,
                bgcolor=self.paleta.surface_2,
                border_radius=8,
            ),
            self.error,
        ]

    def _teclear(self) -> None:
        """Cada tecla: se apunta y se lanza una búsqueda que quizá no llegue a
        hacerse, porque la siguiente tecla la invalida."""
        self._peticion += 1
        self.pagina.run_task(self._buscar_pronto, self._peticion)

    async def _buscar_pronto(self, mio: int) -> None:
        await asyncio.sleep(ESPERA_ANTES_DE_BUSCAR)
        if mio != self._peticion:
            return  # ha seguido escribiendo: esta búsqueda ya no interesa

        texto = (self.busqueda.value or "").strip()
        if len(texto) < LETRAS_MINIMAS:
            self._pintar_resultados([], "")
            return

        if not self._asegurar_internet():
            return

        self._pintar_resultados([], "buscando...")
        try:
            # EN OTRO HILO: urllib bloquea, y bloquear aquí congela la ventana
            # entera hasta doce segundos si Yahoo va lento.
            encontrados = await asyncio.to_thread(mercado.buscar, texto)
        except mercado.MercadoNoDisponible as fallo:
            self._pintar_resultados([], str(fallo))
            return

        if mio != self._peticion:
            return  # llegó tarde: ya hay una búsqueda más nueva
        self._pintar_resultados(
            encontrados,
            "" if encontrados else f"No encuentro nada con «{texto}».",
        )

    def _asegurar_internet(self) -> bool:
        """Enciende los precios de mercado la primera vez, avisando.

        Lo decidió el usuario: sin esto, el buscador parecería roto la primera
        vez que se usa en un ordenador nuevo. Se enciende y se dice qué sale de
        aquí; el interruptor sigue en la pantalla para apagarlo cuando quiera.
        """
        with conectado() as conexion:
            if repo.leer_precios_de_mercado(conexion):
                return True
            repo.guardar_precios_de_mercado(conexion, True)
        self._pintar_resultados(
            [],
            "He encendido los precios de internet para poder buscar. De tu "
            "ordenador sale solo lo que escribes aquí; puedes apagarlo en la "
            "pantalla de Inversiones.",
        )
        return True

    def _pintar_resultados(self, encontrados: list[dict], mensaje: str) -> None:
        self.resultados.controls = [self._fila(uno) for uno in encontrados[:8]]
        self.estado.value = mensaje
        try:
            self.resultados.update()
            self.estado.update()
        except Exception:  # noqa: BLE001
            pass  # el diálogo ya no está en pantalla

    def _fila(self, uno: dict) -> ft.Control:
        return ft.Container(
            content=ft.Row(
                [
                    ft.Column(
                        [
                            ft.Text(
                                uno["nombre"] or uno["simbolo"],
                                size=13,
                                color=self.paleta.ink,
                            ),
                            ft.Text(
                                f"{uno['simbolo']} · {uno['bolsa']} · {uno['tipo']}",
                                size=11,
                                color=self.paleta.muted,
                            ),
                        ],
                        spacing=1,
                        tight=True,
                        expand=True,
                    ),
                    ft.Icon(ft.Icons.CHEVRON_RIGHT, size=16, color=self.paleta.muted),
                ],
                spacing=8,
            ),
            padding=ft.Padding.symmetric(vertical=7, horizontal=8),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
            on_click=lambda _, u=uno: self._elegir(u),
            ink=True,
        )

    def _elegir(self, uno: dict) -> None:
        self.elegido = uno
        # El tipo lo dice Yahoo: pedírselo al usuario sabiéndolo ya sería hacerle
        # trabajo de más.
        self.tipo = TipoActivo(uno.get("tipo_nuestro") or "otro")
        self._repintar()

    def _elegido(self) -> ft.Control:
        uno = self.elegido
        return ft.Container(
            content=ft.Row(
                [
                    ft.Icon(ft.Icons.CHECK_CIRCLE, size=18, color=self.paleta.positivo),
                    ft.Column(
                        [
                            ft.Text(
                                uno["nombre"] or uno["simbolo"],
                                size=13,
                                weight=ft.FontWeight.W_600,
                                color=self.paleta.ink,
                            ),
                            ft.Text(
                                f"{uno['simbolo']} · {uno['bolsa']}",
                                size=11,
                                color=self.paleta.muted,
                            ),
                        ],
                        spacing=1,
                        tight=True,
                        expand=True,
                    ),
                    componentes.boton(
                        self.paleta,
                        "Cambiar",
                        al_pulsar=lambda _: self._volver_a_buscar(),
                    ),
                ],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=10,
            bgcolor=self.paleta.surface_2,
            border_radius=8,
        )

    def _volver_a_buscar(self) -> None:
        self.elegido = None
        self.a_mano = False
        self._repintar()

    def _poner_a_mano(self) -> None:
        self.a_mano = True
        self.nombre.value = (self.busqueda.value or "").strip()
        self._repintar()

    def _elegir_tipo(self) -> ft.Control:
        return ft.Row(
            [
                ft.Container(
                    content=ft.Text(
                        uno.value.capitalize(),
                        size=12,
                        color=self.paleta.acento_ink
                        if uno is self.tipo
                        else self.paleta.ink_soft,
                    ),
                    padding=ft.Padding.symmetric(horizontal=11, vertical=7),
                    bgcolor=self.paleta.acento
                    if uno is self.tipo
                    else self.paleta.surface_2,
                    border_radius=8,
                    on_click=lambda _, t=uno: self._cambiar_tipo(t),
                    ink=True,
                )
                for uno in TipoActivo
            ],
            spacing=6,
            wrap=True,
        )

    def _cambiar_tipo(self, tipo: TipoActivo) -> None:
        self.tipo = tipo
        self._repintar()

    def _elegir_modo(self) -> ft.Control:
        return ft.Row(
            [
                ft.Container(
                    content=ft.Text(
                        texto,
                        size=12,
                        color=self.paleta.acento_ink
                        if texto == self.modo
                        else self.paleta.ink_soft,
                    ),
                    padding=ft.Padding.symmetric(horizontal=12, vertical=7),
                    bgcolor=self.paleta.acento
                    if texto == self.modo
                    else self.paleta.surface_2,
                    border_radius=8,
                    on_click=lambda _, m=texto: self._cambiar_modo(m),
                    ink=True,
                )
                for texto in (Modo.DINERO, Modo.UNIDADES)
            ],
            spacing=6,
        )

    def _cambiar_modo(self, modo: str) -> None:
        self.modo = modo
        self._recalcular()
        self._repintar()

    # ----------------------------------------------------------------------
    # Guardar
    # ----------------------------------------------------------------------

    def _construir_compra(self):
        try:
            fecha = date.fromisoformat((self.fecha.value or "").strip())
        except ValueError as fallo:
            raise ValueError("la fecha se escribe como 2025-08-19") from fallo

        precio = parsear_importe(self.precio.value or "", EUR)
        if precio is None:
            raise ValueError("escribe el precio al que compraste")

        if self.modo == Modo.DINERO:
            dinero = parsear_importe(self.dinero.value or "", EUR)
            if dinero is None:
                raise ValueError("escribe cuántos euros pusiste")
            return compra_por_dinero(dinero, precio, fecha)

        unidades = parsear_unidades(self.unidades.value or "")
        if unidades is None:
            raise ValueError("escribe cuántas unidades tienes")
        return compra_por_unidades(unidades, precio, fecha)

    def _recalcular(self) -> None:
        try:
            self.previa.value = vista_previa(self._construir_compra(), EUR)
            self.previa.color = self.paleta.ink
        except (ValueError, TypeError) as fallo:
            self.previa.value = str(fallo)
            self.previa.color = self.paleta.muted
        try:
            self.previa.update()
        except Exception:  # noqa: BLE001
            pass  # el diálogo ya no está en pantalla

    def _avisar(self, texto: str) -> None:
        self.error.value = texto
        self.error.visible = True
        try:
            self.error.update()
        except Exception:  # noqa: BLE001
            self._repintar()

    def _guardar(self) -> None:
        if self.elegido is None and not self.a_mano:
            self._avisar("Busca primero qué has comprado, o ponlo a mano.")
            return

        try:
            operacion = self._construir_compra()
            posicion = Posicion(
                nombre=(
                    self.elegido["nombre"] or self.elegido["simbolo"]
                    if self.elegido
                    else (self.nombre.value or "")
                ),
                ticker=(
                    self.elegido["simbolo"] if self.elegido else (self.ticker.value or "")
                ),
                tipo=self.tipo,
            )
        except (ValueError, TypeError) as fallo:
            self._avisar(str(fallo))
            return

        try:
            with conectado() as conexion:
                guardada = repo.crear(conexion, posicion)
                repo.anadir_operacion(conexion, guardada.id, operacion)
        except (ValueError, TypeError) as fallo:
            self._avisar(str(fallo))
            return

        self.pagina.pop_dialog()
        # El precio actual NO lo escribe el usuario: se busca solo. Si falla, la
        # posición se queda guardada igual y la pantalla avisa de que le falta
        # precio; perder la compra por un problema de internet sería absurdo.
        self.al_guardar(traer_precio_de=guardada.id)
