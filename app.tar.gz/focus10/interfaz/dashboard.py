"""El Dashboard: el día de hoy. Lo que hay que hacer y cómo va.

LA DISPOSICIÓN LA DIBUJÓ EL USUARIO EN PAPEL, y es esta:

  fecha y hora arriba
  [ hábitos de hoy ]     [ gastos, gimnasio y educación, apilados ]
  [ horario de hoy, a lo ancho                                    ]
  [ cosas a hacer, a lo ancho                                     ]

LAS TARJETAS VIVEN EN TRES ARCHIVOS: aquí la pantalla, la cabecera, los gastos y
el gimnasio; los hábitos en dashboard_habitos.py, y el horario, la educación y
las cosas a hacer en dashboard_agenda.py. PantallaDashboard las hereda.

POR QUÉ EL MARCADO VIVE AQUÍ Y NO EN HÁBITOS: son dos preguntas distintas. "¿Qué
me toca hoy?" se contesta cada mañana y necesita botones; "¿cómo llevo el año?"
se contesta de vez en cuando y necesita una foto. Tenerlas juntas obligaba a
elegir vista cada vez que abrías la app solo para marcar el agua.

TODO SE FECHA POR JORNADA, no por el reloj: marcar un hábito a las 3 de la
madrugada cuenta para la jornada que empezó ayer. Es la misma regla del dinero, y
para quien trabaja de noche es la diferencia entre una racha real y una racha
rota cada madrugada.

EL GIMNASIO SÍ TIENE SU TARJETA, y enseña tres cosas distintas según el día: lo
que toca hoy si no has empezado, cómo llevas el entreno si estás en mitad de él,
o que hoy toca descansar. Los tres son datos de verdad leídos de la base; ninguno
se calcula ni se estima.
"""

from __future__ import annotations

import asyncio
from datetime import date, datetime, timedelta

import flet as ft

from ..datos import (
    estadisticas_habitos,
    repositorio_categorias,
    repositorio_dias,
    repositorio_educacion,
    repositorio_gimnasio,
    repositorio_habitos,
    repositorio_horario,
    repositorio_movimientos,
    repositorio_objetivos,
    repositorio_tareas,
)
from ..datos.ajustes import leer_moneda_principal
from ..datos.bd import conectado
from ..dominio.educacion import DIAS_DE_LA_SEMANA_QUE_VIENE
from ..dominio.estadisticas_habitos import Periodo
from ..dominio.habito import Franja
from ..dominio.movimiento import Tipo
from ..dominio.objetivo import Estado as EstadoObjetivo
from ..dominio.objetivo import avance as avance_objetivo
from ..dominio.reparto import por_categoria
from ..dominio.rutina import dia_de
from ..dominio.semana import DIAS, MESES
from ..dominio.sesion import texto_volumen
from . import (
    componentes,
    dialogo_cierre,
    dialogo_movimiento,
    empezar_entreno,
    estilo,
    grafico_reparto,
    lema,
    reloj,
    resumen_mensual,
)
from . import estadisticas_habitos as vista_estadisticas
from .dashboard_agenda import TarjetasDeHoy
from .dashboard_habitos import TarjetaHabitos
from .estilo import Paleta


SEGUNDOS_ENTRE_RELOJES = 1
"""Cada cuánto se repinta el reloj.

ERA VEINTE Y AHORA ES UNO por el segundero: una aguja que solo se mueve cada
veinte segundos no es un segundero, es un adorno que se teletransporta. Lo que se
repinta es SOLO el reloj —treinta y cuatro píxeles de lienzo—, no la pantalla
entera, y la cuenta se para sola al cambiar de sección."""


DIAS_ATRASADOS = 14
"""Cuánto hacia atrás se buscan cosas de estudio sin hacer.

DOS SEMANAS Y NO TODO EL HISTORIAL: una tarea de hace tres meses que nunca
marcaste ya no la vas a hacer, y arrastrarla para siempre convierte el resumen
en una lista de reproches.
"""


class PantallaDashboard(TarjetaHabitos, TarjetasDeHoy, componentes.Pantalla):
    def __init__(self, pagina: ft.Page, paleta: Paleta, al_entrenar=None) -> None:
        super().__init__(pagina, paleta)
        # ABRIR LA PANTALLA DE ENTRENAR SUSTITUYE LA VENTANA ENTERA, y eso solo
        # lo sabe hacer quien la monto. Por eso se recibe de fuera.
        self.al_entrenar = al_entrenar
        self.franja: Franja | None = None  # None = todas
        # El reloj vive en un hueco que se rellena en cada tic: así se cambia
        # el dibujo sin reconstruir la cabecera entera.
        self.hueco_reloj = ft.Container(width=reloj.LADO, height=reloj.LADO)
        self.reloj = ft.Text(
            "",
            size=estilo.TEXTO_TARJETA,
            weight=ft.FontWeight.W_600,
            color=paleta.ink,
        )
        self.reloj_ampm = ft.Text(
            "", size=estilo.ROTULO, weight=ft.FontWeight.W_600, color=paleta.muted
        )
        self.reloj_24h = ft.Text("", size=estilo.ROTULO, color=paleta.muted)
        self._segundo_pintado: int | None = None
        self._vivo = True
        self.refrescar()

    def montada(self) -> None:
        super().montada()
        # El reloj solo empieza a correr cuando la pantalla está puesta: pedirle
        # a un control que se repinte antes de estar en la ventana revienta.
        self.pagina.run_task(self._tic_tac)

    async def _tic_tac(self) -> None:
        """Mantiene la hora al día mientras esta pantalla siga puesta.

        Se para sola al cambiar de sección (self._vivo). Sin eso, cada visita al
        Dashboard dejaría un reloj más corriendo por detrás para siempre.
        """
        while self._vivo:
            await asyncio.sleep(SEGUNDOS_ENTRE_RELOJES)
            if not self._vivo or not self._en_pagina:
                return
            ahora = datetime.now()
            if ahora.second == self._segundo_pintado:
                continue
            self._segundo_pintado = ahora.second
            self._poner_la_hora(ahora)
            try:
                self.hueco_reloj.update()
                self.reloj.update()
                self.reloj_ampm.update()
                self.reloj_24h.update()
            except Exception:
                # La pantalla ya no está en la ventana: se para y ya está.
                self._vivo = False
                return

    def _poner_la_hora(self, ahora: datetime) -> None:
        """Deja la hora puesta en el reloj dibujado y en los dos textos.

        LOS DOS FORMATOS A LA VEZ los pidió el usuario. Le dije que no lo
        recomendaba —es la misma información dos veces— y aun así los quiere, así
        que van los dos: el de doce horas manda, en grande, y el de veinticuatro
        va detrás en pequeño y apagado para que no compita.
        """
        momento = ahora.time()
        self.hueco_reloj.content = reloj.dibujar(self.paleta, momento)
        numero, ampm = reloj.texto_12h(momento)
        self.reloj.value = numero
        self.reloj_ampm.value = ampm
        self.reloj_24h.value = f"24h · {reloj.texto_24h(momento)}"

    def cerrar(self) -> None:
        """La llama la ventana al cambiar de sección, para parar el reloj."""
        self._vivo = False

    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            self.dia = repositorio_dias.abierto(conexion)
            self.hoy = self.dia.jornada
            # SOLO EL DIA DE AYER, y lo pidio el usuario asi: "aca solo debe
            # aparecer el dia anterior; para ver el resto se debe entrar al mes".
            # Tiene sentido: el Dashboard es para hoy, y el unico dia de antes
            # que sigue pesando es el que acabas de cerrar. Los demas se miran
            # en el calendario, que es donde estan todos y ademas ordenados.
            #
            # SE PIDEN DOS Y SE QUITA EL ABIERTO: los dias vienen del mas nuevo
            # al mas viejo, y el primero siempre es el de hoy, que esta abierto.
            # De los dos, queda uno: el anterior.
            self.dias_cerrados = [
                uno for uno in repositorio_dias.listar(conexion, limite=2)
                if not uno.abierto
            ]
            self.principal = leer_moneda_principal(conexion)
            self.habitos = repositorio_habitos.listar(conexion)
            self.tareas = repositorio_tareas.listar_del_dia(conexion, self.hoy)
            movimientos = repositorio_movimientos.listar(
                conexion, desde=self.hoy, hasta=self.hoy
            )
            nombres = {
                una.id: una.nombre
                for una in repositorio_categorias.listar(conexion)
            }
            self.horario_semanal = repositorio_horario.leer_horario(conexion)
            # DE EDUCACION SOLO LO QUE SE ENSENA AQUI: lo de hoy y lo que
            # viene. El Dashboard no es otra pantalla de Educacion; es el
            # resumen, y pedir el historial entero para ensenar tres lineas
            # seria trabajo tirado en cada repintado.
            self.materias_estudio = repositorio_educacion.listar_materias(conexion)
            self.estudio = repositorio_educacion.listar_eventos(
                conexion, self.hoy - timedelta(days=DIAS_ATRASADOS), self.hoy
                + timedelta(days=DIAS_DE_LA_SEMANA_QUE_VIENE)
            )
            objetivos = repositorio_objetivos.listar(conexion)
            aportaciones = repositorio_objetivos.todas_las_aportaciones(conexion)
        # Solo los ABIERTOS: lo cumplido baja y deja de aparecer aquí, como se
        # pidió. Un panel que sigue recordándote lo que ya conseguiste deja de
        # ser un panel de lo que tienes por delante.
        self.porques = [
            uno
            for uno in (
                avance_objetivo(uno, aportaciones.get(uno.id, []), self.hoy)
                for uno in objetivos
            )
            if uno.estado is EstadoObjetivo.ABIERTO and uno.objetivo.porque
        ]
        self.reparto = por_categoria(movimientos, nombres, principal=self.principal)
        self.movimientos = movimientos

        ahora = datetime.now()
        self._segundo_pintado = ahora.second
        self._poner_la_hora(ahora)

        piezas: list[ft.Control] = [self._cabecera()]
        if self.porques:
            piezas.append(self._tarjeta_porques())
        piezas += [
            self._fila_de_arriba(),
            self._tarjeta_horario(),
            self._tarjeta_tareas(),
        ]
        # LOS DIAS ANTERIORES, si hay alguno. La tarjeta se devuelve a None
        # cuando no hay ninguno cerrado, y entonces ni se monta.
        dias_atras = self._tarjeta_cerrar_el_dia()
        if dias_atras is not None:
            piezas.append(dias_atras)
        self.pintar(piezas)

    # ----------------------------------------------------------------------
    # Cabecera: fecha a la izquierda, hora a la derecha
    # ----------------------------------------------------------------------

    def _cabecera(self) -> ft.Control:
        """La fecha a la izquierda y el reloj a la derecha.

        LA FECHA VA EN DOS ALTURAS: el número en la serif de los titulares, y
        debajo en versalitas pequeñas el día de la semana, el mes escrito y el
        año. Lo pidió así el usuario. La gracia es que el número se lee de lejos
        y las letras dicen lo que el número no puede decir: si hoy es sábado.
        """
        return ft.Row(
            [
                ft.Column(
                    [
                        ft.Text(
                            self.hoy.strftime("%d/%m/%Y"),
                            size=estilo.TITULAR,
                            color=self.paleta.ink,
                            font_family=self.paleta.titular,
                        ),
                        ft.Text(
                            _dia_largo(self.hoy).upper(),
                            size=estilo.ROTULO,
                            weight=ft.FontWeight.W_600,
                            color=self.paleta.muted,
                        ),
                        # LA FRASE DEL TEMA. Es lo ÚNICO que cambia de palabras
                        # al cambiar de estilo: ver interfaz/lema.py, donde está
                        # escrito por qué no cambia nada más.
                        ft.Text(
                            lema.de(self.paleta.tema),
                            size=estilo.TEXTO_TARJETA,
                            color=self.paleta.ink_soft,
                            font_family=self.paleta.titular,
                        ),
                        # EL NUMERO DEL DIA, que es el que manda desde que los
                        # cierra el usuario: la fecha del calendario y el dia de
                        # la aplicacion son dos cosas distintas, y esta es la
                        # que dice por cual vas.
                        ft.Text(
                            f"DÍA {self.dia.numero}",
                            size=estilo.ROTULO,
                            weight=ft.FontWeight.W_600,
                            color=self.paleta.acento,
                        ),
                    ],
                    spacing=2,
                    tight=True,
                    expand=True,
                ),
                ft.Row(
                    [
                        self.hueco_reloj,
                        ft.Column(
                            [
                                ft.Row(
                                    [self.reloj, self.reloj_ampm],
                                    spacing=5,
                                    tight=True,
                                    vertical_alignment=ft.CrossAxisAlignment.END,
                                ),
                                self.reloj_24h,
                            ],
                            spacing=0,
                            tight=True,
                            horizontal_alignment=ft.CrossAxisAlignment.START,
                        ),
                    ],
                    spacing=10,
                    tight=True,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                # AL LADO DEL RELOJ Y ARRIBA DEL TODO, y lo pidió el usuario ahí.
                #
                # LO TENÍA ABAJO A PROPÓSITO —cerrar el día no se deshace y un
                # botón arriba se toca sin querer— y aquí arriba esa protección
                # la hace la ventanita, que sigue exigiendo elegir una nota y
                # escribir la reflexión antes de cerrar nada.
                componentes.boton(
                    self.paleta,
                    "Finalizar día",
                    icono=ft.Icons.NIGHTS_STAY_OUTLINED,
                    principal=True,
                    al_pulsar=lambda _: dialogo_cierre.abrir(
                        self.pagina, self.paleta, self.refrescar
                    ),
                ),
            ],
            spacing=12,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _tarjeta_cerrar_el_dia(self) -> ft.Control | None:
        """Los últimos días cerrados, con su nota y su reflexión.

        EL BOTÓN DE FINALIZAR YA NO ESTÁ AQUÍ: se subió al lado del reloj porque
        lo pidió el usuario. Lo que se queda es lo otro que pidió —"que los días
        anteriores sigan siendo accesibles con su valoración y reflexión"— y
        este es su sitio natural.

        DEVUELVE None SI NO HAY NINGUNO CERRADO. Una tarjeta vacía que dice
        "aquí saldrán tus días" es ruido el primer día y ruido para siempre si
        nunca cierras ninguno.
        """
        if not self.dias_cerrados:
            return None

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Días anteriores",
                        f"vas por el día {self.dia.numero}",
                    ),
                    *[self._fila_dia_cerrado(uno) for uno in self.dias_cerrados],
                    ft.Text(
                        "Toca para ver el mes entero",
                        size=estilo.ROTULO,
                        color=self.paleta.acento,
                    ),
                ],
                spacing=12,
                tight=True,
            ),
            # LA TARJETA ENTERA ES EL BOTÓN, no un enlace pequeño en una
            # esquina: es el sitio donde el usuario ya mira los días de antes, y
            # lo pidió así —"el lugar está bien, si yo hago un clic ahí tengo
            # que entrar a un apartado donde se va a ver todo el mes"—.
            al_pulsar=lambda _: resumen_mensual.abrir(self.pagina, self.paleta),
        )

    def _fila_dia_cerrado(self, dia) -> ft.Control:
        """Un dia ya cerrado, con su nota y su reflexion."""
        return ft.Column(
            [
                ft.Row(
                    [
                        ft.Text(
                            f"Día {dia.numero}",
                            size=estilo.TEXTO_APOYO,
                            weight=ft.FontWeight.W_600,
                            color=self.paleta.ink,
                            expand=True,
                        ),
                        ft.Text(
                            f"{dia.valoracion}/10",
                            size=estilo.TEXTO_APOYO,
                            weight=ft.FontWeight.W_600,
                            color=self.paleta.acento,
                        ),
                    ],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                ft.Text(
                    dia.reflexion,
                    size=estilo.TEXTO_APOYO,
                    color=self.paleta.ink_soft,
                ),
                ft.Text(
                    "cerrado el "
                    + dia.cerrado_en.strftime("%d/%m a las %H:%M")
                    + f" · duró {dia.texto_duracion()}",
                    size=estilo.ROTULO,
                    color=self.paleta.muted,
                ),
            ],
            spacing=2,
            tight=True,
        )

    def _tarjeta_porques(self) -> ft.Control:
        """Por qué quieres cada objetivo. Todos los abiertos, uno debajo de otro.

        Lo eligió el usuario. Es lo primero que se lee cada mañana, y por eso va
        arriba del todo y con el texto entero: recortarlo con puntos suspensivos
        lo dejaría justo sin la parte que convence.

        Los cumplidos no salen: un panel que sigue recordándote lo que ya
        conseguiste deja de ser un panel de lo que tienes por delante.
        """
        filas = []
        for como_va in self.porques:
            objetivo = como_va.objetivo
            tono = self.paleta.color_de(objetivo.color)
            filas.append(
                ft.Row(
                    [
                        ft.Container(width=4, height=38, bgcolor=tono, border_radius=2),
                        ft.Column(
                            [
                                ft.Text(
                                    objetivo.porque,
                                    size=13,
                                    color=self.paleta.ink,
                                    italic=True,
                                ),
                                ft.Text(
                                    f"{objetivo.nombre} · {como_va.porcentaje} %",
                                    size=11,
                                    color=self.paleta.muted,
                                ),
                            ],
                            spacing=2,
                            tight=True,
                            expand=True,
                        ),
                    ],
                    spacing=10,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                )
            )

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta, "Por qué lo estás haciendo", None
                    ),
                    ft.Column(filas, spacing=14),
                ],
                spacing=12,
            ),
        )

    def _fila_de_arriba(self) -> ft.Control:
        """Los hábitos a un lado; al otro, las tres tarjetas cortas apiladas.

        POR QUÉ ASÍ Y NO EN DOS FILAS DE DOS, que es como estaba: la tarjeta de
        hábitos CRECE con cada hábito que tengas —una fila por cada uno— mientras
        que las de gastos, gimnasio y educación miden casi siempre lo mismo.
        Emparejando hábitos con una sola tarjeta corta, la diferencia de altura
        se quedaba en negro a la derecha, y era el hueco más grande de toda la
        aplicación.

        Apiladas, las tres cortas suman una altura parecida a la de los hábitos y
        el hueco desaparece sin haber inventado nada que enseñar: son las mismas
        tarjetas de siempre, colocadas donde caben.

        NO SE LES PONE `expand` PARA IGUALARLAS DEL TODO. Es lo primero que
        apetece hacer y deja la pantalla EN BLANCO: esto cuelga de una columna
        con scroll, o sea de altura sin límite, y ahí no hay alto que repartir.
        Lo comprueba herramientas/revisar_diseno.py en cada pasada.

        En ventanas estrechas se apila todo solo: es lo que hace ResponsiveRow, y
        sin eso las tarjetas se estrujarían hasta no poder leerse.
        """
        cortas = ft.Column(
            [
                self._tarjeta_gastos(),
                self._tarjeta_gimnasio(),
                self._tarjeta_educacion(),
            ],
            spacing=16,
        )

        # DEBAJO DE LOS HÁBITOS, «¿CÓMO VOY ESTE MES?»: lo pidió el usuario como
        # un vistazo, sin tener que entrar en Hábitos. Los números salen del
        # mismo sitio que la pestaña Estadísticas, así que coinciden siempre.
        izquierda: list[ft.Control] = [self._tarjeta_habitos()]
        progreso = self._tarjeta_progreso_habitos()
        if progreso is not None:
            izquierda.append(progreso)

        return ft.ResponsiveRow(
            [
                ft.Container(
                    content=ft.Column(izquierda, spacing=16),
                    col={"xs": 12, "lg": 6},
                ),
                ft.Container(content=cortas, col={"xs": 12, "lg": 6}),
            ],
            spacing=16,
            run_spacing=16,
        )

    def _tarjeta_progreso_habitos(self) -> ft.Control | None:
        """El resumen compacto del mes. Sin hábitos no hay nada que resumir."""
        with conectado() as conexion:
            resumen = estadisticas_habitos.resumen(conexion, Periodo.MES, self.hoy)
        if not resumen.habitos:
            return None
        return vista_estadisticas.tarjeta_compacta(self.paleta, resumen)

    def _tarjeta_gimnasio(self) -> ft.Control:
        """Lo del gimnasio hoy: lo que toca, o cómo llevas el entreno.

        TRES ESTADOS Y NINGUNO INVENTADO:
          - entrenando: las series que llevas marcadas y el volumen, de verdad.
          - toca y no has empezado: el nombre del día y cuántos ejercicios.
          - descanso o día sin asignar: se dice, y ya está.

        SÍ HAY BOTÓN DE EMPEZAR, y esto es un cambio de opinión del usuario:
        antes no lo había a propósito —«esa decisión se toma en el gimnasio
        mirando lo que toca»— y pidió ponerlo aquí también, «en la zona de
        entrenamientos, no en cualquier lugar». Tiene sentido: esta tarjeta ya te
        dice lo que toca hoy, así que la decisión ya la has tomado al leerla.

        EL BOTÓN ES EL MISMO CÓDIGO QUE EL DE RUTINA, no una segunda copia: si
        fueran dos, un día uno empezaría a crear la sesión de otra forma. Vive
        en empezar_entreno.py.

        CON VARIOS ENTRENOS EN EL DÍA (uno por bloque), las cifras son las de
        todos: es el resumen del día, no de un entreno.
        """

        with conectado() as conexion:
            rutina = repositorio_gimnasio.leer_rutina(conexion)
            planeado = dia_de(self.hoy, rutina)
            actual = empezar_entreno.estado(conexion, self.hoy, planeado)

        if actual.series_hechas:
            cuerpo: list[ft.Control] = [
                ft.Row(
                    [
                        componentes.cifra(
                            self.paleta, "Series", str(actual.series_hechas)
                        ),
                        componentes.cifra(
                            self.paleta, "Volumen", texto_volumen(actual.volumen)
                        ),
                    ],
                    spacing=32,
                )
            ]
            if actual.pendientes:
                cuerpo.append(ft.Text(
                    "Falta: " + ", ".join(uno.nombre for uno in actual.pendientes),
                    size=estilo.TEXTO_APOYO, color=self.paleta.muted,
                ))
            subtitulo = " · ".join(uno.titulo() for uno in actual.sesiones)
        elif actual.sesiones:
            cuerpo = [
                ft.Text(
                    "Entreno abierto y sin ninguna serie marcada todavía.",
                    size=estilo.TEXTO,
                    color=self.paleta.ink_soft,
                )
            ]
            subtitulo = actual.sesiones[-1].titulo()
        elif planeado.es_descanso:
            cuerpo = [
                ft.Text(
                    "Hoy toca descansar. Descansar también es entrenar.",
                    size=estilo.TEXTO,
                    color=self.paleta.ink_soft,
                )
            ]
            subtitulo = "Descanso"
        elif planeado.hay_entreno:
            cuerpo = [
                ft.Text(
                    f"{len(planeado.ejercicios)} ejercicios planeados. Sin empezar.",
                    size=estilo.TEXTO,
                    color=self.paleta.ink_soft,
                ),
                ft.Text(
                    " · ".join(
                        uno.nombre
                        for uno in sorted(planeado.ejercicios, key=lambda x: x.orden)
                    ),
                    size=estilo.TEXTO_APOYO,
                    color=self.paleta.muted,
                    max_lines=2,
                    overflow=ft.TextOverflow.ELLIPSIS,
                ),
            ]
            subtitulo = planeado.titulo()
        else:
            cuerpo = [
                ft.Text(
                    "Hoy no tienes nada asignado en la rutina.",
                    size=estilo.TEXTO,
                    color=self.paleta.muted,
                )
            ]
            subtitulo = None

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(self.paleta, "Gimnasio", subtitulo),
                    *cuerpo,
                    self._boton_de_entrenar(planeado, actual),
                ],
                spacing=12,
            ),
        )

    def _boton_de_entrenar(self, planeado, actual) -> ft.Control:
        """Empezar o seguir el entreno de hoy. Lo que dice y lo que hace lo
        decide empezar_entreno, el mismo que el botón de Rutina."""
        return componentes.boton(
            self.paleta,
            empezar_entreno.etiqueta(actual, planeado),
            icono=ft.Icons.PLAY_ARROW,
            principal=True,
            al_pulsar=lambda _: empezar_entreno.pulsar(
                self.pagina, self.paleta, self.hoy, planeado, self.al_entrenar
            ),
        )


    # ----------------------------------------------------------------------
    # Gastos del día
    # ----------------------------------------------------------------------

    def _tarjeta_gastos(self) -> ft.Control:
        piezas: list[ft.Control] = [
            componentes.cabecera_tarjeta(
                self.paleta,
                "Gastos de hoy",
                f"{len(self.movimientos)} movimientos"
                if self.movimientos
                else "sin movimientos",
            ),
            ft.Row(
                [
                    grafico_reparto.anillo(self.paleta, self.reparto),
                    ft.Container(
                        content=self._detalle_gastos(),
                        expand=True,
                    ),
                ],
                spacing=16,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        ]
        aviso = grafico_reparto.aviso_de_pendientes(self.paleta, self.reparto)
        if aviso is not None:
            piezas.append(aviso)
        piezas.append(self._apuntar_desde_aqui())
        return componentes.tarjeta(self.paleta, ft.Column(piezas, spacing=14))

    def _apuntar_desde_aqui(self) -> ft.Control:
        """Gasto e Ingreso sin salir del Dashboard.

        LO PIDIÓ EL USUARIO: apunta gastos a diario, y tener que ir a Finanzas
        cada vez para una cosa de diez segundos era el viaje más repetido de la
        aplicación.

        ABREN EL MISMO CARTEL QUE FINANZAS, no una copia: un gasto apuntado aquí
        tiene que ser idéntico a uno apuntado allí —misma categoría, misma
        moneda, mismas comprobaciones—. Con dos carteles, el día que se
        arreglara uno el otro seguiría con el fallo.

        VAN AL PIE Y NO JUNTO AL TÍTULO: en un móvil, el título más dos botones
        no caben en una línea. Y la fila salta de renglón en vez de estirarse,
        que es lo único que una fila así admite.
        """

        def apuntar(tipo: Tipo):
            return lambda _: dialogo_movimiento.abrir(
                self.pagina, tipo, self.paleta, self.refrescar
            )

        return ft.Row(
            [
                componentes.boton(
                    self.paleta,
                    "Gasto",
                    icono=ft.Icons.ARROW_DOWNWARD,
                    color_icono=self.paleta.negativo,
                    al_pulsar=apuntar(Tipo.GASTO),
                ),
                componentes.boton(
                    self.paleta,
                    "Ingreso",
                    icono=ft.Icons.ARROW_UPWARD,
                    color_icono=self.paleta.positivo,
                    al_pulsar=apuntar(Tipo.INGRESO),
                ),
            ],
            spacing=10,
            run_spacing=8,
            wrap=True,
        )

    def _detalle_gastos(self) -> ft.Control:
        if not self.reparto.hay_algo:
            return ft.Text(
                "Cuando apuntes un gasto, aparecerá aquí repartido por "
                "categorías.",
                size=12,
                color=self.paleta.muted,
            )
        return grafico_reparto.leyenda(self.paleta, self.reparto)


def _dia_largo(dia: date) -> str:
    """"Sábado · agosto · 2026" — lo que el número de la fecha no puede decir.

    VA DEBAJO DE "22/08/2026" y por eso no repite el día del mes: ahí arriba ya
    está. Lo que aporta es el día de la semana —que es lo que de verdad se
    pregunta uno— y el mes con su nombre, que se lee más rápido que "08".
    """
    return f"{DIAS[dia.weekday()]} · {MESES[dia.month - 1]} · {dia.year}"
