"""El Dashboard: el día de hoy. Lo que hay que hacer y cómo va.

LA DISPOSICIÓN LA DIBUJÓ EL USUARIO EN PAPEL, y es esta:

  fecha y hora arriba
  [ hábitos de hoy ]     [ resumen de gastos + círculo ]
  [ cosas a hacer, a lo ancho                          ]
  [ gimnasio ]           [ inversiones                 ]

POR QUÉ EL MARCADO VIVE AQUÍ Y NO EN HÁBITOS: son dos preguntas distintas. "¿Qué
me toca hoy?" se contesta cada mañana y necesita botones; "¿cómo llevo el año?"
se contesta de vez en cuando y necesita una foto. Tenerlas juntas obligaba a
elegir vista cada vez que abrías la app solo para marcar el agua.

TODO SE FECHA POR JORNADA, no por el reloj: marcar un hábito a las 3 de la
madrugada cuenta para la jornada que empezó ayer. Es la misma regla del dinero, y
para quien trabaja de noche es la diferencia entre una racha real y una racha
rota cada madrugada.

INVERSIONES DICE QUE NO HAY NADA. No tiene ni un dato aquí todavía y no finge
tenerlo: la tarjeta está para que se vea la forma final de la pantalla, con un
texto que dice claramente que aún no funciona. Un recuadro con números inventados
sería mucho peor que un recuadro que avisa.

EL GIMNASIO SÍ TIENE SU TARJETA, y enseña tres cosas distintas según el día: lo
que toca hoy si no has empezado, cómo llevas el entreno si estás en mitad de él,
o que hoy toca descansar. Los tres son datos de verdad leídos de la base; ninguno
se calcula ni se estima.
"""

from __future__ import annotations

import asyncio
from dataclasses import replace
from datetime import date, datetime

import flet as ft

from ..datos import repositorio_categorias, repositorio_habitos, repositorio_movimientos
from ..datos import repositorio_horario, repositorio_objetivos, repositorio_tareas
from ..datos.ajustes import leer_moneda_principal
from ..datos import repositorio_dias
from ..datos.bd import conectado
from ..dominio.habito import Franja, Habito
from ..dominio.semana import DIAS, MESES
from ..dominio.semana import texto_hora
from ..dominio.objetivo import Estado as EstadoObjetivo
from ..dominio.objetivo import avance as avance_objetivo
from ..dominio.reparto import por_categoria
from ..dominio.tarea import Tarea, ordenar as ordenar_tareas
from . import (
    dialogo_cierre,
    componentes,
    dialogo_habito,
    dialogo_tarea,
    estilo,
    grafico_reparto,
    reloj,
    resumen_mensual,
)
from .estilo import Paleta
from ..datos import repositorio_gimnasio
from ..dominio.rutina import dia_de
from ..dominio.sesion import desde_rutina, texto_volumen


ALTO_DE_LA_LISTA = 430
"""A cuanto alto tiene que llegar la lista de habitos, en pixeles.

DE DONDE SALE ESTE NUMERO: es lo que miden las tres tarjetas cortas de la
columna de al lado —gastos, gimnasio e inversiones— apiladas con sus huecos.
Haciendo que los habitos lleguen ahi, las dos columnas acaban a la misma altura
y no queda el rectangulo negro que hay que mirar todos los dias.

SE REPARTE ENTRE LOS HABITOS QUE HAYA, que es justo lo que pidio el usuario: con
uno, ese habito se ve grande; con dos, cada uno se queda con la mitad; con siete,
son mas bajitos pero llenan igual. Lo que NO se hace es pedirle a Flet que los
estire: esto cuelga de una columna con scroll y ahi no hay alto que repartir.
El calculo se hace aqui, en Python, con un numero concreto.

SI ALGUN DIA CAMBIAN LAS TARJETAS DE LA DERECHA, este numero se queda corto o
largo. Es el precio de repartir a mano; la alternativa —medir de verdad— Flet no
la ofrece desde Python."""

ALTO_MINIMO_HABITO = 54
"""Por debajo de esto la fila deja de leerse: no caben el nombre, la hora y la
barra. Con muchos habitos la tarjeta crece hacia abajo antes que apretarlos."""

ALTO_MAXIMO_HABITO = 108
"""Y por encima, una sola fila con doscientos pixeles de aire dentro parece un
fallo, no un diseno. Con uno o dos habitos sobrara algo de sitio; es preferible
a una fila gigante y hueca."""

SEGUNDOS_ENTRE_RELOJES = 1
"""Cada cuánto se repinta el reloj.

ERA VEINTE Y AHORA ES UNO por el segundero: una aguja que solo se mueve cada
veinte segundos no es un segundero, es un adorno que se teletransporta. Lo que se
repinta es SOLO el reloj —treinta y cuatro píxeles de lienzo—, no la pantalla
entera, y la cuenta se para sola al cambiar de sección."""
"""Cada cuánto se mira el reloj. Se comprueba tres veces por minuto y solo se
repinta cuando cambia el minuto: mirar la hora es gratis, repintar no."""


class PantallaDashboard(componentes.Pantalla):
    def __init__(self, pagina: ft.Page, paleta: Paleta, al_entrenar=None) -> None:
        super().__init__(pagina, paleta)
        # ABRIR LA PANTALLA DE ENTRENAR SUSTITUYE LA VENTANA ENTERA, y eso solo
        # lo sabe hacer quien la monto. Por eso se recibe de fuera.
        self.al_entrenar = al_entrenar
        self.franja: Franja | None = None  # None = todas
        # El reloj vive en un hueco que se rellena en cada tic: así se cambia
        # el dibujo sin reconstruir la cabecera entera.
        self.hueco_reloj = ft.Container(width=reloj.LADO, height=reloj.LADO)
        self.reloj = ft.Text(
            "",
            size=estilo.TEXTO_TARJETA,
            weight=ft.FontWeight.W_600,
            color=paleta.ink,
        )
        self.reloj_ampm = ft.Text(
            "", size=estilo.ROTULO, weight=ft.FontWeight.W_600, color=paleta.muted
        )
        self.reloj_24h = ft.Text("", size=estilo.ROTULO, color=paleta.muted)
        self._segundo_pintado: int | None = None
        self._vivo = True
        self.refrescar()

    def montada(self) -> None:
        super().montada()
        # El reloj solo empieza a correr cuando la pantalla está puesta: pedirle
        # a un control que se repinte antes de estar en la ventana revienta.
        self.pagina.run_task(self._tic_tac)

    async def _tic_tac(self) -> None:
        """Mantiene la hora al día mientras esta pantalla siga puesta.

        Se para sola al cambiar de sección (self._vivo). Sin eso, cada visita al
        Dashboard dejaría un reloj más corriendo por detrás para siempre.
        """
        while self._vivo:
            await asyncio.sleep(SEGUNDOS_ENTRE_RELOJES)
            if not self._vivo or not self._en_pagina:
                return
            ahora = datetime.now()
            if ahora.second == self._segundo_pintado:
                continue
            self._segundo_pintado = ahora.second
            self._poner_la_hora(ahora)
            try:
                self.hueco_reloj.update()
                self.reloj.update()
                self.reloj_ampm.update()
                self.reloj_24h.update()
            except Exception:
                # La pantalla ya no está en la ventana: se para y ya está.
                self._vivo = False
                return

    def _poner_la_hora(self, ahora: datetime) -> None:
        """Deja la hora puesta en el reloj dibujado y en los dos textos.

        LOS DOS FORMATOS A LA VEZ los pidió el usuario. Le dije que no lo
        recomendaba —es la misma información dos veces— y aun así los quiere, así
        que van los dos: el de doce horas manda, en grande, y el de veinticuatro
        va detrás en pequeño y apagado para que no compita.
        """
        momento = ahora.time()
        self.hueco_reloj.content = reloj.dibujar(self.paleta, momento)
        numero, ampm = reloj.texto_12h(momento)
        self.reloj.value = numero
        self.reloj_ampm.value = ampm
        self.reloj_24h.value = f"24h · {reloj.texto_24h(momento)}"

    def cerrar(self) -> None:
        """La llama la ventana al cambiar de sección, para parar el reloj."""
        self._vivo = False

    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            self.dia = repositorio_dias.abierto(conexion)
            self.hoy = self.dia.jornada
            # SOLO EL DIA DE AYER, y lo pidio el usuario asi: "aca solo debe
            # aparecer el dia anterior; para ver el resto se debe entrar al mes".
            # Tiene sentido: el Dashboard es para hoy, y el unico dia de antes
            # que sigue pesando es el que acabas de cerrar. Los demas se miran
            # en el calendario, que es donde estan todos y ademas ordenados.
            #
            # SE PIDEN DOS Y SE QUITA EL ABIERTO: los dias vienen del mas nuevo
            # al mas viejo, y el primero siempre es el de hoy, que esta abierto.
            # De los dos, queda uno: el anterior.
            self.dias_cerrados = [
                uno for uno in repositorio_dias.listar(conexion, limite=2)
                if not uno.abierto
            ]
            self.principal = leer_moneda_principal(conexion)
            self.habitos = repositorio_habitos.listar(conexion)
            self.tareas = repositorio_tareas.listar_del_dia(conexion, self.hoy)
            movimientos = repositorio_movimientos.listar(
                conexion, desde=self.hoy, hasta=self.hoy
            )
            nombres = {
                una.id: una.nombre
                for una in repositorio_categorias.listar(conexion)
            }
            self.horario_semanal = repositorio_horario.leer_horario(conexion)
            objetivos = repositorio_objetivos.listar(conexion)
            aportaciones = repositorio_objetivos.todas_las_aportaciones(conexion)
        # Solo los ABIERTOS: lo cumplido baja y deja de aparecer aquí, como se
        # pidió. Un panel que sigue recordándote lo que ya conseguiste deja de
        # ser un panel de lo que tienes por delante.
        self.porques = [
            uno
            for uno in (
                avance_objetivo(uno, aportaciones.get(uno.id, []), self.hoy)
                for uno in objetivos
            )
            if uno.estado is EstadoObjetivo.ABIERTO and uno.objetivo.porque
        ]
        self.reparto = por_categoria(movimientos, nombres, principal=self.principal)
        self.movimientos = movimientos

        ahora = datetime.now()
        self._segundo_pintado = ahora.second
        self._poner_la_hora(ahora)

        piezas: list[ft.Control] = [self._cabecera()]
        if self.porques:
            piezas.append(self._tarjeta_porques())
        piezas += [
            self._fila_de_arriba(),
            self._tarjeta_horario(),
            self._tarjeta_tareas(),
        ]
        # LOS DIAS ANTERIORES, si hay alguno. La tarjeta se devuelve a None
        # cuando no hay ninguno cerrado, y entonces ni se monta.
        dias_atras = self._tarjeta_cerrar_el_dia()
        if dias_atras is not None:
            piezas.append(dias_atras)
        self.pintar(piezas)

    # ----------------------------------------------------------------------
    # Cabecera: fecha a la izquierda, hora a la derecha
    # ----------------------------------------------------------------------

    def _cabecera(self) -> ft.Control:
        """La fecha a la izquierda y el reloj a la derecha.

        LA FECHA VA EN DOS ALTURAS: el número en la serif de los titulares, y
        debajo en versalitas pequeñas el día de la semana, el mes escrito y el
        año. Lo pidió así el usuario. La gracia es que el número se lee de lejos
        y las letras dicen lo que el número no puede decir: si hoy es sábado.
        """
        return ft.Row(
            [
                ft.Column(
                    [
                        ft.Text(
                            self.hoy.strftime("%d/%m/%Y"),
                            size=estilo.TITULAR,
                            color=self.paleta.ink,
                            font_family=self.paleta.titular,
                        ),
                        ft.Text(
                            _dia_largo(self.hoy).upper(),
                            size=estilo.ROTULO,
                            weight=ft.FontWeight.W_600,
                            color=self.paleta.muted,
                        ),
                        # EL NUMERO DEL DIA, que es el que manda desde que los
                        # cierra el usuario: la fecha del calendario y el dia de
                        # la aplicacion son dos cosas distintas, y esta es la
                        # que dice por cual vas.
                        ft.Text(
                            f"DÍA {self.dia.numero}",
                            size=estilo.ROTULO,
                            weight=ft.FontWeight.W_600,
                            color=self.paleta.acento,
                        ),
                    ],
                    spacing=2,
                    tight=True,
                    expand=True,
                ),
                ft.Row(
                    [
                        self.hueco_reloj,
                        ft.Column(
                            [
                                ft.Row(
                                    [self.reloj, self.reloj_ampm],
                                    spacing=5,
                                    tight=True,
                                    vertical_alignment=ft.CrossAxisAlignment.END,
                                ),
                                self.reloj_24h,
                            ],
                            spacing=0,
                            tight=True,
                            horizontal_alignment=ft.CrossAxisAlignment.START,
                        ),
                    ],
                    spacing=10,
                    tight=True,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                # AL LADO DEL RELOJ Y ARRIBA DEL TODO, y lo pidió el usuario ahí.
                #
                # LO TENÍA ABAJO A PROPÓSITO —cerrar el día no se deshace y un
                # botón arriba se toca sin querer— y aquí arriba esa protección
                # la hace la ventanita, que sigue exigiendo elegir una nota y
                # escribir la reflexión antes de cerrar nada.
                componentes.boton(
                    self.paleta,
                    "Finalizar día",
                    icono=ft.Icons.NIGHTS_STAY_OUTLINED,
                    principal=True,
                    al_pulsar=lambda _: dialogo_cierre.abrir(
                        self.pagina, self.paleta, self.refrescar
                    ),
                ),
            ],
            spacing=12,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _tarjeta_cerrar_el_dia(self) -> ft.Control | None:
        """Los últimos días cerrados, con su nota y su reflexión.

        EL BOTÓN DE FINALIZAR YA NO ESTÁ AQUÍ: se subió al lado del reloj porque
        lo pidió el usuario. Lo que se queda es lo otro que pidió —"que los días
        anteriores sigan siendo accesibles con su valoración y reflexión"— y
        este es su sitio natural.

        DEVUELVE None SI NO HAY NINGUNO CERRADO. Una tarjeta vacía que dice
        "aquí saldrán tus días" es ruido el primer día y ruido para siempre si
        nunca cierras ninguno.
        """
        if not self.dias_cerrados:
            return None

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Días anteriores",
                        f"vas por el día {self.dia.numero}",
                    ),
                    *[self._fila_dia_cerrado(uno) for uno in self.dias_cerrados],
                    ft.Text(
                        "Toca para ver el mes entero",
                        size=estilo.ROTULO,
                        color=self.paleta.acento,
                    ),
                ],
                spacing=12,
                tight=True,
            ),
            # LA TARJETA ENTERA ES EL BOTÓN, no un enlace pequeño en una
            # esquina: es el sitio donde el usuario ya mira los días de antes, y
            # lo pidió así —"el lugar está bien, si yo hago un clic ahí tengo
            # que entrar a un apartado donde se va a ver todo el mes"—.
            al_pulsar=lambda _: resumen_mensual.abrir(self.pagina, self.paleta),
        )

    def _fila_dia_cerrado(self, dia) -> ft.Control:
        """Un dia ya cerrado, con su nota y su reflexion."""
        return ft.Column(
            [
                ft.Row(
                    [
                        ft.Text(
                            f"Día {dia.numero}",
                            size=estilo.TEXTO_APOYO,
                            weight=ft.FontWeight.W_600,
                            color=self.paleta.ink,
                            expand=True,
                        ),
                        ft.Text(
                            f"{dia.valoracion}/10",
                            size=estilo.TEXTO_APOYO,
                            weight=ft.FontWeight.W_600,
                            color=self.paleta.acento,
                        ),
                    ],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                ft.Text(
                    dia.reflexion,
                    size=estilo.TEXTO_APOYO,
                    color=self.paleta.ink_soft,
                ),
                ft.Text(
                    "cerrado el "
                    + dia.cerrado_en.strftime("%d/%m a las %H:%M")
                    + f" · duró {dia.texto_duracion()}",
                    size=estilo.ROTULO,
                    color=self.paleta.muted,
                ),
            ],
            spacing=2,
            tight=True,
        )

    def _tarjeta_porques(self) -> ft.Control:
        """Por qué quieres cada objetivo. Todos los abiertos, uno debajo de otro.

        Lo eligió el usuario. Es lo primero que se lee cada mañana, y por eso va
        arriba del todo y con el texto entero: recortarlo con puntos suspensivos
        lo dejaría justo sin la parte que convence.

        Los cumplidos no salen: un panel que sigue recordándote lo que ya
        conseguiste deja de ser un panel de lo que tienes por delante.
        """
        filas = []
        for como_va in self.porques:
            objetivo = como_va.objetivo
            tono = self.paleta.color_de(objetivo.color)
            filas.append(
                ft.Row(
                    [
                        ft.Container(width=4, height=38, bgcolor=tono, border_radius=2),
                        ft.Column(
                            [
                                ft.Text(
                                    objetivo.porque,
                                    size=13,
                                    color=self.paleta.ink,
                                    italic=True,
                                ),
                                ft.Text(
                                    f"{objetivo.nombre} · {como_va.porcentaje} %",
                                    size=11,
                                    color=self.paleta.muted,
                                ),
                            ],
                            spacing=2,
                            tight=True,
                            expand=True,
                        ),
                    ],
                    spacing=10,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                )
            )

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta, "Por qué lo estás haciendo", None
                    ),
                    ft.Column(filas, spacing=14),
                ],
                spacing=12,
            ),
        )

    def _fila_de_arriba(self) -> ft.Control:
        """Los hábitos a un lado; al otro, las tres tarjetas cortas apiladas.

        POR QUÉ ASÍ Y NO EN DOS FILAS DE DOS, que es como estaba: la tarjeta de
        hábitos CRECE con cada hábito que tengas —una fila por cada uno— mientras
        que las de gastos, gimnasio e inversiones miden casi siempre lo mismo.
        Emparejando hábitos con una sola tarjeta corta, la diferencia de altura
        se quedaba en negro a la derecha, y era el hueco más grande de toda la
        aplicación.

        Apiladas, las tres cortas suman una altura parecida a la de los hábitos y
        el hueco desaparece sin haber inventado nada que enseñar: son las mismas
        tarjetas de siempre, colocadas donde caben.

        NO SE LES PONE `expand` PARA IGUALARLAS DEL TODO. Es lo primero que
        apetece hacer y deja la pantalla EN BLANCO: esto cuelga de una columna
        con scroll, o sea de altura sin límite, y ahí no hay alto que repartir.
        Lo comprueba herramientas/revisar_diseno.py en cada pasada.

        En ventanas estrechas se apila todo solo: es lo que hace ResponsiveRow, y
        sin eso las tarjetas se estrujarían hasta no poder leerse.
        """
        cortas = ft.Column(
            [
                self._tarjeta_gastos(),
                self._tarjeta_gimnasio(),
                self._tarjeta_pendiente(
                    "Inversiones",
                    ft.Icons.TRENDING_UP,
                    "Próximamente. No hay ninguna inversión guardada todavía.",
                ),
            ],
            spacing=16,
        )

        return ft.ResponsiveRow(
            [
                ft.Container(
                    content=self._tarjeta_habitos(), col={"xs": 12, "lg": 6}
                ),
                ft.Container(content=cortas, col={"xs": 12, "lg": 6}),
            ],
            spacing=16,
            run_spacing=16,
        )

    def _tarjeta_gimnasio(self) -> ft.Control:
        """Lo del gimnasio hoy: lo que toca, o cómo llevas el entreno.

        TRES ESTADOS Y NINGUNO INVENTADO:
          - entrenando: las series que llevas marcadas y el volumen, de verdad.
          - toca y no has empezado: el nombre del día y cuántos ejercicios.
          - descanso o día sin asignar: se dice, y ya está.

        SÍ HAY BOTÓN DE EMPEZAR, y esto es un cambio de opinión del usuario:
        antes no lo había a propósito —«esa decisión se toma en el gimnasio
        mirando lo que toca»— y pidió ponerlo aquí también, «en la zona de
        entrenamientos, no en cualquier lugar». Tiene sentido: esta tarjeta ya te
        dice lo que toca hoy, así que la decisión ya la has tomado al leerla.

        EL BOTÓN ES EL MISMO CÓDIGO QUE EL DE RUTINA, no una segunda copia: si
        fueran dos, un día uno empezaría a crear la sesión de otra forma.
        """

        with conectado() as conexion:
            rutina = repositorio_gimnasio.leer_rutina(conexion)
            sesion = repositorio_gimnasio.sesion_de(conexion, self.hoy)

        planeado = dia_de(self.hoy, rutina)

        if sesion is not None and sesion.entrenado:
            cuerpo: list[ft.Control] = [
                ft.Row(
                    [
                        componentes.cifra(
                            self.paleta, "Series", str(sesion.series_hechas)
                        ),
                        componentes.cifra(
                            self.paleta, "Volumen", texto_volumen(sesion.volumen)
                        ),
                    ],
                    spacing=32,
                )
            ]
            subtitulo = sesion.titulo()
        elif sesion is not None:
            cuerpo = [
                ft.Text(
                    "Entreno abierto y sin ninguna serie marcada todavía.",
                    size=estilo.TEXTO,
                    color=self.paleta.ink_soft,
                )
            ]
            subtitulo = sesion.titulo()
        elif planeado.es_descanso:
            cuerpo = [
                ft.Text(
                    "Hoy toca descansar. Descansar también es entrenar.",
                    size=estilo.TEXTO,
                    color=self.paleta.ink_soft,
                )
            ]
            subtitulo = "Descanso"
        elif planeado.hay_entreno:
            cuerpo = [
                ft.Text(
                    f"{len(planeado.ejercicios)} ejercicios planeados. Sin empezar.",
                    size=estilo.TEXTO,
                    color=self.paleta.ink_soft,
                ),
                ft.Text(
                    " · ".join(
                        uno.nombre
                        for uno in sorted(planeado.ejercicios, key=lambda x: x.orden)
                    ),
                    size=estilo.TEXTO_APOYO,
                    color=self.paleta.muted,
                    max_lines=2,
                    overflow=ft.TextOverflow.ELLIPSIS,
                ),
            ]
            subtitulo = planeado.titulo()
        else:
            cuerpo = [
                ft.Text(
                    "Hoy no tienes nada asignado en la rutina.",
                    size=estilo.TEXTO,
                    color=self.paleta.muted,
                )
            ]
            subtitulo = None

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(self.paleta, "Gimnasio", subtitulo),
                    *cuerpo,
                    self._boton_de_entrenar(planeado, sesion),
                ],
                spacing=12,
            ),
        )

    def _boton_de_entrenar(self, planeado, sesion) -> ft.Control:
        """Empezar o seguir el entreno de hoy, desde el resumen.

        DICE "SEGUIR" SI YA EMPEZASTE. Un segundo "Empezar" hace pensar que se
        borra lo que llevas hecho, y con eso en la cabeza nadie lo pulsa.
        """
        if sesion is not None and not sesion.en_marcha and sesion.segundos:
            etiqueta = "Abrir el entreno de hoy"
        elif sesion is not None:
            etiqueta = "Seguir entrenando"
        elif planeado.hay_entreno:
            etiqueta = "Empezar entreno"
        else:
            etiqueta = "Entrenar igualmente"

        return componentes.boton(
            self.paleta,
            etiqueta,
            icono=ft.Icons.PLAY_ARROW,
            principal=True,
            al_pulsar=lambda _: self._entrenar(planeado, sesion),
        )

    def _entrenar(self, planeado, sesion) -> None:
        """Crea la sesión si hace falta y abre la pantalla de entrenar.

        UN ENTRENO YA EMPEZADO NO SE VUELVE A CREAR: se abre el que hay. Crear
        otro perdería las series ya marcadas.
        """
        if self.al_entrenar is None:
            return
        if sesion is None:
            with conectado() as conexion:
                repositorio_gimnasio.guardar_sesion(
                    conexion,
                    replace(
                        desde_rutina(planeado, self.hoy), empezada_en=datetime.now()
                    ),
                )
        self.al_entrenar(self.hoy)

    def _tarjeta_horario(self) -> ft.Control:
        """Lo que tienes hoy, solo las horas con algo.

        SOLO LAS QUE TIENEN ALGO, y esto es una CORRECCIÓN. Antes salía la
        columna entera —las diecisiete horas de la franja, la mayoría con un
        guion— porque así lo había pedido el usuario para no esconder los
        huecos. Al verlo funcionando cambió de idea: "que se vea más chico, eso
        no tiene que ocupar todo, solo que se vean las tareas".

        Y tiene razón: el Dashboard es el resumen del día, no el horario. Para
        ver los huecos ya está la sección Horario, que enseña la rejilla entera;
        aquí catorce líneas de guiones empujaban hacia abajo todo lo demás y no
        contaban nada.

        CUENTAN TAMBIÉN LAS HORAS SOLO PINTADAS: una hora marcada de verde sin
        nada escrito también es algo que tienes puesto, y saltársela sería
        contradecir lo que se ve en la otra pantalla.

        LA HORA ACTUAL VA MARCADA cuando tiene algo: es lo que convierte una
        lista en un "vas por aquí".
        """
        dia = self.hoy.weekday()
        con_algo = self.horario_semanal.con_algo_de(dia)

        cuerpo: list[ft.Control] = [
            componentes.cabecera_tarjeta(self.paleta, "Horario de hoy")
        ]

        if not con_algo:
            # NO SE INVENTA NADA para rellenar el hueco: se dice que está vacío
            # y dónde se escribe. Es la norma del usuario y aquí aplica entera.
            cuerpo.append(
                componentes.aviso_vacio(
                    self.paleta,
                    "Hoy no tienes nada escrito en el horario. Se escribe en la "
                    "sección Horario, casilla por casilla.",
                )
            )
            return componentes.tarjeta(self.paleta, ft.Column(cuerpo, spacing=12))

        ahora = datetime.now().hour
        for casilla in con_algo:
            cuerpo.append(
                self._fila_de_horario(
                    casilla.hora,
                    casilla.texto,
                    casilla.color,
                    es_ahora=casilla.hora == ahora,
                )
            )
        return componentes.tarjeta(self.paleta, ft.Column(cuerpo, spacing=2))

    def _fila_de_horario(
        self, hora: int, texto: str, pintada: str | None, *, es_ahora: bool
    ) -> ft.Control:
        """Una hora del día, con su color si lo tiene.

        LA HORA ACTUAL MANDA SOBRE EL COLOR: si son las diez y las diez están
        pintadas de verde, gana el marcado de "vas por aquí". Saber dónde estás
        es más urgente que saber de qué color lo pintaste, y dos marcados a la
        vez no se distinguirían de ninguno.
        """
        if es_ahora:
            fondo = self.paleta.acento
            tinta = self.paleta.acento_ink
        elif pintada is not None:
            fondo = estilo.pastel(pintada, self.paleta)
            tinta = estilo.tinta_sobre_pastel(self.paleta)
        else:
            fondo = None
            tinta = self.paleta.ink if texto else self.paleta.muted

        return ft.Container(
            content=ft.Row(
                [
                    ft.Container(
                        content=ft.Text(
                            texto_hora(hora), size=estilo.TEXTO_APOYO, color=tinta
                        ),
                        width=48,
                    ),
                    # Sin guion de relleno: aqui solo salen horas con algo,
                    # asi que siempre hay texto o, como poco, color.
                    ft.Text(texto, size=13, color=tinta, expand=True),
                ],
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor=fondo,
            border_radius=6,
            padding=ft.Padding.symmetric(horizontal=8, vertical=4),
        )

    def _tarjeta_pendiente(self, titulo: str, icono, texto: str) -> ft.Control:
        """Una tarjeta que dice claramente que aún no hay nada.

        No lleva ningún botón: un botón que no hace nada es peor que no tenerlo,
        porque lo pulsas, no pasa nada y ya no te fías del resto de la pantalla.
        """
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(self.paleta, titulo, None),
                    ft.Row(
                        [
                            ft.Icon(icono, size=20, color=self.paleta.muted),
                            ft.Text(
                                texto, size=12, color=self.paleta.muted, expand=True
                            ),
                        ],
                        spacing=10,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                ],
                spacing=12,
            ),
        )

    # ----------------------------------------------------------------------
    # Gastos del día
    # ----------------------------------------------------------------------

    def _tarjeta_gastos(self) -> ft.Control:
        piezas: list[ft.Control] = [
            componentes.cabecera_tarjeta(
                self.paleta,
                "Gastos de hoy",
                f"{len(self.movimientos)} movimientos"
                if self.movimientos
                else "sin movimientos",
            ),
            ft.Row(
                [
                    grafico_reparto.anillo(self.paleta, self.reparto),
                    ft.Container(
                        content=self._detalle_gastos(),
                        expand=True,
                    ),
                ],
                spacing=16,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        ]
        aviso = grafico_reparto.aviso_de_pendientes(self.paleta, self.reparto)
        if aviso is not None:
            piezas.append(aviso)
        return componentes.tarjeta(self.paleta, ft.Column(piezas, spacing=14))

    def _detalle_gastos(self) -> ft.Control:
        if not self.reparto.hay_algo:
            return ft.Text(
                "Cuando apuntes un gasto en Finanzas, aparecerá aquí repartido "
                "por categorías.",
                size=12,
                color=self.paleta.muted,
            )
        return grafico_reparto.leyenda(self.paleta, self.reparto)

    # ----------------------------------------------------------------------
    # Cosas a hacer
    # ----------------------------------------------------------------------

    def _tarjeta_tareas(self) -> ft.Control:
        ordenadas = ordenar_tareas(self.tareas, self.hoy)
        pendientes = [una for una in ordenadas if not una.hecha]

        if ordenadas:
            cuerpo: ft.Control = ft.Column(
                [self._fila_tarea(una) for una in ordenadas], spacing=0
            )
        else:
            cuerpo = componentes.aviso_vacio(
                self.paleta,
                "Nada apuntado para hoy. Con el botón de arriba apuntas algo.",
            )

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    ft.Row(
                        [
                            ft.Container(
                                content=componentes.cabecera_tarjeta(
                                    self.paleta,
                                    "Cosas a hacer",
                                    f"{len(pendientes)} pendientes"
                                    if pendientes
                                    else "todo hecho",
                                ),
                                expand=True,
                            ),
                            componentes.boton(
                                self.paleta,
                                "Apuntar",
                                icono=ft.Icons.ADD,
                                principal=True,
                                al_pulsar=lambda _: dialogo_tarea.abrir(
                                    self.pagina, self.paleta, self.hoy, self.refrescar
                                ),
                            ),
                        ],
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    cuerpo,
                ],
                spacing=14,
            ),
        )

    def _fila_tarea(self, tarea: Tarea) -> ft.Control:
        atraso = tarea.texto_de_atraso(self.hoy)

        # La casilla vacía va SIN icono dentro, en vez de con uno transparente:
        # un color inventado a mano aquí es justo lo que prohíbe la regla de que
        # los colores viven solo en estilo.py, y el test de arquitectura lo cazó.
        izquierda = ft.Container(
            content=ft.Icon(ft.Icons.CHECK_ROUNDED, size=15, color=estilo.BLANCO)
            if tarea.hecha
            else None,
            width=24,
            height=24,
            bgcolor=self.paleta.positivo if tarea.hecha else None,
            border=None
            if tarea.hecha
            else ft.Border.all(
                2, self.paleta.aviso if atraso else self.paleta.borde_fuerte
            ),
            border_radius=7,
            alignment=ft.Alignment.CENTER,
            on_click=lambda _, t=tarea: self._alternar(t),
            tooltip="Deshacer" if tarea.hecha else "Dar por hecha",
            ink=True,
        )

        textos: list[ft.Control] = [
            ft.Text(
                tarea.titulo,
                size=13,
                color=self.paleta.muted if tarea.hecha else self.paleta.ink,
                # Tachado al hacerla: se ve de un vistazo qué queda sin leer nada.
                style=ft.TextStyle(
                    decoration=ft.TextDecoration.LINE_THROUGH if tarea.hecha else None
                ),
            )
        ]
        pie: list[str] = []
        if atraso:
            pie.append(atraso)
        if tarea.nota:
            pie.append(tarea.nota)
        if pie:
            textos.append(
                ft.Text(
                    " · ".join(pie),
                    size=11,
                    color=self.paleta.aviso if atraso else self.paleta.muted,
                )
            )

        return ft.Container(
            content=ft.Row(
                [
                    izquierda,
                    ft.Column(textos, spacing=1, tight=True, expand=True),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.MORE_HORIZ,
                        ayuda="Corregir o borrar",
                        al_pulsar=lambda _, t=tarea: dialogo_tarea.abrir(
                            self.pagina, self.paleta, self.hoy, self.refrescar, t
                        ),
                    ),
                ],
                spacing=12,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(vertical=8),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
        )

    def _alternar(self, tarea: Tarea) -> None:
        """Dar por hecha o deshacer.

        Se marca con la jornada de HOY, no con la de la tarea: si una tarea del
        jueves se hace el viernes, lo que pasó es que se hizo el viernes. Es lo
        que mantiene honesto el historial del jueves.
        """
        with conectado() as conexion:
            repositorio_tareas.marcar(
                conexion, tarea.id, None if tarea.hecha else self.hoy
            )
        self.refrescar()

    # ----------------------------------------------------------------------
    # Los hábitos de hoy
    # ----------------------------------------------------------------------

    def _tarjeta_habitos(self) -> ft.Control:
        if not self.habitos:
            return componentes.tarjeta(
                self.paleta,
                ft.Column(
                    [
                        self._cabecera_habitos(0, 0),
                        componentes.aviso_vacio(
                            self.paleta,
                            "Todavía no tienes ningún hábito. Créalo con el botón "
                            "de arriba.",
                            icono=ft.Icons.CHECK_CIRCLE_OUTLINE,
                            alto=120,
                        ),
                    ],
                    spacing=14,
                ),
            )

        de_hoy = [uno for uno in self.habitos if uno.toca_en(self.hoy)]
        visibles = [
            uno
            for uno in de_hoy
            if self.franja is None or uno.esta_en_franja(self.franja)
        ]

        with conectado() as conexion:
            cantidades = {
                uno.id: repositorio_habitos.cantidad(conexion, uno.id, self.hoy)
                for uno in de_hoy
            }

        cumplidos = sum(
            1 for uno in de_hoy if uno.cumplido_con(cantidades.get(uno.id, 0))
        )

        if visibles:
            alto = _alto_de_cada_habito(len(visibles))
            cuerpo: ft.Control = ft.Column(
                [
                    self._fila_habito(uno, cantidades.get(uno.id, 0), alto)
                    for uno in visibles
                ],
                spacing=0,
            )
        elif de_hoy:
            cuerpo = componentes.aviso_vacio(
                self.paleta, "Ninguno de hoy cae en esta franja."
            )
        else:
            cuerpo = componentes.aviso_vacio(
                self.paleta, "Hoy no toca ninguno de tus hábitos."
            )

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    self._cabecera_habitos(cumplidos, len(de_hoy)),
                    self._pestanas_de_franja(),
                    cuerpo,
                ],
                spacing=14,
            ),
        )

    def _cabecera_habitos(self, cumplidos: int, cuantos: int) -> ft.Control:
        return ft.Row(
            [
                ft.Container(
                    content=componentes.cabecera_tarjeta(
                        self.paleta,
                        "Hábitos",
                        f"{cumplidos} de {cuantos} cumplidos"
                        if cuantos
                        else "no toca ninguno",
                    ),
                    expand=True,
                ),
                componentes.boton(
                    self.paleta,
                    "Nuevo",
                    icono=ft.Icons.ADD,
                    al_pulsar=lambda _: dialogo_habito.abrir(
                        self.pagina, self.paleta, self.refrescar
                    ),
                ),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _pestanas_de_franja(self) -> ft.Control:
        opciones: list[tuple[str, Franja | None]] = [("Todos", None)]
        opciones += [(franja.value.capitalize(), franja) for franja in Franja]

        return ft.Row(
            [
                ft.Container(
                    content=ft.Text(
                        texto,
                        size=12,
                        color=self.paleta.acento
                        if franja is self.franja
                        else self.paleta.muted,
                        weight=ft.FontWeight.W_600
                        if franja is self.franja
                        else ft.FontWeight.NORMAL,
                    ),
                    padding=ft.Padding.symmetric(horizontal=12, vertical=6),
                    bgcolor=self.paleta.acento_suave if franja is self.franja else None,
                    border_radius=estilo.RADIO_BOTON,
                    on_click=lambda _, f=franja: self._cambiar_franja(f),
                    ink=True,
                )
                for texto, franja in opciones
            ],
            spacing=4,
        )

    def _cambiar_franja(self, franja: Franja | None) -> None:
        self.franja = franja
        self.refrescar()

    def _fila_habito(
        self, habito: Habito, cantidad: int, alto: int | None = None
    ) -> ft.Control:
        cumplido = habito.cumplido_con(cantidad)
        fraccion = min(1.0, cantidad / habito.objetivo) if habito.objetivo else 0.0

        contador, sobrante = habito.texto_avance(cantidad)
        derecha: list[ft.Control] = [
            ft.Text(
                contador,
                size=13,
                weight=ft.FontWeight.W_600,
                color=self.paleta.positivo if cumplido else self.paleta.ink_soft,
            )
        ]
        # Lo que te pasaste del objetivo, en pequeño y apagado: es un dato de más,
        # no la cuenta principal.
        if sobrante:
            derecha.append(
                ft.Text(
                    sobrante,
                    size=11,
                    weight=ft.FontWeight.W_500,
                    color=self.paleta.muted,
                )
            )
        # El botón de quitar solo tiene sentido cuando se cuenta: en un hábito de
        # "1 vez" se apaga volviendo a pulsar el círculo.
        if cantidad > 0 and habito.objetivo > 1:
            derecha.append(
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.REMOVE,
                    ayuda="Quitar uno",
                    al_pulsar=lambda _, h=habito: self._sumar(h, -1),
                )
            )

        hora = habito.hora.strftime("%H:%M") if habito.hora else "—"
        fila = ft.Row(
            [
                componentes.circulo_habito(
                    self.paleta,
                    color=habito.color,
                    emoji=habito.emoji,
                    cantidad=cantidad,
                    objetivo=habito.objetivo,
                    ayuda=self._ayuda_del_circulo(habito, cantidad),
                    al_pulsar=lambda _, h=habito: self._pulsar(h, cantidad),
                ),
                ft.Column(
                    [
                        ft.Text(
                            habito.nombre,
                            size=14,
                            weight=ft.FontWeight.W_500,
                            color=self.paleta.ink,
                        ),
                        ft.Text(
                            f"{hora} · {habito.texto_objetivo()}",
                            size=11,
                            color=self.paleta.muted,
                        ),
                    ],
                    spacing=1,
                    tight=True,
                    expand=True,
                ),
                ft.Row(derecha, spacing=4, tight=True),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.MORE_HORIZ,
                    ayuda="Corregir o archivar",
                    al_pulsar=lambda _, h=habito: dialogo_habito.abrir(
                        self.pagina, self.paleta, self.refrescar, h
                    ),
                ),
            ],
            spacing=12,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

        return ft.Container(
            content=ft.Column(
                [
                    fila,
                    # La barra ocupa el ancho entero de la fila: así el avance se
                    # ve de un vistazo desde el otro lado de la mesa, en vez de
                    # tener que fijarse en una rayita de cuarenta píxeles.
                    componentes.barra_de_avance(
                        self.paleta, color=habito.color, fraccion=fraccion
                    ),
                ],
                spacing=8,
                # El contenido centrado dentro del alto que le toque: con pocos
                # hábitos la fila es alta y el nombre tiene que quedar en medio,
                # no pegado arriba con un agujero debajo.
                alignment=ft.MainAxisAlignment.CENTER,
            ),
            height=alto,
            padding=ft.Padding.symmetric(vertical=9),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
        )

    def _ayuda_del_circulo(self, habito: Habito, cantidad: int) -> str:
        if habito.objetivo == 1:
            return (
                f"Deshacer {habito.nombre}"
                if habito.cumplido_con(cantidad)
                else f"Marcar {habito.nombre}"
            )
        return f"Sumar uno a {habito.nombre}"

    def _pulsar(self, habito: Habito, cantidad: int) -> None:
        """Qué hace pulsar el círculo.

        En un hábito de "1 vez" es un interruptor: pulsar otra vez lo apaga. Sin
        esto, el gimnasio acababa en "3/1", que no significa nada.

        En uno que se cuenta, cada pulsación suma uno, y pasarse del objetivo es
        legítimo: si te bebes nueve vasos, fueron nueve.
        """
        if habito.se_apaga_al_pulsar(cantidad):
            self._marcar(habito, self.hoy, 0)
        else:
            self._sumar(habito, 1)

    def _sumar(self, habito: Habito, cuanto: int) -> None:
        with conectado() as conexion:
            repositorio_habitos.sumar(conexion, habito.id, self.hoy, cuanto)
        self.refrescar()

    def _marcar(self, habito: Habito, dia: date, cantidad: int) -> None:
        with conectado() as conexion:
            repositorio_habitos.marcar(conexion, habito.id, dia, cantidad)
        self.refrescar()


def _alto_de_cada_habito(cuantos: int) -> int:
    """Cuánto mide cada fila para que entre todas llenen la columna.

    ES UNA DIVISIÓN, no una regla de diseño: el alto que hay que llenar partido
    por los hábitos que se ven. Con uno se lleva todo, con dos la mitad cada uno,
    con siete un séptimo. Es lo que pidió el usuario con estas palabras: "si
    pongo un hábito, ese hábito se ve grande; si pongo dos, se separa en la
    mitad; si pongo otro, en tres".

    LOS DOS TOPES NO SON CAPRICHO. Por debajo del mínimo la fila deja de leerse
    —no caben el nombre, la hora y la barra—; por encima del máximo, una sola
    fila con un palmo de aire dentro parece un fallo. Fuera de ese rango se
    prefiere que sobre un poco de sitio antes que enseñar algo ilegible o
    ridículo.
    """
    if cuantos <= 0:
        return ALTO_MINIMO_HABITO
    repartido = ALTO_DE_LA_LISTA // cuantos
    return max(ALTO_MINIMO_HABITO, min(ALTO_MAXIMO_HABITO, repartido))


def _dia_largo(dia: date) -> str:
    """"Sábado · agosto · 2026" — lo que el número de la fecha no puede decir.

    VA DEBAJO DE "22/08/2026" y por eso no repite el día del mes: ahí arriba ya
    está. Lo que aporta es el día de la semana —que es lo que de verdad se
    pregunta uno— y el mes con su nombre, que se lee más rápido que "08".
    """
    return f"{DIAS[dia.weekday()]} · {MESES[dia.month - 1]} · {dia.year}"
