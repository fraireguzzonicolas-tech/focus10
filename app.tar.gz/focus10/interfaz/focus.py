"""La pantalla de Focus: el pomodoro, el bloqueo de webs y el cierre de programas.

LAS DURACIONES SE CAMBIAN AQUÍ, no en Configuración. Lo pidió el usuario y tiene
razón: son un ajuste que se toca a menudo —hoy 25 minutos, mañana 50— y esconderlo
en otra pantalla convierte un gesto de dos segundos en un viaje.

QUÉ PASA AL CAMBIAR UN NÚMERO: si el reloj está parado, se pone al día en el
momento. Si hay una sesión en marcha, no se corta y el número nuevo entra en la
fase siguiente. Las dos reglas viven en dominio/pomodoro.py, no aquí.

LO QUE ESTA PANTALLA NUNCA HACE: decir que algo está bloqueado sin comprobarlo.
Si el UAC se rechaza, si el guardián no arranca, o si el navegador tiene el DNS
seguro en modo estricto, sale escrito en rojo o en ámbar. Un candado dibujado
sobre un bloqueo que no existe es peor que no tener bloqueo.
"""

from __future__ import annotations

import asyncio
import time
from pathlib import Path

import flet as ft

from ..datos import repositorio_focus
from ..datos.bd import conectado
from ..datos.rutas import carpeta_datos
from ..dominio.pomodoro import (
    SESIONES_MAXIMAS,
    SESIONES_MINIMAS,
    Ajustes,
    Fase,
    arrancar,
    avanzar,
    con_ajustes,
    correr,
    empezar,
    parsear_duracion,
    pausar,
    reiniciar_fase,
    siguiente_fase,
    texto_duracion,
)
from ..sistema import avisos, cerrador, dns_seguro, elevacion
from ..sistema import estado as estado_bloqueo
from ..sistema import hosts, programas, rescate
from . import componentes, estilo, reloj_pomodoro
from .estilo import Paleta

SEGUNDOS_POR_VUELTA = 1.0
CARPETA_ESTADO = "focus"

ANCHO_CASILLA = 110
"""Lo que mide la casilla de la duración. Da para "1 h 30 min" sin quedar enorme."""


class PantallaFocus(componentes.Pantalla):
    def __init__(self, pagina: ft.Page, paleta: Paleta) -> None:
        super().__init__(pagina, paleta)
        self._vivo = True
        self._latiendo = False
        self._error = ""

        with conectado() as conexion:
            self.ajustes = repositorio_focus.leer_ajustes(conexion)
        self.estado = empezar(self.ajustes)

        self.carpeta_estado = carpeta_datos() / CARPETA_ESTADO
        self.intento_uac: elevacion.Intento | None = None
        self.ultimo_cierre: cerrador.Resultado | None = None
        self.avisos_dns = _mirar_dns()

        self.refrescar()

    def montada(self) -> None:
        super().montada()
        # UN SOLO LATIDO EN TODA LA VIDA DE LA PANTALLA. Como ahora esta pantalla
        # sobrevive a salir de la sección, montarla otra vez arrancaría un
        # segundo reloj sobre el mismo estado y el minuto correría de dos en dos.
        if not self._latiendo:
            self._latiendo = True
            self.pagina.run_task(self._latir)

    def cerrar(self) -> None:
        """Sales de la pantalla, PERO EL RELOJ SIGUE.

        LO PIDIÓ EL USUARIO: "al salir del apartado de FOCUS deja de andar".
        Y tenía razón en que estaba mal: la gracia de un pomodoro es olvidarte
        de él, y uno que solo cuenta mientras lo miras no sirve para nada.

        ANTES SE PARABA Y SE SOLTABA EL BLOQUEO AQUÍ, y era una de las cuatro
        salvaguardas. Las otras tres siguen intactas y son las que de verdad
        protegen: el fin de la fase suelta, el latido caduca si la aplicación se
        cuelga, y la hora límite suelta pase lo que pase. Esta era la más débil
        de las cuatro —dependía de que salieras de la pantalla— y era justo la
        que rompía el reloj.

        SOLO SE DEJA DE PINTAR: el estado, el bloqueo y la cuenta atrás siguen
        donde estaban.

        AL CERRAR LA APLICACIÓN NO HACE FALTA SOLTAR NADA A MANO: el latido deja
        de escribirse con el proceso, y el guardián suelta en cuanto caduca. Es
        la misma red que ya cubría un cuelgue o un apagón.
        """
        self._en_pagina = False

    def cambiar_paleta(self, paleta: Paleta) -> None:
        """El tema ha cambiado y esta pantalla sigue viva desde antes."""
        self.paleta = paleta
        self.refrescar()

    # ----------------------------------------------------------------------
    # El reloj
    # ----------------------------------------------------------------------

    async def _latir(self) -> None:
        """Una vuelta por segundo: descuenta, avisa al guardián y repinta.

        El latido al guardián se manda AQUÍ y no en un hilo aparte a propósito:
        si esta pantalla se queda colgada, el latido deja de escribirse y el
        guardián suelta el bloqueo. Un latido que sigue latiendo con la
        aplicación colgada no serviría de nada.
        """
        while self._vivo:
            await asyncio.sleep(SEGUNDOS_POR_VUELTA)
            if not self._vivo:
                return

            if self.estado.corriendo:
                antes_terminada = self.estado.terminada
                # Se guarda CUAL fase acaba antes de tocar nada: es lo que
                # decide si suena "ya está, descansa" o "vamos".
                fase_que_acaba = self.estado.fase
                self.estado = correr(self.estado, 1, self.ajustes)
                self._escribir_estado()
                if self.estado.terminada and not antes_terminada:
                    # La fase se acabó: se suelta el bloqueo ANTES de repintar,
                    # para que no haya ni un segundo de "descanso bloqueado".
                    self._soltar_bloqueo()
                    self._avisar_del_final(fase_que_acaba)
                # SE REPINTA SOLO SI ESTÁS MIRANDO. Fuera de la sección la
                # cuenta atrás sigue igual de viva; lo que no tiene sentido es
                # redibujar una pantalla que no está en la ventana.
                if not self._en_pagina:
                    continue
                try:
                    self.refrescar()
                except Exception:  # noqa: BLE001
                    self._vivo = False
                    return

    def _avisar_del_final(self, fase: Fase) -> None:
        """Pita y saca un aviso de Windows al acabar una fase.

        POR QUÉ HACE FALTA: la gracia del pomodoro es poder olvidarte del reloj.
        Si hay que mirar la pantalla para saber si ya toca parar, el reloj no
        está trabajando para ti. Con el aviso puedes estar en otra ventana, o con
        el móvil, y enterarte igual.

        DOS SONIDOS DISTINTOS, uno por cada final: al acabar el trabajo bajan
        —"ya está, para"—; al acabar el descanso suben —"vamos"—. Se distinguen
        sin mirar, que es de lo que se trata.

        SE REUTILIZA LA MISMA PIEZA QUE EL GIMNASIO (sistema/avisos.py): no
        bloquea la ventana, no revienta si no hay altavoces, y ya está probada.
        Escribir un segundo avisador para lo mismo habría acabado con dos
        comportamientos distintos.
        """
        if fase.es_trabajo:
            avisos.sonar(avisos.TONOS_DESCANSO)
            cuanto = texto_duracion(
                self.ajustes.duracion_de(siguiente_fase(self.estado, self.ajustes))
            )
            avisos.notificar(
                "Focus10 · se acabó el trabajo", f"Toca descansar {cuanto}."
            )
        else:
            avisos.sonar()
            avisos.notificar(
                "Focus10 · se acabó el descanso",
                "Vuelve cuando quieras: el reloj espera a que le des tú.",
            )

    def _pulsar_reloj(self) -> None:
        if self.estado.terminada:
            self.estado = avanzar(self.estado, self.ajustes)
        elif self.estado.corriendo:
            self.estado = pausar(self.estado)
            self._soltar_bloqueo()
        else:
            self.estado = arrancar(self.estado)
            self._aplicar_bloqueo()
        self.refrescar()

    def _reiniciar(self) -> None:
        self.estado = reiniciar_fase(self.estado, self.ajustes)
        self._soltar_bloqueo()
        self.refrescar()

    def _saltar(self) -> None:
        self.estado = avanzar(self.estado, self.ajustes)
        self._soltar_bloqueo()
        self.refrescar()

    # ----------------------------------------------------------------------
    # Los números
    # ----------------------------------------------------------------------

    def _cambiar_sesiones(self, cuanto: int) -> None:
        nuevo = min(
            SESIONES_MAXIMAS,
            max(SESIONES_MINIMAS, self.ajustes.sesiones_por_ciclo + cuanto),
        )
        self._guardar_ajustes(sesiones_por_ciclo=nuevo)

    def _guardar_ajustes(self, **cambios) -> None:
        viejos = self.ajustes
        try:
            nuevos = Ajustes(
                trabajo=cambios.get("trabajo", viejos.trabajo),
                descanso=cambios.get("descanso", viejos.descanso),
                descanso_largo=cambios.get("descanso_largo", viejos.descanso_largo),
                sesiones_por_ciclo=cambios.get(
                    "sesiones_por_ciclo", viejos.sesiones_por_ciclo
                ),
            )
        except (ValueError, TypeError) as fallo:
            self._error = str(fallo)
            self.refrescar()
            return

        with conectado() as conexion:
            repositorio_focus.guardar_ajustes(conexion, nuevos)
        self.ajustes = nuevos
        # Las dos reglas del usuario viven en el dominio, no aquí.
        self.estado = con_ajustes(self.estado, viejos, nuevos)
        self._error = ""
        self.refrescar()

    # ----------------------------------------------------------------------
    # El bloqueo
    # ----------------------------------------------------------------------

    def _aplicar_bloqueo(self) -> None:
        """Enciende lo que esté encendido, y solo en la fase de trabajo."""
        if not self.estado.fase.es_trabajo:
            return

        with conectado() as conexion:
            webs, cerrar = repositorio_focus.leer_interruptores(conexion)
            dominios = repositorio_focus.dominios_para_bloquear(conexion)
            lista_programas = repositorio_focus.listar_programas(conexion)

        if webs and dominios:
            self._encender_guardian(dominios)
        if cerrar and lista_programas:
            self.ultimo_cierre = cerrador.cerrar(lista_programas)

    def _encender_guardian(self, dominios: list[str]) -> None:
        self._escribir_estado(activo=True, dominios=dominios)
        rescate.escribir_en_todas(
            [rescate.carpeta_del_escritorio(), Path(__file__).resolve().parents[3]]
        )
        if self.intento_uac is not None and self.intento_uac.arrancado:
            return  # ya hay guardián de esta sesión: el UAC se pide UNA vez
        self.intento_uac = elevacion.arrancar_guardian(
            self.carpeta_estado,
            Path(__file__).resolve().parents[2],
            hosts.ruta_del_sistema(),
        )

    def _escribir_estado(self, *, activo: bool | None = None, dominios=None) -> None:
        """Escribe el papelito del guardián: el latido y hasta cuándo vale."""
        if activo is None:
            activo = self.estado.corriendo and self.estado.fase.es_trabajo
        if dominios is None:
            dominios = self._dominios_puestos
        else:
            self._dominios_puestos = tuple(dominios)

        ahora = time.time()
        estado_bloqueo.guardar(
            self.carpeta_estado,
            estado_bloqueo.Estado(
                activo=bool(activo),
                latido=ahora,
                limite=estado_bloqueo.limite_para(ahora + self.estado.restante),
                dominios=tuple(dominios),
                ruta_hosts=str(hosts.ruta_del_sistema()),
            ),
        )

    _dominios_puestos: tuple[str, ...] = ()

    def _soltar_bloqueo(self) -> None:
        """Le dice al guardián que suelte. Si no hay guardián, no pasa nada."""
        try:
            self._escribir_estado(activo=False)
        except OSError:
            # Si no se puede escribir, el guardián soltará igual por el latido
            # viejo o por la hora límite. Esa es la gracia de tener cuatro.
            pass

    def _bloqueo_de_verdad(self) -> list[str]:
        """Qué hay bloqueado AHORA en el archivo hosts. Se mira, no se supone."""
        try:
            return hosts.dominios_bloqueados(hosts.leer(hosts.ruta_del_sistema()))
        except OSError:
            return []

    # ----------------------------------------------------------------------
    # Pintar
    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            webs, cerrar = repositorio_focus.leer_interruptores(conexion)
            self.dominios = repositorio_focus.listar_dominios(conexion)
            self.programas = repositorio_focus.listar_programas(conexion)
        self.bloquear_webs, self.cerrar_programas = webs, cerrar

        piezas: list[ft.Control] = [
            componentes.titulo_pagina(self.paleta, "Focus", self._subtitulo()),
            self._tarjeta_reloj(),
        ]
        # DONDE NO SE PUEDE BLOQUEAR SE DICE, en vez de dejar interruptores que
        # no hacen nada. Bloquear webs y cerrar programas son cosas del sistema
        # operativo, y solo Windows deja hacerlas.
        #
        # SE PREGUNTA "¿SE PUEDE BLOQUEAR?" Y NO "¿ESTOY EN UN NAVEGADOR?", que
        # es lo que habia antes. Daba la respuesta buena de casualidad, porque
        # en el movil se usaba la web; con la aplicacion de Android ya no es un
        # navegador, tampoco puede bloquear, y la pantalla habria ofrecido
        # interruptores muertos.
        #
        # SE AVISA AUNQUE MOLESTE porque la alternativa es peor: un interruptor
        # que se enciende y no bloquea nada te hace creer que estas protegido.
        if not hosts.puede_bloquear():
            piezas.append(
                componentes.aviso(
                    self.paleta,
                    [
                        "El cronometro funciona, pero en este aparato NO se "
                        "pueden bloquear webs ni cerrar programas.",
                        "Eso solo va en la aplicacion de ordenador: hace falta "
                        "tocar cosas del sistema que ni una pagina web ni una "
                        "aplicacion de movil pueden tocar.",
                    ],
                )
            )
        if self._error:
            piezas.append(componentes.aviso_error(self.paleta, [self._error]))

        piezas.append(self._tarjeta_duraciones())
        # LAS DOS TARJETAS DEL BLOQUEO NO SE ENSEÑAN DONDE NO PUEDE FUNCIONAR.
        #
        # ANTES SE ENSEÑABAN IGUAL, con el aviso encima: quedaban interruptores
        # que se encienden, se guardan y no bloquean nada. Eso es exactamente
        # simular una funcion que no existe, y lo destapo el banco de pruebas al
        # forzar el caso del movil.
        if hosts.puede_bloquear():
            piezas += [self._tarjeta_webs(), self._tarjeta_programas()]

        self.pintar(piezas)

    def _subtitulo(self) -> str:
        if self.estado.corriendo:
            return f"{self.estado.fase.value} en marcha"
        if self.estado.terminada:
            return "fase terminada: pulsa para seguir"
        return "parado"

    def _tarjeta_reloj(self) -> ft.Control:
        if self.estado.terminada:
            texto, icono = "Siguiente", ft.Icons.SKIP_NEXT
        elif self.estado.corriendo:
            texto, icono = "Pausar", ft.Icons.PAUSE
        else:
            texto, icono = "Empezar", ft.Icons.PLAY_ARROW

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    reloj_pomodoro.anillo(self.paleta, self.estado, self.ajustes),
                    ft.Row(
                        [
                            componentes.boton(
                                self.paleta,
                                texto,
                                icono=icono,
                                principal=True,
                                al_pulsar=lambda _: self._pulsar_reloj(),
                            ),
                            componentes.boton(
                                self.paleta,
                                "Reiniciar",
                                icono=ft.Icons.REPLAY,
                                al_pulsar=lambda _: self._reiniciar(),
                            ),
                            componentes.boton(
                                self.paleta,
                                "Saltar fase",
                                icono=ft.Icons.SKIP_NEXT,
                                al_pulsar=lambda _: self._saltar(),
                            ),
                        ],
                        spacing=8,
                        alignment=ft.MainAxisAlignment.CENTER,
                    ),
                    *self._estado_del_bloqueo(),
                ],
                spacing=16,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )

    def _estado_del_bloqueo(self) -> list[ft.Control]:
        """Lo que de verdad está pasando. Nunca un candado sin comprobar."""
        lineas: list[ft.Control] = []

        if self.intento_uac is not None and not self.intento_uac.arrancado:
            lineas.append(
                componentes.aviso_error(self.paleta, [self.intento_uac.mensaje()])
            )
        elif self.estado.corriendo and self.estado.fase.es_trabajo:
            puestos = self._bloqueo_de_verdad()
            if self.bloquear_webs and self.dominios and not puestos:
                lineas.append(
                    componentes.aviso(
                        self.paleta,
                        [
                            "Las webs todavía NO están bloqueadas. Si Windows "
                            "acaba de pedirte permiso, acéptalo; tarda unos "
                            "segundos en aplicarse."
                        ],
                    )
                )
            elif puestos:
                lineas.append(
                    ft.Text(
                        f"{len(puestos)} direcciones bloqueadas ahora mismo",
                        size=11,
                        color=self.paleta.positivo,
                    )
                )

        if self.ultimo_cierre is not None and self.ultimo_cierre.hubo_perdida_posible:
            cuales = ", ".join(self.ultimo_cierre.forzados)
            lineas.append(
                componentes.aviso(
                    self.paleta,
                    [f"Hubo que forzar el cierre de {cuales}: lo no guardado se perdió."],
                )
            )
        if self.ultimo_cierre is not None and self.ultimo_cierre.resistieron:
            cuales = ", ".join(self.ultimo_cierre.resistieron)
            lineas.append(
                componentes.aviso(self.paleta, [f"{cuales} no se dejó cerrar."])
            )
        return lineas

    # ----------------------------------------------------------------------

    def _tarjeta_duraciones(self) -> ft.Control:
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Duraciones",
                        "se cambian aquí mismo; si hay una sesión en marcha, "
                        "entran en la siguiente fase",
                    ),
                    self._fila_duracion("Trabajo", "trabajo"),
                    self._fila_duracion("Descanso", "descanso"),
                    self._fila_duracion("Descanso largo", "descanso_largo"),
                    self._fila_sesiones(),
                ],
                spacing=10,
            ),
        )

    def _fila_duracion(self, etiqueta: str, campo: str) -> ft.Control:
        """El nombre a la izquierda y una casilla escribible a la derecha.

        SE ESCRIBE, NO SE SUMA. Antes había cuatro botones de ±5 y ±30 y el
        usuario acabó con un "1 h 31 min" a base de clics. Para poner hora y
        media, escribir "90" es un gesto; llegar a base de sumar treinta y
        quitar cinco son cuatro, y uno de más te deja un número absurdo.
        """
        casilla = componentes.campo_texto(
            self.paleta,
            "",
            valor=texto_duracion(getattr(self.ajustes, campo)),
            pista="90 o 1:30",
            ancho=ANCHO_CASILLA,
            al_enviar=lambda e, c=campo: self._escribir_duracion(c, e.control.value),
        )
        # Al salir de la casilla también se guarda: si solo valiera el Enter,
        # cambiarías el número, harías clic en otro sitio y se perdería sin que
        # nada te avisara.
        casilla.on_blur = lambda e, c=campo: self._escribir_duracion(c, e.control.value)
        casilla.text_align = ft.TextAlign.RIGHT

        return ft.Row(
            [
                ft.Text(etiqueta, size=13, color=self.paleta.ink, expand=True),
                casilla,
            ],
            spacing=8,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _escribir_duracion(self, campo: str, escrito: str) -> None:
        """Lee lo escrito y lo guarda, o explica por qué no vale.

        Si no se entiende, la casilla vuelve a lo que había: dejar dentro un
        texto que no vale hace que al siguiente clic se intente guardar otra vez
        y salte el mismo error para siempre.
        """
        actual = getattr(self.ajustes, campo)
        try:
            segundos = parsear_duracion(escrito)
        except (ValueError, TypeError) as fallo:
            self._error = str(fallo)
            self.refrescar()
            return
        if segundos == actual:
            # Nada que hacer. Repintar aquí borraría el aviso de un error
            # anterior sin que el usuario haya arreglado nada.
            return
        self._guardar_ajustes(**{campo: segundos})

    def _fila_sesiones(self) -> ft.Control:
        return ft.Row(
            [
                ft.Text(
                    "Sesiones antes del descanso largo",
                    size=13,
                    color=self.paleta.ink,
                    expand=True,
                ),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.REMOVE,
                    ayuda="Una menos",
                    al_pulsar=lambda _: self._cambiar_sesiones(-1),
                ),
                ft.Container(
                    content=ft.Text(
                        str(self.ajustes.sesiones_por_ciclo),
                        size=13,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.ink,
                    ),
                    width=40,
                    alignment=ft.Alignment.CENTER,
                ),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.ADD,
                    ayuda="Una más",
                    al_pulsar=lambda _: self._cambiar_sesiones(1),
                ),
            ],
            spacing=6,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    # ----------------------------------------------------------------------

    def _tarjeta_webs(self) -> ft.Control:
        self.campo_dominio = componentes.campo_texto(
            self.paleta,
            "Web a bloquear",
            pista="youtube.com",
            al_enviar=lambda _: self._anadir_dominio(),
        )

        piezas: list[ft.Control] = [
            componentes.cabecera_tarjeta(
                self.paleta,
                "Bloquear webs",
                "solo durante el trabajo; en los descansos se suelta",
            ),
            componentes.interruptor(
                self.paleta,
                "Bloquear estas webs mientras trabajo",
                valor=self.bloquear_webs,
                al_cambiar=lambda e: self._guardar_interruptores(webs=e.control.value),
            ),
        ]

        aviso_dns = dns_seguro.aviso(self.avisos_dns)
        if aviso_dns:
            piezas.append(componentes.aviso(self.paleta, [aviso_dns]))

        piezas.append(
            ft.Row(
                [
                    ft.Container(content=self.campo_dominio, expand=True),
                    componentes.boton(
                        self.paleta,
                        "Añadir",
                        icono=ft.Icons.ADD,
                        al_pulsar=lambda _: self._anadir_dominio(),
                    ),
                ],
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            )
        )
        piezas.append(
            ft.Column(
                [self._fila_dominio(uno) for uno in self.dominios], spacing=0
            )
            if self.dominios
            else componentes.aviso_vacio(
                self.paleta, "Todavía no has puesto ninguna web."
            )
        )
        piezas.append(
            ft.Text(
                "Hay sitios que nunca se bloquean, a propósito: desde donde "
                "pedirías ayuda, los traductores, la Wikipedia, la RAE y lo que "
                "necesita Windows.",
                size=11,
                color=self.paleta.muted,
            )
        )
        return componentes.tarjeta(self.paleta, ft.Column(piezas, spacing=12))

    def _fila_dominio(self, dominio: str) -> ft.Control:
        return ft.Container(
            content=ft.Row(
                [
                    ft.Icon(ft.Icons.PUBLIC_OFF, size=16, color=self.paleta.muted),
                    ft.Text(dominio, size=13, color=self.paleta.ink, expand=True),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.CLOSE,
                        ayuda="Quitar",
                        al_pulsar=lambda _, d=dominio: self._quitar_dominio(d),
                    ),
                ],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(vertical=4),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
        )

    def _anadir_dominio(self) -> None:
        try:
            with conectado() as conexion:
                repositorio_focus.anadir_dominio(
                    conexion, self.campo_dominio.value or ""
                )
            self._error = ""
        except ValueError as fallo:
            # El mensaje del dominio se enseña tal cual: ya viene escrito para
            # que lo lea una persona.
            self._error = str(fallo)
        self.campo_dominio.value = ""
        self.refrescar()

    def _quitar_dominio(self, dominio: str) -> None:
        with conectado() as conexion:
            repositorio_focus.quitar_dominio(conexion, dominio)
        self.refrescar()

    # ----------------------------------------------------------------------

    def _tarjeta_programas(self) -> ft.Control:
        piezas: list[ft.Control] = [
            componentes.cabecera_tarjeta(
                self.paleta,
                "Cerrar programas",
                "esto no necesita permisos de administrador",
            ),
            componentes.interruptor(
                self.paleta,
                "Cerrar estos programas al empezar a trabajar",
                valor=self.cerrar_programas,
                al_cambiar=lambda e: self._guardar_interruptores(
                    cerrar=e.control.value
                ),
            ),
            componentes.aviso(
                self.paleta,
                [
                    "Primero se pide cerrar por las buenas. Si a los nueve "
                    "segundos el programa sigue abierto, se fuerza, y entonces "
                    "lo que no hayas guardado se pierde."
                ],
            ),
            ft.Row(
                [
                    componentes.boton(
                        self.paleta,
                        "Elegir de lo que tengo abierto",
                        icono=ft.Icons.APPS,
                        al_pulsar=lambda _: self._abrir_lista_de_abiertos(),
                    )
                ]
            ),
        ]
        piezas.append(
            ft.Column([self._fila_programa(uno) for uno in self.programas], spacing=0)
            if self.programas
            else componentes.aviso_vacio(
                self.paleta, "Todavía no has puesto ningún programa."
            )
        )
        return componentes.tarjeta(self.paleta, ft.Column(piezas, spacing=12))

    def _fila_programa(self, nombre: str) -> ft.Control:
        return ft.Container(
            content=ft.Row(
                [
                    ft.Icon(ft.Icons.CANCEL_OUTLINED, size=16, color=self.paleta.muted),
                    ft.Text(nombre, size=13, color=self.paleta.ink, expand=True),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.CLOSE,
                        ayuda="Quitar",
                        al_pulsar=lambda _, n=nombre: self._quitar_programa(n),
                    ),
                ],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(vertical=4),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
        )

    def _abrir_lista_de_abiertos(self) -> None:
        """La lista de lo que hay abierto, con su título de ventana.

        Es lo que pidió el usuario: "no me sé que Discord es discord.exe". Los
        protegidos salen apagados y con su explicación, en vez de no salir: si
        no aparecieran, te quedarías buscando un programa que no está.
        """
        abiertos = programas.abiertos()
        ya_puestos = set(self.programas)

        filas = [
            ft.Container(
                content=ft.Row(
                    [
                        ft.Text(
                            uno.titulo,
                            size=13,
                            color=self.paleta.muted if uno.protegido else self.paleta.ink,
                            expand=True,
                        ),
                        ft.Text(uno.nombre, size=11, color=self.paleta.muted),
                        ft.Text(
                            "protegido"
                            if uno.protegido
                            else ("ya está" if uno.nombre in ya_puestos else ""),
                            size=11,
                            color=self.paleta.muted,
                        ),
                    ],
                    spacing=10,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                padding=ft.Padding.symmetric(vertical=6, horizontal=4),
                border_radius=estilo.RADIO_BOTON,
                on_click=(
                    None
                    if uno.protegido or uno.nombre in ya_puestos
                    else (lambda _, n=uno.nombre: self._anadir_programa(n))
                ),
                ink=not uno.protegido,
                tooltip=(
                    "Es parte de Windows, de esta aplicación o de tu antivirus: "
                    "cerrarlo rompería el sistema."
                    if uno.protegido
                    else None
                ),
            )
            for uno in abiertos
        ]

        cuerpo: ft.Control = (
            ft.Column(filas, spacing=0, scroll=ft.ScrollMode.AUTO, height=340)
            if filas
            else componentes.aviso_vacio(
                self.paleta,
                "No he podido leer qué programas tienes abiertos.",
            )
        )
        self.pagina.show_dialog(
            componentes.dialogo(
                self.paleta,
                "¿Qué cierro?",
                ft.Container(content=cuerpo, width=460),
                pagina=self.pagina,
                texto_aceptar="Listo",
                al_aceptar=lambda _: self.pagina.pop_dialog(),
            )
        )

    def _anadir_programa(self, nombre: str) -> None:
        try:
            with conectado() as conexion:
                repositorio_focus.anadir_programa(conexion, nombre)
            self._error = ""
        except ValueError as fallo:
            self._error = str(fallo)
        self.pagina.pop_dialog()
        self.refrescar()

    def _quitar_programa(self, nombre: str) -> None:
        with conectado() as conexion:
            repositorio_focus.quitar_programa(conexion, nombre)
        self.refrescar()

    def _guardar_interruptores(self, *, webs=None, cerrar=None) -> None:
        webs = self.bloquear_webs if webs is None else bool(webs)
        cerrar = self.cerrar_programas if cerrar is None else bool(cerrar)
        with conectado() as conexion:
            repositorio_focus.guardar_interruptores(
                conexion, bloquear_webs=webs, cerrar_programas=cerrar
            )
        if not webs:
            self._soltar_bloqueo()
        self.refrescar()


def _mirar_dns() -> list:
    """Revisa el DNS seguro de los navegadores instalados, sin poder fallar.

    Se hace UNA vez al abrir la pantalla y no en cada repintado: son varios
    archivos en disco, y hacerlo cada segundo mientras corre el reloj sería
    castigar el disco para nada.
    """
    import os

    try:
        local = Path(os.environ.get("LOCALAPPDATA", ""))
        roaming = Path(os.environ.get("APPDATA", ""))
        return dns_seguro.revisar(local, roaming)
    except (OSError, ValueError):
        return []
