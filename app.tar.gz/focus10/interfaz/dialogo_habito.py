"""La ventanita de crear o corregir un hábito.

Sirve para las dos cosas: si se le pasa un hábito, lo corrige; si no, crea uno
nuevo. Es la misma ventana porque son los mismos campos, y tener dos copias
acabaría con dos comportamientos distintos.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import time

import flet as ft

from ..datos import repositorio_habitos
from ..datos.bd import conectado
from ..dominio.semana import DIAS, LETRAS
from ..dominio.habito import (
    COLORES,
    LARGO_MAXIMO_EMOJI,
    LARGO_MAXIMO_NOMBRE,
    LARGO_MAXIMO_UNIDAD,
    TODOS_LOS_DIAS,
    Habito,
)
from . import componentes, emojis, estilo
from .estilo import Paleta



def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    al_guardar: Callable[[], None],
    habito: Habito | None = None,
) -> None:
    """Abre la ventanita. Sin `habito`, crea uno nuevo."""
    pagina.show_dialog(_DialogoHabito(pagina, paleta, habito, al_guardar).control)


class _DialogoHabito:
    def __init__(
        self,
        pagina: ft.Page,
        paleta: Paleta,
        habito: Habito | None,
        al_guardar: Callable[[], None],
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.habito = habito
        self.al_guardar = al_guardar

        self.color = habito.color if habito else COLORES[0]
        self.dias = set(habito.dias) if habito else set(TODOS_LOS_DIAS)

        self.emoji_elegido = habito.emoji if habito else emojis.POR_OMISION
        self.emoji = componentes.campo_texto(
            paleta, "Otro", valor="", ancho=80, largo_maximo=LARGO_MAXIMO_EMOJI,
        )
        self.emoji.on_blur = lambda _: self._emoji_escrito()
        self.emoji.on_submit = lambda _: self._emoji_escrito()
        self.muestra_emoji = ft.Container(
            content=ft.Text(self.emoji_elegido, size=26),
            width=54, height=54,
            border=ft.Border.all(2, estilo.color_de_habito(self.color)),
            border_radius=54,
            alignment=ft.Alignment.CENTER,
        )
        self.cuadricula = ft.Column(spacing=8, tight=True)
        self._pintar_emojis()
        self.nombre = componentes.campo_texto(
            paleta, "Nombre", valor=habito.nombre if habito else "",
            pista="Beber agua", ancho=250, largo_maximo=LARGO_MAXIMO_NOMBRE,
        )
        self.objetivo = componentes.campo_texto(
            paleta, "Objetivo", valor=str(habito.objetivo) if habito else "1",
            ancho=110,
        )
        self.objetivo.keyboard_type = ft.KeyboardType.NUMBER
        self.unidad = componentes.campo_texto(
            paleta, "Unidad", valor=habito.unidad if habito else "vez",
            pista="vasos, minutos, veces", ancho=220,
            largo_maximo=LARGO_MAXIMO_UNIDAD,
        )
        self.hora = componentes.campo_texto(
            paleta, "Hora (opcional)",
            valor=habito.hora.strftime("%H:%M") if habito and habito.hora else "",
            pista="06:00", ancho=150,
        )

        self.fila_colores = ft.Row(spacing=8)
        self.fila_dias = ft.Row(spacing=6)
        self._pintar_colores()
        self._pintar_dias()

        self.control = componentes.dialogo(
            paleta,
            "Corregir hábito" if habito else "Nuevo hábito",
            ft.Column(
                [
                    ft.Row(
                        [self.muestra_emoji, self.nombre],
                        spacing=12,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    ft.Text("Emoji", size=11, color=paleta.muted),
                    self.cuadricula,
                    ft.Row(
                        [
                            self.emoji,
                            ft.Text(
                                "o pega aquí el que quieras",
                                size=11,
                                color=paleta.muted,
                            ),
                        ],
                        spacing=8,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    ft.Row([self.objetivo, self.unidad], spacing=10),
                    ft.Text("Color", size=11, color=paleta.muted),
                    self.fila_colores,
                    ft.Text("Días en que toca", size=11, color=paleta.muted),
                    self.fila_dias,
                    self.hora,
                    ft.Text(
                        "Sin hora, el hábito aparece en las tres franjas del día.",
                        size=11,
                        color=paleta.muted,
                    ),
                    *self._boton_de_borrar(),
                ],
                spacing=12,
                tight=True,
                width=380,
                scroll=ft.ScrollMode.AUTO,
            ),
            pagina=pagina,
            al_aceptar=lambda _: self._guardar(),
        )

    # ----------------------------------------------------------------------

    def _pintar_emojis(self) -> None:
        """La cuadrícula por temas. El elegido se marca con el color del hábito."""
        filas: list[ft.Control] = []
        for tema, grupo in emojis.POR_TEMA.items():
            filas.append(
                ft.Row(
                    [
                        ft.Container(
                            content=ft.Text(tema, size=10, color=self.paleta.muted),
                            width=58,
                        ),
                        *[self._boton_emoji(uno) for uno in grupo],
                    ],
                    spacing=6,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                )
            )
        self.cuadricula.controls = filas

    def _boton_emoji(self, uno: str) -> ft.Control:
        elegido = uno == self.emoji_elegido
        return ft.Container(
            content=ft.Text(uno, size=19),
            width=36,
            height=36,
            bgcolor=self.paleta.acento_suave if elegido else None,
            border=ft.Border.all(
                2 if elegido else 1,
                estilo.color_de_habito(self.color) if elegido else self.paleta.borde,
            ),
            border_radius=10,
            alignment=ft.Alignment.CENTER,
            on_click=lambda _, e=uno: self._elegir_emoji(e),
            ink=True,
        )

    def _elegir_emoji(self, uno: str) -> None:
        self.emoji_elegido = uno
        self.emoji.value = ""
        self._refrescar_emoji()

    def _emoji_escrito(self) -> None:
        """Lo escrito a mano manda sobre lo elegido en la cuadrícula."""
        escrito = (self.emoji.value or "").strip()
        if escrito:
            self.emoji_elegido = escrito
            self._refrescar_emoji()

    def _refrescar_emoji(self) -> None:
        self.muestra_emoji.content = ft.Text(self.emoji_elegido, size=26)
        self.muestra_emoji.border = ft.Border.all(
            2, estilo.color_de_habito(self.color)
        )
        self._pintar_emojis()
        self.pagina.update()

    def _pintar_colores(self) -> None:
        """Los ocho colores, con el elegido marcado por un borde."""
        self.fila_colores.controls = [
            ft.Container(
                width=28,
                height=28,
                bgcolor=estilo.color_de_habito(nombre),
                border_radius=28,
                border=ft.Border.all(
                    3 if nombre == self.color else 0, self.paleta.ink
                ),
                on_click=lambda _, c=nombre: self._elegir_color(c),
                tooltip=nombre,
                ink=True,
            )
            for nombre in COLORES
        ]

    def _elegir_color(self, nombre: str) -> None:
        self.color = nombre
        self._pintar_colores()
        # La muestra del emoji lleva el color del hábito, así que también cambia.
        self._refrescar_emoji()

    def _pintar_dias(self) -> None:
        """Las siete letras. Las marcadas son los días en que toca."""
        botones = []
        for numero, (letra, nombre_largo) in enumerate(zip(LETRAS, DIAS)):
            elegido = numero in self.dias
            botones.append(
                ft.Container(
                    content=ft.Text(
                        letra,
                        size=12,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.acento_ink if elegido else self.paleta.ink_soft,
                    ),
                    width=32,
                    height=32,
                    bgcolor=self.paleta.acento if elegido else self.paleta.surface_2,
                    border=None if elegido else ft.Border.all(1, self.paleta.borde),
                    border_radius=8,
                    alignment=ft.Alignment.CENTER,
                    on_click=lambda _, n=numero: self._cambiar_dia(n),
                    tooltip=nombre_largo,
                    ink=True,
                )
            )
        self.fila_dias.controls = botones

    def _cambiar_dia(self, numero: int) -> None:
        if numero in self.dias:
            self.dias.discard(numero)
        else:
            self.dias.add(numero)
        self._pintar_dias()
        self.pagina.update()

    # ----------------------------------------------------------------------

    def _boton_de_borrar(self) -> list[ft.Control]:
        """El botón de borrar, SOLO al corregir un hábito que ya existe.

        Al crear uno nuevo no hay nada que borrar, y un botón que no hace nada
        es peor que no tenerlo. Es el mismo sitio y la misma forma que en Tareas
        y en Objetivos: dentro de la ventanita de corregir, abajo del todo, sin
        color de peligro hasta que se confirma.
        """
        if self.habito is None:
            return []
        return [
            ft.Container(height=4),
            componentes.boton(
                self.paleta,
                "Borrar este hábito",
                icono=ft.Icons.DELETE_OUTLINE,
                al_pulsar=lambda _: self._pedir_borrado(),
            ),
        ]

    def _pedir_borrado(self) -> None:
        """Pregunta antes de tocar nada, y DICE cuál de las dos cosas va a pasar.

        Se cierra esta ventanita antes de preguntar: dos diálogos apilados dejan
        el de atrás sin poder tocarse y parece que se ha colgado. Es lo mismo que
        hace Tareas.

        Lo que decide entre borrar y archivar está en confirmar_borrado, que ya
        estaba escrito desde el principio: un hábito con historial NO se borra,
        se archiva, porque tirar meses de marcas es justo lo que más cuesta
        recuperar.
        """
        self.pagina.pop_dialog()
        confirmar_borrado(self.pagina, self.paleta, self.habito, self.al_guardar)

    def _guardar(self) -> None:
        for campo in (self.nombre, self.objetivo, self.hora):
            campo.error_text = None

        objetivo = (self.objetivo.value or "").strip()
        if not objetivo.isdigit() or int(objetivo) < 1:
            self.objetivo.error_text = "Un número, 1 o más"
            self.pagina.update()
            return

        hora = None
        texto_hora = (self.hora.value or "").strip()
        if texto_hora:
            hora = _leer_hora(texto_hora)
            if hora is None:
                self.hora.error_text = "Escríbela como 06:00"
                self.pagina.update()
                return

        if not self.dias:
            componentes.avisar(
                self.pagina, "Elige al menos un día: un hábito que no toca nunca "
                "no se puede cumplir."
            )
            return

        try:
            # Construir el Habito valida el resto (nombre vacío, emoji, unidad)
            # con las reglas del dominio, que son las de verdad.
            nuevo = Habito(
                nombre=self.nombre.value or "",
                emoji=self.emoji_elegido,
                color=self.color,
                objetivo=int(objetivo),
                unidad=self.unidad.value or "",
                dias=frozenset(self.dias),
                hora=hora,
                activo=self.habito.activo if self.habito else True,
                orden=self.habito.orden if self.habito else 0,
                id=self.habito.id if self.habito else None,
            )
        except (ValueError, TypeError) as error:
            self.nombre.error_text = str(error)
            self.pagina.update()
            return

        with conectado() as conexion:
            if self.habito is None:
                repositorio_habitos.crear(conexion, nuevo)
            else:
                repositorio_habitos.actualizar(conexion, nuevo)

        self.pagina.pop_dialog()
        componentes.avisar(
            self.pagina,
            f"Hábito guardado: {nuevo.nombre} · {nuevo.texto_objetivo()}",
        )
        self.al_guardar()


def _leer_hora(texto: str) -> time | None:
    """Lee "06:00". Devuelve None si no lo entiende, para poder avisar."""
    partes = texto.split(":")
    if len(partes) != 2 or not all(parte.strip().isdigit() for parte in partes):
        return None
    horas, minutos = int(partes[0]), int(partes[1])
    if not (0 <= horas <= 23 and 0 <= minutos <= 59):
        return None
    return time(hour=horas, minute=minutos)


def confirmar_borrado(
    pagina: ft.Page, paleta: Paleta, habito: Habito, al_terminar: Callable[[], None]
) -> None:
    """Borra un hábito, o lo desactiva si ya tiene historial.

    Se decide aquí y se DICE cuál de las dos cosas va a pasar: borrar un hábito
    con meses de marcas tiraría justo lo que más cuesta acumular.
    """
    with conectado() as conexion:
        tiene_historial = repositorio_habitos.tiene_marcas(conexion, habito.id)

    def hacerlo(_):
        with conectado() as conexion:
            if tiene_historial:
                repositorio_habitos.cambiar_actividad(conexion, habito.id, False)
            else:
                repositorio_habitos.borrar(conexion, habito.id)
        pagina.pop_dialog()
        componentes.avisar(
            pagina,
            "Hábito archivado; su historial se conserva."
            if tiene_historial
            else "Hábito borrado.",
        )
        al_terminar()

    if tiene_historial:
        titulo = f"¿Archivar «{habito.nombre}»?"
        texto = (
            "Este hábito ya tiene marcas, así que no se borra: se archiva.\n\n"
            "Dejará de aparecer en las listas, pero su historial se conserva y "
            "puedes recuperarlo cuando quieras."
        )
        aceptar = "Archivar"
    else:
        titulo = f"¿Borrar «{habito.nombre}»?"
        texto = "No tiene ninguna marca, así que se borra del todo.\n\nNo se puede deshacer."
        aceptar = "Borrar"

    componentes.confirmar(
        paleta, pagina, titulo=titulo, texto=texto,
        texto_aceptar=aceptar, al_aceptar=hacerlo,
    )
