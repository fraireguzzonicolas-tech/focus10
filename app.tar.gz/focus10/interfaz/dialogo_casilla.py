"""La ventanita de una casilla del horario: color, tarea, emoji y nota.

LO PIDIÓ EL USUARIO ASÍ: "cuando seleccione el cuadrado parezca un apartado y
ahí elijo el color, pongo la tarea, puedo poner una nota tipo como la de los
gastos, incluso que pueda poner emojis".

EL EMOJI ES PARTE DEL TEXTO, no un campo aparte, y lo dijo él: "estudiar francés
(emoji de bandera de Francia)". Así que la cuadrícula de emojis no guarda nada
por su cuenta: escribe el emoji dentro de lo que estás escribiendo. Un campo de
emoji separado habría obligado a decidir dónde va respecto al texto, y la
respuesta correcta es "donde tú lo pongas".

SE AÑADE AL FINAL DE LO ESCRITO y no donde tengas el cursor. Flet no dice dónde
está el cursor de un campo, así que fingir que se inserta en medio sería
inventarse un comportamiento que no se puede cumplir; al final es predecible y
siempre acierta.

LA NOTA NO SE VE EN LA REJILLA: la casilla es pequeña y solo enseña el texto y
el color, que es lo que se eligió. Para que no quede escondida del todo, la
rejilla la enseña al pasar el ratón por encima.
"""

from __future__ import annotations

import flet as ft

from ..datos import repositorio_horario as repo
from ..datos.bd import conectado
from ..dominio.semana import (
    COLORES,
    DIAS,
    LARGO_MAXIMO_CASILLA,
    LARGO_MAXIMO_NOTA,
    texto_hora,
)
from . import componentes, emojis, estilo
from .estilo import Paleta

ANCHO = 420

NOMBRES_DE_COLOR = {
    "verde": "Verde",
    "azul": "Azul",
    "lila": "Lila",
    "rosa": "Rosa",
    "melocoton": "Melocotón",
    "amarillo": "Amarillo",
}


class _DialogoCasilla:
    def __init__(
        self, pagina: ft.Page, paleta: Paleta, dia: int, hora: int, al_guardar
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.dia = dia
        self.hora = hora
        self.al_guardar = al_guardar

        with conectado() as conexion:
            horario = repo.leer_horario(conexion)
        self.color = horario.color_de(dia, hora)

        self.texto = componentes.campo_texto(
            self.paleta,
            "Qué haces a esta hora",
            valor=horario.texto_de(dia, hora),
            pista="Estudiar francés",
            largo_maximo=LARGO_MAXIMO_CASILLA,
        )
        self.nota = componentes.campo_texto(
            self.paleta,
            "Nota (opcional)",
            valor=horario.nota_de(dia, hora),
            pista="El detalle que no cabe en la casilla",
            largo_maximo=LARGO_MAXIMO_NOTA,
        )
        self.nota.multiline = True
        self.nota.min_lines = 2
        self.nota.max_lines = 4

        self.fila_colores = ft.Row(spacing=8, wrap=True, run_spacing=8)
        self._pintar_colores()

        self.cuadricula = ft.Column(spacing=6, tight=True)
        self._pintar_emojis()

        self.error = ft.Text(
            "", size=estilo.TEXTO_APOYO, color=self.paleta.negativo, visible=False
        )

    # ------------------------------------------------------------------

    @property
    def control(self) -> ft.AlertDialog:
        piezas: list[ft.Control] = [
            ft.Text("Color", size=12, color=self.paleta.muted),
            self.fila_colores,
            componentes.separador(self.paleta),
            self.texto,
            ft.Text("Emojis", size=12, color=self.paleta.muted),
            self.cuadricula,
            componentes.separador(self.paleta),
            self.nota,
            self.error,
            *self._boton_de_vaciar(),
        ]
        return componentes.dialogo(
            self.paleta,
            f"{DIAS[self.dia].capitalize()} a las {texto_hora(self.hora)}",
            ft.Column(piezas, spacing=12, tight=True, width=ANCHO, scroll=ft.ScrollMode.AUTO),
            pagina=self.pagina,
            texto_aceptar="Guardar",
            al_aceptar=lambda _: self._guardar(),
        )

    def _boton_de_vaciar(self) -> list[ft.Control]:
        """Solo sale si la casilla tiene algo. Vaciar algo vacío no es nada."""
        if not (self.texto.value or "").strip() and self.color is None:
            return []
        return [
            ft.Row(
                [
                    componentes.boton(
                        self.paleta,
                        "Vaciar la casilla",
                        icono=ft.Icons.DELETE_OUTLINE,
                        al_pulsar=lambda _: self._vaciar(),
                    ),
                    ft.Container(expand=True),
                ]
            )
        ]

    # ------------------------------------------------------------------

    def _pintar_colores(self) -> None:
        muestras = [
            ft.Container(
                width=40,
                height=40,
                bgcolor=estilo.pastel(nombre, self.paleta),
                border_radius=8,
                border=ft.Border.all(
                    2 if nombre == self.color else 1,
                    self.paleta.ink if nombre == self.color else self.paleta.borde,
                ),
                tooltip=NOMBRES_DE_COLOR[nombre],
                on_click=lambda _, c=nombre: self._elegir_color(c),
                ink=True,
            )
            for nombre in COLORES
        ]
        # "Sin color" es una opción más y va con las demás: si estuviera en otro
        # sitio habría que buscarla, y quitar el color es tan normal como ponerlo.
        muestras.append(
            ft.Container(
                content=ft.Icon(
                    ft.Icons.FORMAT_COLOR_RESET, size=18, color=self.paleta.muted
                ),
                width=40,
                height=40,
                border_radius=8,
                border=ft.Border.all(
                    2 if self.color is None else 1,
                    self.paleta.ink if self.color is None else self.paleta.borde,
                ),
                tooltip="Sin color",
                on_click=lambda _: self._elegir_color(None),
                ink=True,
            )
        )
        self.fila_colores.controls = muestras

    def _elegir_color(self, nombre: str | None) -> None:
        self.color = nombre
        self._pintar_colores()
        self.pagina.update()

    # ------------------------------------------------------------------

    def _pintar_emojis(self) -> None:
        filas: list[ft.Control] = []
        for tema, grupo in emojis.POR_TEMA.items():
            filas.append(
                ft.Row(
                    [
                        ft.Container(
                            content=ft.Text(tema, size=10, color=self.paleta.muted),
                            width=58,
                        ),
                        *[self._boton_emoji(uno) for uno in grupo],
                    ],
                    spacing=6,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                )
            )
        self.cuadricula.controls = filas

    def _boton_emoji(self, uno: str) -> ft.Control:
        return ft.Container(
            content=ft.Text(uno, size=17),
            width=32,
            height=32,
            border_radius=6,
            border=ft.Border.all(1, self.paleta.borde),
            on_click=lambda _, e=uno: self._meter_emoji(e),
            ink=True,
        )

    def _meter_emoji(self, uno: str) -> None:
        """Escribe el emoji al final de la tarea.

        SI YA NO CABE, NO SE MANDA UN ERROR: simplemente no se añade. Es un
        botón de adorno; hacerte leer un aviso por tocar un emoji cuando el
        campo está lleno sería desproporcionado.
        """
        actual = self.texto.value or ""
        if len(actual) + len(uno) > LARGO_MAXIMO_CASILLA:
            return
        self.texto.value = actual + uno
        # SE ACTUALIZA LA PAGINA Y NO EL CAMPO: pedirle a un control que se
        # redibuje exige que ya este puesto en la pagina, y eso es una condicion
        # que aqui no se controla. Es como lo hace el resto de la aplicacion.
        self.pagina.update()

    # ------------------------------------------------------------------

    def _guardar(self) -> None:
        texto = (self.texto.value or "").strip()
        if not texto and self.color is None:
            # TEXTO O COLOR, PERO ALGO: una casilla con solo una nota sería una
            # hora que en la rejilla parece libre y no lo está.
            self.error.value = (
                "Pon al menos un color o una tarea. Una nota sola no se ve en "
                "la rejilla."
            )
            self.error.visible = True
            self.pagina.update()
            return

        try:
            with conectado() as conexion:
                repo.guardar_casilla(
                    conexion,
                    self.dia,
                    self.hora,
                    texto,
                    self.color,
                    self.nota.value or "",
                )
        except (ValueError, TypeError) as fallo:
            self.error.value = str(fallo)
            self.error.visible = True
            self.pagina.update()
            return

        self.pagina.pop_dialog()
        self.al_guardar()

    def _vaciar(self) -> None:
        with conectado() as conexion:
            repo.borrar_casilla(conexion, self.dia, self.hora)
        self.pagina.pop_dialog()
        self.al_guardar()


def abrir(pagina: ft.Page, paleta: Paleta, dia: int, hora: int, al_guardar) -> None:
    """Abre la ventanita de una casilla."""
    pagina.show_dialog(_DialogoCasilla(pagina, paleta, dia, hora, al_guardar).control)
