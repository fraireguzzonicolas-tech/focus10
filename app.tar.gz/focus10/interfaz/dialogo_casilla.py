"""La ventanita de una casilla del horario: color, tarea, icono y nota.

LO PIDIÓ EL USUARIO ASÍ: "cuando seleccione el cuadrado parezca un apartado y
ahí elijo el color, pongo la tarea, puedo poner una nota tipo como la de los
gastos, incluso que pueda poner emojis".

LOS EMOJIS PASARON A SER LOS ICONOS DE LOS HÁBITOS, también a petición suya:
"cámbialos por los que pusimos en el apartado de hábitos". El emoji lo dibujaba
el sistema operativo, distinto en cada aparato y sin los colores del tema. El
icono es un campo aparte (no va dentro del texto) porque un dibujo de línea no
es un carácter que se pueda escribir.

TOCAR EL ICONO ELEGIDO LO QUITA. Sin eso, una vez puesto no habría forma de
volver a dejar la casilla sin icono.

LA NOTA NO SE VE EN LA REJILLA: la casilla es pequeña y solo enseña el texto y
el color, que es lo que se eligió. Para que no quede escondida del todo, la
rejilla la enseña al pasar el ratón por encima.
"""

from __future__ import annotations

import flet as ft

from ..datos import repositorio_horario as repo
from ..datos.bd import conectado
from ..dominio.semana import (
    COLORES,
    DIAS,
    LETRAS,
    Casilla,
    sitios_a_repetir,
    LARGO_MAXIMO_CASILLA,
    LARGO_MAXIMO_NOTA,
    texto_hora,
)
from . import componentes, estilo, iconos_habito
from .estilo import Paleta

ANCHO = 420

NOMBRES_DE_COLOR = {
    "verde": "Verde",
    "azul": "Azul",
    "lila": "Lila",
    "rosa": "Rosa",
    "melocoton": "Melocotón",
    "amarillo": "Amarillo",
}


class _DialogoCasilla:
    def __init__(
        self, pagina: ft.Page, paleta: Paleta, dia: int, hora: int, al_guardar
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.dia = dia
        self.hora = hora
        self.al_guardar = al_guardar

        with conectado() as conexion:
            horario = repo.leer_horario(conexion)
        self.color = horario.color_de(dia, hora)
        self.icono = horario.icono_de(dia, hora)

        self.texto = componentes.campo_texto(
            self.paleta,
            "Qué haces a esta hora",
            valor=horario.texto_de(dia, hora),
            pista="Estudiar francés",
            largo_maximo=LARGO_MAXIMO_CASILLA,
        )
        self.nota = componentes.campo_texto(
            self.paleta,
            "Nota (opcional)",
            valor=horario.nota_de(dia, hora),
            pista="El detalle que no cabe en la casilla",
            largo_maximo=LARGO_MAXIMO_NOTA,
        )
        self.nota.multiline = True
        self.nota.min_lines = 2
        self.nota.max_lines = 4

        self.fila_colores = ft.Row(spacing=8, wrap=True, run_spacing=8)
        self._pintar_colores()

        self.cuadricula = ft.Column(spacing=6, tight=True)
        self._pintar_iconos()

        # REPETIR: los días marcados y hasta qué hora. El día de la casilla va
        # marcado de entrada y no se puede quitar: es donde estás escribiendo.
        self.dias_repetir: set[int] = {dia}
        self.fila_dias = ft.Row(spacing=6, wrap=True, run_spacing=6)
        self._pintar_dias()
        self.hasta = componentes.selector(
            self.paleta,
            "Hasta las",
            [("", "Solo esta hora")]
            + [(str(una), texto_hora(una)) for una in range(hora + 1, 24)],
            valor="",
            ancho=180,
        )

        self.error = ft.Text(
            "", size=estilo.TEXTO_APOYO, color=self.paleta.negativo, visible=False
        )

    # ------------------------------------------------------------------

    @property
    def control(self) -> ft.AlertDialog:
        piezas: list[ft.Control] = [
            ft.Text("Color", size=12, color=self.paleta.muted),
            self.fila_colores,
            componentes.separador(self.paleta),
            self.texto,
            ft.Text("Icono (opcional)", size=12, color=self.paleta.muted),
            self.cuadricula,
            componentes.separador(self.paleta),
            ft.Text("Repetir en (opcional)", size=12, color=self.paleta.muted),
            self.fila_dias,
            self.hasta,
            componentes.separador(self.paleta),
            self.nota,
            self.error,
            *self._boton_de_vaciar(),
        ]
        return componentes.dialogo(
            self.paleta,
            f"{DIAS[self.dia].capitalize()} a las {texto_hora(self.hora)}",
            ft.Column(piezas, spacing=12, tight=True, width=ANCHO, scroll=ft.ScrollMode.AUTO),
            pagina=self.pagina,
            texto_aceptar="Guardar",
            al_aceptar=lambda _: self._guardar(),
        )

    def _boton_de_vaciar(self) -> list[ft.Control]:
        """Solo sale si la casilla tiene algo. Vaciar algo vacío no es nada."""
        if not (self.texto.value or "").strip() and self.color is None:
            return []
        return [
            ft.Row(
                [
                    componentes.boton(
                        self.paleta,
                        "Vaciar la casilla",
                        icono=ft.Icons.DELETE_OUTLINE,
                        al_pulsar=lambda _: self._vaciar(),
                    ),
                    ft.Container(expand=True),
                ]
            )
        ]

    # ------------------------------------------------------------------

    def _pintar_colores(self) -> None:
        muestras = [
            ft.Container(
                width=40,
                height=40,
                bgcolor=estilo.pastel(nombre, self.paleta),
                border_radius=8,
                border=ft.Border.all(
                    2 if nombre == self.color else 1,
                    self.paleta.ink if nombre == self.color else self.paleta.borde,
                ),
                tooltip=NOMBRES_DE_COLOR[nombre],
                on_click=lambda _, c=nombre: self._elegir_color(c),
                ink=True,
            )
            for nombre in COLORES
        ]
        # "Sin color" es una opción más y va con las demás: si estuviera en otro
        # sitio habría que buscarla, y quitar el color es tan normal como ponerlo.
        muestras.append(
            ft.Container(
                content=ft.Icon(
                    ft.Icons.FORMAT_COLOR_RESET, size=18, color=self.paleta.muted
                ),
                width=40,
                height=40,
                border_radius=8,
                border=ft.Border.all(
                    2 if self.color is None else 1,
                    self.paleta.ink if self.color is None else self.paleta.borde,
                ),
                tooltip="Sin color",
                on_click=lambda _: self._elegir_color(None),
                ink=True,
            )
        )
        self.fila_colores.controls = muestras

    def _elegir_color(self, nombre: str | None) -> None:
        self.color = nombre
        self._pintar_colores()
        self.pagina.update()

    # ------------------------------------------------------------------

    def _pintar_iconos(self) -> None:
        """La misma cuadrícula por temas que al crear un hábito."""
        self.cuadricula.controls = iconos_habito.filas_por_tema(self.paleta.muted, self._boton_icono)

    def _boton_icono(self, clave: str) -> ft.Control:
        elegido = clave == self.icono
        return ft.Container(
            content=ft.Icon(
                iconos_habito.icono_de(clave),
                size=19,
                color=self.paleta.acento if elegido else self.paleta.ink_soft,
            ),
            width=36,
            height=36,
            bgcolor=self.paleta.acento_suave if elegido else None,
            border=ft.Border.all(
                2 if elegido else 1,
                self.paleta.acento if elegido else self.paleta.borde,
            ),
            border_radius=10,
            alignment=ft.Alignment.CENTER,
            on_click=lambda _, c=clave: self._elegir_icono(c),
            ink=True,
            tooltip=clave,
        )

    def _elegir_icono(self, clave: str) -> None:
        self.icono = "" if clave == self.icono else clave
        self._pintar_iconos()
        # SE ACTUALIZA LA PAGINA Y NO LA CUADRICULA: pedirle a un control que se
        # redibuje exige que ya este puesto en la pagina, y eso es una condicion
        # que aqui no se controla. Es como lo hace el resto de la aplicacion.
        self.pagina.update()

    def _pintar_dias(self) -> None:
        self.fila_dias.controls = [
            ft.Container(
                content=ft.Text(
                    letra,
                    size=12,
                    color=self.paleta.acento_ink if uno in self.dias_repetir
                    else self.paleta.ink_soft,
                ),
                width=34,
                height=34,
                alignment=ft.Alignment.CENTER,
                bgcolor=self.paleta.acento if uno in self.dias_repetir else None,
                border=ft.Border.all(1, self.paleta.borde),
                border_radius=17,
                tooltip=DIAS[uno].capitalize(),
                on_click=lambda _, d=uno: self._alternar_dia(d),
                ink=True,
            )
            for uno, letra in enumerate(LETRAS)
        ]

    def _alternar_dia(self, dia: int) -> None:
        if dia == self.dia:
            return
        self.dias_repetir ^= {dia}
        self._pintar_dias()
        self.pagina.update()

    # ------------------------------------------------------------------

    def _guardar(self) -> None:
        texto = (self.texto.value or "").strip()
        if not texto and self.color is None:
            # TEXTO O COLOR, PERO ALGO: una casilla con solo una nota sería una
            # hora que en la rejilla parece libre y no lo está.
            self.error.value = (
                "Pon al menos un color o una tarea. Una nota sola no se ve en "
                "la rejilla."
            )
            self.error.visible = True
            self.pagina.update()
            return

        try:
            with conectado() as conexion:
                repo.guardar_casilla(
                    conexion,
                    self.dia,
                    self.hora,
                    texto,
                    self.color,
                    self.nota.value or "",
                    self.icono,
                )
                sitios = sitios_a_repetir(
                    self.dia,
                    self.hora,
                    self.dias_repetir,
                    int(self.hasta.value) if self.hasta.value else None,
                )
                puestas, saltadas = repo.repetir_casilla(
                    conexion,
                    Casilla(
                        self.dia, self.hora, texto, self.color,
                        self.nota.value or "", self.icono,
                    ),
                    sitios,
                )
        except (ValueError, TypeError) as fallo:
            self.error.value = str(fallo)
            self.error.visible = True
            self.pagina.update()
            return

        self.pagina.pop_dialog()
        self.al_guardar()
        if sitios:
            # SE DICE LO QUE PASÓ, y más si algo se saltó: sin esto el usuario
            # descubriría solo que su lunes ocupado no cambió.
            aviso = f"Repetida en {puestas} casilla{'s' if puestas != 1 else ''}."
            if saltadas:
                aviso += (
                    f" {saltadas} ya tenía{'n' if saltadas != 1 else ''} algo "
                    "y no se tocaron."
                )
            componentes.avisar(self.pagina, aviso)

    def _vaciar(self) -> None:
        with conectado() as conexion:
            repo.borrar_casilla(conexion, self.dia, self.hora)
        self.pagina.pop_dialog()
        self.al_guardar()


def abrir(pagina: ft.Page, paleta: Paleta, dia: int, hora: int, al_guardar) -> None:
    """Abre la ventanita de una casilla."""
    pagina.show_dialog(_DialogoCasilla(pagina, paleta, dia, hora, al_guardar).control)
