"""Un gráfico de barras con la raya de tu objetivo.

PARA QUÉ: enseñar cuánto comiste cada día de la semana, o cada semana del mes,
y si eso quedó por encima o por debajo de lo que te habías propuesto.

POR QUÉ SE DIBUJA A MANO SOBRE UN LIENZO: Flet 0.86 no trae control de gráficos.
Pero sí trae un lienzo donde se pintan rectángulos y líneas de verdad, que es lo
único que hace falta aquí. Sin depender de nada de fuera.

LA RAYA DEL OBJETIVO ES LA MITAD DEL GRÁFICO. Unas barras sueltas no dicen si
2400 kcal es mucho o poco: eso depende de lo que TÚ busques. Con la raya, la
respuesta se ve sin pensar y sin leer un número.

LAS BARRAS A CERO SE DIBUJAN COMO UNA LÍNEA FINA en la base, no como nada. Lo
pidió el usuario —un día sin apuntar cuenta como cero— y si no se dibujara nada,
un día en blanco y un día que no existe se verían igual.

LA ESCALA LA MANDA EL VALOR MÁS ALTO, incluido el objetivo. Si un día te pasaste
mucho, la barra llega arriba del todo y las demás se encogen: así se ve de golpe
que ese día fue distinto, en vez de recortar la barra y disimularlo.
"""

from __future__ import annotations

import flet as ft
import flet.canvas as cv

from . import estilo
from .estilo import Paleta, con_opacidad

ALTO = 120
MARGEN_ARRIBA = 12
MARGEN_ABAJO = 20
ALTO_MINIMO_BARRA = 2
"""Lo que mide una barra de valor cero.

No es cero: es una rayita. Un cero dibujado como nada se confunde con un hueco.
"""


def grafico_barras(
    valores: list[int],
    etiquetas: list[str],
    paleta: Paleta,
    *,
    objetivo: int | None = None,
    color: str | None = None,
    ancho: int | None = None,
) -> ft.Control:
    """Las barras, con su raya de objetivo si la hay.

    `valores` y `etiquetas` tienen que venir igual de largos: cada barra lleva
    su nombre debajo. Si no cuadraran, se dibujaría una barra sin nombre o un
    nombre sin barra, y las dos cosas son un fallo silencioso.
    """
    if len(valores) != len(etiquetas):
        raise ValueError(
            f"hay {len(valores)} valores y {len(etiquetas)} etiquetas, "
            "y tiene que haber los mismos"
        )
    if not valores:
        return ft.Container(height=ALTO)

    if ancho is None:
        ancho = estilo.ancho_de_grafico(560)
    tinta = color or paleta.acento

    # EL TECHO INCLUYE EL OBJETIVO: si todos los días quedaste corto, la raya
    # tiene que verse igualmente. Sin esto se saldría por arriba del dibujo.
    techo = max([*valores, objetivo or 0, 1])
    alto_util = ALTO - MARGEN_ARRIBA - MARGEN_ABAJO
    base = ALTO - MARGEN_ABAJO

    hueco = 4
    ancho_barra = max(2.0, (ancho - hueco * (len(valores) - 1)) / len(valores))

    formas: list[cv.Shape] = []

    # La raya del objetivo va DEBAJO de las barras: si se cruzara por encima
    # taparía justo la punta, que es lo que se quiere comparar.
    if objetivo:
        y = base - (objetivo / techo) * alto_util
        formas.append(
            cv.Line(
                0, y, ancho, y,
                paint=ft.Paint(
                    color=paleta.muted,
                    stroke_width=1,
                    stroke_dash_pattern=[4, 4],
                ),
            )
        )

    for numero, valor in enumerate(valores):
        x = numero * (ancho_barra + hueco)
        alto_barra = max(ALTO_MINIMO_BARRA, (valor / techo) * alto_util)
        # LAS QUE PASAN EL OBJETIVO SE PINTAN DISTINTO: es la información que se
        # viene a buscar, y verla sin comparar alturas es más rápido.
        pasado = bool(objetivo) and valor > objetivo
        formas.append(
            cv.Rect(
                x, base - alto_barra, ancho_barra, alto_barra,
                border_radius=2,
                paint=ft.Paint(
                    color=tinta if not pasado else con_opacidad(tinta, 0.55)
                ),
            )
        )

    return ft.Column(
        [
            ft.Container(
                content=cv.Canvas(formas, expand=True),
                width=ancho,
                height=ALTO,
            ),
            _pie(etiquetas, ancho_barra, hueco, paleta),
        ],
        spacing=0,
        tight=True,
    )


def _pie(
    etiquetas: list[str], ancho_barra: float, hueco: int, paleta: Paleta
) -> ft.Control:
    """Los nombres de debajo, cada uno bajo su barra.

    SE DIBUJAN COMO TEXTO Y NO EN EL LIENZO porque el texto del lienzo no se
    ajusta solo ni respeta la tipografía de la aplicación. Poniéndolos en una
    fila con el mismo ancho que las barras, quedan alineados igual.
    """
    return ft.Row(
        [
            ft.Container(
                content=ft.Text(
                    texto,
                    size=estilo.ROTULO,
                    color=paleta.muted,
                    text_align=ft.TextAlign.CENTER,
                    # DOS LINEAS: en el mes cada barra pone "S2" y debajo
                    # el tramo de días. En la semana son una letra y sobra sitio.
                    max_lines=2,
                    overflow=ft.TextOverflow.CLIP,
                ),
                width=ancho_barra,
            )
            for texto in etiquetas
        ],
        spacing=hueco,
        tight=True,
    )
