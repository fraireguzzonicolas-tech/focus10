"""Sumar el bot de WhatsApp: el «¿querés agregar a FOCUS1%?» y lo que pasa al decir que sí.

LO PIDIÓ EL USUARIO: un SOLO bot para todos, que ya viene en la app («no
quiero que cada usuario genere su propio chatbot»), y que Focus lo ofrezca:
«¿querés agregar un chatbot en WhatsApp? Si dice que sí, se agrega un contacto
llamado FOCUS1% y desde ahí puede controlar toda la app».

SE OFRECE UNA VEZ, al abrir la app con tu cuenta (lo eligió él). Digas que sí
o que no, no se repite; queda el botón en Configuración (tarjeta_whatsapp.py),
que hace lo mismo.

AL DECIR QUE SÍ, TRES PASOS:
  1. se deja en la nube la huella de un código de un solo uso (ver
     sistema/whatsapp.py: es lo que prueba que ese WhatsApp es tuyo);
  2. en el celular se abre «Nuevo contacto» ya rellenado con FOCUS1% y el
     número del bot, y vos tocás Guardar;
  3. se abre el chat con «FOCUS <código>» ya escrito. Al mandarlo, quedás
     vinculado. MANDARLO LO TENÉS QUE HACER VOS: WhatsApp no deja que una app
     mande mensajes por vos, y está bien que no deje.
"""

from __future__ import annotations

import flet as ft

from ..datos import ajustes
from ..datos.bd import conectado
from ..sistema import whatsapp
from ..sistema.sincronizacion import ServidorDijoQueNo, SinConexion
from . import componentes
from .con_sesion import con_la_sesion
from .estilo import Paleta

NOMBRE_DEL_CONTACTO = "FOCUS1%"


async def sumar(pagina: ft.Page, avisos) -> str:
    """Los tres pasos de la cabecera. Devuelve el código, por si hay que
    enseñarlo otra vez. Si no hay red, falla con SinConexion antes de abrir nada."""
    codigo = whatsapp.nuevo_codigo()
    await con_la_sesion(lambda testigo: whatsapp.pedir_codigo(testigo, codigo))
    if avisos is not None:
        try:
            await avisos.agregar_contacto(NOMBRE_DEL_CONTACTO, f"+{whatsapp.NUMERO_DEL_BOT}")
        except Exception:  # noqa: BLE001
            # SIN AGENDA (o si se cerró rara) no se corta: el chat se abre igual.
            pass
    pagina.launch_url(whatsapp.enlace(codigo))
    return codigo


def ofrecer_si_toca(pagina: ft.Page, paleta: Paleta, avisos) -> None:
    """Al abrir la app: si nunca se te ofreció y no estás vinculado, se pregunta."""
    if not whatsapp.NUMERO_DEL_BOT:
        return  # todavía no hay bot: ofrecerlo sería ofrecer algo que no anda
    with conectado() as conexion:
        if ajustes.leer(conexion, ajustes.CLAVE_WHATSAPP_OFRECIDO) == "si":
            return
    pagina.run_task(_preguntar, pagina, paleta, avisos)


def _ya_se_ofrecio() -> None:
    with conectado() as conexion:
        ajustes.escribir(conexion, ajustes.CLAVE_WHATSAPP_OFRECIDO, "si")


async def _preguntar(pagina: ft.Page, paleta: Paleta, avisos) -> None:
    try:
        vinculado = await con_la_sesion(whatsapp.vinculado)
    except (SinConexion, ServidorDijoQueNo):
        # SIN RED NO SE PREGUNTA NI SE MARCA: se pregunta la próxima vez que
        # abras la app con conexión. Preguntar sin poder hacerlo no sirve.
        return
    if vinculado:
        _ya_se_ofrecio()
        return

    def ahora_no(_):
        _ya_se_ofrecio()
        pagina.pop_dialog()

    def si(_):
        _ya_se_ofrecio()
        pagina.pop_dialog()
        pagina.run_task(_decir_que_si, pagina, avisos)

    pagina.show_dialog(ft.AlertDialog(
        title=ft.Text(f"¿Agregar a {NOMBRE_DEL_CONTACTO} en WhatsApp?"),
        content=ft.Text(
            f"Le escribís a {NOMBRE_DEL_CONTACTO} como a cualquier contacto y hace lo "
            "mismo que el asistente: apuntar gastos y comidas, crear hábitos, "
            "recordatorios, anotar el gimnasio y contestarte cómo vas. Solo te "
            "responde a vos."
        ),
        actions=[
            ft.TextButton("Ahora no", on_click=ahora_no),
            ft.FilledButton("Sí, agregar", on_click=si),
        ],
    ))


async def _decir_que_si(pagina: ft.Page, avisos) -> None:
    try:
        await sumar(pagina, avisos)
    except SinConexion:
        componentes.avisar(pagina, "No hay conexión. Lo podés hacer después desde Configuración.")
    except ServidorDijoQueNo:
        componentes.avisar(pagina, "WhatsApp todavía no está disponible. Probá desde Configuración.")
