"""El resumen de un día: cuánto comiste, cuánta agua y qué comiste.

LO PIDIÓ EL USUARIO: "que yo pueda entrar a cada día y ver un resumen: cuánta
prote, carbos... agua, y qué comí".

SE ABRE DESDE EL CALENDARIO DEL MES, tocando un día.

NO SE EDITA NADA DESDE AQUÍ, y es a propósito: esto es para mirar hacia atrás.
Poder cambiar la cena del 3 de marzo desde una ventanita de consulta es la clase
de botón que se pulsa sin querer y que reescribe un dato que ya no recuerdas.

LO QUE NO SE SABE SE DICE. Un día sin nada apuntado no enseña cuatro ceros como
si hubieras ayunado: dice que no apuntaste nada. Los ceros los pone el gráfico
del mes, que es otra pregunta y está decidido aparte.
"""

from __future__ import annotations

import flet as ft

from ..dominio.cumplimiento import ResumenDeDia, fraccion_de
from ..dominio.agua import texto_litros
from ..dominio.alimento import texto_gramos
from ..dominio.dinero import formatear
from ..dominio.moneda import EUR, Moneda
from ..dominio.resumen_diario import DiaResumido
from ..dominio.semana import texto_fecha
from ..dominio.nutricion import NOMBRES, NUTRIENTES
from . import componentes, estilo
from .estilo import Paleta

DIAS = (
    "Lunes",
    "Martes",
    "Miércoles",
    "Jueves",
    "Viernes",
    "Sábado",
    "Domingo",
)



def abrir(
    pagina: ft.Page,
    paleta: Paleta,
    resumen: ResumenDeDia,
    *,
    extra: DiaResumido | None = None,
    moneda: Moneda = EUR,
) -> ft.AlertDialog:
    """Enseña el día. Devuelve la ventanita para poder probarla.

    `extra` ES EL RESTO DEL DÍA —entreno, hábitos, tareas, gastos, la nota— y
    solo llega desde el resumen mensual. Desde el calendario de la comida se
    abre sin él y la ventana enseña lo de siempre.

    ES LA MISMA VENTANA PARA LOS DOS SITIOS a propósito: dos ventanas que
    enseñan "el día 17" con contenidos distintos según por dónde entraste es la
    clase de cosa que hace dudar de cuál de las dos dice la verdad.
    """
    ventanita = ft.AlertDialog(
        modal=True,
        title=ft.Text(
            texto_fecha(resumen.jornada),
            size=15,
            weight=ft.FontWeight.W_600,
            color=paleta.ink,
        ),
        content=ft.Container(
            content=ft.Column(
                _cuerpo(paleta, resumen, extra, moneda), spacing=14, scroll="auto"
            ),
            width=360,
        ),
        bgcolor=paleta.surface,
        actions=[ft.TextButton("Cerrar", on_click=lambda _: pagina.pop_dialog())],
        actions_alignment=ft.MainAxisAlignment.END,
    )
    pagina.show_dialog(ventanita)
    return ventanita


def _cuerpo(
    paleta: Paleta,
    resumen: ResumenDeDia,
    extra: DiaResumido | None = None,
    moneda: Moneda = EUR,
) -> list[ft.Control]:
    if extra is not None and not resumen.apuntado and not resumen.agua_ml:
        # DESDE EL RESUMEN MENSUAL NO SE CORTA AQUÍ: un día sin comida apuntada
        # puede tener entreno, hábitos y una nota, y decir "no apuntaste nada"
        # encima de todo eso sería falso.
        return _nota(paleta, extra) + [
            componentes.aviso_vacio(paleta, "Ese día no apuntaste ni comida ni agua.")
        ] + _resto(paleta, extra, moneda)

    if not resumen.apuntado and not resumen.agua_ml:
        return [
            componentes.aviso_vacio(
                paleta, "Ese día no apuntaste nada: ni comida ni agua."
            )
        ]

    piezas: list[ft.Control] = [] if extra is None else _nota(paleta, extra)
    if resumen.apuntado:
        piezas += [_fila(paleta, uno, resumen) for uno in NUTRIENTES]
    else:
        piezas.append(
            componentes.aviso_vacio(paleta, "Ese día no apuntaste ninguna comida.")
        )

    piezas.append(_agua(paleta, resumen))
    if resumen.registros:
        piezas.append(_lo_que_comiste(paleta, resumen))
    if extra is not None:
        piezas += _resto(paleta, extra, moneda)
    return piezas


def _nota(paleta: Paleta, extra: DiaResumido) -> list[ft.Control]:
    """La valoración y la reflexión que escribiste al finalizar el día.

    VAN LAS PRIMERAS porque es lo que tú escribiste: el resto son cuentas que
    hizo la aplicación, y tus propias palabras pesan más que sus números.
    """
    if extra.valoracion is None and not extra.nota:
        return []
    piezas: list[ft.Control] = []
    if extra.valoracion is not None:
        piezas.append(
            ft.Text(
                f"📝 Valoraste el día con un {extra.valoracion} de 10",
                size=estilo.TEXTO_APOYO,
                weight=ft.FontWeight.W_600,
                color=paleta.ink,
            )
        )
    if extra.nota:
        piezas.append(
            ft.Text(extra.nota, size=estilo.TEXTO_APOYO, color=paleta.ink_soft)
        )
    return [ft.Column(piezas, spacing=6, tight=True)]


def _resto(
    paleta: Paleta, extra: DiaResumido, moneda: Moneda
) -> list[ft.Control]:
    """Entreno, hábitos, tareas y gastos de ese día.

    CADA APARTADO SOLO SALE SI HUBO ALGO. Una lista de cuatro apartados vacíos
    dice "fallaste en todo" cuando lo que pasa es que ese día no usaste la
    aplicación, y no es lo mismo.
    """
    piezas: list[ft.Control] = []

    if extra.entreno:
        piezas.append(_entreno(paleta, extra))

    if extra.hubo_habitos:
        piezas.append(_habitos(paleta, extra))

    if extra.tareas:
        piezas.append(
            _lista(paleta, f"Hiciste {len(extra.tareas)}", extra.tareas)
        )

    if extra.gasto:
        piezas.append(
            ft.Text(
                f"💰 Gastaste {formatear(extra.gasto, moneda)}",
                size=estilo.TEXTO_APOYO,
                color=paleta.ink,
            )
        )

    return piezas


def _entreno(paleta: Paleta, extra: DiaResumido) -> ft.Control:
    """"🏋️ Pecho y tríceps", los ejercicios y el peso más alto.

    LO PIDIÓ EL USUARIO: "el ejercicio que hiciste, tipo, ese día hice pecho".
    """
    titulo = f"🏋️ {extra.titulo_entreno()}"
    if extra.texto_peso():
        titulo += f" · lo más alto, {extra.texto_peso()}"

    return ft.Column(
        [
            ft.Text(
                titulo,
                size=estilo.TEXTO_APOYO,
                weight=ft.FontWeight.W_600,
                color=paleta.ink,
            ),
            # SOLO LOS EJERCICIOS EN LOS QUE SE MARCÓ ALGO. Los que quedaron sin
            # tocar estaban planeados, no hechos, y aquí se cuenta lo que pasó.
            *[
                ft.Text(f"· {uno}", size=estilo.TEXTO_APOYO, color=paleta.ink_soft)
                for uno in extra.ejercicios
            ],
        ],
        spacing=4,
        tight=True,
    )


def _habitos(paleta: Paleta, extra: DiaResumido) -> ft.Control:
    """Los hábitos del día con un check o una cruz, como se pidió."""
    return ft.Column(
        [
            ft.Text(
                f"Hábitos · {extra.texto_habitos()}",
                size=estilo.ROTULO,
                color=paleta.muted,
                weight=ft.FontWeight.W_600,
            ),
            *[
                ft.Text(
                    f"{'✓' if hecho else '✕'} {nombre}",
                    size=estilo.TEXTO_APOYO,
                    color=paleta.positivo if hecho else paleta.muted,
                )
                for nombre, hecho in extra.habitos
            ],
        ],
        spacing=4,
        tight=True,
    )


def _lista(paleta: Paleta, titulo: str, cosas) -> ft.Control:
    return ft.Column(
        [
            ft.Text(
                titulo,
                size=estilo.ROTULO,
                color=paleta.muted,
                weight=ft.FontWeight.W_600,
            ),
            *[
                ft.Text(f"✓ {una}", size=estilo.TEXTO_APOYO, color=paleta.ink_soft)
                for una in cosas
            ],
        ],
        spacing=4,
        tight=True,
    )


def _fila(paleta: Paleta, nutriente: str, resumen: ResumenDeDia) -> ft.Control:
    """Un nutriente con su objetivo y su barra, como en la pantalla de hoy."""
    total = resumen.totales.de(nutriente)
    objetivo = getattr(resumen.objetivos, nutriente)
    es_kcal = nutriente == "kcal"

    escrito = f"{total} kcal" if es_kcal else f"{texto_gramos(total)} g"
    if objetivo is not None:
        meta = f"{objetivo} kcal" if es_kcal else f"{texto_gramos(objetivo)} g"
        escrito = f"{escrito} de {meta}"

    fraccion = fraccion_de(total, objetivo)
    piezas: list[ft.Control] = [
        ft.Row(
            [
                ft.Text(
                    _con_tick(NOMBRES[nutriente], fraccion),
                    size=estilo.TEXTO_APOYO,
                    color=paleta.ink_soft,
                    expand=True,
                ),
                ft.Text(
                    escrito,
                    size=estilo.TEXTO_APOYO,
                    weight=ft.FontWeight.W_600,
                    color=paleta.ink,
                ),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )
    ]
    # SIN OBJETIVO NO HAY BARRA: una barra sin contra-qué es un porcentaje
    # inventado. Es la misma regla que en la pantalla de hoy.
    if fraccion is not None:
        piezas.append(
            componentes.barra_de_avance(
                paleta,
                color="ambar" if fraccion > 1 else "verde",
                fraccion=min(1.0, fraccion),
            )
        )
    return ft.Column(piezas, spacing=6, tight=True)


def _con_tick(nombre: str, fraccion: float | None) -> str:
    """Le pone un ✓ al que llegó a su objetivo.

    LO PIDIÓ EL USUARIO —"si llegaste a lo que tenías que llegar, con un tick"—.
    SIN OBJETIVO NO HAY TICK NI CRUZ: no se puede llegar a algo que no dijiste.
    """
    if fraccion is None:
        return nombre
    return f"{nombre} ✓" if fraccion >= 1 else nombre


def _agua(paleta: Paleta, resumen: ResumenDeDia) -> ft.Control:
    escrito = texto_litros(resumen.agua_ml)
    fraccion = fraccion_de(resumen.agua_ml, resumen.objetivo_agua)
    if resumen.objetivo_agua is not None:
        escrito = f"{escrito} de {texto_litros(resumen.objetivo_agua)}"
    return ft.Row(
        [
            ft.Text(
                _con_tick("Agua", fraccion),
                size=estilo.TEXTO_APOYO,
                color=paleta.ink_soft,
                expand=True,
            ),
            ft.Text(
                escrito,
                size=estilo.TEXTO_APOYO,
                weight=ft.FontWeight.W_600,
                color=paleta.ink,
            ),
        ],
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )


def _lo_que_comiste(paleta: Paleta, resumen: ResumenDeDia) -> ft.Control:
    """La lista de lo comido, en el orden en que se apuntó.

    ANTES IBA AGRUPADA POR DESAYUNO / COMIDA / CENA, y dejó de tener sentido
    cuando el usuario quitó el momento del día: los registros nuevos no llevan
    ninguno, así que la agrupación era un título vacío encima de todo.

    LOS VIEJOS SÍ LLEVAN ETIQUETA y no se pierde: se enseña pegada al nombre,
    en pequeño, para quien mire un día de antes del cambio.
    """
    piezas: list[ft.Control] = [
        ft.Text(
            "Lo que comiste",
            size=estilo.ROTULO,
            color=paleta.muted,
            weight=ft.FontWeight.W_600,
        )
    ]
    for registro in sorted(resumen.registros, key=lambda uno: uno.momento):
        nombre = registro.nombre
        if registro.comida:
            nombre = f"{nombre} ({registro.comida})"
        piezas.append(
            ft.Row(
                [
                    ft.Text(
                        f"· {nombre}",
                        size=estilo.TEXTO_APOYO,
                        color=paleta.ink,
                        expand=True,
                    ),
                    ft.Text(
                        f"{registro.kcal} kcal",
                        size=estilo.ROTULO,
                        color=paleta.muted,
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            )
        )
    return ft.Column(piezas, spacing=4, tight=True)
