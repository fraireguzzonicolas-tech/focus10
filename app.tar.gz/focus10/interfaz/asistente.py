"""La ventana del asistente: escribís (o hablás) y hace lo que pedís en Focus.

SE ABRE DESDE EL BOTÓN DE ARRIBA, en todas las pantallas. Lo eligió el
usuario: tiene que estar a mano esté donde esté, también manejando.

LO QUE SE VE ES LA CONVERSACIÓN, en burbujas: lo tuyo a la derecha, lo del
asistente a la izquierda. Los avisos de la app (sin conexión, tope del día)
van en gris y NO se le mandan a Claude: no son parte de la charla.

EL RECORRIDO DE CADA MENSAJE está en datos/asistente_charla.py, compartido
con WhatsApp. Aquí se pintan las burbujas y se maneja la voz.

LA CONVERSACIÓN SE GUARDA UN DÍA (lo pidió el usuario): al abrir sigue donde
quedó, también en tu otro aparato. Ver datos/asistente_guardado.py.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from datetime import date, datetime

import flet as ft

from ..datos import asistente_acciones, asistente_charla, asistente_guardado
from ..datos.bd import conectado
from ..sistema import asistente as servidor
from ..sistema.sincronizacion import ServidorDijoQueNo, SinConexion
from . import componentes, estilo, iconos_habito
from .con_sesion import con_la_sesion
from .estilo import Paleta

USUARIO = "usuario"
ASISTENTE = "asistente"
APP = "app"
"""Quién dice cada burbuja. Lo de APP no viaja al servidor."""

ALTO_CHARLA = 320
ALTO_CHARLA_MOVIL = 190
"""En el celular, más baja: con el teclado abierto queda poco más de media
pantalla, y la ventanita entera (charla + casilla) tiene que caber encima.
Lo eligió el usuario («ventanita más chica») cuando el teclado tapaba la casilla."""

SALUDO = (
    "Decime qué querés hacer: «creame un hábito los lunes a las 14», "
    "«agregá 400 euros para Jorge»…"
)

NO_ACTIVADO = (
    "El asistente todavía no está activado. Mientras tanto, el aviso de pagos "
    "repetidos funciona igual al apuntar desde «Nuevo gasto»."
)


def abrir(pagina: ft.Page, paleta: Paleta, al_hacer: Callable[[], None], voz=None) -> None:
    """Abre el asistente. `al_hacer` refresca la pantalla tras cambiar algo.

    `voz` es la pieza de Android que escucha y habla (focus10_avisos). Solo
    existe en la app instalada en el teléfono; sin ella no hay micrófono y el
    asistente funciona igual, escribiendo.
    """
    ventana = _Asistente(pagina, paleta, al_hacer, voz)
    pagina.show_dialog(ventana.control)
    pagina.run_task(ventana._mirar_si_esta_activado)


class _Asistente:
    def __init__(
        self, pagina: ft.Page, paleta: Paleta, al_hacer: Callable[[], None], voz=None
    ) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.al_hacer = al_hacer
        self.voz = voz
        self.por_voz = False
        """Si lo último se dijo hablando. Entonces la respuesta también se dice
        en voz alta: quien habla puede estar manejando y no mirar la pantalla."""
        with conectado() as conexion:
            self.charla, self.vistas = asistente_guardado.leer(conexion, datetime.now())
        """La conversación y lo pendiente (el recorrido de cada mensaje está en
        datos/asistente_charla.py, el mismo que usa WhatsApp), y las burbujas que
        se ven. Las dos vienen de lo guardado, si es de hace menos de un día."""
        self.pensando = False

        ancho = estilo.ancho_de_grafico(380, margenes=72)
        self.burbujas = ft.ListView(
            [self._burbuja(APP, SALUDO), *(self._burbuja(quien, texto) for quien, texto in self.vistas)],
            spacing=8,
            height=ALTO_CHARLA_MOVIL if estilo.pantalla_estrecha() else ALTO_CHARLA,
            auto_scroll=True,
        )
        self.campo = componentes.campo_texto(
            paleta, "Escribile al asistente", al_enviar=lambda _: self._mandar_escrito()
        )
        self.campo.expand = True
        self.boton = componentes.boton_icono(
            paleta, ft.Icons.SEND, ayuda="Mandar", al_pulsar=lambda _: self._mandar_escrito()
        )
        botones = [self.boton]
        if voz is not None:
            botones.insert(0, componentes.boton_icono(
                paleta, ft.Icons.MIC, ayuda="Hablar",
                al_pulsar=lambda _: self.pagina.run_task(self._escuchar),
            ))
        self.fila = ft.Row(
            [self.campo, *botones],
            spacing=6,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )
        self.control = ft.AlertDialog(
            modal=False,
            # EN EL CELULAR, MÁS PEGADA A LOS BORDES Y CON DESPLAZAMIENTO: si
            # aun así el teclado no deja sitio, la ventanita se corre en vez de
            # esconder la casilla debajo del teclado.
            scrollable=estilo.pantalla_estrecha(),
            inset_padding=ft.Padding.symmetric(horizontal=12, vertical=12)
            if estilo.pantalla_estrecha() else None,
            title=ft.Text("Asistente", size=15, weight=ft.FontWeight.W_600, color=paleta.ink),
            content=ft.Column(
                [self.burbujas, self.fila],
                spacing=10,
                tight=True,
                width=ancho,
            ),
            bgcolor=paleta.surface,
            actions=[ft.TextButton("Cerrar", on_click=lambda _: pagina.pop_dialog())],
        )

    # ------------------------------------------------------------- dibujo

    def _burbuja(self, quien: str, texto: str) -> ft.Control:
        """Una burbuja: lo tuyo corrido a la derecha, lo demás a la izquierda.

        CON MARGEN Y NO CON UNA FILA: una fila no limita el ancho de lo que
        lleva dentro, y un texto largo se salía por el costado en el móvil. Con
        margen, la burbuja ocupa el resto y el texto baja de renglón.
        """
        paleta = self.paleta
        mia = quien == USUARIO
        de_la_app = quien == APP
        return ft.Container(
            content=ft.Text(
                texto,
                size=13,
                italic=de_la_app,
                color=paleta.acento_ink if mia else (paleta.muted if de_la_app else paleta.ink),
            ),
            bgcolor=paleta.acento if mia else (None if de_la_app else paleta.surface_2),
            padding=ft.Padding.symmetric(horizontal=12, vertical=8),
            border_radius=14,
            margin=ft.Margin.only(left=40) if mia else ft.Margin.only(right=40),
        )

    def _decir(self, quien: str, texto: str) -> None:
        self.burbujas.controls.append(self._burbuja(quien, texto))
        if quien != APP:
            # LO DE LA APP NO SE GUARDA: «Pensando…» o «sin conexión» de ayer
            # no le dicen nada a nadie al volver a abrir.
            self.vistas.append((quien, texto))
            self._guardar()
        self.pagina.update()

    def _guardar(self) -> None:
        try:
            with conectado() as conexion:
                asistente_guardado.guardar(conexion, self.charla, self.vistas, datetime.now())
        except Exception:  # noqa: BLE001
            # No poder guardarla no puede cortar la conversación en marcha.
            pass

    # ------------------------------------------------------- si está activado

    async def _mirar_si_esta_activado(self) -> None:
        """Mientras no esté la llave de Claude en el servidor, se dice y se apaga.

        LO DEMÁS SIGUE ANDANDO: la memoria y el aviso de pagos repetidos son de
        Focus, no de la IA, y funcionan igual en «Nuevo gasto».
        """
        try:
            listo = await asyncio.to_thread(servidor.activado)
        except RuntimeError:
            # EN LA WEB NO HAY HILOS (ver con_la_sesion).
            listo = servidor.activado()
        if listo is not False:
            return
        self.campo.disabled = True
        for boton in self.fila.controls[1:]:
            boton.disabled = True
        self._decir(APP, NO_ACTIVADO)

    # ------------------------------------------------------------ la voz

    async def _escuchar(self) -> None:
        """Abre la ventanita de voz del teléfono y manda lo que dijiste."""
        try:
            texto = await self.voz.escuchar()
        except Exception as fallo:  # noqa: BLE001
            self._decir(APP, f"No pude usar el micrófono: {fallo}")
            return
        if not texto.strip():
            return
        self.por_voz = True
        self.campo.value = texto
        self._mandar()

    def _contestar(self, texto: str, *, y_escuchar: bool = False) -> None:
        """La respuesta del asistente: escrita siempre, y en voz alta si hablaste.

        `y_escuchar`: después de decir una pregunta («¿Seguro que querés…?»),
        vuelve a abrir el micrófono para oír el sí o el no sin tocar nada.
        """
        self._decir(ASISTENTE, texto)
        if self.por_voz and self.voz is not None:
            self.pagina.run_task(self._hablar, texto, y_escuchar)

    async def _hablar(self, texto: str, y_escuchar: bool) -> None:
        try:
            await self.voz.decir(texto)
        except Exception as fallo:  # noqa: BLE001
            self._decir(APP, f"No pude hablar: {fallo}")
            return
        if y_escuchar:
            await self._escuchar()

    # ------------------------------------------------------------ la charla

    def _mandar_escrito(self) -> None:
        self.por_voz = False
        self._mandar()

    def _mandar(self) -> None:
        texto = (self.campo.value or "").strip()
        if not texto or self.pensando:
            return
        self.campo.value = ""
        self._decir(USUARIO, texto)

        # EL SÍ O EL NO A LO PENDIENTE SE RESUELVE AQUÍ, sin red ni Claude.
        if self.charla.pendiente is not None:
            with conectado() as conexion:
                turno = asistente_charla.respuesta_local(
                    self.charla, texto, conexion, self._contexto(conexion)
                )
            if turno is not None:
                self._mostrar(turno)
                return

        self.pensando = True
        self._decir(APP, "Pensando…")
        self.pagina.run_task(self._preguntar, texto)

    def _contexto(self, conexion):
        return asistente_acciones.contexto(conexion, date.today(), iconos_habito.todas())

    async def _preguntar(self, texto: str) -> None:
        def en_segundo_plano(testigo: str) -> asistente_charla.Turno:
            # TODO EN EL MISMO HILO, con su propia conexión: la red y la base.
            with conectado() as conexion:
                return asistente_charla.responder(
                    self.charla, texto, conexion, self._contexto(conexion),
                    lambda mensajes, contexto: servidor.preguntar(testigo, mensajes, contexto),
                )

        try:
            turno = await con_la_sesion(en_segundo_plano)
        except (servidor.AsistenteNoDisponible, ServidorDijoQueNo, SinConexion) as fallo:
            self._quitar_pensando()
            self._decir(APP, str(fallo) or "No pude hablar con el asistente.")
            return
        self._quitar_pensando()
        self._mostrar(turno)

    def _mostrar(self, turno: asistente_charla.Turno) -> None:
        # Después de una pregunta («¿Seguro…?») la voz vuelve a escuchar sola.
        self._contestar(turno.texto, y_escuchar=turno.pregunta)
        if turno.hecho:
            self.al_hacer()

    def _quitar_pensando(self) -> None:
        self.pensando = False
        if self.burbujas.controls:
            self.burbujas.controls.pop()
