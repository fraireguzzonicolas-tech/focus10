"""La pantalla de Educación: qué estudiar, qué viene, y cómo vas.

CUATRO PESTAÑAS: Hoy, Calendario, Objetivos y Progreso. "Hoy" contesta "¿qué
hago ahora?"; las otras son para organizar y para mirar atrás. (La Pizarra
estuvo aquí como quinta pestaña del 8 al 11 nov 2026; ahora es la pizarra
infinita, con su propia sección: ver pizarra.py.)

NO HAY PESTAÑA DE MATERIAS, y lo pidió el usuario: "siento que el apartado de
materias es inútil, ya que está el objetivo". La materia se escribe donde hace
falta —en el objetivo o al planificar— y nace sola; los TEMAS viven dentro del
objetivo, que es donde se miran. Los que no cuelgan de ninguno salen al final,
en su propia tarjeta, para que no queden inalcanzables.

AQUÍ NO SE CALCULA NADA A MANO: el progreso, el orden de lo que toca y qué es
lo atrasado salen de dominio/educacion.py. Esta pantalla lee, pinta y llama.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import date, timedelta
from enum import StrEnum

import flet as ft

from ..datos import repositorio_dias
from ..datos import repositorio_educacion as repo
from ..datos.bd import conectado
from ..dominio.educacion import (
    Evento,
    Materia,
    Prioridad,
    Tema,
    TipoEvento,
    de_la_semana,
    lo_de_hoy,
    minutos_estudiados,
    ordenar,
    palabra_de_dominio,
    progreso_de,
    progreso_de_meta,
    siguiente_dominio,
    texto_de_minutos,
)
from ..dominio.semana import dias_del_mes, texto_fecha, texto_mes
from . import componentes, dialogo_educacion, educacion_calendario, estilo
from .estilo import Paleta

DIAS_DE_ACTIVIDAD = 7
CUANTAS_RECIENTES = 6


class Vista(StrEnum):
    HOY = "hoy"
    CALENDARIO = "calendario"
    OBJETIVOS = "objetivos"
    PROGRESO = "progreso"


VISTAS = (
    (Vista.HOY, "Hoy"),
    (Vista.CALENDARIO, "Calendario"),
    (Vista.OBJETIVOS, "Objetivos"),
    (Vista.PROGRESO, "Progreso"),
)


class PantallaEducacion(componentes.Pantalla):
    def __init__(self, pagina: ft.Page, paleta: Paleta) -> None:
        super().__init__(pagina, paleta)
        self.vista = Vista.HOY
        self.mes: date | None = None
        """El primer día del mes que se está mirando. None es el de hoy."""

        self.dia_elegido: date | None = None
        self.refrescar()

    # ------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            self.hoy = repositorio_dias.jornada_abierta(conexion)
            self.materias = repo.listar_materias(conexion)
            self.temas = repo.listar_temas(conexion)
            self.eventos = repo.listar_eventos(conexion)
            self.metas = repo.listar_metas(conexion)
            self.temas_por_meta = {
                una.id: repo.temas_de_meta(conexion, una.id) for una in self.metas
            }

        if self.dia_elegido is None:
            self.dia_elegido = self.hoy

        piezas: list[ft.Control] = [self._cabecera(), self._pestanas()]
        if not self.metas and not self.eventos:
            piezas.append(self._tarjeta_primera_vez())
        elif self.vista is Vista.HOY:
            piezas += self._vista_hoy()
        elif self.vista is Vista.CALENDARIO:
            piezas += self._vista_calendario()
        elif self.vista is Vista.OBJETIVOS:
            piezas += self._vista_objetivos()
        else:
            piezas += self._vista_progreso()

        self.pintar(piezas)

    def _cabecera(self) -> ft.Control:
        return componentes.titulo_pagina(
            self.paleta,
            "Educación",
            self._subtitulo(),
            acciones=[
                componentes.boton(
                    self.paleta,
                    "Añadir",
                    icono=ft.Icons.EVENT_OUTLINED,
                    al_pulsar=lambda _: self._nuevo_evento(TipoEvento.TAREA),
                ),
                componentes.boton(
                    self.paleta,
                    "Estudiar",
                    icono=ft.Icons.MENU_BOOK_OUTLINED,
                    principal=True,
                    al_pulsar=lambda _: self._nuevo_evento(TipoEvento.SESION),
                ),
            ],
        )

    def _subtitulo(self) -> str:
        if self.vista is Vista.CALENDARIO:
            return texto_mes(self.mes or self.hoy)
        pendientes = len(lo_de_hoy(self.eventos, self.hoy))
        if pendientes:
            return f"{pendientes} cosa{'s' if pendientes != 1 else ''} para hoy"
        return texto_fecha(self.hoy)

    def _pestanas(self) -> ft.Control:
        return componentes.segmentado(
            self.paleta, list(VISTAS), self.vista, self._cambiar_vista
        )

    def _cambiar_vista(self, cual: str) -> None:
        self.vista = Vista(cual)
        self.refrescar()

    def _tarjeta_primera_vez(self) -> ft.Control:
        """SIN NADA APUNTADO NO HAY NADA QUE ENSEÑAR, y se dice en vez de pintar
        cuatro pestañas vacías que parecen rotas."""
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.aviso_vacio(
                        self.paleta,
                        "Empieza por un objetivo —«Aprobar Matemáticas»— o "
                        "apunta directamente lo que vas a estudiar.",
                        icono=ft.Icons.SCHOOL_OUTLINED,
                    ),
                    ft.Row(
                        [
                            componentes.boton(
                                self.paleta,
                                "Crear un objetivo",
                                icono=ft.Icons.FLAG_OUTLINED,
                                principal=True,
                                al_pulsar=lambda _: self._nueva_meta(),
                            )
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                    ),
                ],
                spacing=12,
                tight=True,
            ),
        )

    # ------------------------------------------------------------------
    # Hoy
    # ------------------------------------------------------------------

    def _vista_hoy(self) -> list[ft.Control]:
        return [
            self._tarjeta_lista(
                "Hoy",
                texto_fecha(self.hoy),
                lo_de_hoy(self.eventos, self.hoy),
                vacio="Hoy no tienes nada apuntado. Si estudias algo, apúntalo "
                "con «Estudiar».",
                con_dia=False,
            ),
            self._tarjeta_lista(
                "Esta semana",
                "lo que viene",
                de_la_semana(self.eventos, self.hoy),
                vacio="Nada en los próximos siete días.",
                con_dia=True,
            ),
        ]

    def _tarjeta_lista(
        self,
        titulo: str,
        subtitulo: str | None,
        eventos: list[Evento],
        *,
        vacio: str,
        con_dia: bool,
    ) -> ft.Control:
        """Una tarjeta con una lista de cosas del calendario. La usan tres vistas."""
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(self.paleta, titulo, subtitulo),
                    *(
                        [
                            self._fila_evento(
                                uno, con_dia=con_dia or uno.fecha != self.hoy
                            )
                            for uno in eventos
                        ]
                        or [componentes.aviso_vacio(self.paleta, vacio)]
                    ),
                ],
                spacing=8,
            ),
        )

    def _fila_evento(self, evento: Evento, *, con_dia: bool) -> ft.Control:
        """Una cosa del calendario, con lo justo para reconocerla y tocarla."""
        color = educacion_calendario.color_de(self.paleta, evento.tipo)
        apoyo: list[str] = []
        if con_dia:
            apoyo.append(_dia_corto(evento.fecha, self.hoy))
        if evento.hora:
            apoyo.append(evento.hora)
        nombre_materia = self._nombre_de_materia(evento.materia_id)
        if nombre_materia:
            apoyo.append(nombre_materia)
        if evento.minutos and not evento.hecho:
            apoyo.append(texto_de_minutos(evento.minutos))
        if evento.hecho:
            apoyo.append(f"hecho · {texto_de_minutos(evento.minutos_contados)}")

        return ft.Container(
            content=ft.Row(
                [
                    ft.Container(width=3, height=32, bgcolor=color, border_radius=2),
                    ft.Icon(
                        educacion_calendario.icono_de(evento.tipo), size=16, color=color
                    ),
                    ft.Column(
                        [
                            ft.Text(
                                self._titulo_de(evento),
                                size=13,
                                color=self.paleta.ink,
                                weight=(
                                    ft.FontWeight.W_600
                                    if evento.prioridad is Prioridad.ALTA
                                    else None
                                ),
                            ),
                            ft.Text(
                                " · ".join(apoyo), size=11, color=self.paleta.muted
                            ),
                        ],
                        spacing=1,
                        tight=True,
                        expand=True,
                    ),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.UNDO if evento.hecho else ft.Icons.CHECK,
                        al_pulsar=(
                            (lambda _, e=evento: self._desmarcar(e))
                            if evento.hecho
                            else (lambda _, e=evento: self._marcar(e))
                        ),
                        ayuda="No lo hice" if evento.hecho else "Ya lo hice",
                    ),
                ],
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(vertical=4, horizontal=4),
            border_radius=estilo.RADIO_BOTON,
            on_click=lambda _, e=evento: self._corregir_evento(e),
            ink=True,
            opacity=0.55 if evento.hecho else 1.0,
            tooltip="Pulsa para corregirlo",
        )

    def _titulo_de(self, evento: Evento) -> str:
        """Lo que se lee. Una sesión se llama por su tema, que es lo que estudias."""
        if evento.titulo:
            return evento.titulo
        tema = self._nombre_de_tema(evento.tema_id)
        if tema:
            return tema
        return self._nombre_de_materia(evento.materia_id) or "Sesión de estudio"

    def _nombre_de_materia(self, id_materia: int | None) -> str:
        return next(
            (una.nombre for una in self.materias if una.id == id_materia), ""
        )

    def _nombre_de_tema(self, id_tema: int | None) -> str:
        return next((uno.nombre for uno in self.temas if uno.id == id_tema), "")

    # ------------------------------------------------------------------
    # Calendario
    # ------------------------------------------------------------------

    def _vista_calendario(self) -> list[ft.Control]:
        primero = self.mes or self.hoy.replace(day=1)
        del_dia = ordenar(
            [uno for uno in self.eventos if uno.fecha == self.dia_elegido]
        )

        return [
            componentes.tarjeta(
                self.paleta,
                ft.Column(
                    [
                        ft.Row(
                            [
                                componentes.boton_icono(
                                    self.paleta,
                                    ft.Icons.CHEVRON_LEFT,
                                    al_pulsar=lambda _: self._mover_mes(-1),
                                    ayuda="Mes anterior",
                                ),
                                ft.Container(
                                    content=ft.Text(
                                        texto_mes(primero),
                                        size=13,
                                        color=self.paleta.ink,
                                        text_align=ft.TextAlign.CENTER,
                                    ),
                                    expand=True,
                                    alignment=ft.Alignment.CENTER,
                                ),
                                componentes.boton_icono(
                                    self.paleta,
                                    ft.Icons.CHEVRON_RIGHT,
                                    al_pulsar=lambda _: self._mover_mes(1),
                                    ayuda="Mes siguiente",
                                ),
                            ],
                            spacing=4,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                        educacion_calendario.rejilla(
                            self.paleta,
                            dias_del_mes(primero),
                            self.eventos,
                            self.hoy,
                            elegido=self.dia_elegido,
                            al_tocar=self._elegir_dia,
                        ),
                        educacion_calendario.leyenda(self.paleta),
                    ],
                    spacing=12,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                ),
            ),
            componentes.tarjeta(
                self.paleta,
                ft.Column(
                    [
                        ft.Row(
                            [
                                ft.Container(
                                    content=componentes.cabecera_tarjeta(
                                        self.paleta, texto_fecha(self.dia_elegido), None
                                    ),
                                    expand=True,
                                ),
                                componentes.boton(
                                    self.paleta,
                                    "Añadir",
                                    icono=ft.Icons.ADD,
                                    al_pulsar=lambda _: self._nuevo_evento(
                                        TipoEvento.SESION, self.dia_elegido
                                    ),
                                ),
                            ],
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                        *(
                            [self._fila_evento(uno, con_dia=False) for uno in del_dia]
                            or [
                                componentes.aviso_vacio(
                                    self.paleta, "Ese día no tienes nada apuntado."
                                )
                            ]
                        ),
                    ],
                    spacing=8,
                ),
            ),
        ]

    def _mover_mes(self, cuantos: int) -> None:
        primero = self.mes or self.hoy.replace(day=1)
        movido = primero + timedelta(days=32 * cuantos if cuantos > 0 else -1)
        self.mes = movido.replace(day=1)
        self.refrescar()

    def _elegir_dia(self, dia: date) -> None:
        self.dia_elegido = dia
        self.refrescar()

    # ------------------------------------------------------------------
    # Objetivos, con sus temas dentro
    # ------------------------------------------------------------------

    def _vista_objetivos(self) -> list[ft.Control]:
        piezas: list[ft.Control] = [self._tarjeta_meta(una) for una in self.metas]
        if not self.metas:
            piezas.append(
                componentes.tarjeta(
                    self.paleta,
                    componentes.aviso_vacio(
                        self.paleta,
                        "Un objetivo es a dónde vas: «Aprobar Matemáticas», "
                        "«Llegar a B2 de alemán».",
                        icono=ft.Icons.FLAG_OUTLINED,
                    ),
                )
            )

        # LOS TEMAS QUE NO CUELGAN DE NINGÚN OBJETIVO NO SE PUEDEN PERDER: sin
        # esta tarjeta quedarían creados y sin forma de tocarlos.
        de_metas = {uno.id for temas in self.temas_por_meta.values() for uno in temas}
        sueltos = [uno for uno in self.temas if uno.id not in de_metas]
        if sueltos:
            piezas.append(
                componentes.tarjeta(
                    self.paleta,
                    ft.Column(
                        [
                            componentes.cabecera_tarjeta(
                                self.paleta, "Otros temas", "sin objetivo"
                            ),
                            *[self._fila_tema(uno) for uno in sueltos],
                        ],
                        spacing=8,
                    ),
                )
            )

        piezas.append(
            ft.Row(
                [
                    componentes.boton(
                        self.paleta,
                        "Nuevo objetivo",
                        icono=ft.Icons.ADD,
                        al_pulsar=lambda _: self._nueva_meta(),
                    )
                ]
            )
        )
        return piezas

    def _tarjeta_meta(self, meta) -> ft.Control:
        suyos = self.temas_por_meta.get(meta.id, [])
        avance = progreso_de_meta(meta, suyos)
        color = (
            self.paleta.muted
            if meta.cumplida
            else _color_de_prioridad(self.paleta, meta.prioridad)
        )
        apoyo: list[str] = []
        nombre_materia = self._nombre_de_materia(meta.materia_id)
        if nombre_materia:
            apoyo.append(nombre_materia)
        if meta.fecha_limite:
            dias = meta.dias_hasta(self.hoy)
            apoyo.append(
                _dia_corto(meta.fecha_limite, self.hoy)
                + (f" · faltan {dias} días" if dias is not None and dias > 0 else "")
            )
        if meta.cumplida:
            apoyo.append("cumplido")

        filas: list[ft.Control] = [
            ft.Row(
                [
                    ft.Container(width=8, height=8, bgcolor=color, border_radius=4),
                    ft.Container(
                        content=componentes.cabecera_tarjeta(
                            self.paleta, meta.nombre, " · ".join(apoyo) or None
                        ),
                        expand=True,
                    ),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.CHECK,
                        al_pulsar=lambda _, m=meta: self._cumplir_meta(m),
                        ayuda="Reabrir" if meta.cumplida else "Marcar cumplido",
                    ),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.EDIT_OUTLINED,
                        al_pulsar=lambda _, m=meta: self._corregir_meta(m),
                        ayuda="Corregir",
                    ),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.DELETE_OUTLINE,
                        al_pulsar=lambda _, m=meta: self._borrar_meta(m),
                        ayuda="Borrar",
                    ),
                ],
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            componentes.barra_de_avance(
                self.paleta, color=color, fraccion=avance / 100
            ),
            ft.Text(f"{avance} %", size=11, color=self.paleta.muted),
        ]
        filas += [self._fila_tema(uno) for uno in suyos]
        if meta.materia_id:
            filas.append(
                ft.Row(
                    [
                        componentes.boton(
                            self.paleta,
                            "Añadir tema",
                            icono=ft.Icons.ADD,
                            al_pulsar=lambda _, m=meta: self._nuevo_tema(m),
                        )
                    ]
                )
            )
        else:
            # SIN MATERIA NO HAY DÓNDE COLGAR UN TEMA, y se dice en vez de
            # ofrecer un botón que abriría una ventanita que no puede guardar.
            filas.append(
                ft.Text(
                    "Ponle una materia al objetivo para poder añadirle temas.",
                    size=11,
                    color=self.paleta.muted,
                )
            )
        return componentes.tarjeta(self.paleta, ft.Column(filas, spacing=8))

    def _fila_tema(self, tema: Tema) -> ft.Control:
        """Un tema con su dominio, y dos botones para moverlo.

        SE SUBE Y SE BAJA DESDE AQUÍ, sin abrir nada: cambiar cómo llevas un
        tema es lo que más veces se hace, y meterlo dentro de una ventanita
        haría que nadie lo tocara nunca y el progreso fuera mentira.
        """
        apoyo = [palabra_de_dominio(tema.dominio)]
        nombre_materia = self._nombre_de_materia(tema.materia_id)
        if nombre_materia:
            apoyo.append(nombre_materia)
        return ft.Container(
            content=ft.Row(
                [
                    ft.Column(
                        [
                            ft.Text(tema.nombre, size=13, color=self.paleta.ink),
                            ft.Text(
                                " · ".join(apoyo), size=11, color=self.paleta.muted
                            ),
                        ],
                        spacing=1,
                        tight=True,
                        expand=True,
                    ),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.REMOVE,
                        al_pulsar=lambda _, t=tema: self._mover_dominio(t, False),
                        ayuda="Lo llevo peor",
                    ),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.ADD,
                        al_pulsar=lambda _, t=tema: self._mover_dominio(t, True),
                        ayuda="Lo llevo mejor",
                    ),
                ],
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(vertical=4, horizontal=4),
            border_radius=estilo.RADIO_BOTON,
            on_click=lambda _, t=tema: self._corregir_tema(t),
            ink=True,
            tooltip="Pulsa para corregirlo",
        )

    # ------------------------------------------------------------------
    # Progreso
    # ------------------------------------------------------------------

    def _vista_progreso(self) -> list[ft.Control]:
        desde = self.hoy - timedelta(days=DIAS_DE_ACTIVIDAD - 1)
        hechos = [
            uno
            for uno in self.eventos
            if uno.hecho and uno.hecho_en is not None and desde <= uno.hecho_en <= self.hoy
        ]
        recientes = sorted(
            (uno for uno in self.eventos if uno.hecho),
            key=lambda uno: (uno.hecho_en, uno.id or 0),
            reverse=True,
        )[:CUANTAS_RECIENTES]

        return [
            componentes.tarjeta(
                self.paleta,
                ft.Column(
                    [
                        componentes.cabecera_tarjeta(
                            self.paleta, "Estos siete días", None
                        ),
                        ft.Row(
                            [
                                componentes.cifra(
                                    self.paleta,
                                    "Estudiado",
                                    texto_de_minutos(minutos_estudiados(hechos)),
                                ),
                                componentes.cifra(
                                    self.paleta,
                                    "Sesiones",
                                    str(
                                        sum(
                                            1
                                            for uno in hechos
                                            if uno.tipo is TipoEvento.SESION
                                        )
                                    ),
                                ),
                                componentes.cifra(
                                    self.paleta,
                                    "Temas hechos",
                                    str(
                                        sum(1 for uno in self.temas if uno.dominio >= 100)
                                    ),
                                ),
                                componentes.cifra(
                                    self.paleta,
                                    "Objetivos",
                                    str(sum(1 for una in self.metas if not una.cumplida)),
                                ),
                            ],
                            spacing=12,
                            wrap=True,
                            run_spacing=12,
                        ),
                    ],
                    spacing=12,
                ),
            ),
            componentes.tarjeta(
                self.paleta,
                ft.Column(
                    [
                        componentes.cabecera_tarjeta(
                            self.paleta, "Por materia", "según cómo llevas sus temas"
                        ),
                        *(
                            [self._fila_progreso(una) for una in self.materias]
                            or [
                                componentes.aviso_vacio(
                                    self.paleta,
                                    "Todavía no hay materias: nacen al crear un "
                                    "objetivo o al planificar.",
                                )
                            ]
                        ),
                    ],
                    spacing=10,
                ),
            ),
            self._tarjeta_lista(
                "Lo último que estudiaste",
                None,
                recientes,
                vacio="Todavía no has marcado ninguna sesión como hecha.",
                con_dia=True,
            ),
        ]

    def _fila_progreso(self, materia: Materia) -> ft.Control:
        progreso = progreso_de(materia, self.temas, self.eventos)
        color = self.paleta.color_de(materia.color)
        return ft.Column(
            [
                ft.Row(
                    [
                        ft.Text(materia.nombre, size=13, color=self.paleta.ink,
                                expand=True),
                        ft.Text(
                            f"{progreso.dominio_medio} % · "
                            f"{texto_de_minutos(progreso.minutos)}",
                            size=11,
                            color=self.paleta.muted,
                        ),
                    ],
                    spacing=8,
                ),
                componentes.barra_de_avance(
                    self.paleta, color=color, fraccion=progreso.fraccion
                ),
            ],
            spacing=4,
            tight=True,
        )

    # ------------------------------------------------------------------
    # Lo que hacen los botones
    # ------------------------------------------------------------------

    def _nuevo_tema(self, meta) -> None:
        dialogo_educacion.abrir_tema(
            self.pagina, self.paleta, self.hoy, self._guardar_tema_de(meta),
            materia_id=meta.materia_id,
        )

    def _guardar_tema_de(self, meta):
        """Al crear un tema desde un objetivo, queda dentro de ese objetivo.

        Sin esto habría que crearlo y luego acordarse de entrar a corregir el
        objetivo para marcarlo, que es justo el paso que nadie da.
        """

        def guardado() -> None:
            with conectado() as conexion:
                suyos = {uno.id for uno in repo.temas_de_meta(conexion, meta.id)}
                de_la_materia = repo.listar_temas(conexion, meta.materia_id)
                # EL RECIEN CREADO ES EL DEL ID MAS ALTO, y solo se añade ese:
                # meter todos los de la materia se llevaría por delante los que
                # quitaste del objetivo a propósito.
                nuevos = {uno.id for uno in de_la_materia} - suyos
                if nuevos:
                    repo.poner_temas_de_meta(
                        conexion, meta.id, sorted(suyos | {max(nuevos)})
                    )
            self.refrescar()

        return guardado

    def _corregir_tema(self, tema: Tema) -> None:
        dialogo_educacion.abrir_tema(
            self.pagina, self.paleta, self.hoy, self.refrescar,
            materia_id=tema.materia_id, tema=tema,
        )

    def _mover_dominio(self, tema: Tema, hacia_arriba: bool) -> None:
        with conectado() as conexion:
            repo.cambiar_dominio(
                conexion, tema.id, siguiente_dominio(tema.dominio, hacia_arriba)
            )
        self.refrescar()

    def _nuevo_evento(self, tipo: TipoEvento, fecha: date | None = None) -> None:
        dialogo_educacion.abrir_evento(
            self.pagina,
            self.paleta,
            self.materias,
            self.temas,
            self.hoy,
            self.refrescar,
            fecha=fecha or self.hoy,
            tipo=tipo,
        )

    def _corregir_evento(self, evento: Evento) -> None:
        dialogo_educacion.abrir_evento(
            self.pagina,
            self.paleta,
            self.materias,
            self.temas,
            self.hoy,
            self.refrescar,
            evento=evento,
        )

    def _marcar(self, evento: Evento) -> None:
        """Las sesiones preguntan cuánto y cómo fue; lo demás se marca y ya.

        UNA TAREA NO TIENE "CÓMO TE FUE": preguntarlo por cada entrega sería
        pedir por pedir, y a la tercera vez nadie marca nada.
        """
        if evento.tipo is TipoEvento.SESION:
            dialogo_educacion.abrir_registro(
                self.pagina, self.paleta, evento, self.hoy, self.refrescar
            )
            return
        with conectado() as conexion:
            repo.marcar_hecho(conexion, evento.id, self.hoy)
        self.refrescar()

    def _desmarcar(self, evento: Evento) -> None:
        with conectado() as conexion:
            repo.desmarcar(conexion, evento.id)
        self.refrescar()

    def _nueva_meta(self) -> None:
        dialogo_educacion.abrir_meta(
            self.pagina, self.paleta, self.materias, self.temas, self.hoy,
            self.refrescar,
        )

    def _corregir_meta(self, meta) -> None:
        dialogo_educacion.abrir_meta(
            self.pagina, self.paleta, self.materias, self.temas, self.hoy,
            self.refrescar, meta,
        )

    def _cumplir_meta(self, meta) -> None:
        with conectado() as conexion:
            repo.actualizar_meta(
                conexion,
                replace(meta, cumplida_en=None if meta.cumplida else self.hoy),
            )
        self.refrescar()

    def _borrar_meta(self, meta) -> None:
        def borrar(_):
            with conectado() as conexion:
                repo.borrar_meta(conexion, meta.id)
                repo.limpiar_materias_sueltas(conexion)
            self.pagina.pop_dialog()
            self.refrescar()

        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo="Borrar el objetivo",
            texto=f"Se borra «{meta.nombre}». Sus temas no se tocan.",
            al_aceptar=borrar,
        )


# ---------------------------------------------------------------------------


def _color_de_prioridad(paleta: Paleta, prioridad: Prioridad) -> str:
    return {
        Prioridad.ALTA: paleta.negativo,
        Prioridad.MEDIA: paleta.acento,
        Prioridad.BAJA: paleta.muted,
    }[prioridad]


def _dia_corto(dia: date, hoy: date) -> str:
    """"hoy", "mañana", "atrasado" o "22/09". Lo que diría una persona."""
    dias = (dia - hoy).days
    if dias == 0:
        return "hoy"
    if dias == 1:
        return "mañana"
    if dias < 0:
        return "atrasado"
    return dia.strftime("%d/%m")

