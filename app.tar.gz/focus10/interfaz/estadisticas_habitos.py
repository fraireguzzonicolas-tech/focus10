"""Cómo se ven las estadísticas de hábitos: la tarjeta compacta del Dashboard y
la pestaña completa de Hábitos.

LAS DOS SALEN DEL MISMO Resumen (dominio/estadisticas_habitos.py), así que
enseñan los mismos números. La del Dashboard es un vistazo; la de Hábitos, el
análisis entero.

LOS COLORES SON LOS DEL TEMA, lo decidió el usuario: la curva y el porcentaje
van en el acento (violeta en Electric, rosa en Ochentas, blanco en Elegante), y
en el mapa de calor cada hábito lleva su propio color, como en el resto de la
aplicación.

TODO CABE A LO ANCHO DEL MÓVIL, sin deslizar de costado (regla del usuario): el
mapa de calor de un mes son 31 cuadraditos que se encogen hasta caber, y el año
se enseña por meses en vez de por días.
"""

from __future__ import annotations

from collections.abc import Callable

import flet as ft
import flet.canvas as cv

from ..dominio.estadisticas_habitos import (
    DeUnHabito,
    Estado,
    Periodo,
    Resumen,
    por_meses,
)
from ..dominio.semana import LETRAS, MESES
from . import componentes, estilo
from .estilo import Paleta, con_opacidad

ALTO_CURVA_COMPACTA = 70
ALTO_CURVA = 140
GROSOR = 2.5
HUECO_CASILLA = 2
LADO_MAXIMO_CASILLA = 22

PERIODOS = [(uno.value, uno.value.capitalize()) for uno in Periodo]


# --------------------------------------------------------------------- piezas


def anillo(paleta: Paleta, porcentaje: int | None, *, lado: int = 76) -> ft.Control:
    """El porcentaje dentro de un anillo. Sin dato, «—» y el anillo vacío.

    «—» Y NO «0 %»: si todavía no había nada que cumplir, un cero diría que lo
    fallaste todo.
    """
    return ft.Stack(
        [
            ft.ProgressRing(
                value=(porcentaje or 0) / 100,
                width=lado,
                height=lado,
                stroke_width=max(5, lado // 11),
                color=paleta.acento,
                bgcolor=paleta.borde,
            ),
            ft.Container(
                content=ft.Text(
                    "—" if porcentaje is None else f"{porcentaje}%",
                    size=round(lado * 0.24),
                    weight=ft.FontWeight.W_700,
                    color=paleta.ink,
                ),
                width=lado,
                height=lado,
                alignment=ft.Alignment.CENTER,
            ),
        ],
        width=lado,
        height=lado,
    )


def numeros(paleta: Paleta, resumen: Resumen) -> ft.Control:
    """Completados, restantes y en qué día del período vas."""

    def renglon(etiqueta: str, valor: str) -> ft.Control:
        return ft.Row(
            [
                ft.Text(etiqueta, size=estilo.TEXTO_APOYO, color=paleta.muted),
                ft.Text(valor, size=estilo.TEXTO, weight=ft.FontWeight.W_600, color=paleta.ink),
            ],
            spacing=6,
            tight=True,
        )

    return ft.Column(
        [
            renglon("Completados", str(resumen.total.cumplidos)),
            renglon("Restantes", str(resumen.total.restantes)),
            renglon("Día", f"{resumen.dia_actual} de {resumen.dias_totales}"),
        ],
        spacing=4,
        tight=True,
    )


def curva(paleta: Paleta, resumen: Resumen, *, ancho: int, alto: int) -> ft.Control:
    """El porcentaje de cada día del período, como una línea con su sombra.

    LOS DÍAS QUE NO LLEGARON, Y LOS QUE NO TENÍAN NADA QUE CUMPLIR, NO SE
    DIBUJAN: la línea se corta en vez de caer a cero, porque «no había nada» o
    «todavía no pasó» no es lo mismo que «lo fallaste».
    """
    dias = resumen.por_dia
    total = max(len(dias) - 1, 1)
    puntos = [
        (ancho * indice / total, alto - 4 - (alto - 8) * dia.proporcion)
        for indice, dia in enumerate(dias)
        if dia.hay_algo_programado and dia.jornada <= resumen.hoy
    ]
    linea = ft.Paint(color=paleta.acento, stroke_width=GROSOR, style=ft.PaintingStyle.STROKE)
    sombra = ft.Paint(color=con_opacidad(paleta.acento, 0.14))
    fondo = ft.Paint(color=paleta.borde, stroke_width=1)

    formas: list[cv.Shape] = [cv.Line(0, alto - 1, ancho, alto - 1, paint=fondo)]
    if len(puntos) >= 2:
        trazo = _trazo_suave(puntos)
        # LA SOMBRA DEBAJO: la misma forma cerrada contra el suelo. Hace que se
        # lea como «cuánto» y no solo como «sube y baja».
        formas.append(
            cv.Path(
                [
                    cv.Path.MoveTo(puntos[0][0], alto),
                    cv.Path.LineTo(*puntos[0]),
                    *trazo,
                    cv.Path.LineTo(puntos[-1][0], alto),
                    cv.Path.Close(),
                ],
                paint=sombra,
            )
        )
        formas.append(cv.Path([cv.Path.MoveTo(*puntos[0]), *trazo], paint=linea))
    if len(puntos) == 1:
        formas.append(cv.Circle(puntos[0][0], puntos[0][1], 3.5, paint=ft.Paint(color=paleta.acento)))

    return ft.Container(content=cv.Canvas(formas, expand=True), width=ancho, height=alto)


def _trazo_suave(puntos: list[tuple[float, float]]) -> list:
    """La línea como curva, PASANDO POR LOS MISMOS PUNTOS.

    SOLO CAMBIA EL DIBUJO, NO EL DATO: cada día sigue en su altura exacta; lo
    que se redondea es el camino ENTRE dos días. En zigzag, treinta días se
    leían como ruido; así se lee la tendencia, como en la referencia que mandó
    el usuario.

    Cada tramo es una curva que sale de un punto y llega al siguiente, con los
    dos «tiradores» a media distancia en horizontal: así nunca se pasa por
    encima ni por debajo de los puntos reales (no inventa picos).
    """
    trazo = []
    for (x0, y0), (x1, y1) in zip(puntos, puntos[1:], strict=False):
        medio = (x0 + x1) / 2
        trazo.append(cv.Path.CubicTo(medio, y0, medio, y1, x1, y1))
    return trazo


def _color_de(paleta: Paleta, habito, estado: Estado) -> str:
    color = paleta.color_de(habito.color)
    return {
        Estado.CUMPLIDO: color,
        Estado.FALLADO: con_opacidad(color, 0.16),
        Estado.PENDIENTE: con_opacidad(color, 0.45),
        # El fondo de la tarjeta: ese día el hábito no existía.
        Estado.NO_TOCABA: paleta.surface,
        Estado.FUTURO: con_opacidad(paleta.borde, 0.5),
    }[estado]


def mapa_de_calor(paleta: Paleta, resumen: Resumen, ancho: int) -> ft.Control:
    """Cada hábito, y debajo un cuadradito por día: lleno si lo cumpliste.

    EL NOMBRE VA ENCIMA DE SU FILA Y NO AL LADO: al lado se comía un tercio del
    ancho, y en un móvil los 31 días del mes ya no cabían.
    """
    dias = sorted(next(iter(resumen.habitos)).estados) if resumen.habitos else []
    cuantos = max(len(dias), 1)
    lado = max(4, min(LADO_MAXIMO_CASILLA, (ancho - HUECO_CASILLA * (cuantos - 1)) // cuantos))
    filas: list[ft.Control] = []
    for uno in resumen.habitos:
        filas.append(ft.Text(uno.habito.nombre, size=estilo.TEXTO_APOYO, color=paleta.ink_soft,
                             max_lines=1, overflow=ft.TextOverflow.ELLIPSIS))
        filas.append(
            ft.Row(
                [
                    ft.Container(
                        width=lado,
                        height=lado,
                        border_radius=max(2, lado // 4),
                        bgcolor=_color_de(paleta, uno.habito, uno.estados[dia]),
                        border=ft.Border.all(1, paleta.borde)
                        if uno.estados[dia] in (Estado.PENDIENTE, Estado.NO_TOCABA)
                        else None,
                        tooltip=f"{dia.day}/{dia.month}: {uno.estados[dia].value}",
                    )
                    for dia in dias
                ],
                spacing=HUECO_CASILLA,
            )
        )
    return ft.Column(filas, spacing=4, tight=True)


def _barra(paleta: Paleta, porcentaje: int | None, color: str) -> ft.Control:
    return ft.ProgressBar(
        value=(porcentaje or 0) / 100,
        color=color,
        bgcolor=paleta.borde,
        bar_height=8,
        border_radius=4,
    )


def fila_de_habito(paleta: Paleta, uno: DeUnHabito) -> ft.Control:
    """Un hábito: su porcentaje, su barra y sus rachas."""
    pct = uno.cuenta.porcentaje
    return ft.Column(
        [
            ft.Row(
                [
                    ft.Text(uno.habito.nombre, size=estilo.TEXTO, color=paleta.ink,
                            weight=ft.FontWeight.W_500, expand=True, max_lines=1,
                            overflow=ft.TextOverflow.ELLIPSIS),
                    ft.Text("—" if pct is None else f"{pct}%", size=estilo.TEXTO,
                            weight=ft.FontWeight.W_600, color=paleta.ink),
                ],
            ),
            _barra(paleta, pct, paleta.color_de(uno.habito.color)),
            ft.Text(
                f"{uno.cuenta.cumplidos} de {uno.cuenta.base} · racha {uno.rachas.actual} "
                f"· mejor {uno.rachas.mejor}",
                size=estilo.TEXTO_APOYO,
                color=paleta.muted,
            ),
        ],
        spacing=4,
        tight=True,
    )


def _por_meses(paleta: Paleta, resumen: Resumen, ancho: int) -> ft.Control:
    """El año: por cada hábito, doce barritas verticales, una por mes."""
    lado = max(6, (ancho - 11 * 3) // 12)
    filas: list[ft.Control] = []
    for uno in resumen.habitos:
        color = paleta.color_de(uno.habito.color)
        meses = por_meses(uno, resumen.desde.year)
        filas.append(ft.Text(uno.habito.nombre, size=estilo.TEXTO_APOYO, color=paleta.ink_soft,
                             max_lines=1, overflow=ft.TextOverflow.ELLIPSIS))
        filas.append(
            ft.Row(
                [
                    ft.Container(
                        content=ft.Container(
                            height=max(2, round(28 * (pct or 0) / 100)),
                            bgcolor=color,
                            border_radius=2,
                        ),
                        width=lado,
                        height=28,
                        alignment=ft.Alignment.BOTTOM_CENTER,
                        bgcolor=con_opacidad(paleta.borde, 0.35),
                        border_radius=2,
                        tooltip=f"{MESES[n]}: {'—' if pct is None else f'{pct}%'}",
                    )
                    for n, pct in enumerate(meses)
                ],
                spacing=3,
            )
        )
    return ft.Column(filas, spacing=4, tight=True)


# --------------------------------------------------------------------- tarjetas


def tarjeta_compacta(paleta: Paleta, resumen: Resumen) -> ft.Control:
    """Para el Dashboard: «¿cómo voy este mes con mis hábitos?», de un vistazo.

    UN VISTAZO Y NO UNA PANTALLA: el anillo con el porcentaje, tres números y
    una curva baja del mes. El análisis entero está en Hábitos → Estadísticas.
    """
    # UN ANCHO MODERADO, QUE CABE EN LOS DOS SITIOS: en la PC esta tarjeta
    # ocupa media ventana, y en el móvil, el ancho entero de 375.
    ancho = estilo.ancho_de_grafico(360, margenes=72)
    return componentes.tarjeta(
        paleta,
        ft.Column(
            [
                componentes.cabecera_tarjeta(paleta, "Tus hábitos este mes"),
                ft.Row(
                    [anillo(paleta, resumen.total.porcentaje, lado=64), numeros(paleta, resumen)],
                    spacing=16,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                curva(paleta, resumen, ancho=ancho, alto=ALTO_CURVA_COMPACTA),
            ],
            spacing=12,
            tight=True,
        ),
    )


def vista_completa(
    paleta: Paleta,
    resumen: Resumen,
    al_cambiar_periodo: Callable[[str], None],
) -> list[ft.Control]:
    """La pestaña Estadísticas entera, para el período elegido."""
    ancho = estilo.ancho_de_grafico(760, margenes=72)
    piezas: list[ft.Control] = [
        componentes.segmentado(paleta, PERIODOS, resumen.periodo.value, al_cambiar_periodo)
    ]

    cabeza: list[ft.Control] = [
        ft.Row(
            [anillo(paleta, resumen.total.porcentaje, lado=88), numeros(paleta, resumen)],
            spacing=20,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )
    ]
    # EL DÍA NO TIENE CURVA: es un solo punto. Ahí manda la lista de abajo.
    if resumen.periodo is not Periodo.DIA:
        cabeza.append(curva(paleta, resumen, ancho=ancho, alto=ALTO_CURVA))
        cabeza.append(_etiquetas(paleta, resumen, ancho))
    piezas.append(componentes.tarjeta(paleta, ft.Column(
        [componentes.cabecera_tarjeta(paleta, f"Progreso {_del_periodo(resumen.periodo)}"), *cabeza],
        spacing=12, tight=True,
    )))

    if not resumen.habitos:
        piezas.append(componentes.aviso_vacio(paleta, "Todavía no tienes hábitos. Créalos en la pestaña Hábitos."))
        return piezas

    piezas.append(_manteniendo_y_fallando(paleta, resumen))

    ordenados = sorted(
        resumen.habitos,
        key=lambda uno: -1 if uno.cuenta.porcentaje is None else uno.cuenta.porcentaje,
        reverse=True,
    )
    piezas.append(componentes.tarjeta(paleta, ft.Column(
        [componentes.cabecera_tarjeta(paleta, "Cada hábito", "de mejor a peor")]
        + [fila_de_habito(paleta, uno) for uno in ordenados],
        spacing=14, tight=True,
    )))

    detalle = (
        _por_meses(paleta, resumen, ancho)
        if resumen.periodo is Periodo.ANO
        else mapa_de_calor(paleta, resumen, ancho)
    )
    piezas.append(componentes.tarjeta(paleta, ft.Column(
        [componentes.cabecera_tarjeta(paleta, "Mes por mes" if resumen.periodo is Periodo.ANO else "Día por día"),
         detalle],
        spacing=12, tight=True,
    )))
    return piezas


def _del_periodo(periodo: Periodo) -> str:
    return {Periodo.DIA: "de hoy", Periodo.SEMANA: "de la semana",
            Periodo.MES: "del mes", Periodo.ANO: "del año"}[periodo]


def _etiquetas(paleta: Paleta, resumen: Resumen, ancho: int) -> ft.Control:
    """Algunas marcas bajo la curva: las letras de la semana, días del mes o meses."""
    if resumen.periodo is Periodo.SEMANA:
        textos = list(LETRAS)
    elif resumen.periodo is Periodo.MES:
        textos = ["1", "8", "15", "22", str(resumen.dias_totales)]
    else:
        textos = [MESES[n][:3].capitalize() for n in (0, 3, 6, 9, 11)]
    return ft.Row(
        [ft.Text(t, size=11, color=paleta.muted) for t in textos],
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        width=ancho,
    )


def _manteniendo_y_fallando(paleta: Paleta, resumen: Resumen) -> ft.Control:
    """La respuesta corta a «cuáles mantengo y cuáles estoy fallando»."""
    bien, mal = resumen.mejores_y_peores()

    def lista(titulo: str, cuales: list[DeUnHabito], vacio: str) -> ft.Control:
        return ft.Column(
            [ft.Text(titulo, size=estilo.TEXTO_APOYO, color=paleta.muted)]
            + (
                [ft.Text(f"{u.habito.nombre} · {u.cuenta.porcentaje}%", size=estilo.TEXTO,
                         color=paleta.ink) for u in cuales]
                or [ft.Text(vacio, size=estilo.TEXTO_APOYO, color=paleta.muted)]
            ),
            spacing=4,
            tight=True,
        )

    return componentes.tarjeta(paleta, ft.Column(
        [
            componentes.cabecera_tarjeta(paleta, "Cómo vas"),
            lista("✅ Manteniendo (80% o más)", bien, "Ninguno todavía."),
            lista("⚠️ Fallando (menos de 50%)", mal, "Ninguno. Bien."),
        ],
        spacing=12,
        tight=True,
    ))
