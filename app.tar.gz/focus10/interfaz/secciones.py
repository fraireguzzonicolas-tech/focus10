"""Las secciones de Focus, en el orden del menú, y por cuál se abre.

APARTE DE app.py para que la ventana y sus dos partes (app_entreno.py y
app_marco.py) las lean del mismo sitio sin importarse en círculo.
"""

from __future__ import annotations

import flet as ft

# Las secciones, en el orden en que se enseñan, con su icono.
SECCIONES = (
    ("Dashboard", ft.Icons.SPACE_DASHBOARD_OUTLINED),
    # LA COMUNIDAD, JUSTO DESPUÉS DEL DASHBOARD: lo pidió el usuario como
    # «otro apartado» propio. Desde el 8 nov 2026 es SOLO el ranking: quién va
    # primero en constancia. Ver interfaz/comunidad.py.
    # EL ÍCONO ES UN TROFEO y no un grupo de gente: ya no es una red social.
    ("Comunidad", ft.Icons.EMOJI_EVENTS_OUTLINED),
    ("Horario", ft.Icons.GRID_ON_OUTLINED),
    ("Finanzas", ft.Icons.ACCOUNT_BALANCE_WALLET_OUTLINED),
    ("Objetivos", ft.Icons.FLAG_OUTLINED),
    # EDUCACIÓN OCUPA EL SITIO DE INVERSIONES, que pasó a ser una pestaña de
    # Finanzas. Mismo lugar a propósito: el orden del menú no cambia.
    ("Educación", ft.Icons.SCHOOL_OUTLINED),
    # LA PIZARRA INFINITA, AL LADO DE EDUCACIÓN: es para estudiar. En la PC y
    # en el celular (lo eligió el usuario el 8 nov 2026).
    ("Pizarra", ft.Icons.DRAW_OUTLINED),
    ("Hábitos", ft.Icons.REPEAT),
    ("Gimnasio", ft.Icons.FITNESS_CENTER),
    ("Alimentación", ft.Icons.RESTAURANT_OUTLINED),
    ("Focus", ft.Icons.CENTER_FOCUS_STRONG_OUTLINED),
    ("Configuración", ft.Icons.SETTINGS_OUTLINED),
)

NOMBRE_SECCION_INICIAL = "Dashboard"
"""Por dónde se abre la aplicación.

EL DASHBOARD, y lo pidió el usuario. Antes se abría en Finanzas, con el
razonamiento de que era "la única que hace algo a diario". Ese razonamiento se
quedó viejo: desde que el Dashboard resume el día entero —los hábitos, las
tareas, el horario de hoy y los gastos— es la pantalla que contesta "¿qué tengo
que hacer ahora?", que es justo la pregunta con la que se abre una aplicación
así.

SE GUARDA EL NOMBRE Y NO EL NÚMERO a propósito. Antes era un 1 a pelo, y al
meter "Horario" en segundo lugar la aplicación habría arrancado en el horario
sin que nadie lo pidiera. Un número que hay que acordarse de mover cada vez que
cambia una lista se acaba quedando atrás.
"""

SECCION_INICIAL = SECCIONES.index(
    next(uno for uno in SECCIONES if uno[0] == NOMBRE_SECCION_INICIAL)
)
