"""La sección Pizarra: las carpetas a la izquierda y la pizarra infinita.

LO PIDIÓ EL USUARIO (11 nov 2026): una pizarra infinita tipo Miro dentro de
Focus, en su propia sección del menú, en la PC y en el celular. Las carpetas
llevan nombre y adentro van las pizarras, que se renombran, duplican y borran.

LA PIZARRA EN SÍ ES DE FLUTTER (extensiones/focus10_pizarra): moverse,
dibujar, elegir y deshacer pasan allá, sin ir y volver a Python a cada
movimiento. Esta pantalla solo le da el documento y GUARDA lo que ella avisa.

EL DOCUMENTO DE LA PIEZA SE TIENE SIEMPRE AL DÍA con lo último guardado. Pasó
el 12 nov 2026: al entrar o salir de pantalla completa la pizarra se rearma, y
se rearmaba con el documento de CUANDO SE ABRIÓ; lo hecho después desaparecía
y lo siguiente se guardaba encima de esa copia vieja. Mandarle lo mismo que ya
tiene no le borra el deshacer: ella compara y, si es igual, no toca nada.

EL BOTÓN «GUARDAR» (12 nov 2026, lo pidió el usuario): todo se guarda solo al
terminar cada cambio, MENOS el texto que se está escribiendo, que se guarda al
terminarlo. El botón lo termina y guarda ya, y la hora de «Guardado» lo
confirma. Está arriba y, en pantalla completa, al lado de la flecha.

LAS IMÁGENES (12 nov 2026): Ctrl V o el botón «Imagen». Lo de pegar,
guardar y subir vive en pizarra_imagenes.py; aquí solo se conecta.

PANTALLA COMPLETA (12 nov 2026): la pizarra ocupa todo el monitor, sin el
menú de Focus ni el panel de carpetas; la flecha de la esquina (o Esc, cuando
la pizarra no lo usa para otra cosa) vuelve. Lo de esconder el menú lo hace la
ventana (app.Ventana.pantalla_completa): esta pantalla solo se lo pide.

SIN LA PIEZA DE FLUTTER (Focus abierto desde el código con abrir.py, o un APK
viejo) la pizarra no se puede dibujar: se dice, en vez de una pantalla rota.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Callable

import flet as ft

from ..datos import ajustes
from ..datos import repositorio_pizarra as repo
from ..datos.bd import conectado
from ..dominio import pizarra_documento as documentos
from . import componentes, estilo
from .estilo import Paleta
from .pizarra_imagenes import ImagenesDePizarra

ANCHO_PANEL = 250


def _ahora() -> datetime:
    """La hora de ahora AL SEGUNDO: la base no guarda microsegundos (fechas.py)."""
    return datetime.now().replace(microsecond=0)


def pieza_de_flutter():
    """La clase Pizarra de la extensión, o None si este Focus no la trae."""
    try:
        from focus10_pizarra import Pizarra
    except ImportError:
        return None
    return Pizarra


def tema_de(paleta: Paleta) -> str:
    """Los colores de Focus para la pizarra, en JSON (ver tema.dart)."""
    return json.dumps({
        "fondo": paleta.surface,
        "rejilla": paleta.borde,
        "tinta": paleta.ink,
        "suave": paleta.muted,
        "acento": paleta.acento,
        "acento_tinta": paleta.acento_ink,
        "superficie": paleta.surface_2,
        "nombres": estilo.COLORES_DE_PARTIDA,
    })


class PantallaPizarra(componentes.Pantalla):
    def __init__(
        self,
        pagina: ft.Page,
        paleta: Paleta,
        al_pantalla_completa: Callable[[bool], None] | None = None,
        portapapeles: ft.Clipboard | None = None,
        selector: ft.FilePicker | None = None,
    ) -> None:
        super().__init__(pagina, paleta)
        self.al_pantalla_completa = al_pantalla_completa
        self.imagenes = ImagenesDePizarra(
            pagina, lambda: self.lienzo, lambda: self.documento,
            portapapeles=portapapeles, selector=selector,
        )
        self.completa = False
        self.cuadernos: list[repo.Cuaderno] = []
        self.paginas: list[repo.Pagina] = []
        self.cuaderno_id: int | None = None
        # LA CARPETA DE `cuaderno_id` ESTÁ ABIERTA EN LA BARRA (se cierra con
        # su flecha), y dentro, el bloque «Pizarras» también se puede plegar.
        # Al empezar, abierta: la de la última pizarra, como eligió el usuario.
        self.carpeta_abierta = True
        self.bloque_abierto = True
        self.pagina_id: int | None = None
        self.documento: dict | None = None
        self.guardado = ""
        """El último JSON guardado desde aquí: para saber si lo que llega de la
        nube es otra cosa (y entonces hay que mandárselo a la pizarra)."""
        self.lienzo: ft.Control | None = None
        self.estado = ft.Text("", size=estilo.ROTULO, color=paleta.muted)
        self.raiz = ft.Row(spacing=0, expand=True, vertical_alignment=ft.CrossAxisAlignment.START)
        with conectado() as conexion:
            ultima = ajustes.leer(conexion, ajustes.CLAVE_PIZARRA_ULTIMA)
        self._abrir_al_empezar(int(ultima) if ultima.isdigit() else None)
        # LAS QUE QUEDARON SIN SUBIR (sin internet la otra vez), ahora.
        self.imagenes.subir_si_quedaron()

    @property
    def control(self) -> ft.Control:
        return self.raiz

    # ------------------------------------------------------------ leer

    def _leer(self) -> None:
        with conectado() as conexion:
            self.cuadernos = repo.listar_cuadernos(conexion)
            ids = {c.id for c in self.cuadernos}
            if self.cuaderno_id not in ids:
                self.cuaderno_id = self.cuadernos[0].id if self.cuadernos else None
            self.paginas = (
                repo.listar_paginas(conexion, self.cuaderno_id) if self.cuaderno_id else []
            )

    def _abrir_al_empezar(self, pagina_id: int | None) -> None:
        if pagina_id is not None:
            with conectado() as conexion:
                fila = conexion.execute(
                    "SELECT cuaderno_id FROM pizarra_paginas WHERE id = ?", (pagina_id,)
                ).fetchone()
            if fila is not None:
                self.cuaderno_id = fila["cuaderno_id"]
        self._leer()
        ids = [p.id for p in self.paginas]
        self._abrir_pagina(pagina_id if pagina_id in ids else (ids[0] if ids else None))

    def _abrir_pagina(self, pagina_id: int | None) -> None:
        self.pagina_id = pagina_id
        self.documento = None
        self.lienzo = None
        if pagina_id is not None:
            with conectado() as conexion:
                self.documento = repo.leer_documento(conexion, pagina_id)
                ajustes.escribir(conexion, ajustes.CLAVE_PIZARRA_ULTIMA, str(pagina_id))
            if self.documento is not None:
                self.guardado = documentos.a_guardado(self.documento)
                self.lienzo = self._lienzo()
                self.imagenes.traer(self.documento)
        self.estado.value = ""
        self._dibujar()

    def refrescar(self) -> None:
        """Llegó algo de la nube. Si cambió la pizarra abierta, se le manda.

        SOLO SI CAMBIÓ DE VERDAD: lo de aquí ya está guardado, así que lo
        guardado y lo de la pantalla coinciden salvo que otro aparato haya
        tocado esta misma pizarra. Mandarlo siempre le borraría el deshacer.
        """
        self._leer()
        if self.pagina_id not in [p.id for p in self.paginas]:
            self._abrir_pagina(self.paginas[0].id if self.paginas else None)
            return
        with conectado() as conexion:
            guardado = repo.leer_documento(conexion, self.pagina_id)
        if guardado is not None and self.lienzo is not None:
            texto = documentos.a_guardado(guardado)
            if texto != self.guardado:
                self.documento, self.guardado = guardado, texto
                self.lienzo.documento = texto
                self.lienzo.rejilla = bool(guardado.get("rejilla", True))
                # LO QUE LLEGÓ PUEDE TRAER IMÁGENES de otro aparato.
                self.imagenes.traer(guardado)
        self.imagenes.subir_si_quedaron()
        self._dibujar()

    # ------------------------------------------------------------ la pizarra

    def _lienzo(self) -> ft.Control | None:
        Pizarra = pieza_de_flutter()
        if Pizarra is None:
            return None
        with conectado() as conexion:
            vistas = _leer_vistas(ajustes.leer(conexion, ajustes.CLAVE_PIZARRA_VISTAS))
        return Pizarra(
            clave=str(self.pagina_id),
            documento=self.guardado,
            tema=tema_de(self.paleta),
            vista=json.dumps(vistas[str(self.pagina_id)]) if str(self.pagina_id) in vistas else "",
            rejilla=bool(self.documento.get("rejilla", True)),
            fuente=estilo.FUENTE,
            carpeta=self.imagenes.carpeta(),
            imagenes=self.imagenes.disponibles(self.documento),
            expand=True,
            on_documento=self._al_cambiar_documento,
            on_vista=self._al_cambiar_vista,
            on_rejilla=self._al_cambiar_rejilla,
            on_escape=lambda _: self.pantalla_completa(False),
            on_pegar=self._al_pegar,
        )

    async def _al_pegar(self, e) -> None:
        try:
            punto = json.loads(e.data)
            x, y = float(punto["x"]), float(punto["y"])
        except (TypeError, ValueError, KeyError):
            x = y = None
        await self.imagenes.pegar(None if x is None else (x, y))

    def _al_cambiar_documento(self, e) -> None:
        try:
            nuevo = json.loads(e.data)
        except (TypeError, ValueError):
            return
        if not isinstance(nuevo, dict):
            return
        # LA CUADRÍCULA LA GUARDA FOCUS, no la pizarra: va dentro del mismo
        # documento para que viaje con él.
        nuevo["rejilla"] = bool((self.documento or {}).get("rejilla", True))
        self._guardar(nuevo)

    def _al_cambiar_rejilla(self, e) -> None:
        if self.documento is None:
            return
        prendida = e.data if isinstance(e.data, bool) else str(e.data).lower() == "true"
        self._guardar({**self.documento, "rejilla": prendida})

    def _al_cambiar_vista(self, e) -> None:
        try:
            vista = json.loads(e.data)
        except (TypeError, ValueError):
            return
        with conectado() as conexion:
            vistas = _leer_vistas(ajustes.leer(conexion, ajustes.CLAVE_PIZARRA_VISTAS))
            vistas[str(self.pagina_id)] = vista
            ajustes.escribir(conexion, ajustes.CLAVE_PIZARRA_VISTAS, json.dumps(vistas))
        # Y LA VISTA TAMBIÉN AL DÍA: rearmada, la pizarra vuelve a donde estabas.
        if self.lienzo is not None:
            self.lienzo.vista = json.dumps(vista)

    def _guardar(self, documento: dict) -> None:
        try:
            with conectado() as conexion:
                sigue = repo.guardar_documento(conexion, self.pagina_id, documento, _ahora())
        except documentos.DocumentoLleno:
            # LO QUE NO ENTRA NO SE GUARDA, Y SE DICE: lo de antes queda a salvo.
            componentes.avisar(
                self.pagina,
                "Esta pizarra está llena y lo último no se guardó: deshacelo (Ctrl Z) "
                "o seguí en otra pizarra.",
            )
            return
        if not sigue:
            componentes.avisar(self.pagina, "Esta pizarra se borró en otro aparato.")
            self.refrescar()
            return
        self.documento = documento
        self.guardado = documentos.a_guardado(documento)
        # AL DÍA: si la pizarra se rearma (pantalla completa, renombrar), que
        # arranque con esto y no con lo que tenía al abrirse.
        if self.lienzo is not None:
            self.lienzo.documento = self.guardado
            self.lienzo.rejilla = bool(documento.get("rejilla", True))
        self.estado.value = "Guardado " + _ahora().strftime("%H:%M")
        self._actualizar(self.estado)

    # ------------------------------------------------------------ pantalla completa

    async def guardar_ya(self, _=None) -> None:
        """El botón «Guardar»: la pizarra termina lo que se escribe y avisa el
        documento, y _guardar lo guarda y pone la hora."""
        if self.lienzo is None:
            return
        try:
            listo = await self.lienzo.guardar()
        except Exception:  # noqa: BLE001  (la pieza no contestó: tiempo agotado, ventana cerrándose)
            listo = False
        if not listo:
            componentes.avisar(self.pagina, "No se pudo guardar ahora: probá de nuevo en un momento.")

    def _boton_guardar(self) -> ft.Control:
        return componentes.boton_icono(
            self.paleta, ft.Icons.SAVE_OUTLINED, ayuda="Guardar", al_pulsar=self.guardar_ya,
        )

    def _boton_imagen(self) -> ft.Control:
        """«Imagen»: elegir un archivo, o pegar la copiada. EN EL CELULAR ES LA
        ÚNICA FORMA (no hay Ctrl V); en la PC, Ctrl V es más rápido."""
        async def pegar(_):
            await self.imagenes.pegar(None)

        return ft.PopupMenuButton(
            icon=ft.Icons.ADD_PHOTO_ALTERNATE_OUTLINED, icon_color=self.paleta.ink,
            tooltip="Imagen (o Ctrl V)",
            items=[
                ft.PopupMenuItem("Elegir una imagen…", on_click=self.imagenes.elegir),
                ft.PopupMenuItem("Pegar la imagen copiada", on_click=pegar),
            ],
        )

    def pantalla_completa(self, activar: bool) -> None:
        if activar == self.completa or self.al_pantalla_completa is None:
            return
        self.completa = activar
        self._dibujar()
        self.al_pantalla_completa(activar)

    # ------------------------------------------------------------ dibujar

    def _dibujar(self) -> None:
        angosto = estilo.pantalla_estrecha()
        if self.completa and self.lienzo is not None:
            self.raiz.controls = [self._a_pantalla_completa()]
        else:
            self.raiz.controls = (
                [self._trabajo(angosto)] if angosto
                else [self._panel(), ft.VerticalDivider(width=1, color=self.paleta.borde), self._trabajo(angosto)]
            )
        if self._en_pagina:
            self.raiz.update()

    def _actualizar(self, control: ft.Control) -> None:
        if self._en_pagina:
            try:
                control.update()
            except Exception:  # noqa: BLE001
                pass

    def _panel(self) -> ft.Control:
        paleta = self.paleta
        filas: list[ft.Control] = [ft.Row(
            [
                ft.Text("Carpetas", size=estilo.SUBTITULAR, weight=ft.FontWeight.W_600,
                        color=paleta.ink, font_family=paleta.titular, expand=True),
                componentes.boton_icono(paleta, ft.Icons.CREATE_NEW_FOLDER_OUTLINED, ayuda="Carpeta nueva",
                                        al_pulsar=lambda _: self._pedir_nombre_cuaderno()),
            ],
        )]
        # CADA CARPETA SE ABRE Y SE CIERRA CON SU FLECHA, y de a una: abrir
        # otra cierra la que estaba. Lo pidió el usuario (19 nov 2026) para que
        # la barra no se alargue con todas las pizarras de todas las carpetas.
        for cuaderno in self.cuadernos:
            abierta = cuaderno.id == self.cuaderno_id and self.carpeta_abierta
            filas.append(self._fila_carpeta(cuaderno, abierta))
            if abierta:
                filas.append(self._bloque_pizarras())
        if not self.cuadernos:
            filas.append(ft.Text(
                "Creá tu primera carpeta con el botón de arriba.",
                size=estilo.TEXTO_APOYO, color=paleta.muted,
            ))
        return ft.Container(
            ft.Column(filas, spacing=2, scroll=ft.ScrollMode.AUTO),
            width=ANCHO_PANEL, padding=ft.Padding.only(right=12),
        )

    def _fila_carpeta(self, cuaderno: repo.Cuaderno, abierta: bool) -> ft.Control:
        """Una carpeta: su nombre, su menú y la flecha que la abre o la cierra."""
        paleta = self.paleta
        return ft.Container(
            ft.Row(
                [
                    ft.Icon(ft.Icons.FOLDER_OPEN_OUTLINED if abierta else ft.Icons.FOLDER_OUTLINED,
                            size=18, color=paleta.ink_soft),
                    ft.Text(cuaderno.nombre, size=estilo.TEXTO, color=paleta.ink,
                            weight=ft.FontWeight.W_600 if abierta else None,
                            max_lines=1, overflow=ft.TextOverflow.ELLIPSIS, expand=True),
                    self._menu([
                        ("Renombrar", lambda _, c=cuaderno: self._pedir_nombre_cuaderno(c)),
                        ("Borrar", lambda _, c=cuaderno: self._borrar_cuaderno(c)),
                    ]),
                    ft.Icon(ft.Icons.EXPAND_MORE if abierta else ft.Icons.CHEVRON_RIGHT,
                            size=18, color=paleta.muted),
                ],
                spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.only(left=10, right=8, top=4, bottom=4),
            # LA ABIERTA SE DISTINGUE CON UN FONDO, como en el dibujo del
            # usuario: así se ve de un vistazo dónde está el bloque.
            bgcolor=paleta.surface_2 if abierta else None,
            border_radius=10, ink=True,
            tooltip="Cerrar" if abierta else "Abrir",
            on_click=lambda _, c=cuaderno.id: self._tocar_carpeta(c),
        )

    def _bloque_pizarras(self) -> ft.Control:
        """Lo que hay dentro de la carpeta abierta: el bloque «Pizarras», con
        su propia flecha para plegarlo, y una fila por pizarra."""
        paleta = self.paleta
        cabecera = ft.Container(
            ft.Row(
                [
                    ft.Icon(ft.Icons.CO_PRESENT_OUTLINED, size=18, color=paleta.ink_soft),
                    ft.Text("Pizarras", size=estilo.TEXTO, color=paleta.ink_soft, expand=True),
                    ft.Icon(ft.Icons.EXPAND_MORE if self.bloque_abierto else ft.Icons.CHEVRON_RIGHT,
                            size=18, color=paleta.muted),
                ],
                spacing=10, vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.only(left=12, right=10, top=8, bottom=8),
            border_radius=10, ink=True,
            tooltip="Plegar" if self.bloque_abierto else "Desplegar",
            on_click=lambda _: self._plegar_bloque(),
        )
        dentro: list[ft.Control] = [cabecera]
        if self.bloque_abierto:
            for hoja in self.paginas:
                dentro.append(self._fila(
                    ft.Icons.ARTICLE_OUTLINED, hoja.titulo, hoja.id == self.pagina_id,
                    al_pulsar=lambda _, p=hoja.id: self._abrir_pagina(p),
                    menu=[
                        ("Renombrar", lambda _, p=hoja: self._pedir_titulo(p)),
                        ("Duplicar", lambda _, p=hoja: self._duplicar(p)),
                        ("Borrar", lambda _, p=hoja: self._borrar_pagina(p)),
                    ],
                ))
            dentro.append(ft.Container(
                ft.Row([ft.Icon(ft.Icons.ADD, size=14, color=paleta.muted),
                        ft.Text("Pizarra", size=estilo.TEXTO_APOYO, color=paleta.muted)],
                       spacing=6),
                padding=ft.Padding.only(left=14, top=8, bottom=8),
                on_click=lambda _: self._nueva_pagina(), ink=True, border_radius=8,
            ))
        # EL BLOQUE CUELGA DE SU CARPETA: va corrido a la derecha y con una raya
        # a la izquierda, para que se lea «esto está dentro de Italiano».
        return ft.Container(
            ft.Container(
                ft.Column(dentro, spacing=0, tight=True),
                bgcolor=paleta.surface_2, border_radius=12,
                border=ft.Border.all(1, paleta.borde),
                padding=ft.Padding.only(left=4, right=4, top=2, bottom=4),
            ),
            padding=ft.Padding.only(left=10, top=4, bottom=6),
            margin=ft.Margin.only(left=8),
            border=ft.Border.only(left=ft.BorderSide(1, paleta.borde)),
        )

    def _menu(self, opciones) -> ft.Control:
        """Los tres puntos de una fila, con lo que se puede hacer con ella."""
        paleta = self.paleta
        return ft.PopupMenuButton(
            icon=ft.Icons.MORE_HORIZ, icon_size=16, icon_color=paleta.muted, tooltip="Más",
            items=[ft.PopupMenuItem(nombre, on_click=accion) for nombre, accion in opciones],
        )

    def _fila(self, icono, texto, elegida, *, al_pulsar, menu):
        """Una pizarra del bloque. La que se está viendo va con el acento."""
        paleta = self.paleta
        return ft.Container(
            ft.Row(
                [
                    ft.Icon(icono, size=16, color=paleta.acento_ink if elegida else paleta.ink_soft),
                    ft.Text(
                        texto, size=estilo.TEXTO, color=paleta.acento_ink if elegida else paleta.ink,
                        weight=ft.FontWeight.W_600 if elegida else None,
                        max_lines=1, overflow=ft.TextOverflow.ELLIPSIS, expand=True,
                    ),
                    self._menu(menu),
                ],
                spacing=10, vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.only(left=12, right=0, top=2, bottom=2),
            bgcolor=paleta.acento if elegida else None,
            border=ft.Border.only(top=ft.BorderSide(1, paleta.borde)),
            border_radius=8, on_click=al_pulsar, ink=True,
        )

    def _trabajo(self, angosto: bool) -> ft.Control:
        paleta = self.paleta
        if self.documento is None:
            return ft.Container(
                ft.Column(
                    [
                        ft.Icon(ft.Icons.DRAW_OUTLINED, size=40, color=paleta.muted),
                        ft.Text("Tu espacio para estudiar, dibujar y organizar ideas.",
                                size=estilo.TEXTO_TARJETA, color=paleta.ink),
                        componentes.boton(paleta, "Crear una carpeta", principal=True,
                                          al_pulsar=lambda _: self._pedir_nombre_cuaderno()),
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=14, tight=True,
                ),
                expand=True, alignment=ft.Alignment.CENTER,
            )
        if self.lienzo is None:
            return self._sin_pieza()
        return ft.Column(
            [self._barra(angosto), ft.Container(self.lienzo, expand=True, border_radius=12,
                                                clip_behavior=ft.ClipBehavior.HARD_EDGE)],
            spacing=8, expand=True,
        )

    def _barra(self, angosto: bool) -> ft.Control:
        paleta = self.paleta
        if angosto:
            # EN EL CELULAR NO ENTRA EL PANEL: la pizarra se elige de una lista.
            titulo: ft.Control = ft.Container(componentes.selector(
                paleta, "Pizarra",
                [(str(p.id), p.titulo) for p in self.paginas],
                valor=str(self.pagina_id),
                al_elegir=lambda e: self._abrir_pagina(int(e.control.value)),
            ), expand=True)
            # Y LO QUE EN LA PC HACE EL PANEL, en un menú: cambiar de carpeta y
            # crear. Sin esto, desde el celular no se saldría de una carpeta.
            menu = ft.PopupMenuButton(
                icon=ft.Icons.FOLDER_OUTLINED, tooltip="Carpetas",
                items=[
                    *[ft.PopupMenuItem(c.nombre, on_click=lambda _, c=c.id: self._elegir_cuaderno(c))
                      for c in self.cuadernos],
                    ft.PopupMenuItem("Pizarra nueva", on_click=lambda _: self._nueva_pagina()),
                    ft.PopupMenuItem("Carpeta nueva", on_click=lambda _: self._pedir_nombre_cuaderno()),
                ],
            )
            return ft.Row([titulo, menu, self._boton_imagen(), self._boton_guardar(), self.estado],
                          vertical_alignment=ft.CrossAxisAlignment.CENTER)
        else:
            titulo = ft.Text(
                next((p.titulo for p in self.paginas if p.id == self.pagina_id), ""),
                size=estilo.SUBTITULAR, weight=ft.FontWeight.W_600, color=paleta.ink,
                font_family=paleta.titular, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS,
                expand=True,
            )
        botones: list[ft.Control] = [self._boton_imagen(), self._boton_guardar()] if self.lienzo is not None else []
        if self.al_pantalla_completa is not None and self.lienzo is not None:
            botones.append(componentes.boton_icono(
                paleta, ft.Icons.FULLSCREEN, ayuda="Pantalla completa",
                al_pulsar=lambda _: self.pantalla_completa(True),
            ))
        return ft.Row([titulo, self.estado, *botones], vertical_alignment=ft.CrossAxisAlignment.CENTER)

    def _a_pantalla_completa(self) -> ft.Control:
        """Solo la pizarra, de borde a borde, y la flecha para volver."""
        def boton(icono, ayuda, accion) -> ft.Control:
            return ft.Container(
                ft.IconButton(icon=icono, icon_color=self.paleta.ink, tooltip=ayuda, on_click=accion),
                bgcolor=self.paleta.surface_2, border_radius=12,
                border=ft.Border.all(1, self.paleta.borde),
            )

        volver = boton(ft.Icons.ARROW_BACK, "Salir de pantalla completa (Esc)",
                       lambda _: self.pantalla_completa(False))
        guardar = boton(ft.Icons.SAVE_OUTLINED, "Guardar", self.guardar_ya)
        # LA FLECHA, ARRIBA A LA IZQUIERDA: ahí la pizarra no tiene nada (sus
        # herramientas van a la izquierda al medio y el zoom abajo a la derecha).
        # Y SE VE QUE SE GUARDA: en pantalla completa no está la barra de arriba
        # con el «Guardado HH:MM», así que va al lado de la flecha.
        imagen = ft.Container(self._boton_imagen(), bgcolor=self.paleta.surface_2, border_radius=12,
                              border=ft.Border.all(1, self.paleta.borde))
        esquina = ft.Row([volver, guardar, imagen, self.estado], spacing=10, tight=True)
        return ft.Stack(
            [ft.Container(self.lienzo, expand=True), ft.Container(esquina, left=12, top=12)],
            expand=True,
        )

    def _sin_pieza(self) -> ft.Control:
        return ft.Container(
            componentes.aviso_vacio(
                self.paleta,
                "La pizarra necesita el Focus armado: abrilo desde el acceso del "
                "escritorio. Este Focus se abrió desde el código y no la trae.",
                icono=ft.Icons.DRAW_OUTLINED,
            ),
            expand=True, alignment=ft.Alignment.CENTER,
        )

    # ------------------------------------------------------------ carpetas y pizarras

    def _elegir_cuaderno(self, cuaderno_id: int) -> None:
        """El menú de carpetas del CELULAR: entra a la carpeta y abre su
        primera pizarra (ahí no hay barra lateral donde elegirla)."""
        self.cuaderno_id = cuaderno_id
        self.carpeta_abierta = True
        self._leer()
        self._abrir_pagina(self.paginas[0].id if self.paginas else None)

    def _tocar_carpeta(self, cuaderno_id: int) -> None:
        """La barra lateral de la PC: abre o cierra esa carpeta.

        DE A UNA (lo eligió el usuario): abrir otra cierra la anterior, así la
        barra queda corta. ABRIRLA NO CAMBIA LA PIZARRA QUE ESTÁS VIENDO: solo
        enseña la lista, y la que quieras la elegís de ahí.
        """
        if cuaderno_id == self.cuaderno_id:
            self.carpeta_abierta = not self.carpeta_abierta
        else:
            self.cuaderno_id = cuaderno_id
            self.carpeta_abierta = True
            self.bloque_abierto = True
            self._leer()
        self._dibujar()

    def _plegar_bloque(self) -> None:
        """La flecha del bloque «Pizarras», dentro de la carpeta abierta."""
        self.bloque_abierto = not self.bloque_abierto
        self._dibujar()

    def _pedir_nombre_cuaderno(self, cuaderno: repo.Cuaderno | None = None) -> None:
        self._pedir_texto(
            "Carpeta nueva" if cuaderno is None else "Renombrar carpeta",
            "Nombre", cuaderno.nombre if cuaderno else "", repo.NOMBRE_MAXIMO,
            lambda nombre: self._guardar_cuaderno(cuaderno, nombre),
        )

    def _guardar_cuaderno(self, cuaderno, nombre: str) -> None:
        with conectado() as conexion:
            if cuaderno is None:
                nuevo = repo.crear_cuaderno(conexion, nombre, _ahora())
                self.cuaderno_id = nuevo.id
                # LA NUEVA QUEDA ABIERTA, con su primera pizarra a la vista.
                self.carpeta_abierta = self.bloque_abierto = True
            else:
                repo.renombrar_cuaderno(conexion, cuaderno.id, nombre)
        self._leer()
        if cuaderno is None:
            self._abrir_pagina(self.paginas[0].id)
        else:
            self._dibujar()

    def _pedir_titulo(self, hoja: repo.Pagina) -> None:
        def guardar(titulo: str) -> None:
            with conectado() as conexion:
                repo.renombrar_pagina(conexion, hoja.id, titulo)
            self._leer()
            self._dibujar()

        self._pedir_texto("Renombrar pizarra", "Nombre", hoja.titulo, repo.TITULO_MAXIMO, guardar)

    def _nueva_pagina(self) -> None:
        with conectado() as conexion:
            nueva = repo.crear_pagina(
                conexion, self.cuaderno_id, repo.titulo_nuevo(conexion, self.cuaderno_id),
                _ahora(),
            )
        self._leer()
        self._abrir_pagina(nueva)

    def _duplicar(self, hoja: repo.Pagina) -> None:
        with conectado() as conexion:
            nueva = repo.duplicar_pagina(conexion, hoja.id, _ahora())
        self._leer()
        if nueva is not None:
            self._abrir_pagina(nueva)

    def _borrar_cuaderno(self, cuaderno: repo.Cuaderno) -> None:
        def borrar(_):
            with conectado() as conexion:
                repo.borrar_cuaderno(conexion, cuaderno.id)
            self.pagina.pop_dialog()
            self._abrir_al_empezar(None)

        cuantas = "1 pizarra" if cuaderno.paginas == 1 else f"{cuaderno.paginas} pizarras"
        componentes.confirmar(
            self.paleta, self.pagina, titulo=f"Borrar «{cuaderno.nombre}»",
            texto=f"Se borra la carpeta con sus {cuantas}, también en tus otros aparatos.",
            al_aceptar=borrar,
        )

    def _borrar_pagina(self, hoja: repo.Pagina) -> None:
        def borrar(_):
            with conectado() as conexion:
                repo.borrar_pagina(conexion, hoja.id)
            self.pagina.pop_dialog()
            self._leer()
            if hoja.id == self.pagina_id:
                self._abrir_pagina(self.paginas[0].id if self.paginas else None)
            else:
                self._dibujar()

        componentes.confirmar(
            self.paleta, self.pagina, titulo=f"Borrar «{hoja.titulo}»",
            texto="Se borra la pizarra con todo lo que tiene, también en tus otros aparatos.",
            al_aceptar=borrar,
        )

    def _pedir_texto(self, titulo, etiqueta, valor, maximo, al_guardar) -> None:
        campo = componentes.campo_texto(self.paleta, etiqueta, valor=valor,
                                        largo_maximo=maximo, ancho=320)
        aviso = ft.Text("", size=12, color=self.paleta.negativo, visible=False)

        def guardar(_):
            if not (campo.value or "").strip():
                aviso.value, aviso.visible = "Hace falta un nombre.", True
                self._actualizar(aviso)
                return
            self.pagina.pop_dialog()
            al_guardar(campo.value)

        campo.on_submit = guardar
        self.pagina.show_dialog(componentes.dialogo(
            self.paleta, titulo, ft.Column([campo, aviso], tight=True, spacing=8),
            pagina=self.pagina, al_aceptar=guardar,
        ))


def _leer_vistas(texto: str) -> dict:
    try:
        vistas = json.loads(texto or "{}")
    except (TypeError, ValueError):
        return {}
    return vistas if isinstance(vistas, dict) else {}
