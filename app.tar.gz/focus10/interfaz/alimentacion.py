"""La pantalla de Alimentación: lo que has comido y lo que has bebido.

LA REGLA DE TODA LA PANTALLA: aquí no se calcula nada que el usuario no haya
escrito. Lo único que se hace con sus números es sumarlos para los totales del
día, y sumar no es inventar. No hay base de datos de alimentos, no hay
estimaciones, no hay sugerencias "de ayuda". Una versión anterior analizaba el
texto y le puso 29 kcal a 300 gramos de fideos; la lección fue que el problema no
era el analizador, era la idea de tener uno.

SIN OBJETIVO NO HAY BARRA. Una barra necesita un contra-qué; sin objetivo,
cualquier barra que dibuje es un porcentaje inventado. Se enseña el total y ya.

EL VASO SE MUEVE DE VERDAD: dos ondas a distinta velocidad y en sentidos
contrarios, repintadas veinte veces por segundo mientras esta pantalla esté
puesta. Ver el agua SUBIR al pulsar es media gracia de la tarjeta.
"""

from __future__ import annotations

import asyncio
from enum import StrEnum
from datetime import datetime

import flet as ft

from ..datos import repositorio_alimentacion as repo
from ..datos import repositorio_dias
from ..datos.bd import conectado
from ..dominio.agua import (
    ML_MAXIMOS_OBJETIVO,
    Trago,
    Vaso,
    parsear_ml,
    texto_litros,
    total as total_agua,
)
from ..dominio.alimento import (
    Registro,
    parsear_gramos,
    parsear_kcal,
    texto_gramos,
)
from ..dominio.semana import LETRAS, texto_fecha
from ..dominio.cumplimiento import (
    Cumplimiento,
    ResumenDeDia,
    cuenta,
    cumplimiento_de,
)
from ..dominio.resumen_comida import (
    mes_de,
    por_dia,
    por_semana,
    promedio,
    semana_de,
)
from ..dominio.nutricion import NOMBRES, Objetivos, sumar
from . import calendario_comida, componentes, dialogo_dia, dialogo_comida, estilo, vaso_agua
from .grafico_barras import grafico_barras
from .estilo import Paleta



class Vista(StrEnum):
    """Las tres formas de mirar lo que comes.

    HOY es para apuntar; SEMANA y MES son para enterarte. Son cosas distintas y
    por eso no caben en una sola pantalla: apuntando quieres la lista de lo que
    llevas, y mirando atrás quieres promedios y una tendencia.
    """

    HOY = "hoy"
    SEMANA = "semana"
    MES = "mes"


NUTRIENTES_A_LA_VISTA = (
    ("kcal", "Calorías", "kcal"),
    ("proteinas", "Proteínas", "g"),
    ("carbohidratos", "Carbohidratos", "g"),
    ("grasas", "Grasas", "g"),
)
"""Los cuatro gráficos, en este orden y con su unidad.

LAS CALORIAS VAN PRIMERAS porque es el número que se mira; los macros debajo,
para quien quiera afinar. El orden es el mismo que en la tarjeta de hoy, a
propósito: cambiarlo obligaría a buscar cada vez.
"""


class PantallaAlimentacion(componentes.Pantalla):
    def __init__(self, pagina: ft.Page, paleta: Paleta) -> None:
        super().__init__(pagina, paleta)
        self.animacion = vaso_agua.Animacion()
        self.hueco_vaso = ft.Container()
        self._vivo = True
        self._error = ""
        self._primera_vez = True
        # SE ENTRA POR HOY: la pantalla se usa sobre todo para apuntar lo que
        # acabas de comer, y hacer que empiece en un resumen pondría una pantalla
        # de por medio en lo que más veces se hace.
        self.vista = Vista.HOY
        self.refrescar()

    def montada(self) -> None:
        super().montada()
        self.pagina.run_task(self._animar)

    def cerrar(self) -> None:
        """Para la animación al salir de la pantalla.

        Sin esto, cada visita dejaría un bucle más repintando un vaso que ya no
        está en la ventana.
        """
        self._vivo = False

    async def _animar(self) -> None:
        """Repinta SOLO el vaso, veinte veces por segundo.

        Repintar la pantalla entera a esa velocidad sería absurdo: la lista de
        comidas no cambia mientras miras el agua. Por eso el vaso vive en su
        propio hueco y es lo único que se actualiza.
        """
        while self._vivo:
            await asyncio.sleep(vaso_agua.SEGUNDOS_POR_FOTOGRAMA)
            if not self._vivo or not self._en_pagina:
                return
            self.animacion.avanzar()
            try:
                self._pintar_vaso()
                self.hueco_vaso.update()
            except Exception:  # noqa: BLE001
                self._vivo = False
                return

    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            self.hoy = repositorio_dias.jornada_abierta(conexion)
            self.registros = repo.listar_del_dia(conexion, self.hoy)
            self.comidas = repo.listar_comidas(conexion)
            self.objetivos = repo.leer_objetivos(conexion)
            self.objetivo_agua = repo.leer_objetivo_agua(conexion)
            self.tragos = repo.tragos_del_dia(conexion, self.hoy)

            # EL TRAMO SOLO SE LEE SI HACE FALTA: en la vista de hoy sería
            # traerse un mes entero de comidas para no enseñarlas.
            self.dias = []
            if self.vista is not Vista.HOY:
                if self.vista is Vista.SEMANA:
                    desde, hasta = semana_de(self.hoy)
                else:
                    desde, hasta = mes_de(self.hoy)
                self.tramo = (desde, hasta)
                self.dias = por_dia(
                    repo.listar_entre(conexion, desde, hasta), desde, hasta
                )

        self.totales = sumar(self.registros)
        self.vaso = Vaso(bebido=total_agua(self.tragos), objetivo=self.objetivo_agua)

        if self._primera_vez:
            # Al abrir, el agua ya está donde toca: verla subir desde cero sería
            # una animación bonita contando una mentira.
            self.animacion.colocar_en(self.vaso.fraccion)
            self._primera_vez = False
        else:
            self.animacion.apuntar_a(self.vaso.fraccion)

        piezas: list[ft.Control] = [self._cabecera(), self._pestanas()]
        if self._error:
            piezas.append(componentes.aviso_error(self.paleta, [self._error]))

        if self.vista is not Vista.HOY:
            piezas += self._resumen()
            self.pintar(piezas)
            return

        piezas += [
            self._fila_de_arriba(),
            self._tarjeta_objetivos(),
            self._tarjeta_comidas(),
        ]

        self.pintar(piezas)

    def _pestanas(self) -> ft.Control:
        return componentes.segmentado(
            self.paleta,
            [(Vista.HOY, "Hoy"), (Vista.SEMANA, "Semana"), (Vista.MES, "Mes")],
            self.vista,
            self._cambiar_vista,
        )

    def _cambiar_vista(self, cual: str) -> None:
        self.vista = Vista(cual)
        self.refrescar()

    # ------------------------------------------------------------------
    # El resumen de la semana y del mes
    # ------------------------------------------------------------------

    def _resumen(self) -> list[ft.Control]:
        """Los cuatro gráficos, con los promedios encima.

        LOS DIAS SIN APUNTAR CUENTAN COMO CERO, y lo eligió el usuario sabiendo
        lo que implica: "contá lo que hice; si ese día no anoté sería como que no
        comí, 0". Así el gráfico también dice si estás siendo constante
        apuntando, no solo lo que comes. Por eso se enseña además cuántos días
        llegaste a apuntar: para que un promedio bajo se pueda leer bien.
        """
        if not self.dias:
            return [
                componentes.tarjeta(
                    self.paleta,
                    componentes.aviso_vacio(
                        self.paleta, "Todavía no hay nada apuntado en este tramo."
                    ),
                )
            ]

        apuntados = sum(1 for uno in self.dias if uno.apuntado)
        medias = promedio(self.dias)

        piezas: list[ft.Control] = [self._tarjeta_promedios(medias, apuntados)]
        # EL CALENDARIO VA ANTES QUE LOS GRÁFICOS porque responde la pregunta
        # que se viene a hacer —"¿cumplí?"— y los gráficos responden la de
        # después: "¿cuánto?".
        if self.vista is Vista.MES:
            piezas.append(self._tarjeta_calendario())
        for nutriente, titulo, unidad in NUTRIENTES_A_LA_VISTA:
            piezas.append(self._tarjeta_grafico(nutriente, titulo, unidad))
        return piezas

    def _tarjeta_calendario(self) -> ft.Control:
        """La rejilla del mes con el recuento encima."""
        estados = {
            uno.jornada: cumplimiento_de(uno, self.objetivos, self.hoy)
            for uno in self.dias
        }
        recuento = cuenta(self.dias, self.objetivos, self.hoy)
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Días cumplidos",
                        self._resumen_del_mes(recuento),
                    ),
                    calendario_comida.rejilla(
                        self.paleta, estados, al_tocar=self._abrir_dia
                    ),
                    calendario_comida.leyenda(self.paleta),
                ],
                spacing=12,
                tight=True,
            ),
        )

    def _resumen_del_mes(self, recuento: dict) -> str:
        """"12 de 20 días" — y los que no han pasado no cuentan.

        SE DICE SOBRE CUÁNTOS, y no solo cuántos: "12 días cumplidos" a día 15
        del mes y a día 30 quieren decir cosas muy distintas.
        """
        if recuento[Cumplimiento.SIN_OBJETIVO]:
            return "Pon un objetivo de calorías y de proteína para poder saberlo"
        vividos = sum(
            cuantos
            for estado, cuantos in recuento.items()
            if estado is not Cumplimiento.FUTURO
        )
        if not vividos:
            return "Todavía no ha pasado ningún día de este mes"
        cumplidos = recuento[Cumplimiento.CUMPLIDO]
        return f"{cumplidos} de {vividos} días, por calorías y proteína"

    def _abrir_dia(self, jornada):
        """Lee ese día entero y lo enseña.

        SE VUELVE A LA BASE en vez de usar lo que ya está en memoria: aquí hacen
        falta los registros uno a uno —"qué comí"— y el resumen del mes solo
        guarda las sumas.
        """
        with conectado() as conexion:
            registros = repo.listar_del_dia(conexion, jornada)
            tragos = repo.tragos_del_dia(conexion, jornada)
        # SE DEVUELVE LA VENTANITA PARA PODER PROBARLA. Quien la abre no
        # necesita nada de vuelta; el banco de pruebas sí, y buscarla rebuscando
        # en la página era frágil.
        return dialogo_dia.abrir(
            self.pagina,
            self.paleta,
            ResumenDeDia(
                jornada=jornada,
                totales=sumar(registros),
                objetivos=self.objetivos,
                registros=tuple(registros),
                agua_ml=total_agua(tragos),
                objetivo_agua=self.objetivo_agua,
            ),
        )

    def _tarjeta_promedios(self, medias, apuntados: int) -> ft.Control:
        cuantos = len(self.dias)
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(self.paleta, "Promedio por día"),
                    ft.Row(
                        [
                            componentes.cifra(
                                self.paleta,
                                titulo,
                                _con_unidad(medias.de(nutriente), unidad),
                            )
                            for nutriente, titulo, unidad in NUTRIENTES_A_LA_VISTA
                        ],
                        wrap=True,
                        run_spacing=12,
                        spacing=18,
                    ),
                    ft.Text(
                        f"Apuntaste {apuntados} de {cuantos} días. Los días sin "
                        "apuntar cuentan como cero, así que bajan el promedio.",
                        size=estilo.TEXTO_APOYO,
                        color=self.paleta.muted,
                    ),
                ],
                spacing=10,
            ),
        )

    def _tarjeta_grafico(self, nutriente: str, titulo: str, unidad: str) -> ft.Control:
        objetivo = self.objetivos.de(nutriente)
        if self.vista is Vista.SEMANA:
            valores = [uno.de(nutriente) for uno in self.dias]
            etiquetas = [LETRAS[uno.jornada.weekday()] for uno in self.dias]
            meta = objetivo
        else:
            # EL MES VA POR SEMANAS: treinta barras en un móvil de 375 puntos son
            # diez puntos por barra. De un mes se quiere ver la tendencia, no el
            # martes 14.
            semanas = por_semana(self.dias)
            valores = [una.de(nutriente) for una in semanas]
            etiquetas = [una.etiqueta() for una in semanas]
            # La raya sigue siendo el objetivo DIARIO, porque las barras son
            # promedios por día. Compararlas con un objetivo semanal sería
            # comparar dos cosas distintas.
            meta = objetivo

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta, f"{titulo} ({unidad})"
                    ),
                    grafico_barras(
                        valores, etiquetas, self.paleta, objetivo=meta
                    ),
                ],
                spacing=10,
            ),
        )

    def _cabecera(self) -> ft.Control:
        return componentes.titulo_pagina(
            self.paleta,
            "Alimentación",
            texto_fecha(self.hoy),
            acciones=[
                componentes.boton(
                    self.paleta,
                    "Repetir",
                    icono=ft.Icons.HISTORY,
                    al_pulsar=lambda _: self._abrir_repetir(),
                ),
                componentes.boton(
                    self.paleta,
                    "Apuntar",
                    icono=ft.Icons.ADD,
                    principal=True,
                    al_pulsar=lambda _: dialogo_comida.abrir(
                        self.pagina, self.paleta, self.hoy, self.refrescar
                    ),
                ),
            ],
        )

    def _fila_de_arriba(self) -> ft.Control:
        """Los totales y el agua, uno al lado del otro y de la MISMA altura.

        EL REPARTO ES 6/6 Y NO 7/5. Con el reparto viejo la tarjeta de agua era
        estrecha y alta —el vaso arriba y cuatro filas de mandos debajo— mientras
        que la de macros era corta y ancha. La diferencia dejaba un rectangulo
        negro enorme bajo los macros.

        Lo que iguala las alturas es que el agua ponga el vaso a la IZQUIERDA y
        los mandos a su DERECHA (ver _tarjeta_agua): asi mide la mitad de alto y
        las dos columnas acaban casi a la vez.

        AQUI NO SE PIDE QUE SE ESTIREN A LO ALTO, y costo una pantalla en blanco
        aprenderlo: la columna que contiene todo esto lleva scroll, o sea altura
        SIN LIMITE. Un hijo que pide "llename el alto que sobra" no tiene nada
        que llenar, el calculo del tamano no cierra y Flet no dibuja NADA: se
        queda la cabecera y debajo el vacio. Dentro de algo con scroll, el alto
        lo pone el contenido y no al reves.
        """
        return ft.ResponsiveRow(
            [
                ft.Container(
                    content=self._tarjeta_totales(),
                    col={"xs": 12, "lg": 6},
                ),
                ft.Container(
                    content=self._tarjeta_agua(),
                    col={"xs": 12, "lg": 6},
                ),
            ],
            spacing=16,
            run_spacing=16,
        )

    # ----------------------------------------------------------------------
    # Totales del día
    # ----------------------------------------------------------------------

    def _tarjeta_totales(self) -> ft.Control:
        avances = self.totales.avance(self.objetivos)
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Hoy",
                        f"{len(self.registros)} registros"
                        if self.registros
                        else "todavía no has apuntado nada",
                    ),
                    *[self._fila_avance(uno) for uno in avances],
                ],
                spacing=14,
            ),
        )

    def _fila_avance(self, avance) -> ft.Control:
        es_kcal = avance.nutriente == "kcal"
        total = (
            f"{avance.total} kcal" if es_kcal else f"{texto_gramos(avance.total)} g"
        )
        if avance.objetivo is None:
            derecha = ft.Text(total, size=13, weight=ft.FontWeight.W_600,
                              color=self.paleta.ink)
        else:
            objetivo = (
                f"{avance.objetivo} kcal"
                if es_kcal
                else f"{texto_gramos(avance.objetivo)} g"
            )
            derecha = ft.Text(
                f"{total} de {objetivo}",
                size=13,
                weight=ft.FontWeight.W_600,
                color=self.paleta.aviso if avance.pasado else self.paleta.ink,
            )

        piezas: list[ft.Control] = [
            ft.Row(
                [
                    ft.Text(
                        NOMBRES[avance.nutriente],
                        size=13,
                        color=self.paleta.ink_soft,
                        expand=True,
                    ),
                    derecha,
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            )
        ]
        # SIN OBJETIVO NO HAY BARRA: una barra sin contra-qué es un porcentaje
        # inventado.
        if avance.fraccion is not None:
            piezas.append(
                componentes.barra_de_avance(
                    self.paleta,
                    color="ambar" if avance.pasado else "verde",
                    fraccion=avance.fraccion,
                )
            )
        return ft.Column(piezas, spacing=6, tight=True)

    # ----------------------------------------------------------------------
    # El agua
    # ----------------------------------------------------------------------

    def _pintar_vaso(self) -> None:
        self.hueco_vaso.content = vaso_agua.dibujar(
            self.paleta, self.animacion, self.vaso
        )

    def _tarjeta_agua(self) -> ft.Control:
        self._pintar_vaso()

        # SIN ANCHO FIJO: con los 140 px de antes, las etiquetas "He bebido
        # (ml)" y "Objetivo del día (ml)" no cabían y se partían en dos líneas,
        # lo que estiraba la tarjeta a lo alto sin decir nada nuevo. Ahora se
        # reparten el ancho que haya.
        self.campo_ml = componentes.campo_texto(
            self.paleta,
            "He bebido (ml)",
            # EN MILILITROS ENTEROS Y SIN COMAS, y lo dijo el usuario con estas
            # palabras: "un litro equivale a 1000, no hay otra manera, no es
            # 1.000 ni 1,000; quinientos mililitros sería 500". La pista lo
            # enseña con el ejemplo que él mismo puso.
            pista="1000",
            al_enviar=lambda _: self._beber_escrito(),
        )
        self.campo_quitar = componentes.campo_texto(
            self.paleta,
            "Quitar (ml)",
            pista="500",
            al_enviar=lambda _: self._quitar_escrito(),
        )
        self.campo_objetivo_agua = componentes.campo_texto(
            self.paleta,
            "Objetivo del día (ml)",
            valor=str(self.objetivo_agua) if self.objetivo_agua else "",
            pista="2000",
            al_enviar=lambda e: self._guardar_objetivo_agua(e.control.value),
        )
        self.campo_objetivo_agua.on_blur = lambda e: self._guardar_objetivo_agua(
            e.control.value
        )

        mandos = ft.Column(
            [
                ft.Row(
                    [
                        ft.Container(content=self.campo_ml, expand=True),
                        componentes.boton(
                            self.paleta,
                            "Añadir",
                            icono=ft.Icons.ADD,
                            principal=True,
                            al_pulsar=lambda _: self._beber_escrito(),
                        ),
                    ],
                    spacing=8,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                # LOS ATAJOS (+200, +250, +330, +500) SE QUITARON. Lo pidió el
                # usuario: "que no me aparezcan opciones de poner doscientos
                # cincuenta; yo escribo lo que tengo que poner, punto".
                #
                # Y EN SU SITIO, EL DE QUITAR, que también pidió: "agregar un
                # apartado para sacar, tipo sacar mililitros, no sé si se use,
                # pero por las dudas".
                ft.Row(
                    [
                        ft.Container(content=self.campo_quitar, expand=True),
                        componentes.boton(
                            self.paleta,
                            "Quitar",
                            icono=ft.Icons.REMOVE,
                            al_pulsar=lambda _: self._quitar_escrito(),
                        ),
                    ],
                    spacing=8,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                ft.Row(
                    [
                        ft.Container(content=self.campo_objetivo_agua, expand=True),
                        componentes.boton(
                            self.paleta,
                            "Deshacer",
                            icono=ft.Icons.UNDO,
                            al_pulsar=lambda _: self._deshacer_trago(),
                        ),
                    ],
                    spacing=8,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                ft.Text(
                    self._texto_ultimo_trago(),
                    size=estilo.TEXTO_APOYO,
                    color=self.paleta.muted,
                ),
            ],
            spacing=12,
            # EN COLUMNA NO SE ESTIRA: expand dentro de una columna es estirarse
            # a lo ALTO, y aquí dejaría los mandos flotando lejos del vaso.
            expand=not estilo.pantalla_estrecha(),
        )

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(self.paleta, "Agua", None),
                    # EL VASO A UN LADO Y LOS MANDOS AL OTRO. Antes iban en
                    # columna: vaso, campo, atajos, objetivo, deshacer y aviso,
                    # seis filas que hacían la tarjeta el doble de alta que la de
                    # macros y dejaban el hueco negro de al lado. Puestos en fila
                    # ocupan lo mismo pero en la mitad de alto, y el vaso —que es
                    # lo que se mira— queda a la altura de los ojos.
                    # EN EL MÓVIL, EL VASO ARRIBA Y LOS MANDOS DEBAJO, y no es
                    # una preferencia: en fila no entran. El vaso mide 150 px
                    # fijos y cada botón otros cien y pico; en una pantalla de
                    # 375 al campo de escribir le quedaban cuatro píxeles y las
                    # letras salían una debajo de otra, en vertical, encima de
                    # todo lo demás. Se podía escribir el agua, pero no se veía
                    # lo escrito. Lo cazó el usuario con una captura.
                    ft.Column(
                        [self.hueco_vaso, mandos],
                        spacing=16,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    )
                    if estilo.pantalla_estrecha()
                    else ft.Row(
                        [self.hueco_vaso, mandos],
                        spacing=20,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                ],
                spacing=12,
            ),
        )

    def _texto_ultimo_trago(self) -> str:
        if not self.tragos:
            return "Todavía no has bebido nada hoy."
        ultimo = self.tragos[-1]
        # "1 tragos" se lee mal, y es lo primero que ves al empezar el día.
        cuantos = len(self.tragos)
        return (
            f"{cuantos} {'trago' if cuantos == 1 else 'tragos'} hoy · el último, "
            f"{texto_litros(ultimo.ml)} a las {ultimo.momento.strftime('%H:%M')}"
        )

    def _beber_escrito(self) -> None:
        try:
            ml = parsear_ml(self.campo_ml.value or "")
        except (ValueError, TypeError) as fallo:
            self._error = str(fallo)
            self.refrescar()
            return
        self.campo_ml.value = ""
        self._beber(ml)

    def _quitar_escrito(self) -> None:
        """Quita los mililitros escritos. Un trago negativo, ni más ni menos.

        SE APUNTA COMO UN TRAGO Y NO SE BORRAN OTROS, y es a propósito: borrar
        el último trago ya lo hace "Deshacer". Esto es para corregir el total
        —"me pasé apuntando"— sin tocar lo que ya escribiste.
        """
        try:
            ml = parsear_ml(self.campo_quitar.value or "")
        except (ValueError, TypeError) as fallo:
            self._error = str(fallo)
            self.refrescar()
            return
        self.campo_quitar.value = ""
        self._beber(-ml)

    def _beber(self, ml: int) -> None:
        """Apunta un trago. SE SUMA a lo que había, porque es una fila nueva."""
        with conectado() as conexion:
            repo.beber(
                conexion,
                Trago(
                    ml=ml,
                    jornada=self.hoy,
                    momento=datetime.now().replace(microsecond=0),
                ),
            )
        self._error = ""
        self.refrescar()

    def _deshacer_trago(self) -> None:
        """Borra el último trago. Nunca resta: quita una fila."""
        with conectado() as conexion:
            borrado = repo.deshacer_ultimo_trago(conexion, self.hoy)
        self._error = "" if borrado else "No queda ningún trago que deshacer hoy."
        self.refrescar()

    def _guardar_objetivo_agua(self, escrito: str) -> None:
        limpio = (escrito or "").strip()
        try:
            # Vaciarlo es quitar el objetivo, no un error: sin objetivo el vaso
            # se queda vacío y al lado sigue estando lo que llevas.
            ml = None if not limpio else parsear_ml(limpio, tope=ML_MAXIMOS_OBJETIVO)
        except (ValueError, TypeError) as fallo:
            self._error = str(fallo)
            self.refrescar()
            return
        if ml == self.objetivo_agua:
            return
        with conectado() as conexion:
            repo.guardar_objetivo_agua(conexion, ml)
        self._error = ""
        self.refrescar()

    # ----------------------------------------------------------------------
    # Los objetivos de comida
    # ----------------------------------------------------------------------

    def _tarjeta_objetivos(self) -> ft.Control:
        self.campos_objetivo = {}
        filas = []
        for nutriente in ("kcal", "proteinas", "carbohidratos", "grasas"):
            actual = self.objetivos.de(nutriente)
            valor = ""
            if actual is not None:
                valor = str(actual) if nutriente == "kcal" else texto_gramos(actual)
            campo = componentes.campo_texto(
                self.paleta,
                "kcal" if nutriente == "kcal" else "g",
                valor=valor,
                pista="sin objetivo",
                al_enviar=lambda e, n=nutriente: self._guardar_objetivo(
                    n, e.control.value
                ),
            )
            campo.on_blur = lambda e, n=nutriente: self._guardar_objetivo(
                n, e.control.value
            )
            self.campos_objetivo[nutriente] = campo
            filas.append(
                # CADA UNO SE COME SU CUARTO DE TARJETA. Con el ancho fijo de
                # antes, los cuatro campos ocupaban el tercio izquierdo y los
                # otros dos tercios se quedaban en negro. Repartidos, la fila
                # llena la tarjeta y los campos son lo bastante anchos para ver
                # el número entero sin que se corte.
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(
                                NOMBRES[nutriente],
                                size=estilo.TEXTO_APOYO,
                                color=self.paleta.muted,
                            ),
                            campo,
                        ],
                        spacing=4,
                        tight=True,
                    ),
                    expand=True,
                )
            )

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Mis objetivos del día",
                        "déjalo vacío si no quieres objetivo de algo; entonces se "
                        "enseña el total sin barra",
                    ),
                    # EN EL ORDENADOR, LOS CUATRO EN UNA FILA: se reparten el
                    # ancho y llenan la tarjeta. En el móvil NO CABEN: cuatro
                    # campos exigen 440 puntos y la pantalla tiene 375, así que
                    # van de dos en dos. (Con `wrap` y anchos elásticos Flet no
                    # sabe cuándo saltar y deja huecos raros; por eso se parte
                    # a mano.)
                    ft.Column(
                        [ft.Row(filas[:2], spacing=12), ft.Row(filas[2:], spacing=12)],
                        spacing=12,
                    )
                    if estilo.pantalla_estrecha()
                    else ft.Row(filas, spacing=12),
                ],
                spacing=12,
            ),
        )

    def _guardar_objetivo(self, nutriente: str, escrito: str) -> None:
        limpio = (escrito or "").strip()
        try:
            if not limpio:
                valor = None
            elif nutriente == "kcal":
                valor = parsear_kcal(limpio) or None
            else:
                valor = parsear_gramos(limpio) or None
            nuevos = Objetivos(
                **{
                    campo: (valor if campo == nutriente else self.objetivos.de(campo))
                    for campo in ("kcal", "proteinas", "carbohidratos", "grasas")
                }
            )
        except (ValueError, TypeError) as fallo:
            self._error = str(fallo)
            self.refrescar()
            return
        if nuevos == self.objetivos:
            return
        with conectado() as conexion:
            repo.guardar_objetivos(conexion, nuevos)
        self._error = ""
        self.refrescar()

    # ----------------------------------------------------------------------
    # Lo apuntado hoy
    # ----------------------------------------------------------------------

    def _tarjeta_comidas(self) -> ft.Control:
        """Lo apuntado hoy, en una lista seguida.

        ANTES IBA AGRUPADO POR DESAYUNO / COMIDA / CENA, y esa parte la quitó el
        usuario entera: "yo pongo el nombre, no importa si es almuerzo, cena, lo
        que sea; si quiero llamarlos comida uno, comida dos, no importa".

        SE CONSERVA EL ORDEN EN QUE LO APUNTASTE, que es el único que se sabe de
        verdad. Inventar uno por la hora o por el nombre sería colocar las cosas
        donde a la aplicación le parezca.
        """
        piezas: list[ft.Control] = [
            componentes.cabecera_tarjeta(
                self.paleta,
                "Lo que has comido hoy",
                f"{len(self.registros)} registros"
                if self.registros
                else "todavía no has apuntado nada",
            )
        ]
        if not self.registros:
            piezas.append(
                componentes.aviso_vacio(
                    self.paleta, "Apunta lo primero con el botón de arriba."
                )
            )
        else:
            ordenados = sorted(self.registros, key=lambda uno: uno.momento)
            piezas += [self._fila_registro(uno) for uno in ordenados]
        return componentes.tarjeta(self.paleta, ft.Column(piezas, spacing=10))

    def _fila_registro(self, registro: Registro) -> ft.Control:
        """Una línea de comida. Se pulsa encima para corregirla, como se pidió."""
        macros = " · ".join(
            f"{texto_gramos(getattr(registro, campo))} g {etiqueta}"
            for campo, etiqueta in (
                ("proteinas", "P"),
                ("carbohidratos", "C"),
                ("grasas", "G"),
            )
        )
        return ft.Container(
            content=ft.Row(
                [
                    ft.Column(
                        [
                            ft.Text(registro.resumen(), size=13, color=self.paleta.ink),
                            ft.Text(macros, size=11, color=self.paleta.muted),
                        ],
                        spacing=1,
                        tight=True,
                        expand=True,
                    ),
                    ft.Text(
                        f"{registro.kcal} kcal",
                        size=13,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.ink_soft,
                    ),
                ],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(vertical=7, horizontal=6),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
            border_radius=estilo.RADIO_BOTON,
            on_click=lambda _, r=registro: dialogo_comida.abrir(
                self.pagina, self.paleta, self.hoy, self.refrescar, r
            ),
            ink=True,
            tooltip="Pulsa para corregirlo",
        )

    # ----------------------------------------------------------------------
    # Repetir
    # ----------------------------------------------------------------------

    def _abrir_repetir(self) -> None:
        """Lo único que la aplicación se ofrece a hacer por el usuario.

        Y ni siquiera rellena sola: le enseña lo que él escribió otro día para
        que lo repita si quiere, y al elegirlo se abre la ventanita con esos
        valores para que pueda cambiarlos ANTES de añadirlo.
        """
        with conectado() as conexion:
            repetibles = repo.mas_repetidos(conexion)

        if not repetibles:
            componentes.avisar(
                self.pagina, "Todavía no has apuntado nada que repetir."
            )
            return

        filas = [
            ft.Container(
                content=ft.Row(
                    [
                        ft.Column(
                            [
                                ft.Text(
                                    registro.resumen(), size=13, color=self.paleta.ink
                                ),
                                ft.Text(
                                    f"{registro.kcal} kcal · "
                                    f"{texto_gramos(registro.proteinas)} g P",
                                    size=11,
                                    color=self.paleta.muted,
                                ),
                            ],
                            spacing=1,
                            tight=True,
                            expand=True,
                        ),
                        ft.Text(
                            f"{veces} {'vez' if veces == 1 else 'veces'}",
                            size=11,
                            color=self.paleta.muted,
                        ),
                    ],
                    spacing=10,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                padding=ft.Padding.symmetric(vertical=7, horizontal=6),
                border_radius=estilo.RADIO_BOTON,
                on_click=lambda _, r=registro: self._repetir(r),
                ink=True,
            )
            for registro, veces in repetibles
        ]

        self.pagina.show_dialog(
            componentes.dialogo(
                self.paleta,
                "Repetir algo que ya apunté",
                ft.Container(
                    content=ft.Column(
                        filas, spacing=0, scroll=ft.ScrollMode.AUTO, height=360
                    ),
                    width=420,
                ),
                pagina=self.pagina,
                texto_aceptar="Cerrar",
                al_aceptar=lambda _: self.pagina.pop_dialog(),
            )
        )

    def _repetir(self, registro: Registro) -> None:
        self.pagina.pop_dialog()
        dialogo_comida.abrir(
            self.pagina, self.paleta, self.hoy, self.refrescar, registro, copiando=True
        )





def _con_unidad(valor: int, unidad: str) -> str:
    """El número con su unidad detrás: "2.450 kcal", "180 g".

    LOS MACROS SE GUARDAN EN DECIMAS DE GRAMO —así lo decidimos para no perder
    precisión con los decimales— y aquí se pasan a gramos enteros, que es como
    se leen. Las calorías se guardan enteras y no se tocan.
    """
    if unidad == "g":
        return f"{valor // 10} g"
    return f"{valor} {unidad}"
