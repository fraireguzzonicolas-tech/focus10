"""La pantalla de Alimentación: lo que has comido y lo que has bebido.

LA REGLA DE TODA LA PANTALLA: aquí no se calcula nada que el usuario no haya
escrito. Lo único que se hace con sus números es sumarlos para los totales del
día, y sumar no es inventar. No hay base de datos de alimentos, no hay
estimaciones, no hay sugerencias "de ayuda". Una versión anterior analizaba el
texto y le puso 29 kcal a 300 gramos de fideos; la lección fue que el problema no
era el analizador, era la idea de tener uno.

SIN OBJETIVO NO HAY BARRA. Una barra necesita un contra-qué; sin objetivo,
cualquier barra que dibuje es un porcentaje inventado. Se enseña el total y ya.

EL VASO SE MUEVE DE VERDAD: dos ondas a distinta velocidad y en sentidos
contrarios, repintadas veinte veces por segundo mientras esta pantalla esté
puesta. Ver el agua SUBIR al pulsar es media gracia de la tarjeta.
"""

from __future__ import annotations

import asyncio
from datetime import date, datetime

import flet as ft

from ..datos import repositorio_alimentacion as repo
from ..datos.ajustes import leer_horario
from ..datos.bd import conectado
from ..dominio.agua import (
    ML_MAXIMOS_OBJETIVO,
    Trago,
    Vaso,
    parsear_ml,
    texto_litros,
    total as total_agua,
)
from ..dominio.alimento import (
    LARGO_MAXIMO_COMIDA,
    Registro,
    parsear_gramos,
    parsear_kcal,
    texto_gramos,
)
from ..dominio.habito import DIAS_SEMANA
from ..dominio.jornada import jornada_actual
from ..dominio.nutricion import NOMBRES, Objetivos, por_comida, sumar
from . import componentes, dialogo_comida, estilo, vaso_agua
from .estilo import Paleta

MESES = (
    "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
)

TRAGOS_RAPIDOS = (200, 250, 330, 500)
"""Los vasos de siempre. No son una recomendación de cuánto beber: son atajos
para no escribir el número más común, y el campo de escribir sigue estando."""


class PantallaAlimentacion:
    def __init__(self, pagina: ft.Page, paleta: Paleta) -> None:
        self.pagina = pagina
        self.paleta = paleta
        self.contenido = ft.Column(spacing=16, scroll=ft.ScrollMode.AUTO, expand=True)
        self.animacion = vaso_agua.Animacion()
        self.hueco_vaso = ft.Container()
        self._en_pagina = False
        self._vivo = True
        self._error = ""
        self._primera_vez = True
        self.refrescar()

    @property
    def control(self) -> ft.Control:
        return self.contenido

    def montada(self) -> None:
        self._en_pagina = True
        self.pagina.run_task(self._animar)

    def cerrar(self) -> None:
        """Para la animación al salir de la pantalla.

        Sin esto, cada visita dejaría un bucle más repintando un vaso que ya no
        está en la ventana.
        """
        self._vivo = False

    async def _animar(self) -> None:
        """Repinta SOLO el vaso, veinte veces por segundo.

        Repintar la pantalla entera a esa velocidad sería absurdo: la lista de
        comidas no cambia mientras miras el agua. Por eso el vaso vive en su
        propio hueco y es lo único que se actualiza.
        """
        while self._vivo:
            await asyncio.sleep(vaso_agua.SEGUNDOS_POR_FOTOGRAMA)
            if not self._vivo or not self._en_pagina:
                return
            self.animacion.avanzar()
            try:
                self._pintar_vaso()
                self.hueco_vaso.update()
            except Exception:  # noqa: BLE001
                self._vivo = False
                return

    # ----------------------------------------------------------------------

    def refrescar(self) -> None:
        with conectado() as conexion:
            horario = leer_horario(conexion)
            self.hoy = jornada_actual(horario)
            self.registros = repo.listar_del_dia(conexion, self.hoy)
            self.comidas = repo.listar_comidas(conexion)
            self.objetivos = repo.leer_objetivos(conexion)
            self.objetivo_agua = repo.leer_objetivo_agua(conexion)
            self.tragos = repo.tragos_del_dia(conexion, self.hoy)

        self.totales = sumar(self.registros)
        self.vaso = Vaso(bebido=total_agua(self.tragos), objetivo=self.objetivo_agua)

        if self._primera_vez:
            # Al abrir, el agua ya está donde toca: verla subir desde cero sería
            # una animación bonita contando una mentira.
            self.animacion.colocar_en(self.vaso.fraccion)
            self._primera_vez = False
        else:
            self.animacion.apuntar_a(self.vaso.fraccion)

        piezas: list[ft.Control] = [self._cabecera()]
        if self._error:
            piezas.append(componentes.aviso_error(self.paleta, [self._error]))
        piezas += [
            self._fila_de_arriba(),
            self._tarjeta_objetivos(),
            self._tarjeta_comidas(),
        ]

        self.contenido.controls = piezas
        if self._en_pagina:
            self.contenido.update()

    def _cabecera(self) -> ft.Control:
        return componentes.titulo_pagina(
            self.paleta,
            "Alimentación",
            _dia_largo(self.hoy),
            acciones=[
                componentes.boton(
                    self.paleta,
                    "Repetir",
                    icono=ft.Icons.HISTORY,
                    al_pulsar=lambda _: self._abrir_repetir(),
                ),
                componentes.boton(
                    self.paleta,
                    "Apuntar",
                    icono=ft.Icons.ADD,
                    principal=True,
                    al_pulsar=lambda _: dialogo_comida.abrir(
                        self.pagina, self.paleta, self.hoy, self.refrescar
                    ),
                ),
            ],
        )

    def _fila_de_arriba(self) -> ft.Control:
        """Los totales y el agua, uno al lado del otro y de la MISMA altura.

        EL REPARTO ES 6/6 Y NO 7/5. Con el reparto viejo la tarjeta de agua era
        estrecha y alta —el vaso arriba y cuatro filas de mandos debajo— mientras
        que la de macros era corta y ancha. La diferencia dejaba un rectangulo
        negro enorme bajo los macros.

        Lo que iguala las alturas es que el agua ponga el vaso a la IZQUIERDA y
        los mandos a su DERECHA (ver _tarjeta_agua): asi mide la mitad de alto y
        las dos columnas acaban casi a la vez.

        AQUI NO SE PIDE QUE SE ESTIREN A LO ALTO, y costo una pantalla en blanco
        aprenderlo: la columna que contiene todo esto lleva scroll, o sea altura
        SIN LIMITE. Un hijo que pide "llename el alto que sobra" no tiene nada
        que llenar, el calculo del tamano no cierra y Flet no dibuja NADA: se
        queda la cabecera y debajo el vacio. Dentro de algo con scroll, el alto
        lo pone el contenido y no al reves.
        """
        return ft.ResponsiveRow(
            [
                ft.Container(
                    content=self._tarjeta_totales(),
                    col={"xs": 12, "lg": 6},
                ),
                ft.Container(
                    content=self._tarjeta_agua(),
                    col={"xs": 12, "lg": 6},
                ),
            ],
            spacing=16,
            run_spacing=16,
        )

    # ----------------------------------------------------------------------
    # Totales del día
    # ----------------------------------------------------------------------

    def _tarjeta_totales(self) -> ft.Control:
        avances = self.totales.avance(self.objetivos)
        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Hoy",
                        f"{len(self.registros)} registros"
                        if self.registros
                        else "todavía no has apuntado nada",
                    ),
                    *[self._fila_avance(uno) for uno in avances],
                ],
                spacing=14,
            ),
        )

    def _fila_avance(self, avance) -> ft.Control:
        es_kcal = avance.nutriente == "kcal"
        total = (
            f"{avance.total} kcal" if es_kcal else f"{texto_gramos(avance.total)} g"
        )
        if avance.objetivo is None:
            derecha = ft.Text(total, size=13, weight=ft.FontWeight.W_600,
                              color=self.paleta.ink)
        else:
            objetivo = (
                f"{avance.objetivo} kcal"
                if es_kcal
                else f"{texto_gramos(avance.objetivo)} g"
            )
            derecha = ft.Text(
                f"{total} de {objetivo}",
                size=13,
                weight=ft.FontWeight.W_600,
                color=self.paleta.aviso if avance.pasado else self.paleta.ink,
            )

        piezas: list[ft.Control] = [
            ft.Row(
                [
                    ft.Text(
                        NOMBRES[avance.nutriente],
                        size=13,
                        color=self.paleta.ink_soft,
                        expand=True,
                    ),
                    derecha,
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            )
        ]
        # SIN OBJETIVO NO HAY BARRA: una barra sin contra-qué es un porcentaje
        # inventado.
        if avance.fraccion is not None:
            piezas.append(
                componentes.barra_de_avance(
                    self.paleta,
                    color="ambar" if avance.pasado else "verde",
                    fraccion=avance.fraccion,
                )
            )
        return ft.Column(piezas, spacing=6, tight=True)

    # ----------------------------------------------------------------------
    # El agua
    # ----------------------------------------------------------------------

    def _pintar_vaso(self) -> None:
        self.hueco_vaso.content = vaso_agua.dibujar(
            self.paleta, self.animacion, self.vaso
        )

    def _tarjeta_agua(self) -> ft.Control:
        self._pintar_vaso()

        # SIN ANCHO FIJO: con los 140 px de antes, las etiquetas "He bebido
        # (ml)" y "Objetivo del día (ml)" no cabían y se partían en dos líneas,
        # lo que estiraba la tarjeta a lo alto sin decir nada nuevo. Ahora se
        # reparten el ancho que haya.
        self.campo_ml = componentes.campo_texto(
            self.paleta,
            "He bebido (ml)",
            pista="250",
            al_enviar=lambda _: self._beber_escrito(),
        )
        self.campo_objetivo_agua = componentes.campo_texto(
            self.paleta,
            "Objetivo del día (ml)",
            valor=str(self.objetivo_agua) if self.objetivo_agua else "",
            pista="2000",
            al_enviar=lambda e: self._guardar_objetivo_agua(e.control.value),
        )
        self.campo_objetivo_agua.on_blur = lambda e: self._guardar_objetivo_agua(
            e.control.value
        )

        mandos = ft.Column(
            [
                ft.Row(
                    [
                        ft.Container(content=self.campo_ml, expand=True),
                        componentes.boton(
                            self.paleta,
                            "Añadir",
                            icono=ft.Icons.ADD,
                            principal=True,
                            al_pulsar=lambda _: self._beber_escrito(),
                        ),
                    ],
                    spacing=8,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                # LOS CUATRO ATAJOS SE REPARTEN EL ANCHO en vez de amontonarse a
                # la izquierda. Además de llenar el hueco, hace la diana más
                # grande: son los botones que más se pulsan de esta pantalla.
                ft.Row(
                    [
                        ft.Container(
                            content=componentes.boton(
                                self.paleta,
                                f"+{ml}",
                                al_pulsar=lambda _, m=ml: self._beber(m),
                            ),
                            expand=True,
                        )
                        for ml in TRAGOS_RAPIDOS
                    ],
                    spacing=6,
                ),
                ft.Row(
                    [
                        ft.Container(content=self.campo_objetivo_agua, expand=True),
                        componentes.boton(
                            self.paleta,
                            "Deshacer",
                            icono=ft.Icons.UNDO,
                            al_pulsar=lambda _: self._deshacer_trago(),
                        ),
                    ],
                    spacing=8,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                ft.Text(
                    self._texto_ultimo_trago(),
                    size=estilo.TEXTO_APOYO,
                    color=self.paleta.muted,
                ),
            ],
            spacing=12,
            expand=True,
        )

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(self.paleta, "Agua", None),
                    # EL VASO A UN LADO Y LOS MANDOS AL OTRO. Antes iban en
                    # columna: vaso, campo, atajos, objetivo, deshacer y aviso,
                    # seis filas que hacían la tarjeta el doble de alta que la de
                    # macros y dejaban el hueco negro de al lado. Puestos en fila
                    # ocupan lo mismo pero en la mitad de alto, y el vaso —que es
                    # lo que se mira— queda a la altura de los ojos.
                    ft.Row(
                        [self.hueco_vaso, mandos],
                        spacing=20,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                ],
                spacing=12,
            ),
        )

    def _texto_ultimo_trago(self) -> str:
        if not self.tragos:
            return "Todavía no has bebido nada hoy."
        ultimo = self.tragos[-1]
        return (
            f"{len(self.tragos)} tragos hoy · el último, "
            f"{texto_litros(ultimo.ml)} a las {ultimo.momento.strftime('%H:%M')}"
        )

    def _beber_escrito(self) -> None:
        try:
            ml = parsear_ml(self.campo_ml.value or "")
        except (ValueError, TypeError) as fallo:
            self._error = str(fallo)
            self.refrescar()
            return
        self.campo_ml.value = ""
        self._beber(ml)

    def _beber(self, ml: int) -> None:
        """Apunta un trago. SE SUMA a lo que había, porque es una fila nueva."""
        with conectado() as conexion:
            repo.beber(
                conexion,
                Trago(
                    ml=ml,
                    jornada=self.hoy,
                    momento=datetime.now().replace(microsecond=0),
                ),
            )
        self._error = ""
        self.refrescar()

    def _deshacer_trago(self) -> None:
        """Borra el último trago. Nunca resta: quita una fila."""
        with conectado() as conexion:
            borrado = repo.deshacer_ultimo_trago(conexion, self.hoy)
        self._error = "" if borrado else "No queda ningún trago que deshacer hoy."
        self.refrescar()

    def _guardar_objetivo_agua(self, escrito: str) -> None:
        limpio = (escrito or "").strip()
        try:
            # Vaciarlo es quitar el objetivo, no un error: sin objetivo el vaso
            # se queda vacío y al lado sigue estando lo que llevas.
            ml = None if not limpio else parsear_ml(limpio, tope=ML_MAXIMOS_OBJETIVO)
        except (ValueError, TypeError) as fallo:
            self._error = str(fallo)
            self.refrescar()
            return
        if ml == self.objetivo_agua:
            return
        with conectado() as conexion:
            repo.guardar_objetivo_agua(conexion, ml)
        self._error = ""
        self.refrescar()

    # ----------------------------------------------------------------------
    # Los objetivos de comida
    # ----------------------------------------------------------------------

    def _tarjeta_objetivos(self) -> ft.Control:
        self.campos_objetivo = {}
        filas = []
        for nutriente in ("kcal", "proteinas", "carbohidratos", "grasas"):
            actual = self.objetivos.de(nutriente)
            valor = ""
            if actual is not None:
                valor = str(actual) if nutriente == "kcal" else texto_gramos(actual)
            campo = componentes.campo_texto(
                self.paleta,
                "kcal" if nutriente == "kcal" else "g",
                valor=valor,
                pista="sin objetivo",
                al_enviar=lambda e, n=nutriente: self._guardar_objetivo(
                    n, e.control.value
                ),
            )
            campo.on_blur = lambda e, n=nutriente: self._guardar_objetivo(
                n, e.control.value
            )
            self.campos_objetivo[nutriente] = campo
            filas.append(
                # CADA UNO SE COME SU CUARTO DE TARJETA. Con el ancho fijo de
                # antes, los cuatro campos ocupaban el tercio izquierdo y los
                # otros dos tercios se quedaban en negro. Repartidos, la fila
                # llena la tarjeta y los campos son lo bastante anchos para ver
                # el número entero sin que se corte.
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(
                                NOMBRES[nutriente],
                                size=estilo.TEXTO_APOYO,
                                color=self.paleta.muted,
                            ),
                            campo,
                        ],
                        spacing=4,
                        tight=True,
                    ),
                    expand=True,
                )
            )

        return componentes.tarjeta(
            self.paleta,
            ft.Column(
                [
                    componentes.cabecera_tarjeta(
                        self.paleta,
                        "Mis objetivos del día",
                        "déjalo vacío si no quieres objetivo de algo; entonces se "
                        "enseña el total sin barra",
                    ),
                    # Sin wrap: los cuatro se reparten el ancho y siempre
                    # caben en una fila. Con wrap y anchos elásticos, Flet no
                    # sabe cuándo saltar y deja huecos raros.
                    ft.Row(filas, spacing=12),
                ],
                spacing=12,
            ),
        )

    def _guardar_objetivo(self, nutriente: str, escrito: str) -> None:
        limpio = (escrito or "").strip()
        try:
            if not limpio:
                valor = None
            elif nutriente == "kcal":
                valor = parsear_kcal(limpio) or None
            else:
                valor = parsear_gramos(limpio) or None
            nuevos = Objetivos(
                **{
                    campo: (valor if campo == nutriente else self.objetivos.de(campo))
                    for campo in ("kcal", "proteinas", "carbohidratos", "grasas")
                }
            )
        except (ValueError, TypeError) as fallo:
            self._error = str(fallo)
            self.refrescar()
            return
        if nuevos == self.objetivos:
            return
        with conectado() as conexion:
            repo.guardar_objetivos(conexion, nuevos)
        self._error = ""
        self.refrescar()

    # ----------------------------------------------------------------------
    # La lista de comidas
    # ----------------------------------------------------------------------

    def _tarjeta_comidas(self) -> ft.Control:
        nombres = [una.nombre for una in self.comidas]
        grupos = por_comida(self.registros, nombres)

        piezas: list[ft.Control] = [
            self._grupo(nombre, grupos[nombre]) for nombre in nombres
        ]

        # LOS DE UNA COMIDA QUE YA NO EXISTE salen igual, al final. Si borras el
        # "segundo desayuno" después de haber apuntado cosas ahí, esas cosas no
        # desaparecen: se quedan agrupadas con su nombre. Perder lo comido por
        # ordenar una lista sería mucho peor que ver un grupo de más.
        huerfanos = [nombre for nombre in grupos if nombre not in nombres]
        for nombre in sorted(huerfanos):
            piezas.append(self._grupo(nombre, grupos[nombre], borrada=True))

        piezas.append(
            ft.Row(
                [
                    componentes.boton(
                        self.paleta,
                        "Añadir comida",
                        icono=ft.Icons.ADD,
                        al_pulsar=lambda _: self._pedir_comida_nueva(),
                    ),
                    ft.Container(expand=True),
                ]
            )
        )
        return componentes.tarjeta(self.paleta, ft.Column(piezas, spacing=16))

    def _pedir_comida_nueva(self) -> None:
        """Pregunta el nombre y la añade al final del día.

        AL FINAL Y NO EN MEDIO: no hay forma de adivinar a qué hora comes eso.
        Se pone la última y se sube con las flechas, que es honesto y no obliga a
        pedirte una hora que a lo mejor no tienes clara.
        """
        campo = componentes.campo_texto(
            self.paleta,
            "Nombre de la comida",
            pista="segundo desayuno",
            largo_maximo=LARGO_MAXIMO_COMIDA,
        )
        error = ft.Text("", size=estilo.TEXTO_APOYO, color=self.paleta.negativo,
                        visible=False)

        def guardar(_):
            try:
                with conectado() as conexion:
                    repo.crear_comida(conexion, campo.value or "")
            except (ValueError, TypeError) as fallo:
                error.value = str(fallo)
                error.visible = True
                error.update()
                return
            self.pagina.pop_dialog()
            self.refrescar()

        self.pagina.show_dialog(
            componentes.dialogo(
                self.paleta,
                "Añadir una comida",
                ft.Column([campo, error], spacing=10, tight=True, width=340),
                pagina=self.pagina,
                texto_aceptar="Añadir",
                al_aceptar=guardar,
            )
        )

    def _quitar_comida(self, tipo) -> None:
        componentes.confirmar(
            self.paleta,
            self.pagina,
            titulo=f"Quitar «{tipo.nombre}»",
            texto=(
                "Lo que ya apuntaste ahí NO se borra: se sigue viendo, agrupado "
                "con ese nombre al final del día."
            ),
            texto_aceptar="Quitar",
            al_aceptar=lambda _: self._quitar_de_verdad(tipo),
        )

    def _quitar_de_verdad(self, tipo) -> None:
        with conectado() as conexion:
            repo.borrar_comida(conexion, tipo.id)
        self.pagina.pop_dialog()
        self.refrescar()

    def _mover_comida(self, tipo, arriba: bool) -> None:
        with conectado() as conexion:
            repo.mover_comida(conexion, tipo.id, arriba)
        self.refrescar()

    def _grupo(
        self, comida: str, registros: list[Registro], *, borrada: bool = False
    ) -> ft.Control:
        kcal = sum(uno.kcal for uno in registros)
        cabecera = ft.Row(
            [
                ft.Text(
                    comida.capitalize(),
                    size=13,
                    weight=ft.FontWeight.W_600,
                    color=self.paleta.muted if borrada else self.paleta.ink,
                ),
                ft.Text(
                    "ya no está en tu lista" if borrada else "",
                    size=estilo.ROTULO,
                    color=self.paleta.muted,
                    expand=True,
                ),
                ft.Text(
                    f"{kcal} kcal" if registros else "",
                    size=12,
                    color=self.paleta.muted,
                ),
                *self._mandos_de_comida(comida, borrada),
            ],
            spacing=8,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )
        cuerpo: ft.Control = (
            ft.Column([self._fila_registro(uno) for uno in registros], spacing=0)
            if registros
            else ft.Text("—", size=12, color=self.paleta.muted)
        )
        return ft.Column([cabecera, cuerpo], spacing=6, tight=True)

    def _mandos_de_comida(self, comida: str, borrada: bool) -> list[ft.Control]:
        """Las flechas y la papelera de un momento del día.

        Una comida borrada no los lleva: ya no está en la lista, así que no hay
        nada que ordenar ni que quitar. Solo se enseña para que sus registros
        sigan viéndose.
        """
        if borrada:
            return []
        tipo = next((una for una in self.comidas if una.es_la_misma(comida)), None)
        if tipo is None:
            return []
        return [
            componentes.boton_icono(
                self.paleta, ft.Icons.ARROW_UPWARD, ayuda="Subir",
                al_pulsar=lambda _, x=tipo: self._mover_comida(x, True),
            ),
            componentes.boton_icono(
                self.paleta, ft.Icons.ARROW_DOWNWARD, ayuda="Bajar",
                al_pulsar=lambda _, x=tipo: self._mover_comida(x, False),
            ),
            componentes.boton_icono(
                self.paleta, ft.Icons.DELETE_OUTLINE, ayuda="Quitar del día",
                al_pulsar=lambda _, x=tipo: self._quitar_comida(x),
            ),
        ]

    def _fila_registro(self, registro: Registro) -> ft.Control:
        """Una línea de comida. Se pulsa encima para corregirla, como se pidió."""
        macros = " · ".join(
            f"{texto_gramos(getattr(registro, campo))} g {etiqueta}"
            for campo, etiqueta in (
                ("proteinas", "P"),
                ("carbohidratos", "C"),
                ("grasas", "G"),
            )
        )
        return ft.Container(
            content=ft.Row(
                [
                    ft.Column(
                        [
                            ft.Text(registro.resumen(), size=13, color=self.paleta.ink),
                            ft.Text(macros, size=11, color=self.paleta.muted),
                        ],
                        spacing=1,
                        tight=True,
                        expand=True,
                    ),
                    ft.Text(
                        f"{registro.kcal} kcal",
                        size=13,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.ink_soft,
                    ),
                ],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(vertical=7, horizontal=6),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.paleta.borde)),
            border_radius=estilo.RADIO_BOTON,
            on_click=lambda _, r=registro: dialogo_comida.abrir(
                self.pagina, self.paleta, self.hoy, self.refrescar, r
            ),
            ink=True,
            tooltip="Pulsa para corregirlo",
        )

    # ----------------------------------------------------------------------
    # Repetir
    # ----------------------------------------------------------------------

    def _abrir_repetir(self) -> None:
        """Lo único que la aplicación se ofrece a hacer por el usuario.

        Y ni siquiera rellena sola: le enseña lo que él escribió otro día para
        que lo repita si quiere, y al elegirlo se abre la ventanita con esos
        valores para que pueda cambiarlos ANTES de añadirlo.
        """
        with conectado() as conexion:
            repetibles = repo.mas_repetidos(conexion)

        if not repetibles:
            componentes.avisar(
                self.pagina, "Todavía no has apuntado nada que repetir."
            )
            return

        filas = [
            ft.Container(
                content=ft.Row(
                    [
                        ft.Column(
                            [
                                ft.Text(
                                    registro.resumen(), size=13, color=self.paleta.ink
                                ),
                                ft.Text(
                                    f"{registro.kcal} kcal · "
                                    f"{texto_gramos(registro.proteinas)} g P",
                                    size=11,
                                    color=self.paleta.muted,
                                ),
                            ],
                            spacing=1,
                            tight=True,
                            expand=True,
                        ),
                        ft.Text(
                            f"{veces} {'vez' if veces == 1 else 'veces'}",
                            size=11,
                            color=self.paleta.muted,
                        ),
                    ],
                    spacing=10,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                padding=ft.Padding.symmetric(vertical=7, horizontal=6),
                border_radius=estilo.RADIO_BOTON,
                on_click=lambda _, r=registro: self._repetir(r),
                ink=True,
            )
            for registro, veces in repetibles
        ]

        self.pagina.show_dialog(
            componentes.dialogo(
                self.paleta,
                "Repetir algo que ya apunté",
                ft.Container(
                    content=ft.Column(
                        filas, spacing=0, scroll=ft.ScrollMode.AUTO, height=360
                    ),
                    width=420,
                ),
                pagina=self.pagina,
                texto_aceptar="Cerrar",
                al_aceptar=lambda _: self.pagina.pop_dialog(),
            )
        )

    def _repetir(self, registro: Registro) -> None:
        self.pagina.pop_dialog()
        dialogo_comida.abrir(
            self.pagina, self.paleta, self.hoy, self.refrescar, registro, copiando=True
        )


def _dia_largo(dia: date) -> str:
    nombre = DIAS_SEMANA[dia.weekday()][2].capitalize()
    return f"{nombre} {dia.day} de {MESES[dia.month - 1]}"
