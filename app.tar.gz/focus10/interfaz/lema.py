"""Una frase por tema, en la cabecera del Dashboard. Y nada más.

DE DÓNDE SALE: al rediseñar los trece temas, el usuario enseñó maquetas donde
cada uno hablaba distinto —«Misiones de hoy», «Semillas de hoy», «Rituales de
hoy»—. Se le planteó hacerlo entero y lo cortó él mismo, con buen criterio:

    «Hábitos en todos tiene que ser hábitos, nada de semillas. Todo lo que
    tenga funcionalidad va igual en todo, así se hace más sencillo el código.
    Detalles sí, pero nada que cambie el código, solo boludeces, ningún botón.»

ASÍ QUE ESTO ES LO ÚNICO QUE CAMBIA CON EL TEMA, y las razones de que sea tan
poco valen más que la frase:

  - LOS NOMBRES SE QUEDAN QUIETOS. Un hábito se llama hábito en los trece. Si
    buscaras «Hábitos» y el tema lo llamara «Semillas», cambiar de tema dejaría
    de ser cosmético: tendrías que reaprender tu propia aplicación cada vez.
  - NINGÚN BOTÓN. «Descartar entreno» se llama igual siempre. Un botón que
    borra una hora de trabajo no puede cambiar de nombre según el color.
  - NADA QUE SE PUEDA COMPROBAR POR SU TEXTO. Las cuarenta comprobaciones de
    interfaz buscan textos literales; si trece temas los cambiaran, o serían
    trece veces más frágiles o habría que relajarlas. Esa red ha cazado esta
    semana que el reloj no arrancaba y que las calorías se inventaban un peso.

ES DECORACIÓN Y SE TRATA COMO TAL: si un día sobra, se borra este archivo y una
línea del Dashboard.
"""

from __future__ import annotations

LEMAS = {
    "elegante": "Todo en orden.",
    "ochentas": "Subí de nivel.",
    "premium": "Tu día, refinado.",
    "minimalista": "Un paso a la vez.",
    "natural": "Crecer también cuenta.",
    "solar": "Hoy encendiste el día.",
    "electric": "Construí impulso.",
    "isla": "Respirá hondo.",
    "aurora": "Todo en calma.",
    "terra": "Anotá el día.",
    "ia": "Día bajo control.",
    "focus": "Construí tu día.",
    "galaxia": "Otra noche despejada.",
}

POR_OMISION = "Todo en orden."
"""La de Elegante, que es el tema de partida.

SE DEVUELVE ALGO SIEMPRE: un tema sin frase dejaría un hueco en la cabecera, y
un hueco se lee como que algo se ha roto.
"""


def de(clave: str) -> str:
    """La frase de ese tema."""
    return LEMAS.get(clave, POR_OMISION)
