"""El perfil competitivo de alguien del ranking: sus cuentas y cómo le fue.

SOLO ESTADÍSTICAS, lo pidió el usuario: puesto, puntos, hábitos cumplidos,
entrenos, días activos, racha, y el PROGRESO: en qué puesto estuvo cada día
de este mes y cada mes desde que existe el ranking. Ni nombres de hábitos, ni
fotos, ni textos.

EL GRÁFICO SE DIBUJA CON RECTÁNGULOS, como el de Finanzas (ver grafico.py):
una barra por día, más alta cuanto mejor el puesto. Cada barra se reparte el
ancho (expand), así entra en un celular sin deslizar.
"""

from __future__ import annotations

import flet as ft

from . import componentes, estilo

ALTO_GRAFICO = 90

MESES = ("ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic")


def nombre_del_mes(clave: str) -> str:
    """«2026-11» → «nov 2026»."""
    try:
        anio, mes = clave.split("-")
        return f"{MESES[int(mes) - 1]} {anio}"
    except (ValueError, IndexError):
        return clave


def piezas(pantalla, datos: dict) -> list[ft.Control]:
    """Lo que pinta la pantalla de la Comunidad cuando se abre un perfil."""
    paleta = pantalla.paleta
    cuentas = ft.Row(
        [
            _cifra(paleta, str(datos.get("habitos", 0)), "hábitos cumplidos"),
            _cifra(paleta, str(datos.get("entrenos", 0)), "entrenos"),
            _cifra(paleta, str(datos.get("dias", 0)), "días activos"),
            _cifra(paleta, str(datos.get("racha", 0)), "racha más larga"),
        ],
        wrap=True, spacing=12, run_spacing=12,
    )
    cabeza = ft.Row(
        [
            componentes.boton_icono(paleta, ft.Icons.ARROW_BACK, ayuda="Volver al ranking",
                                    al_pulsar=lambda _: pantalla.cerrar_perfil()),
            ft.Text(f"@{datos.get('alias', '')}", size=estilo.TITULAR, weight=ft.FontWeight.W_600,
                    color=paleta.acento if datos.get("yo") else paleta.ink,
                    font_family=paleta.titular, expand=True,
                    max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
        ],
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )
    resumen = componentes.tarjeta(paleta, ft.Column(
        [
            componentes.cabecera_tarjeta(paleta, f"Este mes · {nombre_del_mes(datos.get('mes', ''))}"),
            ft.Row(
                [
                    ft.Text(f"#{datos.get('puesto', '–')}", size=estilo.CIFRA_GRANDE,
                            weight=ft.FontWeight.W_700, color=paleta.acento,
                            font_family=paleta.titular),
                    ft.Text(f"de {datos.get('competidores', 0)} · {datos.get('puntos', 0)} puntos",
                            size=estilo.TEXTO_TARJETA, color=paleta.ink),
                ],
                spacing=14, vertical_alignment=ft.CrossAxisAlignment.CENTER, wrap=True,
            ),
            cuentas,
        ],
        spacing=12,
    ))
    progreso = componentes.tarjeta(paleta, ft.Column(
        [
            componentes.cabecera_tarjeta(paleta, "Progreso", "Su puesto al terminar cada día"),
            grafico_puestos(paleta, list(datos.get("puestos_por_dia") or []),
                            int(datos.get("competidores") or 1)),
        ],
        spacing=10,
    ))
    meses = [
        ft.Row(
            [
                ft.Text(nombre_del_mes(m.get("mes", "")), size=estilo.TEXTO, color=paleta.ink, expand=True),
                ft.Text(f"#{m.get('puesto', '–')}", size=estilo.TEXTO, weight=ft.FontWeight.W_600,
                        color=paleta.acento),
                ft.Text(f"{m.get('puntos', 0)} pts", size=estilo.TEXTO_APOYO, color=paleta.muted,
                        width=70, text_align=ft.TextAlign.RIGHT),
            ],
        )
        for m in reversed(datos.get("meses") or [])
    ]
    historial = componentes.tarjeta(paleta, ft.Column(
        [componentes.cabecera_tarjeta(paleta, "Mes a mes"), *meses], spacing=8,
    ))
    return [cabeza, resumen, progreso, historial]


def _cifra(paleta, valor: str, texto: str) -> ft.Control:
    return ft.Container(
        ft.Column(
            [
                ft.Text(valor, size=estilo.CIFRA, weight=ft.FontWeight.W_600, color=paleta.ink,
                        font_family=paleta.titular),
                ft.Text(texto, size=estilo.ROTULO, color=paleta.muted),
            ],
            spacing=0, tight=True,
        ),
        width=130,
    )


def alturas(puestos: list[int], competidores: int) -> list[int]:
    """La altura de la barra de cada día: el 1.º llena el gráfico, el último
    apenas se ve, y un día sin puntos (puesto 0) no tiene barra."""
    total = max(1, competidores)
    salida = []
    for puesto in puestos:
        if puesto <= 0:
            salida.append(0)
        else:
            salida.append(max(6, round(ALTO_GRAFICO * (total - puesto + 1) / total)))
    return salida


def grafico_puestos(paleta, puestos: list[int], competidores: int) -> ft.Control:
    if not any(puestos):
        return ft.Text("Sin puntos todavía este mes.", size=estilo.TEXTO_APOYO, color=paleta.muted)
    barras = []
    for dia, (puesto, alto) in enumerate(zip(puestos, alturas(puestos, competidores)), start=1):
        barras.append(ft.Container(
            ft.Container(height=alto, bgcolor=paleta.acento, border_radius=3),
            expand=True, height=ALTO_GRAFICO, alignment=ft.Alignment.BOTTOM_CENTER,
            tooltip=f"Día {dia}: puesto {puesto}" if puesto else f"Día {dia}: sin puntos",
        ))
    return ft.Column(
        [
            ft.Row(barras, spacing=2, vertical_alignment=ft.CrossAxisAlignment.END),
            ft.Row(
                [ft.Text("Día 1", size=estilo.ROTULO, color=paleta.muted, expand=True),
                 ft.Text(f"Día {len(puestos)}", size=estilo.ROTULO, color=paleta.muted)],
            ),
        ],
        spacing=4, tight=True,
    )
