"""Empezar el entreno de hoy: lo usan el botón del Dashboard y el de Rutina.

ANTES CADA UNO TENÍA SU COPIA, y las dos decían lo mismo. Al llegar los varios
entrenos por día la regla se complicó lo bastante como para que dos copias
acabaran separándose, así que vive aquí una sola vez.

LA REGLA, con las palabras del usuario: «si ese día hay dos entrenamientos,
primero se debe empezar uno, no los dos al mismo tiempo; elegís cuál empezar,
cada uno es independiente del otro, no se suma el tiempo». Entonces:

  - SI HAY UNO EN MARCHA, el botón lo abre. No se empieza otro encima.
  - SI EL DÍA TIENE VARIOS BLOQUES (GYM, Movilidad...), se pregunta cuál. Los
    ya hechos salen también, para volver a abrirlos.
  - SI TIENE UNO SOLO, se empieza directo, como siempre.
  - UN ENTRENO YA EMPEZADO NO SE VUELVE A CREAR: se abre el que hay. Crear
    otro perdería las series ya marcadas.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime

import flet as ft

from ..datos import repositorio_entreno, repositorio_gimnasio
from ..datos.bd import conectado
from ..dominio.rutina import BloqueDeRutina, DiaDeRutina
from ..dominio.sesion import Sesion
from .estilo import Paleta


@dataclass(frozen=True)
class Estado:
    """Cómo está el gimnasio hoy, para el texto y el botón."""

    sesiones: tuple[Sesion, ...]
    """Los entrenos de hoy que ya existen, empezados o terminados."""
    pendientes: tuple[BloqueDeRutina, ...]
    """Los bloques de la rutina de hoy que todavía no se empezaron."""

    @property
    def en_marcha(self) -> Sesion | None:
        return next((uno for uno in self.sesiones if uno.en_marcha), None)

    @property
    def series_hechas(self) -> int:
        return sum(uno.series_hechas for uno in self.sesiones)

    @property
    def volumen(self) -> int:
        return sum(uno.volumen for uno in self.sesiones)


def bloques_de(dia: DiaDeRutina) -> list[BloqueDeRutina]:
    """Los bloques de ese día que tienen algo que hacer, en su orden."""
    if dia.es_descanso:
        return []
    return [uno for uno in sorted(dia.bloques, key=lambda b: b.orden) if uno.ejercicios]


def estado(conexion, hoy: date, dia: DiaDeRutina) -> Estado:
    sesiones = tuple(repositorio_gimnasio.sesiones_del_dia(conexion, hoy))
    # UN ENTRENO DE ANTES DE LOS BLOQUES (bloque vacío) ERA EL DÍA ENTERO: con
    # él, no queda ningún bloque pendiente.
    if any(not uno.bloque for uno in sesiones):
        return Estado(sesiones, ())
    hechos = {uno.bloque for uno in sesiones}
    return Estado(sesiones, tuple(b for b in bloques_de(dia) if b.nombre not in hechos))


def etiqueta(actual: Estado, dia: DiaDeRutina) -> str:
    """Lo que dice el botón. «Seguir» si ya empezaste: un segundo «Empezar»
    hace pensar que se borra lo que llevás hecho."""
    if actual.en_marcha is not None:
        return "Seguir entrenando"
    if actual.pendientes and actual.sesiones:
        return "Empezar el siguiente"
    if actual.pendientes:
        return "Empezar entreno"
    if actual.sesiones:
        return "Abrir el entreno de hoy"
    if dia.es_descanso:
        return "Entrenar igualmente"
    return "Empezar un entreno suelto"


def pulsar(pagina: ft.Page, paleta: Paleta, hoy: date, dia: DiaDeRutina, al_entrenar) -> None:
    """Lo que pasa al tocar el botón (ver la cabecera)."""
    if al_entrenar is None:
        return
    with conectado() as conexion:
        actual = estado(conexion, hoy, dia)

    if actual.en_marcha is not None:
        al_entrenar(hoy, actual.en_marcha.bloque)
        return
    if not actual.pendientes and not actual.sesiones:
        # DESCANSO O NADA PLANEADO: un entreno suelto, vacío, para añadirle
        # ejercicios a mano. Pasa, y no obliga a cambiar el plan de la semana.
        _empezar(hoy, dia, None, al_entrenar)
        return
    if len(actual.pendientes) + len(actual.sesiones) == 1:
        if actual.pendientes:
            _empezar(hoy, dia, actual.pendientes[0], al_entrenar)
        else:
            al_entrenar(hoy, actual.sesiones[0].bloque)
        return
    _preguntar_cual(pagina, paleta, hoy, dia, actual, al_entrenar)


def _empezar(hoy: date, dia: DiaDeRutina, bloque: BloqueDeRutina | None, al_entrenar) -> None:
    # CON LO ÚLTIMO REAL de cada ejercicio: ver repositorio_entreno.empezar.
    with conectado() as conexion:
        repositorio_entreno.empezar(conexion, dia, hoy, datetime.now(), bloque)
    al_entrenar(hoy, "" if bloque is None else bloque.nombre)


def _preguntar_cual(pagina, paleta: Paleta, hoy, dia, actual: Estado, al_entrenar) -> None:
    def empezar_este(bloque):
        pagina.pop_dialog()
        _empezar(hoy, dia, bloque, al_entrenar)

    def abrir_este(sesion):
        pagina.pop_dialog()
        al_entrenar(hoy, sesion.bloque)

    opciones = [
        ft.FilledButton(f"Empezar «{uno.nombre}»", on_click=lambda _, b=uno: empezar_este(b))
        for uno in actual.pendientes
    ] + [
        ft.OutlinedButton(f"Abrir «{uno.titulo()}» (hecho)", on_click=lambda _, s=uno: abrir_este(s))
        for uno in actual.sesiones
    ]
    pagina.show_dialog(ft.AlertDialog(
        title=ft.Text("¿Cuál empezás?"),
        content=ft.Column(
            [
                ft.Text("Cada entreno tiene su propio reloj y su resumen.", size=13,
                        color=paleta.ink_soft),
                *opciones,
            ],
            tight=True,
            spacing=10,
        ),
        actions=[ft.TextButton("Cancelar", on_click=lambda _: pagina.pop_dialog())],
    ))
