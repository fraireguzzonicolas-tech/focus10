"""La cuadrícula del año: un cuadrito por día, como el calendario de HelloHabit.

POR QUÉ SE DIBUJA EN UN LIENZO Y NO CON CONTENEDORES: son 365 cuadritos por
hábito. Con siete hábitos serían más de dos mil controles en pantalla, cada uno
con su tamaño, su color y su borde que Flet tiene que mantener. En un lienzo son
365 rectángulos pintados de una pasada, y la pantalla abre igual de rápido con
uno que con veinte hábitos.

LO QUE SE PIERDE Y POR QUÉ SE ACEPTA: un rectángulo pintado no puede tener ayuda
emergente, así que no se puede pasar el ratón por un día suelto para ver qué
pasó. A cambio la pantalla es la foto del año de un vistazo, que es justo para lo
que sirve; el detalle de un día concreto está en el Dashboard.

LOS CUATRO GRISES: un cuadrito apagado significa tres cosas distintas —fallé, no
tocaba, o aún no ha llegado— y se distinguen con tonos. Sin eso, un hábito de
lunes-miércoles-viernes parecería fallado cuatro días de cada siete.
"""

from __future__ import annotations

import flet as ft
import flet.canvas as cv

from ..dominio.anuario import Anuario, EstadoDia, por_semanas
from .estilo import Paleta, color_de_habito, con_opacidad

LADO = 8
"""Lo que mide un cuadrito. Pequeño a propósito: el año entero tiene que caber."""

HUECO = 2
PASO = LADO + HUECO
FILAS = 7
REDONDEO = 2


def rejilla(paleta: Paleta, anuario: Anuario, *, color: str) -> ft.Control:
    """El año entero de un hábito, en cuadritos."""
    semanas = por_semanas(anuario)
    tono = color_de_habito(color)

    # Un solo objeto Paint por estado, compartido por todos los cuadritos que lo
    # usan: crear uno por día serían 365 objetos para cuatro colores distintos.
    pinturas = {
        EstadoDia.CUMPLIDO: ft.Paint(color=tono),
        EstadoDia.FALLADO: ft.Paint(color=con_opacidad(tono, 0.14)),
        EstadoDia.NO_PROGRAMADO: ft.Paint(color=paleta.surface_2),
        EstadoDia.ANTES: ft.Paint(color=paleta.surface_2),
        EstadoDia.FUTURO: ft.Paint(color=paleta.surface_2),
    }

    formas: list[cv.Shape] = []
    for columna, dias in enumerate(semanas):
        for fila, casilla in enumerate(dias):
            if casilla is None:
                # Hueco del principio o del final del año: ese día no existe, y
                # pintarlo diría que sí.
                continue
            formas.append(
                cv.Rect(
                    x=columna * PASO,
                    y=fila * PASO,
                    width=LADO,
                    height=LADO,
                    border_radius=REDONDEO,
                    paint=pinturas[casilla.estado],
                )
            )

    ancho = len(semanas) * PASO
    return ft.Container(
        content=cv.Canvas(formas, width=ancho, height=FILAS * PASO),
        width=ancho,
        height=FILAS * PASO,
    )


def cabecera(
    paleta: Paleta,
    *,
    nombre: str,
    emoji: str,
    objetivo: str,
    anuario: Anuario,
    color: str,
) -> ft.Control:
    """La línea de arriba: el hábito, su objetivo y su porcentaje del año."""
    tono = color_de_habito(color)
    return ft.Row(
        [
            ft.Text(emoji, size=15),
            ft.Text(nombre, size=14, weight=ft.FontWeight.W_600, color=paleta.ink),
            ft.Text(f"— {objetivo}", size=13, color=paleta.muted, expand=True),
            _porcentaje(paleta, anuario, tono),
        ],
        spacing=8,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )


def _porcentaje(paleta: Paleta, anuario: Anuario, tono: str) -> ft.Control:
    """El número de la derecha, o una raya cuando todavía no hay nada que contar.

    NO SE ENSEÑA "0 %" CUANDO NO HAY DATOS: un hábito recién creado, o el año que
    viene, no han fallado nada. Un cero ahí sería un suspenso inventado.
    """
    if not anuario.hay_algo_que_contar:
        return ft.Text(
            "—",
            size=13,
            color=paleta.muted,
            tooltip="Todavía no hay ningún día que contar",
        )
    return ft.Text(
        f"{anuario.porcentaje}%",
        size=13,
        weight=ft.FontWeight.W_600,
        color=tono,
        tooltip=f"{anuario.cumplidos} de {anuario.programados} días que tocaban",
    )
