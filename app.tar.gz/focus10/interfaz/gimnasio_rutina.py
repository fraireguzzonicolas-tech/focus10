"""La rutina de la semana: la vista de RUTINA del gimnasio.

ES EL PLAN, y solo el plan. Aquí no se marca nada como hecho ni se apunta ningún
peso levantado: eso vive en la sesión y en otra tabla. Lo que se escribe aquí es
"los lunes toca esto, con estas series objetivo", y se repite cada semana hasta
que se cambie.

LOS DÍAS VIENEN PLEGADOS, y lo pidió el usuario: entrena todos los días, y con
los siete abiertos la pantalla se hacía kilométrica. Plegados, la semana entera
cabe de un vistazo y cada línea ya dice lo que necesita saberse —el nombre del
día y cuántos ejercicios tiene—; se abre el que se vaya a tocar.

CON FLECHAS Y NO CON ARRASTRE para ordenar, y lo eligió el usuario con estas
palabras: "prefiero flechas que funcionen a un arrastre que falle". Flet tiene
arrastre, pero dentro de una lista que se repinta entera con cada cambio es
frágil de un modo que no compensa para ganar un gesto.

EL DESCANSO LO ELIGE LA PERSONA, ejercicio por ejercicio, aquí. La ficha de la
biblioteca solo aporta el valor de partida al añadirlo; a partir de ahí manda lo
que se escriba en esta pantalla.
"""

from __future__ import annotations

from dataclasses import replace

import flet as ft

from ..datos import repositorio_gimnasio
from ..datos.bd import conectado
from ..dominio.descanso import (
    parsear_descanso,
    parsear_duracion,
    texto_descanso,
    texto_duracion,
)
from ..dominio.ejercicio import Grupo, Medida
from ..dominio.habito import COLORES
from ..dominio.rutina import (
    REPETICIONES_MAXIMAS,
    SERIES_MAXIMAS,
    DiaDeRutina,
    EjercicioPlaneado,
    mover,
    parsear_peso,
    renumerar,
    texto_peso,
)
from . import componentes, dialogo_anadir_ejercicio, estilo


def vista(pantalla) -> list[ft.Control]:
    return _Vista(pantalla).piezas()


class _Vista:
    def __init__(self, pantalla) -> None:
        self.pantalla = pantalla
        self.paleta = pantalla.paleta
        self.pagina = pantalla.pagina
        # Qué días están abiertos. Vive en la pantalla y no aquí porque esta
        # clase se construye de nuevo en cada repintado: si viviera aquí, el día
        # que acabas de abrir se cerraría solo al escribir un número.
        if not hasattr(pantalla, "dias_abiertos"):
            pantalla.dias_abiertos = set()

    def piezas(self) -> list[ft.Control]:
        return [
            ft.Row(
                [
                    ft.Text(
                        "Esto es el PLAN, y se repite cada semana. Lo que hagas "
                        "de verdad se apunta en «Hoy» y no cambia nada de aquí.",
                        size=estilo.TEXTO,
                        color=self.paleta.muted,
                        expand=True,
                    ),
                    componentes.boton(
                        self.paleta,
                        "Cerrar todos"
                        if self.pantalla.dias_abiertos
                        else "Abrir todos",
                        al_pulsar=lambda _: self._todos(),
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=16,
            ),
            *[self._tarjeta_dia(numero) for numero in range(7)],
        ]

    def _todos(self) -> None:
        if self.pantalla.dias_abiertos:
            self.pantalla.dias_abiertos = set()
        else:
            self.pantalla.dias_abiertos = set(range(7))
        self.pantalla.refrescar()

    # ------------------------------------------------------------------
    # Un día
    # ------------------------------------------------------------------

    def _tarjeta_dia(self, numero: int) -> ft.Control:
        dia = self.pantalla.rutina.get(numero) or DiaDeRutina(dia=numero)
        abierto = numero in self.pantalla.dias_abiertos

        cuerpo: list[ft.Control] = [self._cabecera(dia, abierto)]
        if abierto:
            cuerpo.append(componentes.separador(self.paleta))
            cuerpo += self._detalle(dia)

        return componentes.tarjeta(
            self.paleta,
            ft.Column(cuerpo, spacing=14),
            relleno=16 if not abierto else estilo.RELLENO_TARJETA,
        )

    def _cabecera(self, dia: DiaDeRutina, abierto: bool) -> ft.Control:
        """La línea que se ve siempre. Tocarla abre o cierra el día.

        LLEVA EL RESUMEN DENTRO a propósito: un día plegado que solo dijera
        "lunes" obligaría a abrirlo para saber si hay algo. Con "Empuje · 4
        ejercicios" la semana se lee entera sin tocar nada.
        """
        if dia.es_descanso:
            resumen = "Descanso"
            tono = self.paleta.muted
        elif dia.ejercicios:
            cuantos = len(dia.ejercicios)
            resumen = f"{dia.titulo()} · {cuantos} ejercicio"
            resumen += "s" if cuantos != 1 else ""
            tono = self.paleta.ink_soft
        else:
            resumen = "Sin asignar"
            tono = self.paleta.muted

        return ft.Container(
            content=ft.Row(
                [
                    ft.Icon(
                        ft.Icons.EXPAND_MORE if abierto else ft.Icons.CHEVRON_RIGHT,
                        size=20,
                        color=self.paleta.muted,
                    ),
                    ft.Text(
                        dia.nombre_del_dia.capitalize(),
                        size=estilo.TEXTO_TARJETA,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.ink,
                        width=110,
                    ),
                    ft.Text(resumen, size=estilo.TEXTO, color=tono, expand=True),
                    self._punto_de_color(dia),
                ],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            on_click=lambda _, n=dia.dia: self._alternar(n),
            ink=True,
            border_radius=10,
            padding=ft.Padding.symmetric(horizontal=6, vertical=4),
        )

    def _punto_de_color(self, dia: DiaDeRutina) -> ft.Control:
        """Un círculo con el color del día. Es lo que ata esta pantalla con el
        calendario, donde ese mismo color pinta la casilla."""
        if dia.es_descanso or not dia.ejercicios:
            return ft.Container(width=12, height=12)
        return ft.Container(
            width=12,
            height=12,
            bgcolor=estilo.color_de_habito(dia.color),
            border_radius=999,
        )

    def _alternar(self, numero: int) -> None:
        if numero in self.pantalla.dias_abiertos:
            self.pantalla.dias_abiertos.discard(numero)
        else:
            self.pantalla.dias_abiertos.add(numero)
        self.pantalla.refrescar()

    # ------------------------------------------------------------------
    # Lo de dentro
    # ------------------------------------------------------------------

    def _detalle(self, dia: DiaDeRutina) -> list[ft.Control]:
        nombre = componentes.campo_texto(
            self.paleta, "Nombre del día", valor=dia.nombre, ancho=220
        )
        nombre.on_blur = lambda _, d=dia, c=nombre: self._guardar(
            replace(d, nombre=(c.value or "").strip())
        )

        piezas: list[ft.Control] = [
            ft.Row(
                [
                    nombre,
                    self._selector_color(dia),
                    ft.Container(expand=True),
                    componentes.interruptor(
                        self.paleta,
                        "Descanso",
                        valor=dia.es_descanso,
                        al_cambiar=lambda e, d=dia: self._marcar_descanso(
                            d, e.control.value
                        ),
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=12,
            )
        ]

        if dia.es_descanso:
            piezas.append(
                ft.Text(
                    "Día de descanso. Descansar también es entrenar.",
                    size=estilo.TEXTO,
                    color=self.paleta.muted,
                )
            )
            return piezas

        ordenados = sorted(dia.ejercicios, key=lambda uno: uno.orden)

        # DOS TABLAS Y NO UNA, y esto lo pidió el usuario viendo una caminata en
        # cinta con casillas de peso y repeticiones: "al ser cardio no va serie,
        # peso, etc.; solo pones el tiempo". Tenía razón. Un ejercicio que se
        # mide en TIEMPO no tiene repeticiones ni kilos, y enseñar esas casillas
        # a cero no es neutral: invita a rellenarlas con algo que luego no
        # significa nada.
        #
        # Se separan en dos tablas en vez de dejar huecos en la misma porque una
        # tabla con la mitad de las celdas vacías se lee peor que dos tablas
        # cortas, y porque las cabeceras dirían "REPS" encima de una columna que
        # ahí no existe.
        de_tiempo = [uno for uno in ordenados if self._es_de_tiempo(uno)]
        de_peso = [uno for uno in ordenados if not self._es_de_tiempo(uno)]

        if de_peso or not de_tiempo:
            piezas.append(
                componentes.tabla(
                    self.paleta,
                    [
                        ("EJERCICIO", None),
                        ("SERIES", 84),
                        ("REPS", 84),
                        ("PESO", 108),
                        ("DESCANSO", 108),
                        ("", 130),
                    ],
                    [
                        self._fila(dia, uno, ordenados.index(uno))
                        for uno in de_peso
                    ],
                    vacia="Este día no tiene nada asignado todavía.",
                )
            )

        if de_tiempo:
            piezas.append(
                componentes.tabla(
                    self.paleta,
                    [
                        ("EJERCICIO (POR TIEMPO)", None),
                        ("SERIES", 84),
                        ("DURACIÓN", 108),
                        ("DESCANSO", 108),
                        ("", 130),
                    ],
                    [
                        self._fila_de_tiempo(dia, uno, ordenados.index(uno))
                        for uno in de_tiempo
                    ],
                )
            )
        piezas.append(
            componentes.boton(
                self.paleta,
                "Añadir ejercicio",
                icono=ft.Icons.ADD,
                al_pulsar=lambda _, d=dia: self._anadir(d),
            )
        )
        return piezas

    def _selector_color(self, dia: DiaDeRutina) -> ft.Control:
        selector = componentes.selector(
            self.paleta,
            "Color",
            [(uno, uno.capitalize()) for uno in COLORES],
            valor=dia.color,
            ancho=150,
        )
        selector.on_select = lambda e, d=dia, s=selector: self._guardar(
            replace(d, color=s.value or d.color)
        )
        return selector

    def _fila(
        self, dia: DiaDeRutina, planeado: EjercicioPlaneado, indice: int
    ) -> list[ft.Control]:
        series = self._numero(str(planeado.series_objetivo), 66)
        series.on_blur = lambda _, c=series: self._guardar_numero(
            dia, planeado, "series_objetivo", c, 1, SERIES_MAXIMAS
        )
        reps = self._numero(str(planeado.repeticiones_objetivo), 66)
        reps.on_blur = lambda _, c=reps: self._guardar_numero(
            dia, planeado, "repeticiones_objetivo", c, 0, REPETICIONES_MAXIMAS
        )
        peso = self._numero(texto_peso(planeado.peso_objetivo).removesuffix(" kg"), 90)
        peso.on_blur = lambda _, c=peso: self._guardar_peso(dia, planeado, c)

        return [
            ft.Text(planeado.nombre, size=estilo.TEXTO, color=self.paleta.ink),
            series,
            reps,
            peso,
            self._campo_descanso(dia, planeado),
            self._flechas(dia, planeado, indice),
        ]

    def _campo_descanso(self, dia, planeado) -> ft.TextField:
        campo = self._numero(_descanso_escrito(planeado), 90)
        campo.hint_text = "1:30"
        campo.tooltip = (
            "Cuánto descansas entre series de ESTE ejercicio.\n"
            "Vale escribirlo como quieras: 90, 1:30, 1.30, 1.3, 1m30, 30s."
        )
        campo.on_blur = lambda _, c=campo: self._guardar_descanso(dia, planeado, c)
        return campo

    def _flechas(self, dia, planeado, indice: int) -> ft.Control:
        """Subir, bajar y quitar. Las usan las dos clases de fila."""
        return ft.Row(
            [
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.ARROW_UPWARD,
                    ayuda="Subir",
                    al_pulsar=lambda _, i=indice: self._mover(dia, i, True),
                ),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.ARROW_DOWNWARD,
                    ayuda="Bajar",
                    al_pulsar=lambda _, i=indice: self._mover(dia, i, False),
                ),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.DELETE_OUTLINE,
                    ayuda="Quitar del día",
                    al_pulsar=lambda _, p=planeado: self._quitar(dia, p),
                ),
            ],
            spacing=0,
            tight=True,
        )

    def _es_de_tiempo(self, planeado: EjercicioPlaneado) -> bool:
        """Si este ejercicio se mide en tiempo, según su ficha.

        SE MIRA LA FICHA Y NO `segundos_objetivo`. Es tentador decir "si tiene
        duración puesta es de tiempo", pero entonces un ejercicio de cardio
        recién añadido, todavía sin duración, aparecería con casillas de peso
        hasta que le pusieras una. La ficha lo sabe desde el primer momento.
        """
        for uno in self.pantalla.ejercicios:
            if uno.id == planeado.ejercicio_id:
                return uno.medida is Medida.TIEMPO
        # Un ejercicio borrado de la biblioteca no tiene ficha que consultar. Se
        # trata como de peso, que es lo que era la mayoría: cambiarle la forma a
        # un plan viejo sería peor que enseñar una columna de más.
        return False

    def _fila_de_tiempo(
        self, dia: DiaDeRutina, planeado: EjercicioPlaneado, indice: int
    ) -> list[ft.Control]:
        """La fila de un ejercicio que se mide en minutos.

        SERIES SE QUEDA, y no es un descuido: la plancha son tres series de
        cuarenta y cinco segundos con descanso entre medias. Para la cinta pones
        una serie y cero de descanso, y la fila dice justo lo que hay.
        """
        series = self._numero(str(planeado.series_objetivo), 66)
        series.on_blur = lambda _, c=series: self._guardar_numero(
            dia, planeado, "series_objetivo", c, 1, SERIES_MAXIMAS
        )

        duracion = self._numero(_duracion_escrita(planeado), 90)
        duracion.hint_text = "30 min"
        duracion.tooltip = (
            "Cuánto dura cada serie de este ejercicio.\n"
            "Vale escribirlo como quieras: 30min, 30:00, 45s, 1h30."
        )
        duracion.on_blur = lambda _, c=duracion: self._guardar_duracion(
            dia, planeado, c
        )

        return [
            ft.Text(planeado.nombre, size=estilo.TEXTO, color=self.paleta.ink),
            series,
            duracion,
            self._campo_descanso(dia, planeado),
            self._flechas(dia, planeado, indice),
        ]

    def _guardar_duracion(self, dia, planeado, control) -> None:
        escrito = (control.value or "").strip()
        segundos = parsear_duracion(escrito) if escrito else 0
        if segundos is None:
            control.value = _duracion_escrita(planeado)
            control.update()
            componentes.avisar(
                self.pagina,
                "No he entendido esa duración. Vale 30min, 30:00, 45s o 1h30.",
            )
            return
        self._cambiar(dia, replace(planeado, segundos_objetivo=segundos))

    def _numero(self, valor: str, ancho: int) -> ft.TextField:
        return componentes.campo_texto(self.paleta, "", valor=valor, ancho=ancho)

    # ------------------------------------------------------------------
    # Cambios
    # ------------------------------------------------------------------

    def _guardar_numero(
        self, dia, planeado, campo: str, control, minimo: int, maximo: int
    ) -> None:
        texto = (control.value or "").strip()
        if not texto.isdigit() or not minimo <= int(texto) <= maximo:
            # Se devuelve a lo que había y se avisa. NO se recorta al máximo por
            # las bravas: si escribes 300 series, quieres saber que no vale, no
            # encontrarte un 20 que no pusiste tú.
            control.value = str(getattr(planeado, campo))
            control.update()
            componentes.avisar(self.pagina, f"Ese número va de {minimo} a {maximo}.")
            return
        self._cambiar(dia, replace(planeado, **{campo: int(texto)}))

    def _guardar_peso(self, dia, planeado, control) -> None:
        peso = parsear_peso(control.value or "")
        if peso is None:
            control.value = texto_peso(planeado.peso_objetivo).removesuffix(" kg")
            control.update()
            componentes.avisar(self.pagina, "El peso no se entiende. Ejemplo: 62,5")
            return
        self._cambiar(dia, replace(planeado, peso_objetivo=peso))

    def _guardar_descanso(self, dia, planeado, control) -> None:
        """Lee el descanso escrito de cualquier manera y lo deja siempre igual.

        DEJAR EL CAMPO VACÍO BORRA EL DESCANSO PROPIO, y entonces vuelve a
        mandar el de la ficha del ejercicio. Es la forma de decir "para este me
        vale el de siempre" sin tener que acordarse de cuál era.
        """
        escrito = (control.value or "").strip()
        if not escrito:
            self._cambiar(dia, replace(planeado, descanso=None))
            return

        segundos = parsear_descanso(escrito)
        if segundos is None:
            control.value = _descanso_escrito(planeado)
            control.update()
            componentes.avisar(
                self.pagina,
                "No he entendido ese descanso. Vale 90, 1:30, 1.30, 1.3, 1m30 o 30s.",
            )
            return
        self._cambiar(dia, replace(planeado, descanso=segundos))

    def _cambiar(self, dia: DiaDeRutina, planeado: EjercicioPlaneado) -> None:
        ejercicios = tuple(
            planeado if uno.orden == planeado.orden else uno for uno in dia.ejercicios
        )
        self._guardar(replace(dia, ejercicios=ejercicios))

    def _mover(self, dia: DiaDeRutina, indice: int, arriba: bool) -> None:
        ordenados = tuple(sorted(dia.ejercicios, key=lambda uno: uno.orden))
        self._guardar(replace(dia, ejercicios=mover(ordenados, indice, arriba)))

    def _quitar(self, dia: DiaDeRutina, planeado: EjercicioPlaneado) -> None:
        quedan = tuple(
            uno
            for uno in sorted(dia.ejercicios, key=lambda x: x.orden)
            if uno.orden != planeado.orden
        )
        # Renumerar es obligatorio: sin ello, quitar el de en medio dejaría
        # huecos (0, 2, 3) y el siguiente añadido compartiría número con otro.
        self._guardar(replace(dia, ejercicios=renumerar(quedan)))

    def _anadir(self, dia: DiaDeRutina) -> None:
        dialogo_anadir_ejercicio.abrir(
            self.pagina,
            self.paleta,
            self.pantalla.ejercicios,
            lambda elegido, d=dia: self._anadido(d, elegido),
        )

    def _anadido(self, dia: DiaDeRutina, elegido) -> None:
        nuevo = EjercicioPlaneado(
            ejercicio_id=elegido.id,
            nombre=elegido.nombre,
            orden=len(dia.ejercicios),
            # EL DESCANSO DE LA FICHA COMO PUNTO DE PARTIDA, no como ley: se
            # copia aquí una vez y a partir de entonces manda lo que escribas en
            # esta fila. Empezar con el campo vacío obligaría a rellenar seis
            # descansos cada vez que montas un día.
            descanso=elegido.descanso,
            # Un punto de partida para los de tiempo, distinto segun lo que
            # sean: veinte minutos de cardio o cuarenta y cinco segundos de
            # plancha. Un cero se leeria como "no has puesto nada" y obligaria a
            # rellenarlo siempre; esto se cambia escribiendo encima.
            segundos_objetivo=(
                None
                if elegido.medida is not Medida.TIEMPO
                else (20 * 60 if elegido.grupo is Grupo.CARDIO else 45)
            ),
        )
        self._guardar(replace(dia, ejercicios=(*dia.ejercicios, nuevo)))

    def _marcar_descanso(self, dia: DiaDeRutina, es_descanso: bool) -> None:
        """Marcar un día como descanso VACÍA sus ejercicios.

        Lo exige el dominio, y con razón: un día de descanso con ejercicios
        dentro es un día del que nadie sabe si toca ir, y el calendario tendría
        que elegir por su cuenta qué pintar.
        """
        if es_descanso and dia.ejercicios:
            componentes.confirmar(
                self.paleta,
                self.pagina,
                titulo=f"{dia.nombre_del_dia} pasa a ser descanso",
                texto=(
                    f"Se quitan los {len(dia.ejercicios)} ejercicios que tenía "
                    "planeados. Los entrenos ya hechos no se tocan."
                ),
                al_aceptar=lambda _: self._vaciar(dia),
            )
            return
        self._guardar(replace(dia, es_descanso=es_descanso))

    def _vaciar(self, dia: DiaDeRutina) -> None:
        self.pagina.pop_dialog()
        self._guardar(replace(dia, es_descanso=True, ejercicios=()))

    def _guardar(self, dia: DiaDeRutina) -> None:
        with conectado() as conexion:
            repositorio_gimnasio.guardar_dia(conexion, dia)
        self.pantalla.refrescar()


def _duracion_escrita(planeado: EjercicioPlaneado) -> str:
    """La duracion para meter en el campo. Vacia si todavia no se ha elegido."""
    if planeado.segundos_objetivo is None:
        return ""
    return texto_duracion(planeado.segundos_objetivo)


def _descanso_escrito(planeado: EjercicioPlaneado) -> str:
    """El descanso para meter en el campo. Vacío si no se ha elegido ninguno.

    VACÍO Y NO "0:00": un campo con 0:00 diría que elegiste no descansar, y no
    es eso: es que todavía no lo has dicho y vale el de la ficha.
    """
    if planeado.descanso is None:
        return ""
    return texto_descanso(planeado.descanso)
