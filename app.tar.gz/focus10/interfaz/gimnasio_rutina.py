"""La rutina de la semana: la vista de RUTINA del gimnasio.

ES EL PLAN, y solo el plan. Aquí no se marca nada como hecho ni se apunta ningún
peso levantado: eso vive en la sesión y en otra tabla. Lo que se escribe aquí es
"los lunes toca esto, con estas series objetivo", y se repite cada semana hasta
que se cambie.

LOS DÍAS VIENEN PLEGADOS, y lo pidió el usuario: entrena todos los días, y con
los siete abiertos la pantalla se hacía kilométrica. Plegados, la semana entera
cabe de un vistazo y cada línea ya dice lo que necesita saberse —el nombre del
día y cuántos ejercicios tiene—; se abre el que se vaya a tocar.

CON FLECHAS Y NO CON ARRASTRE para ordenar, y lo eligió el usuario con estas
palabras: "prefiero flechas que funcionen a un arrastre que falle". Flet tiene
arrastre, pero dentro de una lista que se repinta entera con cada cambio es
frágil de un modo que no compensa para ganar un gesto.

EL DESCANSO LO ELIGE LA PERSONA, ejercicio por ejercicio, aquí. La ficha de la
biblioteca solo aporta el valor de partida al añadirlo; a partir de ahí manda lo
que se escriba en esta pantalla.

UN DÍA LLEVA VARIOS ENTRENAMIENTOS, y lo pidió el usuario así: "el lunes es un
apartado, no es SOLO un entrenamiento; dentro de Lunes debo poder poner
diferentes entrenamientos tipo GYM, Movilidad...". Cada uno es un BLOQUE con su
nombre, que se escribe libre.

Y CADA SERIE VA POR SEPARADO, con su peso y sus repeticiones: "las series pueden
ser distintas entre sí". Por eso un ejercicio ya no es una fila de tabla con un
"3 × 10", sino una fichita con una fila por serie debajo.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime

import flet as ft

from ..datos import repositorio_gimnasio
from ..datos.bd import conectado
from ..dominio.descanso import (
    parsear_descanso,
    parsear_duracion,
    texto_descanso,
    texto_duracion,
)
from ..dominio.ejercicio import Grupo, Medida
from ..dominio.habito import COLORES
from ..dominio.sesion import desde_rutina
from ..dominio.zona_musculo import zona_de
from ..dominio.rutina import (
    BLOQUES_MAXIMOS,
    REPETICIONES_MAXIMAS,
    SERIES_MAXIMAS,
    BloqueDeRutina,
    DiaDeRutina,
    EjercicioPlaneado,
    SeriePlaneada,
    con_bloque,
    con_bloques,
    con_ejercicios,
    dia_de,
    mover,
    parsear_peso,
    texto_peso,
)
from . import componentes, dialogo_anadir_ejercicio, dibujo_musculo, estilo


def vista(pantalla) -> list[ft.Control]:
    return _Vista(pantalla).piezas()


class _Vista:
    def __init__(self, pantalla) -> None:
        self.pantalla = pantalla
        self.paleta = pantalla.paleta
        self.pagina = pantalla.pagina
        # Qué días están abiertos. Vive en la pantalla y no aquí porque esta
        # clase se construye de nuevo en cada repintado: si viviera aquí, el día
        # que acabas de abrir se cerraría solo al escribir un número.
        if not hasattr(pantalla, "dias_abiertos"):
            pantalla.dias_abiertos = set()

    def piezas(self) -> list[ft.Control]:
        return [
            self._empezar_hoy(),
            ft.Row(
                [
                    ft.Text(
                        "Esto es el PLAN, y se repite cada semana. Lo que hagas "
                        "de verdad se apunta al entrenar y no cambia nada de aquí.",
                        size=estilo.TEXTO,
                        color=self.paleta.muted,
                        expand=True,
                    ),
                    componentes.boton(
                        self.paleta,
                        "Cerrar todos"
                        if self.pantalla.dias_abiertos
                        else "Abrir todos",
                        al_pulsar=lambda _: self._todos(),
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=16,
            ),
            *[self._tarjeta_dia(numero) for numero in range(7)],
        ]

    def _empezar_hoy(self) -> ft.Control:
        """Lo primero de la pantalla: qué toca hoy y el botón de arrancar.

        AQUÍ Y NO EN UNA PESTAÑA APARTE, que es lo que se pidió: estás mirando
        el plan, y empezar es lo siguiente que quieres hacer.

        EL BOTÓN CAMBIA SEGÚN CÓMO ESTÉS. Si ya arrancaste, pone «Seguir
        entrenando» y no «Empezar»: un segundo «Empezar» hace pensar que se
        borra lo que llevas hecho, y nadie lo pulsa.
        """
        hoy = self.pantalla.hoy
        planeado = dia_de(hoy, self.pantalla.rutina)
        with conectado() as conexion:
            sesion = repositorio_gimnasio.sesion_de(conexion, hoy)

        if sesion is not None and not sesion.en_marcha and sesion.segundos:
            texto = "Hoy ya entrenaste. Puedes volver a abrirlo si te dejaste algo."
            etiqueta = "Abrir el entreno de hoy"
        elif sesion is not None:
            texto = "Tienes un entreno a medias."
            etiqueta = "Seguir entrenando"
        elif planeado.es_descanso:
            texto = "Hoy toca descansar. Descansar también es entrenar."
            etiqueta = "Entrenar igualmente"
        elif not planeado.hay_entreno:
            texto = "Hoy no tiene nada asignado en el plan."
            etiqueta = "Empezar un entreno suelto"
        else:
            texto = (
                f"Hoy toca «{planeado.titulo()}», "
                f"{len(planeado.ejercicios)} ejercicios."
            )
            etiqueta = "Empezar entreno"

        return componentes.tarjeta(
            self.paleta,
            ft.Row(
                [
                    ft.Text(
                        texto,
                        size=estilo.TEXTO_TARJETA,
                        color=self.paleta.ink,
                        expand=True,
                    ),
                    componentes.boton(
                        self.paleta,
                        etiqueta,
                        icono=ft.Icons.PLAY_ARROW,
                        principal=True,
                        al_pulsar=lambda _: self._empezar(hoy, planeado, sesion),
                    ),
                ],
                spacing=16,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )

    def _empezar(self, hoy, planeado, sesion) -> None:
        """Crea la sesión del día COPIANDO la rutina. No al revés, nunca.

        UN ENTRENO YA EMPEZADO NO SE VUELVE A CREAR: se abre el que hay. Si se
        creara otro se perderían las series ya marcadas, y eso a mitad de un
        entreno es imperdonable.

        Un entreno suelto —sin nada planeado— se crea vacío y se le añaden
        ejercicios a mano. Sirve para el día que apareces y haces otra cosa, que
        pasa, y que no debería obligarte a cambiar el plan de la semana.
        """
        if sesion is None:
            with conectado() as conexion:
                repositorio_gimnasio.guardar_sesion(
                    conexion,
                    replace(desde_rutina(planeado, hoy), empezada_en=datetime.now()),
                )
        if self.pantalla.al_entrenar is not None:
            self.pantalla.al_entrenar(hoy)

    def _todos(self) -> None:
        if self.pantalla.dias_abiertos:
            self.pantalla.dias_abiertos = set()
        else:
            self.pantalla.dias_abiertos = set(range(7))
        self.pantalla.refrescar()

    # ------------------------------------------------------------------
    # Un día
    # ------------------------------------------------------------------

    def _tarjeta_dia(self, numero: int) -> ft.Control:
        dia = self.pantalla.rutina.get(numero) or DiaDeRutina(dia=numero)
        abierto = numero in self.pantalla.dias_abiertos

        cuerpo: list[ft.Control] = [self._cabecera(dia, abierto)]
        if abierto:
            cuerpo.append(componentes.separador(self.paleta))
            cuerpo += self._detalle(dia)

        return componentes.tarjeta(
            self.paleta,
            ft.Column(cuerpo, spacing=14),
            relleno=16 if not abierto else estilo.RELLENO_TARJETA,
        )

    def _cabecera(self, dia: DiaDeRutina, abierto: bool) -> ft.Control:
        """La línea que se ve siempre. Tocarla abre o cierra el día.

        LLEVA EL RESUMEN DENTRO a propósito: un día plegado que solo dijera
        "lunes" obligaría a abrirlo para saber si hay algo. Con "Empuje · 4
        ejercicios" la semana se lee entera sin tocar nada.
        """
        if dia.es_descanso:
            resumen = "Descanso"
            tono = self.paleta.muted
        elif dia.ejercicios:
            cuantos = len(dia.ejercicios)
            resumen = f"{dia.titulo()} · {cuantos} ejercicio"
            resumen += "s" if cuantos != 1 else ""
            tono = self.paleta.ink_soft
        else:
            resumen = "Sin asignar"
            tono = self.paleta.muted

        return ft.Container(
            content=ft.Row(
                [
                    ft.Icon(
                        ft.Icons.EXPAND_MORE if abierto else ft.Icons.CHEVRON_RIGHT,
                        size=20,
                        color=self.paleta.muted,
                    ),
                    ft.Text(
                        dia.nombre_del_dia.capitalize(),
                        size=estilo.TEXTO_TARJETA,
                        weight=ft.FontWeight.W_600,
                        color=self.paleta.ink,
                        width=110,
                    ),
                    ft.Text(resumen, size=estilo.TEXTO, color=tono, expand=True),
                    self._punto_de_color(dia),
                ],
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            on_click=lambda _, n=dia.dia: self._alternar(n),
            ink=True,
            border_radius=10,
            padding=ft.Padding.symmetric(horizontal=6, vertical=4),
        )

    def _punto_de_color(self, dia: DiaDeRutina) -> ft.Control:
        """Un círculo con el color del día. Es lo que ata esta pantalla con el
        calendario, donde ese mismo color pinta la casilla."""
        if dia.es_descanso or not dia.ejercicios:
            return ft.Container(width=12, height=12)
        return ft.Container(
            width=12,
            height=12,
            bgcolor=estilo.color_de_habito(dia.color),
            border_radius=999,
        )

    def _alternar(self, numero: int) -> None:
        if numero in self.pantalla.dias_abiertos:
            self.pantalla.dias_abiertos.discard(numero)
        else:
            self.pantalla.dias_abiertos.add(numero)
        self.pantalla.refrescar()

    # ------------------------------------------------------------------
    # Lo de dentro
    # ------------------------------------------------------------------

    def _detalle(self, dia: DiaDeRutina) -> list[ft.Control]:
        nombre = componentes.campo_texto(
            self.paleta, "Nombre del día", valor=dia.nombre, ancho=220
        )
        nombre.on_blur = lambda _, d=dia, c=nombre: self._guardar(
            replace(d, nombre=(c.value or "").strip())
        )

        piezas: list[ft.Control] = [
            ft.Row(
                [
                    nombre,
                    self._selector_color(dia),
                    ft.Container(expand=True),
                    componentes.interruptor(
                        self.paleta,
                        "Descanso",
                        valor=dia.es_descanso,
                        al_cambiar=lambda e, d=dia: self._marcar_descanso(
                            d, e.control.value
                        ),
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=12,
            )
        ]

        if dia.es_descanso:
            piezas.append(
                ft.Text(
                    "Día de descanso. Descansar también es entrenar.",
                    size=estilo.TEXTO,
                    color=self.paleta.muted,
                )
            )
            return piezas

        if not dia.bloques:
            piezas.append(
                componentes.aviso_vacio(
                    self.paleta, "Este día no tiene nada asignado todavía."
                )
            )
        for bloque in dia.bloques:
            piezas.append(self._tarjeta_bloque(dia, bloque))

        if len(dia.bloques) < BLOQUES_MAXIMOS:
            piezas.append(
                componentes.boton(
                    self.paleta,
                    "Añadir entrenamiento",
                    icono=ft.Icons.ADD,
                    al_pulsar=lambda _, d=dia: self._anadir_bloque(d),
                )
            )
        return piezas

    def _selector_color(self, dia: DiaDeRutina) -> ft.Control:
        selector = componentes.selector(
            self.paleta,
            "Color",
            [(uno, uno.capitalize()) for uno in COLORES],
            valor=dia.color,
            ancho=150,
        )
        selector.on_select = lambda e, d=dia, s=selector: self._guardar(
            replace(d, color=s.value or d.color)
        )
        return selector

    # ------------------------------------------------------------------
    # Un entrenamiento del día
    # ------------------------------------------------------------------

    def _tarjeta_bloque(self, dia: DiaDeRutina, bloque: BloqueDeRutina) -> ft.Control:
        """Un entrenamiento con su nombre y sus ejercicios dentro.

        LA CAJA NO ES ADORNO: con dos entrenamientos seguidos y sin nada que los
        separe, no se sabe dónde acaba GYM y empieza Movilidad, y el botón de
        añadir ejercicio no dice a cuál de los dos va.
        """
        nombre = componentes.campo_texto(
            self.paleta, "Entrenamiento", valor=bloque.nombre, ancho=220
        )
        nombre.on_blur = lambda _, b=bloque, c=nombre: self._renombrar_bloque(
            dia, b, c
        )

        dentro: list[ft.Control] = [
            ft.Row(
                [
                    nombre,
                    ft.Container(expand=True),
                    componentes.boton_icono(
                        self.paleta,
                        ft.Icons.DELETE_OUTLINE,
                        ayuda="Quitar este entrenamiento",
                        al_pulsar=lambda _, b=bloque: self._quitar_bloque(dia, b),
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=8,
            )
        ]

        ordenados = sorted(bloque.ejercicios, key=lambda uno: uno.orden)
        if not ordenados:
            dentro.append(
                componentes.aviso_vacio(
                    self.paleta, "Este entrenamiento está vacío."
                )
            )
        for indice, planeado in enumerate(ordenados):
            dentro.append(self._tarjeta_ejercicio(dia, bloque, planeado, indice))

        dentro.append(
            componentes.boton(
                self.paleta,
                "Añadir ejercicio",
                icono=ft.Icons.ADD,
                al_pulsar=lambda _, b=bloque: self._anadir(dia, b),
            )
        )
        return ft.Container(
            content=ft.Column(dentro, spacing=10),
            padding=12,
            border=ft.Border.all(1, self.paleta.borde),
            border_radius=estilo.RADIO_TARJETA,
            margin=ft.Margin.only(bottom=10),
        )

    # ------------------------------------------------------------------
    # Un ejercicio, con una fila por serie
    # ------------------------------------------------------------------

    def _tarjeta_ejercicio(
        self,
        dia: DiaDeRutina,
        bloque: BloqueDeRutina,
        planeado: EjercicioPlaneado,
        indice: int,
    ) -> ft.Control:
        """El ejercicio y SUS SERIES, una debajo de otra.

        ANTES ERA UNA FILA CON "3 × 10 a 60 kg" y no se podía escribir una
        pirámide: el usuario pidió "serie 1 × reps × kg, serie 2 × reps × kg".
        Ahora cada serie es su propia fila y se edita sola.
        """
        de_tiempo = self._es_de_tiempo(planeado)
        cabecera = ft.Row(
            [
                self._dibujo(planeado),
                ft.Text(
                    planeado.nombre,
                    size=estilo.TEXTO,
                    weight=ft.FontWeight.W_600,
                    color=self.paleta.ink,
                    expand=True,
                ),
                ft.Text("Descanso", size=estilo.TEXTO_APOYO, color=self.paleta.muted),
                self._campo_descanso(dia, bloque, planeado),
                self._flechas(dia, bloque, planeado, indice),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=8,
        )

        if de_tiempo:
            columnas = [("SERIE", 70), ("DURACIÓN", 110), ("", 52)]
        else:
            columnas = [("SERIE", 70), ("KG", 96), ("REPS", 84), ("", 52)]

        filas = [
            self._fila_serie(dia, bloque, planeado, una, de_tiempo)
            for una in planeado.series
        ]
        piezas: list[ft.Control] = [cabecera]
        if filas:
            piezas.append(componentes.tabla(self.paleta, columnas, filas))
        if len(planeado.series) < SERIES_MAXIMAS:
            piezas.append(
                componentes.boton(
                    self.paleta,
                    "Añadir serie",
                    icono=ft.Icons.ADD,
                    al_pulsar=lambda _, p=planeado: self._anadir_serie(dia, bloque, p),
                )
            )
        return ft.Container(
            content=ft.Column(piezas, spacing=6),
            padding=ft.Padding.symmetric(vertical=8),
        )

    def _fila_serie(
        self,
        dia: DiaDeRutina,
        bloque: BloqueDeRutina,
        planeado: EjercicioPlaneado,
        serie: SeriePlaneada,
        de_tiempo: bool,
    ) -> list[ft.Control]:
        etiqueta = ft.Text(
            str(serie.numero), size=estilo.TEXTO, color=self.paleta.ink_soft
        )
        quitar = componentes.boton_icono(
            self.paleta,
            ft.Icons.CLOSE,
            ayuda="Quitar esta serie",
            al_pulsar=lambda _, s=serie: self._quitar_serie(dia, bloque, planeado, s),
        )

        if de_tiempo:
            duracion = self._numero(_duracion_de(serie), 96)
            duracion.hint_text = "0:45"
            duracion.tooltip = (
                "Cuánto dura esta serie.\n"
                "Vale escribirlo como quieras: 30min, 30:00, 45s, 1h30."
            )
            duracion.on_blur = lambda _, c=duracion, s=serie: self._guardar_duracion(
                dia, bloque, planeado, s, c
            )
            return [etiqueta, duracion, quitar]

        peso = self._numero(texto_peso(serie.peso).removesuffix(" kg"), 82)
        peso.on_blur = lambda _, c=peso, s=serie: self._guardar_peso(
            dia, bloque, planeado, s, c
        )
        reps = self._numero(str(serie.repeticiones), 70)
        reps.on_blur = lambda _, c=reps, s=serie: self._guardar_repeticiones(
            dia, bloque, planeado, s, c
        )
        return [etiqueta, peso, reps, quitar]

    def _campo_descanso(self, dia, bloque, planeado) -> ft.TextField:
        campo = self._numero(_descanso_escrito(planeado), 90)
        campo.hint_text = "1:30"
        campo.tooltip = (
            "Cuánto descansas entre series de ESTE ejercicio.\n"
            "Vale escribirlo como quieras: 90, 1:30, 1.30, 1.3, 1m30, 30s."
        )
        campo.on_blur = lambda _, c=campo: self._guardar_descanso(
            dia, bloque, planeado, c
        )
        return campo

    def _flechas(self, dia, bloque, planeado, indice: int) -> ft.Control:
        return ft.Row(
            [
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.ARROW_UPWARD,
                    ayuda="Subir",
                    al_pulsar=lambda _, i=indice: self._mover(dia, bloque, i, True),
                ),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.ARROW_DOWNWARD,
                    ayuda="Bajar",
                    al_pulsar=lambda _, i=indice: self._mover(dia, bloque, i, False),
                ),
                componentes.boton_icono(
                    self.paleta,
                    ft.Icons.DELETE_OUTLINE,
                    ayuda="Quitar del entrenamiento",
                    al_pulsar=lambda _, p=planeado: self._quitar(dia, bloque, p),
                ),
            ],
            spacing=0,
            tight=True,
        )

    def _ficha(self, planeado: EjercicioPlaneado):
        """La ficha de la biblioteca de ese ejercicio, o None si ya no está.

        DEVUELVE None Y NO UNA FICHA INVENTADA: un ejercicio borrado de la
        biblioteca no tiene grupo que enseñar, y dibujarle uno cualquiera sería
        decir que trabaja algo que no se sabe.
        """
        for uno in self.pantalla.ejercicios:
            if uno.id == planeado.ejercicio_id:
                return uno
        return None

    def _es_de_tiempo(self, planeado: EjercicioPlaneado) -> bool:
        """Si este ejercicio se mide en tiempo, según su ficha.

        SE MIRA LA FICHA Y NO los segundos de las series. Es tentador decir "si
        tiene duración puesta es de tiempo", pero entonces un ejercicio de
        cardio recién añadido, todavía sin duración, aparecería con casillas de
        peso hasta que le pusieras una. La ficha lo sabe desde el primer momento.
        """
        ficha = self._ficha(planeado)
        # Un ejercicio borrado de la biblioteca no tiene ficha que consultar. Se
        # trata como de peso, que es lo que era la mayoría: cambiarle la forma a
        # un plan viejo sería peor que enseñar una columna de más.
        return ficha is not None and ficha.medida is Medida.TIEMPO

    def _dibujo(self, planeado: EjercicioPlaneado) -> ft.Control:
        """La silueta con el músculo que trabaja, o un hueco de su tamaño.

        EL HUECO ES A PROPÓSITO: un ejercicio que ya no está en la biblioteca no
        tiene grupo, y sin el hueco su fila se desplazaría a la izquierda y las
        demás dejarían de estar alineadas.
        """
        ficha = self._ficha(planeado)
        if ficha is None:
            return ft.Container(width=dibujo_musculo.ANCHO_EN_FILA)
        return dibujo_musculo.silueta(
            self.paleta,
            ficha.grupo,
            secundarios=ficha.secundarios,
            zona=zona_de(ficha.nombre, ficha.grupo),
            alto=dibujo_musculo.ALTO_EN_FILA,
        )

    def _numero(self, valor: str, ancho: int) -> ft.TextField:
        return componentes.campo_texto(self.paleta, "", valor=valor, ancho=ancho)

    # ------------------------------------------------------------------
    # Cambios en una serie
    # ------------------------------------------------------------------

    def _cambiar_serie(
        self, dia, bloque, planeado, serie, nueva: SeriePlaneada
    ) -> None:
        series = tuple(
            nueva if una.numero == serie.numero else una for una in planeado.series
        )
        self._cambiar(dia, bloque, replace(planeado, series=series))

    def _guardar_repeticiones(self, dia, bloque, planeado, serie, control) -> None:
        texto = (control.value or "").strip()
        if not texto.isdigit() or not 0 <= int(texto) <= REPETICIONES_MAXIMAS:
            # Se devuelve a lo que había y se avisa. NO se recorta al máximo por
            # las bravas: si escribes 900 repeticiones, quieres saber que no
            # vale, no encontrarte un 500 que no pusiste tú.
            control.value = str(serie.repeticiones)
            control.update()
            componentes.avisar(
                self.pagina, f"Las repeticiones van de 0 a {REPETICIONES_MAXIMAS}."
            )
            return
        self._cambiar_serie(
            dia, bloque, planeado, serie, replace(serie, repeticiones=int(texto))
        )

    def _guardar_peso(self, dia, bloque, planeado, serie, control) -> None:
        peso = parsear_peso(control.value or "")
        if peso is None:
            control.value = texto_peso(serie.peso).removesuffix(" kg")
            control.update()
            componentes.avisar(self.pagina, "El peso no se entiende. Ejemplo: 62,5")
            return
        self._cambiar_serie(dia, bloque, planeado, serie, replace(serie, peso=peso))

    def _guardar_duracion(self, dia, bloque, planeado, serie, control) -> None:
        escrito = (control.value or "").strip()
        segundos = parsear_duracion(escrito) if escrito else 0
        if segundos is None:
            control.value = _duracion_de(serie)
            control.update()
            componentes.avisar(
                self.pagina,
                "No he entendido esa duración. Vale 30min, 30:00, 45s o 1h30.",
            )
            return
        self._cambiar_serie(
            dia, bloque, planeado, serie, replace(serie, segundos=segundos)
        )

    def _anadir_serie(self, dia, bloque, planeado) -> None:
        """Una serie más, copiada de la última.

        SE COPIA LA ÚLTIMA Y NO SE PONE A CERO: quien añade la cuarta serie casi
        siempre quiere lo mismo que la tercera, y si no, escribe encima. Empezar
        a cero obliga a rellenar dos casillas cada vez.
        """
        ultima = planeado.series[-1] if planeado.series else SeriePlaneada(1)
        nueva = replace(ultima, numero=len(planeado.series) + 1, id=None)
        self._cambiar(dia, bloque, replace(planeado, series=(*planeado.series, nueva)))

    def _quitar_serie(self, dia, bloque, planeado, serie) -> None:
        if len(planeado.series) <= 1:
            # UN EJERCICIO SIN NINGUNA SERIE no querría decir nada: para no
            # hacerlo, se quita el ejercicio entero.
            componentes.avisar(
                self.pagina,
                "Es la única serie. Para quitarla, quita el ejercicio entero.",
            )
            return
        quedan = tuple(una for una in planeado.series if una.numero != serie.numero)
        self._cambiar(dia, bloque, replace(planeado, series=quedan))

    def _guardar_descanso(self, dia, bloque, planeado, control) -> None:
        """Lee el descanso escrito de cualquier manera y lo deja siempre igual.

        DEJAR EL CAMPO VACÍO BORRA EL DESCANSO PROPIO, y entonces vuelve a
        mandar el de la ficha del ejercicio. Es la forma de decir "para este me
        vale el de siempre" sin tener que acordarse de cuál era.
        """
        escrito = (control.value or "").strip()
        if not escrito:
            self._cambiar(dia, bloque, replace(planeado, descanso=None))
            return

        segundos = parsear_descanso(escrito)
        if segundos is None:
            control.value = _descanso_escrito(planeado)
            control.update()
            componentes.avisar(
                self.pagina,
                "No he entendido ese descanso. Vale 90, 1:30, 1.30, 1.3, 1m30 o 30s.",
            )
            return
        self._cambiar(dia, bloque, replace(planeado, descanso=segundos))

    # ------------------------------------------------------------------
    # Cambios en un ejercicio y en un bloque
    # ------------------------------------------------------------------

    def _cambiar(
        self, dia: DiaDeRutina, bloque: BloqueDeRutina, planeado: EjercicioPlaneado
    ) -> None:
        ejercicios = tuple(
            planeado if uno.orden == planeado.orden else uno
            for uno in bloque.ejercicios
        )
        self._guardar(con_bloque(dia, bloque, con_ejercicios(bloque, ejercicios)))

    def _mover(self, dia, bloque, indice: int, arriba: bool) -> None:
        ordenados = tuple(sorted(bloque.ejercicios, key=lambda uno: uno.orden))
        self._guardar(
            con_bloque(
                dia, bloque, con_ejercicios(bloque, mover(ordenados, indice, arriba))
            )
        )

    def _quitar(self, dia, bloque, planeado) -> None:
        quedan = tuple(
            uno
            for uno in sorted(bloque.ejercicios, key=lambda x: x.orden)
            if uno.orden != planeado.orden
        )
        self._guardar(con_bloque(dia, bloque, con_ejercicios(bloque, quedan)))

    def _anadir(self, dia: DiaDeRutina, bloque: BloqueDeRutina) -> None:
        dialogo_anadir_ejercicio.abrir(
            self.pagina,
            self.paleta,
            self.pantalla.ejercicios,
            lambda elegido, d=dia, b=bloque: self._anadido(d, b, elegido),
        )

    def _anadido(self, dia: DiaDeRutina, bloque: BloqueDeRutina, elegido) -> None:
        de_tiempo = elegido.medida is Medida.TIEMPO
        # Un punto de partida para los de tiempo, distinto segun lo que sean:
        # veinte minutos de cardio o cuarenta y cinco segundos de plancha. Un
        # cero se leeria como "no has puesto nada" y obligaria a rellenarlo
        # siempre; esto se cambia escribiendo encima.
        segundos = (
            None
            if not de_tiempo
            else (20 * 60 if elegido.grupo is Grupo.CARDIO else 45)
        )
        nuevo = EjercicioPlaneado(
            ejercicio_id=elegido.id,
            nombre=elegido.nombre,
            orden=len(bloque.ejercicios),
            # EL DESCANSO DE LA FICHA COMO PUNTO DE PARTIDA, no como ley: se
            # copia aquí una vez y a partir de entonces manda lo que escribas en
            # esta ficha. Empezar con el campo vacío obligaría a rellenar seis
            # descansos cada vez que montas un día.
            descanso=elegido.descanso,
            # TRES SERIES IGUALES PARA EMPEZAR, que es lo que hace casi todo el
            # mundo; a partir de ahí se cambian una a una o se añaden más.
            series=tuple(
                SeriePlaneada(numero=cual, repeticiones=10, segundos=segundos)
                for cual in range(1, 4)
            ),
        )
        self._guardar(
            con_bloque(
                dia, bloque, con_ejercicios(bloque, (*bloque.ejercicios, nuevo))
            )
        )

    def _anadir_bloque(self, dia: DiaDeRutina) -> None:
        self._guardar(
            con_bloques(dia, (*dia.bloques, BloqueDeRutina(orden=len(dia.bloques))))
        )

    def _renombrar_bloque(self, dia, bloque, control) -> None:
        escrito = (control.value or "").strip()
        if escrito == bloque.nombre:
            return
        self._guardar(con_bloque(dia, bloque, replace(bloque, nombre=escrito)))

    def _quitar_bloque(self, dia: DiaDeRutina, bloque: BloqueDeRutina) -> None:
        """Quitar un entrenamiento se lleva sus ejercicios, así que se pregunta.

        SOLO SI TIENE ALGO DENTRO: preguntar por un bloque vacío sería un clic
        de más para no proteger nada.
        """
        if bloque.ejercicios:
            componentes.confirmar(
                self.paleta,
                self.pagina,
                titulo=f"Quitar «{bloque.nombre}»",
                texto=(
                    f"Se quitan los {len(bloque.ejercicios)} ejercicios que "
                    "tenía planeados. Los entrenos ya hechos no se tocan."
                ),
                al_aceptar=lambda _: self._quitar_bloque_ya(dia, bloque),
            )
            return
        self._quitar_bloque_ya(dia, bloque, cerrar=False)

    def _quitar_bloque_ya(self, dia, bloque, cerrar: bool = True) -> None:
        if cerrar:
            self.pagina.pop_dialog()
        quedan = tuple(uno for uno in dia.bloques if uno.orden != bloque.orden)
        self._guardar(con_bloques(dia, quedan))

    def _marcar_descanso(self, dia: DiaDeRutina, es_descanso: bool) -> None:
        """Marcar un día como descanso VACÍA sus entrenamientos.

        Lo exige el dominio, y con razón: un día de descanso con ejercicios
        dentro es un día del que nadie sabe si toca ir, y el calendario tendría
        que elegir por su cuenta qué pintar.
        """
        if es_descanso and dia.ejercicios:
            componentes.confirmar(
                self.paleta,
                self.pagina,
                titulo=f"{dia.nombre_del_dia} pasa a ser descanso",
                texto=(
                    f"Se quitan los {len(dia.ejercicios)} ejercicios que tenía "
                    "planeados. Los entrenos ya hechos no se tocan."
                ),
                al_aceptar=lambda _: self._vaciar(dia),
            )
            return
        self._guardar(replace(dia, es_descanso=es_descanso))

    def _vaciar(self, dia: DiaDeRutina) -> None:
        self.pagina.pop_dialog()
        self._guardar(replace(con_bloques(dia, ()), es_descanso=True))

    def _guardar(self, dia: DiaDeRutina) -> None:
        with conectado() as conexion:
            repositorio_gimnasio.guardar_dia(conexion, dia)
        self.pantalla.refrescar()


def _duracion_de(serie: SeriePlaneada) -> str:
    """La duracion para meter en el campo. Vacia si todavia no se ha elegido."""
    if serie.segundos is None:
        return ""
    return texto_duracion(serie.segundos)


def _descanso_escrito(planeado: EjercicioPlaneado) -> str:
    """El descanso para meter en el campo. Vacío si no se ha elegido ninguno.

    VACÍO Y NO "0:00": un campo con 0:00 diría que elegiste no descansar, y no
    es eso: es que todavía no lo has dicho y vale el de la ficha.
    """
    if planeado.descanso is None:
        return ""
    return texto_descanso(planeado.descanso)
