"""El cartel de «¡Medalla nueva!», con la opción de compartirla como imagen.

SALE UNA VEZ POR MEDALLA (ver datos/medallas.py, marcar_vistas) y enseña la
mayor de las nuevas. Compartir es opcional: arma la imagen para Instagram o
WhatsApp (imagen_logro.py). Publicarla en la Comunidad ya no existe: desde el
8 nov 2026 la Comunidad es solo el ranking.
"""

from __future__ import annotations

import flet as ft

from ..dominio import logros
from ..dominio.logros import Medalla
from . import estilo, imagen_logro, medalla_vista
from .estilo import Paleta


def abrir(pagina: ft.Page, paleta: Paleta, nuevas: list[Medalla]) -> None:
    """`nuevas` viene de mayor a menor."""
    mayor = nuevas[0]
    demas = len(nuevas) - 1

    renglones: list[ft.Control] = [
        medalla_vista.medalla(paleta, mayor.dias, mayor.habito),
        ft.Text(
            f"{mayor.dias} días seguidos de «{mayor.habito}».",
            size=estilo.TEXTO,
            color=paleta.ink,
            text_align=ft.TextAlign.CENTER,
        ),
    ]
    if demas:
        renglones.append(
            ft.Text(
                f"Y {demas} medalla{'s' if demas > 1 else ''} más.",
                size=estilo.TEXTO_APOYO,
                color=paleta.muted,
                text_align=ft.TextAlign.CENTER,
            )
        )

    def fuera(_):
        pagina.pop_dialog()
        imagen_logro.abrir(pagina, paleta, "medalla", logros.tarjeta_medalla(mayor))

    pagina.show_dialog(
        ft.AlertDialog(
            modal=True,
            title=ft.Text("¡Medalla nueva!", size=16, weight=ft.FontWeight.W_600,
                          text_align=ft.TextAlign.CENTER),
            content=ft.Column(
                renglones,
                spacing=12,
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            actions=[
                ft.TextButton("Genial", on_click=lambda _: pagina.pop_dialog()),
                ft.TextButton("Instagram, WhatsApp…", on_click=fuera),
            ],
            actions_alignment=ft.MainAxisAlignment.CENTER,
        )
    )
