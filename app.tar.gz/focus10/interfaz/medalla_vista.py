"""Cómo se dibuja una medalla de racha: el disco de su metal con el hito dentro.

LA USAN EL CARTEL DE «¡MEDALLA NUEVA!» Y LA IMAGEN PARA COMPARTIR. Antes vivía
con la Comunidad vieja (la red social), que se borró el 8 nov 2026.
"""

from __future__ import annotations

import flet as ft

from ..dominio import logros
from . import estilo
from .estilo import Paleta

LADO_MEDALLA = 56


def _abreviado(dias: int) -> str:
    """Lo que va DENTRO de la medalla: «7d», «1m», «3m», «1a»."""
    if dias < logros.UN_MES:
        return f"{dias}d"
    meses = dias // logros.UN_MES
    if meses % 12 == 0:
        return f"{meses // 12}a"
    return f"{meses}m"


def medalla(
    paleta: Paleta, dias: int, habito: str, *, lado: int = LADO_MEDALLA
) -> ft.Control:
    """Una medalla: el disco de su metal con el hito dentro, y el hábito debajo.

    EL METAL NO DEPENDE DEL TEMA, a propósito: el bronce es bronce en cualquier
    pantalla, como una medalla de verdad. Sube con la racha (bronce, plata,
    oro, platino, diamante), así se ve de lejos cuál costó más. Ver
    dominio/logros.NIVELES.
    """
    metal = logros.nivel_del_hito(dias)
    color = estilo.METALES[metal]
    return ft.Column(
        [
            ft.Container(
                content=ft.Text(
                    _abreviado(dias),
                    size=round(lado * 0.27),
                    weight=ft.FontWeight.W_700,
                    color=estilo.TINTA_MEDALLA,
                ),
                width=lado,
                height=lado,
                border_radius=lado,
                bgcolor=color,
                border=ft.Border.all(max(3, lado // 18), estilo.BRILLO_MEDALLA),
                alignment=ft.Alignment.CENTER,
                tooltip=f"{logros.nombre_del_hito(dias)} · {habito} ({metal})",
            ),
            ft.Text(
                habito,
                size=11,
                color=paleta.ink_soft,
                max_lines=1,
                overflow=ft.TextOverflow.ELLIPSIS,
                text_align=ft.TextAlign.CENTER,
                width=lado + 16,
            ),
        ],
        spacing=4,
        tight=True,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    )
