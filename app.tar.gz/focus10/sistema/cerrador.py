"""Cerrar los programas que distraen mientras dura la fase de trabajo.

ESTO NO NECESITA ADMINISTRADOR, y es una diferencia importante con el bloqueo de
webs: cerrar un programa que has abierto tú lo puede hacer tu propio usuario. Por
eso vive en el proceso normal y no en el guardián elevado. Cuanto menos haga el
proceso con permisos, mejor.

EN DOS TIEMPOS, como pidió el usuario:

  1. Se PIDE cerrar (taskkill sin más). Windows le manda al programa la misma
     señal que cuando pulsas la X: le da ocasión de guardar y despedirse.
  2. Si a los nueve segundos sigue ahí, se FUERZA (taskkill /F). Esto es tirar
     del cable: lo que no estuviera guardado se pierde, y por eso se avisa antes
     en la pantalla.

QUIÉN CONTESTA SI UN PROGRAMA SIGUE ABIERTO: tasklist, que solo lee. NO el código
que devuelve taskkill, y esto costó un fallo de verdad que encontró el test con
la cobaya. Los códigos de taskkill son tres y parecen dos:

    0    la señal se envió
    1    NO se pudo cerrar por las buenas; el programa SIGUE VIVO
    128  no existe ningún programa con ese nombre

Tratar el 1 y el 128 como "no estaba" —que es lo que hacía la primera versión—
significa que el programa que se resiste se da por cerrado y no se fuerza nunca,
que es justo el caso para el que existe el segundo tiempo.

LA COMPROBACIÓN DE PROTEGIDOS SE HACE OTRA VEZ AQUÍ. Ya se hizo al guardar la
regla, y se repite justo antes de cerrar nada. No sobra: entre que se guarda una
regla y se ejecuta pueden pasar semanas, y en medio puede haber una restauración
de la base de datos, una actualización o un archivo tocado a mano. Es la lección
de cuando un test se llevó por delante el explorer.exe.
"""

from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass

from ..dominio.procesos import filtrar_cerrables

SEGUNDOS_DE_CORTESIA = 9.0
"""Lo que se espera entre pedir y forzar. Nueve segundos: lo bastante para que un
programa guarde y se cierre, y lo bastante poco para no dejarte mirando la
pantalla al empezar un pomodoro."""

TIEMPO_MAXIMO = 20


@dataclass(frozen=True)
class Resultado:
    """Qué pasó con cada programa. Se enseña tal cual en la pantalla."""

    cerrados: tuple[str, ...] = ()
    """Se fueron por las buenas, guardando lo suyo."""

    forzados: tuple[str, ...] = ()
    """Hubo que tirarles del cable. Lo no guardado se perdió."""

    no_estaban: tuple[str, ...] = ()
    """No estaban abiertos. No es un fallo."""

    rechazados: tuple[str, ...] = ()
    """Protegidos que alguien había conseguido meter en la lista. Se enseñan
    porque significa que algo va mal en los datos, no que el usuario se
    equivocara al pulsar."""

    resistieron: tuple[str, ...] = ()
    """Ni por las buenas ni por las malas. Pasa con algún antivirus y con lo que
    corre como administrador. Se dice en vez de callarlo: un programa que crees
    cerrado y sigue abierto es peor que uno que sabes que no se cerró."""

    @property
    def hubo_perdida_posible(self) -> bool:
        return bool(self.forzados)

    def resumen(self) -> str:
        partes = []
        if self.cerrados:
            partes.append(f"{len(self.cerrados)} cerrados")
        if self.forzados:
            partes.append(f"{len(self.forzados)} forzados")
        if self.resistieron:
            partes.append(f"{len(self.resistieron)} no se dejaron cerrar")
        if self.no_estaban:
            partes.append(f"{len(self.no_estaban)} no estaban abiertos")
        return ", ".join(partes) if partes else "no había nada que cerrar"


def _ejecutar(argumentos: list[str]) -> tuple[int, str]:
    """Lanza un comando y devuelve (código, salida). Aparte para poder sustituirlo.

    Los tests le pasan una función falsa y comprueban QUÉ comandos se habrían
    lanzado. Así se puede demostrar que a explorer.exe no se le manda ni una
    orden, sin tener que cerrarlo para averiguarlo.
    """
    try:
        hecho = subprocess.run(
            argumentos,
            capture_output=True,
            text=True,
            timeout=TIEMPO_MAXIMO,
            # Sin ventana negra parpadeando al empezar cada pomodoro.
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return hecho.returncode, hecho.stdout
    except (OSError, subprocess.SubprocessError):
        # Que falle un comando no puede tumbar el pomodoro. Se devuelve una
        # salida vacía, que se lee como "no está corriendo": la postura prudente
        # es no forzar nada cuando no se sabe.
        return 1, ""


def esta_corriendo(nombre: str, ejecutar=_ejecutar) -> bool:
    """Si ese programa está abierto ahora mismo.

    Se pregunta con tasklist, que SOLO LEE. Es importante que sea así y no con
    taskkill: una primera versión preguntaba con «taskkill /FI» creyendo que
    consultaba, y taskkill con un filtro y sin /IM no consulta nada, MATA todo lo
    que encaje. Una función que se llama "está corriendo" no puede cerrar nada.
    """
    _, salida = ejecutar(
        ["tasklist", "/FI", f"IMAGENAME eq {nombre}.exe", "/NH", "/FO", "CSV"]
    )
    # Cuando no encuentra nada, tasklist contesta con una frase informativa en
    # vez de una lista, así que se busca el nombre en lo que devuelve.
    return f"{nombre}.exe".lower() in salida.lower()


def cerrar(
    nombres: list[str],
    *,
    espera: float = SEGUNDOS_DE_CORTESIA,
    ejecutar=_ejecutar,
    dormir=time.sleep,
) -> Resultado:
    """Cierra esos programas en dos tiempos y cuenta qué pasó con cada uno.

    `ejecutar` y `dormir` se reciben para poder probar esto sin cerrar nada de
    verdad y sin esperar nueve segundos por test.
    """
    # LA SEGUNDA COMPROBACIÓN. Todo lo que siga después de esta línea ya está
    # limpio; nada de lo rechazado llega a ninguna orden.
    cerrables, rechazados = filtrar_cerrables(nombres)

    presentes = [uno for uno in cerrables if esta_corriendo(uno, ejecutar)]
    no_estaban = [uno for uno in cerrables if uno not in presentes]

    if not presentes:
        return Resultado(no_estaban=tuple(no_estaban), rechazados=tuple(rechazados))

    for nombre in presentes:
        ejecutar(["taskkill", "/IM", f"{nombre}.exe"])

    # Se espera UNA vez para todos, no una vez por programa: con cinco programas
    # y nueve segundos cada uno, empezar a trabajar costaría tres cuartos de
    # minuto mirando una pantalla.
    dormir(espera)

    cerrados: list[str] = []
    forzados: list[str] = []
    resistieron: list[str] = []
    for nombre in presentes:
        if not esta_corriendo(nombre, ejecutar):
            cerrados.append(nombre)
            continue
        ejecutar(["taskkill", "/F", "/IM", f"{nombre}.exe"])
        if esta_corriendo(nombre, ejecutar):
            resistieron.append(nombre)
        else:
            forzados.append(nombre)

    return Resultado(
        cerrados=tuple(cerrados),
        forzados=tuple(forzados),
        no_estaban=tuple(no_estaban),
        rechazados=tuple(rechazados),
        resistieron=tuple(resistieron),
    )
