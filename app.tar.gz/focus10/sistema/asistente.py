"""Hablar con el asistente del servidor (servidor/api/asistente.py).

SOLO EL VIAJE: mandar la conversación y la memoria, y traer lo que entendió.
Qué se hace después lo decide dominio/asistente.py.
"""

from __future__ import annotations

import json

from ..dominio.asistente_tipos import Respuesta
from . import red
from .comentarios import DIRECCION as DIRECCION_COMENTARIOS

DIRECCION = DIRECCION_COMENTARIOS.rsplit("/", 1)[0] + "/asistente"
"""El mismo servidor de Vercel que los comentarios, otra puerta."""

SEGUNDOS_DE_ESPERA = 25
"""Claude tarda unos segundos en entender; con poco margen fallaría de más."""


class AsistenteNoDisponible(RuntimeError):
    """No se pudo hablar con el asistente. El mensaje dice por qué, en castellano."""


def preguntar(testigo: str, mensajes: list[dict], contexto: str, pedir=red.pedir) -> Respuesta:
    """Manda la conversación (en la forma de Claude) y el contexto que armó la
    app, y devuelve lo que contestó el asistente."""
    try:
        cuerpo = pedir(
            DIRECCION,
            metodo="POST",
            cabeceras={"Authorization": f"Bearer {testigo}"},
            cuerpo={"mensajes": mensajes, "contexto": contexto},
            segundos=SEGUNDOS_DE_ESPERA,
        )
    except red.Contesto as fallo:
        raise AsistenteNoDisponible(_motivo(fallo.code, fallo.read())) from fallo
    except red.NoLlego as fallo:
        raise AsistenteNoDisponible("No hay conexión. El asistente necesita internet.") from fallo
    try:
        return Respuesta.de_json(json.loads(cuerpo))
    except ValueError as fallo:
        raise AsistenteNoDisponible("El asistente contestó algo que no entiendo.") from fallo


def activado(pedir=red.pedir) -> bool | None:
    """Si el servidor tiene el asistente encendido (la llave de Claude puesta).

    NO CUESTA NADA: no llama a Claude ni gasta del tope.

    TRES RESPUESTAS Y NO DOS: True o False si el servidor contestó, y None si
    no se pudo preguntar (sin internet). Sin conexión no se sabe, y decir
    «no está activado» sería afirmar algo que no se comprobó.
    """
    try:
        return bool(json.loads(pedir(DIRECCION, segundos=10)).get("activado"))
    except red.NoLlego:
        return None
    except (red.Contesto, ValueError, AttributeError):
        # Contestó, pero sin esta puerta (todavía no se volvió a desplegar) o
        # con algo raro: no está activado.
        return False


def _motivo(codigo: int, cuerpo: bytes) -> str:
    """El error del servidor, dicho para una persona."""
    try:
        dicho = str(json.loads(cuerpo).get("error") or "")
    except (ValueError, AttributeError):
        dicho = ""
    if codigo == 401:
        return "Tu sesión no vale. Entrá de nuevo en Configuración → Tu cuenta."
    if codigo == 429:
        return f"Por hoy no puedo más: {dicho}. Mañana sigo." if dicho else "Llegaste al tope de hoy."
    if codigo in (404, 503):
        return "El asistente todavía no está activado en el servidor."
    return dicho.capitalize() if dicho else f"El servidor contestó {codigo}. Probá de nuevo."
