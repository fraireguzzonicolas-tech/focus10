"""Hablar con el servidor para subir y bajar cambios. Solo eso.

AQUÍ NO SE SABE QUÉ ES UN HÁBITO NI UNA BASE DE DATOS: entran y salen paquetes
(diccionarios). Lo que significan lo decide datos/sincronia.py. Así esta capa
no puede estropear un dato aunque quisiera, y la otra se prueba sin internet.

EL SERVIDOR ES EL MISMO DE LAS CUENTAS, con la misma dirección y la misma
clave pública (ver sistema/cuentas.py). Lo que abre la puerta a TUS datos es
el testigo de tu sesión: sin él, el servidor devuelve una lista vacía, porque
sus reglas solo enseñan a cada cuenta lo suyo (ver servidor/sincronizacion.sql).
"""

from __future__ import annotations

import json

from . import red
from .cuentas import CLAVE_PUBLICA, DIRECCION

POR_PAGINA = 1000
"""Cuántas filas se piden de una vez al bajar. Es el tope que Supabase da por
omisión: pedir más no daría más, solo haría creer que ya no quedan."""

SEGUNDOS_DE_ESPERA = 30


class SinConexion(RuntimeError):
    """No se pudo hablar con el servidor. Lo pendiente sigue esperando."""


class ServidorDijoQueNo(RuntimeError):
    """El servidor contestó, pero con un error: sesión caducada, regla, etc."""


def _pedir(metodo: str, camino: str, testigo: str, cuerpo=None):
    """La petición de verdad. Aparte para poder sustituirla en los tests.

    VA POR sistema/red.py, que en el navegador usa el propio navegador: con
    urllib, la sincronización no funcionaría en la web.
    """
    try:
        crudo = red.pedir(
            f"{DIRECCION.rstrip('/')}/rest/v1/{camino}",
            metodo=metodo,
            cabeceras={"apikey": CLAVE_PUBLICA, "Authorization": f"Bearer {testigo}"},
            cuerpo=cuerpo,
            segundos=SEGUNDOS_DE_ESPERA,
        )
        return json.loads(crudo) if crudo else None
    # EL ORDEN NO IMPORTA YA, PERO LA DISTINCIÓN SÍ: un «tu sesión caducó» no
    # puede contarse como «no hay internet», o se esperaría para siempre a una
    # red que ya funciona.
    except red.Contesto as fallo:
        raise ServidorDijoQueNo(f"{fallo.code}: {fallo.read()[:300]!r}") from fallo
    except red.NoLlego as fallo:
        raise SinConexion(str(fallo)) from fallo


def subir(testigo: str, paquetes: list[dict], pedir=_pedir) -> None:
    """Manda una tanda de cambios. El servidor se queda solo con los más nuevos."""
    if paquetes:
        pedir("POST", "rpc/subir", testigo, {"cambios": paquetes})


def bajar(testigo: str, desde: int, pedir=_pedir) -> list[dict]:
    """Todo lo que llegó al servidor después del número `desde`.

    SE BAJA TODO ANTES DE DEVOLVER NADA, página a página. Ver la regla 3 de
    datos/sincronia.py: aplicar a medias, en orden de llegada, pondría hijos
    antes que sus padres.
    """
    salida: list[dict] = []
    while True:
        pagina = pedir(
            "GET",
            "filas?select=tabla,uid,datos,borrado,cambiado_en,recibido"
            f"&recibido=gt.{desde}&order=recibido.asc&limit={POR_PAGINA}",
            testigo,
        ) or []
        salida += pagina
        if len(pagina) < POR_PAGINA:
            return salida
        desde = max(int(p["recibido"]) for p in pagina)


def hay_algo(testigo: str, pedir=_pedir) -> bool:
    """Si esta cuenta ya tiene datos en el servidor.

    ES LO QUE DECIDE, LA PRIMERA VEZ, QUIÉN MANDA: si no hay nada, este aparato
    es el que sube todo; si ya hay, es el que se vacía y lo baja.
    """
    return bool(pedir("GET", "filas?select=uid&limit=1", testigo))
