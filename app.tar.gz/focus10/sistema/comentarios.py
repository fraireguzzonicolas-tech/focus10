"""Mandar un comentario al servidor, que es quien envía el correo.

POR QUÉ HAY UN SERVIDOR EN MEDIO y no se manda el correo desde aquí: para enviar
un correo hace falta la contraseña de la cuenta, y una contraseña dentro de una
aplicación que se instala en el ordenador de otra gente NO ES UNA CONTRASEÑA:
cualquiera la saca del archivo y manda correos haciéndose pasar por ti. Con una
función en el servidor, la contraseña vive allí y la aplicación solo sabe la
dirección a la que hablar.

MIENTRAS NO HAYA DIRECCIÓN, ESTO NO FINGE. Sin `DIRECCION` puesta, enviar falla
con un mensaje que lo dice. Un botón que contesta "¡enviado!" sin haber enviado
nada es peor que no tener botón: te quedas esperando comentarios que nunca se
mandaron.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request

from ..dominio.comentario import Comentario

DIRECCION = "https://focus10-servidor.vercel.app/api/comentario"
"""La dirección de la función que manda el correo.

SE RELLENA CON UNA LÍNEA cuando esté desplegada en Vercel; algo como
"https://focus10.vercel.app/api/comentario". Va escrita aquí y no en los ajustes
porque es la misma para todos: es TU servidor, no una preferencia del usuario.
"""

SEGUNDOS_DE_ESPERA = 15
"""Más generoso que el del mercado: aquí la persona ya ha escrito y pulsado, y
que le digan "no se pudo" por tres segundos de lentitud da mucha más rabia."""


class NoSePudoEnviar(RuntimeError):
    """El comentario no ha llegado. Lo escrito no se ha perdido: sigue en pantalla."""


def _mandar(direccion: str, cuerpo: dict) -> None:
    """El POST de verdad. Aparte para poder sustituirlo en los tests.

    truststore hace que Python use los certificados de Windows, igual que en el
    mercado: sin esto, en esta máquina cualquier petición HTTPS falla porque algo
    del sistema mira el tráfico y lo vuelve a firmar.
    """
    try:
        import truststore

        truststore.inject_into_ssl()
    except ImportError:
        pass

    peticion = urllib.request.Request(
        direccion,
        data=json.dumps(cuerpo).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(peticion, timeout=SEGUNDOS_DE_ESPERA) as respuesta:
            if respuesta.status >= 300:
                raise NoSePudoEnviar(
                    f"el servidor ha contestado {respuesta.status}"
                )
    except urllib.error.HTTPError as fallo:
        raise NoSePudoEnviar(
            f"el servidor ha contestado {fallo.code}. Prueba dentro de un rato."
        ) from fallo
    except (urllib.error.URLError, TimeoutError, OSError) as fallo:
        raise NoSePudoEnviar(
            "no he podido conectar. Mira si tienes internet y prueba otra vez."
        ) from fallo


def enviar(comentario: Comentario, mandar=_mandar) -> None:
    """Manda el comentario. Si no llega, revienta con un motivo legible.

    NO DEVUELVE NADA: o llegó, o hay una excepción. Un booleano de "salió bien"
    se acaba ignorando en algún sitio y el usuario se queda sin saberlo.
    """
    if not DIRECCION:
        raise NoSePudoEnviar(
            "todavía no hay servidor al que mandarlo: falta poner DIRECCION en "
            "sistema/comentarios.py"
        )
    mandar(DIRECCION, comentario.como_json())
