"""Detectar el DNS seguro, que puede saltarse el bloqueo por archivo hosts.

EL PROBLEMA, en corto: el archivo hosts funciona porque Windows lo consulta antes
de preguntar por ahí fuera a qué número corresponde un nombre. El "DNS seguro"
(DoH, DNS over HTTPS) hace que el navegador pregunte por su cuenta, cifrado, a un
servidor de internet. Según el modo en que esté, ese atajo puede saltarse el
archivo hosts entero, y entonces el bloqueo no bloquea nada.

POR QUÉ ESTO EXISTE: lo pidió el usuario con estas palabras, "detéctalo y dímelo
en pantalla en vez de prometer un bloqueo que no se cumple". Es la misma regla
que gobierna toda la aplicación: si un dato no se sabe, se enseña el hueco y el
aviso, no un número inventado.

LO QUE ESTA PIEZA NO HACE: cambiar la configuración del navegador. Ni se plantea.
Tocar los ajustes de red de alguien por detrás para que una función nuestra
funcione mejor sería pasarse de largo. Aquí se mira y se avisa.

DESCONOCIDO NO ES "APAGADO". Cuando no se puede leer un navegador, se dice que no
se sabe. Callarlo y dar por hecho que está bien es exactamente lo que convierte
un bloqueo en una promesa falsa.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path


class Modo(StrEnum):
    APAGADO = "apagado"
    """No usa DNS seguro: el archivo hosts manda."""

    AUTOMATICO = "automático"
    """Lo usa si puede, pero cae al DNS normal cuando falla. Suele respetar el
    archivo hosts, pero no está garantizado."""

    ESTRICTO = "estricto"
    """Solo DNS seguro. Aquí el archivo hosts se puede saltar del todo."""

    DESCONOCIDO = "desconocido"
    """No se pudo averiguar. NO se da por apagado."""

    @property
    def es_riesgo(self) -> bool:
        """Si con este modo hay que avisar de que el bloqueo puede no cumplirse.

        DESCONOCIDO cuenta como riesgo a propósito: prometer un bloqueo que no
        se ha podido comprobar es peor que avisar de más.
        """
        return self in (Modo.ESTRICTO, Modo.DESCONOCIDO)


@dataclass(frozen=True)
class Hallazgo:
    navegador: str
    modo: Modo
    origen: str
    """De dónde salió el dato: "sus ajustes", "una política del sistema"... Se
    guarda porque no es lo mismo un ajuste que tú puedes cambiar que uno puesto
    por la empresa, y el consejo que se da es distinto."""


# ---------------------------------------------------------------------------
# Lectura: funciones puras, se les da el contenido y contestan
# ---------------------------------------------------------------------------

#: Lo que escriben Chrome y Edge en sus preferencias.
_MODOS_CHROME = {
    "off": Modo.APAGADO,
    "automatic": Modo.AUTOMATICO,
    "secure": Modo.ESTRICTO,
}

#: network.trr.mode de Firefox. El 1 ya no se usa; el 4 es "solo para medir".
_MODOS_FIREFOX = {
    0: Modo.APAGADO,
    1: Modo.AUTOMATICO,
    2: Modo.AUTOMATICO,
    3: Modo.ESTRICTO,
    4: Modo.APAGADO,
    5: Modo.APAGADO,
}


def modo_de_chrome(preferencias: str) -> Modo:
    """El modo que dicen las preferencias de Chrome o Edge (un JSON).

    Si la clave NO está, el navegador usa su valor de fábrica, que en Chrome y
    Edge es el automático. Se devuelve eso y no APAGADO: decir "apagado" cuando
    en realidad es "automático" sería tranquilizar sin motivo.
    """
    try:
        datos = json.loads(preferencias)
    except (ValueError, TypeError):
        return Modo.DESCONOCIDO
    if not isinstance(datos, dict):
        return Modo.DESCONOCIDO

    rincon = datos.get("dns_over_https")
    if not isinstance(rincon, dict):
        return Modo.AUTOMATICO  # sin poner: el de fábrica
    return _MODOS_CHROME.get(str(rincon.get("mode", "")).lower(), Modo.DESCONOCIDO)


def modo_de_firefox(prefs: str) -> Modo:
    """El modo que dice el prefs.js de Firefox.

    Se busca la última aparición de network.trr.mode: Firefox añade líneas al
    final del archivo, así que la última es la que vale. Con la primera, un
    ajuste cambiado hace meses seguiría mandando.
    """
    if not isinstance(prefs, str):
        return Modo.DESCONOCIDO

    valor: int | None = None
    for linea in prefs.splitlines():
        if "network.trr.mode" not in linea:
            continue
        trozo = linea.rsplit(",", 1)[-1].strip().rstrip(");").strip()
        if trozo.isdigit():
            valor = int(trozo)

    if valor is None:
        # Sin la clave, Firefox usa su valor de fábrica, que hoy es el
        # automático en buena parte del mundo. Se dice "automático", no
        # "apagado".
        return Modo.AUTOMATICO
    return _MODOS_FIREFOX.get(valor, Modo.DESCONOCIDO)


def modo_de_politica(valor: object) -> Modo:
    """El modo que impone una política del sistema (registro de Windows)."""
    if valor is None:
        return Modo.DESCONOCIDO
    return _MODOS_CHROME.get(str(valor).strip().lower(), Modo.DESCONOCIDO)


# ---------------------------------------------------------------------------
# Dónde mirar
# ---------------------------------------------------------------------------


def rutas_de_chrome(local: Path) -> list[tuple[str, Path]]:
    """Dónde guardan Chrome y Edge sus preferencias."""
    return [
        ("Chrome", local / "Google" / "Chrome" / "User Data" / "Default" / "Preferences"),
        ("Edge", local / "Microsoft" / "Edge" / "User Data" / "Default" / "Preferences"),
    ]


def rutas_de_firefox(roaming: Path) -> list[Path]:
    """Los prefs.js de todos los perfiles de Firefox que haya."""
    carpeta = roaming / "Mozilla" / "Firefox" / "Profiles"
    if not carpeta.is_dir():
        return []
    return sorted(carpeta.glob("*/prefs.js"))


def revisar(local: Path, roaming: Path) -> list[Hallazgo]:
    """Qué navegadores hay y en qué modo están.

    Los que no están instalados no salen: avisar de Firefox a quien no lo tiene
    es ruido, y el ruido hace que se dejen de leer los avisos que sí importan.
    """
    hallazgos: list[Hallazgo] = []

    for nombre, ruta in rutas_de_chrome(local):
        if not ruta.is_file():
            continue
        try:
            contenido = ruta.read_text(encoding="utf-8", errors="replace")
        except OSError:
            hallazgos.append(Hallazgo(nombre, Modo.DESCONOCIDO, "no se pudo leer"))
            continue
        hallazgos.append(Hallazgo(nombre, modo_de_chrome(contenido), "sus ajustes"))

    for ruta in rutas_de_firefox(roaming):
        try:
            contenido = ruta.read_text(encoding="utf-8", errors="replace")
        except OSError:
            hallazgos.append(Hallazgo("Firefox", Modo.DESCONOCIDO, "no se pudo leer"))
            continue
        hallazgos.append(Hallazgo("Firefox", modo_de_firefox(contenido), "sus ajustes"))

    return hallazgos


# ---------------------------------------------------------------------------
# Qué se le dice al usuario
# ---------------------------------------------------------------------------


def hay_riesgo(hallazgos: list[Hallazgo]) -> bool:
    return any(uno.modo.es_riesgo for uno in hallazgos)


def aviso(hallazgos: list[Hallazgo]) -> str:
    """El texto que se enseña, o cadena vacía si no hay nada que avisar.

    Se nombran los navegadores concretos en vez de soltar una advertencia
    genérica: "puede que no funcione" no le sirve a nadie; "en Firefox no va a
    funcionar" te dice qué hacer.
    """
    estrictos = [uno for uno in hallazgos if uno.modo is Modo.ESTRICTO]
    dudosos = [uno for uno in hallazgos if uno.modo is Modo.DESCONOCIDO]

    partes: list[str] = []
    if estrictos:
        cuales = ", ".join(uno.navegador for uno in estrictos)
        partes.append(
            f"{cuales} tiene el DNS seguro en modo estricto: ahí el bloqueo de "
            "webs NO se va a cumplir. Para que funcione hay que ponerlo en "
            "automático o apagarlo, en los ajustes de privacidad del navegador."
        )
    if dudosos:
        cuales = ", ".join(uno.navegador for uno in dudosos)
        partes.append(
            f"No he podido comprobar el DNS seguro de {cuales}, así que no puedo "
            "prometer que el bloqueo se cumpla ahí."
        )
    return " ".join(partes)
