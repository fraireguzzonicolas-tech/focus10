"""Subir y bajar las imágenes de la pizarra, para verlas en todos tus aparatos.

VAN AL ALMACÉN DE ARCHIVOS DEL MISMO SERVIDOR (Supabase Storage), no a la
tabla: una imagen no entra en una fila, y el almacén está hecho para esto.
Cada una vive en una carpeta con TU número de cuenta, y las reglas del
almacén (servidor/pizarra_imagenes.sql) solo dejan entrar a la tuya.

AQUÍ NO SE SABE QUÉ ES UNA PIZARRA: entra un nombre y unos bytes, y salen
igual. Qué subir y cuándo lo decide interfaz/pizarra_imagenes.py.
"""

from __future__ import annotations

import base64
import json

from . import red
from .cuentas import CLAVE_PUBLICA, DIRECCION

CUBETA = "pizarra"
"""Así se llama el lugar del almacén (lo crea servidor/pizarra_imagenes.sql)."""

SEGUNDOS_DE_ESPERA = 60
"""Más que para el resto: una foto del celular con mala señal tarda."""


class SinConexion(RuntimeError):
    """No se pudo hablar con el servidor. La imagen queda para después."""


class NoEsta(RuntimeError):
    """El servidor no la tiene (todavía no la subió el aparato que la pegó)."""


class ServidorDijoQueNo(RuntimeError):
    """El servidor contestó con un error: sesión caducada, falta el almacén…"""


def cuenta_de(testigo: str) -> str:
    """El número de tu cuenta, que va adentro del testigo de la sesión.

    NO SE COMPRUEBA LA FIRMA AQUÍ, y no hace falta: solo dice en qué carpeta
    buscar. Quien decide si entrás es el servidor, que sí la comprueba.
    """
    try:
        carga = testigo.split(".")[1]
        datos = json.loads(base64.urlsafe_b64decode(carga + "=" * (-len(carga) % 4)))
        cuenta = datos["sub"]
    except (IndexError, ValueError, KeyError, TypeError) as fallo:
        raise ServidorDijoQueNo("la sesión no dice de quién es") from fallo
    if not isinstance(cuenta, str) or not cuenta or "/" in cuenta or ".." in cuenta:
        raise ServidorDijoQueNo("la sesión no dice de quién es")
    return cuenta


def _pedir(metodo: str, camino: str, testigo: str, contenido: bytes | None = None) -> bytes:
    """La petición de verdad. Aparte para poder sustituirla en los tests."""
    cabeceras = {"apikey": CLAVE_PUBLICA, "Authorization": f"Bearer {testigo}"}
    if contenido is not None:
        cabeceras["Content-Type"] = "image/webp"
    try:
        return red.pedir(
            f"{DIRECCION.rstrip('/')}/storage/v1/{camino}",
            metodo=metodo, cabeceras=cabeceras, contenido=contenido, segundos=SEGUNDOS_DE_ESPERA,
        )
    except red.Contesto as fallo:
        cuerpo = fallo.read()[:300]
        # «YA ESTÁ» NO ES UN ERROR: el nombre es el contenido, así que si otro
        # aparato ya la subió, es la misma imagen.
        if fallo.code == 409 or b"Duplicate" in cuerpo or b"already exists" in cuerpo:
            return b""
        if fallo.code == 404 or b"not_found" in cuerpo or b"Object not found" in cuerpo:
            raise NoEsta(camino) from fallo
        raise ServidorDijoQueNo(f"{fallo.code}: {cuerpo!r}") from fallo
    except red.NoLlego as fallo:
        raise SinConexion(str(fallo)) from fallo


def subir(testigo: str, nombre: str, datos: bytes, pedir=_pedir) -> None:
    pedir("POST", f"object/{CUBETA}/{cuenta_de(testigo)}/{nombre}", testigo, datos)


def bajar(testigo: str, nombre: str, pedir=_pedir) -> bytes:
    # «authenticated»: la cubeta es privada, se baja con tu sesión.
    return pedir("GET", f"object/authenticated/{CUBETA}/{cuenta_de(testigo)}/{nombre}", testigo)
