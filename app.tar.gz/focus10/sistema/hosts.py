"""El archivo hosts de Windows: cómo se le mete y se le saca el bloqueo.

QUÉ ES EL ARCHIVO HOSTS: una lista que Windows consulta ANTES de preguntar a
internet a qué número corresponde un nombre. Si dice que "youtube.com" está en
0.0.0.0 —una dirección que no existe—, el navegador no llega a ninguna parte.

LO QUE MÁS IMPORTA AQUÍ: ese archivo es de Windows, no nuestro. Puede tener
líneas de un antivirus, de un programa de trabajo o puestas a mano hace años.
Perderlas sería un estropicio que ni se nota hasta semanas después. Por eso:

  1. Lo nuestro va SIEMPRE entre dos marcas, y solo se toca lo de dentro.
  2. Todo lo de fuera se devuelve carácter por carácter como estaba.
  3. Antes de escribir se guarda una copia del original.
  4. Se respetan los finales de línea del archivo (Windows usa CRLF).

LAS FUNCIONES DE TEXTO NO TOCAN EL DISCO. Reciben el contenido y devuelven el
contenido nuevo. Así todo lo delicado se prueba sin permisos de administrador y
sin poder estropear la máquina de nadie.
"""

from __future__ import annotations

import sys
import re
from pathlib import Path

from ..dominio.dominios import exigir_bloqueable, variantes_para_hosts

# LAS MARCAS SON ASCII PURO, sin acentos ni rayas largas. El hosts lo leen
# herramientas muy viejas de Windows y el .bat de rescate, y cualquiera de
# ellas puede escribirlo en una codificacion que destroce un caracter raro.
# Una marca destrozada es una marca que el rescate ya no encuentra, y el
# bloqueo se queda puesto para siempre. No merece la pena por una raya.
MARCA_INICIO = "# >>> FOCUS10 bloqueo temporal, no editar a mano"
MARCA_FIN = "# <<< FOCUS10 fin del bloqueo temporal"

DESTINO = "0.0.0.0"
"""A dónde se mandan los dominios bloqueados.

Se usa 0.0.0.0 y no 127.0.0.1 a propósito: 127.0.0.1 es tu propio ordenador, así
que si tienes algo escuchando ahí (un servidor de pruebas, por ejemplo) el
navegador se queda esperando y tarda en rendirse. 0.0.0.0 falla en el acto.
"""

RUTA_WINDOWS = r"C:\Windows\System32\drivers\etc\hosts"


def puede_bloquear() -> bool:
    """Si en este aparato se puede bloquear webs y cerrar programas de verdad.

    SOLO EN WINDOWS. El bloqueo escribe en el archivo hosts del sistema con
    permisos de administrador, y cerrar programas mata procesos: las dos cosas
    son del sistema operativo, no de la aplicación.

    ANTES SE PREGUNTABA "¿estoy en un navegador?", que daba la respuesta buena
    por casualidad: en el móvil se usaba la web. Con la aplicación de Android
    esa pregunta se vuelve MENTIRA —no es un navegador, y tampoco puede
    bloquear— y la pantalla ofrecería interruptores que no hacen nada. Un
    interruptor que se enciende y no bloquea es peor que no tenerlo: te hace
    creer que estás protegido.
    """
    return sys.platform == "win32"


def ruta_del_sistema() -> Path:
    """Dónde está el hosts de esta máquina.

    Se construye desde la variable de Windows en vez de escribir "C:\\Windows"
    a pelo, porque no todas las instalaciones están en C:.
    """
    import os

    raiz = os.environ.get("SystemRoot", r"C:\Windows")
    return Path(raiz) / "System32" / "drivers" / "etc" / "hosts"


# ---------------------------------------------------------------------------
# Texto: todo lo que decide QUÉ se escribe, sin tocar el disco
# ---------------------------------------------------------------------------


def bloque(dominios: list[str]) -> str:
    """El trozo que se le añade al hosts, marcas incluidas.

    CADA DOMINIO PASA POR exigir_bloqueable: es la tercera línea de defensa,
    después de la pantalla y de lo que se guardó. Si algo protegido llegara hasta
    aquí —por un archivo tocado a mano, por una versión vieja— revienta antes de
    escribir nada, en vez de bloquearte Google en silencio.
    """
    lineas = [MARCA_INICIO]
    vistos: set[str] = set()
    for dominio in dominios:
        limpio = exigir_bloqueable(dominio)
        for variante in variantes_para_hosts(limpio):
            if variante in vistos:
                continue
            vistos.add(variante)
            lineas.append(f"{DESTINO} {variante}")
    lineas.append(MARCA_FIN)
    return "\n".join(lineas)


def quitar_bloque(texto: str) -> str:
    """Devuelve el hosts sin nuestro trozo, dejando TODO lo demás intacto.

    Quita todos los bloques que encuentre, no solo el primero: si una caída dejó
    dos pegados, hay que limpiarlos los dos. Y si no hay ninguno, devuelve el
    texto tal cual, para que llamar a esto de más nunca estropee nada.
    """
    if not isinstance(texto, str):
        raise TypeError("el contenido del hosts tiene que ser texto")

    patron = re.compile(
        re.escape(MARCA_INICIO) + r".*?" + re.escape(MARCA_FIN) + r"[^\S\n\r]*\r?\n?",
        re.DOTALL,
    )
    # No se recorta NADA más. Una versión anterior hacía un rstrip de los saltos
    # del final "por limpieza", y se comía las líneas en blanco que el usuario
    # tuviera ahí: ida y vuelta, su hosts salía cambiado. Lo que no es nuestro no
    # se toca, ni siquiera para dejarlo más ordenado.
    return patron.sub("", texto)


def poner_bloque(texto: str, dominios: list[str]) -> str:
    """El hosts con nuestro bloqueo puesto al final.

    Primero quita cualquier bloque nuestro anterior: así llamar dos veces seguidas
    deja un solo bloque, y no diez pegados como pasaría si solo se añadiera.
    """
    salto = _final_de_linea(texto)
    base = quitar_bloque(texto)
    nuevo = bloque(dominios).replace("\n", salto)

    # Si el archivo no terminaba en salto de línea, se le pone uno: sin él, la
    # última línea del usuario y nuestra marca acabarían pegadas en la misma
    # línea, y esa línea suya dejaría de funcionar.
    if base and not base.endswith(("\n", "\r")):
        base += salto
    return base + nuevo + salto


def tiene_bloque(texto: str) -> bool:
    return MARCA_INICIO in texto


def dominios_bloqueados(texto: str) -> list[str]:
    """Los dominios que hay ahora mismo dentro de nuestro bloque.

    Sirve para comprobar de verdad qué está puesto, en vez de fiarse de lo que la
    aplicación cree que puso. Si alguien editó el archivo por debajo, aquí se ve.
    """
    dentro = re.search(
        re.escape(MARCA_INICIO) + r"(.*?)" + re.escape(MARCA_FIN), texto, re.DOTALL
    )
    if dentro is None:
        return []
    encontrados = []
    for linea in dentro.group(1).splitlines():
        partes = linea.split()
        if len(partes) == 2 and partes[0] == DESTINO:
            encontrados.append(partes[1])
    return encontrados


def _final_de_linea(texto: str) -> str:
    """El salto de línea que usa ese archivo.

    Windows escribe CRLF. Si escribiéramos LF, el Bloc de notas de toda la vida
    enseñaría el archivo entero en una sola línea gigante y parecería roto.
    Ante la duda —archivo vacío o de una sola línea— se usa el de Windows,
    porque este archivo es de Windows.
    """
    return "\n" if ("\r\n" not in texto and "\n" in texto) else "\r\n"


# ---------------------------------------------------------------------------
# Disco: lo mínimo, y siempre sobre una ruta que se recibe
# ---------------------------------------------------------------------------


def leer(ruta: Path) -> str:
    """El contenido del hosts.

    Se lee sin traducir los saltos de línea (newline="") para poder devolverlos
    exactamente como estaban. Con la traducción automática de Python, un archivo
    CRLF se leería como LF y se reescribiría cambiado de arriba abajo.
    """
    return ruta.read_text(encoding="utf-8", errors="replace", newline="")


def escribir(ruta: Path, contenido: str) -> None:
    """Escribe el hosts tal cual, sin que Python toque los saltos de línea."""
    ruta.write_text(contenido, encoding="utf-8", newline="")


def ruta_de_copia(carpeta: Path) -> Path:
    return carpeta / "hosts.original"


def guardar_copia(ruta_hosts: Path, carpeta: Path) -> Path:
    """Guarda el hosts original antes de tocarlo, si no había copia ya.

    SI YA HAY COPIA NO SE PISA, y es lo más importante de esta función: la copia
    buena es la del hosts SIN nuestro bloqueo. Si se sobrescribiera en cada
    sesión, la segunda vez guardaríamos un hosts que ya lleva el bloqueo dentro,
    y restaurar dejaría el bloqueo puesto para siempre.
    """
    carpeta.mkdir(parents=True, exist_ok=True)
    destino = ruta_de_copia(carpeta)
    if destino.exists():
        return destino
    escribir(destino, leer(ruta_hosts))
    return destino
