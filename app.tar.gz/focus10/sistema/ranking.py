"""Hablar con el ranking del servidor (servidor/api/ranking.py).

SOLO EL VIAJE: pedir la tabla, un perfil, anotarse o salirse. Los puntos NO
se calculan aquí ni en ninguna parte de la app: los calcula el servidor con lo
que cada uno sincroniza, para que nadie pueda «mandar» los suyos.
"""

from __future__ import annotations

import json

from . import red
from .comentarios import DIRECCION as DIRECCION_COMENTARIOS

DIRECCION = DIRECCION_COMENTARIOS.rsplit("/", 1)[0] + "/ranking"
"""El mismo servidor de Vercel que el asistente, otra puerta."""

SEGUNDOS_DE_ESPERA = 20


class RankingNoDisponible(RuntimeError):
    """No se pudo hablar con el ranking. El mensaje dice por qué, en castellano."""


def _pedir(testigo: str, cuerpo: dict, pedir) -> dict:
    try:
        crudo = pedir(
            DIRECCION,
            metodo="POST",
            cabeceras={"Authorization": f"Bearer {testigo}"},
            cuerpo=cuerpo,
            segundos=SEGUNDOS_DE_ESPERA,
        )
    except red.Contesto as fallo:
        raise RankingNoDisponible(_motivo(fallo.code, fallo.read())) from fallo
    except red.NoLlego as fallo:
        raise RankingNoDisponible("No hay conexión. El ranking necesita internet.") from fallo
    try:
        respuesta = json.loads(crudo)
    except ValueError as fallo:
        raise RankingNoDisponible("El servidor contestó algo que no entiendo.") from fallo
    if not isinstance(respuesta, dict):
        raise RankingNoDisponible("El servidor contestó algo que no entiendo.")
    return respuesta


def estado(testigo: str, pedir=red.pedir) -> dict:
    """{"compite": bool, "alias": str}."""
    return _pedir(testigo, {"accion": "estado"}, pedir)


def anotarme(testigo: str, alias: str, pedir=red.pedir) -> dict:
    return _pedir(testigo, {"accion": "anotarme", "alias": alias}, pedir)


def salirme(testigo: str, pedir=red.pedir) -> dict:
    return _pedir(testigo, {"accion": "salirme"}, pedir)


def tabla(testigo: str, periodo: str = "mes", mes: str | None = None, pedir=red.pedir) -> dict:
    """{"filas": [...], "meses": [...]}. `periodo`: «mes» o «siempre»."""
    pedido = {"accion": "tabla", "periodo": periodo}
    if mes:
        pedido["mes"] = mes
    return _pedir(testigo, pedido, pedir)


def perfil(testigo: str, alias: str, pedir=red.pedir) -> dict:
    return _pedir(testigo, {"accion": "perfil", "alias": alias}, pedir)


def _motivo(codigo: int, cuerpo: bytes) -> str:
    """El error del servidor, dicho para una persona."""
    try:
        dicho = str(json.loads(cuerpo).get("error") or "")
    except (ValueError, AttributeError):
        dicho = ""
    if codigo == 401:
        return "Tu sesión no vale. Entrá de nuevo en Configuración → Tu cuenta."
    if codigo in (404, 503) and not dicho.startswith("Esa persona"):
        return "El ranking todavía no está activado en el servidor."
    return dicho if dicho else f"El servidor contestó {codigo}. Probá de nuevo."
