"""Precios de mercado desde Yahoo Finance. Apagado por omisión.

QUÉ SALE DE ESTE ORDENADOR: el símbolo, y nada más. No se manda cuántas unidades
tienes, ni lo que pagaste, ni quién eres. Yahoo ve una petición pidiendo el precio
de "CSPX.L", igual que si abrieras esa página en el navegador.

VIENE APAGADO Y HAY QUE ENCENDERLO. Una aplicación de finanzas que sale a
internet sin preguntar es una aplicación que no se merece que le cuentes tu
dinero.

EL PELIGRO DE VERDAD ESTÁ EN LA MONEDA, y lo avisó el usuario: MUCHOS ETFs
EUROPEOS COTIZAN EN DÓLARES aunque estén en una bolsa europea. CSPX.L está en
Londres y da el precio en USD; comprobado desde esta máquina: 832,79 USD. Guardar
ese 832,79 como euros infla la cartera un 17 % sin que nada lo avise.

Por eso la regla es: SI NO SE PUEDE CONSEGUIR EL CAMBIO, NO SE GUARDA NADA y se
dice por qué. Un precio a medio convertir es peor que no tener precio.

LA CABECERA DE NAVEGADOR NO ES UN TRUCO SUCIO, es un requisito: sin ella Yahoo
contesta 429 y no da nada. Comprobado también desde aquí.
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal

BASE_PRECIO = "https://query1.finance.yahoo.com/v8/finance/chart/"
BASE_BUSQUEDA = "https://query1.finance.yahoo.com/v1/finance/search"

SEGUROS_EN_UN_SIMBOLO = "=^."
"""Los caracteres que NO hay que escapar dentro de un símbolo.

Los tres salen en símbolos de verdad: el "=" en los cambios de divisa
("USDEUR=X"), el "^" en los índices ("^GSPC") y el "." en las bolsas europeas
("CSPX.L"). Yahoo los acepta escapados y sin escapar —lo comprobé contra el
servidor de verdad—, pero sin escapar la dirección se lee, y una dirección que se
lee es una dirección que se puede comprobar a mano cuando algo falla.
"""

NAVEGADOR = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

SEGUNDOS_DE_ESPERA = 12
"""Si Yahoo tarda más, se deja. La pantalla no puede quedarse colgada esperando a
un servidor de fuera."""


class MercadoNoDisponible(RuntimeError):
    """No se pudo conseguir el dato. El mensaje explica por qué, para enseñarlo."""


@dataclass(frozen=True)
class Cotizacion:
    """Un precio traído de internet, con todo lo que hace falta para creérselo."""

    simbolo: str
    precio: int
    """En céntimos de la moneda EN QUE COTIZA, sin convertir."""

    moneda: str
    """El código ISO tal cual lo dice Yahoo: "USD", "EUR", "GBp"..."""

    momento: datetime
    nombre: str = ""
    bolsa: str = ""


@dataclass(frozen=True)
class PrecioEnEuros:
    """El precio ya convertido, CON el original y el cambio usado al lado.

    Se guardan los tres porque lo decidió el usuario y porque es como funcionan
    los movimientos de Finanzas: si un día el número no cuadra, se ve si falló el
    precio o el cambio. Con solo el resultado, no hay forma de saberlo.
    """

    euros: int
    original: int
    moneda_original: str
    cambio: Decimal
    momento: datetime

    @property
    def hubo_conversion(self) -> bool:
        return self.moneda_original != "EUR"

    def explicacion(self, formatear) -> str:
        """"832,79 $ × 0,8561 = 713,00 €", o solo el precio si ya venía en euros."""
        from ..dominio.moneda import CATALOGO, EUR

        if not self.hubo_conversion:
            return formatear(self.euros, EUR)
        # Si la moneda no está en el catálogo (una libra, un franco), se enseña
        # el número con su código detrás en vez de reventar: el aviso vale igual
        # y añadir monedas al catálogo es otra decisión, no un efecto secundario.
        origen = CATALOGO.get(self.moneda_original)
        if origen is None:
            return (
                f"{self.original / 100:.2f} {self.moneda_original} × "
                f"{self.texto_cambio()} = {formatear(self.euros, EUR)}"
            )
        return (
            f"{formatear(self.original, origen)} × {self.texto_cambio()} = "
            f"{formatear(self.euros, EUR)}"
        )

    def texto_cambio(self) -> str:
        """La tasa con coma decimal, como todo lo demás de la aplicación.

        Con el punto de Python quedaba "0.8561" en medio de una frase donde el
        precio pone "832,79": dos separadores distintos en la misma línea hacen
        dudar de si uno de los dos números significa otra cosa.
        """
        return str(self.cambio).replace(".", ",")


# ---------------------------------------------------------------------------
# Lectura de lo que contesta Yahoo: puro, sin red
# ---------------------------------------------------------------------------


def leer_cotizacion(simbolo: str, crudo: dict) -> Cotizacion:
    """Saca el precio de la respuesta de Yahoo, o explica qué falta.

    Es una función aparte y sin red para poder probar con respuestas guardadas
    todas las formas en que esto puede venir mal, sin depender de que internet
    funcione el día que se pasan los tests.
    """
    try:
        meta = crudo["chart"]["result"][0]["meta"]
    except (KeyError, IndexError, TypeError) as fallo:
        raise MercadoNoDisponible(
            f"Yahoo no ha devuelto ningún dato para «{simbolo}»."
        ) from fallo

    precio = meta.get("regularMarketPrice")
    moneda = meta.get("currency")
    if precio is None:
        raise MercadoNoDisponible(f"Yahoo no da precio para «{simbolo}».")
    if not moneda:
        # Sin saber en qué moneda está, el número no significa nada. Es
        # exactamente el fallo que hay que evitar.
        raise MercadoNoDisponible(
            f"Yahoo no dice en qué moneda cotiza «{simbolo}», así que no se puede "
            "guardar el precio sin arriesgarse a confundir dólares con euros."
        )

    centimos, codigo = _a_centimos(precio, str(moneda))
    return Cotizacion(
        simbolo=simbolo.upper(),
        precio=centimos,
        moneda=codigo,
        momento=datetime.now().replace(microsecond=0),
        nombre=str(meta.get("longName") or meta.get("shortName") or ""),
        bolsa=str(meta.get("fullExchangeName") or ""),
    )


def _a_centimos(precio, moneda: str) -> tuple[int, str]:
    """El precio en unidades mínimas enteras, y su código de moneda.

    OJO CON "GBp": la bolsa de Londres cotiza muchas cosas en PENIQUES, no en
    libras, y Yahoo lo dice con una "p" minúscula que es facilísima de pasar por
    alto. Tomar 832,79 peniques por 832,79 libras multiplica el valor por cien.
    """
    valor = Decimal(str(precio))
    if moneda in ("GBp", "ZAc", "ILA"):
        # Ya vienen en la unidad pequeña: son céntimos directamente.
        codigo = {"GBp": "GBP", "ZAc": "ZAR", "ILA": "ILS"}[moneda]
        return _redondear(valor), codigo
    return _redondear(valor * 100), moneda.upper()


def leer_cambio(crudo: dict) -> Decimal:
    """La tasa de cambio de la respuesta de Yahoo, como Decimal.

    Decimal y no float porque con la tasa se multiplica dinero, y el resto del
    programa ya trabaja así: una tasa en coma flotante mete un error diminuto en
    cada posición que luego no cuadra al sumar la cartera.
    """
    try:
        tasa = crudo["chart"]["result"][0]["meta"]["regularMarketPrice"]
    except (KeyError, IndexError, TypeError) as fallo:
        raise MercadoNoDisponible(
            "Yahoo no ha devuelto el tipo de cambio."
        ) from fallo
    if tasa is None:
        raise MercadoNoDisponible("Yahoo no da tipo de cambio ahora mismo.")
    valor = Decimal(str(tasa))
    if valor <= 0:
        raise MercadoNoDisponible(f"el tipo de cambio que da Yahoo no vale: {tasa}")
    return valor


def convertir(cotizacion: Cotizacion, cambio: Decimal | None) -> PrecioEnEuros:
    """Pasa el precio a euros. Sin cambio y sin ser euros, NO devuelve nada.

    Es la regla que puso el usuario, y la razón es la de arriba: guardar 832,79
    dólares como si fueran euros infla la cartera un 17 % en silencio. Más vale
    quedarse sin precio hoy que con un precio mentiroso para siempre.
    """
    if cotizacion.moneda == "EUR":
        return PrecioEnEuros(
            euros=cotizacion.precio,
            original=cotizacion.precio,
            moneda_original="EUR",
            cambio=Decimal(1),
            momento=cotizacion.momento,
        )
    if cambio is None:
        raise MercadoNoDisponible(
            f"«{cotizacion.simbolo}» cotiza en {cotizacion.moneda} y no he podido "
            "conseguir el cambio del día, así que no guardo nada: un precio en "
            "dólares guardado como euros te inflaría la cartera sin avisar."
        )
    return PrecioEnEuros(
        euros=_redondear(Decimal(cotizacion.precio) * cambio),
        original=cotizacion.precio,
        moneda_original=cotizacion.moneda,
        cambio=cambio,
        momento=cotizacion.momento,
    )


MINUTOS_DE_FRESCURA = 15
"""Cuánto vale un precio antes de volver a pedirlo.

Quince minutos: lo bastante fresco para mirar la cartera y lo bastante espaciado
para no pedirle a Yahoo el mismo número cada vez que pasas por la pantalla. Pedir
sin parar acaba en un 429 y en quedarse sin precios justo cuando los quieres.
"""

#: Lo que dice Yahoo en "quoteType" y qué es eso para nosotros.
_TIPOS_DE_YAHOO = {
    "EQUITY": "acción",
    "ETF": "ETF",
    "MUTUALFUND": "fondo",
    "CRYPTOCURRENCY": "cripto",
    "INDEX": "otro",
    "CURRENCY": "otro",
    "FUTURE": "otro",
}


def tipo_desde_yahoo(texto: str | None) -> str:
    """El tipo de activo que dice Yahoo, traducido al nuestro.

    Sirve para rellenar el tipo al elegir del buscador, que es un dato que el
    usuario tendría que poner a mano sabiéndolo ya Yahoo. Lo que no se reconoce
    cae en "otro" en vez de fallar: equivocarse de etiqueta es una molestia, y no
    poder guardar la inversión es un problema.
    """
    if not texto:
        return "otro"
    return _TIPOS_DE_YAHOO.get(str(texto).strip().upper(), "otro")


def necesita_refresco(
    momento: datetime | None, ahora: datetime, minutos: int = MINUTOS_DE_FRESCURA
) -> bool:
    """Si ese precio ya está viejo y toca volver a pedirlo.

    Sin momento devuelve True: un precio sin fecha no se puede dar por fresco.
    Un momento del futuro también cuenta como viejo —pasa si se cambia la hora
    del ordenador— porque quedarse con un precio para siempre por un reloj mal
    puesto sería peor que pedirlo de más.
    """
    if momento is None:
        return True
    diferencia = (ahora - momento).total_seconds()
    return diferencia < 0 or diferencia >= minutos * 60


#: Lo que se puede comprar de verdad va antes que lo que no. El numero es el
#: orden: cuanto mas bajo, mas arriba sale.
_PESO_DEL_TIPO = {"ETF": 0, "fondo": 0, "acción": 1, "cripto": 2, "otro": 3}


def ordenar_resultados(encontrados: list[dict]) -> list[dict]:
    """Pone delante lo que una persona puede comprar.

    POR QUÉ HACE FALTA: buscando "S&P 500", Yahoo devuelve primero los FUTUROS
    (ES=F, SDI=F, EGT=F...), que son contratos que no compra nadie que esté
    apuntando su cartera. Los ETFs y fondos —lo que de verdad se tiene— quedaban
    enterrados debajo. Comprobado contra Yahoo de verdad.

    NO SE ESCONDE NADA: los futuros siguen en la lista, al final. Quitarlos sería
    decidir por el usuario qué puede comprar, y eso no me toca a mí.

    Dentro de cada grupo se respeta el orden de Yahoo, que sabe más que nosotros
    de qué se parece más a lo que se ha escrito. Se usa un orden estable para
    eso: sorted() en Python lo es.
    """
    return sorted(
        encontrados, key=lambda uno: _PESO_DEL_TIPO.get(uno.get("tipo_nuestro"), 3)
    )


#: Los tipos que una persona puede tener de verdad en su cartera.
COMPRABLES = ("ETF", "fondo", "acción", "cripto")


def hay_algo_comprable(encontrados: list[dict]) -> bool:
    return any(uno.get("tipo_nuestro") in COMPRABLES for uno in encontrados)


def variantes_de_busqueda(texto: str) -> list[str]:
    """El texto tal cual, y luego versiones más simples por si Yahoo se atraganta.

    ESTO SALE DE UNA PRUEBA CONTRA YAHOO DE VERDAD, no de una sospecha:

        "S&P 500"  -> 7 futuros y ni un ETF
        "S&P500"   -> ^GSPC, SPXL, UPRO...
        "SP 500"   -> ^GSPC, VFV.TO, HXS-U.TO...

    El "&" seguido de espacio le sienta mal a su buscador. Como "S&P 500" es
    justo como lo escribe cualquiera, hace falta reintentar; y como el reintento
    cuesta otra petición, solo se hace si la primera no trajo nada que se pueda
    comprar.

    Se devuelven en orden de menos a más agresivo, y sin repetidos: si el texto
    no lleva signos raros, la lista tiene un solo elemento y no hay reintento.
    """
    limpio = (texto or "").strip()
    variantes = [limpio]

    # Las dos que funcionaron en la prueba de verdad, en este orden:
    #   sin el signo    "S&P 500" -> "SP 500"   -> ^GSPC, VFV.TO, HXS-U.TO...
    #   sin espacios    "S&P 500" -> "S&P500"   -> ^GSPC, SPXL, UPRO...
    sin_signos = re.sub(r"[^\w\s]", "", limpio)
    sin_signos = re.sub(r"\s+", " ", sin_signos).strip()
    if sin_signos and sin_signos not in variantes:
        variantes.append(sin_signos)

    sin_espacios = re.sub(r"\s+", "", limpio)
    if sin_espacios and sin_espacios not in variantes:
        variantes.append(sin_espacios)

    return variantes


def leer_busqueda(crudo: dict) -> list[dict]:
    """Los resultados del buscador de símbolos, quedándose con lo útil.

    Existe porque nadie se sabe que el S&P 500 es CSPX.L en Londres y SXR8.DE en
    Fráncfort. Se enseña la BOLSA junto al símbolo porque el mismo fondo en dos
    bolsas distintas es lo que hace falta distinguir.
    """
    salida = []
    for uno in (crudo or {}).get("quotes", []) or []:
        simbolo = uno.get("symbol")
        if not simbolo:
            continue
        salida.append(
            {
                "simbolo": simbolo,
                "nombre": uno.get("longname") or uno.get("shortname") or "",
                "bolsa": uno.get("exchDisp") or uno.get("exchange") or "",
                "tipo": uno.get("typeDisp") or uno.get("quoteType") or "",
                # El tipo ya traducido al nuestro, para poder rellenarlo al
                # elegir en vez de pedírselo al usuario sabiéndolo ya Yahoo.
                "tipo_nuestro": tipo_desde_yahoo(uno.get("quoteType")),
            }
        )
    return ordenar_resultados(salida)


# ---------------------------------------------------------------------------
# La red
# ---------------------------------------------------------------------------


def _pedir(url: str) -> dict:
    """Una petición a Yahoo. Aparte para poder sustituirla en los tests.

    truststore hace que Python use los certificados de Windows. Sin esto, en
    esta máquina cualquier petición HTTPS falla con CERTIFICATE_VERIFY_FAILED,
    porque algo del sistema mira el tráfico y lo vuelve a firmar.
    """
    try:
        import truststore

        truststore.inject_into_ssl()
    except ImportError:
        pass

    peticion = urllib.request.Request(url)
    peticion.add_header("User-Agent", NAVEGADOR)
    try:
        with urllib.request.urlopen(peticion, timeout=SEGUNDOS_DE_ESPERA) as respuesta:
            return json.loads(respuesta.read())
    except urllib.error.HTTPError as fallo:
        raise MercadoNoDisponible(
            f"Yahoo ha contestado {fallo.code}. Prueba dentro de un rato."
        ) from fallo
    except (urllib.error.URLError, TimeoutError, OSError) as fallo:
        raise MercadoNoDisponible(
            f"No he podido conectar con Yahoo: {fallo}"
        ) from fallo
    except ValueError as fallo:
        raise MercadoNoDisponible(
            "Yahoo ha contestado algo que no entiendo."
        ) from fallo


def cotizacion(simbolo: str, pedir=_pedir) -> Cotizacion:
    limpio = (simbolo or "").strip()
    if not limpio:
        raise MercadoNoDisponible("hace falta un símbolo")
    return leer_cotizacion(limpio, pedir(BASE_PRECIO + urllib.parse.quote(limpio, safe=SEGUROS_EN_UN_SIMBOLO)))


def cambio_a_euros(moneda: str, pedir=_pedir) -> Decimal:
    """El cambio del día de esa moneda a euros, con el símbolo de Yahoo."""
    if moneda.upper() == "EUR":
        return Decimal(1)
    simbolo = f"{moneda.upper()}EUR=X"
    return leer_cambio(pedir(BASE_PRECIO + urllib.parse.quote(simbolo, safe=SEGUROS_EN_UN_SIMBOLO)))


def precio_en_euros(simbolo: str, pedir=_pedir) -> PrecioEnEuros:
    """El precio de ese símbolo, en euros, o una excepción que explica por qué no.

    Es la única función que usa la pantalla. Junta las dos peticiones —el precio
    y, si hace falta, el cambio— para que quien llama no pueda olvidarse de la
    segunda, que es justo el olvido que infla la cartera un 17 %.
    """
    precio = cotizacion(simbolo, pedir)
    if precio.moneda == "EUR":
        return convertir(precio, None)
    try:
        tasa = cambio_a_euros(precio.moneda, pedir)
    except MercadoNoDisponible:
        # Se relanza con el mensaje del caso concreto: "no hay cambio" a secas no
        # dice qué posición se ha quedado sin precio ni por qué importa.
        return convertir(precio, None)
    return convertir(precio, tasa)


def buscar(texto: str, pedir=_pedir) -> list[dict]:
    """Busca símbolos, reintentando con el texto simplificado si hace falta.

    El reintento NO es gratis (otra petición a Yahoo), así que solo se hace
    cuando la primera búsqueda no ha traído nada que se pueda comprar. En el caso
    normal —"Apple", "bitcoin", "inditex"— se hace una sola petición.
    """
    if not (texto or "").strip():
        return []

    ultimos: list[dict] = []
    for variante in variantes_de_busqueda(texto):
        parametros = urllib.parse.urlencode(
            {"q": variante, "quotesCount": 10, "newsCount": 0}
        )
        encontrados = leer_busqueda(pedir(f"{BASE_BUSQUEDA}?{parametros}"))
        if hay_algo_comprable(encontrados):
            return encontrados
        # Se guarda lo último por si ninguna variante trae nada comprable: es
        # mejor enseñar los futuros que una lista vacía diciendo "no hay nada".
        ultimos = encontrados or ultimos
    return ultimos


def _redondear(valor: Decimal) -> int:
    return int(valor.quantize(Decimal(1), rounding=ROUND_HALF_UP))
