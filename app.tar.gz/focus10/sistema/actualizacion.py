"""Enterarse de que hay una versión nueva publicada, y recargar para tomarla.

SOLO TIENE SENTIDO EN LA WEB. En Windows la aplicación se actualiza cuando se
vuelve a instalar, y en el móvil lo hace Google Play; en el navegador, en
cambio, el que decide qué versión corre es la caché, y ahí es donde hacía falta
ir a «borrar datos del sitio» a mano.

CÓMO SE SABE: cada publicación deja un archivo `version.json` al lado de la
aplicación, con el sello de esa publicación. La copia que está corriendo lleva
el suyo dentro (focus10/sello.py). Si no coinciden, hay una nueva.

POR QUÉ NO BASTA CON RECARGAR: el navegador guarda la aplicación en su caché y
en un «service worker», y una recarga normal puede volver a servir justo lo
mismo que ya tenía. Por eso, antes de recargar, se le quita el service worker y
se le vacían las cachés: es lo mismo que hacer «borrar datos del sitio» a mano,
pero sin tener que explicárselo a nadie.
"""

from __future__ import annotations

import json

from . import red

ARCHIVO = "sello.json"
"""SE LLAMA ASI Y NO version.json PORQUE ESE YA EXISTE: lo genera Flet
con los datos de su cliente, y pisarlo era romper algo suyo para poner
lo nuestro. Se vio al publicar y comprobar que el archivo servido no era
el esperado."""


def se_puede_comprobar(sello: str) -> bool:
    """Si tiene sentido preguntar: solo en el navegador y con sello de verdad."""
    return red.EN_EL_NAVEGADOR and sello != "desarrollo"


def hay_otra_version(sello: str, pedir=red.pedir) -> bool:
    """Si lo publicado ya no es lo que está corriendo aquí.

    ANTE LA DUDA, NO. Sin red, con un archivo a medio escribir o con cualquier
    cosa rara, se contesta que no hay novedad: un aviso de actualización que
    sale cuando no toca enseña a ignorarlo.
    """
    if not se_puede_comprobar(sello):
        return False
    try:
        # SE LE PEGA EL SELLO PROPIO PARA QUE NO LO SIRVA DE LA CACHE: sin eso,
        # el navegador podría contestar con el version.json de hace una hora,
        # que es justo el que dice que no hay nada nuevo.
        crudo = pedir(f"{ARCHIVO}?desde={sello}")
        publicado = json.loads(crudo).get("sello")
    except Exception:  # noqa: BLE001
        return False
    return bool(publicado) and publicado != sello


def recargar() -> None:
    """Tira la caché del navegador y vuelve a cargar. Solo en la web."""
    if not red.EN_EL_NAVEGADOR:
        return
    import js  # noqa: PLC0415  (solo existe en el navegador)

    js.eval(
        """
        (async () => {
          try {
            const rs = await navigator.serviceWorker.getRegistrations();
            await Promise.all(rs.map(r => r.unregister()));
            const ks = await caches.keys();
            await Promise.all(ks.map(k => caches.delete(k)));
          } catch (e) { /* si no se puede, se recarga igual */ }
          location.reload();
        })();
        """
    )
