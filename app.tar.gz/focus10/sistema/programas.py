"""Qué programas hay abiertos ahora mismo, para poder elegirlos de una lista.

POR QUÉ HACE FALTA ESTO: el usuario lo pidió con estas palabras: "no me sé que
Discord es discord.exe". Escribir el nombre del proceso a mano es la clase de
cosa que sabe hacer quien programa y nadie más, y equivocarse significa que la
regla no hace nada y no te enteras hasta el día que la necesitas.

CÓMO SE PREGUNTA: con "tasklist", que viene con Windows. Ni una dependencia
nueva. Se pide con /V para que traiga el TÍTULO DE LA VENTANA, que es lo que
convierte una lista ilegible de doscientos servicios en una lista corta de cosas
que reconoces: "discord.exe — Discord", "spotify.exe — Spotify".

SE FILTRA POR TENER VENTANA a propósito. Lo que no tiene ventana es casi siempre
un servicio del sistema, y de esos no quieres cerrar ninguno.
"""

from __future__ import annotations

import csv
import subprocess
from dataclasses import dataclass

from ..dominio.procesos import ProcesoInvalido, esta_protegido, normalizar

SIN_TITULO = "N/A"
TIEMPO_MAXIMO = 20
"""Segundos de espera para tasklist. Si tarda más, algo va muy mal en la máquina
y es mejor devolver una lista vacía que dejar la ventana colgada."""


@dataclass(frozen=True)
class Programa:
    nombre: str
    """El nombre normalizado, sin .exe: "discord"."""

    titulo: str
    """El título de su ventana: "Discord". Lo que reconoce una persona."""

    protegido: bool
    """True si es de los que nunca se cierran. Se devuelve en vez de esconderlo
    para que la pantalla pueda enseñarlo apagado y explicar por qué, en lugar de
    dejar al usuario buscando un programa que no aparece."""


def _tasklist() -> str:
    """La salida cruda de tasklist. Aparte para poder sustituirla en los tests."""
    resultado = subprocess.run(
        ["tasklist", "/FO", "CSV", "/V", "/NH"],
        capture_output=True,
        text=True,
        timeout=TIEMPO_MAXIMO,
        # Sin ventana negra parpadeando cada vez que se abre la pantalla.
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    return resultado.stdout


def leer_lista(salida: str) -> list[Programa]:
    """Convierte la salida de tasklist en programas elegibles.

    Es una función de texto para poder probarla con una salida guardada, sin
    depender de qué haya abierto en la máquina donde corren los tests.
    """
    encontrados: dict[str, Programa] = {}

    for fila in csv.reader(salida.splitlines()):
        if len(fila) < 9:
            continue
        bruto, titulo = fila[0], fila[8].strip()
        if not titulo or titulo == SIN_TITULO:
            # Sin ventana: casi siempre un servicio del sistema.
            continue
        try:
            nombre = normalizar(bruto)
        except ProcesoInvalido:
            continue
        # Varias ventanas del mismo programa son un solo programa: cerrar
        # "chrome" las cierra todas, así que enseñarlo quince veces solo estorba.
        if nombre in encontrados:
            continue
        encontrados[nombre] = Programa(
            nombre=nombre, titulo=titulo, protegido=esta_protegido(nombre)
        )

    # Los cerrables primero y por título: es una lista para elegir, y lo que no
    # se puede elegir no debe estar arriba estorbando.
    return sorted(
        encontrados.values(), key=lambda uno: (uno.protegido, uno.titulo.lower())
    )


def abiertos(leer=_tasklist) -> list[Programa]:
    """Los programas con ventana que hay abiertos ahora.

    Si tasklist falla o tarda demasiado se devuelve una lista vacía en vez de
    reventar: quedarse sin la lista es una molestia, tumbar la pantalla de Focus
    por no poder listar procesos es un fallo.
    """
    try:
        return leer_lista(leer())
    except (OSError, subprocess.SubprocessError, ValueError):
        return []
