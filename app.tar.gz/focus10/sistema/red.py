"""Una petición HTTP que funciona en Windows Y DENTRO DEL NAVEGADOR.

POR QUÉ EXISTE, y es un fallo que costó caro: en la web, la aplicación es el
mismo Python corriendo dentro del navegador, y ahí `urllib` NO PUEDE FUNCIONAR.
El navegador no le da sockets a nadie: lo único que sale a internet es él
mismo. Así que cada petición hecha con urllib fallaba con un error de red, la
aplicación decía «mira si tienes internet» y el internet estaba perfecto.

LO QUE ESO ROMPÍA: entrar en la cuenta desde la web —y como la puerta es
obligatoria, la web entera— y mandar un comentario desde la web. En Windows
siempre funcionó, que es donde se probó, y por eso tardó en verse.

CÓMO SE ARREGLA: dentro del navegador se le pide a ÉL que haga la petición
(XMLHttpRequest, lo mismo que usa cualquier página). Fuera, urllib como
siempre. Quien llama no se entera de la diferencia.

LA PETICIÓN ES SÍNCRONA EN LOS DOS CASOS, a propósito: el resto del código ya
está escrito así, y el Python de la web vive en un hilo aparte del dibujo, así
que esperar aquí no congela la ventana.
"""

from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request

EN_EL_NAVEGADOR = sys.platform == "emscripten"
"""Cómo se sabe dónde estamos. Pyodide —el Python del navegador— se compila a
WebAssembly con Emscripten, y eso es lo que dice sys.platform. No se mira si
`flet` cree que es web: esta capa no conoce a flet."""

SEGUNDOS_DE_ESPERA = 30


class NoLlego(RuntimeError):
    """No se pudo hablar con el servidor: sin red, o el navegador lo bloqueó."""


class Contesto(RuntimeError):
    """El servidor contestó, pero con un error.

    IMITA A urllib.error.HTTPError (`code` y `read()`) A PROPÓSITO: así el
    código que ya traducía esos errores a español sigue valiendo igual, venga
    la respuesta de urllib o del navegador.
    """

    def __init__(self, code: int, cuerpo: bytes) -> None:
        super().__init__(f"el servidor contestó {code}")
        self.code = code
        self._cuerpo = cuerpo

    def read(self) -> bytes:
        return self._cuerpo


def pedir(
    url: str,
    *,
    metodo: str = "GET",
    cabeceras: dict[str, str] | None = None,
    cuerpo: dict | None = None,
    segundos: int = SEGUNDOS_DE_ESPERA,
) -> bytes:
    """Hace la petición y devuelve el cuerpo de la respuesta, en bytes."""
    cabeceras = dict(cabeceras or {})
    datos = None
    if cuerpo is not None:
        datos = json.dumps(cuerpo).encode("utf-8")
        cabeceras.setdefault("Content-Type", "application/json")
    if EN_EL_NAVEGADOR:
        return _por_el_navegador(url, metodo, cabeceras, datos)
    return _por_urllib(url, metodo, cabeceras, datos, segundos)


def _por_urllib(url, metodo, cabeceras, datos, segundos) -> bytes:
    # truststore hace que Python verifique con los certificados de Windows.
    # NO desactiva nada: cambia quién comprueba. Hace falta en esta máquina,
    # donde algo intercepta el HTTPS y lo vuelve a firmar.
    try:
        import truststore

        truststore.inject_into_ssl()
    except ImportError:
        pass

    peticion = urllib.request.Request(url, data=datos, headers=cabeceras, method=metodo)
    try:
        with urllib.request.urlopen(peticion, timeout=segundos) as respuesta:
            return respuesta.read()
    except urllib.error.HTTPError as fallo:
        raise Contesto(fallo.code, fallo.read()) from fallo
    except (urllib.error.URLError, TimeoutError, OSError) as fallo:
        raise NoLlego(str(getattr(fallo, "reason", None) or fallo)) from fallo


def _por_el_navegador(url, metodo, cabeceras, datos) -> bytes:
    """La misma petición, pero la hace el navegador.

    SÍNCRONA (el `False` del open) porque el resto del código la espera. En un
    hilo de trabajo —donde vive el Python de la web— eso está permitido y no
    congela la página.
    """
    from js import XMLHttpRequest  # noqa: PLC0415  (solo existe en el navegador)

    peticion = XMLHttpRequest.new()
    peticion.open(metodo, url, False)
    for nombre, valor in cabeceras.items():
        peticion.setRequestHeader(nombre, valor)
    try:
        peticion.send(datos.decode("utf-8") if datos else None)
    except Exception as fallo:  # noqa: BLE001
        # AQUÍ CAEN LOS BLOQUEOS DEL NAVEGADOR (CORS, red cortada). No hay
        # forma de distinguirlos: el navegador no cuenta por qué, a propósito.
        raise NoLlego(f"el navegador no pudo con la petición: {fallo}") from fallo

    cuerpo = (peticion.responseText or "").encode("utf-8")
    if peticion.status == 0:
        raise NoLlego("el navegador bloqueó la petición o no hay red")
    if peticion.status >= 400:
        raise Contesto(peticion.status, cuerpo)
    return cuerpo
