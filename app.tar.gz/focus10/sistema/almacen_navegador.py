"""Guardar el archivo de datos en el navegador, cuando la aplicación corre ahí.

POR QUÉ HACE FALTA: en el navegador, Python corre sobre Pyodide y su sistema de
archivos vive EN MEMORIA. El .db se crea, funciona toda la sesión y desaparece
al recargar la página. Sin esto, cada vez que un amigo abriera el link empezaría
de cero.

LO QUE HACE: mover bytes entre el archivo y `indexedDB`, que es el único almacén
del navegador que sobrevive al cierre. Al arrancar se recuperan y se escriben al
archivo; después de escribir, se vuelcan de vuelta.

POR QUÉ indexedDB Y NO localStorage, que sería más simple: se comprobó en un
navegador de verdad y el código Python corre en un WORKER —un hilo aparte— que
NO tiene acceso ni a `localStorage` ni al documento. Solo `indexedDB`. La forma
fácil no existe.

ESTE MÓDULO NO SABE NADA DE SQLite ni de la aplicación: mueve un archivo, y ya.
Por eso vive en la capa de sistema, que es la única que puede hablar con la
plataforma, y por eso funciona igual el día que el archivo sea otro.

EN WINDOWS NO HACE NADA. Todas sus funciones devuelven "no he hecho nada" sin
fallar, para que el resto del código no tenga que preguntar dónde está.
"""

from __future__ import annotations

import sys
from pathlib import Path

NOMBRE_ALMACEN = "focus10"
CAJON = "archivos"

_JS = """
(() => {
  const NOMBRE = 'focus10';
  const CAJON = 'archivos';

  function abrir() {
    return new Promise((ok, mal) => {
      const p = indexedDB.open(NOMBRE, 1);
      p.onupgradeneeded = () => p.result.createObjectStore(CAJON);
      p.onsuccess = () => ok(p.result);
      p.onerror = () => mal(p.error);
    });
  }

  globalThis.focus10Guardar = async (clave, bytes) => {
    const db = await abrir();
    return new Promise((ok, mal) => {
      const t = db.transaction(CAJON, 'readwrite');
      t.objectStore(CAJON).put(bytes, clave);
      t.oncomplete = () => ok(true);
      t.onerror = () => mal(t.error);
      t.onabort = () => mal(t.error);
    });
  };

  globalThis.focus10Cargar = async (clave) => {
    const db = await abrir();
    return new Promise((ok, mal) => {
      const t = db.transaction(CAJON, 'readonly');
      const r = t.objectStore(CAJON).get(clave);
      // NUNCA SE DEVUELVE null: Pyodide lo convierte en un objeto suyo que NO
      // es el None de Python, y comprobarlo desde alli revienta. Un bloque de
      // cero bytes dice "no habia nada" sin ninguna ambiguedad.
      r.onsuccess = () => ok(r.result == null ? new Uint8Array(0) : r.result);
      r.onerror = () => mal(r.error);
    });
  };
  return 'listo';
})()
"""

_preparado = False


class NoSePudoGuardar(RuntimeError):
    """El navegador no ha dejado guardar el archivo de datos."""


def en_el_navegador() -> bool:
    """True si la aplicación está corriendo dentro de un navegador.

    Pyodide compila Python a WebAssembly con Emscripten, y eso es lo que dice
    `sys.platform`. Es la forma que recomienda el propio Pyodide, y no depende
    de que existan módulos que podrían aparecer por otros motivos.
    """
    return sys.platform == "emscripten"


def preparar() -> bool:
    """Deja listas las funciones de guardado. Devuelve si se pudo.

    SE HACE UNA SOLA VEZ: instalar el ayudante de JavaScript en cada guardado
    sería trabajo repetido en el camino más caliente que hay.
    """
    global _preparado
    if not en_el_navegador():
        return False
    if _preparado:
        return True
    try:
        from pyodide.code import run_js  # type: ignore[import-not-found]

        run_js(_JS)
    except Exception as fallo:  # pragma: no cover - solo pasa en el navegador
        raise NoSePudoGuardar(
            f"no se pudo preparar el almacén del navegador: {fallo}"
        ) from fallo
    _preparado = True
    return True


async def cargar(ruta: Path | str) -> int:
    """Recupera el archivo guardado y lo escribe en disco. Devuelve los bytes.

    DEVUELVE 0 SI NO HABÍA NADA, que es lo que pasa la primera vez que alguien
    abre el link. No es un error: es un usuario nuevo.
    """
    if not preparar():
        return 0
    import js  # type: ignore[import-not-found]

    guardado = await js.focus10Cargar(_clave(ruta))
    datos = guardado.to_bytes()
    if not datos:
        return 0
    destino = Path(ruta)
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_bytes(datos)
    return len(datos)


async def guardar(ruta: Path | str) -> int:
    """Vuelca el archivo al almacén del navegador. Devuelve los bytes escritos.

    SI EL ARCHIVO NO EXISTE no se guarda nada y no se falla: puede pasar si se
    llama antes de que la base llegue a crearse.
    """
    if not preparar():
        return 0
    origen = Path(ruta)
    if not origen.is_file():
        return 0

    import js  # type: ignore[import-not-found]

    datos = origen.read_bytes()
    # El buffer se crea del lado de JavaScript y se rellena: pasar los bytes de
    # Python directamente los copiaría igual, pero con una conversión de más.
    buffer = js.Uint8Array.new(len(datos))
    buffer.assign(datos)
    try:
        await js.focus10Guardar(_clave(ruta), buffer)
    except Exception as fallo:  # pragma: no cover - solo pasa en el navegador
        raise NoSePudoGuardar(
            f"el navegador no dejó guardar los datos: {fallo}"
        ) from fallo
    return len(datos)


def _clave(ruta: Path | str) -> str:
    """Con qué nombre se guarda dentro del navegador.

    Se usa solo el nombre del archivo y no la ruta entera: dentro del navegador
    la ruta es inventada —siempre la misma— y meterla en la clave solo ataría el
    guardado a un detalle que no significa nada ahí.
    """
    return Path(ruta).name
