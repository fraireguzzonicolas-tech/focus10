"""Sonido y aviso de Windows. Para cuando la ventana no está delante.

PARA QUÉ: el cronómetro de descanso del gimnasio. Estás de pie con el móvil en
la mano y la aplicación detrás; si el aviso solo se pinta en la ventana, no te
enteras y el descanso se te va a cuatro minutos.

LAS DOS REGLAS DE ESTE ARCHIVO:

  1. NUNCA BLOQUEA. Ni un aviso ni un pitido pueden congelar la ventana.
  2. NUNCA REVIENTA. Si el sonido falla, falla el sonido y ya está. Que la
     aplicación se caiga porque un pitido no salió sería mucho peor que
     quedarse sin pitido.

Es la única pieza que toca el Windows de los sonidos y los avisos, y por eso
está en «sistema» y no en la interfaz.
"""

from __future__ import annotations

import subprocess
import sys
import threading

# Los tres pitidos del final del descanso: frecuencia en hercios y duración en
# milisegundos. Suben de tono porque un aviso que sube se oye como "ya", y uno
# que baja como "se acabó, descansa". Aquí es lo primero.
TONOS_FINAL = ((784, 130), (988, 130), (1319, 220))

TONOS_AVISO = ((880, 90),)
"""Un solo pitido corto, para los últimos segundos."""

TONOS_DESCANSO = ((1319, 130), (988, 130), (784, 260))
"""Los mismos tres tonos de TONOS_FINAL pero AL REVÉS, de agudo a grave.

PARA QUÉ HACEN FALTA DOS: Focus avisa de dos cosas distintas —se acabó el
trabajo, se acabó el descanso— y son opuestas. Una escala que sube se oye como
"vamos"; una que baja, como "ya está, para". Con el mismo pitido para las dos
habría que mirar la pantalla para saber cuál ha sido, que es justo lo que un
aviso sonoro viene a evitar.

Y no es un adorno: si estás con el móvil o en otra ventana, el sonido es lo
único que te llega."""

# EL IDENTIFICADOR DE APLICACIÓN, y esto costó descubrirlo: Windows solo enseña
# un aviso si viene de un programa que conoce, o sea, uno con acceso directo en
# el menú Inicio. Con un identificador inventado ("Focus10") la llamada devuelve
# ÉXITO y no aparece nada en pantalla: el peor fallo posible, porque parece que
# funciona. Se usa el de PowerShell, que está registrado en cualquier Windows,
# hasta que la aplicación se instale de verdad y tenga el suyo.
IDENTIFICADOR = (
    r"{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe"
)

SEGUNDOS_MAXIMOS_POWERSHELL = 20
"""Si PowerShell tarda más que esto es que algo va mal; se abandona el aviso.
Sin tope, un PowerShell colgado dejaría un hilo vivo para siempre."""

# Para que no parpadee una ventana negra de consola cada vez que salta un aviso.
# Solo existe en Windows, así que se pide con getattr en vez de darlo por hecho.
SIN_VENTANA = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def hay_sonido() -> bool:
    """Si este ordenador puede pitar. En Windows, sí; fuera, no."""
    return sys.platform == "win32"


def sonar(tonos: tuple[tuple[int, int], ...] = TONOS_FINAL) -> None:
    """Pita, sin esperar a que termine.

    EN OTRO HILO A PROPÓSITO: winsound.Beep se queda parado el tiempo que dura
    el pitido. Medio segundo puede parecer poco, pero es medio segundo con la
    ventana congelada, y justo cuando estás mirándola para apuntar la serie.
    """
    if not hay_sonido():
        return
    hilo = threading.Thread(target=_sonar_ahora, args=(tonos,), daemon=True)
    hilo.start()


def notificar(titulo: str, texto: str) -> None:
    """Saca un aviso de Windows, sin esperar a que aparezca.

    SIN ESPERAR: arrancar PowerShell tarda entre medio segundo y un segundo y
    medio. Esperarlo sería congelar la ventana justo al acabar el descanso.
    """
    if sys.platform != "win32":
        return
    hilo = threading.Thread(
        target=_notificar_ahora, args=(titulo, texto), daemon=True
    )
    hilo.start()


def guion_de_aviso(titulo: str, texto: str) -> str:
    """El texto de PowerShell que saca el aviso.

    Está separado para poder comprobarlo en un test sin llenar de avisos la
    pantalla de quien corre las pruebas.
    """
    return f"""
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType=WindowsRuntime] > $null
$plantilla = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$lineas = $plantilla.GetElementsByTagName("text")
$lineas.Item(0).AppendChild($plantilla.CreateTextNode("{_escapar(titulo)}")) > $null
$lineas.Item(1).AppendChild($plantilla.CreateTextNode("{_escapar(texto)}")) > $null
$aviso = [Windows.UI.Notifications.ToastNotification]::new($plantilla)
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("{IDENTIFICADOR}").Show($aviso)
""".strip()


def _escapar(texto: str) -> str:
    """Deja el texto para meterlo entre comillas dobles de PowerShell.

    NO ES DECORACIÓN. Sin esto, un ejercicio llamado «Press "militar"» partiría
    la cadena y PowerShell ejecutaría lo que viniera detrás. El nombre lo escribe
    el usuario, pero un nombre nunca debe poder convertirse en una orden.

    Se quitan además los saltos de línea: el aviso es de dos líneas fijas, y un
    salto de más lo dejaría a medias.
    """
    if not isinstance(texto, str):
        return ""
    limpio = texto.replace("`", "``").replace('"', '`"').replace("$", "`$")
    return limpio.replace("\r", " ").replace("\n", " ")[:120]


def _sonar_ahora(tonos: tuple[tuple[int, int], ...]) -> None:
    try:
        import winsound

        for frecuencia, duracion in tonos:
            winsound.Beep(frecuencia, duracion)
    except Exception:
        # Sin altavoces, sin permisos, o en un Windows donde Beep no existe. Que
        # no suene es un fastidio; que se caiga la aplicación de pie en el
        # gimnasio, un problema de verdad.
        pass


def _notificar_ahora(titulo: str, texto: str) -> None:
    try:
        subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                guion_de_aviso(titulo, texto),
            ],
            capture_output=True,
            timeout=SEGUNDOS_MAXIMOS_POWERSHELL,
            creationflags=SIN_VENTANA,
        )
    except Exception:
        pass
