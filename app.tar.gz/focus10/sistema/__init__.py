"""Lo que toca el sistema operativo o la red: el archivo hosts, el guardián
elevado, los avisos, las cuentas y las peticiones (solo red.py sale a internet).

POR QUÉ UNA CAPA APARTE: es el único sitio del programa que puede estropear algo
fuera de la aplicación. Tenerlo junto y marcado significa que para auditar qué
puede romper Focus10 se lee esta carpeta y ninguna otra.

REGLA DE DEPENDENCIAS: sistema puede usar el dominio (las listas protegidas), y
nada más. Ni base de datos ni interfaz. La vigila tests/test_arquitectura.py.
"""
