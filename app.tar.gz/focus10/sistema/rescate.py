"""El .bat de rescate: quita el bloqueo aunque Focus10 no vuelva a abrirse nunca.

POR QUÉ EXISTE: todo lo demás —el latido, la hora límite, el desbloqueo al
cerrar— depende de que algún proceso nuestro siga vivo para hacerlo. Este archivo
es lo que queda cuando no queda nada: un .bat que se ejecuta solo, se pide a sí
mismo los permisos de administrador y borra nuestro bloque del hosts. No importa
la aplicación, no lee la base de datos, no necesita Python instalado.

POR QUÉ NO LLAMA A PYTHON: si Focus10 no arranca, es muy posible que el problema
sea justamente Python —una actualización, un entorno virtual movido, un antivirus
que se comió el intérprete—. Un rescate que necesita lo mismo que está roto no es
un rescate.

CÓMO BUSCA EL BLOQUE: por las marcas, y solo mira si la línea CONTIENE ">>>
FOCUS10". Las marcas son ASCII puro por esto mismo; si llevaran un acento, una
codificación distinta al reescribir podría destrozarlo y el rescate ya no
encontraría nada.
"""

from __future__ import annotations

from pathlib import Path


NOMBRE = "Focus10-quitar-bloqueo.bat"

# Lo que se busca en cada línea. Un trozo corto y ASCII de cada marca: si algún
# día se cambia el texto completo de las marcas, esto sigue valiendo.
SENAL_INICIO = ">>> FOCUS10"
SENAL_FIN = "<<< FOCUS10"


def contenido() -> str:
    """El texto del .bat.

    Se genera desde aquí en vez de tenerlo como archivo suelto para que las
    señales que busca salgan de las mismas constantes que las escriben. Un
    rescate que busca una marca que ya nadie escribe es papel mojado.
    """
    return f"""@echo off
setlocal
title Focus10 - quitar el bloqueo de webs

echo.
echo   FOCUS10 - RESCATE
echo   Quita el bloqueo de webs del archivo hosts de Windows.
echo   No toca nada mas de ese archivo.
echo.

REM Comprobar si ya vamos con permisos de administrador.
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo   Hacen falta permisos de administrador.
    echo   Windows va a preguntar. Acepta para continuar.
    echo.
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$ruta = Join-Path $env:SystemRoot 'System32\\drivers\\etc\\hosts';" ^
 "if (-not (Test-Path -LiteralPath $ruta)) {{ Write-Host '  No encuentro el archivo hosts.'; exit 1 }};" ^
 "$lineas = Get-Content -LiteralPath $ruta;" ^
 "$fuera = New-Object System.Collections.ArrayList;" ^
 "$dentro = $false; $quitadas = 0;" ^
 "foreach ($linea in $lineas) {{" ^
 "  if ($linea -like '*{SENAL_INICIO}*') {{ $dentro = $true }};" ^
 "  if ($dentro) {{ $quitadas++ }} else {{ [void]$fuera.Add($linea) }};" ^
 "  if ($linea -like '*{SENAL_FIN}*') {{ $dentro = $false }}" ^
 "}};" ^
 "if ($quitadas -eq 0) {{ Write-Host '  No habia ningun bloqueo puesto. Todo en orden.'; exit 0 }};" ^
 "$copia = $ruta + '.antes-del-rescate';" ^
 "Copy-Item -LiteralPath $ruta -Destination $copia -Force;" ^
 "$sinBom = New-Object System.Text.UTF8Encoding $false;" ^
 "[System.IO.File]::WriteAllLines($ruta, $fuera, $sinBom);" ^
 "Write-Host ('  Listo: quitadas ' + $quitadas + ' lineas del bloqueo.');" ^
 "Write-Host ('  Copia de como estaba: ' + $copia)"

echo.
echo   Si el navegador sigue sin entrar, cierralo del todo y vuelve a abrirlo:
echo   se guarda las direcciones un rato en su propia memoria.
echo.
pause
endlocal
"""


def escribir(carpeta: Path) -> Path:
    """Deja el .bat en esa carpeta y devuelve dónde quedó.

    Se reescribe siempre, sin preguntar: es un archivo generado, y uno viejo que
    busque unas marcas que ya no se usan sería peor que no tenerlo.
    """
    carpeta.mkdir(parents=True, exist_ok=True)
    destino = carpeta / NOMBRE
    # Codificación de la consola de Windows y saltos CRLF: un .bat con saltos de
    # Unix se ejecuta mal en algunas versiones, y con acentos raros enseña
    # símbolos en vez de texto.
    destino.write_text(contenido(), encoding="cp1252", newline="\r\n")
    return destino


def escribir_en_todas(carpetas: list[Path]) -> list[Path]:
    """Deja el rescate en varios sitios: el Escritorio y la carpeta de la app.

    Dos copias porque son dos momentos distintos. Si algo va mal HOY, vas a mirar
    al Escritorio. Dentro de un año, cuando ya no te acuerdes de nada, el que
    seguirá ahí es el de la carpeta de la aplicación.

    Si una carpeta falla —el Escritorio está en OneDrive y no responde, por
    ejemplo— se sigue con la otra: es mejor un rescate en un sitio que ninguno
    porque uno de los dos dio error.
    """
    escritos: list[Path] = []
    for carpeta in carpetas:
        try:
            escritos.append(escribir(carpeta))
        except OSError:
            continue
    return escritos


def carpeta_del_escritorio() -> Path:
    """El Escritorio del usuario.

    Se usa USERPROFILE y no una ruta fija porque el Escritorio puede estar
    redirigido a OneDrive, y en ese caso la carpeta "Desktop" de siempre existe
    pero no es la que ve el usuario.
    """
    import os

    perfil = Path(os.environ.get("USERPROFILE", str(Path.home())))
    onedrive = os.environ.get("OneDrive")
    if onedrive:
        con_onedrive = Path(onedrive) / "Desktop"
        if con_onedrive.is_dir():
            return con_onedrive
    for nombre in ("Desktop", "Escritorio"):
        candidata = perfil / nombre
        if candidata.is_dir():
            return candidata
    return perfil
