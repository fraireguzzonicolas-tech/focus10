"""Registrarse y entrar, hablando con el servicio de cuentas.

POR QUÉ UN SERVICIO Y NO UN SERVIDOR PROPIO: el usuario lo dijo claro —"quiero
evitar esa responsabilidad", hablando de la ciberseguridad—. Guardar contraseñas
de otra gente bien hecho es un oficio: hay que cifrarlas como toca, aguantar
intentos a lo bruto, hacer que "he olvidado mi contraseña" no sea una puerta
trasera, y responder si algo sale mal. Supabase se dedica a eso.

AQUÍ NO SE GUARDA NI SE VE NINGUNA CONTRASEÑA. Se manda al servicio y se olvida
en el acto. Lo que vuelve es un testigo que caduca en una hora.

LA CLAVE PÚBLICA ES PÚBLICA DE VERDAD, y por eso puede ir escrita aquí: está
pensada para viajar dentro de las aplicaciones, y sola no deja hacer nada. Quien
manda es la contraseña de cada uno y las reglas de acceso del propio servicio.
NO confundirla con la clave de servicio, que esa sí lo abre todo y NUNCA puede
estar en la aplicación.

MIENTRAS NO HAYA SERVIDOR, ESTO NO FINGE: sin `DIRECCION`, entrar falla con un
mensaje que lo dice. Una pantalla de registro que no registra es peor que no
tenerla.
"""

from __future__ import annotations

import json
from datetime import datetime

from . import red

from ..dominio.cuenta import (
    Sesion,
    caducidad,
    exigir_codigo,
    exigir_contrasena,
    exigir_correo,
)

DIRECCION = "https://qoipmbdnsafrrqccxsov.supabase.co"
"""La dirección del proyecto de Supabase, algo como
"https://abcdefgh.supabase.co". Se rellena con una línea cuando exista."""

CLAVE_PUBLICA = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFvaXBtYmRuc2FmcnJxY2N4c292Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg4MjMzOTMsImV4cCI6MjEwNDM5OTM5M30.QuuWzTRdaFsrlrfSqN1bRlE_i-V_jAl70lKnlLAVV44"
"""La clave "anon" del proyecto. Va aquí a propósito: ver la nota de arriba."""

BORRAR_CUENTA = "https://focus10-servidor.vercel.app/api/borrar_cuenta"
"""Dónde se pide borrar la cuenta entera.

NO LO PUEDE HACER LA APLICACIÓN SOLA: borrar un usuario de Supabase exige la
llave de servicio, que abre el proyecto entero. Esa llave vive en el servidor y
no sale de ahí. Ver servidor/api/borrar_cuenta.py.
"""

SEGUNDOS_DE_ESPERA = 20
"""Generoso: quien acaba de escribir su contraseña prefiere esperar a que le
digan "no se pudo" por tres segundos de red lenta."""


class NoSePudoEntrar(RuntimeError):
    """No se pudo entrar ni registrar, y el mensaje dice por qué en cristiano."""


def hay_servidor() -> bool:
    """Si esta versión tiene a dónde hablar."""
    return bool(DIRECCION and CLAVE_PUBLICA)


def _sin_conexion(fallo: Exception) -> str:
    """El mensaje de «no se pudo conectar», CON la causa técnica detrás.

    LA CAUSA VA EN PANTALLA A PROPÓSITO. Antes esta frase era la misma para
    todo: sin wifi, certificado rechazado, servidor caído o navegador
    bloqueando la petición. Cuando falló de verdad en la web, con «mira si
    tienes internet» no se podía ni empezar a mirar, y el usuario tenía
    internet. No es bonito, pero un mensaje bonito que no dice nada cuesta
    horas; esto se lee de una captura de pantalla.
    """
    detalle = fallo
    return (
        "no he podido conectar. Mira si tienes internet. "
        f"({type(fallo).__name__}: {str(detalle)[:120]})"
    )


def _pedir(camino: str, cuerpo: dict) -> dict:
    """El POST de verdad. Aparte para poder sustituirlo en los tests."""
    return _hablar(
        "POST",
        f"{DIRECCION.rstrip('/')}/auth/v1/{camino}",
        {"apikey": CLAVE_PUBLICA},
        cuerpo,
    )


def _hablar(metodo: str, url: str, cabeceras: dict, cuerpo: dict) -> dict:
    """La petición, con los fallos ya traducidos a español.

    VA POR sistema/red.py Y NO POR urllib: en el navegador urllib no puede
    salir a internet. Ver la cabecera de ese archivo.
    """
    try:
        crudo = red.pedir(
            url,
            metodo=metodo,
            cabeceras=cabeceras,
            cuerpo=cuerpo,
            segundos=SEGUNDOS_DE_ESPERA,
        )
        return json.loads(crudo) if crudo else {}
    except red.Contesto as fallo:
        raise NoSePudoEntrar(_lo_que_dijo(fallo)) from fallo
    except red.NoLlego as fallo:
        raise NoSePudoEntrar(_sin_conexion(fallo)) from fallo
    except ValueError as fallo:
        raise NoSePudoEntrar("el servidor ha contestado algo raro") from fallo



def _actualizar(testigo: str, cuerpo: dict) -> dict:
    """Cambia algo de la cuenta. Va aparte de `_pedir` porque NO es un POST.

    LLEVA EL TESTIGO ADEMAS DE LA CLAVE PUBLICA, y esa es toda la diferencia:
    la clave publica dice de que aplicacion viene, y el testigo dice QUIEN eres.
    Sin lo segundo, cualquiera podria cambiarle la contrasena a cualquiera.
    """
    return _hablar(
        "PUT",
        f"{DIRECCION.rstrip('/')}/auth/v1/user",
        {"apikey": CLAVE_PUBLICA, "Authorization": f"Bearer {testigo}"},
        cuerpo,
    )


def _lo_que_dijo(fallo) -> str:
    """Traduce el error del servicio a algo que se pueda leer.

    SE TRADUCE Y NO SE ENSEÑA TAL CUAL porque lo que manda Supabase viene en
    inglés y a veces es jerga. "Invalid login credentials" no le dice nada a
    quien solo quiere saber que se equivocó de contraseña.
    """
    try:
        dicho = json.loads(fallo.read())
    except Exception:
        dicho = {}

    crudo = " ".join(
        str(dicho.get(clave) or "")
        # SE MIRAN TODAS LAS CLAVES Y NO SOLO UNA: Supabase pone el motivo en
        # "msg" unas veces y en "error_code" otras (el codigo caducado, por
        # ejemplo). Quedarse con una sola dejaba media docena de fallos
        # saliendo como "el servicio ha contestado 403".
        for clave in ("msg", "error_description", "message", "error_code", "error")
    ).lower()

    if "invalid login" in crudo or fallo.code == 400 and "credential" in crudo:
        return "el correo o la contraseña no son correctos"
    if "already registered" in crudo or "already been registered" in crudo:
        return "ese correo ya tiene cuenta: entra en vez de registrarte"
    if "email not confirmed" in crudo:
        return "todavía no has confirmado el correo: mira tu bandeja de entrada"
    if "otp_expired" in crudo or "token has expired" in crudo:
        return "ese código ya no vale o está mal escrito. Pide otro."
    if "same as the old" in crudo or "should be different" in crudo:
        return "esa es la contraseña que ya tenías: pon una distinta"
    if fallo.code == 429:
        return "demasiados intentos seguidos: espera un momento"
    return f"el servicio de cuentas ha contestado {fallo.code}"


def _sesion_de(respuesta: dict, correo: str, ahora: datetime) -> Sesion:
    testigo = respuesta.get("access_token")
    refresco = respuesta.get("refresh_token")
    if not testigo or not refresco:
        # PASA CUANDO HACE FALTA CONFIRMAR EL CORREO: el registro sale bien pero
        # no hay sesión todavía. Decirlo es mejor que un error genérico.
        raise NoSePudoEntrar(
            "cuenta creada. Confirma el correo que te acaban de mandar y entra."
        )
    return Sesion(
        correo=correo,
        testigo=testigo,
        refresco=refresco,
        caduca_en=caducidad(ahora, int(respuesta.get("expires_in") or 3600)),
    )


def entrar(correo: str, contrasena: str, ahora: datetime, pedir=_pedir) -> Sesion:
    """Abre sesión con un correo y una contraseña ya existentes."""
    limpio = exigir_correo(correo)
    exigir_contrasena(contrasena)
    _exigir_servidor()

    respuesta = pedir(
        "token?grant_type=password", {"email": limpio, "password": contrasena}
    )
    return _sesion_de(respuesta, limpio, ahora)


def registrar(correo: str, contrasena: str, ahora: datetime, pedir=_pedir) -> Sesion:
    """Crea la cuenta. Si el servicio pide confirmar el correo, lo dice."""
    limpio = exigir_correo(correo)
    exigir_contrasena(contrasena)
    _exigir_servidor()

    respuesta = pedir("signup", {"email": limpio, "password": contrasena})
    return _sesion_de(respuesta, limpio, ahora)



def pedir_codigo(correo: str, pedir=_pedir) -> None:
    """Pide que manden el código de seis cifras a ese correo.

    NO DICE SI EL CORREO TIENE CUENTA O NO, y no es un descuido: el servicio
    contesta lo mismo en los dos casos a propósito. Si contestara "ese correo no
    existe", cualquiera podría ir probando direcciones para averiguar quién usa
    la aplicación. Así que aquí tampoco se inventa esa respuesta.
    """
    limpio = exigir_correo(correo)
    _exigir_servidor()
    pedir("recover", {"email": limpio})


def cambiar_contrasena(
    correo: str,
    codigo: str,
    nueva: str,
    ahora: datetime,
    pedir=_pedir,
    actualizar=_actualizar,
) -> Sesion:
    """Comprueba el código y pone la contraseña nueva. Devuelve la sesión.

    SON DOS PASOS Y NO UNO: el código sirve para abrir una sesión, y es esa
    sesión la que tiene permiso para cambiar la contraseña. Por eso quien
    termina el proceso YA ESTA DENTRO y no tiene que volver a entrar a mano.
    """
    limpio = exigir_correo(correo)
    cifras = exigir_codigo(codigo)
    exigir_contrasena(nueva)
    _exigir_servidor()

    respuesta = pedir(
        "verify", {"email": limpio, "token": cifras, "type": "recovery"}
    )
    sesion = _sesion_de(respuesta, limpio, ahora)
    actualizar(sesion.testigo, {"password": nueva})
    return sesion


def renovar(sesion: Sesion, ahora: datetime, pedir=_pedir) -> Sesion:
    """Pide un testigo nuevo sin volver a escribir la contraseña.

    ES LO QUE EVITA PEDIR LA CONTRASEÑA CADA HORA. El testigo dura poco a
    propósito; el de refresco dura mucho y solo sirve para esto.
    """
    _exigir_servidor()
    respuesta = pedir(
        "token?grant_type=refresh_token", {"refresh_token": sesion.refresco}
    )
    return _sesion_de(respuesta, sesion.correo, ahora)


def borrar_cuenta(sesion: Sesion, pedir=None) -> None:
    """Borra del servidor los datos de esa cuenta y la cuenta misma.

    NO SE DESHACE. Quien llama tiene que haber preguntado antes.

    SE MANDA EL TESTIGO Y NADA MÁS: el servidor le pregunta a Supabase de quién
    es y borra ESE usuario. Así, aunque alguien llame a esa dirección a mano,
    solo puede borrar lo suyo.
    """
    _exigir_servidor()
    hacerlo = pedir or _borrar_de_verdad
    hacerlo(sesion.testigo)


def _borrar_de_verdad(testigo: str) -> None:
    try:
        red.pedir(
            BORRAR_CUENTA,
            metodo="POST",
            cabeceras={"Authorization": f"Bearer {testigo}"},
            cuerpo={},
            segundos=SEGUNDOS_DE_ESPERA,
        )
    except red.Contesto as fallo:
        raise NoSePudoEntrar(
            f"el servidor no ha podido borrar la cuenta ({fallo.code})"
        ) from fallo
    except red.NoLlego as fallo:
        raise NoSePudoEntrar(_sin_conexion(fallo)) from fallo


def _exigir_servidor() -> None:
    if not hay_servidor():
        raise NoSePudoEntrar(
            "todavía no hay servicio de cuentas configurado: falta poner "
            "DIRECCION y CLAVE_PUBLICA en sistema/cuentas.py"
        )
