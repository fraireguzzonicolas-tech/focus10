"""Registrarse y entrar, hablando con el servicio de cuentas.

POR QUÉ UN SERVICIO Y NO UN SERVIDOR PROPIO: el usuario lo dijo claro —"quiero
evitar esa responsabilidad", hablando de la ciberseguridad—. Guardar contraseñas
de otra gente bien hecho es un oficio: hay que cifrarlas como toca, aguantar
intentos a lo bruto, hacer que "he olvidado mi contraseña" no sea una puerta
trasera, y responder si algo sale mal. Supabase se dedica a eso.

AQUÍ NO SE GUARDA NI SE VE NINGUNA CONTRASEÑA. Se manda al servicio y se olvida
en el acto. Lo que vuelve es un testigo que caduca en una hora.

LA CLAVE PÚBLICA ES PÚBLICA DE VERDAD, y por eso puede ir escrita aquí: está
pensada para viajar dentro de las aplicaciones, y sola no deja hacer nada. Quien
manda es la contraseña de cada uno y las reglas de acceso del propio servicio.
NO confundirla con la clave de servicio, que esa sí lo abre todo y NUNCA puede
estar en la aplicación.

MIENTRAS NO HAYA SERVIDOR, ESTO NO FINGE: sin `DIRECCION`, entrar falla con un
mensaje que lo dice. Una pantalla de registro que no registra es peor que no
tenerla.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from datetime import datetime

from ..dominio.cuenta import Sesion, caducidad, exigir_contrasena, exigir_correo

DIRECCION = "https://qoipmbdnsafrrqccxsov.supabase.co"
"""La dirección del proyecto de Supabase, algo como
"https://abcdefgh.supabase.co". Se rellena con una línea cuando exista."""

CLAVE_PUBLICA = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFvaXBtYmRuc2FmcnJxY2N4c292Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg4MjMzOTMsImV4cCI6MjEwNDM5OTM5M30.QuuWzTRdaFsrlrfSqN1bRlE_i-V_jAl70lKnlLAVV44"
"""La clave "anon" del proyecto. Va aquí a propósito: ver la nota de arriba."""

SEGUNDOS_DE_ESPERA = 20
"""Generoso: quien acaba de escribir su contraseña prefiere esperar a que le
digan "no se pudo" por tres segundos de red lenta."""


class NoSePudoEntrar(RuntimeError):
    """No se pudo entrar ni registrar, y el mensaje dice por qué en cristiano."""


def hay_servidor() -> bool:
    """Si esta versión tiene a dónde hablar."""
    return bool(DIRECCION and CLAVE_PUBLICA)


def _pedir(camino: str, cuerpo: dict) -> dict:
    """El POST de verdad. Aparte para poder sustituirlo en los tests."""
    try:
        import truststore

        truststore.inject_into_ssl()
    except ImportError:
        pass

    peticion = urllib.request.Request(
        f"{DIRECCION.rstrip('/')}/auth/v1/{camino}",
        data=json.dumps(cuerpo).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "apikey": CLAVE_PUBLICA,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(peticion, timeout=SEGUNDOS_DE_ESPERA) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as fallo:
        raise NoSePudoEntrar(_lo_que_dijo(fallo)) from fallo
    except (urllib.error.URLError, TimeoutError, OSError) as fallo:
        raise NoSePudoEntrar(
            "no he podido conectar. Mira si tienes internet."
        ) from fallo
    except ValueError as fallo:
        raise NoSePudoEntrar("el servidor ha contestado algo raro") from fallo


def _lo_que_dijo(fallo) -> str:
    """Traduce el error del servicio a algo que se pueda leer.

    SE TRADUCE Y NO SE ENSEÑA TAL CUAL porque lo que manda Supabase viene en
    inglés y a veces es jerga. "Invalid login credentials" no le dice nada a
    quien solo quiere saber que se equivocó de contraseña.
    """
    try:
        dicho = json.loads(fallo.read())
    except Exception:
        dicho = {}

    crudo = str(
        dicho.get("msg") or dicho.get("error_description") or dicho.get("message") or ""
    ).lower()

    if "invalid login" in crudo or fallo.code == 400 and "credential" in crudo:
        return "el correo o la contraseña no son correctos"
    if "already registered" in crudo or "already been registered" in crudo:
        return "ese correo ya tiene cuenta: entra en vez de registrarte"
    if "email not confirmed" in crudo:
        return "todavía no has confirmado el correo: mira tu bandeja de entrada"
    if fallo.code == 429:
        return "demasiados intentos seguidos: espera un momento"
    return f"el servicio de cuentas ha contestado {fallo.code}"


def _sesion_de(respuesta: dict, correo: str, ahora: datetime) -> Sesion:
    testigo = respuesta.get("access_token")
    refresco = respuesta.get("refresh_token")
    if not testigo or not refresco:
        # PASA CUANDO HACE FALTA CONFIRMAR EL CORREO: el registro sale bien pero
        # no hay sesión todavía. Decirlo es mejor que un error genérico.
        raise NoSePudoEntrar(
            "cuenta creada. Confirma el correo que te acaban de mandar y entra."
        )
    return Sesion(
        correo=correo,
        testigo=testigo,
        refresco=refresco,
        caduca_en=caducidad(ahora, int(respuesta.get("expires_in") or 3600)),
    )


def entrar(correo: str, contrasena: str, ahora: datetime, pedir=_pedir) -> Sesion:
    """Abre sesión con un correo y una contraseña ya existentes."""
    limpio = exigir_correo(correo)
    exigir_contrasena(contrasena)
    _exigir_servidor()

    respuesta = pedir(
        "token?grant_type=password", {"email": limpio, "password": contrasena}
    )
    return _sesion_de(respuesta, limpio, ahora)


def registrar(correo: str, contrasena: str, ahora: datetime, pedir=_pedir) -> Sesion:
    """Crea la cuenta. Si el servicio pide confirmar el correo, lo dice."""
    limpio = exigir_correo(correo)
    exigir_contrasena(contrasena)
    _exigir_servidor()

    respuesta = pedir("signup", {"email": limpio, "password": contrasena})
    return _sesion_de(respuesta, limpio, ahora)


def renovar(sesion: Sesion, ahora: datetime, pedir=_pedir) -> Sesion:
    """Pide un testigo nuevo sin volver a escribir la contraseña.

    ES LO QUE EVITA PEDIR LA CONTRASEÑA CADA HORA. El testigo dura poco a
    propósito; el de refresco dura mucho y solo sirve para esto.
    """
    _exigir_servidor()
    respuesta = pedir(
        "token?grant_type=refresh_token", {"refresh_token": sesion.refresco}
    )
    return _sesion_de(respuesta, sesion.correo, ahora)


def _exigir_servidor() -> None:
    if not hay_servidor():
        raise NoSePudoEntrar(
            "todavía no hay servicio de cuentas configurado: falta poner "
            "DIRECCION y CLAVE_PUBLICA en sistema/cuentas.py"
        )
