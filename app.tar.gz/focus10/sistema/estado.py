"""El papelito que se dejan el programa normal y el guardián elevado.

POR QUÉ UN ARCHIVO Y NO ALGO MÁS FINO: son dos procesos distintos, uno de ellos
con permisos de administrador. Un archivo de texto plano se puede leer con el
Bloc de notas cuando algo va mal, sobrevive a que los dos procesos mueran, y no
abre ningún puerto ni canal que otro programa pueda usar para mandarle órdenes al
proceso elevado. Para algo que corre como administrador, eso último importa más
que la elegancia.

LAS CUATRO MANERAS DE QUE EL BLOQUEO SE SUELTE, que pidió el usuario:

  1. Termina la fase de trabajo   -> el programa normal pone activo = False.
  2. Cierro la aplicación         -> igual, al cerrar.
  3. La aplicación se cuelga      -> el LATIDO deja de actualizarse y el
                                     guardián lo nota.
  4. Pase lo que pase             -> el LÍMITE absoluto, una hora escrita en el
                                     archivo que el guardián respeta aunque no
                                     entienda nada más.

Las cuatro las decide el guardián leyendo esto. Ninguna depende de que el
programa normal siga vivo para pedirlo, que es justo el caso en el que hace
falta.

LAS FECHAS SE GUARDAN COMO SEGUNDOS DESDE 1970 Y EN UTC. Con la hora local, un
cambio de horario de verano movería el límite una hora entera en el peor momento.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

VERSION = 1
"""Sube si cambia la FORMA del archivo. El guardián se niega a obedecer un
archivo de una versión que no conoce: ante la duda, desbloquea."""

NOMBRE = "bloqueo.json"

TOLERANCIA_LATIDO = 90.0
"""Segundos sin latido tras los cuales se da la aplicación por muerta.

Noventa y no diez: el programa late cada quince segundos, y un ordenador que se
queda pensando —una actualización, un antivirus revisando, la tapa cerrada un
momento— puede tardar bastante más de diez. Con un margen corto, el bloqueo se
soltaría solo a media sesión de trabajo, que es peor que soltarse tarde.
"""

@dataclass(frozen=True)
class Estado:
    """Lo que el programa normal le cuenta al guardián."""

    activo: bool
    """False es una orden directa: suelta el bloqueo ya."""

    latido: float
    """Cuándo dio señales de vida el programa normal por última vez."""

    limite: float
    """A partir de aquí se suelta pase lo que pase."""

    dominios: tuple[str, ...] = ()
    ruta_hosts: str = ""
    ruta_copia: str = ""
    version: int = VERSION

    def a_json(self) -> str:
        return json.dumps(
            {
                "version": self.version,
                "activo": self.activo,
                "latido": self.latido,
                "limite": self.limite,
                "dominios": list(self.dominios),
                "ruta_hosts": self.ruta_hosts,
                "ruta_copia": self.ruta_copia,
            },
            indent=2,
        )

    def debe_soltar(self, ahora: float, tolerancia: float = TOLERANCIA_LATIDO) -> str:
        """Por qué hay que soltar el bloqueo, o cadena vacía si no hay que soltarlo.

        Devuelve el MOTIVO y no un sí/no para poder escribirlo en el registro: el
        día que el bloqueo se suelte cuando no debía, saber si fue el latido o el
        límite es la diferencia entre arreglarlo y adivinar.
        """
        if self.version != VERSION:
            return "el archivo de estado es de otra versión"
        if not self.activo:
            return "la aplicación pidió soltar"
        if ahora >= self.limite:
            return "se alcanzó la hora límite"
        if ahora - self.latido > tolerancia:
            return "la aplicación dejó de dar señales de vida"
        return ""


def desde_json(texto: str) -> Estado | None:
    """Lee el estado, o None si el archivo no se entiende.

    NO REVIENTA CON UN ARCHIVO ROTO, y es a propósito: quien llama a esto es el
    guardián, que corre como administrador. Si un archivo medio escrito lo
    tumbara, el bloqueo se quedaría puesto sin nadie que lo quite, que es
    exactamente el desastre que hay que evitar. None significa "no me fío", y
    ante la duda se suelta.
    """
    try:
        datos = json.loads(texto)
    except (ValueError, TypeError):
        return None
    # ESTA COMPROBACIÓN NO CAMBIA NADA Y SE QUEDA. Lo probé quitándola: con una
    # lista, un número o un "null", el datos["version"] de abajo lanza TypeError
    # y el except lo convierte en None igualmente. Ningún test puede notar la
    # diferencia. Se queda porque dice en voz alta lo que se espera del archivo
    # —un objeto—, en vez de dejar que se descubra al estrellarse tres líneas
    # más abajo. En un archivo que gobierna un proceso con permisos de
    # administrador, prefiero que la intención esté escrita.
    if not isinstance(datos, dict):
        return None
    try:
        return Estado(
            version=int(datos["version"]),
            activo=bool(datos["activo"]),
            latido=float(datos["latido"]),
            limite=float(datos["limite"]),
            dominios=tuple(str(uno) for uno in datos.get("dominios", [])),
            ruta_hosts=str(datos.get("ruta_hosts", "")),
            ruta_copia=str(datos.get("ruta_copia", "")),
        )
    except (KeyError, TypeError, ValueError):
        return None


def ruta(carpeta: Path) -> Path:
    return carpeta / NOMBRE


def guardar(carpeta: Path, estado: Estado) -> Path:
    """Escribe el estado de forma que nunca se lea a medias.

    Se escribe en un archivo temporal y luego se REEMPLAZA de golpe. Sin esto, el
    guardián podría leer justo mientras se escribe, encontrar medio archivo, no
    entenderlo y soltar el bloqueo a mitad de una sesión de trabajo.
    """
    carpeta.mkdir(parents=True, exist_ok=True)
    destino = ruta(carpeta)
    temporal = destino.with_suffix(".tmp")
    temporal.write_text(estado.a_json(), encoding="utf-8")
    temporal.replace(destino)
    return destino


def leer(carpeta: Path) -> Estado | None:
    """El estado guardado, o None si no hay o no se entiende."""
    archivo = ruta(carpeta)
    try:
        return desde_json(archivo.read_text(encoding="utf-8"))
    except OSError:
        return None


def limite_para(fin_de_fase: float, margen: float = 15 * 60) -> float:
    """La hora límite absoluta: lo que dure la fase de trabajo más un margen.

    El margen lo eligió el usuario: quince minutos. Es lo más ajustado que no te
    deja tirado. Si la aplicación muere, como mucho aguantas un cuarto de hora de
    bloqueo de más; con cuatro horas fijas podrías estar toda la tarde sin poder
    entrar a una web por un cuelgue.
    """
    return fin_de_fase + margen
