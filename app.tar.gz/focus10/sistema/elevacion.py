"""Pedir permisos de administrador para arrancar el guardián. UNA vez por sesión.

POR QUÉ UNA VEZ Y NO POR POMODORO: lo pidió el usuario, y además es lo correcto.
Un permiso que Windows te pide cada veinticinco minutos se acaba concediendo sin
mirar, y entonces el aviso deja de proteger de nada. Se pide al encender el
bloqueo de webs por primera vez, y el guardián se queda vivo hasta que se cierra
la aplicación.

CÓMO SE PIDE: con ShellExecuteW y el verbo "runas", que es la forma normal de
Windows de decir "abre esto como administrador". Windows enseña su ventana de
siempre; nosotros no vemos ni tocamos ninguna contraseña, solo recibimos un
número que dice si la persona aceptó o no.

LO QUE NO SE PUEDE PROBAR SOLO: que la ventana del UAC salga y que alguien la
acepte. Eso exige una persona delante. Los tests de aquí prueban todo lo demás
—qué comando se construye, cómo se leen las respuestas, qué pasa si dicen que
no— y la parte humana la comprueba el usuario. Está dicho así en el README en
vez de dar por bueno lo que no se ha visto funcionar.
"""

from __future__ import annotations

import ctypes
import sys
from dataclasses import dataclass
from pathlib import Path

MOSTRAR_NORMAL = 1
SW_OCULTO = 0

#: ShellExecuteW devuelve un número: por encima de 32 es que arrancó.
UMBRAL_EXITO = 32

RECHAZADO = (5,)
"""El código con el que ShellExecuteW dice "la persona no dio permiso"
(SE_ERR_ACCESSDENIED).

AQUÍ NO VA EL 1223. Lo puse al escribir esto, de memoria: 1223 es
ERROR_CANCELLED, y es lo que contesta GetLastError, NO lo que devuelve
ShellExecuteW. Meterlo era peor que inútil: 1223 es mayor que 32, así que la
comprobación de "arrancó" lo pillaba antes y un rechazo se habría dado por
bloqueo activo. Lo cazó el test, que probaba los dos códigos por separado.
"""


@dataclass(frozen=True)
class Intento:
    """Cómo salió el intento de arrancar el guardián."""

    arrancado: bool
    rechazado: bool
    """True si la persona dijo que no. Se distingue de un fallo técnico: no es
    lo mismo "no quiero" que "algo va mal", y el mensaje en pantalla es otro."""

    detalle: str = ""

    def mensaje(self) -> str:
        """Lo que se le enseña al usuario. Nunca miente sobre lo que hay."""
        if self.arrancado:
            return "El bloqueo de webs está activo."
        if self.rechazado:
            return (
                "No diste permiso de administrador, así que las webs NO se van a "
                "bloquear. El pomodoro y el cierre de programas funcionan igual."
            )
        return (
            "No se pudo arrancar el bloqueo de webs, así que NO se están "
            f"bloqueando. {self.detalle}".strip()
        )


def interprete_sin_consola() -> Path:
    """El pythonw.exe del mismo entorno, para que no salga una ventana negra.

    Se busca al lado del python.exe que está corriendo, no en el PATH: en una
    máquina con tres Pythons instalados, el del PATH puede no ser el que tiene
    las cosas de esta aplicación. Si no está, se usa el normal: una ventana
    negra molesta, no funcionar es peor.
    """
    actual = Path(sys.executable)
    sin_consola = actual.with_name("pythonw.exe")
    return sin_consola if sin_consola.exists() else actual


def orden_del_guardian(carpeta_estado: Path, ruta_hosts: Path | None = None) -> str:
    """Los argumentos con los que se arranca el guardián.

    La carpeta va SIEMPRE como argumento y no se calcula dentro del guardián: al
    elevar, Windows puede darle al proceso nuevo un usuario distinto y, con él,
    otra carpeta de datos. Pasarla a mano es lo único que garantiza que los dos
    procesos miran el mismo papelito.

    Las rutas van entre comillas porque en Windows llevan espacios casi siempre
    ("Proyect Claude Code" ya los tiene). Sin comillas, el guardián recibiría
    tres argumentos partidos y no encontraría nada.
    """
    partes = ["-m", "focus10.sistema.guardian", f'"{carpeta_estado}"']
    if ruta_hosts is not None:
        partes.append(f'"{ruta_hosts}"')
    return " ".join(partes)


def _shell_execute(programa: str, argumentos: str, carpeta: str) -> int:
    """La llamada de Windows, aparte para poder sustituirla en los tests."""
    return int(
        ctypes.windll.shell32.ShellExecuteW(
            None, "runas", programa, argumentos, carpeta, SW_OCULTO
        )
    )


def arrancar_guardian(
    carpeta_estado: Path,
    raiz_del_codigo: Path,
    ruta_hosts: Path | None = None,
    ejecutar=_shell_execute,
) -> Intento:
    """Pide el UAC y arranca el guardián. Devuelve qué pasó, sin adornos.

    `raiz_del_codigo` es la carpeta desde la que se lanza, para que el "-m
    focus10.sistema.guardian" encuentre el paquete: el proceso elevado no hereda
    el sys.path de este.
    """
    interprete = interprete_sin_consola()
    orden = orden_del_guardian(carpeta_estado, ruta_hosts)

    try:
        codigo = ejecutar(str(interprete), orden, str(raiz_del_codigo))
    except (AttributeError, OSError) as fallo:
        return Intento(arrancado=False, rechazado=False, detalle=str(fallo))

    # El rechazo se mira ANTES que el éxito, aunque hoy no haga falta porque el
    # 5 es menor que 32. Al revés, el día que se añada aquí un código grande por
    # error, un "no doy permiso" pasaría por "bloqueo activo" sin que nadie lo
    # note. Ese error ya lo cometí una vez con el 1223.
    if codigo in RECHAZADO:
        return Intento(arrancado=False, rechazado=True)
    if codigo > UMBRAL_EXITO:
        return Intento(arrancado=True, rechazado=False)
    return Intento(
        arrancado=False,
        rechazado=False,
        detalle=f"Windows devolvió el código {codigo}.",
    )
