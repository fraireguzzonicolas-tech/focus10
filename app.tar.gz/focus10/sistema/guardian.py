"""El guardián: el único trozo del programa que corre como administrador.

QUÉ HACE Y NADA MÁS: pone el bloqueo en el archivo hosts, vigila el papelito de
estado, y lo quita en cuanto toca. No abre ventanas, no consulta internet, no
lee la base de datos, no cierra programas. Cuanto menos haga algo que corre como
administrador, menos puede salir mal.

SE ARRANCA UNA VEZ POR SESIÓN, no por pomodoro: así el UAC de Windows sale una
sola vez al abrir Focus10 y no cada veinticinco minutos. Lo pidió el usuario y
además es lo correcto: un permiso que se pide cada rato se acaba concediendo sin
leerlo.

LA LISTA PROTEGIDA ESTÁ AQUÍ OTRA VEZ, A MANO Y COMPLETA. No se importa de
dominio/dominios.py y no es un descuido: este proceso tiene permisos para
estropear el arranque de Windows, y tiene que poder negarse aunque lo que le
llegue venga de una versión distinta de la aplicación, de un archivo manipulado,
o de un módulo que alguien haya cambiado. Dos cerraduras con la misma llave no
son dos cerraduras. El test test_guardian.py comprueba que las dos listas dicen
lo mismo, para que no se separen por descuido.

CÓMO SE PRUEBA: todo lo de decidir es una función pura a la que se le pasa la
carpeta y el reloj. Los tests le dan un hosts falso en una carpeta temporal. Este
archivo no se ejecuta como administrador en ningún test.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

# Ojo: importar del paquete solo lo que NO decide sobre seguridad. Las funciones
# de texto del hosts se reutilizan porque son puras y están muy probadas; la
# lista protegida, no: esa se repite abajo a propósito.
from . import hosts
from .estado import leer

#: La misma lista que dominio/dominios.py, escrita aparte a propósito.
#: Si añades uno allí, añádelo aquí. El test lo exige.
PROTEGIDOS_GUARDIAN: frozenset[str] = frozenset(
    {
        "claude.ai",
        "anthropic.com",
        "claude.com",
        "google.com",
        "translate.google.com",
        "deepl.com",
        "wordreference.com",
        "wikipedia.org",
        "wikimedia.org",
        "rae.es",
        "dle.rae.es",
        "localhost",
        "localhost.localdomain",
        "microsoft.com",
        "windows.com",
        "windowsupdate.com",
        "microsoftonline.com",
        "live.com",
        "msftconnecttest.com",
        "msftncsi.com",
    }
)

SEGUNDOS_ENTRE_VUELTAS = 5.0
"""Cada cuánto mira el guardián el papelito. Cinco segundos: lo bastante rápido
para que el desbloqueo se note al acabar el pomodoro, y lo bastante lento para
no estar abriendo un archivo sin parar."""


def es_protegido_aqui(dominio: str) -> bool:
    """La comprobación propia del guardián, sin fiarse de nadie.

    Normaliza a lo bruto —minúsculas, sin espacios, sin punto final— y compara
    etiqueta a etiqueta. Es a propósito más simple que la del dominio: aquí no
    hace falta entender URLs, hace falta no equivocarse.
    """
    if not isinstance(dominio, str):
        return True  # ante la duda, protegido
    limpio = dominio.strip().lower().rstrip(".")
    if not limpio:
        return True
    return any(
        limpio == protegido or limpio.endswith("." + protegido)
        for protegido in PROTEGIDOS_GUARDIAN
    )


def filtrar(dominios: tuple[str, ...]) -> list[str]:
    """Lo que el guardián acepta bloquear de lo que le han pedido.

    Lo protegido no se bloquea y no se avisa con una excepción: se descarta y
    punto. Un guardián que se cae por un dominio raro deja el hosts a medias.
    """
    return [uno for uno in dominios if not es_protegido_aqui(uno)]


def aplicar(carpeta: Path, ruta_hosts: Path, dominios: tuple[str, ...]) -> list[str]:
    """Pone el bloqueo. Devuelve lo que de verdad se bloqueó."""
    aceptados = filtrar(dominios)
    hosts.guardar_copia(ruta_hosts, carpeta)
    texto = hosts.leer(ruta_hosts)
    hosts.escribir(ruta_hosts, hosts.poner_bloque(texto, aceptados))
    return aceptados


def soltar(ruta_hosts: Path) -> None:
    """Quita nuestro bloque del hosts, dejando el resto intacto.

    NO restaura la copia por encima: si el usuario o un antivirus añadieron una
    línea mientras trabajábamos, restaurar la copia se la comería. Quitar solo lo
    nuestro es la operación segura, y por eso la copia es un último recurso y no
    el camino normal.
    """
    texto = hosts.leer(ruta_hosts)
    if hosts.tiene_bloque(texto):
        hosts.escribir(ruta_hosts, hosts.quitar_bloque(texto))


def una_vuelta(carpeta: Path, ahora: float, ruta_hosts: Path) -> str:
    """Una pasada del guardián. Devuelve qué hizo, para el registro.

    Es la función que se prueba: se le da una carpeta temporal, un hosts falso y
    la hora que se quiera, y se mira qué contesta. Así se puede comprobar el caso
    "la aplicación lleva media hora muerta" sin esperar media hora.
    """
    estado = leer(carpeta)
    if estado is None:
        # Sin papelito o con el papelito roto: se suelta. Es la postura segura,
        # y la única que no depende de entender nada.
        soltar(ruta_hosts)
        return "sin estado válido: soltado"

    motivo = estado.debe_soltar(ahora)
    if motivo:
        soltar(ruta_hosts)
        return f"soltado ({motivo})"

    puestos = hosts.dominios_bloqueados(hosts.leer(ruta_hosts))
    esperados = []
    for uno in filtrar(estado.dominios):
        esperados.extend(hosts.variantes_para_hosts(uno))
    if sorted(puestos) != sorted(set(esperados)):
        aplicar(carpeta, ruta_hosts, estado.dominios)
        return "bloqueo puesto al día"
    return "sin cambios"


def vigilar(carpeta: Path, ruta_hosts: Path, dormir=time.sleep) -> str:
    """El bucle de verdad. Termina cuando suelta el bloqueo.

    `dormir` se recibe para que un test pueda pasarle una función que no duerme.
    Sin eso, probar el bucle costaría segundos reales por vuelta.
    """
    while True:
        resultado = una_vuelta(carpeta, time.time(), ruta_hosts)
        if resultado.startswith("soltado") or resultado.startswith("sin estado"):
            return resultado
        dormir(SEGUNDOS_ENTRE_VUELTAS)


def main(argumentos: list[str] | None = None) -> int:
    """Punto de entrada del proceso elevado.

    Recibe la carpeta del estado como argumento en vez de calcularla: al elevar,
    Windows puede darle a este proceso un usuario distinto y, con él, otra carpeta
    de datos. Pasarla a mano es lo único que garantiza que los dos procesos miran
    el mismo papelito.
    """
    argumentos = sys.argv[1:] if argumentos is None else argumentos
    if not argumentos:
        print("uso: guardian.py <carpeta-de-estado> [ruta-hosts]")
        return 2

    carpeta = Path(argumentos[0])
    ruta_hosts = Path(argumentos[1]) if len(argumentos) > 1 else hosts.ruta_del_sistema()

    try:
        resultado = vigilar(carpeta, ruta_hosts)
    except Exception as fallo:  # noqa: BLE001
        # Pase lo que pase, se intenta soltar antes de morir. Un guardián que se
        # muere con el bloqueo puesto es el peor final posible.
        try:
            soltar(ruta_hosts)
        except Exception:  # noqa: BLE001
            pass
        print(f"el guardián falló y soltó el bloqueo: {fallo}")
        return 1

    print(resultado)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
