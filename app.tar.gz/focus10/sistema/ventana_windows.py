"""Que Windows reconozca la ventana como Focus1% y no como «Flet».

EL PROBLEMA QUE RESUELVE: en la PC la ventana no la abre nuestro Python, la
abre el programa de Flet (flet.exe), que es un proceso aparte. Windows agrupa
los botones de la barra de tareas por programa, así que veía dos cosas
distintas: el ícono anclado de Focus1% (que arranca pythonw.exe, sin ventana)
y una ventana de «Flet» con el logo de Flet. Lo vio el usuario: tocaba Focus y
aparecía otro ícono al lado.

LA SOLUCIÓN QUE DA WINDOWS PARA ESTE CASO —un lanzador que abre la ventana
desde otro proceso— es ponerle a la ventana una «identidad de aplicación»
(AppUserModelID) y decirle cómo volver a abrirla (el comando, el nombre y el
ícono). Con eso:

- la barra de tareas la muestra con el ícono y el nombre de Focus1%;
- al anclarla, el ancla abre Focus (pythonw abrir.py), no Flet;
- y las siguientes veces la ventana cae en ese mismo botón anclado.

SE HABLA CON WINDOWS DIRECTAMENTE (ctypes) y no con una librería: son cuatro
llamadas y no merece la pena sumar una dependencia para eso.

SI ALGO FALLA, NO PASA NADA GRAVE: se devuelve False y la aplicación sigue
abierta, solo que con el ícono de Flet. Nunca es motivo para no arrancar.
"""

from __future__ import annotations

import ctypes
import os
import sys
from ctypes import wintypes
from pathlib import Path

ID_DE_LA_APP = "Focus10.Escritorio"
"""La identidad que comparten la ventana y el acceso directo. Windows junta en
un mismo botón todo lo que tenga la misma; por eso es una constante y la usa
también herramientas/poner_en_escritorio.py."""

CLASE_DE_VENTANA_FLET = "FLUTTER_RUNNER_WIN32_WINDOW"
"""Así se llama por dentro la ventana que abre Flet (es una app de Flutter)."""


def orden_de_relanzar(python: Path, lanzador: Path) -> str:
    """El comando que ejecuta el ícono anclado para volver a abrir Focus.

    CON COMILLAS: la carpeta del proyecto tiene espacios («Proyect Claude
    Code»), y sin ellas Windows cortaría la ruta en el primer espacio.
    """
    return f'"{python}" "{lanzador}"'


def python_sin_consola() -> Path:
    """pythonw.exe, el Python que no abre ventana negra de consola.

    Es el mismo que usa el acceso directo del escritorio. Si por lo que sea no
    está, el que está corriendo: peor (deja una consola), pero abre.
    """
    actual = Path(sys.executable)
    sin_consola = actual.with_name("pythonw.exe")
    return sin_consola if sin_consola.is_file() else actual


# --- Lo que hace falta de Windows --------------------------------------------


class _GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", wintypes.DWORD),
        ("Data2", wintypes.WORD),
        ("Data3", wintypes.WORD),
        ("Data4", ctypes.c_ubyte * 8),
    ]

    @classmethod
    def de(cls, texto: str) -> _GUID:
        guid = cls()
        ctypes.oledll.ole32.CLSIDFromString(texto, ctypes.byref(guid))
        return guid


class _PROPERTYKEY(ctypes.Structure):
    _fields_ = [("fmtid", _GUID), ("pid", wintypes.DWORD)]


class _PROPVARIANT(ctypes.Structure):
    # Solo el caso que se usa: un texto (VT_LPWSTR). El relleno del final da
    # al hueco el tamaño real de un PROPVARIANT, que Windows lee entero.
    _fields_ = [
        ("vt", ctypes.c_ushort),
        ("reservado1", ctypes.c_ushort),
        ("reservado2", ctypes.c_ushort),
        ("reservado3", ctypes.c_ushort),
        ("texto", ctypes.c_wchar_p),
        ("relleno", ctypes.c_void_p),
    ]


_VT_LPWSTR = 31
_IID_IPROPERTYSTORE = "{886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99}"
_GRUPO_APPUSERMODEL = "{9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3}"
_RELANZAR_ORDEN = 2
_RELANZAR_ICONO = 3
_RELANZAR_NOMBRE = 4
_ID = 5

# Los huecos de IPropertyStore, contando los tres de IUnknown.
_LIBERAR = 2
_PONER = 6
_GUARDAR = 7


def _llamar(objeto: ctypes.c_void_p, hueco: int, *argumentos) -> int:
    """Llama al método número `hueco` de un objeto COM."""
    tabla = ctypes.cast(objeto, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p)))[0]
    tipos = [ctypes.c_void_p] + [type(a) for a in argumentos]
    metodo = ctypes.WINFUNCTYPE(ctypes.HRESULT, *tipos)(tabla[hueco])
    return metodo(objeto, *argumentos)


def _poner_textos(almacen: ctypes.c_void_p, textos: list[tuple[int, str]]) -> None:
    grupo = _GUID.de(_GRUPO_APPUSERMODEL)
    for numero, texto in textos:
        clave = _PROPERTYKEY(grupo, numero)
        valor = _PROPVARIANT(vt=_VT_LPWSTR, texto=texto)
        _llamar(almacen, _PONER, ctypes.pointer(clave), ctypes.pointer(valor))


def _procesos_hijos(padre: int) -> set[int]:
    """Los procesos que arrancó este. flet.exe es uno de ellos."""

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.c_void_p),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", ctypes.c_long),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", ctypes.c_wchar * 260),
        ]

    kernel = ctypes.windll.kernel32
    kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    foto = kernel.CreateToolhelp32Snapshot(0x2, 0)  # 0x2: la lista de procesos
    hijos: set[int] = set()
    entrada = PROCESSENTRY32W(dwSize=ctypes.sizeof(PROCESSENTRY32W))
    try:
        hay = kernel.Process32FirstW(foto, ctypes.byref(entrada))
        while hay:
            if entrada.th32ParentProcessID == padre:
                hijos.add(entrada.th32ProcessID)
            hay = kernel.Process32NextW(foto, ctypes.byref(entrada))
    finally:
        kernel.CloseHandle(foto)
    return hijos


def _ventana_de_flet(padre: int) -> int | None:
    """La ventana de Flet que abrió ESTE Focus, no otra.

    POR EL PROCESO Y NO SOLO POR EL NOMBRE: si hubiera otra app hecha con Flet
    abierta, tiene la misma clase de ventana; sin mirar quién la abrió se le
    podría cambiar la identidad a esa.
    """
    usuario = ctypes.windll.user32
    hijos = _procesos_hijos(padre)
    encontrada: list[int] = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def mirar(ventana, _):
        clase = ctypes.create_unicode_buffer(64)
        usuario.GetClassNameW(ventana, clase, 64)
        if clase.value == CLASE_DE_VENTANA_FLET:
            proceso = wintypes.DWORD()
            usuario.GetWindowThreadProcessId(ventana, ctypes.byref(proceso))
            if proceso.value in hijos:
                encontrada.append(ventana)
                return False
        return True

    usuario.EnumWindows(mirar, 0)
    return encontrada[0] if encontrada else None


def presentarse(nombre: str, icono: Path, lanzador: Path) -> bool:
    """Le pone a la ventana de Focus su identidad de aplicación.

    Devuelve si lo consiguió. Fuera de Windows no hay nada que hacer.

    EL ORDEN IMPORTA: primero cómo relanzarla y después la identidad. La
    barra de tareas lee los datos de relanzar en cuanto cambia la identidad;
    si llegara antes la identidad, podría quedarse sin ellos.
    """
    if sys.platform != "win32":
        return False
    try:
        ventana = _ventana_de_flet(os.getpid())
        if ventana is None:
            return False
        almacen = ctypes.c_void_p()
        iid = _GUID.de(_IID_IPROPERTYSTORE)
        ctypes.oledll.shell32.SHGetPropertyStoreForWindow(
            wintypes.HWND(ventana), ctypes.byref(iid), ctypes.byref(almacen)
        )
        try:
            _poner_textos(
                almacen,
                [
                    (_RELANZAR_ORDEN, orden_de_relanzar(python_sin_consola(), lanzador)),
                    (_RELANZAR_NOMBRE, nombre),
                    (_RELANZAR_ICONO, f"{icono},0"),
                    (_ID, ID_DE_LA_APP),
                ],
            )
        finally:
            _llamar(almacen, _LIBERAR)
        return True
    except OSError:
        return False


def marcar_acceso_directo(acceso: Path) -> bool:
    """Le pone a un acceso directo (.lnk) la misma identidad que a la ventana.

    PARA QUE LA VENTANA CAIGA EN SU BOTÓN: si el acceso directo y la ventana
    dicen ser la misma aplicación, Windows los junta. Lo usa
    herramientas/poner_en_escritorio.py.
    """
    if sys.platform != "win32":
        return False
    try:
        ctypes.oledll.ole32.CoInitialize(None)
        almacen = ctypes.c_void_p()
        iid = _GUID.de(_IID_IPROPERTYSTORE)
        # 2: GPS_READWRITE, abrirlo para cambiarlo.
        ctypes.oledll.shell32.SHGetPropertyStoreFromParsingName(
            str(acceso), None, 2, ctypes.byref(iid), ctypes.byref(almacen)
        )
        try:
            _poner_textos(almacen, [(_ID, ID_DE_LA_APP)])
            _llamar(almacen, _GUARDAR)
        finally:
            _llamar(almacen, _LIBERAR)
        return True
    except OSError:
        return False
