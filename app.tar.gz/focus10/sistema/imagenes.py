"""Guardar una imagen en la carpeta de Imágenes de la PC.

PARA COMPARTIR FUERA DESDE LA PC: Windows no tiene el menú de compartir del
móvil, así que la imagen del logro se guarda aquí y se dice dónde, para que la
subas tú a Instagram o la mandes por WhatsApp Web.
"""

from __future__ import annotations

from pathlib import Path

CARPETA = "Focus1%"


def guardar(imagen: bytes, nombre: str, *, base: Path | None = None) -> Path:
    """La guarda en Imágenes/Focus1% SIN PISAR otra con el mismo nombre.

    NO SE PISA NADA: compartir dos medallas seguidas no puede borrar la
    primera imagen. La segunda se llama «...-2.png».
    """
    carpeta = (base or Path.home() / "Pictures") / CARPETA
    carpeta.mkdir(parents=True, exist_ok=True)
    destino = carpeta / nombre
    numero = 2
    while destino.exists():
        destino = carpeta / f"{Path(nombre).stem}-{numero}.png"
        numero += 1
    destino.write_bytes(imagen)
    return destino
