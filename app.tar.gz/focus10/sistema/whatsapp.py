"""Vincular este WhatsApp con la cuenta, desde la app.

CÓMO SE VINCULA: la app inventa un código de un solo uso, guarda en la nube SOLO
su huella (vence a los 10 minutos) y abre WhatsApp con «FOCUS <código>» ya
escrito para el número del bot. Al mandarlo, el servidor comprueba el código
y une ESE número a ESTA cuenta (servidor/lib/whatsapp.py). Nadie teclea su
número de teléfono en ningún sitio: lo da WhatsApp, firmado por Meta.

POR QUÉ ASÍ Y NO «escribí tu número en la app»: escribir un número no prueba
que sea tuyo. Mandar el código desde ese WhatsApp, sí.
"""

from __future__ import annotations

import hashlib
import secrets
import urllib.parse

from .sincronizacion import _pedir

NUMERO_DEL_BOT = ""
"""El número de WhatsApp del bot, con prefijo de país y sin «+» (34600111222).

VACÍO MIENTRAS NO ESTÉ ACTIVADO (ver servidor/WHATSAPP.md): la tarjeta de
Configuración lo dice en vez de ofrecer algo que no anda."""

LETRAS = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
"""Sin 0/O ni 1/I/L, que se confunden al copiar. El servidor acepta
cualquier letra o cifra: la huella es la que tiene que coincidir."""
LARGO = 8


def nuevo_codigo() -> str:
    """Ocho letras al azar de verdad (secrets, no random): unos 40 bits. Con
    diez minutos de vida y cinco intentos por hora, no se adivina."""
    return "".join(secrets.choice(LETRAS) for _ in range(LARGO))


def huella(codigo: str) -> str:
    """La MISMA cuenta que hace el servidor (servidor/lib/whatsapp.huella).
    Una prueba vigila que no se separen."""
    return hashlib.sha256(codigo.strip().upper().encode("utf-8")).hexdigest()


def enlace(codigo: str) -> str:
    """El enlace que abre WhatsApp con el mensaje ya escrito para el bot."""
    return f"https://wa.me/{NUMERO_DEL_BOT}?text=" + urllib.parse.quote(f"FOCUS {codigo}")


def pedir_codigo(testigo: str, codigo: str, pedir=_pedir) -> None:
    """Deja la huella del código en la nube, a nombre de esta cuenta."""
    pedir("POST", "rpc/crear_codigo_whatsapp", testigo, {"p_huella": huella(codigo)})


def vinculado(testigo: str, pedir=_pedir) -> bool:
    """Si esta cuenta tiene un WhatsApp vinculado. Las reglas de la nube solo
    dejan ver el de esta cuenta."""
    return bool(pedir("GET", "whatsapp_vinculos?select=wa_id", testigo))


def desvincular(testigo: str, pedir=_pedir) -> None:
    """Suelta el WhatsApp de esta cuenta. El filtro es porque la nube no deja
    borrar sin uno; las reglas ya limitan el borrado a lo de esta cuenta."""
    pedir("DELETE", "whatsapp_vinculos?wa_id=not.is.null", testigo)
