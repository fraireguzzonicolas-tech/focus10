"""Punto de entrada: `python -m focus10` abre la aplicacion.

Se llama __main__.py porque es el nombre que Python busca al ejecutar un
paquete con -m. Es el equivalente al metodo main de Java.
"""

from .interfaz.app import ejecutar

if __name__ == "__main__":
    ejecutar()
