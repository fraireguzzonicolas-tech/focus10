"""Que version exacta es esta copia. Lo escribe preparar_web.py."""

from __future__ import annotations

SELLO = "1.0.0+20260912-0929"
