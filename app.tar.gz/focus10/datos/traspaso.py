"""Llevarse los datos a otro aparato: sacar una copia y meterla.

LO PIDIÓ EL USUARIO: "tengo la aplicación en el móvil pero no tengo todo lo
hecho en la computadora, ya que son diferentes usuarios; se están guardando en
el dispositivo y no en el usuario".

ESTO NO ES SINCRONIZAR, Y ES IMPORTANTE QUE SE NOTE. Meter una copia REEMPLAZA
todo lo que había en este aparato. No junta, no mezcla, no suma: sustituye. Un
aparato manda y el otro recibe. Juntar de verdad —que los dos puedan apuntar y
luego se pongan de acuerdo— es otro problema, mucho más grande, y fingir aquí
que se hace sería la peor forma de perder datos.

SE MUEVE EL ARCHIVO ENTERO Y NO UNA LISTA DE COSAS. Los datos ya son un único
archivo SQLite en los dos sitios —en el ordenador en el disco, en el navegador
en memoria respaldado en indexedDB—, así que copiarlo entero es exacto por
construcción: no hay forma de olvidarse de una tabla. Escribir un exportador
tabla por tabla, con veinticinco tablas, sí la hay.

SE USA EL backup() DE SQLITE Y NO UN copy() DEL ARCHIVO, por el mismo motivo que
en copias.py: con journal_mode=WAL parte de lo último escrito vive en un archivo
`-wal` aparte, y copiar solo el `.db` daría una copia a la que le faltan los
últimos cambios. Una copia incompleta que parece buena es peor que ninguna.
"""

from __future__ import annotations

import sqlite3
import tempfile
import zipfile
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

from . import cambios, copias, migraciones, rutas

EXTENSION = ".zip"
"""La copia es un zip de verdad, con la base dentro.

ANTES ERA UNA EXTENSIÓN PROPIA, `.focus10`, y parecía buena idea: dejaba claro
de quién era el archivo. En la práctica fue un problema: Windows lo enseñaba
como un papel en blanco —"no sé qué es esto"— y, lo que de verdad importa, el
móvil NO DEJABA ELEGIRLO. Android filtra por tipo de archivo, y un tipo que no
conoce no aparece o sale apagado. La copia se podía sacar y no se podía meter,
que es la mitad inútil.

UN ZIP LO CONOCE TODO EL MUNDO: Windows, Android, WhatsApp, el correo. Y de
regalo ocupa como un tercio, porque una base de SQLite se comprime muy bien.

SE SIGUEN ACEPTANDO LAS COPIAS VIEJAS al meterlas: quien ya tenga un `.focus10`
guardado no se queda tirado. Ver `_como_base`.
"""

NOMBRE_DENTRO = "focus10.db"
"""Cómo se llama la base dentro del zip."""

# Tablas que tiene que haber para creer que el archivo es de Focus10. No están
# todas: bastan unas cuantas de sitios distintos para descartar cualquier otra
# base de datos que alguien elija por error.
TABLAS_ESPERADAS = ("ajustes", "dias", "habitos", "movimientos", "comidas")


class NoSePuedeTraspasar(RuntimeError):
    """El archivo no sirve, y el mensaje dice por qué en cristiano."""


def nombre_sugerido(momento: datetime | None = None) -> str:
    """"Focus10 2026-09-05.focus10", para que se ordenen solos por fecha."""
    cuando = momento or datetime.now()
    return f"Focus10 {cuando:%Y-%m-%d}{EXTENSION}"


def exportar(destino: Path, ruta_bd: Path | None = None) -> Path:
    """Deja en `destino` una copia completa de los datos de este aparato."""
    origen = Path(ruta_bd) if ruta_bd else rutas.ruta_bd()
    if not origen.is_file():
        raise NoSePuedeTraspasar("todavía no hay datos que copiar")

    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)

    # PRIMERO LA COPIA DE SQLITE Y LUEGO EL ZIP: comprimir el archivo del disco
    # a pelo se dejaria fuera lo ultimo escrito, que con WAL vive aparte.
    with tempfile.TemporaryDirectory() as carpeta:
        intermedia = Path(carpeta) / NOMBRE_DENTRO
        conexion = sqlite3.connect(origen)
        try:
            copia = sqlite3.connect(intermedia)
            try:
                conexion.backup(copia)
            finally:
                copia.close()
        finally:
            conexion.close()

        _quitar_la_sesion(intermedia)

        with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as paquete:
            paquete.write(intermedia, NOMBRE_DENTRO)

    return destino


def _quitar_la_sesion(copia: Path) -> None:
    """Borra de la copia el testigo de la cuenta, si lo hubiera.

    UNA COPIA SE PASA POR WHATSAPP, se sube a Drive y se deja en Descargas.
    Con la sesion dentro, cualquiera que la abriera entraria en la cuenta sin
    saber la contrasena. Los datos apuntados si viajan —para eso es la copia—;
    la llave de tu cuenta, no.

    SE BORRA DE LA COPIA Y NO DEL ORIGINAL: aqui no se cierra tu sesion.
    """
    from . import ajustes

    conexion = sqlite3.connect(copia)
    try:
        conexion.executemany(
            "UPDATE ajustes SET valor = '' WHERE clave = ?",
            [(clave,) for clave in ajustes.CLAVES_DE_LA_CUENTA],
        )
        conexion.commit()
    finally:
        conexion.close()


@contextmanager
def _como_base(origen: Path):
    """Da la base de datos que hay dentro de esa copia, sea zip o no.

    LAS COPIAS VIEJAS SIGUEN VALIENDO: antes la copia era la base tal cual, sin
    comprimir. Quien tenga una guardada la puede meter igual, y por eso esto
    mira lo que hay en vez de fiarse del nombre del archivo.
    """
    origen = Path(origen)
    if not zipfile.is_zipfile(origen):
        yield origen
        return

    with tempfile.TemporaryDirectory() as carpeta:
        try:
            with zipfile.ZipFile(origen) as paquete:
                if NOMBRE_DENTRO not in paquete.namelist():
                    raise NoSePuedeTraspasar(
                        "ese zip no es una copia de Focus10"
                    )
                paquete.extract(NOMBRE_DENTRO, carpeta)
        except zipfile.BadZipFile as fallo:
            raise NoSePuedeTraspasar("esa copia está dañada") from fallo
        yield Path(carpeta) / NOMBRE_DENTRO


def revisar(origen: Path) -> int:
    """Comprueba que el archivo se puede meter y devuelve su versión.

    SE MIRA ANTES DE TOCAR NADA. Reemplazar los datos con un archivo roto, o de
    otro programa, o de una versión más nueva de la aplicación, deja el aparato
    peor de lo que estaba. Aquí se descarta todo eso mientras el original sigue
    intacto.
    """
    origen = Path(origen)
    if not origen.is_file():
        raise NoSePuedeTraspasar("no encuentro ese archivo")

    with _como_base(origen) as base:
        return _revisar_la_base(base)


def _revisar_la_base(origen: Path) -> int:
    try:
        conexion = sqlite3.connect(f"file:{origen}?mode=ro", uri=True)
    except sqlite3.Error as fallo:
        raise NoSePuedeTraspasar("ese archivo no se puede abrir") from fallo

    try:
        try:
            estado = conexion.execute("PRAGMA integrity_check").fetchone()[0]
        except sqlite3.DatabaseError as fallo:
            raise NoSePuedeTraspasar(
                "ese archivo no es una copia de Focus10"
            ) from fallo
        if estado != "ok":
            raise NoSePuedeTraspasar("esa copia está dañada y no se puede meter")

        tablas = {
            fila[0]
            for fila in conexion.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            )
        }
        faltan = [una for una in TABLAS_ESPERADAS if una not in tablas]
        if faltan:
            raise NoSePuedeTraspasar(
                "ese archivo no es una copia de Focus10"
            )

        version = int(conexion.execute("PRAGMA user_version").fetchone()[0])
    finally:
        conexion.close()

    # UNA COPIA MÁS NUEVA NO SE METE. Si viene de una versión posterior de la
    # aplicación, esta no sabe leer su forma y no hay migración hacia atrás:
    # meterla dejaría la aplicación sin arrancar. Más vieja sí vale, porque las
    # migraciones la ponen al día al abrirla.
    if version > migraciones.VERSION_OBJETIVO:
        raise NoSePuedeTraspasar(
            "esa copia viene de una versión más nueva de Focus10. "
            "Actualiza la aplicación de este aparato y vuelve a intentarlo."
        )
    return version


def importar(origen: Path, ruta_bd: Path | None = None) -> Path:
    """REEMPLAZA los datos de este aparato con los de esa copia.

    Devuelve la ruta de la copia de seguridad de lo que había antes.

    SE GUARDA LO DE ANTES SIEMPRE, y por eso esta función devuelve esa ruta en
    vez de nada: lo primero que pregunta quien se equivoca de archivo es "¿y lo
    mío?". La respuesta tiene que estar en pantalla, no en una carpeta que hay
    que adivinar.
    """
    origen = Path(origen)
    revisar(origen)

    destino = Path(ruta_bd) if ruta_bd else rutas.ruta_bd()
    destino.parent.mkdir(parents=True, exist_ok=True)

    respaldo = _guardar_lo_de_ahora(destino)

    with _como_base(origen) as base:
        entrante = sqlite3.connect(f"file:{base}?mode=ro", uri=True)
        try:
            actual = sqlite3.connect(destino)
            try:
                # backup() SE LLEVA TAMBIEN LA VERSION: vive en la cabecera de
                # la base, no en una tabla. Ponerla otra vez a mano era una
                # linea que no cambiaba nada, y lo destapo romperla y ver que
                # ningun test se enteraba.
                entrante.backup(actual)
                cambios.empezar_de_nuevo(actual)
            finally:
                actual.close()
        finally:
            entrante.close()

    return respaldo


def exportar_a_bytes(ruta_bd: Path | None = None) -> bytes:
    """La copia entera como un montón de bytes, sin dejar archivo ninguno.

    ES LO QUE NECESITA EL NAVEGADOR: allí no hay disco donde escribir, así que
    la copia se le entrega al navegador en memoria y él la descarga. En el
    ordenador no hace falta, pero tenerlo aquí deja la pantalla igual en los dos
    sitios: solo mueve bytes.
    """
    with tempfile.TemporaryDirectory() as carpeta:
        intermedio = Path(carpeta) / f"copia{EXTENSION}"
        exportar(intermedio, ruta_bd=ruta_bd)
        return intermedio.read_bytes()


def importar_de_bytes(datos: bytes, ruta_bd: Path | None = None) -> Path:
    """Mete una copia que llega como bytes. REEMPLAZA, igual que la otra.

    SE ESCRIBE EN UN ARCHIVO TEMPORAL Y SE PASA POR LA MISMA PUERTA: así las
    cuatro comprobaciones —que abra, que no esté dañada, que sea de Focus10, que
    no venga de una versión más nueva— valen también aquí. Escribir una segunda
    versión de esas comprobaciones para el navegador sería tener dos reglas que
    algún día no coinciden, y justo en lo único que no se puede deshacer.
    """
    with tempfile.TemporaryDirectory() as carpeta:
        intermedio = Path(carpeta) / f"entrante{EXTENSION}"
        intermedio.write_bytes(datos)
        return importar(intermedio, ruta_bd=ruta_bd)


def _guardar_lo_de_ahora(ruta_bd: Path) -> Path:
    """La copia de lo que había, antes de pisarlo. Va donde las automáticas."""
    if not ruta_bd.is_file():
        # Aparato nuevo, sin datos todavía: no hay nada que salvar.
        return copias.carpeta_de_copias(ruta_bd)

    conexion = sqlite3.connect(ruta_bd)
    try:
        version = migraciones.version_actual(conexion)
        return copias.copiar(conexion, ruta_bd, version)
    finally:
        conexion.close()
