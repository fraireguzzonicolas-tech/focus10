"""Pasar fechas y horas a texto para guardarlas, y volver a leerlas.

POR QUÉ TEXTO Y NO UN TIPO DE FECHA DE VERDAD: SQLite no tiene tipo fecha. Lo
que hay son tres opciones —texto, número de segundos, o número juliano— y aquí
se usa texto en formato ISO ("2025-08-19 03:00:00") por tres motivos:

  1. Ordena bien solo. Al ser año-mes-día, el orden alfabético coincide con el
     cronológico, así que "ORDER BY momento" funciona sin trucos.
  2. Se puede comparar con >= y < para filtrar por rangos, que es como se sacan
     los movimientos de una jornada o de un mes.
  3. Se entiende abriendo la base de datos con cualquier visor. Un número de
     segundos no le dice nada a nadie.

POR QUÉ AL SEGUNDO Y NO MÁS FINO: para apuntar un gasto no hacen falta
milésimas, y una precisión que no se usa solo sirve para que dos fechas que
parecen iguales no lo sean.

POR QUÉ NO SE USA detect_types DE sqlite3: ese mecanismo convierte columnas
automáticamente según el tipo declarado, pero las tablas STRICT solo admiten los
cinco tipos de SQLite (INTEGER, TEXT...), así que no hay dónde declarar "esto es
una fecha". Convertir a mano es más aburrido y no tiene sorpresas.
"""

from __future__ import annotations

from datetime import date, datetime

FORMATO_MOMENTO = "%Y-%m-%d %H:%M:%S"
FORMATO_DIA = "%Y-%m-%d"


def momento_a_texto(momento: datetime) -> str:
    """Escribe un momento para guardarlo."""
    if not isinstance(momento, datetime):
        raise TypeError(f"se esperaba un datetime, no {type(momento).__name__}")
    if momento.tzinfo is not None:
        raise ValueError("los momentos van en hora local, sin zona horaria")
    if momento.microsecond:
        raise ValueError(
            "el momento se guarda al segundo; quita los microsegundos antes"
        )
    return momento.strftime(FORMATO_MOMENTO)


def momento_desde_texto(texto: str) -> datetime:
    """Lee un momento guardado. Falla claro si el texto está corrupto."""
    if not isinstance(texto, str):
        raise TypeError(f"se esperaba texto, no {type(texto).__name__}")
    try:
        return datetime.strptime(texto.strip(), FORMATO_MOMENTO)
    except ValueError as error:
        raise ValueError(f"momento mal guardado: {texto!r}") from error


def dia_a_texto(dia: date) -> str:
    """Escribe una jornada para guardarla."""
    # datetime hereda de date, así que hay que descartarlo expresamente: una
    # jornada con hora dentro sería un dato distinto del que se espera.
    if not isinstance(dia, date) or isinstance(dia, datetime):
        raise TypeError(f"se esperaba un date, no {type(dia).__name__}")
    return dia.strftime(FORMATO_DIA)


def dia_desde_texto(texto: str) -> date:
    """Lee una jornada guardada."""
    if not isinstance(texto, str):
        raise TypeError(f"se esperaba texto, no {type(texto).__name__}")
    try:
        return datetime.strptime(texto.strip(), FORMATO_DIA).date()
    except ValueError as error:
        raise ValueError(f"jornada mal guardada: {texto!r}") from error
