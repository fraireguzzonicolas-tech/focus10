"""Guardar y leer posiciones y operaciones.

AQUÍ NO SE GUARDAN NI LAS UNIDADES NI EL PRECIO MEDIO. No hay función para
hacerlo porque no hay columna donde ponerlos: se calculan siempre con
dominio.inversion.calcular a partir de las operaciones. Es lo que impide que
existan dos versiones de la verdad.

EL PRECIO ACTUAL SÍ SE GUARDA, con de dónde vino y cuándo. Si vino del mercado se
guardan además el precio original, su moneda y el cambio usado: los tres, o
ninguno. Media conversión guardada es peor que ninguna, porque parece un dato
bueno y no se puede comprobar.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime
from decimal import Decimal

from ..dominio.inversion import (
    Operacion,
    Posicion,
    Resumen,
    TipoActivo,
    TipoOperacion,
    calcular,
)
from .fechas import dia_a_texto, dia_desde_texto

ORIGEN_MANO = "mano"
ORIGEN_MERCADO = "mercado"


class PosicionNoExiste(LookupError):
    """Se pidió tocar una posición que no está."""


class TickerRepetido(ValueError):
    """Ya hay una posición con ese ticker."""


# ---------------------------------------------------------------------------
# Posiciones
# ---------------------------------------------------------------------------


def listar(conexion: sqlite3.Connection) -> list[Posicion]:
    filas = conexion.execute("SELECT * FROM posiciones ORDER BY nombre").fetchall()
    return [_posicion_desde_fila(fila) for fila in filas]


def obtener(conexion: sqlite3.Connection, id_posicion: int) -> Posicion | None:
    fila = conexion.execute(
        "SELECT * FROM posiciones WHERE id = ?", (id_posicion,)
    ).fetchone()
    return _posicion_desde_fila(fila) if fila else None


def crear(conexion: sqlite3.Connection, posicion: Posicion) -> Posicion:
    try:
        cursor = conexion.execute(
            "INSERT INTO posiciones (nombre, ticker, tipo) VALUES (?, ?, ?)",
            (posicion.nombre, posicion.ticker, posicion.tipo.value),
        )
    except sqlite3.IntegrityError as fallo:
        # El índice único es quien lo impide; aquí solo se traduce a un mensaje
        # que se pueda enseñar. Dos posiciones del mismo ticker partirían la
        # misma inversión en dos y ninguna de las dos cuadraría con el banco.
        raise TickerRepetido(
            f"ya tienes una posición con el símbolo {posicion.ticker}"
        ) from fallo
    return obtener(conexion, cursor.lastrowid)


def actualizar(conexion: sqlite3.Connection, posicion: Posicion) -> Posicion:
    """Corrige el nombre, el símbolo o el tipo. NO toca el precio ni las
    operaciones: cada cosa tiene su puerta."""
    if posicion.id is None:
        raise ValueError("para corregir hace falta el id de la posición")
    _exigir(conexion, posicion.id)
    try:
        conexion.execute(
            "UPDATE posiciones SET nombre = ?, ticker = ?, tipo = ? WHERE id = ?",
            (posicion.nombre, posicion.ticker, posicion.tipo.value, posicion.id),
        )
    except sqlite3.IntegrityError as fallo:
        raise TickerRepetido(
            f"ya tienes otra posición con el símbolo {posicion.ticker}"
        ) from fallo
    return obtener(conexion, posicion.id)


def borrar(conexion: sqlite3.Connection, id_posicion: int) -> None:
    """Borra la posición y sus operaciones.

    Las operaciones se van con ella a propósito: una operación sin posición no
    significa nada, y dejarlas sueltas solo llenaría la tabla de filas que nadie
    puede volver a ver.
    """
    _exigir(conexion, id_posicion)
    conexion.execute("DELETE FROM operaciones WHERE posicion_id = ?", (id_posicion,))
    conexion.execute("DELETE FROM posiciones WHERE id = ?", (id_posicion,))


# ---------------------------------------------------------------------------
# El precio actual
# ---------------------------------------------------------------------------


def guardar_precio_a_mano(
    conexion: sqlite3.Connection, id_posicion: int, precio: int
) -> Posicion:
    """El precio escrito en la casilla de la tabla."""
    _exigir(conexion, id_posicion)
    if isinstance(precio, bool) or not isinstance(precio, int) or precio < 0:
        raise ValueError("el precio tiene que ser un entero de céntimos, no negativo")
    conexion.execute(
        "UPDATE posiciones SET precio_actual = ?, precio_origen = ?, "
        "precio_momento = ?, precio_original = NULL, precio_moneda = NULL, "
        "precio_cambio = NULL WHERE id = ?",
        (
            precio,
            ORIGEN_MANO,
            datetime.now().replace(microsecond=0).isoformat(" "),
            id_posicion,
        ),
    )
    return obtener(conexion, id_posicion)


def guardar_precio_de_mercado(
    conexion: sqlite3.Connection,
    id_posicion: int,
    *,
    euros: int,
    original: int,
    moneda: str,
    cambio: Decimal,
    momento: datetime,
) -> Posicion:
    """El precio traído de internet, con todo lo que hace falta para creérselo.

    Se piden los cinco datos a la vez, sin valores por omisión: así no se puede
    guardar media conversión por olvidarse de un argumento. El cambio va como
    TEXTO para no perder ni un decimal por el camino, igual que las tasas de
    Finanzas.
    """
    _exigir(conexion, id_posicion)
    conexion.execute(
        "UPDATE posiciones SET precio_actual = ?, precio_origen = ?, "
        "precio_momento = ?, precio_original = ?, precio_moneda = ?, "
        "precio_cambio = ? WHERE id = ?",
        (
            euros,
            ORIGEN_MERCADO,
            momento.isoformat(" "),
            original,
            moneda,
            format(cambio, "f"),
            id_posicion,
        ),
    )
    return obtener(conexion, id_posicion)


def detalle_del_precio(conexion: sqlite3.Connection, id_posicion: int) -> dict | None:
    """De dónde salió el precio y cuándo. None si no hay precio todavía.

    Lo pidió el usuario: en pantalla se distingue un precio traído de internet de
    uno escrito a mano, y se ve de cuándo es.
    """
    fila = conexion.execute(
        "SELECT precio_actual, precio_origen, precio_momento, precio_original, "
        "precio_moneda, precio_cambio FROM posiciones WHERE id = ?",
        (id_posicion,),
    ).fetchone()
    if fila is None or fila["precio_actual"] is None:
        return None
    return {
        "precio": int(fila["precio_actual"]),
        "origen": fila["precio_origen"] or ORIGEN_MANO,
        "momento": datetime.fromisoformat(fila["precio_momento"])
        if fila["precio_momento"]
        else None,
        "original": int(fila["precio_original"])
        if fila["precio_original"] is not None
        else None,
        "moneda": fila["precio_moneda"],
        "cambio": Decimal(fila["precio_cambio"]) if fila["precio_cambio"] else None,
    }


# ---------------------------------------------------------------------------
# Operaciones
# ---------------------------------------------------------------------------


def operaciones_de(conexion: sqlite3.Connection, id_posicion: int) -> list[Operacion]:
    filas = conexion.execute(
        "SELECT * FROM operaciones WHERE posicion_id = ? ORDER BY fecha, id",
        (id_posicion,),
    ).fetchall()
    return [_operacion_desde_fila(fila) for fila in filas]


def anadir_operacion(
    conexion: sqlite3.Connection, id_posicion: int, operacion: Operacion
) -> Operacion:
    _exigir(conexion, id_posicion)
    cursor = conexion.execute(
        "INSERT INTO operaciones (posicion_id, tipo, fecha, unidades, precio, importe) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (
            id_posicion,
            operacion.tipo.value,
            dia_a_texto(operacion.fecha),
            operacion.unidades,
            operacion.precio,
            operacion.importe,
        ),
    )
    fila = conexion.execute(
        "SELECT * FROM operaciones WHERE id = ?", (cursor.lastrowid,)
    ).fetchone()
    return _operacion_desde_fila(fila)


def actualizar_operacion(
    conexion: sqlite3.Connection, operacion: Operacion
) -> Operacion:
    """Corregir una compra ya registrada, que lo pidió el usuario."""
    if operacion.id is None:
        raise ValueError("para corregir hace falta el id de la operación")
    conexion.execute(
        "UPDATE operaciones SET tipo = ?, fecha = ?, unidades = ?, precio = ?, "
        "importe = ? WHERE id = ?",
        (
            operacion.tipo.value,
            dia_a_texto(operacion.fecha),
            operacion.unidades,
            operacion.precio,
            operacion.importe,
            operacion.id,
        ),
    )
    fila = conexion.execute(
        "SELECT * FROM operaciones WHERE id = ?", (operacion.id,)
    ).fetchone()
    if fila is None:
        raise PosicionNoExiste(f"no hay ninguna operación con id {operacion.id}")
    return _operacion_desde_fila(fila)


def borrar_operacion(conexion: sqlite3.Connection, id_operacion: int) -> None:
    conexion.execute("DELETE FROM operaciones WHERE id = ?", (id_operacion,))


def resumen_de(conexion: sqlite3.Connection, posicion: Posicion) -> Resumen:
    """Lo que se enseña en la tabla, calculado desde las operaciones. Siempre."""
    return calcular(operaciones_de(conexion, posicion.id), posicion.precio_actual)


# ---------------------------------------------------------------------------
# El interruptor de los precios de mercado
# ---------------------------------------------------------------------------


def leer_precios_de_mercado(conexion: sqlite3.Connection) -> bool:
    """Apagado de fábrica: una app de finanzas que sale a internet sin preguntar
    no se merece que le cuentes tu dinero."""
    fila = conexion.execute(
        "SELECT precios_de_mercado FROM focus_ajustes WHERE id = 1"
    ).fetchone()
    return bool(fila["precios_de_mercado"])


def guardar_precios_de_mercado(conexion: sqlite3.Connection, encendido: bool) -> None:
    conexion.execute(
        "UPDATE focus_ajustes SET precios_de_mercado = ? WHERE id = 1",
        (int(bool(encendido)),),
    )


# ---------------------------------------------------------------------------


def _posicion_desde_fila(fila: sqlite3.Row) -> Posicion:
    return Posicion(
        id=int(fila["id"]),
        nombre=fila["nombre"],
        ticker=fila["ticker"],
        tipo=TipoActivo(fila["tipo"]),
        precio_actual=int(fila["precio_actual"])
        if fila["precio_actual"] is not None
        else None,
    )


def _operacion_desde_fila(fila: sqlite3.Row) -> Operacion:
    return Operacion(
        id=int(fila["id"]),
        posicion_id=int(fila["posicion_id"]),
        tipo=TipoOperacion(fila["tipo"]),
        fecha=dia_desde_texto(fila["fecha"]),
        unidades=int(fila["unidades"]),
        precio=int(fila["precio"]),
        importe=int(fila["importe"]),
    )


def _exigir(conexion: sqlite3.Connection, id_posicion: int) -> Posicion:
    posicion = obtener(conexion, id_posicion)
    if posicion is None:
        raise PosicionNoExiste(f"no hay ninguna posición con id {id_posicion}")
    return posicion
