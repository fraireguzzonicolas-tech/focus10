"""Acceso a los datos en disco (SQLite). Punto de entrada: bd.abrir_bd()."""
