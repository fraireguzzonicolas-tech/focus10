"""La migración 41: los cuadernos y las páginas de la pizarra (Whiteboard).

ESTE ARCHIVO ES PARTE DE UNA MIGRACIÓN PUBLICADA Y NO SE EDITA NUNCA.

DOS TABLAS: cuadernos («Cálculo», «Francés») y sus páginas. Lo eligió el
usuario: cuadernos propios, sin colgar de las materias de Educación.

LA HOJA ENTERA VA EN UNA COLUMNA (`contenido`, JSON): se abre y se guarda
siempre completa. Ver dominio/pizarra_documento.py, que además le pone tope de peso.

VIAJAN A LA NUBE como todo lo demás —el usuario quiere no perderlas y verlas
en otra PC—, con los mismos tres disparadores de la 33. Los nombres para
sincronizar son AL AZAR, también el de los cuadernos: dos PC que crean
«Cálculo» sin internet tendrán dos cuadernos con ese nombre, que se ven y se
arreglan; con un nombre fijo por título, chocarían y uno no llegaría.
"""

from __future__ import annotations

from .migracion_33 import _disparadores

VIAJAN_41 = ("pizarra_cuadernos", "pizarra_paginas")
"""Las tablas nuevas que viajan. Se suman a las demás en sincronia.py."""

TABLAS = (
    """
    CREATE TABLE pizarra_cuadernos (
        id INTEGER PRIMARY KEY,
        nombre TEXT NOT NULL,
        orden INTEGER NOT NULL DEFAULT 0,
        creado_en TEXT NOT NULL,
        uid TEXT,
        cambiado_en TEXT,
        CHECK (length(trim(nombre)) BETWEEN 1 AND 60),
        CHECK (orden >= 0)
    ) STRICT
    """,
    """
    CREATE TABLE pizarra_paginas (
        id INTEGER PRIMARY KEY,
        cuaderno_id INTEGER NOT NULL
            REFERENCES pizarra_cuadernos (id) ON DELETE CASCADE,
        titulo TEXT NOT NULL,
        orden INTEGER NOT NULL DEFAULT 0,
        contenido TEXT NOT NULL DEFAULT '{}',
        editada_en TEXT NOT NULL,
        uid TEXT,
        cambiado_en TEXT,
        CHECK (length(trim(titulo)) BETWEEN 1 AND 80),
        CHECK (orden >= 0),
        CHECK (length(CAST(contenido AS BLOB)) <= 1000000)
    ) STRICT
    """,
    "CREATE INDEX pizarra_paginas_por_cuaderno ON pizarra_paginas (cuaderno_id, orden)",
)


def sentencias() -> tuple[str, ...]:
    disparadores: tuple[str, ...] = ()
    for tabla in VIAJAN_41:
        disparadores += _disparadores(tabla)
    return TABLAS + disparadores
