"""Copias de seguridad automáticas antes de cambiar la forma de la base.

POR QUÉ EXISTE: el usuario lo pidió con estas palabras — "necesito que se
actualice cada vez que hagamos un cambio pero que no desaparezca lo ya metido".
Actualizar el programa nunca toca los datos, porque viven en carpetas distintas;
lo único que sí los toca es una MIGRACIÓN, que cambia la forma de las tablas.

CONTRA QUÉ PROTEGE, exactamente: cada migración va ya en su propia transacción,
así que una que FALLA no rompe nada —la base se queda entera en la versión
anterior—. Contra lo que no había red es contra una migración que SALE BIEN pero
está mal escrita: la 17, por ejemplo, reconstruye la tabla de comidas entera. Si
esa reconstrucción tuviera un fallo, la migración terminaría "con éxito" y los
datos ya no estarían. Eso no lo detecta ninguna transacción, y por eso hace falta
una copia.

CUÁNDO SE HACE: solo cuando hay migraciones pendientes de verdad. Abrir la
aplicación diez veces al día no genera diez copias.

SE USA LA COPIA DE SQLITE Y NO UN copy() DEL ARCHIVO: con journal_mode=WAL, parte
de lo escrito recientemente vive en un archivo `-wal` aparte. Copiar solo el .db
daría una copia a la que le faltan los últimos cambios, que es peor que no tener
copia, porque parece buena.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path

NOMBRE_CARPETA = "copias"

CUANTAS_SE_GUARDAN = 10
"""Cuántas copias se conservan.

Diez son de sobra para volver atrás y no llenan el disco: una base con años de
uso ocupa unos pocos megas. Se borran las más viejas, nunca la más reciente.
"""


class NoSePudoCopiar(RuntimeError):
    """No se ha podido dejar la copia de seguridad antes de migrar."""


def carpeta_de_copias(ruta_bd: Path) -> Path:
    """Dónde van las copias: al lado del archivo de datos.

    Al lado y no en una carpeta del sistema para que, si alguien se lleva la
    aplicación a un pendrive, se lleve también sus copias.
    """
    return Path(ruta_bd).parent / NOMBRE_CARPETA


def nombre_de_copia(version: int, momento: datetime | None = None) -> str:
    """Cómo se llama una copia: con la versión de la que viene y la fecha.

    LA VERSIÓN VA EN EL NOMBRE porque es el dato que hace falta para saber qué
    copia recuperar: "la de antes de la 17" se encuentra a simple vista.
    """
    cuando = (momento or datetime.now()).strftime("%Y-%m-%d_%H%M%S")
    return f"focus10-v{version}-{cuando}.db"


def copiar(conexion: sqlite3.Connection, ruta_bd: Path, version: int) -> Path:
    """Deja una copia de la base tal y como está ahora. Devuelve dónde.

    SE HACE DESDE LA CONEXIÓN ABIERTA con `Connection.backup`, que es la forma
    que da SQLite: se encarga del WAL y de que la copia sea coherente aunque
    algo esté escribiendo a la vez.
    """
    carpeta = carpeta_de_copias(ruta_bd)
    try:
        carpeta.mkdir(parents=True, exist_ok=True)
        destino = carpeta / nombre_de_copia(version)
        copia = sqlite3.connect(str(destino))
        try:
            conexion.backup(copia)
        finally:
            copia.close()
    except (OSError, sqlite3.Error) as fallo:
        raise NoSePudoCopiar(
            f"no se ha podido guardar la copia de seguridad en {carpeta}: "
            f"{fallo}"
        ) from fallo
    return destino


def limpiar_viejas(ruta_bd: Path, cuantas: int = CUANTAS_SE_GUARDAN) -> list[Path]:
    """Borra las copias más antiguas y devuelve las que ha borrado.

    NUNCA BORRA LA MÁS RECIENTE, pase lo que pase con el número: quedarse sin
    ninguna copia por una cuenta mal hecha sería justo lo contrario de para lo
    que está esto.
    """
    guardar = max(1, cuantas)
    carpeta = carpeta_de_copias(ruta_bd)
    if not carpeta.is_dir():
        return []

    # Por fecha de modificación y no por el nombre: si alguien renombra una
    # copia a mano, ordenar por nombre borraría la que no toca.
    todas = sorted(
        (uno for uno in carpeta.glob("focus10-v*.db") if uno.is_file()),
        key=lambda uno: uno.stat().st_mtime,
        reverse=True,
    )
    borradas = []
    for vieja in todas[guardar:]:
        try:
            vieja.unlink()
            borradas.append(vieja)
        except OSError:
            # Que no se pueda borrar una copia vieja no es motivo para impedir
            # abrir la aplicación: ocupa sitio y ya está.
            pass
    return borradas


def antes_de_migrar(
    conexion: sqlite3.Connection, ruta_bd: Path, actual: int, objetivo: int
) -> Path | None:
    """Copia la base si hay migraciones pendientes. Devuelve la copia, o None.

    SI NO HAY NADA PENDIENTE NO HACE NADA: abrir la aplicación no tiene por qué
    generar una copia cada vez.

    SI LA COPIA FALLA, NO SE MIGRA. Es una decisión deliberada y va contra la
    prioridad de "que funcione", así que conviene el motivo: una copia que falla
    casi siempre significa disco lleno o carpeta sin permisos, y cambiar la forma
    de las tablas en esas condiciones es exactamente cuando se pierden cosas. Se
    prefiere no abrir, con un mensaje que dice qué pasa, a abrir y arriesgarse.
    """
    if actual >= objetivo:
        return None
    # Una base recién creada (versión 0 y sin tablas) no tiene nada que perder.
    if actual == 0:
        return None

    copia = copiar(conexion, ruta_bd, actual)
    limpiar_viejas(ruta_bd)
    return copia
