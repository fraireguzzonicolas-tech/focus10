"""La charla con el asistente, UNA SOLA VEZ para la app y para WhatsApp.

EL RECORRIDO DE CADA MENSAJE:
1. Si había algo esperando tu «sí» o tu «no» (un pago que parece repetido, un
   borrado), se resuelve aquí mismo, sin llamar a Claude.
2. Si no, se le manda a Claude la charla y el contexto; elige una acción.
3. Focus decide (dominio/asistente.py): la hace, pregunta antes o contesta.
4. Cómo salió se le cuenta a Claude al principio del mensaje siguiente
   («[Focus] Hecho: …»), para que la charla siga sabiendo qué pasó.

ESTABA DENTRO DE LA VENTANA DEL ASISTENTE y se sacó al sumar WhatsApp: con dos
copias, un día la app y WhatsApp habrían hecho cosas distintas con la misma
frase. Lo que queda en la ventana es pintar burbujas y la voz.

LA CHARLA SE PUEDE GUARDAR COMO JSON (`Charla.a_json`): WhatsApp la guarda en
la nube entre mensaje y mensaje, porque cada mensaje lo atiende un servidor
distinto.

LO PENDIENTE SE GUARDA COMO LA ACCIÓN, NO COMO LA ORDEN: al decir «sí» se
vuelve a decidir con los datos de ESE momento. Si entre la pregunta y el «sí»
el hábito ya no existe, no se borra «otro»: se dice.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Callable
from dataclasses import dataclass, field

from ..dominio import asistente
from ..dominio.asistente import Contexto
from ..dominio.asistente_tipos import Accion, Confirmar, Decir, Hacer, Respuesta
from . import asistente_acciones


@dataclass
class Charla:
    mensajes: list[dict] = field(default_factory=list)
    """La conversación en la forma de Claude, tal cual viaja al servidor."""
    resultado: list[str] | None = None
    """[id de la acción, cómo salió]: va al principio del próximo mensaje."""
    pendiente: dict | None = None
    """{"accion": {...}, "pregunta": "…"}: lo que espera tu sí o tu no."""

    def a_json(self) -> dict:
        return {"mensajes": self.mensajes, "resultado": self.resultado, "pendiente": self.pendiente}

    @classmethod
    def de_json(cls, datos: dict | None) -> Charla:
        datos = datos or {}
        return cls(
            mensajes=list(datos.get("mensajes") or []),
            resultado=datos.get("resultado"),
            pendiente=datos.get("pendiente"),
        )


@dataclass(frozen=True)
class Turno:
    """Lo que contesta el asistente a un mensaje."""

    texto: str
    hecho: bool = False
    """Si cambió algo en Focus (para refrescar la pantalla)."""
    pregunta: bool = False
    """Si espera un sí o un no (la voz vuelve a escuchar sola)."""


def _accion(pendiente: dict) -> Accion:
    cruda = pendiente["accion"]
    return Accion(str(cruda["id"]), str(cruda["nombre"]), dict(cruda["datos"]))


def _hacer(charla: Charla, conexion: sqlite3.Connection, decision, id_accion: str) -> Turno:
    """Ejecuta la orden. LO QUE FALLA SE DICE: un «listo» que no fue es peor."""
    try:
        frase = asistente_acciones.ejecutar(conexion, decision.orden)
        conexion.commit()
    except Exception as fallo:  # noqa: BLE001
        conexion.rollback()
        no_hecho = Decir(f"No pude hacerlo: {fallo}")
        charla.resultado = [id_accion, asistente.resultado_para_la_ia(no_hecho, None)]
        return Turno(no_hecho.texto)
    charla.resultado = [id_accion, asistente.resultado_para_la_ia(decision, True)]
    return Turno(f"Listo: {frase}.", hecho=True)


def respuesta_local(
    charla: Charla, texto: str, conexion: sqlite3.Connection, contexto: Contexto
) -> Turno | None:
    """El sí o el no a lo pendiente, sin red. None si no aplica (no había nada
    pendiente, o lo que dijiste no es ni sí ni no)."""
    if charla.pendiente is None:
        return None
    respuesta = asistente.contesta_si_o_no(texto)
    if respuesta is None:
        return None
    pendiente, charla.pendiente = charla.pendiente, None
    accion = _accion(pendiente)
    if respuesta is False:
        charla.resultado = [accion.id, "[Focus] La persona dijo que no: no se hizo."]
        return Turno("Listo, no lo hago.")
    # SE VUELVE A DECIDIR CON LOS DATOS DE AHORA (ver la cabecera).
    decision = asistente.decidir(Respuesta("", accion), contexto)
    if isinstance(decision, Decir):
        charla.resultado = [accion.id, asistente.resultado_para_la_ia(decision, None)]
        return Turno(decision.texto)
    return _hacer(charla, conexion, decision, accion.id)


def responder(
    charla: Charla,
    texto: str,
    conexion: sqlite3.Connection,
    contexto: Contexto,
    preguntar: Callable[[list[dict], str], Respuesta],
) -> Turno:
    """Un mensaje entero. `preguntar(mensajes, contexto_en_texto)` es el viaje a
    Claude (en la app y en WhatsApp va por caminos distintos).

    SI PREGUNTAR FALLA, TU MENSAJE NO QUEDA EN LA CHARLA (y lo que había que
    contarle a Claude queda para el próximo): reintentar no deja dos mensajes
    tuyos seguidos. El error sube a quien llama, que lo cuenta.
    """
    local = respuesta_local(charla, texto, conexion, contexto)
    if local is not None:
        return local
    if charla.pendiente is not None:
        # Dijo otra cosa: lo pendiente queda sin hacer y se entiende como nuevo.
        charla.resultado = [
            charla.pendiente["accion"]["id"], "[Focus] La persona cambió de tema: no se hizo."
        ]
        charla.pendiente = None

    # EL RESULTADO DE LA ACCIÓN ANTERIOR VA PRIMERO en tu mensaje: así lo pide
    # Claude, y así sabe qué pasó antes de leer lo que decís ahora.
    if charla.resultado is not None:
        id_accion, contado = charla.resultado
        contenido: str | list = [
            {"type": "tool_result", "tool_use_id": id_accion, "content": contado},
            {"type": "text", "text": texto},
        ]
    else:
        contenido = texto
    charla.mensajes.append({"role": "user", "content": contenido})
    try:
        respuesta = preguntar(charla.mensajes, asistente.contexto_para_la_ia(contexto))
    except Exception:
        charla.mensajes.pop()
        raise
    charla.resultado = None
    charla.mensajes.append({"role": "assistant", "content": respuesta.contenido})

    decision = asistente.decidir(respuesta, contexto)
    if respuesta.accion is None:
        return Turno(decision.texto)
    if isinstance(decision, Hacer):
        return _hacer(charla, conexion, decision, respuesta.accion.id)
    if isinstance(decision, Confirmar):
        accion = respuesta.accion
        charla.pendiente = {
            "accion": {"id": accion.id, "nombre": accion.nombre, "datos": accion.datos},
            "pregunta": decision.pregunta,
        }
        return Turno(decision.pregunta, pregunta=True)
    charla.resultado = [respuesta.accion.id, asistente.resultado_para_la_ia(decision, None)]
    return Turno(decision.texto)
