"""La migración 31, entera: los cimientos de la sincronización.

ESTE ARCHIVO ES PARTE DE UNA MIGRACIÓN PUBLICADA Y NO SE EDITA NUNCA, igual que
cualquier otra de migraciones.py. Está aparte solo porque son ciento y pico
sentencias sacadas de una lista, y escritas a mano serían ciento y pico sitios
donde equivocarse. Si algo de aquí tiene que cambiar, se hace en la 32.

QUÉ HACE, en cuatro cosas:

1. A CADA FILA LE DA UN NOMBRE ÚNICO EN EL MUNDO (`uid`). El `id` de siempre lo
   reparte cada aparato por su cuenta —1, 2, 3...—, así que el hábito 5 de la
   PC y el hábito 5 del móvil son cosas distintas. Para que dos aparatos hablen
   de LA MISMA fila hace falta un nombre que no dependa de quién la creó.

2. LO QUE «SOLO PUEDE HABER UNO» SE NOMBRA POR LO QUE LO HACE ÚNICO. El entreno
   del 9 de septiembre se llama `ses:2026-09-09` en todos los aparatos. Así, si
   los dos lo empiezan sin internet, al juntarse están hablando del mismo y se
   funde en uno, con las series de los dos dentro. Con un nombre al azar habría
   dos «entreno del martes». Lo mismo con las categorías de fábrica: «Ocio» se
   llama igual en el móvil y en la PC, y no sale repetida.

3. CADA CAMBIO QUEDA APUNTADO SOLO, con disparadores (triggers) de la propia
   base. La alternativa era tocar los veintitantos repositorios para que cada
   uno avisara al guardar, y bastaría con olvidar UNO para que un tipo de dato
   dejara de viajar sin que nadie se enterase. Un disparador no se olvida.

4. LAS MARCAS DE HÁBITOS PASAN A SER UNA CUENTA POR APARATO. Antes se guardaba
   el total del día («2 veces»), y dos aparatos que suman uno cada uno sin
   internet dirían los dos «1»: al juntarse quedaría 1 en vez de 2. Ahora cada
   aparato lleva su propia fila y lo que se enseña es la suma. Nadie pisa a
   nadie, porque cada fila solo la escribe su aparato.

LO QUE NO VIAJA, y por qué:

- `focus_programas` y `focus_ajustes`: qué programas cerrar y si bloquear webs
  son cosas de ESTE ordenador (rutas como C:\\...\\juego.exe). En el móvil no
  significan nada, y activarlas desde otro aparato sería una sorpresa.
- De `ajustes`, todo menos lo de la lista VIAJAN_AJUSTES. ES UNA LISTA DE LO
  QUE SÍ, NO DE LO QUE NO: ahí dentro vive la sesión de tu cuenta
  (`cuenta.testigo`), que no puede salir del aparato jamás. Con una lista de
  exclusiones, un ajuste nuevo nacería viajando; con esta, nace local, que es
  el fallo seguro.

UNA ADVERTENCIA PARA EL FUTURO: si una migración reconstruye una de estas
tablas (tabla nueva, copiar, DROP, renombrar), el DROP se lleva sus
disparadores y hay que volver a crearlos. Lo vigila un test: toda tabla que
viaja tiene que tener sus tres.
"""

from __future__ import annotations

AHORA = "strftime('%Y-%m-%dT%H:%M:%fZ', 'now')"
"""La hora del cambio: UTC y con milésimas.

UTC PORQUE LOS APARATOS PUEDEN ESTAR EN HUSOS DISTINTOS, y «gana el último»
necesita comparar horas que signifiquen lo mismo. Las milésimas, porque dos
cambios del mismo segundo son normales al tocar varias veces un botón.
"""

AL_AZAR = "lower(hex(randomblob(16)))"
"""Un nombre de 32 cifras al azar: la probabilidad de que dos coincidan es
cero a efectos prácticos, sin tener que preguntar a nadie."""

EN_SILENCIO = "(SELECT COUNT(*) FROM sinc_silencio) = 0"
"""Los disparadores solo apuntan si NO se está aplicando algo que llegó de
fuera. Sin esto, cada cambio recibido se volvería a mandar, y dos aparatos se
estarían devolviendo el mismo cambio para siempre."""

# tabla -> cómo se nombra una fila (con «{f}» donde va NEW. o nada).
# Las que no están en NATURALES reciben un nombre al azar.
NATURALES: dict[str, str] = {
    "ajustes": "'a:' || {f}clave",
    "categorias": "'cat:' || {f}tipo || ':' || lower({f}nombre)",
    "tipos_de_comida": "'tc:' || lower({f}nombre)",
    "horario_semanal": "'hs:' || {f}dia || ':' || {f}hora",
    "posiciones": "'pos:' || {f}ticker",
    "focus_dominios": "'dom:' || {f}dominio",
    "sesiones": "'ses:' || {f}fecha",
    "dias": "'dia:' || {f}jornada",
    "rutina_dias": "'rd:' || {f}dia",
    "semanas_premiadas": "'sp:' || {f}domingo",
    # UNA SOLA FILA POR DISEÑO (CHECK id = 1): se llama igual en todas partes.
    "nutricion_objetivos": "'unica'",
    "marcas": (
        "'m:' || (SELECT uid FROM habitos WHERE id = {f}habito_id)"
        " || ':' || {f}jornada || ':' || {f}aparato"
    ),
}

VIAJAN = (
    "ajustes", "aportaciones", "categorias", "comidas", "dias", "ejercicios",
    "focus_dominios", "habitos", "horario_semanal", "marcas", "movimientos",
    "nutricion_objetivos", "objetivos", "operaciones", "posiciones",
    "recompensas", "rutina_bloques", "rutina_dias", "rutina_ejercicios",
    "rutina_series", "saldos", "semanas_premiadas", "series",
    "sesion_ejercicios", "sesiones", "tareas", "tipos_de_comida", "tragos",
)

VIAJAN_AJUSTES = ("usuario.", "dinero.", "horario.")
"""Los prefijos de ajustes que viajan. Ver la cabecera: es una lista de lo que
SÍ, a propósito."""


def _nombre(tabla: str, fila: str) -> str:
    """La expresión SQL que nombra una fila. `fila` es «NEW.» o «»."""
    plantilla = NATURALES.get(tabla)
    return AL_AZAR if plantilla is None else plantilla.format(f=fila)


def _cuando(tabla: str, fila: str) -> str:
    """La condición para apuntar un cambio de esta tabla."""
    condicion = EN_SILENCIO
    if tabla == "ajustes":
        prefijos = " OR ".join(f"{fila}clave LIKE '{p}%'" for p in VIAJAN_AJUSTES)
        condicion += f" AND ({prefijos})"
    return condicion


def _marcas_por_aparato() -> tuple[str, ...]:
    """Rehace `marcas` para que cada aparato lleve su propia cuenta.

    SE QUITA EL CHECK (cantidad >= 0), y es a propósito: la fila de UN aparato
    puede quedar en negativo —el móvil desmarca lo que marcó la PC—, y lo que
    no puede ser negativo es la SUMA. Eso lo garantiza el repositorio, que es
    el único que escribe aquí.
    """
    return (
        """
        CREATE TABLE marcas_nueva (
            id INTEGER PRIMARY KEY,
            habito_id INTEGER NOT NULL REFERENCES habitos (id),
            jornada TEXT NOT NULL,
            cantidad INTEGER NOT NULL,
            aparato TEXT NOT NULL,
            CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]')
        ) STRICT
        """,
        """
        INSERT INTO marcas_nueva (id, habito_id, jornada, cantidad, aparato)
        SELECT id, habito_id, jornada, cantidad,
               (SELECT valor FROM sinc_estado WHERE clave = 'aparato')
        FROM marcas
        """,
        "DROP TABLE marcas",
        "ALTER TABLE marcas_nueva RENAME TO marcas",
        """
        CREATE UNIQUE INDEX marcas_una_por_jornada
            ON marcas (habito_id, jornada, aparato)
        """,
        "CREATE INDEX marcas_por_jornada ON marcas (jornada)",
    )


def _de_una_tabla(tabla: str) -> tuple[str, ...]:
    """Las columnas, el relleno, el índice y los tres disparadores de una tabla."""
    return (
        f"ALTER TABLE {tabla} ADD COLUMN uid TEXT",
        f"ALTER TABLE {tabla} ADD COLUMN cambiado_en TEXT",
        f"UPDATE {tabla} SET uid = {_nombre(tabla, '')}, cambiado_en = {AHORA}",
        f"CREATE UNIQUE INDEX {tabla}_por_uid ON {tabla} (uid)",
        # AL CREAR: se le pone nombre si no lo trae (lo trae cuando llega de
        # otro aparato) y se apunta. El UPDATE de dentro NO dispara el de
        # «cambio», porque ese exige que ya tuviera nombre (OLD.uid).
        f"""
        CREATE TRIGGER {tabla}_sinc_alta AFTER INSERT ON {tabla}
        WHEN {_cuando(tabla, 'NEW.')}
        BEGIN
            UPDATE {tabla}
               SET uid = COALESCE(NEW.uid, {_nombre(tabla, 'NEW.')}),
                   cambiado_en = {AHORA}
             WHERE rowid = NEW.rowid;
            INSERT INTO sinc_pendientes (tabla, uid)
                 SELECT '{tabla}', uid FROM {tabla} WHERE rowid = NEW.rowid
            ON CONFLICT (tabla, uid) DO UPDATE SET vez = vez + 1;
        END
        """,
        # AL CAMBIAR: se sella la hora y se apunta. El UPDATE de dentro no se
        # vuelve a disparar a sí mismo: SQLite no deja que un disparador se
        # llame solo mientras recursive_triggers esté apagado, que es como
        # viene y como lo deja conexion.py.
        f"""
        CREATE TRIGGER {tabla}_sinc_cambio AFTER UPDATE ON {tabla}
        WHEN OLD.uid IS NOT NULL AND {_cuando(tabla, 'NEW.')}
        BEGIN
            UPDATE {tabla} SET cambiado_en = {AHORA} WHERE rowid = NEW.rowid;
            INSERT INTO sinc_pendientes (tabla, uid) VALUES ('{tabla}', NEW.uid)
            ON CONFLICT (tabla, uid) DO UPDATE SET vez = vez + 1;
        END
        """,
        # AL BORRAR: solo se apunta el nombre. Al subir, la fila ya no estará,
        # y eso es justo lo que le dice al servidor que se borró.
        f"""
        CREATE TRIGGER {tabla}_sinc_baja AFTER DELETE ON {tabla}
        WHEN OLD.uid IS NOT NULL AND {_cuando(tabla, 'OLD.')}
        BEGIN
            INSERT INTO sinc_pendientes (tabla, uid) VALUES ('{tabla}', OLD.uid)
            ON CONFLICT (tabla, uid) DO UPDATE SET vez = vez + 1;
        END
        """,
    )


def sentencias() -> tuple[str, ...]:
    """Todas las sentencias de la migración 31, en orden."""
    base = (
        # LO QUE ES DE ESTE APARATO Y NO VIAJA: quién soy, hasta dónde bajé,
        # si ya me sincronicé alguna vez.
        """
        CREATE TABLE sinc_estado (
            clave TEXT PRIMARY KEY NOT NULL,
            valor TEXT NOT NULL
        ) STRICT
        """,
        f"INSERT INTO sinc_estado (clave, valor) VALUES ('aparato', {AL_AZAR})",
        # LA COLA DE LO QUE FALTA SUBIR. Una entrada por fila, no por cambio:
        # tocar diez veces el mismo hábito sube la fila una vez, como está
        # ahora. `vez` cuenta los cambios, para no borrar de la cola uno que
        # llegó mientras se estaba subiendo el anterior.
        """
        CREATE TABLE sinc_pendientes (
            tabla TEXT NOT NULL,
            uid TEXT NOT NULL,
            vez INTEGER NOT NULL DEFAULT 1,
            PRIMARY KEY (tabla, uid)
        ) STRICT
        """,
        # EL INTERRUPTOR DE SILENCIO: mientras tenga una fila, los disparadores
        # no apuntan nada. Ver EN_SILENCIO.
        "CREATE TABLE sinc_silencio (n INTEGER NOT NULL) STRICT",
    )
    tablas: tuple[str, ...] = ()
    for tabla in VIAJAN:
        tablas += _de_una_tabla(tabla)
    return base + _marcas_por_aparato() + tablas
