"""Subir y bajar cambios: la parte que vive en ESTE aparato.

AQUÍ NO HAY RED. Este archivo sabe qué falta subir, cómo se empaqueta una fila
para que la entienda otro aparato, y cómo se aplica lo que llega. Hablar con el
servidor lo hace sistema/sincronizacion.py, y quien junta las dos cosas se las
pasa a sincronizar() como funciones. Así todo esto se prueba con dos bases y un
servidor de mentira, sin internet.

LAS TRES REGLAS QUE SOSTIENEN TODO:

1. UN PAQUETE LLEVA NOMBRES, NO NÚMEROS. El hábito 5 de la PC no es el 5 del
   móvil, así que una marca no puede viajar diciendo «soy del hábito 5»: viaja
   diciendo «soy del hábito a3f9…», su nombre único. Al llegar, se busca qué
   número tiene ESE hábito en este aparato.

2. GANA EL ÚLTIMO. Si la fila que llega es más vieja que la de aquí, no se
   toca: la de aquí subirá y ganará también en el servidor. Decisión suya.

3. LO QUE LLEGA SE APLICA POR DEPENDENCIAS, NO POR ORDEN DE LLEGADA. Si
   marcaste un hábito y luego le cambiaste el nombre, el servidor tiene el
   hábito DESPUÉS que la marca (el cambio de nombre lo reenvió al final). Un
   aparato nuevo que lo bajara en ese orden recibiría una marca de un hábito
   que aún no tiene. Por eso se baja todo primero y se aplica ordenado:
   primero los padres, luego los hijos; y los borrados al revés.

LO QUE NO SE PUEDE APLICAR NO PARA LO DEMÁS. Una fila que choca (un nombre de
categoría que ya existe con otro dueño) o cuyo padre no existe se salta, se
cuenta y se dice en el informe. Detener toda la sincronización por una fila
dejaría las otras mil sin llegar.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone

from .conexion import transaccion
from .migracion_31 import VIAJAN, VIAJAN_AJUSTES

LOTE = 500
"""Cuántos cambios se suben de una vez. Con muchos pendientes (la primera vez,
todo) una sola petición enorme tarda y, si se corta, se pierde entera."""

MARGEN = 200
"""Cuántos números de «recibido» se vuelven a pedir por si acaso.

EL SERVIDOR REPARTE LOS NÚMEROS AL RECIBIR, PERO LOS CONFIRMA AL TERMINAR, y
dos subidas a la vez pueden confirmarse en otro orden: el 41 puede aparecer
después de que alguien ya leyera el 42. Volver a pedir los últimos doscientos
cuesta nada —aplicar dos veces lo mismo no cambia nada, porque gana el último
y es el mismo— y evita perder uno para siempre.
"""

REFERENCIAS_SIN_CLAVE = {
    ("rutina_ejercicios", "ejercicio_id"): "ejercicios",
    ("sesion_ejercicios", "ejercicio_id"): "ejercicios",
}
"""Columnas que apuntan a otra tabla SIN que la base lo declare.

Los ejercicios se pueden borrar sin perder la rutina que los usaba, y por eso
nunca tuvieron clave ajena. Pero apuntan igual: si viajaran como número,
llegarían señalando a otro ejercicio. Si mañana aparece otra así, va aquí.
"""


@dataclass
class Informe:
    """Lo que pasó en una sincronización, para enseñarlo y para los tests."""

    subidos: int = 0
    aplicados: int = 0
    saltados: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Lo que la base sabe de sí misma
# ---------------------------------------------------------------------------


def _columnas(conexion: sqlite3.Connection, tabla: str) -> list[tuple[str, bool]]:
    """(nombre, es_clave_primaria) de cada columna."""
    return [(f[1], bool(f[5])) for f in conexion.execute(f"PRAGMA table_info({tabla})")]


def _referencias(conexion: sqlite3.Connection, tabla: str) -> dict[str, tuple[str, str]]:
    """columna -> (tabla a la que apunta, columna de esa tabla)."""
    salida: dict[str, tuple[str, str]] = {}
    for f in conexion.execute(f"PRAGMA foreign_key_list({tabla})"):
        padre, desde, hacia = f[2], f[3], f[4]
        if hacia is None:
            hacia = next(c for c, pk in _columnas(conexion, padre) if pk)
        salida[desde] = (padre, hacia)
    for (hija, columna), padre in REFERENCIAS_SIN_CLAVE.items():
        if hija == tabla:
            salida[columna] = (padre, "id")
    return salida


def orden(conexion: sqlite3.Connection) -> list[str]:
    """Las tablas que viajan, cada una DESPUÉS de las que necesita."""
    pendientes = list(VIAJAN)
    listo: list[str] = []
    while pendientes:
        for tabla in pendientes:
            # Solo cuentan los padres que también viajan: uno que no viaja
            # no va a llegar nunca, y esperarlo dejaría la tabla sin sitio.
            padres = {p for p, _ in _referencias(conexion, tabla).values()} - {tabla}
            if padres & set(VIAJAN) <= set(listo):
                listo.append(tabla)
                pendientes.remove(tabla)
                break
        else:
            raise RuntimeError(f"referencias en círculo entre: {pendientes}")
    return listo


def _es_numero_propio(columna: str, es_pk: bool) -> bool:
    """El `id` que reparte este aparato no viaja: en el otro no significa nada.

    SOLO EL QUE SE LLAMA id. Las tablas cuya clave es un dato de verdad —el día
    de la semana en la rutina, la clave de un ajuste— sí la mandan, porque ahí
    el número es lo que la fila ES, y es el mismo en todos los aparatos.
    """
    return es_pk and columna == "id"


# ---------------------------------------------------------------------------
# Subir
# ---------------------------------------------------------------------------


def _ahora() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _empaquetar(conexion: sqlite3.Connection, tabla: str, uid: str) -> dict:
    """La fila tal como la entiende otro aparato, o su aviso de borrado."""
    fila = conexion.execute(f"SELECT * FROM {tabla} WHERE uid = ?", (uid,)).fetchone()
    if fila is None:
        return {"tabla": tabla, "uid": uid, "datos": None, "borrado": True,
                "cambiado_en": _ahora()}
    referencias = _referencias(conexion, tabla)
    datos: dict[str, object] = {}
    for columna, es_pk in _columnas(conexion, tabla):
        if columna in ("uid", "cambiado_en") or _es_numero_propio(columna, es_pk):
            continue
        valor = fila[columna]
        if columna in referencias and valor is not None:
            padre, clave = referencias[columna]
            encontrado = conexion.execute(
                f"SELECT uid FROM {padre} WHERE {clave} = ?", (valor,)
            ).fetchone()
            valor = None if encontrado is None else encontrado[0]
        datos[columna] = valor
    return {"tabla": tabla, "uid": uid, "datos": datos, "borrado": False,
            "cambiado_en": fila["cambiado_en"]}


def por_subir(conexion: sqlite3.Connection, cuantos: int = LOTE) -> list[tuple[dict, int]]:
    """Los siguientes cambios pendientes, empaquetados, con su `vez`."""
    filas = conexion.execute(
        "SELECT tabla, uid, vez FROM sinc_pendientes LIMIT ?", (cuantos,)
    ).fetchall()
    return [(_empaquetar(conexion, f[0], f[1]), int(f[2])) for f in filas]


def confirmar(conexion: sqlite3.Connection, subidos: list[tuple[dict, int]]) -> None:
    """Quita de la cola lo que ya está en el servidor.

    SOLO SI NO CAMBIÓ MIENTRAS SUBÍA. Si la `vez` ya no es la que se leyó, hubo
    un cambio nuevo después de empaquetar, y ese todavía no ha subido.
    """
    with transaccion(conexion):
        conexion.executemany(
            "DELETE FROM sinc_pendientes WHERE tabla = ? AND uid = ? AND vez = ?",
            [(p["tabla"], p["uid"], vez) for p, vez in subidos],
        )


# ---------------------------------------------------------------------------
# Bajar y aplicar
# ---------------------------------------------------------------------------


def _traducir(conexion, tabla, datos: dict) -> dict:
    """Cambia los nombres de los padres por el número que tienen AQUÍ.

    Lanza LookupError si falta alguno: esa fila no se puede poner todavía.
    """
    salida = dict(datos)
    for columna, (padre, clave) in _referencias(conexion, tabla).items():
        uid = salida.get(columna)
        if uid is None:
            continue
        encontrado = conexion.execute(
            f"SELECT {clave} FROM {padre} WHERE uid = ?", (uid,)
        ).fetchone()
        if encontrado is None:
            raise LookupError(f"{tabla}: falta su {padre} ({uid})")
        salida[columna] = encontrado[0]
    return salida


def _poner(conexion, paquete: dict) -> bool:
    """Crea o actualiza una fila que llegó. Devuelve si cambió algo."""
    tabla, uid = paquete["tabla"], paquete["uid"]
    local = conexion.execute(
        f"SELECT rowid, cambiado_en FROM {tabla} WHERE uid = ?", (uid,)
    ).fetchone()
    if local is not None and (local[1] or "") >= paquete["cambiado_en"]:
        return False
    datos = _traducir(conexion, tabla, paquete["datos"])
    columnas = list(datos) + ["cambiado_en"]
    valores = list(datos.values()) + [paquete["cambiado_en"]]
    if local is None:
        huecos = ", ".join("?" for _ in range(len(columnas) + 1))
        conexion.execute(
            f"INSERT INTO {tabla} ({', '.join(columnas)}, uid) VALUES ({huecos})",
            valores + [uid],
        )
    else:
        cambios = ", ".join(f"{c} = ?" for c in columnas)
        conexion.execute(
            f"UPDATE {tabla} SET {cambios} WHERE rowid = ?", valores + [local[0]]
        )
    return True


def _quitar(conexion, paquete: dict) -> bool:
    """Borra una fila que se borró en otro aparato. Devuelve si había algo.

    SI AQUÍ SE CAMBIÓ DESPUÉS DEL BORRADO, SE QUEDA: gana el último, y el
    último fue tocarla, no borrarla.
    """
    tabla, uid = paquete["tabla"], paquete["uid"]
    local = conexion.execute(
        f"SELECT rowid, cambiado_en FROM {tabla} WHERE uid = ?", (uid,)
    ).fetchone()
    if local is None or (local[1] or "") > paquete["cambiado_en"]:
        return False
    conexion.execute(f"DELETE FROM {tabla} WHERE rowid = ?", (local[0],))
    return True


def aplicar(conexion: sqlite3.Connection, paquetes: list[dict], informe: Informe) -> None:
    """Pone en esta base lo que llegó, sin volver a apuntarlo para subir."""
    with transaccion(conexion):
        _aplicar_dentro(conexion, paquetes, informe)


def _aplicar_dentro(conexion, paquetes: list[dict], informe: Informe) -> None:
    """Lo mismo que aplicar(), dentro de una transacción que ya está abierta."""
    tablas = orden(conexion)
    posicion = {t: i for i, t in enumerate(tablas)}
    validos = [p for p in paquetes if p.get("tabla") in posicion]
    altas = sorted((p for p in validos if not p["borrado"]), key=lambda p: posicion[p["tabla"]])
    bajas = sorted((p for p in validos if p["borrado"]), key=lambda p: -posicion[p["tabla"]])

    # EN SILENCIO: los disparadores no apuntan lo que se escribe aquí. Ver
    # EN_SILENCIO en migracion_31.py.
    conexion.execute("INSERT INTO sinc_silencio (n) VALUES (1)")
    try:
        for paquete, hacer in [(p, _poner) for p in altas] + [(p, _quitar) for p in bajas]:
            # UN PUNTO DE RETORNO POR FILA: si una falla, se deshace solo
            # esa, no todo lo aplicado antes.
            conexion.execute("SAVEPOINT fila")
            try:
                if hacer(conexion, paquete):
                    informe.aplicados += 1
                conexion.execute("RELEASE fila")
            except (LookupError, sqlite3.IntegrityError) as fallo:
                conexion.execute("ROLLBACK TO fila")
                conexion.execute("RELEASE fila")
                informe.saltados.append(f"{paquete['tabla']} {paquete['uid']}: {fallo}")
    finally:
        conexion.execute("DELETE FROM sinc_silencio")


def _leer_cursor(conexion) -> int:
    fila = conexion.execute("SELECT valor FROM sinc_estado WHERE clave = 'cursor'").fetchone()
    return 0 if fila is None else int(fila[0])


def _guardar_cursor(conexion, valor: int) -> None:
    conexion.execute(
        "INSERT INTO sinc_estado (clave, valor) VALUES ('cursor', ?) "
        "ON CONFLICT (clave) DO UPDATE SET valor = excluded.valor",
        (str(valor),),
    )


# ---------------------------------------------------------------------------
# La primera vez: quién manda
# ---------------------------------------------------------------------------
#
# DECISIÓN SUYA: la primera vez UN aparato manda y el otro se vacía y lo baja
# todo. Juntar los dos habría dejado repetido todo lo que existía en ambos (el
# hábito GYM creado en la PC y en el móvil, los 285 ejercicios de fábrica).
#
# Y DE QUÉ CUENTA SON LOS DATOS. Lo que se guarda como «ya me sincronicé» es
# el correo de la cuenta, no un sí o un no: si en este aparato cierras sesión y
# entra otra persona, lo que hay aquí NO puede subirse a la cuenta de ella.


def _ajustes_que_viajan() -> str:
    return " OR ".join(f"clave LIKE '{p}%'" for p in VIAJAN_AJUSTES)


def cuenta_sincronizada(conexion: sqlite3.Connection) -> str | None:
    """El correo de la cuenta con la que se sincronizó este aparato, o None."""
    fila = conexion.execute("SELECT valor FROM sinc_estado WHERE clave = 'cuenta'").fetchone()
    return None if fila is None else str(fila[0])


def _quedar_con(conexion, correo: str) -> None:
    conexion.execute(
        "INSERT INTO sinc_estado (clave, valor) VALUES ('cuenta', ?) "
        "ON CONFLICT (clave) DO UPDATE SET valor = excluded.valor",
        (correo,),
    )


def mandar(conexion: sqlite3.Connection, correo: str) -> None:
    """Este aparato es el primero: TODO lo que tiene se apunta para subir."""
    with transaccion(conexion):
        for tabla in VIAJAN:
            # EL «WHERE true» NO SOBRA: sin un WHERE, SQLite confunde el ON
            # CONFLICT de detrás con una parte del SELECT y da error de sintaxis.
            condicion = f"WHERE {_ajustes_que_viajan()}" if tabla == "ajustes" else "WHERE true"
            conexion.execute(
                f"INSERT INTO sinc_pendientes (tabla, uid) "
                f"SELECT '{tabla}', uid FROM {tabla} {condicion} "
                "ON CONFLICT (tabla, uid) DO NOTHING"
            )
        # EL CONTADOR VUELVE A CERO: «hasta dónde bajé» era verdad para la
        # cuenta de antes; en otra, esos números son de otra historia.
        _guardar_cursor(conexion, 0)
        _quedar_con(conexion, correo)


def vaciar_y_recibir(
    conexion: sqlite3.Connection, correo: str, paquetes: list[dict]
) -> Informe:
    """Este aparato llega segundo: se vacía y se queda con lo de la cuenta.

    TODO EN UNA SOLA TRANSACCIÓN, Y CON LO DE LA CUENTA YA BAJADO. Si se
    vaciara primero y la bajada fallara a medias, el aparato se quedaría sin
    nada. Así, o se aplica entero, o se queda como estaba.

    LA COPIA DE SEGURIDAD NO ES COSA DE ESTE ARCHIVO: la hace quien llama,
    antes, porque sabe dónde guardarla.
    """
    informe = Informe()
    with transaccion(conexion):
        conexion.execute("INSERT INTO sinc_silencio (n) VALUES (1)")
        try:
            # AL REVÉS DE LAS DEPENDENCIAS: primero los hijos, o las claves
            # ajenas no dejarían borrar a los padres.
            for tabla in reversed(orden(conexion)):
                condicion = f"WHERE {_ajustes_que_viajan()}" if tabla == "ajustes" else ""
                conexion.execute(f"DELETE FROM {tabla} {condicion}")
            conexion.execute("DELETE FROM sinc_pendientes")
        finally:
            conexion.execute("DELETE FROM sinc_silencio")
        _aplicar_dentro(conexion, paquetes, informe)
        if paquetes:
            _guardar_cursor(conexion, max(int(p["recibido"]) for p in paquetes))
        _quedar_con(conexion, correo)
    return informe


# ---------------------------------------------------------------------------
# Todo junto
# ---------------------------------------------------------------------------


def sincronizar(
    conexion: sqlite3.Connection,
    subir: Callable[[list[dict]], None],
    bajar: Callable[[int], list[dict]],
) -> Informe:
    """Sube lo pendiente y aplica lo que haya llegado.

    PRIMERO SUBE. Si lo hiciera al revés, lo recién bajado podría ser más
    viejo que lo que tenemos esperando aquí, y daría igual —gana el último—,
    pero subiendo antes el servidor tiene lo nuestro cuanto antes para los
    demás aparatos.

    SI LA RED FALLA A MEDIAS, NO SE PIERDE NADA: lo que no se confirmó sigue
    en la cola, y el cursor solo avanza después de aplicar.
    """
    informe = Informe()
    while True:
        lote = por_subir(conexion)
        if not lote:
            break
        subir([p for p, _ in lote])
        confirmar(conexion, lote)
        informe.subidos += len(lote)
        if len(lote) < LOTE:
            break

    llegados = bajar(max(0, _leer_cursor(conexion) - MARGEN))
    aplicar(conexion, llegados, informe)
    if llegados:
        with transaccion(conexion):
            _guardar_cursor(conexion, max(int(p["recibido"]) for p in llegados))
    return informe
