"""La migración 39: un día puede tener varios entrenos, uno por bloque.

ESTE ARCHIVO ES PARTE DE UNA MIGRACIÓN PUBLICADA Y NO SE EDITA NUNCA. Está
aparte, como la 32, porque reconstruye una tabla entera con sus disparadores.

LO PIDIÓ EL USUARIO: «si ese día hay dos entrenamientos, primero se debe empezar
uno, no los dos al mismo tiempo», y eligió que cada uno sea INDEPENDIENTE: su
propio reloj, su propio resumen, sin sumarse. Hasta aquí había UN entreno por
fecha (`fecha UNIQUE`), y empezar el día metía los ejercicios de todos los
bloques (GYM, Movilidad...) en el mismo.

AHORA LO ÚNICO ES (fecha, bloque). `bloque` es el nombre del bloque de la
rutina («GYM»). LOS ENTRENOS DE ANTES QUEDAN CON bloque = '': eran el día
entero, y así se siguen leyendo igual.

EL NOMBRE PARA SINCRONIZAR SIGUE SIENDO EL MISMO para los de antes
('ses:2026-10-29'): se copia tal cual. Los nuevos llevan el bloque detrás
('ses:2026-10-29:GYM'), para que el mismo bloque empezado en el celular y en la
PC sea el mismo entreno, y dos bloques distintos no se pisen.

SE RECONSTRUYE porque SQLite no deja quitar un UNIQUE de una columna. Eso
obliga a apagar las claves ajenas (los ejercicios del entreno apuntan aquí) y a
volver a crear el índice y los TRES DISPARADORES de la sincronización, que el
DROP se lleva. Lo vigila un test.
"""

from __future__ import annotations

_NOMBRE = "'ses:' || NEW.fecha || CASE WHEN NEW.bloque = '' THEN '' ELSE ':' || NEW.bloque END"

_TABLA = """
    CREATE TABLE sesiones_nueva (
        id INTEGER PRIMARY KEY,
        fecha TEXT NOT NULL,
        bloque TEXT NOT NULL DEFAULT '',
        nombre TEXT NOT NULL DEFAULT '',
        color TEXT NOT NULL DEFAULT 'azul',
        empezada_en TEXT NOT NULL DEFAULT '',
        segundos INTEGER NOT NULL DEFAULT 0,
        uid TEXT,
        cambiado_en TEXT,
        UNIQUE (fecha, bloque),
        CHECK (fecha GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
        CHECK (length(bloque) <= 40),
        CHECK (color IN ('azul', 'verde', 'ambar', 'rosa',
                         'violeta', 'cian', 'naranja', 'rojo'))
    ) STRICT
"""

_COPIAR = (
    "INSERT INTO sesiones_nueva "
    "(id, fecha, bloque, nombre, color, empezada_en, segundos, uid, cambiado_en) "
    "SELECT id, fecha, '', nombre, color, empezada_en, segundos, uid, cambiado_en "
    "FROM sesiones"
)

_DISPARADORES = (
    f"""
    CREATE TRIGGER sesiones_sinc_alta AFTER INSERT ON sesiones
    WHEN (SELECT COUNT(*) FROM sinc_silencio) = 0
    BEGIN
        UPDATE sesiones
           SET uid = COALESCE(NEW.uid, {_NOMBRE}),
               cambiado_en = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
         WHERE rowid = NEW.rowid;
        INSERT INTO sinc_pendientes (tabla, uid)
             SELECT 'sesiones', uid FROM sesiones WHERE rowid = NEW.rowid
        ON CONFLICT (tabla, uid) DO UPDATE SET vez = vez + 1;
    END
    """,
    """
    CREATE TRIGGER sesiones_sinc_cambio AFTER UPDATE ON sesiones
    WHEN OLD.uid IS NOT NULL AND (SELECT COUNT(*) FROM sinc_silencio) = 0
    BEGIN
        UPDATE sesiones SET cambiado_en = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
         WHERE rowid = NEW.rowid;
        INSERT INTO sinc_pendientes (tabla, uid) VALUES ('sesiones', NEW.uid)
        ON CONFLICT (tabla, uid) DO UPDATE SET vez = vez + 1;
    END
    """,
    """
    CREATE TRIGGER sesiones_sinc_baja AFTER DELETE ON sesiones
    WHEN OLD.uid IS NOT NULL AND (SELECT COUNT(*) FROM sinc_silencio) = 0
    BEGIN
        INSERT INTO sinc_pendientes (tabla, uid) VALUES ('sesiones', OLD.uid)
        ON CONFLICT (tabla, uid) DO UPDATE SET vez = vez + 1;
    END
    """,
)


def sentencias() -> tuple[str, ...]:
    """Todas las sentencias de la migración 39, en orden."""
    return (
        _TABLA,
        _COPIAR,
        "DROP TABLE sesiones",
        "ALTER TABLE sesiones_nueva RENAME TO sesiones",
        "CREATE UNIQUE INDEX sesiones_por_uid ON sesiones (uid)",
        *_DISPARADORES,
    )
