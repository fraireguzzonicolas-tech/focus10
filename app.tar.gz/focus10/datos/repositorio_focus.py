"""Guardar y leer lo de Focus: duraciones, webs a bloquear y programas a cerrar.

LA REGLA QUE GOBIERNA ESTE ARCHIVO: nada entra sin pasar por la puerta del
dominio. Los dominios pasan por `exigir_bloqueable` y los programas por
`exigir_cerrable`, SIEMPRE, incluso cuando quien llama ya ha comprobado. Es la
segunda de las tres cerraduras —pantalla, aquí, y el guardián antes de escribir—
y la única que protege de que alguien meta una fila con otro programa.

POR QUÉ LA BASE NO PUEDE COMPROBARLO SOLA: la lista de protegidos vive en el
código a propósito, para que no se pueda quitar abriendo el archivo de datos. La
base pone lo que puede —minúsculas, sin comodines, sin barras— pero no sabe que
"google.com" es intocable. De eso se encarga esta capa, y por si acaso, el
guardián otra vez.
"""

from __future__ import annotations

import sqlite3

from ..dominio.dominios import exigir_bloqueable
from ..dominio.pomodoro import Ajustes
from ..dominio.procesos import exigir_cerrable


def leer_ajustes(conexion: sqlite3.Connection) -> Ajustes:
    """Las cuatro cifras del pomodoro. Siempre hay fila: la crea la migración."""
    fila = conexion.execute(
        "SELECT trabajo, descanso, descanso_largo, sesiones_por_ciclo "
        "FROM focus_ajustes WHERE id = 1"
    ).fetchone()
    return Ajustes(
        trabajo=int(fila["trabajo"]),
        descanso=int(fila["descanso"]),
        descanso_largo=int(fila["descanso_largo"]),
        sesiones_por_ciclo=int(fila["sesiones_por_ciclo"]),
    )


def guardar_ajustes(conexion: sqlite3.Connection, ajustes: Ajustes) -> Ajustes:
    """Guarda las duraciones. Los límites los pone Ajustes al construirse."""
    if not isinstance(ajustes, Ajustes):
        raise TypeError("hace falta un Ajustes del dominio")
    conexion.execute(
        "UPDATE focus_ajustes SET trabajo = ?, descanso = ?, descanso_largo = ?, "
        "sesiones_por_ciclo = ? WHERE id = 1",
        (
            ajustes.trabajo,
            ajustes.descanso,
            ajustes.descanso_largo,
            ajustes.sesiones_por_ciclo,
        ),
    )
    return leer_ajustes(conexion)


def leer_interruptores(conexion: sqlite3.Connection) -> tuple[bool, bool]:
    """(bloquear webs, cerrar programas). Van por separado, como pidió el usuario:
    hay días de estudiar en los que Spotify no molesta y lo que sobra es el
    navegador."""
    fila = conexion.execute(
        "SELECT bloquear_webs, cerrar_programas FROM focus_ajustes WHERE id = 1"
    ).fetchone()
    return bool(fila["bloquear_webs"]), bool(fila["cerrar_programas"])


def guardar_interruptores(
    conexion: sqlite3.Connection, *, bloquear_webs: bool, cerrar_programas: bool
) -> None:
    conexion.execute(
        "UPDATE focus_ajustes SET bloquear_webs = ?, cerrar_programas = ? WHERE id = 1",
        (int(bool(bloquear_webs)), int(bool(cerrar_programas))),
    )


# ---------------------------------------------------------------------------
# Las webs a bloquear
# ---------------------------------------------------------------------------


def listar_dominios(conexion: sqlite3.Connection) -> list[str]:
    filas = conexion.execute(
        "SELECT dominio FROM focus_dominios ORDER BY dominio"
    ).fetchall()
    return [fila["dominio"] for fila in filas]


def anadir_dominio(conexion: sqlite3.Connection, texto: str) -> str:
    """Guarda un dominio, o explica por qué no se puede.

    Deja pasar el error del dominio tal cual (DominioProtegido, DominioInvalido):
    ya viene escrito para que lo lea una persona, y traducirlo aquí sería tener
    el mismo texto en dos sitios que se despistan.
    """
    limpio = exigir_bloqueable(texto)
    conexion.execute(
        "INSERT OR IGNORE INTO focus_dominios (dominio) VALUES (?)", (limpio,)
    )
    return limpio


def quitar_dominio(conexion: sqlite3.Connection, dominio: str) -> None:
    conexion.execute("DELETE FROM focus_dominios WHERE dominio = ?", (dominio,))


def dominios_para_bloquear(conexion: sqlite3.Connection) -> list[str]:
    """Los dominios guardados, filtrados OTRA VEZ antes de usarlos.

    Los que ya no pasan el filtro se descartan en silencio en vez de reventar:
    esto se llama al empezar una fase de trabajo, y una fila rara guardada hace
    meses no puede impedirte trabajar hoy. El guardián volverá a mirarlos.
    """
    buenos: list[str] = []
    for guardado in listar_dominios(conexion):
        try:
            buenos.append(exigir_bloqueable(guardado))
        except ValueError:
            continue
    return buenos


# ---------------------------------------------------------------------------
# Los programas a cerrar
# ---------------------------------------------------------------------------


def listar_programas(conexion: sqlite3.Connection) -> list[str]:
    filas = conexion.execute(
        "SELECT nombre FROM focus_programas ORDER BY nombre"
    ).fetchall()
    return [fila["nombre"] for fila in filas]


def anadir_programa(conexion: sqlite3.Connection, texto: str) -> str:
    """Guarda un programa, o explica por qué no se puede.

    Esta es la PRIMERA de las dos comprobaciones que pidió el usuario. La segunda
    está en sistema/cerrador.py, justo antes de cerrar nada.
    """
    limpio = exigir_cerrable(texto)
    conexion.execute(
        "INSERT OR IGNORE INTO focus_programas (nombre) VALUES (?)", (limpio,)
    )
    return limpio


def quitar_programa(conexion: sqlite3.Connection, nombre: str) -> None:
    conexion.execute("DELETE FROM focus_programas WHERE nombre = ?", (nombre,))
