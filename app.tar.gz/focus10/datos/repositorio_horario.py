"""Leer y guardar el horario semanal.

SOLO SE GUARDAN LAS CASILLAS CON TEXTO: vaciar una casilla es borrar su fila.
Así la tabla tiene tantas filas como cosas has escrito y no 119 en blanco.
"""

from __future__ import annotations

import sqlite3

from ..dominio.semana import Casilla, FranjaHoraria, HorarioSemanal
from . import ajustes


def leer_casillas(conexion: sqlite3.Connection) -> tuple[Casilla, ...]:
    """Todo lo escrito en la rejilla, ordenado por día y hora."""
    filas = conexion.execute(
        "SELECT dia, hora, texto, color, nota, icono FROM horario_semanal "
        "ORDER BY dia, hora"
    ).fetchall()
    return tuple(
        Casilla(
            fila["dia"],
            fila["hora"],
            fila["texto"],
            # EN LA BASE, "sin pintar" ES CADENA VACIA; en el dominio es None.
            # La traduccion se hace aquí y en un solo sitio: SQLite no distingue
            # bien entre "vacío" y "nada" en una columna NOT NULL, y el dominio
            # sí quiere esa diferencia porque None significa "no tiene color".
            fila["color"] or None,
            fila["nota"],
            fila["icono"],
        )
        for fila in filas
    )


def leer_horario(conexion: sqlite3.Connection) -> HorarioSemanal:
    """La rejilla lista para dibujar: su franja de horas y lo escrito."""
    return HorarioSemanal(ajustes.leer_franja_horario(conexion), leer_casillas(conexion))


def guardar_casilla(
    conexion: sqlite3.Connection,
    dia: int,
    hora: int,
    texto: str,
    color: str | None = None,
    nota: str = "",
    icono: str = "",
) -> None:
    """Escribe una casilla. Si se queda sin texto Y sin color, la borra.

    POR QUÉ VACIAR ES BORRAR Y NO GUARDAR UNA CADENA VACÍA: una fila con texto
    vacío y una fila que no existe significan exactamente lo mismo —esa hora
    está libre—, y tener dos formas de decir lo mismo obliga a acordarse de las
    dos en cada consulta. Antes o después alguien se acuerda solo de una.

    SE VALIDA CONSTRUYENDO UNA `Casilla` en vez de comprobar aquí a mano: las
    reglas de qué es una casilla válida viven en el dominio, y repetirlas aquí
    sería tener dos sitios que se pueden contradecir.
    """
    limpio = (texto or "").strip()
    if not limpio and color is None:
        borrar_casilla(conexion, dia, hora)
        return

    casilla = Casilla(dia, hora, limpio, color, nota, icono)
    conexion.execute(
        """
        INSERT INTO horario_semanal (dia, hora, texto, color, nota, icono)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(dia, hora) DO UPDATE SET
            texto = excluded.texto,
            color = excluded.color,
            nota = excluded.nota,
            icono = excluded.icono
        """,
        (
            casilla.dia,
            casilla.hora,
            casilla.texto,
            casilla.color or "",
            casilla.nota,
            casilla.icono,
        ),
    )


def repetir_casilla(
    conexion: sqlite3.Connection, origen: Casilla, sitios: list[tuple[int, int]]
) -> tuple[int, int]:
    """Copia la casilla en esos sitios. Devuelve (puestas, saltadas).

    LAS OCUPADAS NO SE TOCAN, y lo eligió el usuario: así nunca se pisa algo sin
    querer. Se cuentan para poder decir cuántas se saltaron, en vez de dejar que
    el usuario descubra solo que su lunes no cambió.
    """
    ocupadas = {
        (fila["dia"], fila["hora"])
        for fila in conexion.execute("SELECT dia, hora FROM horario_semanal")
    }
    puestas = saltadas = 0
    for dia, hora in sitios:
        if (dia, hora) in ocupadas:
            saltadas += 1
            continue
        guardar_casilla(
            conexion, dia, hora, origen.texto, origen.color, origen.nota, origen.icono
        )
        puestas += 1
    return puestas, saltadas


def borrar_casilla(conexion: sqlite3.Connection, dia: int, hora: int) -> None:
    """Deja una hora libre. No falla si ya lo estaba."""
    conexion.execute(
        "DELETE FROM horario_semanal WHERE dia = ? AND hora = ?", (dia, hora)
    )


def borrar_todo(conexion: sqlite3.Connection) -> int:
    """Deja la semana entera libre: texto, color, ícono y nota de cada hora.
    Devuelve cuántas casillas borró.

    LO PIDIÓ EL USUARIO (15 nov 2026): borrar el horario de una vez, sin ir
    casilla por casilla. Eligió TODA la semana, también lo escrito fuera de la
    franja Desde–Hasta. La franja no se toca: es cómo se mira, no lo escrito.

    VIAJA COMO CUALQUIER BORRADO: los disparadores de la sincronización apuntan
    cada fila, y el horario queda vacío también en los otros aparatos.
    """
    return conexion.execute("DELETE FROM horario_semanal").rowcount


def guardar_franja(conexion: sqlite3.Connection, franja: FranjaHoraria) -> None:
    """Cambia las horas que se ven.

    NO BORRA NADA de lo que quede fuera. Si escribiste algo a las 6:00 y luego
    estrechas la franja a 7→23, ese texto sigue guardado: la pantalla avisa de
    que hay cosas fuera de la franja y basta con volver a abrirla para verlas.
    Borrar lo que el usuario escribió porque ha cambiado una preferencia de
    visualización sería destruir datos sin pedir permiso.
    """
    ajustes.guardar_franja_horario(conexion, franja)
