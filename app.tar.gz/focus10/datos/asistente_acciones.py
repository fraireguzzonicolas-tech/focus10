"""El asistente con la base: leer lo que necesita saber y ejecutar sus órdenes.

LAS ÓRDENES LLEGAN YA COMPROBADAS (dominio/asistente_*.py). Aquí solo se
guardan, con las mismas funciones que usan las pantallas: crear un hábito por
voz deja exactamente lo mismo que crearlo a mano.
"""

from __future__ import annotations

import sqlite3
from dataclasses import replace
from datetime import date, datetime, timedelta

from ..dominio.asistente import Contexto
from ..dominio.asistente_comidas import RegistrarComida
from ..dominio.asistente_correcciones import CorregirComida, CorregirMovimiento
from ..dominio.asistente_finanzas import Apuntar
from ..dominio.asistente_gimnasio import AnotarSeries, CorregirSerie, TerminarEntreno
from ..dominio.asistente_habitos import BorrarHabito, CambiarHabito, CrearHabito
from ..dominio.asistente_organizacion import (
    CompletarRecordatorio,
    CrearRecordatorio,
    MarcarHabito,
)
from ..dominio.movimiento import Tipo
from ..dominio.sesion import EjercicioDeSesion, Sesion
from . import ajustes, asistente_resumen, repositorio_alimentacion, repositorio_categorias
from . import repositorio_dias
from . import repositorio_ejercicios, repositorio_entreno, repositorio_gimnasio
from . import repositorio_habitos, repositorio_movimientos, repositorio_tareas
from .memoria_gastos import recordados


def contexto(conexion: sqlite3.Connection, hoy: date, iconos: tuple[str, ...]) -> Contexto:
    habitos = repositorio_habitos.listar(conexion)
    return Contexto(
        hoy=hoy,
        principal=ajustes.leer_moneda_principal(conexion),
        categorias=[
            una
            for tipo in (Tipo.GASTO, Tipo.INGRESO, Tipo.AHORRO, Tipo.RETIRADA_AHORRO)
            for una in repositorio_categorias.listar(conexion, tipo=tipo)
        ],
        memoria=recordados(conexion),
        habitos=habitos,
        con_historial=frozenset(
            uno.id for uno in habitos if repositorio_habitos.tiene_marcas(conexion, uno.id)
        ),
        iconos=iconos,
        jornada=repositorio_dias.jornada_abierta(conexion),
        ahora=datetime.now(),
        comidas_conocidas=tuple(
            registro for registro, _ in repositorio_alimentacion.mas_repetidos(conexion)
        ),
        biblioteca=tuple(repositorio_ejercicios.listar(conexion)),
        sesion_hoy=repositorio_gimnasio.sesion_de(conexion, repositorio_dias.jornada_abierta(conexion)),
        ejercicios_recientes=frozenset(
            uno.ejercicio_id
            for sesion in repositorio_gimnasio.sesiones_entre(conexion, hoy - timedelta(days=42), hoy)
            for uno in sesion.ejercicios
            if uno.hechas and uno.ejercicio_id is not None
        ),
        comidas_de_hoy=tuple(repositorio_alimentacion.listar_del_dia(
            conexion, repositorio_dias.jornada_abierta(conexion))),
        ultimo_movimiento=_ultimo_movimiento(conexion),
        tareas_pendientes=tuple(repositorio_tareas.listar_pendientes(conexion)),
        resumen=asistente_resumen.resumen_para_la_ia(
            conexion, hoy, repositorio_dias.jornada_abierta(conexion)
        ),
    )


def _cuanto_llevas(conexion: sqlite3.Connection, jornada: date) -> str:
    """«. Hoy llevás 1540 kcal de 2800»: el total del día, YA GUARDADO.

    SE LEE DE LA BASE DESPUÉS DE GUARDAR, no se suma aparte: así el número es
    exactamente el que ves en Alimentación.
    """
    kcal = sum(r.kcal for r in repositorio_alimentacion.listar_del_dia(conexion, jornada))
    objetivo = repositorio_alimentacion.leer_objetivos(conexion).kcal
    de_cuanto = f" de {objetivo}" if objetivo else ""
    cuando = "Hoy" if jornada == repositorio_dias.jornada_abierta(conexion) else "Ese día"
    return f". {cuando} llevás {kcal} kcal{de_cuanto}"


def _ultimo_movimiento(conexion: sqlite3.Connection):
    """El último apuntado en el día abierto, o None. El último POR ID: es el
    que se apuntó último, aunque su hora diga otra cosa."""
    del_dia = repositorio_movimientos.listar(
        conexion, desde=repositorio_dias.jornada_abierta(conexion),
        hasta=repositorio_dias.jornada_abierta(conexion),
    )
    return max(del_dia, key=lambda uno: uno.id or 0, default=None)


def _anotar(conexion: sqlite3.Connection, orden: AnotarSeries) -> None:
    """Las series dichas, en el entreno del día, CON LAS MISMAS FUNCIONES que la
    pantalla de entrenar (datos/repositorio_entreno.py).

    Si ese ejercicio ya estaba en el entreno, se completan sus series sin hacer,
    en orden; lo que sobra se suma detrás. Lo ya hecho no se toca. Si no había
    entreno hoy, se crea uno suelto (sin cronómetro: no se sabe cuándo empezó).
    """
    sesion = repositorio_gimnasio.sesion_de(conexion, orden.jornada)
    if sesion is None:
        sesion = repositorio_gimnasio.guardar_sesion(conexion, Sesion(fecha=orden.jornada))
    existente = next(
        (uno for uno in sorted(sesion.ejercicios, key=lambda e: e.orden)
         if uno.ejercicio_id == orden.ejercicio.id),
        None,
    )
    if existente is None:
        repositorio_entreno.anadir_ejercicio(conexion, sesion.id, EjercicioDeSesion(
            ejercicio_id=orden.ejercicio.id, nombre=orden.ejercicio.nombre,
            orden=max((uno.orden for uno in sesion.ejercicios), default=-1) + 1,
            series=orden.series,
        ))
        return
    libres = [serie for serie in existente.series if not serie.hecha]
    for dicha, libre in zip(orden.series, libres):
        repositorio_entreno.actualizar_serie(conexion, replace(
            libre, peso=dicha.peso, repeticiones=dicha.repeticiones,
            segundos=dicha.segundos, hecha=True,
        ))
    siguiente = max((serie.numero for serie in existente.series), default=0)
    for dicha in orden.series[len(libres):]:
        siguiente += 1
        repositorio_entreno.anadir_serie(conexion, existente.id, replace(dicha, numero=siguiente))


def ejecutar(conexion: sqlite3.Connection, orden) -> str:
    """Hace la orden y devuelve la frase de lo que hizo («creé «Gimnasio»…»)."""
    if isinstance(orden, Apuntar):
        repositorio_movimientos.apuntar_ahora(
            conexion, orden.tipo, orden.importe, orden.moneda,
            orden.categoria.id, orden.descripcion,
        )
    elif isinstance(orden, RegistrarComida):
        for registro in orden.registros:
            repositorio_alimentacion.crear(conexion, registro)
        return orden.frase() + _cuanto_llevas(conexion, orden.registros[0].jornada)
    elif isinstance(orden, CorregirComida):
        repositorio_alimentacion.actualizar(conexion, orden.despues)
    elif isinstance(orden, CorregirMovimiento):
        repositorio_movimientos.actualizar(conexion, orden.despues)
    elif isinstance(orden, AnotarSeries):
        _anotar(conexion, orden)
    elif isinstance(orden, CorregirSerie):
        repositorio_entreno.actualizar_serie(conexion, orden.serie)
    elif isinstance(orden, TerminarEntreno):
        repositorio_entreno.terminar(conexion, orden.sesion.id, orden.segundos)
    elif isinstance(orden, MarcarHabito):
        repositorio_habitos.marcar(conexion, orden.habito.id, orden.jornada, orden.cantidad)
    elif isinstance(orden, CrearRecordatorio):
        repositorio_tareas.crear(conexion, orden.tarea)
    elif isinstance(orden, CompletarRecordatorio):
        repositorio_tareas.marcar(conexion, orden.tarea.id, orden.jornada)
    elif isinstance(orden, CrearHabito):
        repositorio_habitos.crear(conexion, orden.habito)
    elif isinstance(orden, CambiarHabito):
        repositorio_habitos.actualizar(conexion, orden.despues)
    elif isinstance(orden, BorrarHabito):
        # LA MISMA REGLA QUE SU PANTALLA (dialogo_habito.confirmar_borrado):
        # con marcas se archiva, sin marcas se borra.
        if orden.archivar:
            repositorio_habitos.cambiar_actividad(conexion, orden.habito.id, False)
        else:
            repositorio_habitos.borrar(conexion, orden.habito.id)
    else:
        raise TypeError(f"orden desconocida: {type(orden).__name__}")
    return orden.frase()
