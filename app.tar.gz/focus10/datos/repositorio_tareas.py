"""Guardar y leer las tareas sueltas del día.

POR QUÉ LA CONSULTA DEL DÍA ES COMO ES: la lista de un día son dos cosas, y por
eso el WHERE tiene dos ramas. Las tareas apuntadas PARA ese día, y las de días
anteriores que siguen pendientes y por tanto se arrastran. La regla exacta vive
en dominio/tarea.py (Tarea.toca_en); aquí solo se traen las filas candidatas.
"""

from __future__ import annotations

import sqlite3
from datetime import date

from ..dominio.tarea import Tarea
from .fechas import dia_a_texto, dia_desde_texto


class TareaNoExiste(LookupError):
    """Se pidió tocar una tarea que no está."""


def listar_del_dia(conexion: sqlite3.Connection, dia: date) -> list[Tarea]:
    """Las tareas que hay que enseñar ese día.

    Las de ese día (hechas o no) más las anteriores que siguen pendientes. Las
    de días futuros no salen: apuntar algo para el viernes no debe ensuciar el
    jueves.
    """
    texto = dia_a_texto(dia)
    filas = conexion.execute(
        """
        SELECT * FROM tareas
        WHERE jornada = ?
           OR hecha_en = ?
           OR (jornada < ? AND hecha_en IS NULL)
        """,
        (texto, texto, texto),
    ).fetchall()
    return [_desde_fila(fila) for fila in filas]


def listar_pendientes(conexion: sqlite3.Connection) -> list[Tarea]:
    """Todo lo que sigue sin hacer, sea de cuando sea."""
    filas = conexion.execute(
        "SELECT * FROM tareas WHERE hecha_en IS NULL"
    ).fetchall()
    return [_desde_fila(fila) for fila in filas]


def crear(conexion: sqlite3.Connection, tarea: Tarea) -> Tarea:
    cursor = conexion.execute(
        """
        INSERT INTO tareas (titulo, jornada, hecha_en, nota, orden)
        VALUES (?, ?, ?, ?, ?)
        """,
        (
            tarea.titulo,
            dia_a_texto(tarea.jornada),
            dia_a_texto(tarea.hecha_en) if tarea.hecha_en else None,
            tarea.nota,
            tarea.orden if tarea.orden else _siguiente_orden(conexion),
        ),
    )
    return obtener(conexion, cursor.lastrowid)


def actualizar(conexion: sqlite3.Connection, tarea: Tarea) -> Tarea:
    if tarea.id is None:
        raise ValueError("para actualizar hace falta el id de la tarea")
    _exigir(conexion, tarea.id)
    conexion.execute(
        """
        UPDATE tareas SET titulo = ?, jornada = ?, hecha_en = ?, nota = ?, orden = ?
        WHERE id = ?
        """,
        (
            tarea.titulo,
            dia_a_texto(tarea.jornada),
            dia_a_texto(tarea.hecha_en) if tarea.hecha_en else None,
            tarea.nota,
            tarea.orden,
            tarea.id,
        ),
    )
    return obtener(conexion, tarea.id)


def marcar(
    conexion: sqlite3.Connection, id_tarea: int, dia: date | None
) -> Tarea:
    """Dar por hecha una tarea el día que se diga, o devolverla a pendiente.

    `dia` a None es "deshacer": se borra el día en que se hizo y la tarea vuelve
    a arrastrarse. La jornada NO se toca en ningún caso, que es lo que mantiene
    honesto el historial.
    """
    _exigir(conexion, id_tarea)
    conexion.execute(
        "UPDATE tareas SET hecha_en = ? WHERE id = ?",
        (dia_a_texto(dia) if dia is not None else None, id_tarea),
    )
    return obtener(conexion, id_tarea)


def borrar(conexion: sqlite3.Connection, id_tarea: int) -> None:
    _exigir(conexion, id_tarea)
    conexion.execute("DELETE FROM tareas WHERE id = ?", (id_tarea,))


def obtener(conexion: sqlite3.Connection, id_tarea: int) -> Tarea | None:
    fila = conexion.execute(
        "SELECT * FROM tareas WHERE id = ?", (id_tarea,)
    ).fetchone()
    return _desde_fila(fila) if fila else None


# --------------------------------------------------------------------------


def _siguiente_orden(conexion: sqlite3.Connection) -> int:
    fila = conexion.execute(
        "SELECT COALESCE(MAX(orden), 0) + 1 AS siguiente FROM tareas"
    ).fetchone()
    return int(fila["siguiente"])


def _exigir(conexion: sqlite3.Connection, id_tarea: int) -> Tarea:
    tarea = obtener(conexion, id_tarea)
    if tarea is None:
        raise TareaNoExiste(f"no hay ninguna tarea con id {id_tarea}")
    return tarea


def _desde_fila(fila: sqlite3.Row) -> Tarea:
    return Tarea(
        id=int(fila["id"]),
        titulo=fila["titulo"],
        jornada=dia_desde_texto(fila["jornada"]),
        hecha_en=dia_desde_texto(fila["hecha_en"]) if fila["hecha_en"] else None,
        nota=fila["nota"],
        orden=int(fila["orden"]),
    )
