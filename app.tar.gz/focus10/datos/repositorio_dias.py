"""Guardar y leer los días de la aplicación.

SIEMPRE HAY UNO ABIERTO, Y SOLO UNO. Es la pieza de la que cuelga todo lo demás:
cada comida, cada gasto y cada marca de hábito se guarda con la fecha del día
abierto, así que si no hubiera ninguno no se podría apuntar nada, y si hubiera
dos no se sabría en cuál cae lo que apuntas.

POR ESO SE ABRE SOLO CUANDO HACE FALTA: la migración crea el primero, y cerrar
uno abre el siguiente en el mismo movimiento. Nunca queda un hueco en medio.
"""

from __future__ import annotations

import sqlite3
from datetime import date, datetime

from ..dominio.dia import Dia, siguiente
from .fechas import dia_a_texto, dia_desde_texto


class NoHayDiaAbierto(RuntimeError):
    """No hay ningún día abierto, y eso no debería poder pasar.

    SE AVISA EN VEZ DE ABRIR UNO POR LAS BRAVAS: si la aplicación se pusiera a
    crear días para salir del paso, taparía el fallo de verdad —que algo cerró
    un día sin abrir el siguiente— y el historial acabaría con días inventados.
    """


def abierto(conexion: sqlite3.Connection) -> Dia:
    """El día que está abierto ahora mismo."""
    fila = conexion.execute(
        "SELECT * FROM dias WHERE cerrado_en IS NULL ORDER BY numero LIMIT 1"
    ).fetchone()
    if fila is None:
        raise NoHayDiaAbierto(
            "no hay ningún día abierto: la base de datos está en un estado que "
            "no debería poder darse"
        )
    return _desde_fila(fila)


def reabrir(conexion: sqlite3.Connection, *, ahora: datetime) -> Dia:
    """Abre un dia cuando NO QUEDA NINGUNO abierto. Devuelve el nuevo.

    CUANDO PASA ESTO DE VERDAD: `cerrar` deja el dia siguiente abierto en el
    mismo movimiento, asi que no abre huecos. El hueco lo abre la
    SINCRONIZACION: si cierras el dia en el ordenador, el telefono recibe
    primero la fila del dia cerrado y, mientras no le llegue la del dia nuevo,
    se queda con todos los dias cerrados. En ese rato la aplicacion no podia ni
    arrancar, porque TODO cuelga del dia abierto.

    NO SE LLAMA SOLA, LA LLAMA EL USUARIO desde el aviso que sale en pantalla.
    Abrir dias por las bravas taparia el fallo de verdad y llenaria el
    historial de dias inventados; que lo pida una persona deja claro que ese
    dia existe porque alguien dijo que existe.

    SI YA HAY UNO ABIERTO NO HACE NADA y lo devuelve: dos dias abiertos serian
    peor que ninguno, porque no se sabria en cual cae lo que apuntas.
    """
    ultimo = conexion.execute(
        "SELECT * FROM dias ORDER BY numero DESC LIMIT 1"
    ).fetchone()
    if ultimo is not None and ultimo["cerrado_en"] is None:
        return _desde_fila(ultimo)

    if ultimo is None:
        # NI UN DIA EN LA BASE: no hay nada de lo que continuar, asi que este
        # es el dia 1. Pasa con una base recien creada a la que le fallo la
        # migracion inicial.
        nuevo = Dia(numero=1, jornada=ahora.date(), abierto_en=ahora)
    else:
        nuevo = siguiente(_desde_fila(ultimo), ahora)

    with conexion:
        cursor = conexion.execute(
            "INSERT INTO dias (numero, jornada, abierto_en) VALUES (?, ?, ?)",
            (
                nuevo.numero,
                dia_a_texto(nuevo.jornada),
                nuevo.abierto_en.isoformat(" ", "seconds"),
            ),
        )
    return _desde_fila(
        conexion.execute(
            "SELECT * FROM dias WHERE id = ?", (cursor.lastrowid,)
        ).fetchone()
    )


def jornada_abierta(conexion: sqlite3.Connection) -> date:
    """La fecha con la que se guarda todo lo que apuntes ahora.

    ES LA QUE SUSTITUYE A LA VIEJA jornada_actual(horario). Antes salía de
    comparar el reloj con una hora configurada; ahora sale de qué día tienes
    abierto, que es lo que pidió el usuario.
    """
    return abierto(conexion).jornada


def listar(conexion: sqlite3.Connection, *, limite: int | None = None) -> list[Dia]:
    """Los días, del más nuevo al más viejo."""
    sentencia = "SELECT * FROM dias ORDER BY numero DESC"
    if limite is not None:
        sentencia += f" LIMIT {int(limite):d}"
    return [_desde_fila(fila) for fila in conexion.execute(sentencia)]



def entre(conexion: sqlite3.Connection, desde: date, hasta: date) -> list[Dia]:
    """Los dias de ese tramo, con su valoracion y su reflexion.

    LO USA EL RESUMEN DEL MES: la nota del dia sale de aqui, y pedirla dia a dia
    serian treinta consultas para pintar un calendario.
    """
    filas = conexion.execute(
        "SELECT * FROM dias WHERE jornada BETWEEN ? AND ? ORDER BY jornada",
        (dia_a_texto(desde), dia_a_texto(hasta)),
    ).fetchall()
    return [_desde_fila(fila) for fila in filas]


def cerrar(
    conexion: sqlite3.Connection,
    *,
    valoracion: int,
    reflexion: str,
    ahora: datetime,
) -> Dia:
    """Cierra el día abierto y abre el siguiente. Devuelve el nuevo.

    LAS DOS COSAS VAN JUNTAS Y EN UNA SOLA TRANSACCIÓN: si se cerrara uno y
    fallara la apertura del siguiente, la aplicación se quedaría sin día abierto
    y no se podría apuntar nada hasta arreglarlo a mano.
    """
    hoy = abierto(conexion)
    cerrado = Dia(
        id=hoy.id,
        numero=hoy.numero,
        jornada=hoy.jornada,
        abierto_en=hoy.abierto_en,
        cerrado_en=ahora,
        valoracion=valoracion,
        reflexion=reflexion,
    )
    nuevo = siguiente(cerrado, ahora)

    with conexion:
        conexion.execute(
            "UPDATE dias SET cerrado_en = ?, valoracion = ?, reflexion = ?"
            " WHERE id = ?",
            (
                cerrado.cerrado_en.isoformat(" ", "seconds"),
                cerrado.valoracion,
                cerrado.reflexion,
                cerrado.id,
            ),
        )
        cursor = conexion.execute(
            "INSERT INTO dias (numero, jornada, abierto_en) VALUES (?, ?, ?)",
            (
                nuevo.numero,
                dia_a_texto(nuevo.jornada),
                nuevo.abierto_en.isoformat(" ", "seconds"),
            ),
        )
    return _desde_fila(
        conexion.execute(
            "SELECT * FROM dias WHERE id = ?", (cursor.lastrowid,)
        ).fetchone()
    )


def _desde_fila(fila: sqlite3.Row) -> Dia:
    return Dia(
        id=int(fila["id"]),
        numero=int(fila["numero"]),
        jornada=dia_desde_texto(fila["jornada"]),
        abierto_en=datetime.fromisoformat(fila["abierto_en"]),
        cerrado_en=(
            None
            if fila["cerrado_en"] is None
            else datetime.fromisoformat(fila["cerrado_en"])
        ),
        valoracion=None if fila["valoracion"] is None else int(fila["valoracion"]),
        reflexion=fila["reflexion"],
    )
