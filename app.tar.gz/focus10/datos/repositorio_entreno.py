"""Los cambios de un entreno EN MARCHA, fila por fila.

POR QUÉ EXISTE, Y ES LA CAUSA DE QUE EDITAR FUERA LENTO: antes cada cambio, por
pequeño que fuera (un 10 por un 8), pasaba por `guardar_sesion`, que BORRA el
entreno entero de la base y lo vuelve a escribir. Con seis ejercicios de cuatro
series eran treinta borrados y treinta altas por cada número, y como el entreno
viaja a la nube, cada número subía el entreno entero como si fuera nuevo.

Aquí cada cambio toca SOLO SU FILA: cambiar las repeticiones de una serie es un
UPDATE de esa serie. Las demás no se leen ni se escriben, y por eso tampoco se
pueden pisar (era el otro fallo: tocar una serie podía devolver otra a lo viejo).

`guardar_sesion` sigue para crear un entreno de cero (`empezar`).
"""

from __future__ import annotations

import sqlite3
from dataclasses import replace
from datetime import date, datetime

from ..dominio.rutina import BloqueDeRutina, DiaDeRutina
from ..dominio.sesion import EjercicioDeSesion, Serie, Sesion, TipoSerie, desde_rutina
from . import repositorio_gimnasio
from .repositorio_gimnasio import al_fallo
from .fechas import dia_a_texto


def ultimas_reales(
    conexion: sqlite3.Connection, ids: list[int], antes_de: date
) -> dict[int, tuple[Serie, ...]]:
    """De cada ejercicio, las series MARCADAS de la última vez que se hizo.

    «LA ÚLTIMA VEZ QUE SE HIZO» ES LA ÚLTIMA CON ALGO MARCADO: un entreno que
    abriste y no hiciste no borra lo que levantaste la semana anterior.

    UNA CONSULTA PARA TODOS, no una por ejercicio: se llama al empezar.
    """
    ids = [uno for uno in ids if uno is not None]
    if not ids:
        return {}
    huecos = ", ".join("?" for _ in ids)
    filas = conexion.execute(
        f"""
        SELECT se.id, se.ejercicio_id
          FROM sesion_ejercicios se
          JOIN sesiones s ON s.id = se.sesion_id
         WHERE se.ejercicio_id IN ({huecos})
           AND s.fecha < ?
           AND EXISTS (SELECT 1 FROM series x WHERE x.sesion_ejercicio_id = se.id AND x.hecha = 1)
         ORDER BY s.fecha DESC, se.id DESC
        """,
        (*ids, dia_a_texto(antes_de)),
    ).fetchall()
    reales: dict[int, tuple[Serie, ...]] = {}
    for fila in filas:
        if fila["ejercicio_id"] in reales:
            continue
        series = conexion.execute(
            "SELECT * FROM series WHERE sesion_ejercicio_id = ? AND hecha = 1 ORDER BY numero",
            (int(fila["id"]),),
        ).fetchall()
        reales[int(fila["ejercicio_id"])] = tuple(
            Serie(numero=indice, peso=int(una["peso"]), repeticiones=int(una["repeticiones"]),
                  segundos=int(una["segundos"]), metros=int(una["metros"]), hecha=True,
                  tipo=TipoSerie(una["tipo"]))
            for indice, una in enumerate(series, start=1)
        )
    return reales


def empezar(
    conexion: sqlite3.Connection, dia: DiaDeRutina, fecha: date, ahora: datetime,
    bloque: BloqueDeRutina | None = None,
) -> Sesion:
    """Crea el entreno del día con la rutina y lo último real de cada ejercicio.

    LO USAN EL BOTÓN DE LA RUTINA Y EL DEL DASHBOARD, y por eso está aquí: antes
    cada uno lo armaba por su cuenta, y los dos copiaban solo el plan.
    """
    planeados = dia.ejercicios if bloque is None else bloque.ejercicios
    reales = ultimas_reales(conexion, [uno.ejercicio_id for uno in planeados], fecha)
    sesion = desde_rutina(dia, fecha, reales, bloque)
    sesion = replace(sesion, empezada_en=ahora, ejercicios=tuple(
        replace(uno, nota=ultima_nota(conexion, uno.ejercicio_id, fecha)) for uno in sesion.ejercicios
    ))
    return repositorio_gimnasio.guardar_sesion(conexion, sesion)


def ultima_nota(conexion: sqlite3.Connection, ejercicio_id: int | None, antes_de: date) -> str:
    """La nota de la última vez que hiciste ese ejercicio, antes de esa fecha.

    LA DE LA ÚLTIMA VEZ AUNQUE ESTÉ VACÍA: la nota se copia sola de una vez a
    la siguiente, así que una vacía es una que BORRASTE. Si se buscara la
    última no vacía, la que borraste volvería a aparecer la semana siguiente.
    """
    if ejercicio_id is None:
        return ""
    fila = conexion.execute(
        """
        SELECT se.nota FROM sesion_ejercicios se JOIN sesiones s ON s.id = se.sesion_id
         WHERE se.ejercicio_id = ? AND s.fecha < ?
         ORDER BY s.fecha DESC, se.id DESC LIMIT 1
        """,
        (ejercicio_id, dia_a_texto(antes_de)),
    ).fetchone()
    return fila["nota"] if fila else ""


def actualizar_serie(conexion: sqlite3.Connection, serie: Serie) -> None:
    """Guarda una serie, SOLO ESA. Necesita su id (viene de la base)."""
    if serie.id is None:
        raise ValueError("la serie todavía no está guardada")
    conexion.execute(
        "UPDATE series SET peso = ?, repeticiones = ?, hecha = ?, rpe = ?, "
        "tipo = ?, al_fallo = ?, segundos = ?, metros = ? WHERE id = ?",
        (serie.peso, serie.repeticiones, int(serie.hecha), serie.rpe,
         serie.tipo.value, al_fallo(serie), serie.segundos, serie.metros, serie.id),
    )


def anadir_serie(conexion: sqlite3.Connection, id_ejercicio: int, serie: Serie) -> Serie:
    cursor = conexion.execute(
        "INSERT INTO series (sesion_ejercicio_id, numero, peso, repeticiones, hecha, "
        "rpe, tipo, al_fallo, segundos, metros) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (id_ejercicio, serie.numero, serie.peso, serie.repeticiones, int(serie.hecha),
         serie.rpe, serie.tipo.value, al_fallo(serie), serie.segundos, serie.metros),
    )
    return replace(serie, id=cursor.lastrowid)


def quitar_serie(conexion: sqlite3.Connection, id_ejercicio: int, numero: int) -> None:
    """Quita una serie y corre un puesto las de detrás (la 3 pasa a ser la 2).

    Renumerar hace falta por lo mismo que en dominio/sesion.quitar_serie: «la
    última vez» compara la serie 2 de hoy con la 2 de otro día.
    """
    conexion.execute(
        "DELETE FROM series WHERE sesion_ejercicio_id = ? AND numero = ?",
        (id_ejercicio, numero),
    )
    conexion.execute(
        "UPDATE series SET numero = numero - 1 WHERE sesion_ejercicio_id = ? AND numero > ?",
        (id_ejercicio, numero),
    )


def actualizar_ejercicio(conexion: sqlite3.Connection, ejercicio: EjercicioDeSesion) -> None:
    """Lo del ejercicio que no son sus series: cuál es, su sitio y su descanso."""
    if ejercicio.id is None:
        raise ValueError("el ejercicio todavía no está guardado")
    conexion.execute(
        "UPDATE sesion_ejercicios SET ejercicio_id = ?, nombre = ?, orden = ?, "
        "descanso = ?, nota = ? WHERE id = ?",
        (ejercicio.ejercicio_id, ejercicio.nombre, ejercicio.orden, ejercicio.descanso,
         ejercicio.nota, ejercicio.id),
    )


def anadir_ejercicio(
    conexion: sqlite3.Connection, id_sesion: int, ejercicio: EjercicioDeSesion
) -> EjercicioDeSesion:
    cursor = conexion.execute(
        "INSERT INTO sesion_ejercicios (sesion_id, ejercicio_id, nombre, orden, descanso, nota) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (id_sesion, ejercicio.ejercicio_id, ejercicio.nombre, ejercicio.orden,
         ejercicio.descanso, ejercicio.nota),
    )
    id_nuevo = cursor.lastrowid
    series = tuple(anadir_serie(conexion, id_nuevo, una) for una in ejercicio.series)
    return replace(ejercicio, id=id_nuevo, series=series)


def quitar_ejercicio(conexion: sqlite3.Connection, id_ejercicio: int) -> None:
    conexion.execute("DELETE FROM series WHERE sesion_ejercicio_id = ?", (id_ejercicio,))
    conexion.execute("DELETE FROM sesion_ejercicios WHERE id = ?", (id_ejercicio,))


def terminar(conexion: sqlite3.Connection, id_sesion: int, segundos: int) -> None:
    """Congela la duración. SOLO ESO: no reescribe las series con nada viejo.

    Antes «Terminar» guardaba la sesión entera tal como estaba al último
    repintado: lo escrito justo antes de tocarlo se podía perder.
    """
    conexion.execute("UPDATE sesiones SET segundos = ? WHERE id = ?", (segundos, id_sesion))
