"""Los ajustes: una tabla de clave -> valor, y el horario que vive en ella.

POR QUÉ los valores predeterminados están en el código y no insertados por la
migración: así hay UN solo sitio donde se decide cuánto vale un ajuste que
nunca se ha tocado. Si estuvieran insertados en la migración 1, cambiar un
valor por omisión exigiría otra migración, y quien ya la hubiera aplicado
seguiría con el viejo.

POR QUÉ solo se admiten las claves declaradas aquí: una clave mal escrita al
guardar ("jornada.inico") no daría ningún error y el ajuste se leería siempre
con su valor por omisión, sin que nadie entendiera por qué no se guarda nada.
Con la lista cerrada, el fallo salta en el momento.
"""

from __future__ import annotations

import sqlite3

from ..dominio.jornada import Horario
from ..dominio.semana import FranjaHoraria
from ..dominio.moneda import Moneda, por_codigo
from .conexion import transaccion

CLAVE_JORNADA_INICIO = "jornada.inicio"
CLAVE_JORNADA_FIN = "jornada.fin"
CLAVE_TEMA = "interfaz.tema"
CLAVE_NOMBRE = "usuario.nombre"
CLAVE_MONEDA = "dinero.principal"
CLAVE_ESTILO = "interfaz.estilo"
CLAVE_HORARIO_DESDE = "horario.desde"
CLAVE_HORARIO_HASTA = "horario.hasta"

# Turno de noche como punto de partida, que es el del usuario. Se cambia desde
# la aplicación; esto es solo lo que vale antes de tocarlo por primera vez.
PREDETERMINADOS: dict[str, str] = {
    CLAVE_JORNADA_INICIO: "18:00",
    CLAVE_JORNADA_FIN: "10:00",
    # "sistema", "claro" u "oscuro". De partida sigue a Windows, que es lo que
    # el usuario ya ha decidido una vez para todo su ordenador.
    CLAVE_TEMA: "sistema",
    # Vacío a propósito: si no lo has puesto, la aplicación no se inventa un
    # nombre ni te llama "usuario".
    CLAVE_NOMBRE: "",
    # La moneda en la que se enseñan los totales.
    CLAVE_MONEDA: "EUR",
    # EL ESTILO VISUAL, que es distinto del tema: el estilo dice de qué
    # colores es la aplicación y el tema si van en su versión clara u
    # oscura. Los cinco estilos tienen las dos. El de partida lo eligió el
    # usuario: el blanco y negro.
    CLAVE_ESTILO: "elegante",
    # LA FRANJA DEL HORARIO SEMANAL, la primera y la última hora de la rejilla.
    # De 7 a 23 lo eligió el usuario. Se guardan como número de hora suelto y no
    # como "07:00" porque la rejilla va de hora en hora: guardar unos minutos
    # que siempre son cero invita a que algún día alguien ponga otros.
    CLAVE_HORARIO_DESDE: "7",
    CLAVE_HORARIO_HASTA: "23",
}


class ClaveDesconocida(KeyError):
    """Se ha pedido un ajuste que no está declarado en PREDETERMINADOS."""


def leer(conexion: sqlite3.Connection, clave: str) -> str:
    """Devuelve el ajuste guardado, o su valor por omisión si nunca se tocó."""
    _exigir_clave(clave)
    fila = conexion.execute(
        "SELECT valor FROM ajustes WHERE clave = ?", (clave,)
    ).fetchone()
    return PREDETERMINADOS[clave] if fila is None else fila["valor"]


def escribir(conexion: sqlite3.Connection, clave: str, valor: str) -> None:
    """Guarda un ajuste, sobrescribiendo el anterior si lo hubiera.

    No abre transacción a propósito: con la conexión en modo autoconfirmar,
    esta sentencia sola ya es atómica, y así quien necesite guardar varios
    ajustes de golpe puede envolverlos en una transaccion() propia sin que se
    solapen dos BEGIN.
    """
    _exigir_clave(clave)
    if not isinstance(valor, str):
        raise TypeError(
            f"los ajustes se guardan como texto, no {type(valor).__name__}"
        )
    conexion.execute(
        """
        INSERT INTO ajustes (clave, valor) VALUES (?, ?)
        ON CONFLICT(clave) DO UPDATE SET valor = excluded.valor
        """,
        (clave, valor),
    )


def leer_horario(conexion: sqlite3.Connection) -> Horario:
    """El horario de trabajo vigente.

    Si el texto guardado estuviera corrupto (alguien editando el .db a mano),
    Horario.desde_texto lanza un error con el valor exacto. Es a propósito:
    caer en silencio al horario por omisión cambiaría la jornada de todos los
    registros nuevos sin avisar.
    """
    return Horario.desde_texto(
        leer(conexion, CLAVE_JORNADA_INICIO),
        leer(conexion, CLAVE_JORNADA_FIN),
    )


def guardar_horario(conexion: sqlite3.Connection, horario: Horario) -> None:
    """Guarda las dos horas juntas, en una sola transacción.

    Van juntas porque un horario a medias (inicio nuevo con fin viejo) podría
    ser un turno que no existe, y con él se etiquetarían registros.
    """
    if not isinstance(horario, Horario):
        raise TypeError(f"se esperaba un Horario, no {type(horario).__name__}")
    inicio, fin = horario.a_texto()
    with transaccion(conexion):
        escribir(conexion, CLAVE_JORNADA_INICIO, inicio)
        escribir(conexion, CLAVE_JORNADA_FIN, fin)


def leer_franja_horario(conexion: sqlite3.Connection) -> FranjaHoraria:
    """La franja de horas del horario semanal.

    SI EL VALOR GUARDADO NO VALE, se cae con el valor exacto en vez de volver
    calladamente a 7-23: si alguien edita el .db a mano y deja "siete", cambiar
    la franja en silencio escondería casillas escritas sin decir por qué.
    """
    return FranjaHoraria(
        desde=_hora_entera(leer(conexion, CLAVE_HORARIO_DESDE), CLAVE_HORARIO_DESDE),
        hasta=_hora_entera(leer(conexion, CLAVE_HORARIO_HASTA), CLAVE_HORARIO_HASTA),
    )


def guardar_franja_horario(
    conexion: sqlite3.Connection, franja: FranjaHoraria
) -> None:
    """Guarda las dos horas JUNTAS, en una sola transacción.

    Igual que la jornada: una franja a medias —el inicio nuevo con el fin
    viejo— puede ser un tramo que no existe, y con él se dibujaría la rejilla.
    """
    if not isinstance(franja, FranjaHoraria):
        raise TypeError(
            f"se esperaba una FranjaHoraria, no {type(franja).__name__}"
        )
    with transaccion(conexion):
        escribir(conexion, CLAVE_HORARIO_DESDE, str(franja.desde))
        escribir(conexion, CLAVE_HORARIO_HASTA, str(franja.hasta))


def _hora_entera(valor: str, clave: str) -> int:
    try:
        return int(valor)
    except (TypeError, ValueError):
        raise ValueError(
            f"el ajuste «{clave}» tiene que ser un número de hora, "
            f"y hay guardado {valor!r}"
        ) from None


def _exigir_clave(clave: str) -> None:
    if clave not in PREDETERMINADOS:
        raise ClaveDesconocida(
            f"ajuste no declarado: {clave!r}. Añádelo a PREDETERMINADOS en "
            "datos/ajustes.py antes de usarlo."
        )


def leer_moneda_principal(conexion: sqlite3.Connection) -> Moneda:
    """La moneda en la que se enseñan los totales.

    Si el código guardado no existe (alguien editó el archivo, o se quitó una
    moneda del catálogo), falla con un mensaje claro en vez de caer al euro sin
    avisar: los totales saldrían en una moneda distinta de la que el usuario cree.
    """
    return por_codigo(leer(conexion, CLAVE_MONEDA))


def leer_estilo(conexion: sqlite3.Connection) -> str:
    """La clave del estilo elegido.

    Devuelve texto y no un Estilo a propósito: esta capa no sabe de interfaz.
    Quien lo pinta traduce la clave, y si estuviera corrupta cae al de por
    omisión en vez de fallar, porque un ajuste raro solo debe costar otro color.
    """
    return leer(conexion, CLAVE_ESTILO)


def guardar_estilo(conexion: sqlite3.Connection, clave: str) -> None:
    escribir(conexion, CLAVE_ESTILO, clave)


def guardar_moneda_principal(conexion: sqlite3.Connection, moneda: Moneda) -> None:
    """Cambia la moneda principal.

    NO toca nada de lo ya guardado, por decisión del usuario: cada movimiento
    conserva su importe y la conversión que tenía el día que se apuntó. Si se
    recalculara todo, el resumen de un mes pasado cambiaría de valor de un día
    para otro.
    """
    if not isinstance(moneda, Moneda):
        raise TypeError(f"se esperaba una Moneda, no {type(moneda).__name__}")
    escribir(conexion, CLAVE_MONEDA, moneda.codigo)
