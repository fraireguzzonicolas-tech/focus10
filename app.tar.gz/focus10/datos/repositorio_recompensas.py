"""Guardar las recompensas y qué semanas ya se resolvieron.

DOS COSAS Y NADA MÁS: la lista de hasta cinco premios que se ha puesto el
usuario, y una fila por cada semana que ya se preguntó. Esa segunda tabla es la
que hace que el aviso salga UNA vez y no en cada arranque.
"""

from __future__ import annotations

import sqlite3
from datetime import date, datetime

from ..dominio.recompensa import MAXIMO_RECOMPENSAS, Recompensa
from .fechas import dia_a_texto


class DemasiadasRecompensas(ValueError):
    """Ya hay cinco. Lo pidió el usuario: entre 0 y 5."""


def listar(conexion: sqlite3.Connection) -> list[Recompensa]:
    return [
        Recompensa(
            id=int(fila["id"]), nombre=fila["nombre"], orden=int(fila["orden"])
        )
        for fila in conexion.execute(
            "SELECT * FROM recompensas ORDER BY orden, id"
        )
    ]


def crear(conexion: sqlite3.Connection, nombre: str) -> Recompensa:
    """Añade una. Falla si ya hay cinco, en vez de callarse."""
    cuantas = conexion.execute("SELECT COUNT(*) FROM recompensas").fetchone()[0]
    if cuantas >= MAXIMO_RECOMPENSAS:
        raise DemasiadasRecompensas(
            f"ya tienes {MAXIMO_RECOMPENSAS} recompensas: quita una para añadir otra"
        )

    # SE VALIDA CON EL DOMINIO ANTES DE TOCAR LA BASE: así un nombre en blanco
    # no llega a escribirse y el error dice qué pasa, no "constraint failed".
    recompensa = Recompensa(nombre=nombre, orden=cuantas)
    cursor = conexion.execute(
        "INSERT INTO recompensas (nombre, orden) VALUES (?, ?)",
        (recompensa.nombre, recompensa.orden),
    )
    return Recompensa(
        id=int(cursor.lastrowid), nombre=recompensa.nombre, orden=recompensa.orden
    )


def borrar(conexion: sqlite3.Connection, id_recompensa: int) -> None:
    conexion.execute("DELETE FROM recompensas WHERE id = ?", (id_recompensa,))


def semana_resuelta(conexion: sqlite3.Connection, domingo: date) -> bool:
    """Si esa semana ya se preguntó.

    ES LO QUE IMPIDE QUE EL AVISO SALGA DOS VECES, y lo pidió el usuario: "si
    abre y cierra la aplicación varias veces, no debe volver a aparecer".
    """
    fila = conexion.execute(
        "SELECT 1 FROM semanas_premiadas WHERE domingo = ?", (dia_a_texto(domingo),)
    ).fetchone()
    return fila is not None


def resolver(
    conexion: sqlite3.Connection,
    *,
    domingo: date,
    porcentaje: int,
    nivel: int,
    elegida: str,
    ahora: datetime,
) -> None:
    """Deja constancia de la semana y de lo que se eligió.

    SE ESCRIBE AUNQUE NO SE ELIJA NADA (`elegida` vacía): cerrar la ventana sin
    elegir también es una respuesta, y volver a preguntar al día siguiente sería
    insistir. La semana queda resuelta igual.
    """
    conexion.execute(
        "INSERT OR REPLACE INTO semanas_premiadas"
        " (domingo, porcentaje, nivel, elegida, elegida_en)"
        " VALUES (?, ?, ?, ?, ?)",
        (
            dia_a_texto(domingo),
            porcentaje,
            nivel,
            elegida,
            ahora.isoformat(" ", "seconds"),
        ),
    )
