"""Dónde vive el archivo de datos.

POR QUÉ en %APPDATA% y no junto al programa: si el .db estuviera en la carpeta
del ejecutable, al reinstalar o mover el programa se llevaría por delante los
datos, y en una instalación bajo "Program Files" Windows ni siquiera deja
escribir. %APPDATA% es la carpeta que Windows reserva para esto, va por
usuario, y las copias de seguridad del sistema ya la incluyen.
"""

from __future__ import annotations

import os
from pathlib import Path

from ..sistema import almacen_navegador

NOMBRE_APP = "Focus10"
"""La CARPETA donde viven los datos, no el nombre que se ve.

NO SE TOCA AUNQUE LA APLICACION CAMBIE DE NOMBRE: aqui dentro estan los
datos de quien ya la usa, y cambiarlo seria abrir la aplicacion en una
carpeta vacia y creer que se ha perdido todo. El nombre que se lee en
pantalla es focus10.NOMBRE."""
NOMBRE_BD = "focus10.db"

# Variable de entorno para forzar otra carpeta. Existe por dos motivos: los
# tests necesitan una carpeta temporal, y algún día puede querer llevar la
# aplicación en un pendrive con sus datos al lado.
VARIABLE_CARPETA = "FOCUS10_DATOS"


def carpeta_datos() -> Path:
    """La carpeta donde se guarda todo. No la crea; solo dice cuál es."""
    forzada = os.environ.get(VARIABLE_CARPETA)
    if forzada:
        return Path(forzada)

    # EN EL NAVEGADOR NO HAY CARPETAS DE USUARIO: el sistema de archivos es
    # inventado y vive en memoria. Se usa la raíz, y de que el archivo no se
    # pierda al recargar se encarga sistema/almacen_navegador.py, que lo copia
    # al almacén del navegador.
    #
    # VA ANTES QUE %APPDATA% a propósito: dentro del navegador esa variable no
    # existe, pero si algún día existiera, seguiría sin ser una carpeta de
    # verdad y el archivo acabaría en un sitio que no se puede recuperar.
    if almacen_navegador.en_el_navegador():
        return Path("/")

    appdata = os.environ.get("APPDATA")
    if appdata:
        return Path(appdata) / NOMBRE_APP

    # Fuera de Windows no existe %APPDATA%. No es el destino de la aplicación,
    # pero conviene que el código no explote: los tests y las herramientas de
    # desarrollo pueden correr en otro sistema.
    return Path.home() / f".{NOMBRE_APP.lower()}"


def ruta_bd() -> Path:
    """La ruta completa del archivo de base de datos."""
    return carpeta_datos() / NOMBRE_BD


def asegurar_carpeta() -> Path:
    """Crea la carpeta de datos si no existe y la devuelve."""
    carpeta = carpeta_datos()
    carpeta.mkdir(parents=True, exist_ok=True)
    return carpeta
