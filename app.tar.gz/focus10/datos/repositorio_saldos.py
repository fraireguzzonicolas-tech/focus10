"""Guardar y leer las anotaciones de ahorro e inversión.

POR QUÉ NO HAY "ACTUALIZAR": un saldo no se corrige, se vuelve a anotar. Cada
fila es la foto de un momento, y una foto pasada no cambia. Si te equivocas al
teclear, borras esa anotación y haces otra.
"""

from __future__ import annotations

import sqlite3
from dataclasses import replace
from decimal import Decimal

from ..dominio.cambio import tasa_a_texto, tasa_desde_texto
from ..dominio.moneda import EUR, Moneda, por_codigo
from ..dominio.saldo import Clase, Saldo
from .conexion import transaccion
from .fechas import dia_a_texto, dia_desde_texto, momento_a_texto, momento_desde_texto

COLUMNAS = "clase, importe, moneda, momento, jornada, nota, tasa, importe_principal"


class SaldoNoExiste(LookupError):
    """No hay ninguna anotación con ese id."""


def anotar(conexion: sqlite3.Connection, saldo: Saldo) -> Saldo:
    """Guarda una anotación nueva y la devuelve ya con su id."""
    if not isinstance(saldo, Saldo):
        raise TypeError(f"se esperaba un Saldo, no {type(saldo).__name__}")
    if saldo.id is not None:
        raise ValueError(
            f"esta anotación ya está guardada (id {saldo.id}); las anotaciones "
            "no se corrigen, se vuelve a anotar"
        )
    cursor = conexion.execute(
        f"INSERT INTO saldos ({COLUMNAS}) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        _a_fila(saldo),
    )
    return replace(saldo, id=cursor.lastrowid)


def ultimo(conexion: sqlite3.Connection, clase: Clase) -> Saldo | None:
    """La anotación más reciente de esa clase, que es "cuánto llevas ahora".

    None si nunca se ha anotado nada: eso es distinto de llevar cero, y quien lo
    enseñe tiene que poder decir "aún no lo has puesto" en vez de "0,00 €".
    """
    _exigir_clase(clase)
    fila = conexion.execute(
        "SELECT * FROM saldos WHERE clase = ? ORDER BY momento DESC, id DESC LIMIT 1",
        (clase.value,),
    ).fetchone()
    return None if fila is None else _desde_fila(fila)


def historial(
    conexion: sqlite3.Connection, clase: Clase, limite: int | None = None
) -> list[Saldo]:
    """Todas las anotaciones de esa clase, de la más reciente a la más antigua."""
    _exigir_clase(clase)
    tope = ""
    parametros: list[object] = [clase.value]
    if limite is not None:
        if isinstance(limite, bool) or not isinstance(limite, int) or limite <= 0:
            raise ValueError(f"el límite tiene que ser un entero positivo: {limite!r}")
        tope = "LIMIT ?"
        parametros.append(limite)

    filas = conexion.execute(
        f"SELECT * FROM saldos WHERE clase = ? ORDER BY momento DESC, id DESC {tope}",
        parametros,
    ).fetchall()
    return [_desde_fila(fila) for fila in filas]


def obtener(conexion: sqlite3.Connection, id_saldo: int) -> Saldo | None:
    fila = conexion.execute("SELECT * FROM saldos WHERE id = ?", (id_saldo,)).fetchone()
    return None if fila is None else _desde_fila(fila)


def borrar(conexion: sqlite3.Connection, id_saldo: int) -> None:
    cursor = conexion.execute("DELETE FROM saldos WHERE id = ?", (id_saldo,))
    if cursor.rowcount == 0:
        raise SaldoNoExiste(f"no existe la anotación {id_saldo}")


def listar_pendientes(conexion: sqlite3.Connection) -> list[Saldo]:
    """Las anotaciones que se hicieron sin poder consultar el tipo de cambio."""
    filas = conexion.execute(
        "SELECT * FROM saldos WHERE tasa IS NULL ORDER BY momento, id"
    ).fetchall()
    return [_desde_fila(fila) for fila in filas]


def resolver_cambio(
    conexion: sqlite3.Connection,
    id_saldo: int,
    tasa: Decimal,
    principal: Moneda = EUR,
) -> Saldo:
    """Pone la tasa a una anotación que estaba pendiente y la guarda."""
    with transaccion(conexion):
        actual = obtener(conexion, id_saldo)
        if actual is None:
            raise SaldoNoExiste(f"no existe la anotación {id_saldo}")
        resuelto = actual.con_tasa(tasa, principal)
        conexion.execute(
            "UPDATE saldos SET tasa = ?, importe_principal = ? WHERE id = ?",
            (tasa_a_texto(resuelto.tasa), resuelto.importe_principal, id_saldo),
        )
    return resuelto


def _exigir_clase(clase: Clase) -> None:
    if not isinstance(clase, Clase):
        raise TypeError(f"clase tiene que ser Clase, no {type(clase).__name__}")


def _a_fila(saldo: Saldo) -> tuple:
    return (
        saldo.clase.value,
        saldo.importe,
        saldo.moneda.codigo,
        momento_a_texto(saldo.momento),
        dia_a_texto(saldo.jornada),
        saldo.nota,
        None if saldo.tasa is None else tasa_a_texto(saldo.tasa),
        saldo.importe_principal,
    )


def _desde_fila(fila: sqlite3.Row) -> Saldo:
    return Saldo(
        id=fila["id"],
        clase=Clase(fila["clase"]),
        importe=fila["importe"],
        moneda=por_codigo(fila["moneda"]),
        momento=momento_desde_texto(fila["momento"]),
        jornada=dia_desde_texto(fila["jornada"]),
        nota=fila["nota"],
        tasa=None if fila["tasa"] is None else tasa_desde_texto(fila["tasa"]),
        importe_principal=fila["importe_principal"],
    )
