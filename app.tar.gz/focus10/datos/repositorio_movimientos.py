"""Guardar y leer los movimientos de dinero.

POR QUÉ SE GUARDA EL IMPORTE CONVERTIDO Y NO SOLO LA TASA: teniendo la tasa se
podría calcular al vuelo, pero entonces sumar un mes obligaría a traer todos los
movimientos a Python y multiplicarlos uno a uno. Guardando el resultado, el
total de un mes es un SUM de SQLite sobre enteros. La tasa se guarda igual, al
lado, para poder comprobar de dónde salió cada cifra.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass, replace
from datetime import date, datetime

from ..dominio.cambio import TASA_UNO, tasa_a_texto, tasa_desde_texto
from ..dominio.moneda import Moneda, por_codigo
from ..dominio.movimiento import Movimiento, Tipo
from . import ajustes
from .conexion import transaccion
from .fechas import dia_a_texto, dia_desde_texto, momento_a_texto, momento_desde_texto
from .repositorio_dias import jornada_abierta

COLUMNAS = (
    "tipo, importe, moneda, categoria_id, descripcion, momento, jornada, "
    "tasa, importe_principal, moneda_principal"
)


class MovimientoNoExiste(LookupError):
    """No hay ningún movimiento con ese id."""


@dataclass(frozen=True)
class TotalDeJornada:
    """Lo que hace falta para pintar una barra del gráfico diario."""

    jornada: date
    gastos: int
    ingresos: int
    pendientes: int
    """Cuántos movimientos de ese día no se pudieron convertir. Si es mayor que
    cero, la barra está incompleta y hay que decirlo."""


def guardar(conexion: sqlite3.Connection, movimiento: Movimiento) -> Movimiento:
    """Guarda un movimiento nuevo y lo devuelve ya con su id."""
    if not isinstance(movimiento, Movimiento):
        raise TypeError(f"se esperaba un Movimiento, no {type(movimiento).__name__}")
    if movimiento.id is not None:
        # Sin este control, "guardar" un movimiento ya guardado crearía un
        # duplicado silencioso en vez de corregir el que había.
        raise ValueError(
            f"este movimiento ya está guardado (id {movimiento.id}); "
            "usa actualizar() para corregirlo"
        )
    cursor = conexion.execute(
        f"INSERT INTO movimientos ({COLUMNAS}) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        _a_fila(movimiento),
    )
    return replace(movimiento, id=cursor.lastrowid)


def apuntar_ahora(
    conexion: sqlite3.Connection,
    tipo: Tipo,
    importe: int,
    moneda: Moneda,
    categoria_id: int,
    descripcion: str = "",
) -> Movimiento:
    """Apunta un movimiento con la hora de ahora, en el día que está abierto.

    LO USAN LA VENTANITA DE «NUEVO GASTO» Y EL ASISTENTE, y por eso está aquí:
    apuntar por voz tiene que dar exactamente lo mismo que apuntar a mano.

    SIN TASA A PROPÓSITO: el tipo de cambio todavía no se consulta. Si la
    moneda es la principal, Movimiento.nuevo pone tasa 1 solo; si es otra,
    queda pendiente, que es lo honesto.
    """
    return guardar(
        conexion,
        Movimiento.nuevo(
            tipo=tipo,
            importe=importe,
            categoria_id=categoria_id,
            momento=datetime.now(),
            jornada=jornada_abierta(conexion),
            principal=ajustes.leer_moneda_principal(conexion),
            moneda=moneda,
            descripcion=descripcion,
            tasa=None,
        ),
    )


def cambiar_moneda_principal(conexion: sqlite3.Connection, moneda: Moneda) -> int:
    """Cambia la moneda principal, y lo pendiente EN ESA MONEDA pasa a contar.

    LO ELIGIÓ EL USUARIO: si tenía la principal en euros y apuntó algo en pesos,
    eso quedó pendiente; al pasar la principal a pesos, ya no falta ningún tipo
    de cambio (un peso es un peso) y entra en los totales.

    LO YA CONVERTIDO NO SE TOCA NUNCA (ver ajustes.guardar_moneda_principal):
    así el resumen de un mes pasado no cambia de valor de un día para otro.

    Devuelve cuántos movimientos pasaron a contar.
    """
    with transaccion(conexion):
        ajustes.guardar_moneda_principal(conexion, moneda)
        return conexion.execute(
            "UPDATE movimientos SET tasa = ?, importe_principal = importe, "
            "moneda_principal = moneda WHERE tasa IS NULL AND moneda = ?",
            (tasa_a_texto(TASA_UNO), moneda.codigo),
        ).rowcount


def obtener(conexion: sqlite3.Connection, id_movimiento: int) -> Movimiento | None:
    fila = conexion.execute(
        "SELECT * FROM movimientos WHERE id = ?", (id_movimiento,)
    ).fetchone()
    return None if fila is None else _desde_fila(fila)


def listar(
    conexion: sqlite3.Connection,
    *,
    desde: date | None = None,
    hasta: date | None = None,
    tipo: Tipo | None = None,
    limite: int | None = None,
) -> list[Movimiento]:
    """Los movimientos, del más reciente al más antiguo.

    `desde` y `hasta` filtran por JORNADA y los dos extremos entran. Se filtra
    por jornada y no por el reloj porque es la fecha con la que el usuario
    piensa: lo del lunes incluye lo de las tres de la madrugada del martes.
    """
    condiciones = []
    parametros: list[object] = []
    if desde is not None:
        condiciones.append("jornada >= ?")
        parametros.append(dia_a_texto(desde))
    if hasta is not None:
        condiciones.append("jornada <= ?")
        parametros.append(dia_a_texto(hasta))
    if tipo is not None:
        if not isinstance(tipo, Tipo):
            raise TypeError(f"tipo tiene que ser Tipo o None, no {type(tipo).__name__}")
        condiciones.append("tipo = ?")
        parametros.append(tipo.value)

    donde = f"WHERE {' AND '.join(condiciones)}" if condiciones else ""
    tope = ""
    if limite is not None:
        if isinstance(limite, bool) or not isinstance(limite, int) or limite <= 0:
            raise ValueError(f"el límite tiene que ser un entero positivo: {limite!r}")
        tope = "LIMIT ?"
        parametros.append(limite)

    filas = conexion.execute(
        f"SELECT * FROM movimientos {donde} ORDER BY momento DESC, id DESC {tope}",
        parametros,
    ).fetchall()
    return [_desde_fila(fila) for fila in filas]


def actualizar(conexion: sqlite3.Connection, movimiento: Movimiento) -> Movimiento:
    """Corrige un movimiento ya guardado. Falla si no existe."""
    if movimiento.id is None:
        raise ValueError("no se puede actualizar un movimiento sin id; usa guardar()")
    asignaciones = ", ".join(
        f"{columna.strip()} = ?" for columna in COLUMNAS.split(",")
    )
    cursor = conexion.execute(
        f"UPDATE movimientos SET {asignaciones} WHERE id = ?",
        (*_a_fila(movimiento), movimiento.id),
    )
    if cursor.rowcount == 0:
        raise MovimientoNoExiste(f"no existe el movimiento {movimiento.id}")
    return movimiento


def borrar(conexion: sqlite3.Connection, id_movimiento: int) -> None:
    cursor = conexion.execute("DELETE FROM movimientos WHERE id = ?", (id_movimiento,))
    if cursor.rowcount == 0:
        raise MovimientoNoExiste(f"no existe el movimiento {id_movimiento}")


def listar_pendientes(conexion: sqlite3.Connection) -> list[Movimiento]:
    """Los que se apuntaron sin poder consultar el tipo de cambio.

    Del más antiguo al más nuevo: al recuperar la conexión interesa resolver
    primero los que llevan más tiempo esperando.
    """
    filas = conexion.execute(
        "SELECT * FROM movimientos WHERE tasa IS NULL ORDER BY momento, id"
    ).fetchall()
    return [_desde_fila(fila) for fila in filas]


def totales_por_jornada(
    conexion: sqlite3.Connection, desde: date, hasta: date
) -> list[TotalDeJornada]:
    """Gastos e ingresos de cada jornada del rango, para el gráfico diario.

    Solo aparecen las jornadas que tienen algo apuntado: los días vacíos los
    rellena quien pinte el gráfico, que es el único que sabe cuántas barras
    quiere. Suma en la base de datos y no en Python porque un mes son treinta
    sumas de enteros y no hay razón para traer cada movimiento.
    """
    filas = conexion.execute(
        """
        SELECT jornada,
               tipo,
               COALESCE(SUM(importe_principal), 0) AS total,
               SUM(CASE WHEN importe_principal IS NULL THEN 1 ELSE 0 END) AS pendientes
        FROM movimientos
        WHERE jornada >= ? AND jornada <= ?
        GROUP BY jornada, tipo
        ORDER BY jornada
        """,
        (dia_a_texto(desde), dia_a_texto(hasta)),
    ).fetchall()

    por_dia: dict[date, dict[str, int]] = {}
    for fila in filas:
        dia = dia_desde_texto(fila["jornada"])
        acumulado = por_dia.setdefault(dia, {"gastos": 0, "ingresos": 0, "pendientes": 0})
        clave = "gastos" if fila["tipo"] == Tipo.GASTO.value else "ingresos"
        acumulado[clave] = int(fila["total"])
        acumulado["pendientes"] += int(fila["pendientes"])

    return [
        TotalDeJornada(
            jornada=dia,
            gastos=valores["gastos"],
            ingresos=valores["ingresos"],
            pendientes=valores["pendientes"],
        )
        for dia, valores in sorted(por_dia.items())
    ]


def _a_fila(movimiento: Movimiento) -> tuple:
    """Convierte un Movimiento en los valores que espera el INSERT."""
    return (
        movimiento.tipo.value,
        movimiento.importe,
        movimiento.moneda.codigo,
        movimiento.categoria_id,
        movimiento.descripcion,
        momento_a_texto(movimiento.momento),
        dia_a_texto(movimiento.jornada),
        None if movimiento.tasa is None else tasa_a_texto(movimiento.tasa),
        movimiento.importe_principal,
        None
        if movimiento.moneda_principal is None
        else movimiento.moneda_principal.codigo,
    )


def _moneda_o_nada(codigo: str | None) -> Moneda | None:
    """La moneda de ese codigo, o None si la columna esta vacia."""
    return None if codigo is None else por_codigo(codigo)


def _desde_fila(fila: sqlite3.Row) -> Movimiento:
    """Reconstruye un Movimiento desde la base de datos.

    Cada conversión puede fallar con un mensaje claro si el dato está corrupto,
    en vez de devolver un movimiento medio inventado.
    """
    return Movimiento(
        id=fila["id"],
        tipo=Tipo(fila["tipo"]),
        importe=fila["importe"],
        moneda=por_codigo(fila["moneda"]),
        categoria_id=fila["categoria_id"],
        descripcion=fila["descripcion"],
        momento=momento_desde_texto(fila["momento"]),
        jornada=dia_desde_texto(fila["jornada"]),
        tasa=None if fila["tasa"] is None else tasa_desde_texto(fila["tasa"]),
        importe_principal=fila["importe_principal"],
        # SE LEE CON _moneda_o_nada y no con por_codigo a secas: la columna
        # es NULL en los movimientos anteriores a la migracion 16 cuya
        # moneda de conversion no se pudo saber, y eso NO es un error: es
        # "no se sabe", que es un dato legitimo y el que evita inventarselo.
        moneda_principal=_moneda_o_nada(fila["moneda_principal"]),
    )
