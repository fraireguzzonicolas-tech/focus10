"""Guardar y leer los hábitos y sus marcas diarias.

CÓMO SE GUARDAN LOS DÍAS DE LA SEMANA: como texto de dígitos, "0246" para lunes,
miércoles, viernes y domingo. Se ordena siempre igual al escribir, para que dos
hábitos con los mismos días se guarden idénticos y se puedan comparar de un
vistazo abriendo la base de datos.

CÓMO FUNCIONA MARCAR: hay como mucho UNA fila por hábito y jornada, y pulsar el
círculo suma a la cantidad que ya hubiera. Un índice único lo garantiza aunque el
código se equivoque.
"""

from __future__ import annotations

import sqlite3
from dataclasses import replace
from datetime import date, time

from ..dominio.habito import Habito, Marca, ordenar
from . import cambios
from .conexion import transaccion
from .fechas import dia_a_texto, dia_desde_texto

COLUMNAS = "nombre, icono, color, objetivo, unidad, dias, hora, activo, orden"


class HabitoNoExiste(LookupError):
    """No hay ningún hábito con ese id."""


class HabitoEnUso(ValueError):
    """No se puede borrar: tiene marcas apuntadas."""


# --------------------------------------------------------------------------
# Los hábitos
# --------------------------------------------------------------------------


def listar(conexion: sqlite3.Connection, *, incluir_inactivos: bool = False) -> list[Habito]:
    """Los hábitos, ya ordenados como se enseñan: por hora, los sin hora al final.

    El orden lo pone el dominio, no el SQL: es una regla de negocio ("la lista se
    lee como el día") y tiene sus tests. Ordenarlo aquí con un ORDER BY sería
    tener la misma regla en dos sitios.
    """
    donde = "" if incluir_inactivos else "WHERE activo = 1"
    filas = conexion.execute(f"SELECT * FROM habitos {donde}").fetchall()
    return ordenar([_desde_fila(fila) for fila in filas])


def obtener(conexion: sqlite3.Connection, id_habito: int) -> Habito | None:
    fila = conexion.execute(
        "SELECT * FROM habitos WHERE id = ?", (id_habito,)
    ).fetchone()
    return None if fila is None else _desde_fila(fila)


def crear(conexion: sqlite3.Connection, habito: Habito) -> Habito:
    """Guarda un hábito nuevo y lo devuelve ya con su id."""
    if not isinstance(habito, Habito):
        raise TypeError(f"se esperaba un Habito, no {type(habito).__name__}")
    if habito.id is not None:
        raise ValueError(
            f"este hábito ya está guardado (id {habito.id}); usa actualizar()"
        )
    if habito.orden == 0:
        # Sin orden elegido se coloca el último, que es lo que espera quien acaba
        # de crearlo.
        habito = replace(habito, orden=_siguiente_orden(conexion))

    cursor = conexion.execute(
        f"INSERT INTO habitos ({COLUMNAS}) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        _a_fila(habito),
    )
    return replace(habito, id=cursor.lastrowid)


def actualizar(conexion: sqlite3.Connection, habito: Habito) -> Habito:
    """Corrige un hábito ya guardado.

    Cambiar los días NO toca las marcas viejas: una marca de un día que ya no
    está programado sigue ahí, simplemente deja de contar para la racha. Borrarla
    sería reescribir el pasado.
    """
    if habito.id is None:
        raise ValueError("no se puede actualizar un hábito sin id; usa crear()")
    asignaciones = ", ".join(f"{c.strip()} = ?" for c in COLUMNAS.split(","))
    cursor = conexion.execute(
        f"UPDATE habitos SET {asignaciones} WHERE id = ?",
        (*_a_fila(habito), habito.id),
    )
    if cursor.rowcount == 0:
        raise HabitoNoExiste(f"no existe el hábito {habito.id}")
    return habito


def cambiar_actividad(
    conexion: sqlite3.Connection, id_habito: int, activo: bool
) -> Habito:
    """Activa o desactiva. Desactivar es la forma correcta de "quitar" un hábito
    que ya tiene historial: deja de aparecer y lo apuntado sigue entendiéndose."""
    if not isinstance(activo, bool):
        raise TypeError("activo tiene que ser True o False")
    actual = _exigir(conexion, id_habito)
    conexion.execute(
        "UPDATE habitos SET activo = ? WHERE id = ?", (int(activo), id_habito)
    )
    return replace(actual, activo=activo)


def tiene_marcas(conexion: sqlite3.Connection, id_habito: int) -> bool:
    fila = conexion.execute(
        "SELECT 1 FROM marcas WHERE habito_id = ? LIMIT 1", (id_habito,)
    ).fetchone()
    return fila is not None


def borrar(conexion: sqlite3.Connection, id_habito: int) -> None:
    """Borra de verdad, y SOLO si no tiene ninguna marca.

    Con marcas se niega: borrarlo tiraría el historial entero de ese hábito, que
    es justo lo que uno lleva meses acumulando.
    """
    _exigir(conexion, id_habito)
    if tiene_marcas(conexion, id_habito):
        raise HabitoEnUso(
            f"el hábito {id_habito} ya tiene marcas y borrarlo tiraría su "
            "historial; desactívalo si no quieres seguir con él"
        )
    conexion.execute("DELETE FROM habitos WHERE id = ?", (id_habito,))


def reordenar(conexion: sqlite3.Connection, ids_en_orden: list[int]) -> None:
    """Coloca los hábitos en el orden dado, todo o nada."""
    with transaccion(conexion):
        for posicion, id_habito in enumerate(ids_en_orden, start=1):
            cursor = conexion.execute(
                "UPDATE habitos SET orden = ? WHERE id = ?", (posicion, id_habito)
            )
            if cursor.rowcount == 0:
                raise HabitoNoExiste(f"no existe el hábito {id_habito}")


# --------------------------------------------------------------------------
# Las marcas
# --------------------------------------------------------------------------


# CADA APARATO LLEVA SU PROPIA CUENTA, y lo que se enseña es la suma. Ver la
# cabecera de migracion_31.py: guardar el total hacía que dos aparatos que
# marcan una vez cada uno sin internet acabaran en 1 en vez de en 2.
#
# LA SUMA NUNCA BAJA DE CERO AL LEERLA. La fila de un aparato sí puede quedar
# en negativo (el móvil desmarca lo que marcó la PC), y dos desmarques hechos
# a la vez sin internet podrían dejar la suma en -1. Eso no es un dato que
# enseñar: se enseña cero.
_SUMA = "MAX(0, SUM(cantidad))"


def cantidad(conexion: sqlite3.Connection, id_habito: int, jornada: date) -> int:
    """Cuánto se hizo ese día, sumando todos los aparatos. Cero si no hay marca."""
    fila = conexion.execute(
        f"SELECT {_SUMA} AS total FROM marcas WHERE habito_id = ? AND jornada = ?",
        (id_habito, dia_a_texto(jornada)),
    ).fetchone()
    return 0 if fila is None or fila["total"] is None else int(fila["total"])


def marcar(
    conexion: sqlite3.Connection, id_habito: int, jornada: date, cantidad_nueva: int
) -> Marca:
    """Deja la cantidad de ese día en el valor dado.

    Se construye la Marca antes de tocar la base para que las reglas del dominio
    (nada negativo, la jornada es un día sin hora) se apliquen aquí también.

    SOLO SE ESCRIBE LA FILA DE ESTE APARATO: se le pone lo que falta para que
    la suma dé el total pedido. Así lo que apuntó otro aparato no se toca nunca,
    que es lo que hace que al juntarse no se pierda nada.
    """
    marca = Marca(habito_id=id_habito, jornada=jornada, cantidad=cantidad_nueva)
    yo = cambios.aparato(conexion)
    fila = conexion.execute(
        """
        SELECT COALESCE(SUM(cantidad), 0) AS otros FROM marcas
        WHERE habito_id = ? AND jornada = ? AND aparato != ?
        """,
        (marca.habito_id, dia_a_texto(marca.jornada), yo),
    ).fetchone()
    conexion.execute(
        """
        INSERT INTO marcas (habito_id, jornada, cantidad, aparato) VALUES (?, ?, ?, ?)
        ON CONFLICT(habito_id, jornada, aparato)
        DO UPDATE SET cantidad = excluded.cantidad
        """,
        (
            marca.habito_id,
            dia_a_texto(marca.jornada),
            marca.cantidad - int(fila["otros"]),
            yo,
        ),
    )
    return marca


def sumar(
    conexion: sqlite3.Connection, id_habito: int, jornada: date, cuanto: int = 1
) -> int:
    """Suma (o resta) a lo que hubiera ese día y devuelve la cantidad que queda.

    Nunca baja de cero: restar en un día vacío deja un cero, no un número
    negativo.

    Va en una transacción porque son dos pasos —leer y escribir— y entre medias
    OTRA conexión podría cambiar la cantidad. Los tests no lo alcanzan: usan una
    sola conexión, así que tampoco hay mutación para esta línea. Se queda porque
    las respuestas a los clics pueden ejecutarse en hilos distintos, y dos
    pulsaciones seguidas al mismo círculo son exactamente ese caso.
    """
    if isinstance(cuanto, bool) or not isinstance(cuanto, int):
        raise TypeError("cuanto tiene que ser int")

    with transaccion(conexion):
        actual = cantidad(conexion, id_habito, jornada)
        nueva = max(0, actual + cuanto)
        marcar(conexion, id_habito, jornada, nueva)
    return nueva


def cantidades_de(
    conexion: sqlite3.Connection,
    id_habito: int,
    desde: date | None = None,
    hasta: date | None = None,
) -> dict[date, int]:
    """Lo marcado por ese hábito, por jornada. Sin fechas, todo su historial.

    Todo el historial es lo que necesita el cálculo de rachas: la mejor racha
    puede estar en cualquier punto del pasado.
    """
    condiciones = ["habito_id = ?"]
    parametros: list[object] = [id_habito]
    if desde is not None:
        condiciones.append("jornada >= ?")
        parametros.append(dia_a_texto(desde))
    if hasta is not None:
        condiciones.append("jornada <= ?")
        parametros.append(dia_a_texto(hasta))

    filas = conexion.execute(
        f"SELECT jornada, {_SUMA} AS cantidad FROM marcas "
        f"WHERE {' AND '.join(condiciones)} GROUP BY jornada",
        parametros,
    ).fetchall()
    return {dia_desde_texto(f["jornada"]): int(f["cantidad"]) for f in filas}


def primera_jornada(conexion: sqlite3.Connection, id_habito: int) -> date | None:
    """El primer día que ese hábito tiene marca, o None si no tiene ninguna.

    PARA QUÉ SIRVE: la cuadrícula del año necesita saber desde cuándo cuenta un
    hábito. No guardamos la fecha en que se creó —la tabla nunca la tuvo—, así que
    un hábito nacido en junio parecería haber fallado los cinco meses anteriores.
    El primer día con marca es el único dato real que hay para saberlo, y es
    honesto: dice "desde aquí hay constancia de que existía".

    Funciona porque las jornadas se guardan como AAAA-MM-DD, y en ese formato el
    orden alfabético y el cronológico son el mismo; por eso MIN() da la más
    antigua sin tener que traerlas todas a Python.

    EL MIN() NO SE PUEDE QUITAR AUNQUE PAREZCA QUE SOBRA: hoy existe un índice
    único por (habito_id, jornada), así que un SELECT sin MIN devolvería la más
    antigua de todas formas, porque SQLite recorre ese índice en orden. Lo probé
    quitándolo y ningún test se enteró. Pero eso es una casualidad del índice, no
    una garantía: el día que el índice cambie de columnas o desaparezca, esta
    función empezaría a devolver una jornada cualquiera y nada lo avisaría. Por
    eso se pide lo que se quiere en vez de confiar en el orden en que llegan las
    filas.
    """
    fila = conexion.execute(
        "SELECT MIN(jornada) AS primera FROM marcas WHERE habito_id = ?",
        (id_habito,),
    ).fetchone()
    if fila is None or fila["primera"] is None:
        return None
    return dia_desde_texto(fila["primera"])


def cantidades_de_todos(
    conexion: sqlite3.Connection, desde: date, hasta: date
) -> dict[tuple[int, date], int]:
    """Lo marcado por TODOS los hábitos en un rango, indexado por (hábito, día).

    De una sola consulta, que es lo que necesitan el calendario del mes y la
    gráfica de la semana: pedirlo hábito por hábito serían treinta consultas para
    pintar una pantalla.
    """
    filas = conexion.execute(
        f"""
        SELECT habito_id, jornada, {_SUMA} AS cantidad FROM marcas
        WHERE jornada >= ? AND jornada <= ?
        GROUP BY habito_id, jornada
        """,
        (dia_a_texto(desde), dia_a_texto(hasta)),
    ).fetchall()
    return {
        (int(f["habito_id"]), dia_desde_texto(f["jornada"])): int(f["cantidad"])
        for f in filas
    }


# --------------------------------------------------------------------------


def _siguiente_orden(conexion: sqlite3.Connection) -> int:
    fila = conexion.execute(
        "SELECT COALESCE(MAX(orden), 0) + 1 AS siguiente FROM habitos"
    ).fetchone()
    return int(fila["siguiente"])


def _exigir(conexion: sqlite3.Connection, id_habito: int) -> Habito:
    habito = obtener(conexion, id_habito)
    if habito is None:
        raise HabitoNoExiste(f"no existe el hábito {id_habito}")
    return habito


def _dias_a_texto(dias: frozenset[int]) -> str:
    """{0, 4, 2} -> "024". Ordenado siempre, para que dos hábitos con los mismos
    días se guarden idénticos.

    AVISO PARA QUIEN LO LEA: hoy un frozenset de números pequeños ya se recorre
    en orden en CPython, así que quitar el sorted() no cambiaría nada... por
    ahora. Eso es un detalle interno de Python, no una promesa: el sorted() es
    lo que hace que el formato guardado no dependa de él. Por eso NO hay una
    mutación para esta línea: ningún test podría notar su ausencia.
    """
    return "".join(str(numero) for numero in sorted(dias))


def _dias_desde_texto(texto: str) -> frozenset[int]:
    if not texto or not texto.isdigit():
        raise ValueError(f"días mal guardados: {texto!r}")
    return frozenset(int(caracter) for caracter in texto)


def _hora_a_texto(hora: time | None) -> str | None:
    return None if hora is None else hora.strftime("%H:%M")


def _hora_desde_texto(texto: str | None) -> time | None:
    if texto is None:
        return None
    partes = texto.strip().split(":")
    if len(partes) != 2 or not all(parte.isdigit() for parte in partes):
        raise ValueError(f"hora mal guardada: {texto!r}")
    return time(hour=int(partes[0]), minute=int(partes[1]))


def _a_fila(habito: Habito) -> tuple:
    return (
        habito.nombre,
        habito.icono,
        habito.color,
        habito.objetivo,
        habito.unidad,
        _dias_a_texto(habito.dias),
        _hora_a_texto(habito.hora),
        int(habito.activo),
        habito.orden,
    )


def _desde_fila(fila: sqlite3.Row) -> Habito:
    return Habito(
        id=fila["id"],
        nombre=fila["nombre"],
        icono=fila["icono"],
        color=fila["color"],
        objetivo=fila["objetivo"],
        unidad=fila["unidad"],
        dias=_dias_desde_texto(fila["dias"]),
        hora=_hora_desde_texto(fila["hora"]),
        activo=bool(fila["activo"]),
        orden=fila["orden"],
    )
