"""La migración 34: las casillas del horario llevan icono, como los hábitos.

LO PIDIÓ EL USUARIO: "los emojis del apartado de horarios siguen siendo estos,
cámbialos por los que pusimos en el apartado de hábitos". El motivo es el mismo
que en la 32: el emoji lo dibuja el sistema operativo, y cada aparato lo pinta
distinto e ignorando los colores del tema.

UNA COLUMNA NUEVA Y NO DENTRO DEL TEXTO: el emoji iba escrito dentro de la
tarea ("Francés 🇫🇷"), pero un icono de línea no es un carácter y no se puede
meter en un texto. Se añade con ALTER TABLE, que NO se lleva los disparadores de
la sincronización: la tabla no se reconstruye.

LO YA ESCRITO SE CONVIERTE, y lo eligió el usuario: si el texto tiene uno de los
emojis de la lista, se saca del texto y la casilla se queda con su icono. El
que no está en la lista (una bandera, por ejemplo) se queda escrito donde
estaba: convertirlo en una estrella cualquiera sería perder lo que puso.

SOLO SE SACA SI LA CASILLA NO SE QUEDA VACÍA: una casilla que era solo "💧" y
sin color no puede quedar sin texto, porque la tabla exige texto o color. Esa se
queda como estaba.
"""

from __future__ import annotations

EQUIVALENCIAS = (
    # LAS FORMAS CON EL CARÁCTER INVISIBLE VAN PRIMERO: si se probara antes la
    # forma corta, sacaría el símbolo y dejaría el U+FE0F suelto en el texto.
    ("\U0001f3cb️", "pesa"),
    ("\U0001f6cf️", "cama"),
    ("✈️", "viajar"),
    ("☀️", "sol"),
    ("\U0001f4b0", "moneda"),
    ("\U0001f4b5", "billete"),
    ("\U0001f4b3", "tarjeta"),
    ("\U0001f3e6", "banco"),
    ("\U0001f4c8", "grafico"),
    ("\U0001f4da", "libro"),
    ("\U0001f393", "estudiar"),
    ("\U0001f4bb", "ordenador"),
    ("\U0001f9e0", "idea"),
    ("\U0001f4dd", "escribir"),
    ("\U0001f4a7", "agua"),
    ("\U0001f48a", "pastilla"),
    ("\U0001f634", "dormir"),
    ("\U0001faa5", "cuidarse"),
    ("\U0001f9b7", "estirar"),
    ("\U0001f3cb", "pesa"),
    ("\U0001f3c3", "correr"),
    ("\U0001f6b4", "bici"),
    ("\U0001f9d8", "yoga"),
    ("⚽", "futbol"),
    ("\U0001f34e", "fruta"),
    ("\U0001f957", "ensalada"),
    ("\U0001f373", "cocinar"),
    ("\U0001f95b", "pan"),
    ("\U0001f372", "sopa"),
    ("\U0001f9f9", "limpiar"),
    ("\U0001f9fa", "lavar"),
    ("\U0001fab4", "planta"),
    ("\U0001f6cf", "cama"),
    ("\U0001f415", "mascota"),
    ("\U0001f3b8", "guitarra"),
    ("\U0001f3ae", "juego"),
    ("\U0001f4d6", "leer"),
    ("\U0001f3a7", "musica"),
    ("✈", "viajar"),
    ("☀", "sol"),
    ("✅", "hecho"),
    ("⭐", "estrella"),
    ("\U0001f525", "racha"),
    ("⏰", "corazon"),
)
"""La misma tabla que usó la 32 para los hábitos: el emoji que ocupaba un sitio
en la lista de emojis se convierte en el icono que ocupa ese sitio ahora."""


def sentencias() -> tuple[str, ...]:
    columna = (
        "ALTER TABLE horario_semanal "
        "ADD COLUMN icono TEXT NOT NULL DEFAULT '' "
        "CHECK (length(icono) <= 30)",
    )
    conversiones = tuple(
        f"""
        UPDATE horario_semanal
           SET icono = '{clave}',
               texto = trim(replace(texto, '{emoji}', ''))
         WHERE icono = ''
           AND instr(texto, '{emoji}') > 0
           AND (length(trim(replace(texto, '{emoji}', ''))) > 0 OR length(color) > 0)
        """
        for emoji, clave in EQUIVALENCIAS
    )
    return columna + conversiones
