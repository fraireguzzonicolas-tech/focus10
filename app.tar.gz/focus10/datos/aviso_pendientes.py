"""Cuándo se abre sola la lista de tareas pendientes (la de la campana).

LO PIDIÓ EL USUARIO (15 nov 2026): «cada vez que entre en la aplicación, si
pasaron 8 horas desde el último aviso, que aparezca un aviso de que tiene
tareas pendientes», relacionado con la campana del Dashboard. Eligió que se
abra la MISMA lista que abre la campana (para tachar ahí mismo) y que cuente
tanto abrir Focus como volver a él desde otra app.

AQUÍ SOLO ESTÁ LA REGLA; quien abre la lista es interfaz/app.py.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta

from . import ajustes, repositorio_tareas

HORAS_ENTRE_AVISOS = 8


def toca_avisar(conexion: sqlite3.Connection, ahora: datetime) -> bool:
    """Si hay que abrir la lista: hay pendientes y pasaron 8 horas.

    SIN PENDIENTES NO SE AVISA NADA: una lista vacía que se abre sola solo
    molesta. Y la cuenta de las 8 horas no empieza: el día que aparezca una
    pendiente, se avisa al entrar.

    SI EL ÚLTIMO AVISO DICE SER DEL FUTURO (se cambió la hora del aparato), se
    avisa: si no, quedaría callado hasta que el reloj llegara a esa fecha.
    """
    if not repositorio_tareas.listar_pendientes(conexion):
        return False
    try:
        ultimo = datetime.fromisoformat(ajustes.leer(conexion, ajustes.CLAVE_AVISO_PENDIENTES))
    except ValueError:
        return True
    return ultimo > ahora or ahora - ultimo >= timedelta(hours=HORAS_ENTRE_AVISOS)


def apuntar_aviso(conexion: sqlite3.Connection, ahora: datetime) -> None:
    """Se avisó ahora: las próximas 8 horas, no."""
    ajustes.escribir(conexion, ajustes.CLAVE_AVISO_PENDIENTES, ahora.isoformat(timespec="seconds"))
