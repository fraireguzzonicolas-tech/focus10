"""Guardar y leer la rutina y las sesiones.

DOS COSAS SEPARADAS, DOS JUEGOS DE FUNCIONES. Nada de aquí escribe a la vez en la
rutina y en una sesión: si una sola función pudiera hacerlo, tarde o temprano
alguien la usaría y el plan se reescribiría solo.

BORRAR UN EJERCICIO DE LA BIBLIOTECA no borra nada de aquí: deja la referencia en
NULL y el nombre donde está. Se hace a mano y no con ON DELETE SET NULL porque
esa cláusula solo funciona con el PRAGMA de claves foráneas encendido, y depender
de un ajuste de la conexión para no perder dos años de historial es demasiado
frágil para lo que está en juego.
"""

from __future__ import annotations

import sqlite3
from datetime import date

from ..dominio.rutina import (
    BloqueDeRutina,
    DiaDeRutina,
    EjercicioPlaneado,
    SeriePlaneada,
)
from ..dominio.sesion import EjercicioDeSesion, Serie, Sesion
from .fechas import dia_a_texto, dia_desde_texto


class SesionNoExiste(LookupError):
    """Se pidió tocar una sesión que no está."""


# ---------------------------------------------------------------------------
# La rutina (el plan)
# ---------------------------------------------------------------------------


def leer_rutina(conexion: sqlite3.Connection) -> dict[int, DiaDeRutina]:
    """Los siete días, con sus bloques, sus ejercicios y sus series.

    TRES CONSULTAS Y NO UNA POR EJERCICIO. Un día con cinco ejercicios de cuatro
    series son veintiuna consultas si se va preguntando de una en una, y esto se
    hace cada vez que se abre el apartado y cada vez que se guarda algo.
    """
    series: dict[int, list[SeriePlaneada]] = {}
    for fila in conexion.execute(
        "SELECT * FROM rutina_series ORDER BY rutina_ejercicio_id, numero, id"
    ).fetchall():
        series.setdefault(int(fila["rutina_ejercicio_id"]), []).append(
            SeriePlaneada(
                id=int(fila["id"]),
                numero=int(fila["numero"]),
                repeticiones=int(fila["repeticiones"]),
                peso=int(fila["peso"]),
                segundos=_entero_o_nada(fila["segundos"]),
            )
        )

    ejercicios: dict[int, list[EjercicioPlaneado]] = {}
    for fila in conexion.execute(
        "SELECT * FROM rutina_ejercicios ORDER BY bloque_id, orden, id"
    ).fetchall():
        identificador = int(fila["id"])
        # UN EJERCICIO BORRADO DE LA BIBLIOTECA sigue en el plan por su nombre;
        # el id 0 no existe y el dominio lo rechaza, así que se guarda con el id
        # de la propia fila para poder tocarlo igual.
        borrado = not fila["ejercicio_id"]
        ejercicios.setdefault(int(fila["bloque_id"]), []).append(
            EjercicioPlaneado(
                id=identificador,
                ejercicio_id=(
                    identificador if borrado else int(fila["ejercicio_id"])
                ),
                nombre=(
                    f"{fila['nombre']} (ya no está en la biblioteca)"
                    if borrado
                    else fila["nombre"]
                ),
                orden=int(fila["orden"]),
                descanso=_entero_o_nada(fila["descanso"]),
                series=tuple(series.get(identificador, [])),
            )
        )

    bloques: dict[int, list[BloqueDeRutina]] = {}
    for fila in conexion.execute(
        "SELECT * FROM rutina_bloques ORDER BY dia, orden, id"
    ).fetchall():
        bloques.setdefault(int(fila["dia"]), []).append(
            BloqueDeRutina(
                id=int(fila["id"]),
                nombre=fila["nombre"],
                orden=int(fila["orden"]),
                ejercicios=tuple(ejercicios.get(int(fila["id"]), [])),
            )
        )

    dias: dict[int, DiaDeRutina] = {}
    for fila in conexion.execute("SELECT * FROM rutina_dias ORDER BY dia").fetchall():
        numero = int(fila["dia"])
        es_descanso = bool(fila["es_descanso"])
        dias[numero] = DiaDeRutina(
            dia=numero,
            nombre=fila["nombre"],
            color=fila["color"],
            es_descanso=es_descanso,
            bloques=() if es_descanso else tuple(bloques.get(numero, [])),
        )
    return dias


def guardar_dia(conexion: sqlite3.Connection, dia: DiaDeRutina) -> None:
    """Guarda un día entero: su nombre, su color, sus bloques y todo lo de dentro.

    SE BORRA Y SE VUELVE A ESCRIBIR, como antes: son unas pocas filas y buscar
    cuál cambió costaría más de mantener de lo que ahorra.

    SE BORRA A MANO, DE ABAJO ARRIBA, aunque las claves ajenas ya borren en
    cascada. Es la misma razón que está escrita arriba en este archivo: el
    borrado en cascada solo funciona con el PRAGMA de claves foráneas encendido,
    y si un día alguien abre la base sin él, esto dejaría series huérfanas
    apuntando a ejercicios que ya no están. Aquí no se depende de un ajuste.
    """
    conexion.execute(
        "UPDATE rutina_dias SET nombre = ?, color = ?, es_descanso = ? WHERE dia = ?",
        (dia.nombre, dia.color, int(dia.es_descanso), dia.dia),
    )
    _vaciar_dia(conexion, dia.dia)

    for numero, bloque in enumerate(dia.bloques):
        cursor = conexion.execute(
            "INSERT INTO rutina_bloques (dia, nombre, orden) VALUES (?, ?, ?)",
            (dia.dia, bloque.nombre, numero),
        )
        bloque_id = int(cursor.lastrowid)
        for sitio, planeado in enumerate(bloque.ejercicios):
            cursor = conexion.execute(
                "INSERT INTO rutina_ejercicios (bloque_id, ejercicio_id, nombre,"
                " orden, descanso) VALUES (?, ?, ?, ?, ?)",
                (
                    bloque_id,
                    planeado.ejercicio_id or None,
                    planeado.nombre,
                    sitio,
                    planeado.descanso,
                ),
            )
            ejercicio_id = int(cursor.lastrowid)
            conexion.executemany(
                "INSERT INTO rutina_series (rutina_ejercicio_id, numero,"
                " repeticiones, peso, segundos) VALUES (?, ?, ?, ?, ?)",
                [
                    (
                        ejercicio_id,
                        una.numero,
                        una.repeticiones,
                        una.peso,
                        una.segundos,
                    )
                    for una in planeado.series
                ],
            )


def _vaciar_dia(conexion: sqlite3.Connection, dia: int) -> None:
    """Borra los bloques de un día y todo lo que cuelga de ellos."""
    conexion.execute(
        "DELETE FROM rutina_series WHERE rutina_ejercicio_id IN ("
        " SELECT ej.id FROM rutina_ejercicios ej"
        " JOIN rutina_bloques bloque ON bloque.id = ej.bloque_id"
        " WHERE bloque.dia = ?)",
        (dia,),
    )
    conexion.execute(
        "DELETE FROM rutina_ejercicios WHERE bloque_id IN ("
        " SELECT id FROM rutina_bloques WHERE dia = ?)",
        (dia,),
    )
    conexion.execute("DELETE FROM rutina_bloques WHERE dia = ?", (dia,))


# ---------------------------------------------------------------------------
# Las sesiones (lo ejecutado)
# ---------------------------------------------------------------------------


def sesion_de(conexion: sqlite3.Connection, fecha: date) -> Sesion | None:
    fila = conexion.execute(
        "SELECT * FROM sesiones WHERE fecha = ?", (dia_a_texto(fecha),)
    ).fetchone()
    return _sesion_desde_fila(conexion, fila) if fila else None


def sesiones_entre(
    conexion: sqlite3.Connection, desde: date, hasta: date
) -> list[Sesion]:
    filas = conexion.execute(
        "SELECT * FROM sesiones WHERE fecha >= ? AND fecha <= ? ORDER BY fecha",
        (dia_a_texto(desde), dia_a_texto(hasta)),
    ).fetchall()
    return [_sesion_desde_fila(conexion, fila) for fila in filas]


def todas_las_sesiones(conexion: sqlite3.Connection) -> list[Sesion]:
    filas = conexion.execute("SELECT * FROM sesiones ORDER BY fecha").fetchall()
    return [_sesion_desde_fila(conexion, fila) for fila in filas]


def guardar_sesion(conexion: sqlite3.Connection, sesion: Sesion) -> Sesion:
    """Guarda la sesión entera. NO toca la rutina en ningún caso.

    Es la mitad práctica de la separación que pidió el usuario: aquí no hay ni
    una consulta que escriba en rutina_dias o rutina_ejercicios. Si un día
    apareciera, el plan empezaría a cambiar solo.
    """
    fila = conexion.execute(
        "SELECT id FROM sesiones WHERE fecha = ?", (dia_a_texto(sesion.fecha),)
    ).fetchone()

    if fila is None:
        cursor = conexion.execute(
            "INSERT INTO sesiones (fecha, nombre, color) VALUES (?, ?, ?)",
            (dia_a_texto(sesion.fecha), sesion.nombre, sesion.color),
        )
        id_sesion = cursor.lastrowid
    else:
        id_sesion = int(fila["id"])
        conexion.execute(
            "UPDATE sesiones SET nombre = ?, color = ? WHERE id = ?",
            (sesion.nombre, sesion.color, id_sesion),
        )
        _borrar_contenido(conexion, id_sesion)

    for numero, ejercicio in enumerate(sesion.ejercicios):
        cursor = conexion.execute(
            "INSERT INTO sesion_ejercicios (sesion_id, ejercicio_id, nombre, "
            "orden, descanso) VALUES (?, ?, ?, ?, ?)",
            (
                id_sesion,
                ejercicio.ejercicio_id,
                ejercicio.nombre,
                numero,
                ejercicio.descanso,
            ),
        )
        id_ejercicio = cursor.lastrowid
        for serie in ejercicio.series:
            conexion.execute(
                "INSERT INTO series (sesion_ejercicio_id, numero, peso, "
                "repeticiones, hecha, rpe, al_fallo, segundos) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    id_ejercicio,
                    serie.numero,
                    serie.peso,
                    serie.repeticiones,
                    int(serie.hecha),
                    serie.rpe,
                    int(serie.al_fallo),
                    serie.segundos,
                ),
            )

    return sesion_de(conexion, sesion.fecha)


def borrar_sesion(conexion: sqlite3.Connection, fecha: date) -> None:
    fila = conexion.execute(
        "SELECT id FROM sesiones WHERE fecha = ?", (dia_a_texto(fecha),)
    ).fetchone()
    if fila is None:
        raise SesionNoExiste(f"no hay ninguna sesión del {fecha}")
    _borrar_contenido(conexion, int(fila["id"]))
    conexion.execute("DELETE FROM sesiones WHERE id = ?", (int(fila["id"]),))


def historial_de(
    conexion: sqlite3.Connection, id_ejercicio: int
) -> list[tuple[date, EjercicioDeSesion]]:
    """Todas las veces que se ha hecho ese ejercicio, de la más vieja a la más
    nueva. Es lo que alimenta la gráfica y "la última vez"."""
    filas = conexion.execute(
        """
        SELECT se.*, s.fecha AS fecha
        FROM sesion_ejercicios se
        JOIN sesiones s ON s.id = se.sesion_id
        WHERE se.ejercicio_id = ?
        ORDER BY s.fecha
        """,
        (id_ejercicio,),
    ).fetchall()
    return [
        (dia_desde_texto(fila["fecha"]), _ejercicio_desde_fila(conexion, fila))
        for fila in filas
    ]


def ultima_vez(
    conexion: sqlite3.Connection, id_ejercicio: int, antes_de: date
) -> EjercicioDeSesion | None:
    """Lo que se hizo la última vez en ese ejercicio, antes de esa fecha.

    Es la información que de verdad decide qué peso poner hoy, y por eso se
    excluye el día que se está mirando: comparar la sesión de hoy consigo misma
    no diría nada.
    """
    fila = conexion.execute(
        """
        SELECT se.*, s.fecha AS fecha
        FROM sesion_ejercicios se
        JOIN sesiones s ON s.id = se.sesion_id
        WHERE se.ejercicio_id = ? AND s.fecha < ?
        ORDER BY s.fecha DESC
        LIMIT 1
        """,
        (id_ejercicio, dia_a_texto(antes_de)),
    ).fetchone()
    return _ejercicio_desde_fila(conexion, fila) if fila else None


def olvidar_ejercicio(conexion: sqlite3.Connection, id_ejercicio: int) -> None:
    """Deja huérfanas las filas de ese ejercicio, sin borrar ninguna.

    Se llama al borrar de la biblioteca. El nombre se queda donde está, así que
    el historial se sigue leyendo entero: solo se pierde el enlace con una ficha
    que ya no existe.
    """
    conexion.execute(
        "UPDATE sesion_ejercicios SET ejercicio_id = NULL WHERE ejercicio_id = ?",
        (id_ejercicio,),
    )
    conexion.execute(
        "UPDATE rutina_ejercicios SET ejercicio_id = NULL WHERE ejercicio_id = ?",
        (id_ejercicio,),
    )


# ---------------------------------------------------------------------------


def _borrar_contenido(conexion: sqlite3.Connection, id_sesion: int) -> None:
    conexion.execute(
        "DELETE FROM series WHERE sesion_ejercicio_id IN "
        "(SELECT id FROM sesion_ejercicios WHERE sesion_id = ?)",
        (id_sesion,),
    )
    conexion.execute("DELETE FROM sesion_ejercicios WHERE sesion_id = ?", (id_sesion,))


def _sesion_desde_fila(conexion: sqlite3.Connection, fila: sqlite3.Row) -> Sesion:
    ejercicios = conexion.execute(
        "SELECT * FROM sesion_ejercicios WHERE sesion_id = ? ORDER BY orden, id",
        (int(fila["id"]),),
    ).fetchall()
    return Sesion(
        id=int(fila["id"]),
        fecha=dia_desde_texto(fila["fecha"]),
        nombre=fila["nombre"],
        color=fila["color"],
        ejercicios=tuple(
            _ejercicio_desde_fila(conexion, uno) for uno in ejercicios
        ),
    )


def _entero_o_nada(valor) -> int | None:
    """El valor de la columna, o None si esta vacia.

    NO SE CONFUNDE EL HUECO CON EL CERO, y aqui es donde se decide: un cero es un
    descanso de cero segundos elegido a proposito (el cardio no lleva), y un None
    es "aqui no se dijo nada" y se rellena con el de la ficha del ejercicio. Un
    `int(valor or 0)` los habria mezclado y todos los ejercicios de antes de la
    migracion 13 se habrian quedado sin cronometro.
    """
    return None if valor is None else int(valor)


def _ejercicio_desde_fila(
    conexion: sqlite3.Connection, fila: sqlite3.Row
) -> EjercicioDeSesion:
    series = conexion.execute(
        "SELECT * FROM series WHERE sesion_ejercicio_id = ? ORDER BY numero",
        (int(fila["id"]),),
    ).fetchall()
    return EjercicioDeSesion(
        id=int(fila["id"]),
        ejercicio_id=int(fila["ejercicio_id"]) if fila["ejercicio_id"] else None,
        nombre=fila["nombre"],
        orden=int(fila["orden"]),
        descanso=_entero_o_nada(fila["descanso"]),
        series=tuple(
            Serie(
                id=int(una["id"]),
                numero=int(una["numero"]),
                peso=int(una["peso"]),
                repeticiones=int(una["repeticiones"]),
                hecha=bool(una["hecha"]),
                rpe=int(una["rpe"]) if una["rpe"] is not None else None,
                al_fallo=bool(una["al_fallo"]),
                segundos=int(una["segundos"]),
            )
            for una in series
        ),
    )
