"""Guardar y leer la rutina y las sesiones.

DOS COSAS SEPARADAS, DOS JUEGOS DE FUNCIONES. Nada de aquí escribe a la vez en la
rutina y en una sesión: si una sola función pudiera hacerlo, tarde o temprano
alguien la usaría y el plan se reescribiría solo.

BORRAR UN EJERCICIO DE LA BIBLIOTECA no borra nada de aquí: deja la referencia en
NULL y el nombre donde está. Se hace a mano y no con ON DELETE SET NULL porque
esa cláusula solo funciona con el PRAGMA de claves foráneas encendido, y depender
de un ajuste de la conexión para no perder dos años de historial es demasiado
frágil para lo que está en juego.
"""

from __future__ import annotations

import sqlite3
from datetime import date, datetime, timedelta

from ..dominio.ejercicio import Unidad
from ..dominio.rutina import (
    BloqueDeRutina,
    DiaDeRutina,
    EjercicioPlaneado,
    SeriePlaneada,
)
from ..dominio.sesion import EjercicioDeSesion, Marca, Serie, Sesion, TipoSerie, mejor_marca
from .fechas import (
    dia_a_texto,
    dia_desde_texto,
    momento_a_texto,
    momento_desde_texto,
)


class SesionNoExiste(LookupError):
    """Se pidió tocar una sesión que no está."""


def al_fallo(serie: Serie) -> int:
    """Lo que va en la columna vieja «al_fallo» (migración 37).

    SE SIGUE ESCRIBIENDO para un aparato que todavía no se actualizó: él no
    conoce «tipo», pero sí «al_fallo», y así no ve como normal una serie al
    fallo. Lo que manda es «tipo».
    """
    return int(serie.tipo is TipoSerie.FALLO)


# ---------------------------------------------------------------------------
# La rutina (el plan)
# ---------------------------------------------------------------------------


def leer_rutina(conexion: sqlite3.Connection) -> dict[int, DiaDeRutina]:
    """Los siete días, con sus bloques, sus ejercicios y sus series.

    TRES CONSULTAS Y NO UNA POR EJERCICIO. Un día con cinco ejercicios de cuatro
    series son veintiuna consultas si se va preguntando de una en una, y esto se
    hace cada vez que se abre el apartado y cada vez que se guarda algo.
    """
    series: dict[int, list[SeriePlaneada]] = {}
    for fila in conexion.execute(
        "SELECT * FROM rutina_series ORDER BY rutina_ejercicio_id, numero, id"
    ).fetchall():
        series.setdefault(int(fila["rutina_ejercicio_id"]), []).append(
            SeriePlaneada(
                id=int(fila["id"]),
                numero=int(fila["numero"]),
                repeticiones=int(fila["repeticiones"]),
                peso=int(fila["peso"]),
                segundos=_entero_o_nada(fila["segundos"]),
            )
        )

    ejercicios: dict[int, list[EjercicioPlaneado]] = {}
    for fila in conexion.execute(
        "SELECT * FROM rutina_ejercicios ORDER BY bloque_id, orden, id"
    ).fetchall():
        identificador = int(fila["id"])
        # UN EJERCICIO BORRADO DE LA BIBLIOTECA sigue en el plan por su nombre;
        # el id 0 no existe y el dominio lo rechaza, así que se guarda con el id
        # de la propia fila para poder tocarlo igual.
        borrado = not fila["ejercicio_id"]
        ejercicios.setdefault(int(fila["bloque_id"]), []).append(
            EjercicioPlaneado(
                id=identificador,
                ejercicio_id=(
                    identificador if borrado else int(fila["ejercicio_id"])
                ),
                nombre=(
                    f"{fila['nombre']} (ya no está en la biblioteca)"
                    if borrado
                    else fila["nombre"]
                ),
                orden=int(fila["orden"]),
                descanso=_entero_o_nada(fila["descanso"]),
                series=tuple(series.get(identificador, [])),
            )
        )

    bloques: dict[int, list[BloqueDeRutina]] = {}
    for fila in conexion.execute(
        "SELECT * FROM rutina_bloques ORDER BY dia, orden, id"
    ).fetchall():
        bloques.setdefault(int(fila["dia"]), []).append(
            BloqueDeRutina(
                id=int(fila["id"]),
                nombre=fila["nombre"],
                orden=int(fila["orden"]),
                ejercicios=tuple(ejercicios.get(int(fila["id"]), [])),
            )
        )

    dias: dict[int, DiaDeRutina] = {}
    for fila in conexion.execute("SELECT * FROM rutina_dias ORDER BY dia").fetchall():
        numero = int(fila["dia"])
        es_descanso = bool(fila["es_descanso"])
        dias[numero] = DiaDeRutina(
            dia=numero,
            nombre=fila["nombre"],
            color=fila["color"],
            es_descanso=es_descanso,
            bloques=() if es_descanso else tuple(bloques.get(numero, [])),
        )
    return dias


def guardar_dia(conexion: sqlite3.Connection, dia: DiaDeRutina) -> None:
    """Guarda un día entero: su nombre, su color, sus bloques y todo lo de dentro.

    SE BORRA Y SE VUELVE A ESCRIBIR, como antes: son unas pocas filas y buscar
    cuál cambió costaría más de mantener de lo que ahorra.

    SE BORRA A MANO, DE ABAJO ARRIBA, aunque las claves ajenas ya borren en
    cascada. Es la misma razón que está escrita arriba en este archivo: el
    borrado en cascada solo funciona con el PRAGMA de claves foráneas encendido,
    y si un día alguien abre la base sin él, esto dejaría series huérfanas
    apuntando a ejercicios que ya no están. Aquí no se depende de un ajuste.
    """
    conexion.execute(
        "UPDATE rutina_dias SET nombre = ?, color = ?, es_descanso = ? WHERE dia = ?",
        (dia.nombre, dia.color, int(dia.es_descanso), dia.dia),
    )
    _vaciar_dia(conexion, dia.dia)

    for numero, bloque in enumerate(dia.bloques):
        cursor = conexion.execute(
            "INSERT INTO rutina_bloques (dia, nombre, orden) VALUES (?, ?, ?)",
            (dia.dia, bloque.nombre, numero),
        )
        bloque_id = int(cursor.lastrowid)
        for sitio, planeado in enumerate(bloque.ejercicios):
            cursor = conexion.execute(
                "INSERT INTO rutina_ejercicios (bloque_id, ejercicio_id, nombre,"
                " orden, descanso) VALUES (?, ?, ?, ?, ?)",
                (
                    bloque_id,
                    planeado.ejercicio_id or None,
                    planeado.nombre,
                    sitio,
                    planeado.descanso,
                ),
            )
            ejercicio_id = int(cursor.lastrowid)
            conexion.executemany(
                "INSERT INTO rutina_series (rutina_ejercicio_id, numero,"
                " repeticiones, peso, segundos) VALUES (?, ?, ?, ?, ?)",
                [
                    (
                        ejercicio_id,
                        una.numero,
                        una.repeticiones,
                        una.peso,
                        una.segundos,
                    )
                    for una in planeado.series
                ],
            )


def _vaciar_dia(conexion: sqlite3.Connection, dia: int) -> None:
    """Borra los bloques de un día y todo lo que cuelga de ellos."""
    conexion.execute(
        "DELETE FROM rutina_series WHERE rutina_ejercicio_id IN ("
        " SELECT ej.id FROM rutina_ejercicios ej"
        " JOIN rutina_bloques bloque ON bloque.id = ej.bloque_id"
        " WHERE bloque.dia = ?)",
        (dia,),
    )
    conexion.execute(
        "DELETE FROM rutina_ejercicios WHERE bloque_id IN ("
        " SELECT id FROM rutina_bloques WHERE dia = ?)",
        (dia,),
    )
    conexion.execute("DELETE FROM rutina_bloques WHERE dia = ?", (dia,))


# ---------------------------------------------------------------------------
# Las sesiones (lo ejecutado)
# ---------------------------------------------------------------------------


def sesion_de(conexion: sqlite3.Connection, fecha: date, bloque: str | None = None) -> Sesion | None:
    """El entreno de ese día y ese bloque.

    SIN DECIR EL BLOQUE, «EL» DE ESE DÍA: el que está en marcha, y si no, el
    último que se empezó. Es lo que quieren decir el asistente («anotá 4 de
    10») y quien solo pregunta por hoy. Desde la migración 39 un día puede tener
    varios: para verlos todos, `sesiones_del_dia`.
    """
    if bloque is not None:
        fila = conexion.execute(
            "SELECT * FROM sesiones WHERE fecha = ? AND bloque = ?", (dia_a_texto(fecha), bloque)
        ).fetchone()
    else:
        fila = conexion.execute(
            "SELECT * FROM sesiones WHERE fecha = ? "
            "ORDER BY (segundos = 0 AND empezada_en != '') DESC, id DESC LIMIT 1",
            (dia_a_texto(fecha),),
        ).fetchone()
    return _sesion_desde_fila(conexion, fila) if fila else None


def sesiones_del_dia(conexion: sqlite3.Connection, fecha: date) -> list[Sesion]:
    """Todos los entrenos de ese día, en el orden en que se empezaron."""
    filas = conexion.execute(
        "SELECT * FROM sesiones WHERE fecha = ? ORDER BY id", (dia_a_texto(fecha),)
    ).fetchall()
    return [_sesion_desde_fila(conexion, fila) for fila in filas]


HORAS_PARA_RETOMAR = 6
"""Hasta cuánto después de empezar se da un entreno por «en marcha».

POR QUÉ UN TOPE: un entreno que empezaste y nunca terminaste —lo dejaste a
medias hace tres días— no puede secuestrar la aplicación cada vez que la
abres. Seis horas cubren con holgura un entreno largo con el teléfono
bloqueado entre medias, y nada más."""


def sesion_en_marcha(conexion: sqlite3.Connection, ahora: datetime) -> Sesion | None:
    """El entreno empezado y sin terminar de las últimas horas, o None.

    «SIN TERMINAR» ES `segundos = 0`: al pulsar «Terminar entreno» se guarda
    lo que duró, y mientras tanto vale cero.
    """
    filas = conexion.execute(
        "SELECT * FROM sesiones WHERE segundos = 0 AND empezada_en != '' "
        "ORDER BY fecha DESC LIMIT 3"
    ).fetchall()
    for fila in filas:
        empezada = _momento_o_nada(fila["empezada_en"])
        if empezada is not None and ahora - empezada <= timedelta(hours=HORAS_PARA_RETOMAR):
            return _sesion_desde_fila(conexion, fila)
    return None

def sesiones_entre(
    conexion: sqlite3.Connection, desde: date, hasta: date
) -> list[Sesion]:
    filas = conexion.execute(
        "SELECT * FROM sesiones WHERE fecha >= ? AND fecha <= ? ORDER BY fecha, id",
        (dia_a_texto(desde), dia_a_texto(hasta)),
    ).fetchall()
    return [_sesion_desde_fila(conexion, fila) for fila in filas]


def todas_las_sesiones(conexion: sqlite3.Connection) -> list[Sesion]:
    filas = conexion.execute("SELECT * FROM sesiones ORDER BY fecha, id").fetchall()
    return [_sesion_desde_fila(conexion, fila) for fila in filas]


def guardar_sesion(conexion: sqlite3.Connection, sesion: Sesion) -> Sesion:
    """Guarda la sesión entera. NO toca la rutina en ningún caso.

    Es la mitad práctica de la separación que pidió el usuario: aquí no hay ni
    una consulta que escriba en rutina_dias o rutina_ejercicios. Si un día
    apareciera, el plan empezaría a cambiar solo.
    """
    fila = conexion.execute(
        "SELECT id FROM sesiones WHERE fecha = ? AND bloque = ?",
        (dia_a_texto(sesion.fecha), sesion.bloque),
    ).fetchone()

    if fila is None:
        cursor = conexion.execute(
            "INSERT INTO sesiones (fecha, bloque, nombre, color, empezada_en, segundos) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                dia_a_texto(sesion.fecha),
                sesion.bloque,
                sesion.nombre,
                sesion.color,
                _momento_o_vacio(sesion.empezada_en),
                sesion.segundos,
            ),
        )
        id_sesion = cursor.lastrowid
    else:
        id_sesion = int(fila["id"])
        conexion.execute(
            "UPDATE sesiones SET nombre = ?, color = ?, empezada_en = ?, "
            "segundos = ? WHERE id = ?",
            (
                sesion.nombre,
                sesion.color,
                _momento_o_vacio(sesion.empezada_en),
                sesion.segundos,
                id_sesion,
            ),
        )
        _borrar_contenido(conexion, id_sesion)

    for numero, ejercicio in enumerate(sesion.ejercicios):
        cursor = conexion.execute(
            "INSERT INTO sesion_ejercicios (sesion_id, ejercicio_id, nombre, "
            "orden, descanso, nota) VALUES (?, ?, ?, ?, ?, ?)",
            (
                id_sesion,
                ejercicio.ejercicio_id,
                ejercicio.nombre,
                numero,
                ejercicio.descanso,
                ejercicio.nota,
            ),
        )
        id_ejercicio = cursor.lastrowid
        for serie in ejercicio.series:
            conexion.execute(
                "INSERT INTO series (sesion_ejercicio_id, numero, peso, "
                "repeticiones, hecha, rpe, tipo, al_fallo, segundos, metros) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    id_ejercicio,
                    serie.numero,
                    serie.peso,
                    serie.repeticiones,
                    int(serie.hecha),
                    serie.rpe,
                    serie.tipo.value,
                    al_fallo(serie),
                    serie.segundos,
                    serie.metros,
                ),
            )

    return sesion_de(conexion, sesion.fecha, sesion.bloque)


def borrar_sesion(conexion: sqlite3.Connection, fecha: date, bloque: str | None = None) -> None:
    """Borra ESE entreno: el de ese bloque, o «el» del día (ver `sesion_de`)."""
    sesion = sesion_de(conexion, fecha, bloque)
    if sesion is None:
        raise SesionNoExiste(f"no hay ninguna sesión del {fecha}")
    _borrar_contenido(conexion, sesion.id)
    conexion.execute("DELETE FROM sesiones WHERE id = ?", (sesion.id,))


def historial_de(
    conexion: sqlite3.Connection, id_ejercicio: int
) -> list[tuple[date, EjercicioDeSesion]]:
    """Todas las veces que se ha hecho ese ejercicio, de la más vieja a la más
    nueva. Es lo que alimenta la gráfica y "la última vez"."""
    filas = conexion.execute(
        """
        SELECT se.*, s.fecha AS fecha
        FROM sesion_ejercicios se
        JOIN sesiones s ON s.id = se.sesion_id
        WHERE se.ejercicio_id = ?
        ORDER BY s.fecha
        """,
        (id_ejercicio,),
    ).fetchall()
    return [
        (dia_desde_texto(fila["fecha"]), _ejercicio_desde_fila(conexion, fila))
        for fila in filas
    ]



def marca_antes(
    conexion: sqlite3.Connection, id_ejercicio: int, antes_de: date,
    unidad: Unidad = Unidad.REPS,
) -> Marca | None:
    """La mejor marca de ese ejercicio en los días ANTERIORES a esa fecha: la
    que hay que superar hoy para la medalla. En `unidad`: ver mejor_marca."""
    return mejor_marca(
        (
            (fecha, uno) for fecha, uno in historial_de(conexion, id_ejercicio)
            if fecha < antes_de
        ),
        unidad,
    )

def ultima_vez(
    conexion: sqlite3.Connection, id_ejercicio: int, antes_de: date
) -> EjercicioDeSesion | None:
    """Lo que se hizo la última vez en ese ejercicio, antes de esa fecha.

    Es la información que de verdad decide qué peso poner hoy, y por eso se
    excluye el día que se está mirando: comparar la sesión de hoy consigo misma
    no diría nada.
    """
    fila = conexion.execute(
        """
        SELECT se.*, s.fecha AS fecha
        FROM sesion_ejercicios se
        JOIN sesiones s ON s.id = se.sesion_id
        WHERE se.ejercicio_id = ? AND s.fecha < ?
        ORDER BY s.fecha DESC
        LIMIT 1
        """,
        (id_ejercicio, dia_a_texto(antes_de)),
    ).fetchone()
    return _ejercicio_desde_fila(conexion, fila) if fila else None


def olvidar_ejercicio(conexion: sqlite3.Connection, id_ejercicio: int) -> None:
    """Deja huérfanas las filas de ese ejercicio, sin borrar ninguna.

    Se llama al borrar de la biblioteca. El nombre se queda donde está, así que
    el historial se sigue leyendo entero: solo se pierde el enlace con una ficha
    que ya no existe.
    """
    conexion.execute(
        "UPDATE sesion_ejercicios SET ejercicio_id = NULL WHERE ejercicio_id = ?",
        (id_ejercicio,),
    )
    conexion.execute(
        "UPDATE rutina_ejercicios SET ejercicio_id = NULL WHERE ejercicio_id = ?",
        (id_ejercicio,),
    )


# ---------------------------------------------------------------------------


def _borrar_contenido(conexion: sqlite3.Connection, id_sesion: int) -> None:
    conexion.execute(
        "DELETE FROM series WHERE sesion_ejercicio_id IN "
        "(SELECT id FROM sesion_ejercicios WHERE sesion_id = ?)",
        (id_sesion,),
    )
    conexion.execute("DELETE FROM sesion_ejercicios WHERE sesion_id = ?", (id_sesion,))


def _sesion_desde_fila(conexion: sqlite3.Connection, fila: sqlite3.Row) -> Sesion:
    ejercicios = conexion.execute(
        "SELECT * FROM sesion_ejercicios WHERE sesion_id = ? ORDER BY orden, id",
        (int(fila["id"]),),
    ).fetchall()
    return Sesion(
        id=int(fila["id"]),
        fecha=dia_desde_texto(fila["fecha"]),
        nombre=fila["nombre"],
        color=fila["color"],
        empezada_en=_momento_o_nada(fila["empezada_en"]),
        segundos=int(fila["segundos"] or 0),
        bloque=fila["bloque"],
        ejercicios=tuple(
            _ejercicio_desde_fila(conexion, uno) for uno in ejercicios
        ),
    )


def _momento_o_vacio(momento) -> str:
    """La hora de inicio como texto, o vacio si no se sabe.

    VACIO Y NO NULL porque la columna es NOT NULL con vacio por omision: asi los
    entrenos de antes del cronometro y los que aun no han arrancado se leen
    igual, sin tener que distinguir dos formas de "no hay hora".
    """
    return "" if momento is None else momento_a_texto(momento)


def _momento_o_nada(texto) -> datetime | None:
    """La hora de inicio, o None si la columna esta vacia.

    NO REVIENTA SI EL TEXTO ESTA MAL ESCRITO: se trata como si no hubiera hora.
    Una fila rara no puede impedir abrir un entreno entero, y menos aun uno de
    hace dos anos.
    """
    if not texto:
        return None
    try:
        return momento_desde_texto(texto)
    except (ValueError, TypeError):
        return None


def _entero_o_nada(valor) -> int | None:
    """El valor de la columna, o None si esta vacia.

    NO SE CONFUNDE EL HUECO CON EL CERO, y aqui es donde se decide: un cero es un
    descanso de cero segundos elegido a proposito (el cardio no lleva), y un None
    es "aqui no se dijo nada" y se rellena con el de la ficha del ejercicio. Un
    `int(valor or 0)` los habria mezclado y todos los ejercicios de antes de la
    migracion 13 se habrian quedado sin cronometro.
    """
    return None if valor is None else int(valor)


def _ejercicio_desde_fila(
    conexion: sqlite3.Connection, fila: sqlite3.Row
) -> EjercicioDeSesion:
    series = conexion.execute(
        "SELECT * FROM series WHERE sesion_ejercicio_id = ? ORDER BY numero",
        (int(fila["id"]),),
    ).fetchall()
    return EjercicioDeSesion(
        id=int(fila["id"]),
        ejercicio_id=int(fila["ejercicio_id"]) if fila["ejercicio_id"] else None,
        nombre=fila["nombre"],
        orden=int(fila["orden"]),
        descanso=_entero_o_nada(fila["descanso"]),
        nota=fila["nota"],
        series=tuple(
            Serie(
                id=int(una["id"]),
                numero=int(una["numero"]),
                peso=int(una["peso"]),
                repeticiones=int(una["repeticiones"]),
                hecha=bool(una["hecha"]),
                rpe=int(una["rpe"]) if una["rpe"] is not None else None,
                tipo=TipoSerie(una["tipo"]),
                segundos=int(una["segundos"]),
                metros=int(una["metros"]),
            )
            for una in series
        ),
    )
