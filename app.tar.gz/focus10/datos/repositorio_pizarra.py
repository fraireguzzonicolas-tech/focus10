"""Las carpetas (cuadernos) y las pizarras (páginas) en la base (migración 41).

LAS TABLAS SON LAS DE ANTES, A PROPÓSITO: cuando la pizarra pasó a ser
infinita (11 nov 2026) los cuadernos quedaron como carpetas y cada página como
una pizarra. Nada se mudó, y la sincronización sigue igual.

EL DOCUMENTO SE LEE Y SE GUARDA ENTERO, ya convertido (dominio/
pizarra_documento.py): las páginas del formato de antes se convierten al leer.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime

from ..dominio.pizarra_documento import a_guardado, desde_guardado, vacio
from .fechas import momento_a_texto, momento_desde_texto

NOMBRE_MAXIMO = 60
TITULO_MAXIMO = 80


@dataclass(frozen=True)
class Cuaderno:
    id: int
    nombre: str
    paginas: int


@dataclass(frozen=True)
class Pagina:
    id: int
    cuaderno_id: int
    titulo: str
    editada_en: datetime


def _limpio(texto: str, maximo: int) -> str:
    limpio = " ".join((texto or "").split())[:maximo]
    if not limpio:
        raise ValueError("hace falta un nombre")
    return limpio


# --------------------------------------------------------------- cuadernos


def listar_cuadernos(conexion: sqlite3.Connection) -> list[Cuaderno]:
    filas = conexion.execute(
        """
        SELECT c.id, c.nombre, COUNT(p.id) AS paginas
          FROM pizarra_cuadernos c LEFT JOIN pizarra_paginas p ON p.cuaderno_id = c.id
         GROUP BY c.id ORDER BY c.orden, c.id
        """
    ).fetchall()
    return [Cuaderno(f["id"], f["nombre"], f["paginas"]) for f in filas]


def crear_cuaderno(conexion: sqlite3.Connection, nombre: str, ahora: datetime) -> Cuaderno:
    """Una carpeta nueva AL FINAL, con su primera pizarra ya puesta.

    CON UNA PIZARRA Y NO VACÍA: una carpeta sin pizarras es una pantalla en
    blanco que te obliga a un segundo clic antes de poder escribir nada.
    """
    orden = conexion.execute(
        "SELECT COALESCE(MAX(orden) + 1, 0) FROM pizarra_cuadernos"
    ).fetchone()[0]
    cursor = conexion.execute(
        "INSERT INTO pizarra_cuadernos (nombre, orden, creado_en) VALUES (?, ?, ?)",
        (_limpio(nombre, NOMBRE_MAXIMO), orden, momento_a_texto(ahora)),
    )
    crear_pagina(conexion, cursor.lastrowid, "Pizarra 1", ahora)
    return next(c for c in listar_cuadernos(conexion) if c.id == cursor.lastrowid)


def renombrar_cuaderno(conexion: sqlite3.Connection, id_cuaderno: int, nombre: str) -> None:
    conexion.execute(
        "UPDATE pizarra_cuadernos SET nombre = ? WHERE id = ?",
        (_limpio(nombre, NOMBRE_MAXIMO), id_cuaderno),
    )


def borrar_cuaderno(conexion: sqlite3.Connection, id_cuaderno: int) -> None:
    """Se lleva sus páginas (ON DELETE CASCADE). La pantalla lo pregunta antes.

    LA CASCADA TAMBIÉN AVISA A LA NUBE de cada página borrada: SQLite dispara
    los disparadores de las hijas. Lo vigila un test; si no, las páginas
    volverían a bajar en la próxima sincronización.
    """
    conexion.execute("DELETE FROM pizarra_cuadernos WHERE id = ?", (id_cuaderno,))


# --------------------------------------------------------------- páginas


def listar_paginas(conexion: sqlite3.Connection, id_cuaderno: int) -> list[Pagina]:
    filas = conexion.execute(
        "SELECT id, cuaderno_id, titulo, editada_en FROM pizarra_paginas "
        "WHERE cuaderno_id = ? ORDER BY orden, id",
        (id_cuaderno,),
    ).fetchall()
    return [
        Pagina(f["id"], f["cuaderno_id"], f["titulo"], momento_desde_texto(f["editada_en"]))
        for f in filas
    ]


def crear_pagina(
    conexion: sqlite3.Connection, id_cuaderno: int, titulo: str, ahora: datetime
) -> int:
    orden = conexion.execute(
        "SELECT COALESCE(MAX(orden) + 1, 0) FROM pizarra_paginas WHERE cuaderno_id = ?",
        (id_cuaderno,),
    ).fetchone()[0]
    cursor = conexion.execute(
        "INSERT INTO pizarra_paginas (cuaderno_id, titulo, orden, contenido, editada_en) "
        "VALUES (?, ?, ?, ?, ?)",
        (id_cuaderno, _limpio(titulo, TITULO_MAXIMO), orden, a_guardado(vacio()), momento_a_texto(ahora)),
    )
    return cursor.lastrowid


def titulo_nuevo(conexion: sqlite3.Connection, id_cuaderno: int) -> str:
    """«Pizarra N», con N el siguiente a las que hay."""
    cuantas = conexion.execute(
        "SELECT COUNT(*) FROM pizarra_paginas WHERE cuaderno_id = ?", (id_cuaderno,)
    ).fetchone()[0]
    return f"Pizarra {cuantas + 1}"


def renombrar_pagina(conexion: sqlite3.Connection, id_pagina: int, titulo: str) -> None:
    conexion.execute(
        "UPDATE pizarra_paginas SET titulo = ? WHERE id = ?",
        (_limpio(titulo, TITULO_MAXIMO), id_pagina),
    )


def borrar_pagina(conexion: sqlite3.Connection, id_pagina: int) -> None:
    conexion.execute("DELETE FROM pizarra_paginas WHERE id = ?", (id_pagina,))


def duplicar_pagina(conexion: sqlite3.Connection, id_pagina: int, ahora: datetime) -> int | None:
    """Una copia de la pizarra, AL FINAL de su carpeta, con «(copia)» en el
    nombre. Devuelve la nueva, o None si la original ya no existe."""
    fila = conexion.execute(
        "SELECT cuaderno_id, titulo, contenido FROM pizarra_paginas WHERE id = ?", (id_pagina,)
    ).fetchone()
    if fila is None:
        return None
    nueva = crear_pagina(
        conexion, fila["cuaderno_id"], f"{fila['titulo'][:TITULO_MAXIMO - 9]} (copia)", ahora
    )
    conexion.execute(
        "UPDATE pizarra_paginas SET contenido = ? WHERE id = ?", (fila["contenido"], nueva)
    )
    return nueva


def leer_documento(conexion: sqlite3.Connection, id_pagina: int) -> dict | None:
    """El documento de esa pizarra (ya en el formato nuevo), o None si no
    existe (borrada en otro aparato)."""
    fila = conexion.execute(
        "SELECT contenido FROM pizarra_paginas WHERE id = ?", (id_pagina,)
    ).fetchone()
    return None if fila is None else desde_guardado(fila["contenido"])


def guardar_documento(
    conexion: sqlite3.Connection, id_pagina: int, documento: dict, ahora: datetime
) -> bool:
    """Guarda el documento. Devuelve False si la pizarra ya no existe.

    a_guardado avisa con DocumentoLleno si pesa demasiado, ANTES de tocar la
    base: lo que había guardado queda intacto.
    """
    cursor = conexion.execute(
        "UPDATE pizarra_paginas SET contenido = ?, editada_en = ? WHERE id = ?",
        (a_guardado(documento), momento_a_texto(ahora), id_pagina),
    )
    return cursor.rowcount == 1
