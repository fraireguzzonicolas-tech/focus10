"""Guardar y leer objetivos y sus aportaciones.

EL AVANCE NO SE GUARDA en ningún sitio: se calcula con dominio.objetivo.avance a
partir del tipo, de las aportaciones y del porcentaje manual. Igual que las
posiciones de inversiones: lo que no existe no se puede desincronizar.

LO QUE SÍ SE GUARDA es `cumplido_en`, que no es un cálculo: es el día en que se
dio por conseguido. Si se recalculara, sacar dinero de un objetivo terminado lo
devolvería a la lista de pendientes, y eso no es lo que pasó.
"""

from __future__ import annotations

import sqlite3
from datetime import date

from ..dominio.objetivo import Aportacion, Objetivo, TipoObjetivo
from .fechas import dia_a_texto, dia_desde_texto


class ObjetivoNoExiste(LookupError):
    """Se pidió tocar un objetivo que no está."""


def listar(conexion: sqlite3.Connection) -> list[Objetivo]:
    filas = conexion.execute(
        "SELECT * FROM objetivos ORDER BY orden, nombre"
    ).fetchall()
    return [_desde_fila(fila) for fila in filas]


def obtener(conexion: sqlite3.Connection, id_objetivo: int) -> Objetivo | None:
    fila = conexion.execute(
        "SELECT * FROM objetivos WHERE id = ?", (id_objetivo,)
    ).fetchone()
    return _desde_fila(fila) if fila else None


def crear(conexion: sqlite3.Connection, objetivo: Objetivo) -> Objetivo:
    cursor = conexion.execute(
        """
        INSERT INTO objetivos
            (nombre, color, tipo, porque, importe_objetivo, avance_manual,
             fecha_limite, cumplido_en, orden)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        _a_fila(objetivo, conexion),
    )
    return obtener(conexion, cursor.lastrowid)


def actualizar(conexion: sqlite3.Connection, objetivo: Objetivo) -> Objetivo:
    if objetivo.id is None:
        raise ValueError("para corregir hace falta el id del objetivo")
    _exigir(conexion, objetivo.id)
    conexion.execute(
        """
        UPDATE objetivos SET nombre = ?, color = ?, tipo = ?, porque = ?,
            importe_objetivo = ?, avance_manual = ?, fecha_limite = ?,
            cumplido_en = ?, orden = ?
        WHERE id = ?
        """,
        (*_a_fila(objetivo, conexion), objetivo.id),
    )
    return obtener(conexion, objetivo.id)


def borrar(conexion: sqlite3.Connection, id_objetivo: int) -> None:
    """Borra el objetivo y sus aportaciones.

    Se van juntas: una aportación a un objetivo que ya no existe no se puede ni
    ver ni sumar a nada.
    """
    _exigir(conexion, id_objetivo)
    conexion.execute("DELETE FROM aportaciones WHERE objetivo_id = ?", (id_objetivo,))
    conexion.execute("DELETE FROM objetivos WHERE id = ?", (id_objetivo,))


def cambiar_avance(
    conexion: sqlite3.Connection, id_objetivo: int, avance: int
) -> Objetivo:
    """El porcentaje a mano de un objetivo libre, desde su propia tarjeta."""
    objetivo = _exigir(conexion, id_objetivo)
    if objetivo.tipo is not TipoObjetivo.LIBRE:
        raise ValueError(
            "el avance a mano es solo de los objetivos libres; los de dinero "
            "avanzan con sus aportaciones"
        )
    conexion.execute(
        "UPDATE objetivos SET avance_manual = ? WHERE id = ?", (avance, id_objetivo)
    )
    return obtener(conexion, id_objetivo)


def marcar_cumplido(
    conexion: sqlite3.Connection, id_objetivo: int, dia: date | None
) -> Objetivo:
    """Da por conseguido un objetivo, o lo devuelve a abierto con None."""
    _exigir(conexion, id_objetivo)
    conexion.execute(
        "UPDATE objetivos SET cumplido_en = ? WHERE id = ?",
        (dia_a_texto(dia) if dia is not None else None, id_objetivo),
    )
    return obtener(conexion, id_objetivo)


# ---------------------------------------------------------------------------
# Aportaciones
# ---------------------------------------------------------------------------


def aportaciones_de(
    conexion: sqlite3.Connection, id_objetivo: int
) -> list[Aportacion]:
    filas = conexion.execute(
        "SELECT * FROM aportaciones WHERE objetivo_id = ? ORDER BY fecha, id",
        (id_objetivo,),
    ).fetchall()
    return [_aportacion_desde_fila(fila) for fila in filas]


def todas_las_aportaciones(
    conexion: sqlite3.Connection,
) -> dict[int, list[Aportacion]]:
    """Las aportaciones de TODOS los objetivos, de una sola consulta.

    La pantalla necesita el avance de cada objetivo a la vez; pedirlas objetivo a
    objetivo serían quince consultas para pintar una lista.
    """
    filas = conexion.execute(
        "SELECT * FROM aportaciones ORDER BY fecha, id"
    ).fetchall()
    por_objetivo: dict[int, list[Aportacion]] = {}
    for fila in filas:
        una = _aportacion_desde_fila(fila)
        por_objetivo.setdefault(una.objetivo_id, []).append(una)
    return por_objetivo


def aportar(conexion: sqlite3.Connection, aportacion: Aportacion) -> Aportacion:
    _exigir(conexion, aportacion.objetivo_id)
    cursor = conexion.execute(
        "INSERT INTO aportaciones (objetivo_id, importe, fecha, nota) "
        "VALUES (?, ?, ?, ?)",
        (
            aportacion.objetivo_id,
            aportacion.importe,
            dia_a_texto(aportacion.fecha),
            aportacion.nota,
        ),
    )
    fila = conexion.execute(
        "SELECT * FROM aportaciones WHERE id = ?", (cursor.lastrowid,)
    ).fetchone()
    return _aportacion_desde_fila(fila)


def borrar_aportacion(conexion: sqlite3.Connection, id_aportacion: int) -> None:
    conexion.execute("DELETE FROM aportaciones WHERE id = ?", (id_aportacion,))


def ultimas_aportaciones(
    conexion: sqlite3.Connection, cuantas: int = 10
) -> list[tuple[Aportacion, str]]:
    """Las últimas aportaciones de todos los objetivos, con el nombre de cada uno.

    Con el nombre porque una lista de importes sueltos no dice a qué fueron, y
    eso es justo lo que se quiere ver.
    """
    filas = conexion.execute(
        """
        SELECT a.*, o.nombre AS nombre_objetivo
        FROM aportaciones a
        JOIN objetivos o ON o.id = a.objetivo_id
        ORDER BY a.fecha DESC, a.id DESC
        LIMIT ?
        """,
        (cuantas,),
    ).fetchall()
    return [
        (_aportacion_desde_fila(fila), fila["nombre_objetivo"]) for fila in filas
    ]


# ---------------------------------------------------------------------------


def _siguiente_orden(conexion: sqlite3.Connection) -> int:
    fila = conexion.execute(
        "SELECT COALESCE(MAX(orden), 0) + 1 AS siguiente FROM objetivos"
    ).fetchone()
    return int(fila["siguiente"])


def _a_fila(objetivo: Objetivo, conexion: sqlite3.Connection) -> tuple:
    return (
        objetivo.nombre,
        objetivo.color,
        objetivo.tipo.value,
        objetivo.porque,
        objetivo.importe_objetivo,
        objetivo.avance_manual,
        dia_a_texto(objetivo.fecha_limite) if objetivo.fecha_limite else None,
        dia_a_texto(objetivo.cumplido_en) if objetivo.cumplido_en else None,
        objetivo.orden or _siguiente_orden(conexion),
    )


def _desde_fila(fila: sqlite3.Row) -> Objetivo:
    return Objetivo(
        id=int(fila["id"]),
        nombre=fila["nombre"],
        color=fila["color"],
        tipo=TipoObjetivo(fila["tipo"]),
        porque=fila["porque"],
        importe_objetivo=int(fila["importe_objetivo"]),
        avance_manual=int(fila["avance_manual"]),
        fecha_limite=dia_desde_texto(fila["fecha_limite"])
        if fila["fecha_limite"]
        else None,
        cumplido_en=dia_desde_texto(fila["cumplido_en"])
        if fila["cumplido_en"]
        else None,
        orden=int(fila["orden"]),
    )


def _aportacion_desde_fila(fila: sqlite3.Row) -> Aportacion:
    return Aportacion(
        id=int(fila["id"]),
        objetivo_id=int(fila["objetivo_id"]),
        importe=int(fila["importe"]),
        fecha=dia_desde_texto(fila["fecha"]),
        nota=fila["nota"],
    )


def _exigir(conexion: sqlite3.Connection, id_objetivo: int) -> Objetivo:
    objetivo = obtener(conexion, id_objetivo)
    if objetivo is None:
        raise ObjetivoNoExiste(f"no hay ningún objetivo con id {id_objetivo}")
    return objetivo
