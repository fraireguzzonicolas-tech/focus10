"""Guardar y leer las categorías.

Un "repositorio" es simplemente el sitio donde vive el SQL de una tabla. Se
separa por dos motivos: el resto del programa habla de Categorías y no de filas,
y si algún día cambia el esquema solo hay que tocar este archivo.
"""

from __future__ import annotations

import sqlite3

from ..dominio.categoria import Categoria
from ..dominio.movimiento import Tipo
from .conexion import transaccion


class CategoriaNoExiste(LookupError):
    """No hay ninguna categoría con ese id."""


class CategoriaRepetida(ValueError):
    """Ya existe otra categoría con ese nombre para el mismo tipo."""


class CategoriaEnUso(ValueError):
    """No se puede borrar: tiene movimientos apuntados."""


def listar(
    conexion: sqlite3.Connection,
    *,
    tipo: Tipo | None = None,
    incluir_inactivas: bool = False,
) -> list[Categoria]:
    """Las categorías, en el orden en que deben aparecer.

    Por omisión NO devuelve las desactivadas, porque el uso normal es rellenar
    el desplegable de apuntar un gasto. Para la pantalla de administrarlas hay
    que pedirlas expresamente.
    """
    condiciones = []
    parametros: list[object] = []
    if tipo is not None:
        if not isinstance(tipo, Tipo):
            raise TypeError(f"tipo tiene que ser Tipo o None, no {type(tipo).__name__}")
        condiciones.append("tipo = ?")
        parametros.append(tipo.value)
    if not incluir_inactivas:
        condiciones.append("activa = 1")

    donde = f"WHERE {' AND '.join(condiciones)}" if condiciones else ""
    filas = conexion.execute(
        f"SELECT * FROM categorias {donde} ORDER BY tipo, orden, id", parametros
    ).fetchall()
    return [_desde_fila(fila) for fila in filas]


def obtener(conexion: sqlite3.Connection, id_categoria: int) -> Categoria | None:
    """La categoría con ese id, o None. Devuelve las inactivas también, porque
    un movimiento viejo puede apuntar a una que ya no se usa."""
    fila = conexion.execute(
        "SELECT * FROM categorias WHERE id = ?", (id_categoria,)
    ).fetchone()
    return None if fila is None else _desde_fila(fila)


def crear(
    conexion: sqlite3.Connection,
    nombre: str,
    tipo: Tipo,
    orden: int | None = None,
) -> Categoria:
    """Crea una categoría nueva y la devuelve ya con su id.

    Sin `orden`, se coloca la última de su tipo: es lo que espera quien acaba de
    escribir un nombre en una lista.
    """
    # Construir la Categoría antes de tocar la base valida el nombre y el tipo
    # con las reglas del dominio, no con las de SQLite.
    if orden is None:
        orden = _siguiente_orden(conexion, tipo)
    categoria = Categoria(nombre=nombre, tipo=tipo, orden=orden)

    try:
        cursor = conexion.execute(
            "INSERT INTO categorias (nombre, tipo, activa, orden) VALUES (?, ?, 1, ?)",
            (categoria.nombre, categoria.tipo.value, categoria.orden),
        )
    except sqlite3.IntegrityError as error:
        raise CategoriaRepetida(
            f"ya existe una categoría de {tipo.value} llamada {categoria.nombre!r}"
        ) from error
    return _con_id(categoria, cursor.lastrowid)


def renombrar(conexion: sqlite3.Connection, id_categoria: int, nombre: str) -> Categoria:
    """Cambia el nombre. Los movimientos siguen apuntando a la misma categoría,
    así que el historial se renombra entero, que es lo que se espera."""
    actual = _exigir(conexion, id_categoria)
    nueva = Categoria(
        nombre=nombre, tipo=actual.tipo, id=actual.id, activa=actual.activa,
        orden=actual.orden,
    )
    try:
        conexion.execute(
            "UPDATE categorias SET nombre = ? WHERE id = ?", (nueva.nombre, id_categoria)
        )
    except sqlite3.IntegrityError as error:
        raise CategoriaRepetida(
            f"ya existe una categoría de {actual.tipo.value} llamada {nueva.nombre!r}"
        ) from error
    return nueva


def cambiar_actividad(
    conexion: sqlite3.Connection, id_categoria: int, activa: bool
) -> Categoria:
    """Activa o desactiva. Desactivar es la forma correcta de "quitar" una
    categoría que ya se ha usado: deja de ofrecerse y el historial se entiende."""
    if not isinstance(activa, bool):
        raise TypeError("activa tiene que ser True o False")
    actual = _exigir(conexion, id_categoria)
    conexion.execute(
        "UPDATE categorias SET activa = ? WHERE id = ?", (int(activa), id_categoria)
    )
    return Categoria(
        nombre=actual.nombre, tipo=actual.tipo, id=actual.id, activa=activa,
        orden=actual.orden,
    )


def esta_en_uso(conexion: sqlite3.Connection, id_categoria: int) -> bool:
    fila = conexion.execute(
        "SELECT 1 FROM movimientos WHERE categoria_id = ? LIMIT 1", (id_categoria,)
    ).fetchone()
    return fila is not None


def borrar(conexion: sqlite3.Connection, id_categoria: int) -> None:
    """Borra de verdad, y SOLO si no tiene movimientos.

    Si los tiene, falla con un mensaje que dice qué hacer en su lugar. La base
    de datos lo impediría igualmente por la clave ajena; esto es para que el
    error se entienda en vez de salir un "FOREIGN KEY constraint failed".
    """
    _exigir(conexion, id_categoria)
    if esta_en_uso(conexion, id_categoria):
        raise CategoriaEnUso(
            f"la categoría {id_categoria} tiene movimientos apuntados y no se "
            "puede borrar; desactívala si no quieres seguir usándola"
        )
    conexion.execute("DELETE FROM categorias WHERE id = ?", (id_categoria,))


def reordenar(conexion: sqlite3.Connection, ids_en_orden: list[int]) -> None:
    """Coloca las categorías en el orden dado, todo o nada.

    En una transacción porque un reordenamiento a medias dejaría dos categorías
    con el mismo número de orden y una lista que salta de sitio.
    """
    with transaccion(conexion):
        for posicion, id_categoria in enumerate(ids_en_orden, start=1):
            cursor = conexion.execute(
                "UPDATE categorias SET orden = ? WHERE id = ?", (posicion, id_categoria)
            )
            if cursor.rowcount == 0:
                raise CategoriaNoExiste(f"no existe la categoría {id_categoria}")


def _siguiente_orden(conexion: sqlite3.Connection, tipo: Tipo) -> int:
    fila = conexion.execute(
        "SELECT COALESCE(MAX(orden), 0) + 1 AS siguiente FROM categorias WHERE tipo = ?",
        (tipo.value,),
    ).fetchone()
    return int(fila["siguiente"])


def _exigir(conexion: sqlite3.Connection, id_categoria: int) -> Categoria:
    categoria = obtener(conexion, id_categoria)
    if categoria is None:
        raise CategoriaNoExiste(f"no existe la categoría {id_categoria}")
    return categoria


def _con_id(categoria: Categoria, id_nuevo: int) -> Categoria:
    return Categoria(
        nombre=categoria.nombre, tipo=categoria.tipo, id=id_nuevo,
        activa=categoria.activa, orden=categoria.orden,
    )


def _desde_fila(fila: sqlite3.Row) -> Categoria:
    return Categoria(
        id=fila["id"],
        nombre=fila["nombre"],
        tipo=Tipo(fila["tipo"]),
        activa=bool(fila["activa"]),
        orden=fila["orden"],
    )
