"""Las imágenes de la pizarra en este aparato: prepararlas y guardarlas.

NO VAN DENTRO DEL DOCUMENTO: el documento tiene tope de 1 MB y viaja entero
en cada cambio, y una sola captura de pantalla ya lo llenaría. El documento
dice qué archivo es y dónde va; los bytes viven aquí, en la carpeta
«pizarra» junto a la base de datos, y en la nube (sistema/pizarra_nube.py).

PREPARAR ANTES DE GUARDAR, SIEMPRE (con Pillow):
- SE ACHICA a LADO_MAXIMO: una foto del celular de 4000 píxeles pesa 20 veces
  más y en la pizarra se ve igual.
- SE GUARDA COMO WEBP: una captura de pantalla, sin pérdida (las letras se
  leen nítidas) si queda chica; una foto, con un poco de pérdida.
- SE BORRA TODO LO OCULTO de la foto (EXIF): ahí van el lugar donde se sacó y
  el modelo del celular, y la imagen viaja a la nube. Primero la privacidad.

EL NOMBRE SALE DEL CONTENIDO (la huella sha256): la misma imagen pegada dos
veces es un solo archivo, y dos aparatos que la suben no chocan.
"""

from __future__ import annotations

import hashlib
import io
import json
import re
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from . import ajustes, rutas

if TYPE_CHECKING:
    from PIL import Image

# PILLOW SE CARGA RECIÉN AL PREPARAR UNA IMAGEN (ver preparar), no al abrir
# Focus: este archivo lo importan la cuenta y la pizarra, y en la web (que no
# lleva la pieza de la pizarra ni Pillow) cargarlo al arrancar tiraba la app
# entera. Lo demás de aquí —nombres, carpeta, la lista por subir— no lo usa.

CARPETA = "pizarra"

LADO_MAXIMO = 2400
"""Lo más largo que queda una imagen, en píxeles. Alcanza para ver nítida una
captura de un monitor grande a pantalla completa."""

TOPE_SIN_PERDIDA = 700_000
"""Hasta este peso se guarda sin pérdida (las capturas suelen quedar muy por
debajo). Pasado, es una foto: con pérdida pesa una fracción y no se nota."""

CALIDAD = 85

CRUDO_MAXIMO = 64_000_000
"""Lo más que se acepta leer. Una captura de un monitor 4K llega del
portapapeles de Windows sin comprimir: 3840 × 2160 × 4 = 33 MB."""

NOMBRE = re.compile(r"^[0-9a-f]{32}\.webp$")
"""LO ÚNICO QUE SE ACEPTA COMO NOMBRE, igual que en la pizarra (documento.dart,
Imagen.nombreValido). Así un documento raro llegado de la nube no puede hacer
leer ni escribir otro archivo («../../algo»)."""


class ImagenNoValida(ValueError):
    """No es una imagen, está rota o es demasiado grande."""


@dataclass(frozen=True)
class Preparada:
    nombre: str
    datos: bytes
    ancho: int
    alto: int


def preparar(crudo: bytes) -> Preparada:
    """La imagen lista para guardar: achicada, en WebP y sin lo oculto."""
    from PIL import Image, ImageOps, UnidentifiedImageError

    if not crudo or len(crudo) > CRUDO_MAXIMO:
        raise ImagenNoValida("vacía o demasiado grande")
    try:
        with Image.open(io.BytesIO(crudo)) as abierta:
            # DE PIE COMO SE SACÓ: el celular guarda la foto acostada y anota
            # en lo oculto que hay que girarla. Ese dato se borra, así que el
            # giro se aplica antes.
            imagen = ImageOps.exif_transpose(abierta)
            imagen.load()
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError) as fallo:
        raise ImagenNoValida(str(fallo)) from fallo
    imagen = imagen.convert("RGBA" if _tiene_transparencia(imagen) else "RGB")
    imagen.thumbnail((LADO_MAXIMO, LADO_MAXIMO), Image.Resampling.LANCZOS)
    datos = _webp(imagen, sin_perdida=True)
    if len(datos) > TOPE_SIN_PERDIDA:
        datos = _webp(imagen, sin_perdida=False)
    nombre = hashlib.sha256(datos).hexdigest()[:32] + ".webp"
    return Preparada(nombre, datos, imagen.width, imagen.height)


def _tiene_transparencia(imagen: Image.Image) -> bool:
    return imagen.mode in ("RGBA", "LA", "PA") or (imagen.mode == "P" and "transparency" in imagen.info)


def _webp(imagen: Image.Image, *, sin_perdida: bool) -> bytes:
    salida = io.BytesIO()
    # SIN exif NI icc: Pillow no los copia si no se le pasan, y no se pasan.
    imagen.save(salida, "WEBP", lossless=sin_perdida, quality=CALIDAD if not sin_perdida else 80, method=4)
    return salida.getvalue()


# ------------------------------------------------------------ la carpeta


def carpeta(base: Path | None = None) -> Path:
    """Dónde viven. No la crea."""
    return (base or rutas.carpeta_datos()) / CARPETA


def guardar(preparada: Preparada, base: Path | None = None) -> Path:
    """La escribe si no estaba (el nombre es su contenido: si está, es igual).

    SE ESCRIBE APARTE Y SE RENOMBRA: si Focus se cierra a mitad, no queda un
    archivo cortado con el nombre bueno, que después parecería estar.
    """
    _exigir_nombre(preparada.nombre)
    destino = carpeta(base) / preparada.nombre
    if not destino.exists():
        destino.parent.mkdir(parents=True, exist_ok=True)
        provisorio = destino.with_suffix(".parcial")
        provisorio.write_bytes(preparada.datos)
        provisorio.replace(destino)
    return destino


def guardar_bajada(nombre: str, datos: bytes, base: Path | None = None) -> Path:
    """La que bajó de la nube. SE COMPRUEBA QUE SEA LA QUE DICE SER: el nombre
    es la huella del contenido, así que una cortada o cambiada no pasa."""
    _exigir_nombre(nombre)
    if hashlib.sha256(datos).hexdigest()[:32] + ".webp" != nombre:
        raise ImagenNoValida("lo que bajó no coincide con su nombre")
    return guardar(Preparada(nombre, datos, 0, 0), base)


def leer(nombre: str, base: Path | None = None) -> bytes:
    _exigir_nombre(nombre)
    return (carpeta(base) / nombre).read_bytes()


def hay(nombre: str, base: Path | None = None) -> bool:
    return bool(NOMBRE.match(nombre)) and (carpeta(base) / nombre).is_file()


def _exigir_nombre(nombre: str) -> None:
    if not NOMBRE.match(nombre or ""):
        raise ImagenNoValida(f"nombre de imagen que no es de Focus: {nombre!r}")


def nombres_en(documento: dict | None) -> list[str]:
    """Las imágenes que usa un documento, sin repetir y en orden."""
    vistos: dict[str, None] = {}
    for elemento in (documento or {}).get("elementos") or []:
        if isinstance(elemento, dict) and elemento.get("tipo") == "imagen":
            nombre = elemento.get("archivo")
            if isinstance(nombre, str) and NOMBRE.match(nombre):
                vistos[nombre] = None
    return list(vistos)


# ------------------------------------------------------------ lo que falta subir


def por_subir(conexion: sqlite3.Connection) -> list[str]:
    """Las guardadas aquí que todavía no llegaron a la nube (sin internet, o
    sin cuenta cuando se pegaron)."""
    try:
        lista = json.loads(ajustes.leer(conexion, ajustes.CLAVE_PIZARRA_POR_SUBIR) or "[]")
    except ValueError:
        return []
    return [n for n in lista if isinstance(n, str) and NOMBRE.match(n)] if isinstance(lista, list) else []


def anotar_por_subir(conexion: sqlite3.Connection, nombre: str) -> None:
    _exigir_nombre(nombre)
    lista = por_subir(conexion)
    if nombre not in lista:
        ajustes.escribir(conexion, ajustes.CLAVE_PIZARRA_POR_SUBIR, json.dumps([*lista, nombre]))


def quitar_por_subir(conexion: sqlite3.Connection, nombre: str) -> None:
    lista = [n for n in por_subir(conexion) if n != nombre]
    ajustes.escribir(conexion, ajustes.CLAVE_PIZARRA_POR_SUBIR, json.dumps(lista))


# ------------------------------------------------------------ al borrar la cuenta


_PARCIAL = re.compile(r"^[0-9a-f]{32}\.parcial$")
"""Una que se estaba escribiendo cuando Focus se cerró (ver guardar)."""


def borrar_todas(conexion: sqlite3.Connection, base: Path | None = None) -> int:
    """Borra las imágenes de este aparato y la lista de las que faltaba subir.
    Devuelve cuántos archivos borró.

    PARA CUANDO SE BORRA LA CUENTA. Lo pidió el usuario el 13 nov 2026: «si
    alguien borra su cuenta se borra todo lo que ella generaba». Las de la
    nube las borra el servidor (servidor/api/borrar_cuenta.py).

    SOLO LO QUE ES DE FOCUS: archivos con nombre de imagen de la pizarra. Si
    alguien dejó otra cosa en la carpeta, no se toca.

    UNA TRABADA NO FRENA A LAS DEMÁS (Windows no deja borrar un archivo
    abierto en otro programa): se siguen borrando las otras.
    """
    ajustes.escribir(conexion, ajustes.CLAVE_PIZARRA_POR_SUBIR, "[]")
    lugar = carpeta(base)
    if not lugar.is_dir():
        return 0
    borradas = 0
    for archivo in lugar.iterdir():
        if archivo.is_file() and (NOMBRE.match(archivo.name) or _PARCIAL.match(archivo.name)):
            try:
                archivo.unlink(missing_ok=True)
            except OSError:
                continue
            borradas += 1
    return borradas
