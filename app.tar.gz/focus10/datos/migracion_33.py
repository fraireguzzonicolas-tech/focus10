"""La migración 33: las tablas de Educación.

CINCO TABLAS Y NO UNA: materias, temas, metas, qué temas lleva cada meta, y los
eventos del calendario. Es la forma que pidió el usuario —materia, temas,
objetivos, planificación, sesión, progreso— y cada una guarda una cosa.

LAS SESIONES DE ESTUDIO NO TIENEN TABLA PROPIA, y es la decisión que más
simplifica todo: una sesión planificada y una sesión hecha son la MISMA fila de
`educacion_eventos`, que pasa de pendiente a hecha. Lo eligió el usuario. Con
dos tablas habría que decidir qué pasa con el plan cuando se cumple —¿se borra,
se copia, se queda?— y esa pregunta no tiene buena respuesta.

POR QUÉ SE REPITEN AQUÍ LOS DISPARADORES DE SINCRONIZACIÓN: los de la 31 se
generan desde su propia lista, y esa migración está publicada y no se edita. Una
tabla que nace después tiene que traerse los suyos, o no viajaría entre
aparatos y nadie se enteraría hasta echar de menos algo en el móvil.
"""

from __future__ import annotations

AHORA = "strftime('%Y-%m-%dT%H:%M:%fZ', 'now')"
AL_AZAR = "lower(hex(randomblob(16)))"
EN_SILENCIO = "(SELECT COUNT(*) FROM sinc_silencio) = 0"

VIAJAN_33 = (
    "educacion_materias",
    "educacion_temas",
    "educacion_metas",
    "educacion_meta_temas",
    "educacion_eventos",
)
"""Las tablas nuevas que viajan. Se suman a las de la 31 en sincronia.py."""

NATURALES_33: dict[str, str] = {
    # DOS APARATOS QUE CREAN "Matemáticas" SIN INTERNET ESTÁN HABLANDO DE LA
    # MISMA MATERIA. Con un nombre al azar acabarías con dos Matemáticas y los
    # temas repartidos entre ellas. Es lo mismo que ya hacen las categorías.
    "educacion_materias": "'emat:' || lower({f}nombre)",
    "educacion_temas": (
        "'etem:' || (SELECT uid FROM educacion_materias WHERE id = {f}materia_id)"
        " || ':' || lower({f}nombre)"
    ),
    # Que una meta lleve un tema es un hecho, no una fila con vida propia: si
    # los dos aparatos lo marcan, es el mismo.
    "educacion_meta_temas": (
        "'emt:' || (SELECT uid FROM educacion_metas WHERE id = {f}meta_id)"
        " || ':' || (SELECT uid FROM educacion_temas WHERE id = {f}tema_id)"
    ),
}


def _nombre(tabla: str, fila: str) -> str:
    plantilla = NATURALES_33.get(tabla)
    return AL_AZAR if plantilla is None else plantilla.format(f=fila)


def _disparadores(tabla: str) -> tuple[str, ...]:
    """Los tres de siempre: apuntar el alta, el cambio y la baja.

    Son los mismos que crea la migración 31 para sus tablas. Ver su cabecera
    para el porqué de cada uno; aquí solo cambia de qué tabla cuelgan.
    """
    return (
        f"""
        CREATE TRIGGER {tabla}_sinc_alta AFTER INSERT ON {tabla}
        WHEN {EN_SILENCIO}
        BEGIN
            UPDATE {tabla}
               SET uid = COALESCE(NEW.uid, {_nombre(tabla, 'NEW.')}),
                   cambiado_en = {AHORA}
             WHERE rowid = NEW.rowid;
            INSERT INTO sinc_pendientes (tabla, uid)
                 SELECT '{tabla}', uid FROM {tabla} WHERE rowid = NEW.rowid
            ON CONFLICT (tabla, uid) DO UPDATE SET vez = vez + 1;
        END
        """,
        f"""
        CREATE TRIGGER {tabla}_sinc_cambio AFTER UPDATE ON {tabla}
        WHEN OLD.uid IS NOT NULL AND {EN_SILENCIO}
        BEGIN
            UPDATE {tabla} SET cambiado_en = {AHORA} WHERE rowid = NEW.rowid;
            INSERT INTO sinc_pendientes (tabla, uid) VALUES ('{tabla}', NEW.uid)
            ON CONFLICT (tabla, uid) DO UPDATE SET vez = vez + 1;
        END
        """,
        f"""
        CREATE TRIGGER {tabla}_sinc_baja AFTER DELETE ON {tabla}
        WHEN OLD.uid IS NOT NULL AND {EN_SILENCIO}
        BEGIN
            INSERT INTO sinc_pendientes (tabla, uid) VALUES ('{tabla}', OLD.uid)
            ON CONFLICT (tabla, uid) DO UPDATE SET vez = vez + 1;
        END
        """,
    )


TABLAS = (
    """
    CREATE TABLE educacion_materias (
        id INTEGER PRIMARY KEY,
        nombre TEXT NOT NULL,
        color TEXT NOT NULL,
        orden INTEGER NOT NULL DEFAULT 0,
        uid TEXT,
        cambiado_en TEXT,
        CHECK (length(trim(nombre)) > 0),
        CHECK (orden >= 0)
    ) STRICT
    """,
    # SIN DOS MATERIAS CON EL MISMO NOMBRE: son la misma, y tenerlas dos veces
    # partiría los temas y el progreso en dos mitades que no dicen nada.
    "CREATE UNIQUE INDEX educacion_materias_sin_repetir "
    "ON educacion_materias (lower(nombre))",
    """
    CREATE TABLE educacion_temas (
        id INTEGER PRIMARY KEY,
        materia_id INTEGER NOT NULL
            REFERENCES educacion_materias (id) ON DELETE CASCADE,
        nombre TEXT NOT NULL,
        descripcion TEXT NOT NULL DEFAULT '',
        dominio INTEGER NOT NULL DEFAULT 0,
        notas TEXT NOT NULL DEFAULT '',
        creado_en TEXT NOT NULL,
        uid TEXT,
        cambiado_en TEXT,
        CHECK (length(trim(nombre)) > 0),
        CHECK (dominio >= 0 AND dominio <= 100 AND dominio % 25 = 0)
    ) STRICT
    """,
    "CREATE UNIQUE INDEX educacion_temas_sin_repetir "
    "ON educacion_temas (materia_id, lower(nombre))",
    """
    CREATE TABLE educacion_metas (
        id INTEGER PRIMARY KEY,
        nombre TEXT NOT NULL,
        descripcion TEXT NOT NULL DEFAULT '',
        materia_id INTEGER
            REFERENCES educacion_materias (id) ON DELETE SET NULL,
        fecha_limite TEXT,
        prioridad TEXT NOT NULL DEFAULT 'media',
        cumplida_en TEXT,
        orden INTEGER NOT NULL DEFAULT 0,
        uid TEXT,
        cambiado_en TEXT,
        CHECK (length(trim(nombre)) > 0),
        CHECK (prioridad IN ('alta', 'media', 'baja')),
        CHECK (fecha_limite IS NULL
               OR fecha_limite GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
        CHECK (cumplida_en IS NULL
               OR cumplida_en GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
        CHECK (orden >= 0)
    ) STRICT
    """,
    """
    CREATE TABLE educacion_meta_temas (
        id INTEGER PRIMARY KEY,
        meta_id INTEGER NOT NULL
            REFERENCES educacion_metas (id) ON DELETE CASCADE,
        tema_id INTEGER NOT NULL
            REFERENCES educacion_temas (id) ON DELETE CASCADE,
        uid TEXT,
        cambiado_en TEXT
    ) STRICT
    """,
    "CREATE UNIQUE INDEX educacion_meta_temas_sin_repetir "
    "ON educacion_meta_temas (meta_id, tema_id)",
    """
    CREATE TABLE educacion_eventos (
        id INTEGER PRIMARY KEY,
        tipo TEXT NOT NULL,
        titulo TEXT NOT NULL DEFAULT '',
        fecha TEXT NOT NULL,
        hora TEXT,
        minutos INTEGER,
        materia_id INTEGER
            REFERENCES educacion_materias (id) ON DELETE SET NULL,
        tema_id INTEGER
            REFERENCES educacion_temas (id) ON DELETE SET NULL,
        notas TEXT NOT NULL DEFAULT '',
        prioridad TEXT NOT NULL DEFAULT 'media',
        hecho_en TEXT,
        minutos_reales INTEGER,
        dificultad TEXT,
        uid TEXT,
        cambiado_en TEXT,
        CHECK (tipo IN ('sesion', 'tarea', 'examen', 'trabajo', 'importante', 'otro')),
        CHECK (fecha GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
        CHECK (hora IS NULL OR hora GLOB '[0-2][0-9]:[0-5][0-9]'),
        CHECK (minutos IS NULL OR (minutos > 0 AND minutos <= 1440)),
        CHECK (minutos_reales IS NULL
               OR (minutos_reales > 0 AND minutos_reales <= 1440)),
        CHECK (prioridad IN ('alta', 'media', 'baja')),
        CHECK (dificultad IS NULL
               OR dificultad IN ('facil', 'normal', 'dificil')),
        CHECK (hecho_en IS NULL
               OR hecho_en GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]')
    ) STRICT
    """,
    # Lo que más se pregunta: qué hay hoy, y qué hay esta semana.
    "CREATE INDEX educacion_eventos_por_fecha ON educacion_eventos (fecha)",
)


def sentencias() -> tuple[str, ...]:
    """Las tablas, y después los disparadores de cada una."""
    disparadores: tuple[str, ...] = ()
    for tabla in VIAJAN_33:
        disparadores += _disparadores(tabla)
    return TABLAS + disparadores
