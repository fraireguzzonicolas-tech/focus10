"""Leer la memoria de gastos: los de las categorías que se recuerdan.

Las reglas (qué se parece a qué, cómo se avisa) están en dominio/memoria_gastos.py.
Aquí solo está la consulta.
"""

from __future__ import annotations

import sqlite3

from ..dominio.categoria import Memoria
from ..dominio.memoria_gastos import Recordado
from ..dominio.moneda import por_codigo
from ..dominio.movimiento import Tipo
from .fechas import dia_desde_texto


def recordados(conexion: sqlite3.Connection) -> list[Recordado]:
    """Todos los gastos de las categorías marcadas «Sí, recordar cada gasto».

    SIN LÍMITE DE TIEMPO: el usuario quiere que se recuerden «incluso meses
    después», y lo que acota la memoria es qué categorías la tienen, no la
    fecha. Los más nuevos primero.

    SOLO GASTOS: un ingreso que cae por error en una categoría así no es un
    pago, y avisar de «ya le pagaste a Jorge» por un cobro sería falso.
    """
    filas = conexion.execute(
        """
        SELECT m.importe, m.moneda, m.descripcion, m.jornada, c.nombre AS categoria
          FROM movimientos m
          JOIN categorias c ON c.id = m.categoria_id
         WHERE c.memoria = ? AND m.tipo = ?
         ORDER BY m.momento DESC, m.id DESC
        """,
        (Memoria.SI.value, Tipo.GASTO.value),
    ).fetchall()
    return [
        Recordado(
            importe=fila["importe"],
            moneda=por_codigo(fila["moneda"]),
            descripcion=fila["descripcion"],
            categoria=fila["categoria"],
            jornada=dia_desde_texto(fila["jornada"]),
        )
        for fila in filas
    ]
