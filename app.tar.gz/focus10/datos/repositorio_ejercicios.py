"""Guardar y leer la biblioteca de ejercicios.

BORRAR UN EJERCICIO NO TOCA EL HISTORIAL, y es lo más importante de este archivo.
Las sesiones guardan el NOMBRE del ejercicio además de su referencia, así que un
entreno de hace dos años se sigue leyendo aunque hoy limpies la biblioteca.
Perder dos años de registro por ordenar una lista sería mucho peor que tener el
mismo nombre escrito en dos sitios.
"""

from __future__ import annotations

import sqlite3

from ..dominio.ejercicio import Ejercicio, Grupo, Material, Medida, filtrar, ordenar


class EjercicioNoExiste(LookupError):
    """Se pidió tocar un ejercicio que no está."""


def listar(conexion: sqlite3.Connection) -> list[Ejercicio]:
    filas = conexion.execute("SELECT * FROM ejercicios").fetchall()
    return ordenar([_desde_fila(fila) for fila in filas])


def buscar(
    conexion: sqlite3.Connection, *, texto: str = "", grupo: Grupo | None = None
) -> list[Ejercicio]:
    """El buscador de la pantalla.

    El filtro se hace EN PYTHON y no en SQL a propósito: la biblioteca son unas
    decenas de ejercicios, caben de sobra en memoria, y el "sin acentos" del
    dominio no se puede escribir en SQLite sin extensiones. Vale más un buscador
    que encuentre "triceps" que una consulta elegante.
    """
    return filtrar(listar(conexion), texto=texto, grupo=grupo)


def obtener(conexion: sqlite3.Connection, id_ejercicio: int) -> Ejercicio | None:
    fila = conexion.execute(
        "SELECT * FROM ejercicios WHERE id = ?", (id_ejercicio,)
    ).fetchone()
    return _desde_fila(fila) if fila else None


def crear(conexion: sqlite3.Connection, ejercicio: Ejercicio) -> Ejercicio:
    cursor = conexion.execute(
        "INSERT INTO ejercicios (nombre, grupo, material, secundarios, descanso, "
        "notas, medida) VALUES (?, ?, ?, ?, ?, ?, ?)",
        _a_fila(ejercicio),
    )
    return obtener(conexion, cursor.lastrowid)


def actualizar(conexion: sqlite3.Connection, ejercicio: Ejercicio) -> Ejercicio:
    if ejercicio.id is None:
        raise ValueError("para corregir hace falta el id del ejercicio")
    _exigir(conexion, ejercicio.id)
    conexion.execute(
        "UPDATE ejercicios SET nombre = ?, grupo = ?, material = ?, "
        "secundarios = ?, descanso = ?, notas = ?, medida = ? WHERE id = ?",
        (*_a_fila(ejercicio), ejercicio.id),
    )
    return obtener(conexion, ejercicio.id)


def borrar(conexion: sqlite3.Connection, id_ejercicio: int) -> None:
    """Quita el ejercicio de la biblioteca. NO toca ninguna sesión.

    Las series ya registradas guardan el nombre, así que el historial se sigue
    leyendo. Lo único que se pierde es poder volver a elegirlo para una rutina
    nueva, que es exactamente lo que se ha pedido al borrarlo.
    """
    _exigir(conexion, id_ejercicio)
    # PRIMERO se dejan huérfanas las filas del historial y del plan, y DESPUÉS se
    # borra la ficha. En este orden: al revés, entre las dos operaciones habría
    # un instante con filas apuntando a un ejercicio que ya no está.
    from .repositorio_gimnasio import olvidar_ejercicio

    olvidar_ejercicio(conexion, id_ejercicio)
    conexion.execute("DELETE FROM ejercicios WHERE id = ?", (id_ejercicio,))


def cuantos(conexion: sqlite3.Connection) -> int:
    return int(conexion.execute("SELECT COUNT(*) AS n FROM ejercicios").fetchone()["n"])


# ---------------------------------------------------------------------------


def _a_fila(ejercicio: Ejercicio) -> tuple:
    return (
        ejercicio.nombre,
        ejercicio.grupo.value,
        ejercicio.material.value,
        ",".join(sorted(uno.value for uno in ejercicio.secundarios)),
        ejercicio.descanso,
        ejercicio.notas,
        ejercicio.medida.value,
    )


def _desde_fila(fila: sqlite3.Row) -> Ejercicio:
    secundarios = frozenset(
        Grupo(trozo) for trozo in (fila["secundarios"] or "").split(",") if trozo
    )
    return Ejercicio(
        id=int(fila["id"]),
        nombre=fila["nombre"],
        grupo=Grupo(fila["grupo"]),
        material=Material(fila["material"]),
        secundarios=secundarios,
        descanso=int(fila["descanso"]),
        notas=fila["notas"],
        medida=Medida(fila["medida"]),
    )


def _exigir(conexion: sqlite3.Connection, id_ejercicio: int) -> Ejercicio:
    ejercicio = obtener(conexion, id_ejercicio)
    if ejercicio is None:
        raise EjercicioNoExiste(f"no hay ningún ejercicio con id {id_ejercicio}")
    return ejercicio
