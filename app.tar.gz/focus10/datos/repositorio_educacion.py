"""Guardar y leer lo de Educación: materias, temas, metas y eventos.

AQUÍ NO SE CALCULA NI EL PROGRESO NI LOS ESTADOS. El dominio de un tema se
guarda; que eso signifique "completado" lo decide dominio/educacion.py, y las
sumas por materia también. Lo que no se guarda no se puede desincronizar.

BORRAR UNA MATERIA SE LLEVA SUS TEMAS (lo dice la base con ON DELETE CASCADE),
pero NO sus eventos: la sesión del martes pasado ocurrió, y borrar la materia
hoy no la borra de tu semana. El evento se queda sin materia y la pantalla lo
enseña igual.
"""

from __future__ import annotations

import sqlite3
from datetime import date

from ..dominio.educacion import (
    Dificultad,
    Evento,
    Materia,
    Meta,
    Prioridad,
    Tema,
    TipoEvento,
)
from .fechas import dia_a_texto, dia_desde_texto


class NoExiste(LookupError):
    """Se pidió tocar algo de Educación que no está."""


# ---------------------------------------------------------------------------
# Materias
# ---------------------------------------------------------------------------


def listar_materias(conexion: sqlite3.Connection) -> list[Materia]:
    filas = conexion.execute(
        "SELECT * FROM educacion_materias ORDER BY orden, nombre"
    ).fetchall()
    return [_materia(fila) for fila in filas]


def obtener_materia(conexion: sqlite3.Connection, id_materia: int) -> Materia | None:
    fila = conexion.execute(
        "SELECT * FROM educacion_materias WHERE id = ?", (id_materia,)
    ).fetchone()
    return _materia(fila) if fila else None


def crear_materia(conexion: sqlite3.Connection, materia: Materia) -> Materia:
    cursor = conexion.execute(
        "INSERT INTO educacion_materias (nombre, color, orden) VALUES (?, ?, ?)",
        (materia.nombre, materia.color, materia.orden or _siguiente_orden(
            conexion, "educacion_materias")),
    )
    return obtener_materia(conexion, cursor.lastrowid)


def materia_por_nombre(
    conexion: sqlite3.Connection, nombre: str, color: str = "azul"
) -> Materia:
    """La materia que se llama así, y si no existe se crea.

    LAS MATERIAS YA NO TIENEN PANTALLA PROPIA, y lo pidió el usuario: nacen
    cuando escribes su nombre al planificar o al crear un objetivo. Se busca sin
    mirar mayúsculas para que "aleman" y "Aleman" no sean dos.
    """
    fila = conexion.execute(
        "SELECT * FROM educacion_materias WHERE lower(nombre) = lower(?)",
        (nombre.strip(),),
    ).fetchone()
    if fila is not None:
        return _materia(fila)
    return crear_materia(conexion, Materia(nombre=nombre, color=color))


def limpiar_materias_sueltas(conexion: sqlite3.Connection) -> int:
    """Borra las materias que ya no tiene nada colgando, y dice cuántas.

    SE BARREN SOLAS PORQUE NACEN SOLAS: si escribiste "Aleman" por error y
    luego borraste ese objetivo, sin esto la materia se quedaría para siempre
    en los desplegables y en el progreso, al 0 %, sin forma de quitarla.
    """
    cursor = conexion.execute(
        """
        DELETE FROM educacion_materias
         WHERE id NOT IN (SELECT materia_id FROM educacion_temas)
           AND id NOT IN (
               SELECT materia_id FROM educacion_eventos WHERE materia_id IS NOT NULL
           )
           AND id NOT IN (
               SELECT materia_id FROM educacion_metas WHERE materia_id IS NOT NULL
           )
        """
    )
    return cursor.rowcount


# ---------------------------------------------------------------------------
# Temas
# ---------------------------------------------------------------------------


def listar_temas(
    conexion: sqlite3.Connection, materia_id: int | None = None
) -> list[Tema]:
    if materia_id is None:
        filas = conexion.execute(
            "SELECT * FROM educacion_temas ORDER BY materia_id, nombre"
        ).fetchall()
    else:
        filas = conexion.execute(
            "SELECT * FROM educacion_temas WHERE materia_id = ? ORDER BY nombre",
            (materia_id,),
        ).fetchall()
    return [_tema(fila) for fila in filas]


def obtener_tema(conexion: sqlite3.Connection, id_tema: int) -> Tema | None:
    fila = conexion.execute(
        "SELECT * FROM educacion_temas WHERE id = ?", (id_tema,)
    ).fetchone()
    return _tema(fila) if fila else None


def crear_tema(conexion: sqlite3.Connection, tema: Tema, hoy: date) -> Tema:
    cursor = conexion.execute(
        """
        INSERT INTO educacion_temas
            (materia_id, nombre, descripcion, dominio, notas, creado_en)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            tema.materia_id,
            tema.nombre,
            tema.descripcion,
            tema.dominio,
            tema.notas,
            dia_a_texto(tema.creado_en or hoy),
        ),
    )
    return obtener_tema(conexion, cursor.lastrowid)


def actualizar_tema(conexion: sqlite3.Connection, tema: Tema) -> Tema:
    if tema.id is None:
        raise ValueError("para corregir hace falta el id del tema")
    anterior = _exigir(conexion, "educacion_temas", tema.id)
    conexion.execute(
        """
        UPDATE educacion_temas SET materia_id = ?, nombre = ?, descripcion = ?,
            dominio = ?, notas = ?
         WHERE id = ?
        """,
        (
            tema.materia_id,
            tema.nombre,
            tema.descripcion,
            tema.dominio,
            tema.notas,
            tema.id,
        ),
    )
    del anterior
    return obtener_tema(conexion, tema.id)


def cambiar_dominio(conexion: sqlite3.Connection, id_tema: int, dominio: int) -> Tema:
    """Sube o baja el dominio. Se valida creando el Tema: las reglas están ahí."""
    tema = obtener_tema(conexion, id_tema)
    if tema is None:
        raise NoExiste(f"no hay ningún tema con id {id_tema}")
    from dataclasses import replace

    return actualizar_tema(conexion, replace(tema, dominio=dominio))


def borrar_tema(conexion: sqlite3.Connection, id_tema: int) -> None:
    _exigir(conexion, "educacion_temas", id_tema)
    conexion.execute("DELETE FROM educacion_temas WHERE id = ?", (id_tema,))


# ---------------------------------------------------------------------------
# Metas
# ---------------------------------------------------------------------------


def listar_metas(conexion: sqlite3.Connection) -> list[Meta]:
    filas = conexion.execute(
        "SELECT * FROM educacion_metas ORDER BY orden, nombre"
    ).fetchall()
    return [_meta(fila) for fila in filas]


def obtener_meta(conexion: sqlite3.Connection, id_meta: int) -> Meta | None:
    fila = conexion.execute(
        "SELECT * FROM educacion_metas WHERE id = ?", (id_meta,)
    ).fetchone()
    return _meta(fila) if fila else None


def crear_meta(conexion: sqlite3.Connection, meta: Meta) -> Meta:
    cursor = conexion.execute(
        """
        INSERT INTO educacion_metas
            (nombre, descripcion, materia_id, fecha_limite, prioridad,
             cumplida_en, orden)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            meta.nombre,
            meta.descripcion,
            meta.materia_id,
            _dia(meta.fecha_limite),
            meta.prioridad.value,
            _dia(meta.cumplida_en),
            meta.orden or _siguiente_orden(conexion, "educacion_metas"),
        ),
    )
    return obtener_meta(conexion, cursor.lastrowid)


def actualizar_meta(conexion: sqlite3.Connection, meta: Meta) -> Meta:
    if meta.id is None:
        raise ValueError("para corregir hace falta el id de la meta")
    _exigir(conexion, "educacion_metas", meta.id)
    conexion.execute(
        """
        UPDATE educacion_metas SET nombre = ?, descripcion = ?, materia_id = ?,
            fecha_limite = ?, prioridad = ?, cumplida_en = ?, orden = ?
         WHERE id = ?
        """,
        (
            meta.nombre,
            meta.descripcion,
            meta.materia_id,
            _dia(meta.fecha_limite),
            meta.prioridad.value,
            _dia(meta.cumplida_en),
            meta.orden,
            meta.id,
        ),
    )
    return obtener_meta(conexion, meta.id)


def borrar_meta(conexion: sqlite3.Connection, id_meta: int) -> None:
    _exigir(conexion, "educacion_metas", id_meta)
    conexion.execute("DELETE FROM educacion_metas WHERE id = ?", (id_meta,))


def temas_de_meta(conexion: sqlite3.Connection, id_meta: int) -> list[Tema]:
    filas = conexion.execute(
        """
        SELECT t.* FROM educacion_temas t
          JOIN educacion_meta_temas mt ON mt.tema_id = t.id
         WHERE mt.meta_id = ?
         ORDER BY t.nombre
        """,
        (id_meta,),
    ).fetchall()
    return [_tema(fila) for fila in filas]


def poner_temas_de_meta(
    conexion: sqlite3.Connection, id_meta: int, ids_temas: list[int]
) -> None:
    """Deja la meta con exactamente esos temas.

    SE BORRA SOLO LO QUE SOBRA Y SE AÑADE LO QUE FALTA, en vez de borrar todo y
    volver a escribirlo: borrar y recrear haría viajar como cambio cada tema que
    ya estaba, y en el otro aparato parecería que tocaste la meta entera.
    """
    _exigir(conexion, "educacion_metas", id_meta)
    ahora = {
        int(fila["tema_id"])
        for fila in conexion.execute(
            "SELECT tema_id FROM educacion_meta_temas WHERE meta_id = ?", (id_meta,)
        )
    }
    quiero = set(ids_temas)
    for sobra in ahora - quiero:
        conexion.execute(
            "DELETE FROM educacion_meta_temas WHERE meta_id = ? AND tema_id = ?",
            (id_meta, sobra),
        )
    for falta in quiero - ahora:
        conexion.execute(
            "INSERT INTO educacion_meta_temas (meta_id, tema_id) VALUES (?, ?)",
            (id_meta, falta),
        )


# ---------------------------------------------------------------------------
# Eventos del calendario (incluidas las sesiones)
# ---------------------------------------------------------------------------


def listar_eventos(
    conexion: sqlite3.Connection,
    desde: date | None = None,
    hasta: date | None = None,
) -> list[Evento]:
    """Los eventos del tramo, las dos puntas incluidas. Sin tramo, todos."""
    if desde is None or hasta is None:
        filas = conexion.execute(
            "SELECT * FROM educacion_eventos ORDER BY fecha, hora, id"
        ).fetchall()
    else:
        filas = conexion.execute(
            """
            SELECT * FROM educacion_eventos
             WHERE fecha BETWEEN ? AND ?
             ORDER BY fecha, hora, id
            """,
            (dia_a_texto(desde), dia_a_texto(hasta)),
        ).fetchall()
    return [_evento(fila) for fila in filas]


def obtener_evento(conexion: sqlite3.Connection, id_evento: int) -> Evento | None:
    fila = conexion.execute(
        "SELECT * FROM educacion_eventos WHERE id = ?", (id_evento,)
    ).fetchone()
    return _evento(fila) if fila else None


def crear_evento(conexion: sqlite3.Connection, evento: Evento) -> Evento:
    cursor = conexion.execute(
        """
        INSERT INTO educacion_eventos
            (tipo, titulo, fecha, hora, minutos, materia_id, tema_id, notas,
             prioridad, hecho_en, minutos_reales, dificultad)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        _fila_de_evento(evento),
    )
    return obtener_evento(conexion, cursor.lastrowid)


def actualizar_evento(conexion: sqlite3.Connection, evento: Evento) -> Evento:
    if evento.id is None:
        raise ValueError("para corregir hace falta el id del evento")
    _exigir(conexion, "educacion_eventos", evento.id)
    conexion.execute(
        """
        UPDATE educacion_eventos SET tipo = ?, titulo = ?, fecha = ?, hora = ?,
            minutos = ?, materia_id = ?, tema_id = ?, notas = ?, prioridad = ?,
            hecho_en = ?, minutos_reales = ?, dificultad = ?
         WHERE id = ?
        """,
        (*_fila_de_evento(evento), evento.id),
    )
    return obtener_evento(conexion, evento.id)


def borrar_evento(conexion: sqlite3.Connection, id_evento: int) -> None:
    _exigir(conexion, "educacion_eventos", id_evento)
    conexion.execute("DELETE FROM educacion_eventos WHERE id = ?", (id_evento,))


def marcar_hecho(
    conexion: sqlite3.Connection,
    id_evento: int,
    hoy: date,
    minutos_reales: int | None = None,
    dificultad: Dificultad | None = None,
) -> Evento:
    """Lo planeado pasa a hecho, en la misma fila.

    LOS MINUTOS REALES MANDAN SOBRE LOS PLANEADOS y no los borran: si planeaste
    45 y estudiaste 20, se guardan los dos. Así el progreso cuenta lo que
    hiciste y sigues viendo lo que te habías propuesto.
    """
    from dataclasses import replace

    evento = obtener_evento(conexion, id_evento)
    if evento is None:
        raise NoExiste(f"no hay ningún evento con id {id_evento}")
    return actualizar_evento(
        conexion,
        replace(
            evento,
            hecho_en=hoy,
            minutos_reales=minutos_reales or evento.minutos_reales,
            dificultad=dificultad or evento.dificultad,
        ),
    )


def desmarcar(conexion: sqlite3.Connection, id_evento: int) -> Evento:
    """Vuelve a pendiente. Se olvidan los minutos reales y cómo fue: eran de
    una sesión que resulta que no pasó."""
    from dataclasses import replace

    evento = obtener_evento(conexion, id_evento)
    if evento is None:
        raise NoExiste(f"no hay ningún evento con id {id_evento}")
    return actualizar_evento(
        conexion,
        replace(evento, hecho_en=None, minutos_reales=None, dificultad=None),
    )


# ---------------------------------------------------------------------------


def _siguiente_orden(conexion: sqlite3.Connection, tabla: str) -> int:
    fila = conexion.execute(
        f"SELECT COALESCE(MAX(orden), 0) + 1 AS siguiente FROM {tabla}"
    ).fetchone()
    return int(fila["siguiente"])


def _dia(valor: date | None) -> str | None:
    return dia_a_texto(valor) if valor else None


def _fila_de_evento(evento: Evento) -> tuple:
    return (
        evento.tipo.value,
        evento.titulo,
        dia_a_texto(evento.fecha),
        evento.hora or None,
        evento.minutos,
        evento.materia_id,
        evento.tema_id,
        evento.notas,
        evento.prioridad.value,
        _dia(evento.hecho_en),
        evento.minutos_reales,
        evento.dificultad.value if evento.dificultad else None,
    )


def _materia(fila: sqlite3.Row) -> Materia:
    return Materia(
        id=int(fila["id"]),
        nombre=fila["nombre"],
        color=fila["color"],
        orden=int(fila["orden"]),
    )


def _tema(fila: sqlite3.Row) -> Tema:
    return Tema(
        id=int(fila["id"]),
        materia_id=int(fila["materia_id"]),
        nombre=fila["nombre"],
        descripcion=fila["descripcion"],
        dominio=int(fila["dominio"]),
        notas=fila["notas"],
        creado_en=dia_desde_texto(fila["creado_en"]),
    )


def _meta(fila: sqlite3.Row) -> Meta:
    return Meta(
        id=int(fila["id"]),
        nombre=fila["nombre"],
        descripcion=fila["descripcion"],
        materia_id=int(fila["materia_id"]) if fila["materia_id"] else None,
        fecha_limite=dia_desde_texto(fila["fecha_limite"])
        if fila["fecha_limite"]
        else None,
        prioridad=Prioridad(fila["prioridad"]),
        cumplida_en=dia_desde_texto(fila["cumplida_en"])
        if fila["cumplida_en"]
        else None,
        orden=int(fila["orden"]),
    )


def _evento(fila: sqlite3.Row) -> Evento:
    return Evento(
        id=int(fila["id"]),
        tipo=TipoEvento(fila["tipo"]),
        titulo=fila["titulo"],
        fecha=dia_desde_texto(fila["fecha"]),
        hora=fila["hora"] or "",
        minutos=int(fila["minutos"]) if fila["minutos"] else None,
        materia_id=int(fila["materia_id"]) if fila["materia_id"] else None,
        tema_id=int(fila["tema_id"]) if fila["tema_id"] else None,
        notas=fila["notas"],
        prioridad=Prioridad(fila["prioridad"]),
        hecho_en=dia_desde_texto(fila["hecho_en"]) if fila["hecho_en"] else None,
        minutos_reales=int(fila["minutos_reales"]) if fila["minutos_reales"] else None,
        dificultad=Dificultad(fila["dificultad"]) if fila["dificultad"] else None,
    )


def _exigir(conexion: sqlite3.Connection, tabla: str, id_fila: int) -> sqlite3.Row:
    fila = conexion.execute(
        f"SELECT * FROM {tabla} WHERE id = ?", (id_fila,)
    ).fetchone()
    if fila is None:
        raise NoExiste(f"no hay ninguna fila con id {id_fila} en {tabla}")
    return fila
