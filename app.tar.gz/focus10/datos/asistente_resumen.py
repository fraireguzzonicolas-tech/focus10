"""Lo que el asistente sabe de tu cuenta para CONTESTAR preguntas.

«¿Cuánta proteína llevo hoy?», «¿cuánto ahorré este mes?», «¿cuántos días
entrené esta semana?»: los números se los da Focus YA CALCULADOS, con las
mismas funciones que las pantallas (Finanzas, Alimentación, Hábitos…). Claude
solo los lee. Es la misma idea que los totales de la memoria de gastos: un
modelo sumando treinta importes se puede equivocar; leyendo uno, no.

SOLO LO DE HOY, ESTA SEMANA Y ESTE MES, y en pocas líneas: es lo que se
pregunta, y cada línea de más se paga en cada mensaje.

LO QUE NO SE PUDO CONTAR SE DICE: un gasto en dólares sin convertir no entra
en el total en euros, y el resumen lo avisa en vez de callarlo.
"""

from __future__ import annotations

import sqlite3
from datetime import date, timedelta

from ..dominio import dinero, resumen
from ..dominio.guardado import ahorrado
from ..dominio.movimiento import CUENTAN_COMO_GASTO, CUENTAN_COMO_INGRESO, Tipo
from . import ajustes, repositorio_alimentacion, repositorio_categorias, repositorio_gimnasio
from . import repositorio_habitos, repositorio_movimientos, repositorio_tareas

MAXIMO_CATEGORIAS = 12
MAXIMO_TAREAS = 10


def _g(decimas: int) -> str:
    return f"{decimas / 10:.0f} g"


def _total(total: resumen.Total) -> str:
    aviso = total.texto_aviso()
    return total.texto() + (f" ({aviso})" if aviso else "")


def _comidas(conexion, jornada: date) -> str:
    del_dia = repositorio_alimentacion.listar_del_dia(conexion, jornada)
    objetivos = repositorio_alimentacion.leer_objetivos(conexion)
    kcal = sum(r.kcal for r in del_dia)
    prot = sum(r.proteinas for r in del_dia)
    carb = sum(r.carbohidratos for r in del_dia)
    gras = sum(r.grasas for r in del_dia)

    def de(objetivo, en_gramos=False):
        if not objetivo:
            return ""
        return f" de {_g(objetivo) if en_gramos else objetivo}"

    return (
        f"COMIDA DE HOY ({len(del_dia)} apuntes): {kcal} kcal{de(objetivos.kcal)}, "
        f"proteína {_g(prot)}{de(objetivos.proteinas, True)}, "
        f"carbohidratos {_g(carb)}{de(objetivos.carbohidratos, True)}, "
        f"grasa {_g(gras)}{de(objetivos.grasas, True)}."
    )


def _dinero(conexion, hoy: date) -> str:
    principal = ajustes.leer_moneda_principal(conexion)
    primero = hoy.replace(day=1)
    del_mes = repositorio_movimientos.listar(conexion, desde=primero, hasta=hoy)
    gastos = resumen.sumar(del_mes, tipo=CUENTAN_COMO_GASTO, principal=principal)
    ingresos = resumen.sumar(del_mes, tipo=CUENTAN_COMO_INGRESO, principal=principal)
    apartado = resumen.sumar(del_mes, tipo=Tipo.AHORRO, principal=principal)
    sacado = resumen.sumar(del_mes, tipo=Tipo.RETIRADA_AHORRO, principal=principal)
    saldo = ahorrado(repositorio_movimientos.listar(conexion), principal=principal)

    nombres = {c.id: c.nombre for c in repositorio_categorias.listar(conexion, incluir_inactivas=True)}
    por_categoria: dict[int, list] = {}
    for movimiento in del_mes:
        if movimiento.tipo is Tipo.GASTO:
            por_categoria.setdefault(movimiento.categoria_id, []).append(movimiento)
    totales = sorted(
        ((nombres.get(cid, "?"), resumen.sumar(lista, principal=principal))
         for cid, lista in por_categoria.items()),
        key=lambda par: -par[1].convertido,
    )[:MAXIMO_CATEGORIAS]
    lineas = [
        f"DINERO DE ESTE MES (desde {primero.isoformat()}): gastos {_total(gastos)}, "
        f"ingresos {_total(ingresos)}, apartado al ahorro "
        f"{dinero.formatear(apartado.convertido - sacado.convertido, principal)}.",
        f"AHORRO TOTAL HOY: {dinero.formatear(saldo.total, principal)}.",
    ]
    if totales:
        lineas.append("GASTOS DEL MES POR CATEGORÍA: " + "; ".join(
            f"{nombre} {_total(total)}" for nombre, total in totales
        ))
    return "\n".join(lineas)


def _habitos(conexion, jornada: date) -> str:
    pendientes, hechos = [], []
    for habito in repositorio_habitos.listar(conexion):
        if not habito.toca_en(jornada):
            continue
        cuanto = repositorio_habitos.cantidad(conexion, habito.id, jornada)
        (hechos if habito.cumplido_con(cuanto) else pendientes).append(
            f"{habito.nombre} ({cuanto}/{habito.objetivo})"
        )
    return (
        f"HÁBITOS DE HOY — hechos: {', '.join(hechos) or 'ninguno'}; "
        f"pendientes: {', '.join(pendientes) or 'ninguno'}."
    )


def _tareas(conexion) -> str:
    pendientes = repositorio_tareas.listar_pendientes(conexion)
    if not pendientes:
        return "RECORDATORIOS PENDIENTES: ninguno."
    nombres = [f"{t.titulo} ({t.jornada.isoformat()})" for t in pendientes[:MAXIMO_TAREAS]]
    mas = f" y {len(pendientes) - MAXIMO_TAREAS} más" if len(pendientes) > MAXIMO_TAREAS else ""
    return f"RECORDATORIOS PENDIENTES: {'; '.join(nombres)}{mas}."


def _gimnasio(conexion, hoy: date) -> str:
    lunes = hoy - timedelta(days=hoy.weekday())
    semana = [s for s in repositorio_gimnasio.sesiones_entre(conexion, lunes, hoy) if s.series_hechas]
    lineas = [f"GIMNASIO: entrenaste {len(semana)} día(s) esta semana (desde {lunes.isoformat()})."]
    ultimo: dict[str, str] = {}
    for sesion in reversed(repositorio_gimnasio.sesiones_entre(conexion, hoy - timedelta(days=42), hoy)):
        for ejercicio in sesion.ejercicios:
            hechas = [s for s in ejercicio.series if s.hecha]
            if hechas and ejercicio.nombre not in ultimo:
                ultimo[ejercicio.nombre] = (
                    f"{ejercicio.nombre} {sesion.fecha.isoformat()}: "
                    + ", ".join(s.texto() for s in hechas)
                )
    if ultimo:
        lineas.append("ÚLTIMA VEZ DE CADA EJERCICIO (6 semanas): " + "; ".join(ultimo.values()))
    return "\n".join(lineas)


def resumen_para_la_ia(conexion: sqlite3.Connection, hoy: date, jornada: date) -> str:
    return "\n".join([
        _comidas(conexion, jornada),
        _dinero(conexion, hoy),
        _habitos(conexion, jornada),
        _tareas(conexion),
        _gimnasio(conexion, hoy),
    ])
