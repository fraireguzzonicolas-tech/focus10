"""La puerta de entrada a los datos: abrir la base lista para usarse.

Es el único sitio que junta las tres piezas de esta capa (ruta, conexión y
migraciones), para que quien la use no tenga que acordarse del orden.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from . import copias, migraciones, rutas
from .conexion import abrir_conexion, comprobar_sqlite


_hay_cambios = False
"""Si se ha escrito algo desde la última vez que se guardó al navegador.

POR QUÉ UN AVISO Y NO GUARDAR EN EL ACTO: en el navegador, guardar es volcar el
archivo ENTERO —unos 240 KB en una base con uso real— al almacén. Hacerlo en
cada clic sería tirar el trabajo doscientas veces por minuto para escribir lo
mismo. Con este aviso, quien guarda decide cuándo, y agrupa muchos cambios en
una sola escritura.

EN WINDOWS NO SIRVE PARA NADA y no molesta: nadie lo mira.
"""


def marcar_cambio() -> None:
    """Apunta que hay algo nuevo sin guardar en el navegador."""
    global _hay_cambios
    _hay_cambios = True


def hay_cambios() -> bool:
    """Si queda algo por volcar al almacén del navegador."""
    return _hay_cambios


def olvidar_cambios() -> None:
    """Lo llama quien acaba de guardar, y solo si le salió bien.

    SI EL GUARDADO FALLA NO SE LLAMA, y esa es toda la gracia: el aviso se queda
    puesto y el siguiente intento vuelve a guardar. Borrarlo antes de saber si
    funcionó sería perder los cambios en silencio.
    """
    global _hay_cambios
    _hay_cambios = False


def abrir_bd(ruta: Path | str | None = None) -> sqlite3.Connection:
    """Abre la base de datos, creándola y actualizándola si hace falta.

    Sin argumentos usa la ruta de verdad (%APPDATA%\\Focus10\\focus10.db). Se
    puede pasar otra ruta, y de eso viven los tests: cada uno abre la suya en
    una carpeta temporal y así ninguno puede tocar los datos reales.
    """
    comprobar_sqlite()

    if ruta is None:
        rutas.asegurar_carpeta()
        ruta = rutas.ruta_bd()
    else:
        ruta = Path(ruta)
        ruta.parent.mkdir(parents=True, exist_ok=True)

    conexion = abrir_conexion(ruta)
    try:
        # COPIA DE SEGURIDAD ANTES DE CAMBIAR LA FORMA DE LAS TABLAS.
        #
        # Lo pidió el usuario: "que no desaparezca lo ya metido". Cada migración
        # va ya en su propia transacción, así que una que falla no rompe nada;
        # contra lo que no había red es contra una que sale BIEN pero está mal
        # escrita —la 17 reconstruye la tabla de comidas entera—, porque eso
        # ninguna transacción lo detecta.
        #
        # Solo copia si hay migraciones pendientes de verdad.
        copias.antes_de_migrar(
            conexion,
            Path(ruta),
            migraciones.version_actual(conexion),
            migraciones.VERSION_OBJETIVO,
        )
        if migraciones.aplicar(conexion):
            # UNA MIGRACIÓN CAMBIA EL ARCHIVO aunque no se escriba ni una fila,
            # y `total_changes` no cuenta los CREATE TABLE. Sin esto, la primera
            # apertura en un navegador nuevo construiría las veinte tablas y no
            # las guardaría: al recargar habría que rehacerlas otra vez.
            marcar_cambio()
    except BaseException:
        # Si el esquema no se puede poner al día, devolver una conexión medio
        # migrada sería peor que no devolver nada.
        conexion.close()
        raise
    return conexion


@contextmanager
def conectado(ruta: Path | str | None = None) -> Iterator[sqlite3.Connection]:
    """Igual que abrir_bd, pero cerrando sola al terminar el bloque with."""
    conexion = abrir_bd(ruta)
    # SE CUENTAN LAS FILAS TOCADAS, no se da por hecho que hubo escritura: la
    # aplicación abre la base para LEER muchísimas más veces de las que escribe
    # —cada dibujado de pantalla la abre—, y marcar cambios en todas obligaría a
    # volcar 240 KB al almacén cada vez que miras algo.
    antes = conexion.total_changes
    try:
        yield conexion
    finally:
        if conexion.total_changes != antes:
            marcar_cambio()
        conexion.close()
