"""Abrir la base de datos con la configuración correcta, y transacciones.

Aquí no hay ninguna tabla ni ninguna consulta: solo la conexión y sus ajustes.
Las tablas las crean las migraciones.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

# Las tablas STRICT (que impiden guardar un texto donde se espera un entero)
# existen desde SQLite 3.37. Se comprueba al arrancar porque, si faltara, el
# error saldría en forma de "syntax error" incomprensible dentro de una
# migración.
VERSION_SQLITE_MINIMA = (3, 37, 0)


class SQLiteDemasiadoAntiguo(RuntimeError):
    """El SQLite que trae este Python no sirve para las tablas de Focus10."""


def comprobar_sqlite() -> None:
    if sqlite3.sqlite_version_info < VERSION_SQLITE_MINIMA:
        minima = ".".join(str(numero) for numero in VERSION_SQLITE_MINIMA)
        raise SQLiteDemasiadoAntiguo(
            f"Focus10 necesita SQLite {minima} o superior; "
            f"este Python trae la {sqlite3.sqlite_version}"
        )


def abrir_conexion(ruta: Path | str) -> sqlite3.Connection:
    """Abre la conexión y le aplica los ajustes de siempre.

    POR QUÉ isolation_level=None: por defecto, el módulo sqlite3 de Python
    abre transacciones por su cuenta antes de un INSERT, pero NO antes de un
    CREATE TABLE, y decide él cuándo confirmar. Eso convierte las migraciones
    en algo impredecible. Con isolation_level=None ese automatismo se apaga:
    cada sentencia se confirma sola, y cuando hace falta atomicidad se pide un
    BEGIN explícito con transaccion(). Menos magia y comportamiento igual en
    cualquier versión de Python.
    """
    conexion = sqlite3.connect(str(ruta), isolation_level=None)
    # Las filas se leen por nombre de columna (fila["valor"]) en vez de por
    # número: si algún día cambia el orden de un SELECT, el código no se rompe.
    conexion.row_factory = sqlite3.Row

    # foreign_keys: SQLite las ignora si no se piden expresamente, y una
    # integridad que no se comprueba no es integridad.
    conexion.execute("PRAGMA foreign_keys = ON")
    # journal_mode WAL: sobrevive mucho mejor a un cierre brusco o a un apagón,
    # y permite leer mientras se escribe. Es persistente en el archivo.
    conexion.execute("PRAGMA journal_mode = WAL")
    # synchronous NORMAL: con WAL es seguro y evita esperar al disco en cada
    # escritura.
    conexion.execute("PRAGMA synchronous = NORMAL")
    # Si otra ventana o proceso tiene la base ocupada, esperar hasta 5 segundos
    # en vez de fallar en el acto.
    conexion.execute("PRAGMA busy_timeout = 5000")
    return conexion


@contextmanager
def transaccion(conexion: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    """Agrupa varias sentencias en un todo o nada.

    Sirve para que una migración a medio aplicar no deje la base de datos en un
    estado imposible: si algo falla, se deshace entero.
    """
    conexion.execute("BEGIN")
    try:
        yield conexion
    except BaseException:
        conexion.execute("ROLLBACK")
        raise
    conexion.execute("COMMIT")
