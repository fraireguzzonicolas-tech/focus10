"""Tus medallas, sacadas de tus hábitos, y cuáles son nuevas.

NO SE GUARDAN: SE CALCULAN, igual que las rachas (ver dominio/rachas.py). Una
medalla es «tu mejor racha de este hábito llegó a tal hito», y eso sale siempre
de las marcas que ya tienes. Guardarla aparte sería una copia que habría que
acordarse de corregir cada vez que se desmarca un día.

LO ÚNICO QUE SE GUARDA ES CUÁLES YA TE ENSEÑÉ, para anunciar solo las nuevas.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import date

from ..dominio.logros import Medalla, medallas_de
from ..dominio.rachas import calcular_rachas
from . import ajustes, repositorio_habitos


def todas(conexion: sqlite3.Connection, hoy: date) -> list[Medalla]:
    """Todas las medallas ganadas, de todos los hábitos, activos o no.

    TAMBIÉN LOS HÁBITOS QUE YA NO SIGUES: la medalla de 3 meses de un hábito
    que dejaste la ganaste igual.

    EL HÁBITO SE NOMBRA POR SU `uid` (el de la sincronización) y no por su
    número local: así la medalla ganada en el móvil y en la PC es LA MISMA, y
    subirla desde los dos aparatos no la duplica.
    """
    ganadas: list[Medalla] = []
    for habito in repositorio_habitos.listar(conexion, incluir_inactivos=True):
        fila = conexion.execute(
            "SELECT uid FROM habitos WHERE id = ?", (habito.id,)
        ).fetchone()
        uid = str(fila[0]) if fila and fila[0] else f"local-{habito.id}"
        rachas = calcular_rachas(
            habito, repositorio_habitos.cantidades_de(conexion, habito.id), hoy
        )
        ganadas += medallas_de(uid, habito.nombre, rachas.mejor)
    return ganadas


def _vistas(conexion: sqlite3.Connection) -> set[str]:
    try:
        return set(json.loads(ajustes.leer(conexion, ajustes.CLAVE_MEDALLAS_VISTAS) or "[]"))
    except ValueError:
        return set()


def nuevas(conexion: sqlite3.Connection, medallas: list[Medalla]) -> list[Medalla]:
    """Las que todavía no te enseñé, de la más grande a la más chica."""
    vistas = _vistas(conexion)
    return sorted(
        (una for una in medallas if una.clave not in vistas),
        key=lambda una: -una.dias,
    )


def marcar_vistas(conexion: sqlite3.Connection, medallas: list[Medalla]) -> None:
    """Apunta que ya las enseñé, para no volver a anunciarlas."""
    vistas = _vistas(conexion) | {una.clave for una in medallas}
    ajustes.escribir(conexion, ajustes.CLAVE_MEDALLAS_VISTAS, json.dumps(sorted(vistas)))
