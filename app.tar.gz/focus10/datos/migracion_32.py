"""La migración 32: los hábitos cambian el emoji por un icono.

ESTE ARCHIVO ES PARTE DE UNA MIGRACIÓN PUBLICADA Y NO SE EDITA NUNCA. Está
aparte porque lleva la tabla de equivalencias y una tabla reconstruida entera;
en migraciones.py taparía todo lo demás.

POR QUÉ SE CAMBIA: el emoji lo dibuja el sistema operativo, así que el mismo
hábito se veía distinto en Windows, en Android y en el navegador, y en los tres
ignoraba los colores del tema. Era lo único de la aplicación que no obedecía.
Ver interfaz/iconos_habito.py.

NADIE TIENE QUE VOLVER A ELEGIR NADA: la lista de iconos se hizo con los mismos
temas y en el mismo orden que la de emojis, así que cada emoji se convierte en
el icono que ocupaba su sitio. El hábito de la pesa sigue con una pesa.

SE RECONSTRUYE LA TABLA EN VEZ DE AÑADIR UNA COLUMNA, y es a propósito: dejar
`emoji` ahí, obligatorio y sin que nadie lo mire, sería una columna que miente.
Reconstruir obliga a apagar las claves ajenas —las marcas apuntan a los
hábitos— y a volver a crear el índice y los TRES DISPARADORES de la
sincronización, que el DROP se lleva por delante. Lo vigila un test.
"""

from __future__ import annotations

_TABLA = """
    CREATE TABLE habitos_nueva (
        id INTEGER PRIMARY KEY,
        nombre TEXT NOT NULL,
        icono TEXT NOT NULL,
        color TEXT NOT NULL,
        objetivo INTEGER NOT NULL,
        unidad TEXT NOT NULL,
        dias TEXT NOT NULL,
        hora TEXT,
        activo INTEGER NOT NULL DEFAULT 1,
        orden INTEGER NOT NULL DEFAULT 0,
        uid TEXT,
        cambiado_en TEXT,
        CHECK (length(trim(nombre)) > 0),
        CHECK (length(trim(icono)) > 0),
        CHECK (color IN ('azul', 'verde', 'ambar', 'rosa',
                         'violeta', 'cian', 'naranja', 'rojo')),
        CHECK (objetivo >= 1),
        CHECK (length(trim(unidad)) > 0),
        CHECK (length(dias) BETWEEN 1 AND 7),
        CHECK (dias NOT GLOB '*[^0-6]*'),
        CHECK (hora IS NULL OR hora GLOB '[01][0-9]:[0-5][0-9]'
               OR hora GLOB '2[0-3]:[0-5][0-9]'),
        CHECK (activo IN (0, 1)),
        CHECK (orden >= 0)
    ) STRICT
"""

# Cada emoji, al icono que ocupaba su mismo sitio en la lista de antes.
# El que no esté en la lista se queda con la estrella, que es el de omisión:
# mejor un icono cualquiera que un hueco.
_COPIAR = (
    "INSERT INTO habitos_nueva "
    "(id, nombre, icono, color, objetivo, unidad, dias, hora, activo, orden, uid, cambiado_en) "
    "SELECT id, nombre, CASE emoji "
    "WHEN '\U0001f4b0' THEN 'moneda' "
    "WHEN '\U0001f4b5' THEN 'billete' "
    "WHEN '\U0001f4b3' THEN 'tarjeta' "
    "WHEN '\U0001f3e6' THEN 'banco' "
    "WHEN '\U0001f4c8' THEN 'grafico' "
    "WHEN '\U0001f4da' THEN 'libro' "
    "WHEN '\U0001f393' THEN 'estudiar' "
    "WHEN '\U0001f4bb' THEN 'ordenador' "
    "WHEN '\U0001f9e0' THEN 'idea' "
    "WHEN '\U0001f4dd' THEN 'escribir' "
    "WHEN '\U0001f4a7' THEN 'agua' "
    "WHEN '\U0001f48a' THEN 'pastilla' "
    "WHEN '\U0001f634' THEN 'dormir' "
    "WHEN '\U0001faa5' THEN 'cuidarse' "
    "WHEN '\U0001f9b7' THEN 'estirar' "
    "WHEN '\U0001f3cb️' THEN 'pesa' "
    "WHEN '\U0001f3cb' THEN 'pesa' "
    "WHEN '\U0001f3c3' THEN 'correr' "
    "WHEN '\U0001f6b4' THEN 'bici' "
    "WHEN '\U0001f9d8' THEN 'yoga' "
    "WHEN '⚽' THEN 'futbol' "
    "WHEN '\U0001f34e' THEN 'fruta' "
    "WHEN '\U0001f957' THEN 'ensalada' "
    "WHEN '\U0001f373' THEN 'cocinar' "
    "WHEN '\U0001f95b' THEN 'pan' "
    "WHEN '\U0001f372' THEN 'sopa' "
    "WHEN '\U0001f9f9' THEN 'limpiar' "
    "WHEN '\U0001f9fa' THEN 'lavar' "
    "WHEN '\U0001fab4' THEN 'planta' "
    "WHEN '\U0001f6cf️' THEN 'cama' "
    "WHEN '\U0001f6cf' THEN 'cama' "
    "WHEN '\U0001f415' THEN 'mascota' "
    "WHEN '\U0001f3b8' THEN 'guitarra' "
    "WHEN '\U0001f3ae' THEN 'juego' "
    "WHEN '\U0001f4d6' THEN 'leer' "
    "WHEN '\U0001f3a7' THEN 'musica' "
    "WHEN '✈️' THEN 'viajar' "
    "WHEN '✈' THEN 'viajar' "
    "WHEN '☀️' THEN 'sol' "
    "WHEN '☀' THEN 'sol' "
    "WHEN '✅' THEN 'hecho' "
    "WHEN '⭐' THEN 'estrella' "
    "WHEN '\U0001f525' THEN 'racha' "
    "WHEN '⏰' THEN 'corazon' "
    "ELSE 'estrella' END, "
    "color, objetivo, unidad, dias, hora, activo, orden, uid, cambiado_en "
    "FROM habitos"
)
"""LOS EMOJIS CON Y SIN EL CARÁCTER INVISIBLE, los dos. El U+FE0F es lo que
convierte un símbolo en emoji de color, y quien escribió el suyo a mano pudo
guardarlo sin él: sin las dos formas, ese hábito acabaría con una estrella."""

_DISPARADORES = (
    """
    CREATE TRIGGER habitos_sinc_alta AFTER INSERT ON habitos
    WHEN (SELECT COUNT(*) FROM sinc_silencio) = 0
    BEGIN
        UPDATE habitos
           SET uid = COALESCE(NEW.uid, lower(hex(randomblob(16)))),
               cambiado_en = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
         WHERE rowid = NEW.rowid;
        INSERT INTO sinc_pendientes (tabla, uid)
             SELECT 'habitos', uid FROM habitos WHERE rowid = NEW.rowid
        ON CONFLICT (tabla, uid) DO UPDATE SET vez = vez + 1;
    END
    """,
    """
    CREATE TRIGGER habitos_sinc_cambio AFTER UPDATE ON habitos
    WHEN OLD.uid IS NOT NULL AND (SELECT COUNT(*) FROM sinc_silencio) = 0
    BEGIN
        UPDATE habitos SET cambiado_en = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
         WHERE rowid = NEW.rowid;
        INSERT INTO sinc_pendientes (tabla, uid) VALUES ('habitos', NEW.uid)
        ON CONFLICT (tabla, uid) DO UPDATE SET vez = vez + 1;
    END
    """,
    """
    CREATE TRIGGER habitos_sinc_baja AFTER DELETE ON habitos
    WHEN OLD.uid IS NOT NULL AND (SELECT COUNT(*) FROM sinc_silencio) = 0
    BEGIN
        INSERT INTO sinc_pendientes (tabla, uid) VALUES ('habitos', OLD.uid)
        ON CONFLICT (tabla, uid) DO UPDATE SET vez = vez + 1;
    END
    """,
)


def sentencias() -> tuple[str, ...]:
    """Todas las sentencias de la migración 32, en orden."""
    return (
        # EL PRAGMA NO ES UN APAÑO, ES LA RECETA DE SQLITE para reconstruir una
        # tabla de la que cuelga otra. Al renombrar, SQLite REPASA EL ESQUEMA
        # ENTERO y arregla las referencias al nombre viejo; y ahí se encuentra
        # con el disparador de las marcas —que mira los hábitos para ponerle
        # nombre a la fila— apuntando a un `habitos` que en ese instante ya no
        # existe, y se planta: "no such table: main.habitos". En modo antiguo
        # el renombrado no repasa nada, y cuando termina el `habitos` bueno ya
        # está en su sitio.
        "PRAGMA legacy_alter_table = ON",
        _TABLA,
        _COPIAR,
        "DROP TABLE habitos",
        "ALTER TABLE habitos_nueva RENAME TO habitos",
        "PRAGMA legacy_alter_table = OFF",
        "CREATE UNIQUE INDEX habitos_por_uid ON habitos (uid)",
        *_DISPARADORES,
    )
