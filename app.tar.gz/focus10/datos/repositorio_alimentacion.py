"""Guardar y leer la comida, el agua y los objetivos del día.

AQUÍ NO SE CALCULA NADA. Se guarda lo que trae el registro y se devuelve lo que
hay. La única cuenta de todo el archivo es el COUNT de la lista de repetir, que
cuenta veces, no calorías.
"""

from __future__ import annotations

import sqlite3
from datetime import date, datetime

from ..dominio.agua import Trago
from ..dominio.alimento import Registro, TipoDeComida
from ..dominio.nutricion import Objetivos
from .fechas import dia_a_texto, dia_desde_texto


class RegistroNoExiste(LookupError):
    """Se pidió tocar un registro que no está."""


# ---------------------------------------------------------------------------
# La comida
# ---------------------------------------------------------------------------


def listar_del_dia(conexion: sqlite3.Connection, jornada: date) -> list[Registro]:
    filas = conexion.execute(
        "SELECT * FROM comidas WHERE jornada = ? ORDER BY momento, id",
        (dia_a_texto(jornada),),
    ).fetchall()
    return [_desde_fila(fila) for fila in filas]


def listar_entre(
    conexion: sqlite3.Connection, desde: date, hasta: date
) -> list[Registro]:
    """Todo lo comido entre dos jornadas, las dos puntas incluidas.

    LAS FECHAS SE COMPARAN COMO TEXTO y funciona porque se guardan como
    "2026-03-05": en ese formato el orden alfabético y el cronológico son el
    mismo. Es la razón de guardarlas así y no como "5/3/2026", donde marzo
    quedaría antes que febrero.
    """
    filas = conexion.execute(
        "SELECT * FROM comidas WHERE jornada BETWEEN ? AND ? "
        "ORDER BY jornada, momento, id",
        (dia_a_texto(desde), dia_a_texto(hasta)),
    ).fetchall()
    return [_desde_fila(fila) for fila in filas]


def crear(conexion: sqlite3.Connection, registro: Registro) -> Registro:
    cursor = conexion.execute(
        """
        INSERT INTO comidas
            (nombre, comida, nota, jornada, momento, cantidad, unidad,
             kcal, proteinas, carbohidratos, grasas)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        _a_fila(registro),
    )
    return obtener(conexion, cursor.lastrowid)


def actualizar(conexion: sqlite3.Connection, registro: Registro) -> Registro:
    """Corregir un registro. Lo pidió el usuario: pulsar encima y cambiarlo."""
    if registro.id is None:
        raise ValueError("para corregir hace falta el id del registro")
    _exigir(conexion, registro.id)
    conexion.execute(
        """
        UPDATE comidas SET nombre = ?, comida = ?, nota = ?, jornada = ?,
            momento = ?, cantidad = ?, unidad = ?, kcal = ?, proteinas = ?,
            carbohidratos = ?, grasas = ?
        WHERE id = ?
        """,
        (*_a_fila(registro), registro.id),
    )
    return obtener(conexion, registro.id)


def borrar(conexion: sqlite3.Connection, id_registro: int) -> None:
    _exigir(conexion, id_registro)
    conexion.execute("DELETE FROM comidas WHERE id = ?", (id_registro,))


def obtener(conexion: sqlite3.Connection, id_registro: int) -> Registro | None:
    fila = conexion.execute(
        "SELECT * FROM comidas WHERE id = ?", (id_registro,)
    ).fetchone()
    return _desde_fila(fila) if fila else None


def mas_repetidos(
    conexion: sqlite3.Connection, limite: int = 50
) -> list[tuple[Registro, int]]:
    """Lo que más se repite, con sus valores de la ÚLTIMA vez y cuántas veces.

    Es lo único que la aplicación se ofrece a hacer por el usuario, y ni siquiera
    rellena: le enseña lo que él escribió otro día para que lo repita si quiere,
    y puede cambiarlo antes de añadirlo.

    LOS VALORES SON LOS SUYOS, no un promedio ni una versión "corregida". Se coge
    la fila más reciente de cada nombre (el MAX(id), porque los ids crecen), que
    es la última vez que él decidió qué números tenía esa comida.
    """
    filas = conexion.execute(
        """
        SELECT c.*, (SELECT COUNT(*) FROM comidas x WHERE x.nombre = c.nombre) AS veces
        FROM comidas c
        WHERE c.id IN (SELECT MAX(id) FROM comidas GROUP BY nombre)
        ORDER BY veces DESC, c.momento DESC
        LIMIT ?
        """,
        (limite,),
    ).fetchall()
    return [(_desde_fila(fila), int(fila["veces"])) for fila in filas]


# ---------------------------------------------------------------------------
# El agua
# ---------------------------------------------------------------------------


def tragos_del_dia(conexion: sqlite3.Connection, jornada: date) -> list[Trago]:
    filas = conexion.execute(
        "SELECT * FROM tragos WHERE jornada = ? ORDER BY momento, id",
        (dia_a_texto(jornada),),
    ).fetchall()
    return [
        Trago(
            id=int(fila["id"]),
            ml=int(fila["ml"]),
            jornada=dia_desde_texto(fila["jornada"]),
            momento=datetime.fromisoformat(fila["momento"]),
        )
        for fila in filas
    ]


def beber(conexion: sqlite3.Connection, trago: Trago) -> Trago:
    """Apunta un trago. SE SUMA a lo que había: no sustituye el total.

    Lo garantiza la forma de la tabla, no una cuenta: cada trago es una fila
    nueva, así que "sumar" es literalmente insertar.
    """
    cursor = conexion.execute(
        "INSERT INTO tragos (ml, jornada, momento) VALUES (?, ?, ?)",
        (trago.ml, dia_a_texto(trago.jornada), trago.momento.isoformat(" ")),
    )
    fila = conexion.execute(
        "SELECT * FROM tragos WHERE id = ?", (cursor.lastrowid,)
    ).fetchone()
    return Trago(
        id=int(fila["id"]),
        ml=int(fila["ml"]),
        jornada=dia_desde_texto(fila["jornada"]),
        momento=datetime.fromisoformat(fila["momento"]),
    )


def deshacer_ultimo_trago(conexion: sqlite3.Connection, jornada: date) -> Trago | None:
    """Borra el último trago del día y lo devuelve, o None si no había ninguno.

    NUNCA RESTA. Borra una fila, y el total se vuelve a sumar de lo que queda.
    Por eso pulsar deshacer de más no puede dejar el total en negativo: como
    mucho deja la lista vacía.
    """
    tragos = tragos_del_dia(conexion, jornada)
    if not tragos:
        return None
    ultimo = max(tragos, key=lambda uno: (uno.momento, uno.id or 0))
    conexion.execute("DELETE FROM tragos WHERE id = ?", (ultimo.id,))
    return ultimo


# ---------------------------------------------------------------------------
# Los objetivos
# ---------------------------------------------------------------------------


def leer_objetivos(conexion: sqlite3.Connection) -> Objetivos:
    fila = conexion.execute(
        "SELECT kcal, proteinas, carbohidratos, grasas FROM nutricion_objetivos "
        "WHERE id = 1"
    ).fetchone()
    return Objetivos(
        kcal=_entero_o_nada(fila["kcal"]),
        proteinas=_entero_o_nada(fila["proteinas"]),
        carbohidratos=_entero_o_nada(fila["carbohidratos"]),
        grasas=_entero_o_nada(fila["grasas"]),
    )


def guardar_objetivos(conexion: sqlite3.Connection, objetivos: Objetivos) -> Objetivos:
    if not isinstance(objetivos, Objetivos):
        raise TypeError("hace falta unos Objetivos del dominio")
    conexion.execute(
        "UPDATE nutricion_objetivos SET kcal = ?, proteinas = ?, "
        "carbohidratos = ?, grasas = ? WHERE id = 1",
        (
            objetivos.kcal,
            objetivos.proteinas,
            objetivos.carbohidratos,
            objetivos.grasas,
        ),
    )
    return leer_objetivos(conexion)


def leer_objetivo_agua(conexion: sqlite3.Connection) -> int | None:
    fila = conexion.execute(
        "SELECT agua FROM nutricion_objetivos WHERE id = 1"
    ).fetchone()
    return _entero_o_nada(fila["agua"])


def guardar_objetivo_agua(conexion: sqlite3.Connection, ml: int | None) -> None:
    conexion.execute(
        "UPDATE nutricion_objetivos SET agua = ? WHERE id = 1", (ml,)
    )


# ---------------------------------------------------------------------------


def _entero_o_nada(valor) -> int | None:
    return None if valor is None else int(valor)


def _a_fila(registro: Registro) -> tuple:
    return (
        registro.nombre,
        registro.comida,
        registro.nota,
        dia_a_texto(registro.jornada),
        registro.momento.isoformat(" "),
        registro.cantidad,
        registro.unidad,
        registro.kcal,
        registro.proteinas,
        registro.carbohidratos,
        registro.grasas,
    )


def _desde_fila(fila: sqlite3.Row) -> Registro:
    return Registro(
        id=int(fila["id"]),
        nombre=fila["nombre"],
        comida=fila["comida"],
        nota=fila["nota"],
        jornada=dia_desde_texto(fila["jornada"]),
        momento=datetime.fromisoformat(fila["momento"]),
        cantidad=fila["cantidad"],
        unidad=fila["unidad"],
        kcal=int(fila["kcal"]),
        proteinas=int(fila["proteinas"]),
        carbohidratos=int(fila["carbohidratos"]),
        grasas=int(fila["grasas"]),
    )


def _exigir(conexion: sqlite3.Connection, id_registro: int) -> Registro:
    registro = obtener(conexion, id_registro)
    if registro is None:
        raise RegistroNoExiste(f"no hay ningún registro con id {id_registro}")
    return registro


# ---------------------------------------------------------------------------
# Los momentos del día: desayuno, comida, cena... y los que tú añadas
# ---------------------------------------------------------------------------



def listar_comidas(conexion: sqlite3.Connection) -> list[TipoDeComida]:
    """Los momentos del día, EN EL ORDEN DEL DÍA y no alfabético.

    Es como se lee una jornada de comidas: desayuno antes que cena. Ordenar por
    nombre pondría la cena la primera y no significaría nada.
    """
    filas = conexion.execute(
        "SELECT id, nombre, orden FROM tipos_de_comida ORDER BY orden, id"
    ).fetchall()
    return [
        TipoDeComida(id=int(fila["id"]), nombre=fila["nombre"], orden=int(fila["orden"]))
        for fila in filas
    ]


