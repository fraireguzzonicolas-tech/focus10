"""Focus corriendo en el servidor, como UN APARATO MÁS de la cuenta.

LO ELIGIÓ EL USUARIO para WhatsApp: que lo que pide por mensaje se haga «de
verdad» y en el acto, aunque la PC y el celular estén apagados. Tus datos no
viven en un servidor central sino en cada aparato (y una copia de cada fila en
la nube para sincronizar), así que el servidor hace lo mismo que un celular
recién instalado: arma una base de Focus, recibe la cuenta, hace lo pedido con
EL MISMO CÓDIGO que la app (las mismas reglas, ni una copia) y sube el cambio.
Los demás aparatos lo reciben en su próxima sincronización.

SE MIDIÓ ANTES DE ESCRIBIR ESTO: una cuenta de 1.448 filas se arma y se recibe
en 0,2 s. Lo que cuesta es bajarla de la nube (1-2 s), y por eso, si la base ya
estaba en el servidor de un mensaje anterior, solo se baja lo nuevo.

AQUÍ NO HAY RED: `bajar` y `subir` se pasan desde fuera (servidor/), como en
sincronia.py. Así esto se prueba con una nube de mentira.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Callable
from pathlib import Path

from . import sincronia
from .bd import abrir_bd

NOMBRE = "focus10.db"


def abrir(
    carpeta: Path,
    cuenta: str,
    bajar: Callable[[int], list[dict]],
    subir: Callable[[list[dict]], None],
) -> sqlite3.Connection:
    """La base de esa cuenta en el servidor, AL DÍA con la nube.

    SI YA ESTABA (de un mensaje anterior), solo se baja lo nuevo. Si no, o si
    era de otra cuenta, se arma de cero y se recibe todo: una base de otra
    cuenta jamás se reaprovecha, ni para leer.

    `cuenta` es el identificador de la cuenta (el de Supabase). Solo se usa
    para saber si la base guardada es de ella.
    """
    carpeta.mkdir(parents=True, exist_ok=True)
    conexion = abrir_bd(carpeta / NOMBRE)
    if sincronia.cuenta_sincronizada(conexion) == cuenta:
        sincronia.sincronizar(conexion, subir, bajar)
    else:
        sincronia.vaciar_y_recibir(conexion, cuenta, bajar(0))
    return conexion


def guardar(
    conexion: sqlite3.Connection,
    bajar: Callable[[int], list[dict]],
    subir: Callable[[list[dict]], None],
) -> sincronia.Informe:
    """Sube lo que se hizo. Si falla, la red lanza su error y quien llama NO
    debe decir «listo»: lo hecho quedó solo en el servidor, sin llegar a la
    nube, y la próxima vez se vuelve a intentar subir (queda en la cola)."""
    return sincronia.sincronizar(conexion, subir, bajar)
