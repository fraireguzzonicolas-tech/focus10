"""Migraciones del esquema, numeradas y aplicadas solas al arrancar.

CÓMO FUNCIONA: SQLite guarda en la cabecera de cada archivo un número entero
libre para el programa, que se lee y escribe con "PRAGMA user_version". Focus10
lo usa como "número de esquema aplicado". Al arrancar se compara con la última
migración de la lista y se aplican en orden las que falten. Una base recién
creada está en 0, así que un archivo nuevo recibe todas.

POR QUÉ user_version y no una tabla de migraciones: es un entero en la
cabecera, no hace falta crear nada para poder leerlo, y no puede haber una
"tabla de migraciones" que falte precisamente en la base vacía.

LA REGLA QUE NO SE ROMPE NUNCA: una migración ya publicada no se edita jamás.
Si el esquema tiene que cambiar, se añade otra con el número siguiente. Editar
la 1 dejaría a quien ya la aplicó con una base distinta de la de quien la
aplique mañana, y las dos diciendo "estoy en la versión 1". Ese fallo no se
detecta hasta que algo se rompe de una forma rarísima.

POR QUÉ cada migración es una TUPLA de sentencias y no un bloque de SQL:
executescript() de Python confirma por su cuenta lo que hubiera pendiente, lo
que se pelea con las transacciones explícitas; y partir un bloque por los
puntos y coma se rompe en cuanto una sentencia lleve un punto y coma dentro
(un trigger, por ejemplo). Una sentencia por elemento no tiene esos problemas.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass

from .conexion import transaccion


@dataclass(frozen=True)
class Migracion:
    version: int
    descripcion: str
    sentencias: tuple[str, ...]

    sin_claves_ajenas: bool = False
    """Si hay que apagar las claves ajenas mientras se aplica.

    HACE FALTA PARA RECONSTRUIR UNA TABLA DE LA QUE CUELGAN OTRAS. Cambiar un
    CHECK obliga a hacer tabla nueva, copiar, DROP y renombrar; y ese DROP, con
    las claves ajenas encendidas, es un error: los movimientos apuntan a las
    categorías, así que borrar las categorías —aunque sea por un instante y
    dentro de una transacción— rompe la referencia.

    ESTO SALTÓ EN LA BASE DE VERDAD Y NO EN LOS TESTS, y la razón merece estar
    escrita: en una base recién creada no hay ni un movimiento apuntando a
    ninguna categoría, así que el DROP no rompe nada y la migración pasa. El
    fallo necesita datos para aparecer, que es justo lo que tiene la base del
    usuario y no tenía ninguna prueba.

    ES EL PROCEDIMIENTO QUE DOCUMENTA SQLITE, no un apaño: apagar, reconstruir,
    comprobar con `foreign_key_check` que no quedó nada colgando, y encender.
    La comprobación va DENTRO de la transacción, para que un fallo la deshaga
    entera en vez de dejar la base con referencias rotas.
    """


MIGRACIONES: tuple[Migracion, ...] = (
    Migracion(
        version=1,
        descripcion="tabla de ajustes (clave -> valor)",
        sentencias=(
            # STRICT obliga a que cada columna guarde el tipo declarado. Sin
            # ella, SQLite acepta un texto en una columna INTEGER, que es
            # justo el agujero por el que entraría un importe en euros con
            # decimales donde tienen que haber céntimos enteros.
            # Matiz comprobado en los tests: STRICT sí permite conversiones sin
            # pérdida (un 5 en una columna TEXT se guarda como "5"), así que no
            # sustituye a validar en Python; es la segunda barrera.
            """
            CREATE TABLE ajustes (
                clave TEXT PRIMARY KEY NOT NULL,
                valor TEXT NOT NULL
            ) STRICT
            """,
        ),
    ),
    Migracion(
        version=2,
        descripcion="categorías y movimientos de dinero",
        sentencias=(
            # CHECK dentro de la tabla y no solo en Python: los controles del
            # dominio protegen mientras se pasa por el dominio, pero la base de
            # datos es la última defensa si algún día se escribe desde otro
            # sitio (una herramienta, una corrección a mano, un error).
            """
            CREATE TABLE categorias (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                tipo TEXT NOT NULL,
                activa INTEGER NOT NULL DEFAULT 1,
                orden INTEGER NOT NULL DEFAULT 0,
                CHECK (tipo IN ('gasto', 'ingreso')),
                CHECK (activa IN (0, 1)),
                CHECK (length(trim(nombre)) > 0),
                CHECK (orden >= 0)
            ) STRICT
            """,
            # Índice sobre lower(nombre) para que no puedan convivir "Ocio" y
            # "ocio". Aviso honesto: lower() de SQLite solo baja letras ASCII,
            # así que "EDUCACIÓN" y "Educación" sí podrían coexistir por culpa
            # de la tilde. Es un caso raro y el precio de no depender de una
            # extensión que quizá no esté instalada.
            """
            CREATE UNIQUE INDEX categorias_sin_repetir
                ON categorias (lower(nombre), tipo)
            """,
            """
            CREATE TABLE movimientos (
                id INTEGER PRIMARY KEY,
                tipo TEXT NOT NULL,
                importe INTEGER NOT NULL,
                moneda TEXT NOT NULL,
                categoria_id INTEGER NOT NULL REFERENCES categorias (id),
                descripcion TEXT NOT NULL DEFAULT '',
                momento TEXT NOT NULL,
                jornada TEXT NOT NULL,
                tasa TEXT,
                importe_principal INTEGER,
                CHECK (tipo IN ('gasto', 'ingreso')),
                CHECK (importe > 0),
                -- GLOB comprueba la FORMA, no solo el largo. Se descubrio al
                -- escribir el test: con "length(jornada) = 10" entraba
                -- tranquilamente un "18/08/2025", que tiene diez caracteres y
                -- no es una fecha de las que aqui se guardan.
                CHECK (moneda GLOB '[A-Z][A-Z][A-Z]'),
                CHECK (momento GLOB
                    '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK ((tasa IS NULL) = (importe_principal IS NULL)),
                CHECK (importe_principal IS NULL OR importe_principal >= 0)
            ) STRICT
            """,
            # REFERENCES de arriba hace dos cosas, las dos buscadas: impide
            # guardar un movimiento con una categoría que no existe, e impide
            # borrar una categoría que tenga movimientos. Lo segundo es la
            # decisión de "no se borra, se desactiva", puesta donde no se puede
            # saltar por descuido.
            """
            CREATE INDEX movimientos_por_jornada ON movimientos (jornada)
            """,
            # Índice parcial: solo indexa los que están pendientes de cambio,
            # que son cuatro gatos. Buscar "qué me falta por convertir" es
            # inmediato y el índice no engorda con los miles que sí tienen tasa.
            """
            CREATE INDEX movimientos_pendientes
                ON movimientos (id) WHERE tasa IS NULL
            """,
            # Las categorías de partida. Estas SÍ van en la migración (y no en
            # el código, como los ajustes) porque son datos que el usuario va a
            # editar: si las borra, no deben reaparecer al abrir de nuevo.
            """
            INSERT INTO categorias (nombre, tipo, orden) VALUES
                ('Transporte',    'gasto',   1),
                ('Ocio',          'gasto',   2),
                ('Educación',     'gasto',   3),
                ('Alimentación',  'gasto',   4),
                ('Compras',       'gasto',   5),
                ('Vivienda',      'gasto',   6),
                ('Salud',         'gasto',   7),
                ('Suscripciones', 'gasto',   8),
                ('Boludeo',       'gasto',   9),
                ('Sueldo',        'ingreso', 1),
                ('Propinas',      'ingreso', 2),
                ('Extra',         'ingreso', 3),
                ('Regalo',        'ingreso', 4),
                ('Venta',         'ingreso', 5)
            """,
        ),
    ),
    Migracion(
        version=3,
        descripcion="saldos: cuánto hay ahorrado e invertido",
        sentencias=(
            # Es una tabla de FOTOS, no de movimientos: cada fila dice cuánto
            # había en un momento dado. La cifra de ahora es la última fila de
            # su clase; las anteriores son el historial.
            """
            CREATE TABLE saldos (
                id INTEGER PRIMARY KEY,
                clase TEXT NOT NULL,
                importe INTEGER NOT NULL,
                moneda TEXT NOT NULL,
                momento TEXT NOT NULL,
                jornada TEXT NOT NULL,
                nota TEXT NOT NULL DEFAULT '',
                tasa TEXT,
                importe_principal INTEGER,
                CHECK (clase IN ('ahorro', 'inversion')),
                -- Ojo, aquí SÍ se admite el cero, al revés que en movimientos:
                -- tener cero ahorrado es un dato válido y de los más útiles.
                CHECK (importe >= 0),
                CHECK (moneda GLOB '[A-Z][A-Z][A-Z]'),
                CHECK (momento GLOB
                    '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK ((tasa IS NULL) = (importe_principal IS NULL)),
                CHECK (importe_principal IS NULL OR importe_principal >= 0)
            ) STRICT
            """,
            # Se busca casi siempre "la última de esta clase", así que el índice
            # va por clase y momento.
            """
            CREATE INDEX saldos_por_clase ON saldos (clase, momento)
            """,
            """
            CREATE INDEX saldos_pendientes
                ON saldos (id) WHERE tasa IS NULL
            """,
        ),
    ),
    Migracion(
        version=4,
        descripcion="hábitos y sus marcas diarias",
        sentencias=(
            # Los días de la semana van como texto ("0246" = lunes, miércoles,
            # viernes, domingo) en vez de en su propia tabla. Son siete
            # síes-o-noes que no se consultan por separado nunca: siempre se
            # pregunta "¿toca hoy?" teniendo el hábito delante. Una tabla aparte
            # sería una unión más en cada consulta para no ganar nada.
            """
            CREATE TABLE habitos (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                emoji TEXT NOT NULL,
                color TEXT NOT NULL,
                objetivo INTEGER NOT NULL,
                unidad TEXT NOT NULL,
                dias TEXT NOT NULL,
                hora TEXT,
                activo INTEGER NOT NULL DEFAULT 1,
                orden INTEGER NOT NULL DEFAULT 0,
                CHECK (length(trim(nombre)) > 0),
                CHECK (length(trim(emoji)) > 0),
                CHECK (color IN ('azul', 'verde', 'ambar', 'rosa',
                                 'violeta', 'cian', 'naranja', 'rojo')),
                CHECK (objetivo >= 1),
                CHECK (length(trim(unidad)) > 0),
                -- Entre uno y siete dígitos del 0 al 6, sin nada más.
                CHECK (length(dias) BETWEEN 1 AND 7),
                CHECK (dias NOT GLOB '*[^0-6]*'),
                -- Dos patrones y no uno: GLOB no sabe de rangos numericos, y
                -- con un solo '[0-2][0-9]' entraba tan tranquilo un "25:00".
                -- Lo cazo el test, no la vista.
                CHECK (hora IS NULL OR hora GLOB '[01][0-9]:[0-5][0-9]'
                       OR hora GLOB '2[0-3]:[0-5][0-9]'),
                CHECK (activo IN (0, 1)),
                CHECK (orden >= 0)
            ) STRICT
            """,
            # Una marca por hábito y jornada: al pulsar el círculo se SUMA a la
            # que ya hay, no se crea otra fila. El índice único es lo que lo
            # garantiza aunque el código se equivoque.
            """
            CREATE TABLE marcas (
                id INTEGER PRIMARY KEY,
                habito_id INTEGER NOT NULL REFERENCES habitos (id),
                jornada TEXT NOT NULL,
                cantidad INTEGER NOT NULL,
                CHECK (cantidad >= 0),
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]')
            ) STRICT
            """,
            """
            CREATE UNIQUE INDEX marcas_una_por_jornada
                ON marcas (habito_id, jornada)
            """,
            # Para el calendario del mes, que pide todas las marcas de un rango.
            """
            CREATE INDEX marcas_por_jornada ON marcas (jornada)
            """,
        ),
    ),
    Migracion(
        version=5,
        descripcion="tareas sueltas del día",
        sentencias=(
            # LAS DOS FECHAS: jornada es el día PARA EL QUE se apuntó y no se
            # mueve nunca; hecha_en es el día en que se hizo de verdad, o NULL
            # mientras siga pendiente. Separadas es lo que permite que una tarea
            # sin hacer siga apareciendo hoy Y que su día quede registrado como
            # no cumplido. Si al arrastrarla se le cambiara la jornada, ese día
            # parecería que nunca tuvo nada que hacer.
            """
            CREATE TABLE tareas (
                id INTEGER PRIMARY KEY,
                titulo TEXT NOT NULL,
                jornada TEXT NOT NULL,
                hecha_en TEXT,
                nota TEXT NOT NULL DEFAULT '',
                orden INTEGER NOT NULL DEFAULT 0,
                CHECK (length(trim(titulo)) > 0),
                CHECK (length(titulo) <= 120),
                CHECK (length(nota) <= 500),
                CHECK (orden >= 0),
                -- La FORMA de la fecha, no solo su largo: un length(jornada)=10
                -- se tragaba tan tranquilo un "18/08/2025". Ya paso una vez.
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK (hecha_en IS NULL OR
                       hecha_en GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]')
            ) STRICT
            """,
            # La lista del día pregunta siempre por jornada: sin índice habría
            # que recorrer todas las tareas de la historia para pintar un día.
            """
            CREATE INDEX tareas_por_jornada ON tareas (jornada)
            """,
            # Y las pendientes se piden por separado, porque son las que se
            # arrastran de días anteriores.
            """
            CREATE INDEX tareas_pendientes ON tareas (hecha_en)
            """,
        ),
    ),
    Migracion(
        version=6,
        descripcion="ajustes de Focus, webs a bloquear y programas a cerrar",
        sentencias=(
            # Una sola fila, siempre la misma: son LOS ajustes, no una lista de
            # ajustes. El CHECK (id = 1) lo garantiza aunque el codigo se
            # equivoque; sin el, un INSERT de mas dejaria dos configuraciones y
            # ganaria la que saliera primero.
            """
            CREATE TABLE focus_ajustes (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                trabajo INTEGER NOT NULL DEFAULT 1500,
                descanso INTEGER NOT NULL DEFAULT 300,
                descanso_largo INTEGER NOT NULL DEFAULT 900,
                sesiones_por_ciclo INTEGER NOT NULL DEFAULT 4,
                bloquear_webs INTEGER NOT NULL DEFAULT 0,
                cerrar_programas INTEGER NOT NULL DEFAULT 0,
                -- De un minuto a ocho horas, que es el tope que puso el usuario.
                CHECK (trabajo BETWEEN 60 AND 28800),
                CHECK (descanso BETWEEN 60 AND 28800),
                CHECK (descanso_largo BETWEEN 60 AND 28800),
                CHECK (sesiones_por_ciclo BETWEEN 1 AND 12),
                CHECK (bloquear_webs IN (0, 1)),
                CHECK (cerrar_programas IN (0, 1))
            ) STRICT
            """,
            "INSERT INTO focus_ajustes (id) VALUES (1)",
            # OJO: la base NO puede impedir que se guarde un dominio protegido.
            # La lista de protegidos vive en el codigo a proposito, para que no
            # se pueda quitar tocando este archivo. Por eso quien guarda pasa
            # SIEMPRE por dominio/dominios.py, y el guardian vuelve a mirar por
            # su cuenta antes de escribir nada.
            """
            CREATE TABLE focus_dominios (
                id INTEGER PRIMARY KEY,
                dominio TEXT NOT NULL UNIQUE,
                CHECK (length(trim(dominio)) > 0),
                CHECK (dominio = lower(dominio)),
                CHECK (dominio NOT GLOB '*[ /:]*')
            ) STRICT
            """,
            """
            CREATE TABLE focus_programas (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL UNIQUE,
                CHECK (length(trim(nombre)) > 0),
                CHECK (nombre = lower(nombre)),
                -- Sin comodines: un "*" aqui significa "cierra todo lo que
                -- empiece por", y basta un despiste para llevarse media maquina.
                CHECK (nombre NOT GLOB '*[*?]*'),
                CHECK (nombre NOT GLOB '*.exe')
            ) STRICT
            """,
        ),
    ),
    Migracion(
        version=7,
        descripcion="comida, agua y objetivos del dia",
        sentencias=(
            # LOS NUMEROS SON LOS QUE ESCRIBE EL USUARIO. Esta tabla no guarda
            # nada derivado: ni calorias por gramo, ni un id de alimento, ni una
            # referencia a ninguna base de datos de comidas. Una version anterior
            # calculaba las calorias sola y le puso 29 kcal a 300 gramos de
            # fideos; la forma de que eso no vuelva a pasar es que no haya donde
            # guardar un numero calculado.
            #
            # cantidad y unidad son TEXTO a proposito: de ellas no se deriva
            # nada, y asi "1 puñado" es una cantidad tan valida como "300 g".
            """
            CREATE TABLE comidas (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                comida TEXT NOT NULL,
                jornada TEXT NOT NULL,
                momento TEXT NOT NULL,
                cantidad TEXT NOT NULL DEFAULT '',
                unidad TEXT NOT NULL DEFAULT '',
                kcal INTEGER NOT NULL DEFAULT 0,
                proteinas INTEGER NOT NULL DEFAULT 0,
                carbohidratos INTEGER NOT NULL DEFAULT 0,
                grasas INTEGER NOT NULL DEFAULT 0,
                CHECK (length(trim(nombre)) > 0),
                CHECK (comida IN ('desayuno', 'comida', 'cena', 'snack')),
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK (kcal >= 0 AND kcal <= 20000),
                CHECK (proteinas >= 0 AND proteinas <= 100000),
                CHECK (carbohidratos >= 0 AND carbohidratos <= 100000),
                CHECK (grasas >= 0 AND grasas <= 100000)
            ) STRICT
            """,
            "CREATE INDEX comidas_por_jornada ON comidas (jornada)",
            # Para la lista de "repetir", que agrupa por nombre.
            "CREATE INDEX comidas_por_nombre ON comidas (nombre)",
            # UN TRAGO POR FILA, no un total acumulado. Es lo que hace que
            # deshacer sea exacto (se borra la ultima fila, sea de 250 o de 33)
            # y que el total no pueda quedarse en negativo: nunca se resta, se
            # quita una fila y se vuelve a sumar lo que queda.
            """
            CREATE TABLE tragos (
                id INTEGER PRIMARY KEY,
                ml INTEGER NOT NULL,
                jornada TEXT NOT NULL,
                momento TEXT NOT NULL,
                CHECK (ml > 0 AND ml <= 5000),
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]')
            ) STRICT
            """,
            "CREATE INDEX tragos_por_jornada ON tragos (jornada)",
            # NULL es "no me importa este objetivo", y por eso las columnas
            # admiten NULL pero no el cero: tener dos formas de decir lo mismo
            # acaba en que la mitad del codigo comprueba una y la otra mitad la
            # otra.
            """
            CREATE TABLE nutricion_objetivos (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                kcal INTEGER,
                proteinas INTEGER,
                carbohidratos INTEGER,
                grasas INTEGER,
                agua INTEGER,
                CHECK (kcal IS NULL OR kcal > 0),
                CHECK (proteinas IS NULL OR proteinas > 0),
                CHECK (carbohidratos IS NULL OR carbohidratos > 0),
                CHECK (grasas IS NULL OR grasas > 0),
                CHECK (agua IS NULL OR (agua > 0 AND agua <= 20000))
            ) STRICT
            """,
            "INSERT INTO nutricion_objetivos (id) VALUES (1)",
        ),
    ),
    Migracion(
        version=8,
        descripcion="posiciones, operaciones y precios de mercado",
        sentencias=(
            # NI LAS UNIDADES NI EL PRECIO MEDIO TIENEN COLUMNA, y es la decision
            # mas importante de esta migracion: se calculan siempre desde las
            # operaciones. Si estuvieran guardados habria dos versiones de la
            # verdad, y el dia que no cuadren no habria forma de saber cual esta
            # bien. Lo que no existe no se puede desincronizar.
            #
            # El precio actual SI se guarda, porque no se deriva de nada: o lo
            # escribes tu o lo trae internet. Con el se guarda de donde vino y
            # cuando, para poder distinguirlos en pantalla.
            """
            CREATE TABLE posiciones (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                ticker TEXT NOT NULL,
                tipo TEXT NOT NULL,
                precio_actual INTEGER,
                precio_origen TEXT,
                precio_momento TEXT,
                precio_original INTEGER,
                precio_moneda TEXT,
                precio_cambio TEXT,
                CHECK (length(trim(nombre)) > 0),
                CHECK (length(trim(ticker)) > 0),
                CHECK (ticker = upper(ticker)),
                CHECK (tipo IN ('acción', 'ETF', 'fondo', 'cripto', 'otro')),
                CHECK (precio_actual IS NULL OR precio_actual >= 0),
                CHECK (precio_origen IS NULL OR precio_origen IN ('mano', 'mercado')),
                -- Si el precio vino de fuera, tienen que estar las tres cosas
                -- que permiten comprobarlo. Media conversion guardada es peor
                -- que ninguna: parece un dato bueno y no se puede verificar.
                CHECK (precio_origen IS NOT 'mercado' OR (
                    precio_original IS NOT NULL AND
                    precio_moneda IS NOT NULL AND
                    precio_cambio IS NOT NULL))
            ) STRICT
            """,
            "CREATE UNIQUE INDEX posiciones_por_ticker ON posiciones (ticker)",
            # Las unidades van en MILLONESIMAS y el precio en centimos, los dos
            # enteros. Nada de coma flotante: con treinta compras, el error de
            # redondeo del binario se ve en el total de la cartera.
            """
            CREATE TABLE operaciones (
                id INTEGER PRIMARY KEY,
                posicion_id INTEGER NOT NULL REFERENCES posiciones (id),
                tipo TEXT NOT NULL,
                fecha TEXT NOT NULL,
                unidades INTEGER NOT NULL DEFAULT 0,
                precio INTEGER NOT NULL DEFAULT 0,
                importe INTEGER NOT NULL DEFAULT 0,
                CHECK (tipo IN ('compra', 'venta', 'dividendo')),
                CHECK (fecha GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK (unidades >= 0 AND precio >= 0 AND importe >= 0),
                -- Un dividendo lleva importe y nada mas; una compra o venta
                -- lleva unidades y precio y nada mas. Mezclarlos seria dejar
                -- que los tres numeros no cuadren.
                CHECK (
                    (tipo = 'dividendo' AND unidades = 0 AND precio = 0 AND importe > 0)
                    OR (tipo != 'dividendo' AND unidades > 0 AND importe = 0)
                )
            ) STRICT
            """,
            "CREATE INDEX operaciones_por_posicion ON operaciones (posicion_id)",
            "ALTER TABLE focus_ajustes ADD COLUMN precios_de_mercado INTEGER NOT NULL DEFAULT 0",
        ),
    ),
    Migracion(
        version=9,
        descripcion="objetivos y sus aportaciones",
        sentencias=(
            # EL IMPORTE ADMITE CERO, Y ES LO MAS IMPORTANTE DE ESTA TABLA. Lo
            # aviso el propio usuario: si fuera "mayor que cero", los objetivos
            # LIBRES ("sacarme el B2 de aleman") no se podrian guardar, porque no
            # tienen importe ninguno. Lo que decide si hay meta de dinero es el
            # TIPO, no el numero.
            """
            CREATE TABLE objetivos (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                color TEXT NOT NULL,
                tipo TEXT NOT NULL,
                porque TEXT NOT NULL DEFAULT '',
                importe_objetivo INTEGER NOT NULL DEFAULT 0,
                avance_manual INTEGER NOT NULL DEFAULT 0,
                fecha_limite TEXT,
                cumplido_en TEXT,
                orden INTEGER NOT NULL DEFAULT 0,
                CHECK (length(trim(nombre)) > 0),
                CHECK (color IN ('azul', 'verde', 'ambar', 'rosa',
                                 'violeta', 'cian', 'naranja', 'rojo')),
                CHECK (tipo IN ('dinero', 'libre')),
                CHECK (importe_objetivo >= 0),
                CHECK (avance_manual BETWEEN 0 AND 100),
                CHECK (avance_manual % 10 = 0),
                -- Un objetivo libre no lleva importe y uno de dinero no lleva
                -- avance a mano: tener las dos cosas dejaria dos avances
                -- distintos para el mismo objetivo.
                CHECK (tipo != 'libre' OR importe_objetivo = 0),
                CHECK (tipo != 'dinero' OR avance_manual = 0),
                CHECK (fecha_limite IS NULL OR
                       fecha_limite GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK (cumplido_en IS NULL OR
                       cumplido_en GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK (orden >= 0)
            ) STRICT
            """,
            # Las aportaciones NO son movimientos de Finanzas. Lo decidio el
            # usuario: apartar 200 EUR para un viaje no es gastarlos, y meterlo
            # ademas como gasto diria que gasto un dinero que no gasto.
            #
            # El importe puede ser NEGATIVO: sacar dinero de un objetivo pasa. Lo
            # que no puede es ser cero, que no significaria nada.
            """
            CREATE TABLE aportaciones (
                id INTEGER PRIMARY KEY,
                objetivo_id INTEGER NOT NULL REFERENCES objetivos (id),
                importe INTEGER NOT NULL,
                fecha TEXT NOT NULL,
                nota TEXT NOT NULL DEFAULT '',
                CHECK (importe != 0),
                CHECK (fecha GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK (length(nota) <= 200)
            ) STRICT
            """,
            "CREATE INDEX aportaciones_por_objetivo ON aportaciones (objetivo_id)",
        ),
    ),
    Migracion(
        version=10,
        descripcion="biblioteca de ejercicios",
        sentencias=(
            # LOS GRUPOS SECUNDARIOS VAN COMO TEXTO ("triceps,hombro") y no en su
            # propia tabla: son como mucho tres etiquetas por ejercicio y nunca se
            # consultan sueltas, siempre teniendo el ejercicio delante. Una tabla
            # aparte seria una union mas en cada consulta para no ganar nada. Es
            # la misma decision que los dias de la semana de los habitos.
            """
            CREATE TABLE ejercicios (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                grupo TEXT NOT NULL,
                material TEXT NOT NULL,
                secundarios TEXT NOT NULL DEFAULT '',
                descanso INTEGER NOT NULL DEFAULT 90,
                notas TEXT NOT NULL DEFAULT '',
                medida TEXT NOT NULL DEFAULT 'peso × repeticiones',
                CHECK (length(trim(nombre)) > 0),
                CHECK (grupo IN ('pecho', 'espalda', 'pierna', 'hombro',
                                 'bíceps', 'tríceps', 'core', 'cardio')),
                CHECK (material IN ('barra', 'mancuernas', 'máquina', 'polea',
                                    'peso corporal')),
                CHECK (medida IN ('peso × repeticiones', 'tiempo')),
                CHECK (descanso BETWEEN 0 AND 1800)
            ) STRICT
            """,
            "CREATE INDEX ejercicios_por_grupo ON ejercicios (grupo)",
            # LOS 45 DE PARTIDA, para no empezar con la pantalla vacia. Se meten
            # aqui y no al abrir la aplicacion: una migracion corre UNA vez, asi
            # que si el usuario los borra, borrados se quedan. Metiendolos al
            # arrancar volverian a aparecer cada vez y seria imposible limpiarlos.
            """
            INSERT INTO ejercicios (nombre, grupo, material, descanso, medida) VALUES
            ("Press de banca", 'pecho', 'barra', 150, 'peso × repeticiones'),
            ("Press inclinado con mancuernas", 'pecho', 'mancuernas', 120, 'peso × repeticiones'),
            ("Aperturas con mancuernas", 'pecho', 'mancuernas', 90, 'peso × repeticiones'),
            ("Cruces en polea", 'pecho', 'polea', 75, 'peso × repeticiones'),
            ("Fondos en paralelas", 'pecho', 'peso corporal', 120, 'peso × repeticiones'),
            ("Press de banca en maquina", 'pecho', 'máquina', 90, 'peso × repeticiones'),
            ("Dominadas", 'espalda', 'peso corporal', 150, 'peso × repeticiones'),
            ("Remo con barra", 'espalda', 'barra', 150, 'peso × repeticiones'),
            ("Remo con mancuerna a una mano", 'espalda', 'mancuernas', 90, 'peso × repeticiones'),
            ("Jalon al pecho", 'espalda', 'polea', 90, 'peso × repeticiones'),
            ("Remo en polea baja", 'espalda', 'polea', 90, 'peso × repeticiones'),
            ("Peso muerto", 'espalda', 'barra', 180, 'peso × repeticiones'),
            ("Pull-over en polea", 'espalda', 'polea', 75, 'peso × repeticiones'),
            ("Sentadilla con barra", 'pierna', 'barra', 180, 'peso × repeticiones'),
            ("Prensa de piernas", 'pierna', 'máquina', 120, 'peso × repeticiones'),
            ("Zancadas con mancuernas", 'pierna', 'mancuernas', 120, 'peso × repeticiones'),
            ("Peso muerto rumano", 'pierna', 'barra', 150, 'peso × repeticiones'),
            ("Extension de cuadriceps", 'pierna', 'máquina', 90, 'peso × repeticiones'),
            ("Curl femoral tumbado", 'pierna', 'máquina', 90, 'peso × repeticiones'),
            ("Elevacion de gemelos", 'pierna', 'máquina', 60, 'peso × repeticiones'),
            ("Hip thrust", 'pierna', 'barra', 120, 'peso × repeticiones'),
            ("Sentadilla bulgara", 'pierna', 'mancuernas', 120, 'peso × repeticiones'),
            ("Press militar", 'hombro', 'barra', 150, 'peso × repeticiones'),
            ("Press de hombro con mancuernas", 'hombro', 'mancuernas', 120, 'peso × repeticiones'),
            ("Elevaciones laterales", 'hombro', 'mancuernas', 60, 'peso × repeticiones'),
            ("Elevaciones frontales", 'hombro', 'mancuernas', 60, 'peso × repeticiones'),
            ("Pajaro para deltoide posterior", 'hombro', 'mancuernas', 60, 'peso × repeticiones'),
            ("Face pull", 'hombro', 'polea', 60, 'peso × repeticiones'),
            ("Curl con barra", 'bíceps', 'barra', 90, 'peso × repeticiones'),
            ("Curl con mancuernas", 'bíceps', 'mancuernas', 75, 'peso × repeticiones'),
            ("Curl martillo", 'bíceps', 'mancuernas', 75, 'peso × repeticiones'),
            ("Curl en banco Scott", 'bíceps', 'máquina', 75, 'peso × repeticiones'),
            ("Curl en polea", 'bíceps', 'polea', 60, 'peso × repeticiones'),
            ("Press frances", 'tríceps', 'barra', 90, 'peso × repeticiones'),
            ("Extension de triceps en polea", 'tríceps', 'polea', 60, 'peso × repeticiones'),
            ("Fondos en banco", 'tríceps', 'peso corporal', 75, 'peso × repeticiones'),
            ("Patada de triceps", 'tríceps', 'mancuernas', 60, 'peso × repeticiones'),
            ("Plancha", 'core', 'peso corporal', 60, 'tiempo'),
            ("Elevacion de piernas colgado", 'core', 'peso corporal', 60, 'peso × repeticiones'),
            ("Rueda abdominal", 'core', 'peso corporal', 60, 'peso × repeticiones'),
            ("Crunch en polea", 'core', 'polea', 60, 'peso × repeticiones'),
            ("Cinta de correr", 'cardio', 'máquina', 0, 'tiempo'),
            ("Bicicleta estatica", 'cardio', 'máquina', 0, 'tiempo'),
            ("Eliptica", 'cardio', 'máquina', 0, 'tiempo'),
            ("Remo de cardio", 'cardio', 'máquina', 0, 'tiempo')
            """,
        ),
    ),
    Migracion(
        version=11,
        descripcion="rutina semanal y sesiones de gimnasio",
        sentencias=(
            # LA ROTACION: siete dias, uno por dia de la semana. No hay una fila
            # por semana ni por mes; el 17 de agosto usa el dia que le toque por
            # ser domingo. Por eso el dia es la clave primaria.
            """
            CREATE TABLE rutina_dias (
                dia INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL DEFAULT '',
                color TEXT NOT NULL DEFAULT 'azul',
                es_descanso INTEGER NOT NULL DEFAULT 0,
                CHECK (dia BETWEEN 0 AND 6),
                CHECK (es_descanso IN (0, 1)),
                CHECK (color IN ('azul', 'verde', 'ambar', 'rosa',
                                 'violeta', 'cian', 'naranja', 'rojo'))
            ) STRICT
            """,
            # EL PLAN. Ojo: esta tabla y la de abajo (sesion_ejercicios) se
            # parecen mucho y NO son la misma. Duplicar aqui es exactamente lo
            # que pidio el usuario: "separalos en la base de datos desde la
            # primera tabla, aunque al principio parezca duplicar cosas".
            #
            # ejercicio_id admite NULL: si se borra de la biblioteca, el plan se
            # sigue leyendo por el nombre.
            """
            CREATE TABLE rutina_ejercicios (
                id INTEGER PRIMARY KEY,
                dia INTEGER NOT NULL REFERENCES rutina_dias (dia),
                ejercicio_id INTEGER,
                nombre TEXT NOT NULL,
                orden INTEGER NOT NULL DEFAULT 0,
                series_objetivo INTEGER NOT NULL DEFAULT 3,
                repeticiones_objetivo INTEGER NOT NULL DEFAULT 10,
                peso_objetivo INTEGER NOT NULL DEFAULT 0,
                CHECK (length(trim(nombre)) > 0),
                CHECK (dia BETWEEN 0 AND 6),
                CHECK (orden >= 0),
                CHECK (series_objetivo BETWEEN 1 AND 20),
                CHECK (repeticiones_objetivo BETWEEN 0 AND 500),
                CHECK (peso_objetivo BETWEEN 0 AND 100000)
            ) STRICT
            """,
            "CREATE INDEX rutina_ejercicios_por_dia ON rutina_ejercicios (dia)",
            # LO EJECUTADO. Una sesion por fecha: dos entrenos el mismo dia se
            # apuntan como uno, que es como se viven.
            """
            CREATE TABLE sesiones (
                id INTEGER PRIMARY KEY,
                fecha TEXT NOT NULL UNIQUE,
                nombre TEXT NOT NULL DEFAULT '',
                color TEXT NOT NULL DEFAULT 'azul',
                CHECK (fecha GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK (color IN ('azul', 'verde', 'ambar', 'rosa',
                                 'violeta', 'cian', 'naranja', 'rojo'))
            ) STRICT
            """,
            # EL NOMBRE SE GUARDA AQUI, no solo la referencia. Es lo que permite
            # leer un entreno de hace dos anos aunque hoy se limpie la
            # biblioteca. Perder dos anos de registro por ordenar una lista
            # seria mucho peor que tener el mismo nombre en dos sitios.
            """
            CREATE TABLE sesion_ejercicios (
                id INTEGER PRIMARY KEY,
                sesion_id INTEGER NOT NULL REFERENCES sesiones (id),
                ejercicio_id INTEGER,
                nombre TEXT NOT NULL,
                orden INTEGER NOT NULL DEFAULT 0,
                CHECK (length(trim(nombre)) > 0),
                CHECK (orden >= 0)
            ) STRICT
            """,
            "CREATE INDEX sesion_ejercicios_por_sesion ON sesion_ejercicios (sesion_id)",
            "CREATE INDEX sesion_ejercicios_por_ejercicio ON sesion_ejercicios (ejercicio_id)",
            # UNA FILA POR SERIE, como se pidio. "hecha" es lo que decide si esa
            # serie cuenta para el volumen: escrita y sin marcar es una
            # intencion, no un peso levantado.
            """
            CREATE TABLE series (
                id INTEGER PRIMARY KEY,
                sesion_ejercicio_id INTEGER NOT NULL REFERENCES sesion_ejercicios (id),
                numero INTEGER NOT NULL,
                peso INTEGER NOT NULL DEFAULT 0,
                repeticiones INTEGER NOT NULL DEFAULT 0,
                hecha INTEGER NOT NULL DEFAULT 0,
                rpe INTEGER,
                al_fallo INTEGER NOT NULL DEFAULT 0,
                segundos INTEGER NOT NULL DEFAULT 0,
                CHECK (numero BETWEEN 1 AND 20),
                CHECK (peso BETWEEN 0 AND 100000),
                CHECK (repeticiones BETWEEN 0 AND 500),
                CHECK (hecha IN (0, 1)),
                CHECK (al_fallo IN (0, 1)),
                CHECK (rpe IS NULL OR rpe BETWEEN 1 AND 10),
                CHECK (segundos BETWEEN 0 AND 14400)
            ) STRICT
            """,
            "CREATE INDEX series_por_ejercicio ON series (sesion_ejercicio_id)",
            "INSERT INTO rutina_dias (dia) VALUES (0),(1),(2),(3),(4),(5),(6)",
        ),
    ),
    Migracion(
        version=12,
        descripcion="tildes en los nombres de ejercicio y 26 basicos mas",
        sentencias=(
            # LAS TILDES QUE FALTABAN. La carga inicial escribio "Jalon",
            # "Extension" y "Eliptica" sin tilde, y en una pantalla que se mira
            # todos los dias eso canta.
            #
            # POR QUE UNA MIGRACION NUEVA Y NO ARREGLAR LA 11: una migracion
            # publicada no se toca NUNCA. La 11 ya corrio en esta base y en
            # cualquier otra; cambiarla ahora significaria que dos ordenadores
            # con la misma version tendrian datos distintos, y eso es imposible
            # de depurar despues.
            #
            # CADA UPDATE LLEVA EL NOMBRE VIEJO EN EL WHERE. Si el usuario ya
            # habia renombrado alguno a mano, la linea no encuentra nada y su
            # nombre se respeta. Renombrar por encima de una correccion suya
            # seria perder trabajo hecho por arreglar una tilde.
            "UPDATE ejercicios SET nombre = 'Press de banca en máquina' WHERE nombre = 'Press de banca en maquina'",
            "UPDATE ejercicios SET nombre = 'Jalón al pecho' WHERE nombre = 'Jalon al pecho'",
            "UPDATE ejercicios SET nombre = 'Extensión de cuádriceps' WHERE nombre = 'Extension de cuadriceps'",
            "UPDATE ejercicios SET nombre = 'Elevación de gemelos' WHERE nombre = 'Elevacion de gemelos'",
            "UPDATE ejercicios SET nombre = 'Sentadilla búlgara' WHERE nombre = 'Sentadilla bulgara'",
            "UPDATE ejercicios SET nombre = 'Pájaro para deltoide posterior' WHERE nombre = 'Pajaro para deltoide posterior'",
            "UPDATE ejercicios SET nombre = 'Press francés' WHERE nombre = 'Press frances'",
            "UPDATE ejercicios SET nombre = 'Extensión de tríceps en polea' WHERE nombre = 'Extension de triceps en polea'",
            "UPDATE ejercicios SET nombre = 'Patada de tríceps' WHERE nombre = 'Patada de triceps'",
            "UPDATE ejercicios SET nombre = 'Elevación de piernas colgado' WHERE nombre = 'Elevacion de piernas colgado'",
            "UPDATE ejercicios SET nombre = 'Bicicleta estática' WHERE nombre = 'Bicicleta estatica'",
            "UPDATE ejercicios SET nombre = 'Elíptica' WHERE nombre = 'Eliptica'",
            # Y LOS BASICOS QUE FALTABAN, hasta unos ocho o diez por grupo.
            #
            # EL "NOT EXISTS" NO ES ADORNO: la tabla de ejercicios no tiene el
            # nombre como unico, asi que sin el, alguien que ya se hubiera
            # creado a mano "Press cerrado" acabaria con dos filas iguales y sin
            # forma de saber cual es cual. Se compara en minusculas porque
            # "press cerrado" y "Press cerrado" son el mismo ejercicio.
            """
            INSERT INTO ejercicios (nombre, grupo, material, descanso, medida)
            SELECT column1, column2, column3, column4, column5
            FROM (VALUES
                ('Press declinado con barra', 'pecho', 'barra', 120, 'peso × repeticiones'),
                ('Press de banca con mancuernas', 'pecho', 'mancuernas', 120, 'peso × repeticiones'),
                ('Contractor de pecho', 'pecho', 'máquina', 75, 'peso × repeticiones'),
                ('Remo en T', 'espalda', 'barra', 120, 'peso × repeticiones'),
                ('Jalón con agarre neutro', 'espalda', 'polea', 90, 'peso × repeticiones'),
                ('Encogimientos de hombros', 'espalda', 'mancuernas', 75, 'peso × repeticiones'),
                ('Sentadilla frontal', 'pierna', 'barra', 180, 'peso × repeticiones'),
                ('Gemelo sentado', 'pierna', 'máquina', 60, 'peso × repeticiones'),
                ('Abductores en máquina', 'pierna', 'máquina', 60, 'peso × repeticiones'),
                ('Press Arnold', 'hombro', 'mancuernas', 120, 'peso × repeticiones'),
                ('Elevaciones laterales en polea', 'hombro', 'polea', 60, 'peso × repeticiones'),
                ('Remo al mentón', 'hombro', 'barra', 90, 'peso × repeticiones'),
                ('Curl concentrado', 'bíceps', 'mancuernas', 60, 'peso × repeticiones'),
                ('Curl inverso', 'bíceps', 'barra', 75, 'peso × repeticiones'),
                ('Curl en banco inclinado', 'bíceps', 'mancuernas', 75, 'peso × repeticiones'),
                ('Press cerrado', 'tríceps', 'barra', 120, 'peso × repeticiones'),
                ('Extensión sobre la cabeza', 'tríceps', 'mancuernas', 75, 'peso × repeticiones'),
                ('Extensión en polea con cuerda', 'tríceps', 'polea', 60, 'peso × repeticiones'),
                ('Fondos en máquina', 'tríceps', 'máquina', 90, 'peso × repeticiones'),
                ('Plancha lateral', 'core', 'peso corporal', 45, 'tiempo'),
                ('Crunch abdominal', 'core', 'peso corporal', 45, 'peso × repeticiones'),
                ('Giro ruso', 'core', 'peso corporal', 45, 'peso × repeticiones'),
                ('Elevación de piernas tumbado', 'core', 'peso corporal', 45, 'peso × repeticiones'),
                ('Cuerda de saltar', 'cardio', 'peso corporal', 0, 'tiempo'),
                ('Escaladora', 'cardio', 'máquina', 0, 'tiempo'),
                ('Caminata inclinada', 'cardio', 'máquina', 0, 'tiempo')
            )
            WHERE NOT EXISTS (
                SELECT 1 FROM ejercicios
                WHERE lower(ejercicios.nombre) = lower(column1)
            )
            """,
        ),
    ),

    Migracion(
        version=13,
        descripcion="el descanso se elige por ejercicio, en el plan y en el entreno",
        sentencias=(
            # EL DESCANSO LO ELIGE LA PERSONA, y lo pidio el usuario asi: "el
            # descanso no lo pones tu en el ejercicio, lo elige la persona; en
            # este ejercicio quiero descansar treinta segundos, en este un
            # minuto y medio".
            #
            # Hasta ahora venia de la ficha del ejercicio y era el mismo
            # siempre, lo hicieras el lunes pesado o el viernes suave. Ahora la
            # ficha solo aporta el valor de PARTIDA cuando anades el ejercicio a
            # un dia; a partir de ahi manda lo que digas en la rutina.
            #
            # EN LAS DOS TABLAS Y NO EN UNA. La sesion COPIA el descanso del
            # plan, igual que copia el peso y las repeticiones. Si en vez de
            # copiarlo lo fuera a buscar al plan cada vez, cambiar la rutina en
            # noviembre cambiaria tambien el descanso de un entreno de agosto; y
            # un entreno suelto, que no tiene plan detras, se quedaria sin
            # ningun descanso que consultar.
            #
            # -1 COMO "NO SE DIJO NADA". Con la columna a NOT NULL habria que
            # inventar un numero para las filas que ya existen, y ese numero
            # seria mentira: nadie lo eligio. Se deja NULL, y quien lea decide
            # que hacer con el hueco (usar el de la ficha del ejercicio).
            "ALTER TABLE rutina_ejercicios ADD COLUMN descanso INTEGER",
            "ALTER TABLE sesion_ejercicios ADD COLUMN descanso INTEGER",
            # LOS CHECK NO SE PUEDEN ANADIR CON ALTER TABLE en SQLite, asi que
            # el rango lo vigila el dominio (dominio/descanso.py) y lo
            # comprueban sus tests. Se dice aqui en vez de dejar creer que la
            # base lo esta protegiendo: media hora es el tope, y quien lo mete
            # es Python.
            #
            # SE RELLENA CON LO QUE YA HABIA en la ficha de cada ejercicio, para
            # que nadie se encuentre los descansos a cero de golpe. Los que
            # apunten a un ejercicio borrado se quedan en NULL, que es la
            # verdad: no hay ficha de donde sacarlo.
            """
            UPDATE rutina_ejercicios
            SET descanso = (
                SELECT e.descanso FROM ejercicios e
                WHERE e.id = rutina_ejercicios.ejercicio_id
            )
            WHERE ejercicio_id IS NOT NULL
            """,
            """
            UPDATE sesion_ejercicios
            SET descanso = (
                SELECT e.descanso FROM ejercicios e
                WHERE e.id = sesion_ejercicios.ejercicio_id
            )
            WHERE ejercicio_id IS NOT NULL
            """,
        ),
    ),

    Migracion(
        version=14,
        descripcion="la biblioteca completa: 253 ejercicios por grupo",
        sentencias=(
            # LA LISTA LA DIO EL USUARIO, grupo por grupo. Se ha metido entera
            # menos lo que no se podia etiquetar bien, y eso tambien lo decidio
            # el: "ignora esos ejercicios, solo los que la app ya entiende".
            #
            # QUE SE HA DEJADO FUERA Y POR QUE:
            #   - Todo lo de multipower, kettlebell, banda elastica, trineo,
            #     cuerdas de batalla y fitball. La aplicacion solo distingue
            #     barra, mancuernas, maquina, polea y peso corporal; meterlos
            #     con una etiqueta que no les corresponde haria que filtrar por
            #     "mancuernas" sacara kettlebells, y entonces el filtro deja de
            #     querer decir nada.
            #   - Los que venian repetidos dentro de la propia lista: chin-ups
            #     es dominadas supinas, T-bar row es el remo en T, ab wheel es
            #     la rueda abdominal. Dos fichas del mismo ejercicio partirian
            #     el progreso en dos mitades que no se suman nunca.
            #   - El jalon trasnuca, que el propio usuario desaconsejo.
            #
            # PRIMERO SE RENOMBRA Y DESPUES SE INSERTA. El orden importa: la
            # lista trae nombres mas precisos que los que habia ("Press de
            # banca" pasa a ser "Press de banca plano con barra"), y si se
            # insertara antes de renombrar quedarian los dos. Renombrando
            # primero, el NOT EXISTS de abajo ve el nombre nuevo y no duplica.
            #
            # Cada UPDATE lleva el nombre VIEJO en el WHERE: si ya lo habias
            # cambiado tu a mano, esa linea no encuentra nada y tu nombre se
            # queda como esta.
            "UPDATE ejercicios SET nombre = 'Press de banca plano con barra' WHERE nombre = 'Press de banca'",
            "UPDATE ejercicios SET nombre = 'Press de banca plano con mancuernas' WHERE nombre = 'Press de banca con mancuernas'",
            "UPDATE ejercicios SET nombre = 'Press de banca plano en máquina' WHERE nombre = 'Press de banca en máquina'",
            "UPDATE ejercicios SET nombre = 'Aperturas planas con mancuernas' WHERE nombre = 'Aperturas con mancuernas'",
            "UPDATE ejercicios SET nombre = 'Aperturas cruzadas en polea' WHERE nombre = 'Cruces en polea'",
            "UPDATE ejercicios SET nombre = 'Aperturas en peck deck' WHERE nombre = 'Contractor de pecho'",
            "UPDATE ejercicios SET nombre = 'Pullover en polea' WHERE nombre = 'Pull-over en polea'",
            "UPDATE ejercicios SET nombre = 'Dominadas pronas' WHERE nombre = 'Dominadas'",
            "UPDATE ejercicios SET nombre = 'Remo unilateral con mancuerna' WHERE nombre = 'Remo con mancuerna a una mano'",
            "UPDATE ejercicios SET nombre = 'Remo sentado en polea' WHERE nombre = 'Remo en polea baja'",
            "UPDATE ejercicios SET nombre = 'Jalón al pecho agarre ancho' WHERE nombre = 'Jalón al pecho'",
            "UPDATE ejercicios SET nombre = 'Jalón al pecho agarre neutro' WHERE nombre = 'Jalón con agarre neutro'",
            "UPDATE ejercicios SET nombre = 'Peso muerto convencional' WHERE nombre = 'Peso muerto'",
            "UPDATE ejercicios SET nombre = 'Press militar con barra' WHERE nombre = 'Press militar'",
            "UPDATE ejercicios SET nombre = 'Press militar con mancuernas' WHERE nombre = 'Press de hombro con mancuernas'",
            "UPDATE ejercicios SET nombre = 'Elevaciones laterales con mancuernas' WHERE nombre = 'Elevaciones laterales'",
            "UPDATE ejercicios SET nombre = 'Elevaciones frontales con mancuernas' WHERE nombre = 'Elevaciones frontales'",
            "UPDATE ejercicios SET nombre = 'Pájaros con mancuernas' WHERE nombre = 'Pájaro para deltoide posterior'",
            "UPDATE ejercicios SET nombre = 'Remo al mentón con barra' WHERE nombre = 'Remo al mentón'",
            "UPDATE ejercicios SET nombre = 'Encogimientos con mancuernas' WHERE nombre = 'Encogimientos de hombros'",
            "UPDATE ejercicios SET nombre = 'Curl con barra recta' WHERE nombre = 'Curl con barra'",
            "UPDATE ejercicios SET nombre = 'Curl predicador en máquina' WHERE nombre = 'Curl en banco Scott'",
            "UPDATE ejercicios SET nombre = 'Jalón de tríceps con barra recta' WHERE nombre = 'Extensión de tríceps en polea'",
            "UPDATE ejercicios SET nombre = 'Jalón de tríceps con cuerda' WHERE nombre = 'Extensión en polea con cuerda'",
            "UPDATE ejercicios SET nombre = 'Press francés con barra' WHERE nombre = 'Press francés'",
            "UPDATE ejercicios SET nombre = 'Extensión trasnuca con mancuerna' WHERE nombre = 'Extensión sobre la cabeza'",
            "UPDATE ejercicios SET nombre = 'Fondos en máquina asistida' WHERE nombre = 'Fondos en máquina'",
            "UPDATE ejercicios SET nombre = 'Press banca agarre cerrado' WHERE nombre = 'Press cerrado'",
            "UPDATE ejercicios SET nombre = 'Fondos entre bancos' WHERE nombre = 'Fondos en banco'",
            "UPDATE ejercicios SET nombre = 'Prensa inclinada' WHERE nombre = 'Prensa de piernas'",
            "UPDATE ejercicios SET nombre = 'Extensión de piernas' WHERE nombre = 'Extensión de cuádriceps'",
            "UPDATE ejercicios SET nombre = 'Zancadas' WHERE nombre = 'Zancadas con mancuernas'",
            "UPDATE ejercicios SET nombre = 'Curl femoral acostado' WHERE nombre = 'Curl femoral tumbado'",
            "UPDATE ejercicios SET nombre = 'Elevación de gemelos sentado' WHERE nombre = 'Gemelo sentado'",
            "UPDATE ejercicios SET nombre = 'Elevación de gemelos de pie' WHERE nombre = 'Elevación de gemelos'",
            "UPDATE ejercicios SET nombre = 'Hip thrust con barra' WHERE nombre = 'Hip thrust'",
            "UPDATE ejercicios SET nombre = 'Abducción en máquina' WHERE nombre = 'Abductores en máquina'",
            "UPDATE ejercicios SET nombre = 'Crunch clásico' WHERE nombre = 'Crunch abdominal'",
            "UPDATE ejercicios SET nombre = 'Elevación de piernas acostado' WHERE nombre = 'Elevación de piernas tumbado'",
            "UPDATE ejercicios SET nombre = 'Russian twists' WHERE nombre = 'Giro ruso'",
            "UPDATE ejercicios SET nombre = 'Plancha frontal' WHERE nombre = 'Plancha'",
            # DOS CAMBIOS DE GRUPO, siguiendo donde los coloco el usuario en su
            # lista. El grupo que pierden se queda como SECUNDARIO, que es lo
            # que de verdad pasa: unos fondos trabajan triceps y pecho.
            "UPDATE ejercicios SET grupo = 'tríceps', secundarios = 'pecho' WHERE nombre = 'Fondos en paralelas'",
            "UPDATE ejercicios SET grupo = 'hombro', secundarios = 'espalda' WHERE nombre = 'Encogimientos con mancuernas'",
            # Y LA LISTA ENTERA. El NOT EXISTS compara en minusculas: si ya
            # tenias creado a mano un "press frances con barra", se respeta el
            # tuyo con tus mayusculas y tu descanso, y no se mete otro igual.
            """
            INSERT INTO ejercicios
                (nombre, grupo, material, descanso, medida, secundarios)
            SELECT column1, column2, column3, column4, column5, column6
            FROM (VALUES
                ('Press de banca plano con barra', 'pecho', 'barra', 150, 'peso × repeticiones', ''),
                ('Press de banca plano con mancuernas', 'pecho', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Press de banca plano en máquina', 'pecho', 'máquina', 90, 'peso × repeticiones', ''),
                ('Press de banca inclinado con barra', 'pecho', 'barra', 150, 'peso × repeticiones', 'hombro'),
                ('Press inclinado con mancuernas', 'pecho', 'mancuernas', 120, 'peso × repeticiones', 'hombro'),
                ('Press inclinado en máquina', 'pecho', 'máquina', 90, 'peso × repeticiones', 'hombro'),
                ('Press declinado con barra', 'pecho', 'barra', 120, 'peso × repeticiones', ''),
                ('Press declinado con mancuernas', 'pecho', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Press en máquina convergente', 'pecho', 'máquina', 90, 'peso × repeticiones', ''),
                ('Press Hammer Strength', 'pecho', 'máquina', 90, 'peso × repeticiones', ''),
                ('Press unilateral en máquina', 'pecho', 'máquina', 75, 'peso × repeticiones', ''),
                ('Press sentado en máquina', 'pecho', 'máquina', 90, 'peso × repeticiones', ''),
                ('Aperturas planas con mancuernas', 'pecho', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Aperturas inclinadas con mancuernas', 'pecho', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Aperturas declinadas con mancuernas', 'pecho', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Aperturas en peck deck', 'pecho', 'máquina', 75, 'peso × repeticiones', ''),
                ('Aperturas en máquina', 'pecho', 'máquina', 75, 'peso × repeticiones', ''),
                ('Aperturas en polea de pie', 'pecho', 'polea', 75, 'peso × repeticiones', ''),
                ('Aperturas en polea desde arriba', 'pecho', 'polea', 75, 'peso × repeticiones', ''),
                ('Aperturas en polea desde abajo', 'pecho', 'polea', 75, 'peso × repeticiones', ''),
                ('Aperturas en polea a media altura', 'pecho', 'polea', 75, 'peso × repeticiones', ''),
                ('Aperturas cruzadas en polea', 'pecho', 'polea', 75, 'peso × repeticiones', ''),
                ('Aperturas unilaterales en polea', 'pecho', 'polea', 60, 'peso × repeticiones', ''),
                ('Flexiones clásicas', 'pecho', 'peso corporal', 75, 'peso × repeticiones', 'tríceps'),
                ('Flexiones abiertas', 'pecho', 'peso corporal', 75, 'peso × repeticiones', ''),
                ('Flexiones cerradas', 'pecho', 'peso corporal', 75, 'peso × repeticiones', 'tríceps'),
                ('Flexiones inclinadas', 'pecho', 'peso corporal', 75, 'peso × repeticiones', ''),
                ('Flexiones declinadas', 'pecho', 'peso corporal', 75, 'peso × repeticiones', 'hombro'),
                ('Flexiones con pies elevados', 'pecho', 'peso corporal', 75, 'peso × repeticiones', 'hombro'),
                ('Flexiones lastradas', 'pecho', 'peso corporal', 90, 'peso × repeticiones', 'tríceps'),
                ('Flexiones en paralelas', 'pecho', 'peso corporal', 90, 'peso × repeticiones', 'tríceps'),
                ('Flexiones con déficit', 'pecho', 'peso corporal', 75, 'peso × repeticiones', ''),
                ('Pullover con mancuerna', 'pecho', 'mancuernas', 90, 'peso × repeticiones', 'espalda'),
                ('Pullover con barra', 'pecho', 'barra', 90, 'peso × repeticiones', 'espalda'),
                ('Pullover en máquina', 'pecho', 'máquina', 75, 'peso × repeticiones', 'espalda'),
                ('Press con discos', 'pecho', 'barra', 60, 'peso × repeticiones', ''),
                ('Dominadas pronas', 'espalda', 'peso corporal', 150, 'peso × repeticiones', 'bíceps'),
                ('Dominadas supinas', 'espalda', 'peso corporal', 150, 'peso × repeticiones', 'bíceps'),
                ('Dominadas neutras', 'espalda', 'peso corporal', 150, 'peso × repeticiones', 'bíceps'),
                ('Dominadas abiertas', 'espalda', 'peso corporal', 150, 'peso × repeticiones', ''),
                ('Dominadas cerradas', 'espalda', 'peso corporal', 150, 'peso × repeticiones', 'bíceps'),
                ('Dominadas asistidas', 'espalda', 'máquina', 120, 'peso × repeticiones', 'bíceps'),
                ('Dominadas lastradas', 'espalda', 'peso corporal', 180, 'peso × repeticiones', 'bíceps'),
                ('Dominadas en máquina', 'espalda', 'máquina', 120, 'peso × repeticiones', 'bíceps'),
                ('Jalón al pecho agarre ancho', 'espalda', 'polea', 90, 'peso × repeticiones', ''),
                ('Jalón al pecho agarre cerrado', 'espalda', 'polea', 90, 'peso × repeticiones', 'bíceps'),
                ('Jalón al pecho agarre neutro', 'espalda', 'polea', 90, 'peso × repeticiones', 'bíceps'),
                ('Jalón al pecho agarre supino', 'espalda', 'polea', 90, 'peso × repeticiones', 'bíceps'),
                ('Jalón unilateral', 'espalda', 'polea', 75, 'peso × repeticiones', ''),
                ('Jalón con brazos rectos', 'espalda', 'polea', 60, 'peso × repeticiones', ''),
                ('Pullover en polea', 'espalda', 'polea', 75, 'peso × repeticiones', 'pecho'),
                ('Jalón en máquina convergente', 'espalda', 'máquina', 90, 'peso × repeticiones', ''),
                ('Remo con barra', 'espalda', 'barra', 150, 'peso × repeticiones', ''),
                ('Remo Pendlay', 'espalda', 'barra', 150, 'peso × repeticiones', ''),
                ('Remo Yates', 'espalda', 'barra', 150, 'peso × repeticiones', ''),
                ('Remo con mancuernas', 'espalda', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Remo unilateral con mancuerna', 'espalda', 'mancuernas', 90, 'peso × repeticiones', ''),
                ('Remo en banco inclinado', 'espalda', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Remo en máquina', 'espalda', 'máquina', 90, 'peso × repeticiones', ''),
                ('Remo Hammer', 'espalda', 'máquina', 90, 'peso × repeticiones', ''),
                ('Remo sentado en polea', 'espalda', 'polea', 90, 'peso × repeticiones', ''),
                ('Remo unilateral en polea', 'espalda', 'polea', 75, 'peso × repeticiones', ''),
                ('Remo en máquina con apoyo de pecho', 'espalda', 'máquina', 90, 'peso × repeticiones', ''),
                ('Remo landmine', 'espalda', 'barra', 120, 'peso × repeticiones', ''),
                ('Remo invertido', 'espalda', 'peso corporal', 90, 'peso × repeticiones', 'bíceps'),
                ('Remo con agarre amplio', 'espalda', 'barra', 120, 'peso × repeticiones', ''),
                ('Remo con agarre cerrado', 'espalda', 'barra', 120, 'peso × repeticiones', ''),
                ('Remo con agarre neutro', 'espalda', 'barra', 120, 'peso × repeticiones', ''),
                ('Remo con agarre supino', 'espalda', 'barra', 120, 'peso × repeticiones', 'bíceps'),
                ('Hiperextensiones', 'espalda', 'peso corporal', 75, 'peso × repeticiones', 'pierna'),
                ('Hiperextensiones con peso', 'espalda', 'peso corporal', 90, 'peso × repeticiones', 'pierna'),
                ('Hiperextensiones enfocadas al glúteo', 'espalda', 'peso corporal', 75, 'peso × repeticiones', 'pierna'),
                ('Peso muerto convencional', 'espalda', 'barra', 180, 'peso × repeticiones', 'pierna'),
                ('Peso muerto sumo', 'espalda', 'barra', 180, 'peso × repeticiones', 'pierna'),
                ('Peso muerto con mancuernas', 'espalda', 'mancuernas', 150, 'peso × repeticiones', 'pierna'),
                ('Peso muerto con trap bar', 'espalda', 'barra', 180, 'peso × repeticiones', 'pierna'),
                ('Buenos días', 'espalda', 'barra', 120, 'peso × repeticiones', 'pierna'),
                ('Press militar con barra', 'hombro', 'barra', 150, 'peso × repeticiones', 'tríceps'),
                ('Press militar de pie', 'hombro', 'barra', 150, 'peso × repeticiones', 'tríceps'),
                ('Press militar sentado', 'hombro', 'barra', 150, 'peso × repeticiones', 'tríceps'),
                ('Press militar con mancuernas', 'hombro', 'mancuernas', 120, 'peso × repeticiones', 'tríceps'),
                ('Press Arnold', 'hombro', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Press de hombro en máquina', 'hombro', 'máquina', 90, 'peso × repeticiones', ''),
                ('Press de hombro unilateral', 'hombro', 'mancuernas', 90, 'peso × repeticiones', ''),
                ('Push press', 'hombro', 'barra', 150, 'peso × repeticiones', 'pierna'),
                ('Elevaciones laterales con mancuernas', 'hombro', 'mancuernas', 60, 'peso × repeticiones', ''),
                ('Elevaciones laterales sentado', 'hombro', 'mancuernas', 60, 'peso × repeticiones', ''),
                ('Elevaciones laterales de pie', 'hombro', 'mancuernas', 60, 'peso × repeticiones', ''),
                ('Elevaciones laterales en polea', 'hombro', 'polea', 60, 'peso × repeticiones', ''),
                ('Elevación lateral unilateral en polea', 'hombro', 'polea', 60, 'peso × repeticiones', ''),
                ('Elevaciones laterales en máquina', 'hombro', 'máquina', 60, 'peso × repeticiones', ''),
                ('Elevaciones laterales inclinadas', 'hombro', 'mancuernas', 60, 'peso × repeticiones', ''),
                ('Elevaciones frontales con mancuernas', 'hombro', 'mancuernas', 60, 'peso × repeticiones', ''),
                ('Elevaciones frontales con barra', 'hombro', 'barra', 60, 'peso × repeticiones', ''),
                ('Elevaciones frontales con disco', 'hombro', 'barra', 60, 'peso × repeticiones', ''),
                ('Elevaciones frontales con cuerda', 'hombro', 'polea', 60, 'peso × repeticiones', ''),
                ('Elevaciones frontales en polea', 'hombro', 'polea', 60, 'peso × repeticiones', ''),
                ('Elevaciones frontales alternas', 'hombro', 'mancuernas', 60, 'peso × repeticiones', ''),
                ('Pájaros con mancuernas', 'hombro', 'mancuernas', 60, 'peso × repeticiones', 'espalda'),
                ('Pájaros sentado', 'hombro', 'mancuernas', 60, 'peso × repeticiones', 'espalda'),
                ('Pájaros inclinado', 'hombro', 'mancuernas', 60, 'peso × repeticiones', 'espalda'),
                ('Pájaros en máquina', 'hombro', 'máquina', 60, 'peso × repeticiones', 'espalda'),
                ('Reverse peck deck', 'hombro', 'máquina', 60, 'peso × repeticiones', 'espalda'),
                ('Aperturas posteriores en polea', 'hombro', 'polea', 60, 'peso × repeticiones', 'espalda'),
                ('Face pull', 'hombro', 'polea', 60, 'peso × repeticiones', 'espalda'),
                ('Remo al mentón con barra', 'hombro', 'barra', 90, 'peso × repeticiones', ''),
                ('Remo al mentón con polea', 'hombro', 'polea', 75, 'peso × repeticiones', ''),
                ('Remo al mentón con cuerda', 'hombro', 'polea', 75, 'peso × repeticiones', ''),
                ('Encogimientos para trapecio con barra', 'hombro', 'barra', 75, 'peso × repeticiones', 'espalda'),
                ('Encogimientos con mancuernas', 'hombro', 'mancuernas', 75, 'peso × repeticiones', 'espalda'),
                ('Encogimientos en máquina', 'hombro', 'máquina', 75, 'peso × repeticiones', 'espalda'),
                ('Curl con barra recta', 'bíceps', 'barra', 90, 'peso × repeticiones', ''),
                ('Curl con barra EZ', 'bíceps', 'barra', 90, 'peso × repeticiones', ''),
                ('Curl con mancuernas', 'bíceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Curl alterno', 'bíceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Curl simultáneo', 'bíceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Curl martillo', 'bíceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Curl martillo con cuerda', 'bíceps', 'polea', 60, 'peso × repeticiones', ''),
                ('Curl martillo cruzado', 'bíceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Curl en polea', 'bíceps', 'polea', 60, 'peso × repeticiones', ''),
                ('Curl en máquina', 'bíceps', 'máquina', 75, 'peso × repeticiones', ''),
                ('Curl unilateral en polea', 'bíceps', 'polea', 60, 'peso × repeticiones', ''),
                ('Curl concentrado', 'bíceps', 'mancuernas', 60, 'peso × repeticiones', ''),
                ('Curl predicador con barra', 'bíceps', 'barra', 75, 'peso × repeticiones', ''),
                ('Curl predicador con mancuerna', 'bíceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Curl predicador en máquina', 'bíceps', 'máquina', 75, 'peso × repeticiones', ''),
                ('Curl en banco inclinado', 'bíceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Curl araña', 'bíceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Drag curl', 'bíceps', 'barra', 75, 'peso × repeticiones', ''),
                ('Bayesian curl en polea', 'bíceps', 'polea', 60, 'peso × repeticiones', ''),
                ('Curl inverso', 'bíceps', 'barra', 75, 'peso × repeticiones', ''),
                ('Curl con agarre neutro', 'bíceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Curl sentado', 'bíceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Jalón de tríceps con barra recta', 'tríceps', 'polea', 60, 'peso × repeticiones', ''),
                ('Jalón de tríceps con barra EZ', 'tríceps', 'polea', 60, 'peso × repeticiones', ''),
                ('Jalón de tríceps con cuerda', 'tríceps', 'polea', 60, 'peso × repeticiones', ''),
                ('Jalón de tríceps con agarre invertido', 'tríceps', 'polea', 60, 'peso × repeticiones', ''),
                ('Jalón de tríceps unilateral', 'tríceps', 'polea', 60, 'peso × repeticiones', ''),
                ('Jalón de tríceps unilateral cruzado', 'tríceps', 'polea', 60, 'peso × repeticiones', ''),
                ('Extensión por encima de la cabeza con cuerda', 'tríceps', 'polea', 60, 'peso × repeticiones', ''),
                ('Extensión trasnuca en polea', 'tríceps', 'polea', 60, 'peso × repeticiones', ''),
                ('Extensión unilateral por encima de la cabeza', 'tríceps', 'mancuernas', 60, 'peso × repeticiones', ''),
                ('Press francés con barra', 'tríceps', 'barra', 90, 'peso × repeticiones', ''),
                ('Press francés con barra EZ', 'tríceps', 'barra', 90, 'peso × repeticiones', ''),
                ('Press francés con mancuernas', 'tríceps', 'mancuernas', 90, 'peso × repeticiones', ''),
                ('Press francés unilateral', 'tríceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Extensión trasnuca con mancuerna', 'tríceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Extensión trasnuca con dos manos', 'tríceps', 'mancuernas', 75, 'peso × repeticiones', ''),
                ('Extensión trasnuca con barra', 'tríceps', 'barra', 75, 'peso × repeticiones', ''),
                ('Skull crushers', 'tríceps', 'barra', 90, 'peso × repeticiones', ''),
                ('JM press', 'tríceps', 'barra', 90, 'peso × repeticiones', ''),
                ('Fondos en paralelas', 'tríceps', 'peso corporal', 120, 'peso × repeticiones', 'pecho'),
                ('Fondos en máquina asistida', 'tríceps', 'máquina', 90, 'peso × repeticiones', 'pecho'),
                ('Fondos lastrados', 'tríceps', 'peso corporal', 150, 'peso × repeticiones', 'pecho'),
                ('Press banca agarre cerrado', 'tríceps', 'barra', 120, 'peso × repeticiones', 'pecho'),
                ('Flexiones diamante', 'tríceps', 'peso corporal', 75, 'peso × repeticiones', 'pecho'),
                ('Fondos entre bancos', 'tríceps', 'peso corporal', 75, 'peso × repeticiones', ''),
                ('Extensión de tríceps en máquina', 'tríceps', 'máquina', 75, 'peso × repeticiones', ''),
                ('Press de tríceps en máquina', 'tríceps', 'máquina', 75, 'peso × repeticiones', ''),
                ('Extensión unilateral en máquina', 'tríceps', 'máquina', 60, 'peso × repeticiones', ''),
                ('Sentadilla con barra', 'pierna', 'barra', 180, 'peso × repeticiones', ''),
                ('Sentadilla trasera', 'pierna', 'barra', 180, 'peso × repeticiones', ''),
                ('Sentadilla frontal', 'pierna', 'barra', 180, 'peso × repeticiones', ''),
                ('Sentadilla alta', 'pierna', 'barra', 180, 'peso × repeticiones', ''),
                ('Sentadilla low bar', 'pierna', 'barra', 180, 'peso × repeticiones', ''),
                ('Sentadilla sumo', 'pierna', 'barra', 180, 'peso × repeticiones', ''),
                ('Sentadilla goblet', 'pierna', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Sentadilla con pausa', 'pierna', 'barra', 180, 'peso × repeticiones', ''),
                ('Sentadilla búlgara', 'pierna', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Pistol squat', 'pierna', 'peso corporal', 120, 'peso × repeticiones', ''),
                ('Sissy squat', 'pierna', 'peso corporal', 90, 'peso × repeticiones', ''),
                ('Prensa horizontal', 'pierna', 'máquina', 120, 'peso × repeticiones', ''),
                ('Prensa inclinada', 'pierna', 'máquina', 120, 'peso × repeticiones', ''),
                ('Prensa vertical', 'pierna', 'máquina', 120, 'peso × repeticiones', ''),
                ('Hack squat', 'pierna', 'máquina', 150, 'peso × repeticiones', ''),
                ('Hack squat invertida', 'pierna', 'máquina', 150, 'peso × repeticiones', ''),
                ('Pendulum squat', 'pierna', 'máquina', 150, 'peso × repeticiones', ''),
                ('Belt squat', 'pierna', 'máquina', 150, 'peso × repeticiones', ''),
                ('Extensión de piernas', 'pierna', 'máquina', 90, 'peso × repeticiones', ''),
                ('Extensión unilateral de piernas', 'pierna', 'máquina', 75, 'peso × repeticiones', ''),
                ('Zancadas', 'pierna', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Zancadas caminando', 'pierna', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Zancadas hacia atrás', 'pierna', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Zancadas laterales', 'pierna', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Step-up al banco', 'pierna', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Curl femoral acostado', 'pierna', 'máquina', 90, 'peso × repeticiones', ''),
                ('Curl femoral sentado', 'pierna', 'máquina', 90, 'peso × repeticiones', ''),
                ('Curl femoral de pie', 'pierna', 'máquina', 75, 'peso × repeticiones', ''),
                ('Curl femoral unilateral', 'pierna', 'máquina', 75, 'peso × repeticiones', ''),
                ('Peso muerto rumano', 'pierna', 'barra', 150, 'peso × repeticiones', 'espalda'),
                ('Peso muerto rumano con mancuernas', 'pierna', 'mancuernas', 150, 'peso × repeticiones', 'espalda'),
                ('Peso muerto a una pierna', 'pierna', 'mancuernas', 120, 'peso × repeticiones', 'espalda'),
                ('Peso muerto con piernas semirrígidas', 'pierna', 'barra', 150, 'peso × repeticiones', 'espalda'),
                ('Hip thrust con barra', 'pierna', 'barra', 120, 'peso × repeticiones', ''),
                ('Hip thrust en máquina', 'pierna', 'máquina', 120, 'peso × repeticiones', ''),
                ('Hip thrust con mancuerna', 'pierna', 'mancuernas', 120, 'peso × repeticiones', ''),
                ('Hip thrust unilateral', 'pierna', 'peso corporal', 90, 'peso × repeticiones', ''),
                ('Glute bridge', 'pierna', 'peso corporal', 90, 'peso × repeticiones', ''),
                ('Puente de glúteos con peso', 'pierna', 'barra', 90, 'peso × repeticiones', ''),
                ('Patada de glúteo en polea', 'pierna', 'polea', 75, 'peso × repeticiones', ''),
                ('Patada de glúteo en máquina', 'pierna', 'máquina', 75, 'peso × repeticiones', ''),
                ('Pull-through en polea', 'pierna', 'polea', 90, 'peso × repeticiones', ''),
                ('Aductores en máquina', 'pierna', 'máquina', 60, 'peso × repeticiones', ''),
                ('Aducción en polea', 'pierna', 'polea', 60, 'peso × repeticiones', ''),
                ('Aducción lateral con peso corporal', 'pierna', 'peso corporal', 60, 'peso × repeticiones', ''),
                ('Abducción en máquina', 'pierna', 'máquina', 60, 'peso × repeticiones', ''),
                ('Abducción en polea', 'pierna', 'polea', 60, 'peso × repeticiones', ''),
                ('Abducción de pie', 'pierna', 'peso corporal', 60, 'peso × repeticiones', ''),
                ('Abducción acostado', 'pierna', 'peso corporal', 60, 'peso × repeticiones', ''),
                ('Elevación de gemelos de pie', 'pierna', 'máquina', 60, 'peso × repeticiones', ''),
                ('Elevación de gemelos sentado', 'pierna', 'máquina', 60, 'peso × repeticiones', ''),
                ('Elevación de gemelos unilateral', 'pierna', 'peso corporal', 60, 'peso × repeticiones', ''),
                ('Elevación de gemelos en prensa', 'pierna', 'máquina', 60, 'peso × repeticiones', ''),
                ('Elevación de gemelos con mancuerna', 'pierna', 'mancuernas', 60, 'peso × repeticiones', ''),
                ('Donkey calf raise', 'pierna', 'máquina', 60, 'peso × repeticiones', ''),
                ('Crunch clásico', 'core', 'peso corporal', 45, 'peso × repeticiones', ''),
                ('Crunch en máquina', 'core', 'máquina', 45, 'peso × repeticiones', ''),
                ('Crunch en polea', 'core', 'polea', 45, 'peso × repeticiones', ''),
                ('Crunch con cuerda', 'core', 'polea', 45, 'peso × repeticiones', ''),
                ('Crunch declinado', 'core', 'peso corporal', 45, 'peso × repeticiones', ''),
                ('Crunch con disco', 'core', 'barra', 45, 'peso × repeticiones', ''),
                ('Crunch invertido', 'core', 'peso corporal', 45, 'peso × repeticiones', ''),
                ('Elevación de piernas acostado', 'core', 'peso corporal', 45, 'peso × repeticiones', ''),
                ('Elevación de piernas en banco', 'core', 'peso corporal', 45, 'peso × repeticiones', ''),
                ('Elevación de piernas colgado', 'core', 'peso corporal', 60, 'peso × repeticiones', ''),
                ('Elevación de rodillas colgado', 'core', 'peso corporal', 60, 'peso × repeticiones', ''),
                ('Toes to bar', 'core', 'peso corporal', 60, 'peso × repeticiones', ''),
                ('Russian twists', 'core', 'peso corporal', 45, 'peso × repeticiones', ''),
                ('Woodchoppers en polea', 'core', 'polea', 45, 'peso × repeticiones', ''),
                ('Giros en polea', 'core', 'polea', 45, 'peso × repeticiones', ''),
                ('Side bends con mancuerna', 'core', 'mancuernas', 45, 'peso × repeticiones', ''),
                ('Side bends en polea', 'core', 'polea', 45, 'peso × repeticiones', ''),
                ('Plancha frontal', 'core', 'peso corporal', 45, 'tiempo', ''),
                ('Plancha lateral', 'core', 'peso corporal', 45, 'tiempo', ''),
                ('Plancha con peso', 'core', 'peso corporal', 45, 'tiempo', ''),
                ('Dead bug', 'core', 'peso corporal', 45, 'peso × repeticiones', ''),
                ('Bird dog', 'core', 'peso corporal', 45, 'peso × repeticiones', ''),
                ('Rueda abdominal', 'core', 'peso corporal', 60, 'peso × repeticiones', ''),
                ('Pallof press', 'core', 'polea', 45, 'peso × repeticiones', ''),
                ('Hollow hold', 'core', 'peso corporal', 45, 'tiempo', ''),
                ('Dragon flag', 'core', 'peso corporal', 60, 'peso × repeticiones', ''),
                ('Cinta de correr', 'cardio', 'máquina', 0, 'tiempo', ''),
                ('Bicicleta estática', 'cardio', 'máquina', 0, 'tiempo', ''),
                ('Bicicleta reclinada', 'cardio', 'máquina', 0, 'tiempo', ''),
                ('Air bike', 'cardio', 'máquina', 0, 'tiempo', ''),
                ('Elíptica', 'cardio', 'máquina', 0, 'tiempo', ''),
                ('Remo de cardio', 'cardio', 'máquina', 0, 'tiempo', ''),
                ('Escaladora', 'cardio', 'máquina', 0, 'tiempo', ''),
                ('Cuerda de saltar', 'cardio', 'peso corporal', 0, 'tiempo', ''),
                ('Caminata inclinada', 'cardio', 'máquina', 0, 'tiempo', ''),
                ('Burpees', 'cardio', 'peso corporal', 0, 'tiempo', ''),
                ('Mountain climbers', 'cardio', 'peso corporal', 0, 'tiempo', ''),
                ('Farmer''s walk', 'cardio', 'mancuernas', 60, 'tiempo', 'espalda')
            )
            WHERE NOT EXISTS (
                SELECT 1 FROM ejercicios
                WHERE lower(ejercicios.nombre) = lower(column1)
            )
            """,
        ),
    ),

    Migracion(
        version=15,
        descripcion="el plan guarda cuanto dura un ejercicio de tiempo",
        sentencias=(
            # LO PIDIO EL USUARIO viendo la fila de "Caminata inclinada": "al
            # ser cardio no va serie, peso, etc.; solo pones el tiempo, tipo 30
            # min". Tenia razon: la aplicacion ya sabia desde el principio que
            # hay ejercicios que se miden en TIEMPO (la plancha, el cardio),
            # pero el plan no tenia donde guardar cuanto duran, asi que la
            # pantalla ensenaba peso y repeticiones para correr en la cinta.
            #
            # UNA COLUMNA NUEVA Y NO REAPROVECHAR "repeticiones_objetivo". Es
            # tentador: son dos numeros y ahi cabe. Pero eso es exactamente el
            # fallo del que ya se aprendio en Inversiones, cuando una columna
            # llamada "Cantidad" recibio euros en vez de participaciones y la
            # pantalla dijo 49.959 EUR donde habia 761. Una columna que se llama
            # repeticiones y guarda segundos miente, y el dia que alguien sume
            # "repeticiones totales" saldra un numero sin sentido.
            #
            # NULL COMO "AQUI NO SE DIJO NADA", igual que el descanso: las filas
            # que ya existen no tienen duracion elegida, y ponerles un numero
            # seria inventarselo. Quien lea decide que hacer con el hueco.
            "ALTER TABLE rutina_ejercicios ADD COLUMN segundos_objetivo INTEGER",
            # EL RANGO LO VIGILA EL DOMINIO. SQLite no deja anadir un CHECK con
            # ALTER TABLE, asi que el tope de cuatro horas lo pone
            # dominio/descanso.py y lo comprueban sus tests. Se dice aqui en vez
            # de dejar creer que la base lo esta protegiendo.
            #
            # A LOS DE TIEMPO QUE YA ESTABAN SE LES PONE UN PUNTO DE PARTIDA
            # razonable segun lo que sean, porque un cero en pantalla se lee
            # como "no has puesto nada" y obligaria a rellenarlos todos a mano:
            #   - cardio: veinte minutos, que es una sesion normal.
            #   - lo demas de tiempo (planchas): cuarenta y cinco segundos.
            # Son SUGERENCIAS y se cambian escribiendo encima; no hay ninguna
            # cuenta que dependa de ellas.
            """
            UPDATE rutina_ejercicios
            SET segundos_objetivo = 20 * 60
            WHERE segundos_objetivo IS NULL
              AND ejercicio_id IN (
                SELECT id FROM ejercicios
                WHERE medida = 'tiempo' AND grupo = 'cardio'
              )
            """,
            """
            UPDATE rutina_ejercicios
            SET segundos_objetivo = 45
            WHERE segundos_objetivo IS NULL
              AND ejercicio_id IN (
                SELECT id FROM ejercicios
                WHERE medida = 'tiempo' AND grupo <> 'cardio'
              )
            """,
        ),
    ),

    Migracion(
        version=16,
        descripcion="cada movimiento recuerda a que moneda se convirtio",
        sentencias=(
            # EL FALLO QUE ARREGLA, y se descubrio probando justo lo que pidio el
            # usuario: apuntar treinta euros, cambiar la moneda principal a
            # dolares y apuntar cincuenta dolares.
            #
            # Un movimiento guardaba su "importe_principal" —el importe ya
            # convertido— pero NO guardaba a que moneda lo habia convertido. Con
            # una sola moneda principal en toda la vida de la aplicacion eso daba
            # igual. En cuanto se puede cambiar, deja de darlo: los treinta euros
            # se seguian sumando como si fueran treinta DOLARES, y el total decia
            # un numero que no era, sin dar ningun error.
            #
            # No es un fallo de cuentas: es que faltaba un dato. La cuenta estaba
            # bien hecha para una moneda que ya no es la de ahora.
            "ALTER TABLE movimientos ADD COLUMN moneda_principal TEXT",
            # SE RELLENA SOLO LO QUE SE SABE CON CERTEZA. Una tasa de 1 quiere
            # decir que el movimiento se apunto EN la moneda principal de aquel
            # dia, sea cual fuera: si un gasto en euros tiene tasa 1, la
            # principal era el euro. Eso es un hecho, no una suposicion.
            """
            UPDATE movimientos
            SET moneda_principal = moneda
            WHERE tasa = '1' AND moneda_principal IS NULL
            """,
            # LOS DEMAS SE QUEDAN EN NULL A PROPOSITO, y esto es lo importante:
            # de un movimiento con tasa distinta de 1 no se puede saber hoy a que
            # moneda se convirtio. Rellenarlo con "EUR" porque era lo habitual
            # seria inventarse un dato para que las cuentas cuadren, que es
            # exactamente como se falsea un balance sin querer.
            #
            # Y LOS QUE QUEDEN CON IMPORTE CONVERTIDO PERO SIN MONEDA vuelven a
            # estar PENDIENTES. Es la parte incomoda de esto y hay que decirla:
            # se pierde una tasa que el usuario habia dejado guardada.
            #
            # Se hace igual porque un importe convertido del que no se sabe a que
            # moneda NO ES INFORMACION: es un numero sin unidad. Guardarlo tal
            # cual obligaria a que el resto del programa conviviera para siempre
            # con importes que no se pueden sumar a nada, y la primera vez que
            # alguien se despistara volveria el fallo de sumar euros dentro de un
            # total en dolares.
            #
            # Marcado como pendiente, el movimiento sigue entero —su importe y su
            # moneda no se tocan— y la pantalla lo ensena en la lista de "falta
            # resolver esto", que es la verdad.
            #
            # EN LA PRACTICA ESTO NO TOCA NINGUNA FILA: la unica forma de tener
            # una tasa distinta de 1 es resolver un cambio a mano, y esa parte
            # todavia no existe en la aplicacion. Se escribe igual porque una
            # migracion tiene que ser correcta para cualquier base, no solo para
            # la que se tiene delante hoy.
            """
            UPDATE movimientos
            SET tasa = NULL, importe_principal = NULL
            WHERE moneda_principal IS NULL AND importe_principal IS NOT NULL
            """,
        ),
    ),

    Migracion(
        version=17,
        descripcion="las comidas del dia las elige el usuario",
        sentencias=(
            # LO PIDIO EL USUARIO ASI: "pone una opcion de agregar comida, ya que
            # por ejemplo yo que estoy en volumen a veces hago dos desayunos y no
            # quiero poner desayuno desayuno; solo pone una opcion para agregar
            # comida y el nombre lo elige el usuario".
            #
            # Tiene razon y el fallo era de diseno: las cuatro comidas estaban
            # clavadas en el codigo Y en un CHECK de la base. Quien hace cinco
            # comidas, o dos desayunos, no cabia.
            "CREATE TABLE tipos_de_comida ("
            " id INTEGER PRIMARY KEY,"
            " nombre TEXT NOT NULL,"
            " orden INTEGER NOT NULL DEFAULT 0,"
            " CHECK (length(trim(nombre)) > 0),"
            " CHECK (orden >= 0)"
            ") STRICT",
            # SIN REPETIDOS Y SIN DISTINGUIR MAYUSCULAS: "Desayuno" y "desayuno"
            # son la misma comida, y tenerlas las dos partiria el dia en dos
            # grupos que dicen lo mismo.
            "CREATE UNIQUE INDEX tipos_de_comida_sin_repetir "
            "ON tipos_de_comida (lower(nombre))",
            # Las cuatro de siempre, EN EL ORDEN DEL DIA y no alfabetico: es
            # como se lee un dia de comidas. El hueco de diez en diez deja
            # meter una nueva en medio sin renumerar las demas.
            "INSERT INTO tipos_de_comida (nombre, orden) VALUES "
            "('desayuno', 10), ('comida', 20), ('cena', 30), ('snack', 40)",
            # ------------------------------------------------------------------
            # Y AHORA LA PARTE DELICADA: quitar el CHECK que solo dejaba esos
            # cuatro nombres.
            #
            # SQLite NO SABE quitar un CHECK. La unica forma es construir la
            # tabla otra vez sin el, copiar las filas y cambiar los nombres. Es
            # el procedimiento que recomienda la propia documentacion de SQLite,
            # y se hace por pasos para que cada sentencia sea una sola cosa.
            #
            # NO SE PIERDE NADA: se copian todas las columnas de todas las filas.
            # Lo unico que cambia es que la tabla nueva acepta cualquier nombre
            # de comida, que es justo lo que se pedia.
            """
            CREATE TABLE comidas_nueva (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                comida TEXT NOT NULL,
                jornada TEXT NOT NULL,
                momento TEXT NOT NULL,
                cantidad TEXT NOT NULL DEFAULT '',
                unidad TEXT NOT NULL DEFAULT '',
                kcal INTEGER NOT NULL DEFAULT 0,
                proteinas INTEGER NOT NULL DEFAULT 0,
                carbohidratos INTEGER NOT NULL DEFAULT 0,
                grasas INTEGER NOT NULL DEFAULT 0,
                CHECK (length(trim(nombre)) > 0),
                -- El CHECK de "comida" ya no lista nombres: solo exige que haya
                -- alguno. Que sea uno de los que existen lo vigila el dominio,
                -- que es quien puede consultar la tabla de tipos.
                CHECK (length(trim(comida)) > 0),
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK (kcal >= 0 AND kcal <= 20000),
                CHECK (proteinas >= 0 AND proteinas <= 100000),
                CHECK (carbohidratos >= 0 AND carbohidratos <= 100000),
                CHECK (grasas >= 0 AND grasas <= 100000)
            ) STRICT
            """,
            """
            INSERT INTO comidas_nueva
                (id, nombre, comida, jornada, momento, cantidad, unidad,
                 kcal, proteinas, carbohidratos, grasas)
            SELECT id, nombre, comida, jornada, momento, cantidad, unidad,
                 kcal, proteinas, carbohidratos, grasas
            FROM comidas
            """,
            "DROP TABLE comidas",
            "ALTER TABLE comidas_nueva RENAME TO comidas",
            # LOS INDICES SE VAN CON LA TABLA VIEJA y hay que rehacerlos. Sin
            # esto la aplicacion funcionaria igual, solo que mas lenta cada dia
            # que pasara, y nadie relacionaria una cosa con la otra.
            "CREATE INDEX comidas_por_jornada ON comidas (jornada)",
            "CREATE INDEX comidas_por_nombre ON comidas (nombre)",
        ),
    ),
    Migracion(
        version=18,
        descripcion="el horario semanal, la rejilla de horas por dias",
        sentencias=(
            # LO PIDIO EL USUARIO senalando su pizarra: una rejilla de horas por
            # dias, "todo a mano, como la hoja de papel". La aplicacion no
            # propone nada ahi dentro; solo guarda lo que el escriba.
            #
            # SOLO SE GUARDAN LAS CASILLAS CON TEXTO. Siete dias por diecisiete
            # horas son 119 casillas, y casi todas estaran en blanco siempre.
            # Guardar 119 filas vacias para que sigan vacias no aporta nada, y
            # vaciar una casilla es simplemente borrar su fila.
            "CREATE TABLE horario_semanal ("
            " id INTEGER PRIMARY KEY,"
            " dia INTEGER NOT NULL,"
            " hora INTEGER NOT NULL,"
            " texto TEXT NOT NULL,"
            # 0 = lunes ... 6 = domingo, igual que date.weekday() de Python.
            " CHECK (dia >= 0 AND dia <= 6),"
            " CHECK (hora >= 0 AND hora <= 23),"
            " CHECK (length(trim(texto)) > 0),"
            " CHECK (length(texto) <= 120)"
            ") STRICT",
            # UNA CASILLA POR SITIO. Sin esto, dos guardados seguidos de la
            # misma casilla dejarian dos filas y la rejilla ensenaria una u
            # otra segun el orden de lectura, que es de los fallos mas dificiles
            # de reproducir que existen.
            "CREATE UNIQUE INDEX horario_semanal_casilla "
            "ON horario_semanal (dia, hora)",
        ),
    ),
    Migracion(
        version=19,
        descripcion="las casillas del horario pueden ir pintadas de un color",
        sentencias=(
            # LO PIDIO EL USUARIO: "que se puedan poner los cuadrados de colores
            # y/o las letras, para que sea mas visible; colores pasteles, no muy
            # fuertes".
            #
            # HAY QUE RECONSTRUIR LA TABLA y no basta con un ALTER TABLE, porque
            # ademas de la columna nueva hay que RELAJAR una regla: la tabla
            # exigia que toda casilla tuviera texto, y ahora una casilla puede
            # llevar solo color y ninguna letra. SQLite no sabe quitar un CHECK.
            #
            # La tabla se creo en la migracion 18, en esta misma tanda, asi que
            # para el usuario esta vacia y no hay nada que perder. Aun asi se
            # copian las filas: la regla del proyecto es que una migracion no da
            # por hecho lo que hay dentro.
            """
            CREATE TABLE horario_semanal_nueva (
                id INTEGER PRIMARY KEY,
                dia INTEGER NOT NULL,
                hora INTEGER NOT NULL,
                texto TEXT NOT NULL DEFAULT '',
                -- El color se guarda por su NOMBRE ("verde"), no por su tono.
                -- Cadena vacia = sin pintar. El tono exacto vive en
                -- interfaz/estilo.py, que es el unico sitio donde se escriben
                -- colores, y asi el mismo "verde" puede pintarse distinto en el
                -- modo claro y en el oscuro sin tocar ni un dato.
                color TEXT NOT NULL DEFAULT '',
                CHECK (dia >= 0 AND dia <= 6),
                CHECK (hora >= 0 AND hora <= 23),
                CHECK (length(texto) <= 120),
                -- TEXTO O COLOR, PERO ALGO: una casilla sin lo uno ni lo otro
                -- no se ve en la rejilla, asi que guardarla seria guardar una
                -- fila que no significa nada.
                CHECK (length(trim(texto)) > 0 OR length(color) > 0),
                -- NO SE LISTAN LOS COLORES AQUI a proposito, y esto es una
                -- leccion aprendida a golpes: las cuatro comidas del dia
                -- estaban listadas en un CHECK igual que este, y para poder
                -- anadir una quinta hubo que reconstruir la tabla entera. Que
                -- el nombre sea uno de los seis lo comprueba el dominio, que es
                -- quien tiene la lista; aqui solo se acota el largo para que no
                -- entre cualquier cosa.
                CHECK (length(color) <= 20)
            ) STRICT
            """,
            """
            INSERT INTO horario_semanal_nueva (id, dia, hora, texto, color)
            SELECT id, dia, hora, texto, '' FROM horario_semanal
            """,
            "DROP TABLE horario_semanal",
            "ALTER TABLE horario_semanal_nueva RENAME TO horario_semanal",
            # El indice se va con la tabla vieja y hay que rehacerlo. Sin el,
            # dos guardados de la misma casilla dejarian dos filas.
            "CREATE UNIQUE INDEX horario_semanal_casilla "
            "ON horario_semanal (dia, hora)",
        ),
    ),
    Migracion(
        version=20,
        descripcion="cada casilla del horario puede llevar una nota",
        sentencias=(
            # LO PIDIO EL USUARIO: "puedo poner una nota, tipo como la de los
            # gastos". La casilla de la rejilla es pequena y solo ensena el
            # texto; la nota es el detalle que no cabe ahi.
            #
            # AQUI SI BASTA UN ALTER TABLE, al reves que en las dos migraciones
            # anteriores: solo se anade una columna y no hay que quitar ninguna
            # regla, asi que no hace falta reconstruir la tabla. Reconstruir
            # cuando no toca es trabajo y riesgo a cambio de nada.
            #
            # EL LARGO DE LA NOTA LO VIGILA SOLO EL DOMINIO, y conviene decirlo:
            # SQLite no sabe anadir un CHECK a una tabla que ya existe sin
            # reconstruirla entera, y reconstruir una tabla para protegerse de
            # una nota larga no sale a cuenta. El resto de reglas de la casilla
            # —que tenga texto o color, que el dia y la hora existan— siguen
            # estando en la tabla como segunda linea de defensa.
            "ALTER TABLE horario_semanal "
            "ADD COLUMN nota TEXT NOT NULL DEFAULT ''",
        ),
    ),
    Migracion(
        version=21,
        descripcion="antebrazo y movilidad, con sus ejercicios",
        sentencias=(
            # LO PIDIO EL USUARIO: "tambien falta ejercicios de Antebrazo y
            # estiramientos y movilidad". Y no habia donde meterlos: la tabla
            # solo admitia los ocho grupos de siempre.
            #
            # HAY QUE RECONSTRUIR LA TABLA porque los grupos estan en un CHECK y
            # SQLite no sabe quitar un CHECK. Es la tercera vez que pasa en este
            # proyecto —las comidas, los colores del horario y ahora esto— y la
            # leccion ya esta escrita en la migracion 19: no meter listas
            # cerradas en un CHECK si pueden crecer.
            #
            # AQUI SE MANTIENE CERRADA aun asi, y a proposito: los grupos si son
            # una lista fija de verdad, y tenerla abierta acabaria con "pierna",
            # "piernas" y "Pierna" como tres grupos distintos. Eso romperia la
            # pantalla de "que estoy descuidando", que es de las utiles.
            """
            CREATE TABLE ejercicios_nueva (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                grupo TEXT NOT NULL,
                material TEXT NOT NULL,
                secundarios TEXT NOT NULL DEFAULT '',
                descanso INTEGER NOT NULL DEFAULT 90,
                notas TEXT NOT NULL DEFAULT '',
                medida TEXT NOT NULL DEFAULT 'peso × repeticiones',
                CHECK (length(trim(nombre)) > 0),
                CHECK (grupo IN ('pecho', 'espalda', 'pierna', 'hombro',
                                 'bíceps', 'tríceps', 'antebrazo', 'core',
                                 'cardio', 'movilidad')),
                CHECK (material IN ('barra', 'mancuernas', 'máquina', 'polea',
                                    'peso corporal')),
                CHECK (medida IN ('peso × repeticiones', 'tiempo')),
                CHECK (descanso BETWEEN 0 AND 1800)
            ) STRICT
            """,
            """
            INSERT INTO ejercicios_nueva
                (id, nombre, grupo, material, secundarios, descanso, notas, medida)
            SELECT id, nombre, grupo, material, secundarios, descanso, notas, medida
            FROM ejercicios
            """,
            "DROP TABLE ejercicios",
            "ALTER TABLE ejercicios_nueva RENAME TO ejercicios",
            # LOS DE MOVILIDAD SE MIDEN EN TIEMPO, no en repeticiones: un
            # estiramiento se sostiene treinta segundos, y contar
            # "repeticiones" de una paloma no significa nada. Y su descanso es
            # de 30 segundos, no de 90: entre estiramientos no se descansa
            # igual que entre series de banca.
            #
            # NO SE PISA LO QUE EL USUARIO YA TENGA: si alguien ya se habia
            # creado a mano un "Curl de muñeca", el suyo se queda y este no
            # entra. Se compara sin mayusculas para que "curl de muñeca" y
            # "Curl de Muñeca" no acaben siendo dos.
            """
            INSERT INTO ejercicios (nombre, grupo, material, descanso, medida)
            SELECT column1, column2, column3, column4, column5
            FROM (VALUES
            ('Curl de muñeca con barra', 'antebrazo', 'barra', 90, 'peso × repeticiones'),
            ('Curl de muñeca inverso con barra', 'antebrazo', 'barra', 90, 'peso × repeticiones'),
            ('Curl de muñeca con mancuernas', 'antebrazo', 'mancuernas', 90, 'peso × repeticiones'),
            ('Curl inverso con barra', 'antebrazo', 'barra', 90, 'peso × repeticiones'),
            ('Curl inverso con mancuernas', 'antebrazo', 'mancuernas', 90, 'peso × repeticiones'),
            ('Rodillo de muñeca', 'antebrazo', 'peso corporal', 90, 'peso × repeticiones'),
            ('Paseo del granjero', 'antebrazo', 'mancuernas', 90, 'peso × repeticiones'),
            ('Pinza con discos', 'antebrazo', 'peso corporal', 90, 'peso × repeticiones'),
            ('Extensión de muñeca en polea', 'antebrazo', 'polea', 90, 'peso × repeticiones'),
            ('Curl de muñeca en banco', 'antebrazo', 'mancuernas', 90, 'peso × repeticiones'),
            ('Gato-camello', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Perro boca abajo', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Postura del niño', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Paloma', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Mariposa (aductores)', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Zancada baja (psoas)', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Rotación torácica en cuadrupedia', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Dislocaciones de hombro con banda', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Estiramiento de pectoral en marco de puerta', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Estiramiento de dorsal colgado', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Estiramiento de isquiotibiales de pie', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Estiramiento de cuádriceps de pie', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Estiramiento de gemelo en pared', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Estiramiento de tríceps sobre la cabeza', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Sentadilla profunda sostenida', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('90/90 de cadera', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Círculos de cadera', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Movilidad de tobillo en pared', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Estiramiento de cuello lateral', 'movilidad', 'peso corporal', 30, 'tiempo'),
            ('Puente de glúteo sostenido', 'movilidad', 'peso corporal', 30, 'tiempo')
            )
            WHERE NOT EXISTS (
                SELECT 1 FROM ejercicios viejo
                WHERE lower(viejo.nombre) = lower(column1)
            )
            """,
        ),
    ),
    Migracion(
        version=22,
        descripcion="bloques por dia y series sueltas en la rutina",
        sentencias=(
            # DOS COSAS QUE PIDIO EL USUARIO Y QUE TOCAN LO MISMO, asi que van
            # juntas y no en dos migraciones: "el lunes es un apartado, no es
            # SOLO un entrenamiento; dentro de Lunes debo poder poner diferentes
            # entrenamientos tipo GYM, Movilidad..." y "las series pueden ser
            # distintas entre si: serie1 x reps x kg, serie2 x reps x kg".
            #
            # LA FORMA NUEVA ES dia -> bloques -> ejercicios -> series. Antes
            # era dia -> ejercicios, con "3 x 10 a 60 kg" metido en la propia
            # fila del ejercicio.
            #
            # EL ORDEN DE LAS SENTENCIAS DE AQUI NO ES CAPRICHOSO. Las claves
            # ajenas estan encendidas, asi que rutina_series no se puede crear
            # antes de que rutina_ejercicios exista con su nombre definitivo: se
            # apuntaria a una tabla que va a desaparecer en el DROP. Por eso las
            # series viejas se desdoblan primero en una tabla de paso, y
            # rutina_series se crea y se llena AL FINAL.
            """
            CREATE TABLE rutina_bloques (
                id INTEGER PRIMARY KEY,
                dia INTEGER NOT NULL REFERENCES rutina_dias (dia),
                nombre TEXT NOT NULL,
                orden INTEGER NOT NULL DEFAULT 0,
                CHECK (length(trim(nombre)) > 0),
                CHECK (dia BETWEEN 0 AND 6),
                CHECK (orden >= 0)
            ) STRICT
            """,
            # UN BLOQUE POR CADA DIA QUE TUVIERA ALGO. Los dias vacios no
            # reciben ninguno: un bloque vacio en pantalla es ruido, y en cuanto
            # se anada el primer ejercicio se creara solo.
            #
            # SE LLAMA "Entrenamiento" y no como el dia porque el nombre del dia
            # ya se ve arriba: un bloque llamado "Lunes" dentro del lunes no
            # dice nada. Se renombra en un clic.
            """
            INSERT INTO rutina_bloques (dia, nombre, orden)
            SELECT DISTINCT dia, 'Entrenamiento', 0 FROM rutina_ejercicios
            """,
            # LAS SERIES VIEJAS, DESDOBLADAS. "3 x 10 a 60 kg" eran tres series
            # iguales que nadie habia escrito; ahora se escriben. La tabla de
            # paso existe solo dentro de esta migracion.
            """
            CREATE TABLE _series_de_paso AS
            WITH RECURSIVE desdoblar(id, numero, total, reps, peso, segundos) AS (
                SELECT id, 1, series_objetivo, repeticiones_objetivo,
                       peso_objetivo, segundos_objetivo
                FROM rutina_ejercicios
                UNION ALL
                SELECT id, numero + 1, total, reps, peso, segundos
                FROM desdoblar WHERE numero < total
            )
            SELECT id, numero, reps, peso, segundos FROM desdoblar
            """,
            # LA TABLA DE EJERCICIOS, RECONSTRUIDA: ahora cuelga de un bloque y
            # no de un dia, y ya no lleva las series dentro.
            """
            CREATE TABLE rutina_ejercicios_nueva (
                id INTEGER PRIMARY KEY,
                bloque_id INTEGER NOT NULL
                    REFERENCES rutina_bloques (id) ON DELETE CASCADE,
                ejercicio_id INTEGER,
                nombre TEXT NOT NULL,
                orden INTEGER NOT NULL DEFAULT 0,
                descanso INTEGER,
                CHECK (length(trim(nombre)) > 0),
                CHECK (orden >= 0)
            ) STRICT
            """,
            # SE CONSERVA EL id DE CADA FILA a proposito: es a lo que van a
            # apuntar las series desdobladas. Si se dejara que SQLite los
            # renumerara, cada serie acabaria colgando de otro ejercicio.
            """
            INSERT INTO rutina_ejercicios_nueva
                (id, bloque_id, ejercicio_id, nombre, orden, descanso)
            SELECT viejo.id, bloque.id, viejo.ejercicio_id, viejo.nombre,
                   viejo.orden, viejo.descanso
            FROM rutina_ejercicios viejo
            JOIN rutina_bloques bloque ON bloque.dia = viejo.dia
            """,
            "DROP TABLE rutina_ejercicios",
            "ALTER TABLE rutina_ejercicios_nueva RENAME TO rutina_ejercicios",
            # AHORA SI: la tabla a la que apuntan ya existe y ya se llama como
            # se va a llamar para siempre.
            """
            CREATE TABLE rutina_series (
                id INTEGER PRIMARY KEY,
                rutina_ejercicio_id INTEGER NOT NULL
                    REFERENCES rutina_ejercicios (id) ON DELETE CASCADE,
                numero INTEGER NOT NULL,
                repeticiones INTEGER NOT NULL DEFAULT 10,
                peso INTEGER NOT NULL DEFAULT 0,
                segundos INTEGER,
                CHECK (numero >= 1),
                CHECK (repeticiones BETWEEN 0 AND 500),
                CHECK (peso BETWEEN 0 AND 100000),
                CHECK (segundos IS NULL OR segundos BETWEEN 0 AND 86400)
            ) STRICT
            """,
            """
            INSERT INTO rutina_series
                (rutina_ejercicio_id, numero, repeticiones, peso, segundos)
            SELECT id, numero, reps, peso, segundos FROM _series_de_paso
            """,
            "DROP TABLE _series_de_paso",
            # Buscar las series de un ejercicio es lo que se hace al pintar cada
            # dia de la rutina; sin indice serian siete recorridos de la tabla
            # entera cada vez que se abre el apartado.
            "CREATE INDEX IF NOT EXISTS idx_rutina_series_ejercicio "
            "ON rutina_series (rutina_ejercicio_id)",
            "CREATE INDEX IF NOT EXISTS idx_rutina_bloques_dia "
            "ON rutina_bloques (dia)",
        ),
    ),
    Migracion(
        version=23,
        descripcion="ahorro e inversion dejan de ser gastos",
        sentencias=(
            # LO PIDIO EL USUARIO con un ejemplo que decia todo: apartaba 500
            # euros para ahorrar y la aplicacion se los contaba como gasto de
            # transporte. "Se vera como que lo perdi, pero no lo perdi, porque
            # lo estoy ahorrando".
            #
            # HAY QUE RECONSTRUIR LA TABLA, otra vez, porque los tipos viven en
            # un CHECK y SQLite no sabe quitar un CHECK. Es la cuarta vez en
            # este proyecto. La leccion ya esta escrita en la 19 y en la 21.
            #
            # NO SE TOCA NI UN MOVIMIENTO DE LOS QUE HAY. Los que estan
            # apuntados como gasto se quedan como gasto: si esta migracion se
            # pusiera a adivinar cuales eran en realidad ahorro —por la
            # descripcion, por el importe— se estaria inventando el historial
            # del usuario. Los recoloca el a mano, que es quien sabe.
            """
            CREATE TABLE movimientos_nueva (
                id INTEGER PRIMARY KEY,
                tipo TEXT NOT NULL,
                importe INTEGER NOT NULL,
                moneda TEXT NOT NULL,
                categoria_id INTEGER NOT NULL REFERENCES categorias (id),
                descripcion TEXT NOT NULL DEFAULT '',
                momento TEXT NOT NULL,
                jornada TEXT NOT NULL,
                tasa TEXT,
                importe_principal INTEGER,
                moneda_principal TEXT,
                CHECK (tipo IN ('gasto', 'ingreso', 'ahorro',
                                'retirada de ahorro', 'inversión',
                                'retirada de inversión')),
                CHECK (importe > 0),
                CHECK (moneda GLOB '[A-Z][A-Z][A-Z]'),
                CHECK (momento GLOB
                    '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK ((tasa IS NULL) = (importe_principal IS NULL)),
                CHECK (importe_principal IS NULL OR importe_principal >= 0)
            ) STRICT
            """,
            # SE CONSERVAN LOS id: son dos anos de historial y hay pantallas que
            # guardan el id del movimiento que estas editando.
            """
            INSERT INTO movimientos_nueva
                (id, tipo, importe, moneda, categoria_id, descripcion, momento,
                 jornada, tasa, importe_principal, moneda_principal)
            SELECT id, tipo, importe, moneda, categoria_id, descripcion, momento,
                   jornada, tasa, importe_principal, moneda_principal
            FROM movimientos
            """,
            "DROP TABLE movimientos",
            "ALTER TABLE movimientos_nueva RENAME TO movimientos",
            "CREATE INDEX IF NOT EXISTS idx_movimientos_jornada "
            "ON movimientos (jornada)",
        ),
    ),
    Migracion(
        version=24,
        descripcion="categorias para ahorro e inversion",
        # LOS MOVIMIENTOS APUNTAN A LAS CATEGORIAS, asi que no se puede tirar la
        # tabla con las claves ajenas encendidas. Ver el campo en Migracion:
        # esto reviento en la base de verdad del usuario y no en ningun test,
        # porque el fallo necesita que haya movimientos apuntando.
        sin_claves_ajenas=True,
        sentencias=(
            # ESTA MIGRACION EXISTE POR UN FALLO MIO, y el usuario lo vio antes
            # que yo: al apuntar un ahorro salia "No hay ninguna categoria de
            # ahorro activa". Habia anadido los tipos nuevos a los MOVIMIENTOS y
            # me habia olvidado de que las CATEGORIAS tambien llevan tipo, con su
            # propio CHECK de dos valores y sin ninguna fila de ahorro.
            #
            # LA LECCION: un tipo nuevo no es un valor, es todo lo que cuelga de
            # el. La proxima vez, buscar el valor viejo por todo el proyecto
            # antes de dar el cambio por hecho.
            """
            CREATE TABLE categorias_nueva (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                tipo TEXT NOT NULL,
                activa INTEGER NOT NULL DEFAULT 1,
                orden INTEGER NOT NULL DEFAULT 0,
                CHECK (tipo IN ('gasto', 'ingreso', 'ahorro',
                                'retirada de ahorro', 'inversión',
                                'retirada de inversión')),
                CHECK (activa IN (0, 1)),
                CHECK (length(trim(nombre)) > 0),
                CHECK (orden >= 0)
            ) STRICT
            """,
            # SE CONSERVAN LOS id: los movimientos apuntan a ellos. Renumerarlos
            # mandaria dos anos de gastos a la categoria equivocada, y sin dar
            # ningun error.
            """
            INSERT INTO categorias_nueva (id, nombre, tipo, activa, orden)
            SELECT id, nombre, tipo, activa, orden FROM categorias
            """,
            "DROP TABLE categorias",
            "ALTER TABLE categorias_nueva RENAME TO categorias",
            # EL INDICE UNICO SE VUELVE A CREAR, y esto tambien se me habia
            # olvidado: al hacer DROP TABLE se van con ella TODOS sus indices,
            # sin decir nada. Sin este, podrian convivir dos categorias
            # llamadas "Ocio", y el desplegable ensenaria dos filas iguales
            # entre las que no habria forma de elegir.
            #
            # Lo pillaron cinco tests que ya existian, y por eso existen.
            """
            CREATE UNIQUE INDEX IF NOT EXISTS categorias_sin_repetir
                ON categorias (lower(nombre), tipo)
            """,
            # UNA DE PARTIDA PARA CADA TIPO NUEVO, porque sin ninguna no se
            # puede apuntar nada: es justo el error que salio en pantalla.
            #
            # LOS NOMBRES SON GENERICOS a proposito. "Fondo indexado" o "Fondo
            # de emergencia" serian suposiciones sobre como ahorra el usuario;
            # estas se renombran, y se pueden crear las que quiera al lado.
            """
            INSERT INTO categorias (nombre, tipo, activa, orden)
            SELECT column1, column2, 1, 0
            FROM (VALUES
                ('Ahorro', 'ahorro'),
                ('Del ahorro', 'retirada de ahorro'),
                ('Inversión', 'inversión'),
                ('De la inversión', 'retirada de inversión')
            )
            WHERE NOT EXISTS (
                SELECT 1 FROM categorias vieja WHERE vieja.tipo = column2
            )
            """,
        ),
    ),
    Migracion(
        version=25,
        descripcion="ajustes de ahorro e inversion que no tocan el balance",
        # Las dos tablas que se reconstruyen tienen hijos apuntandolas.
        sin_claves_ajenas=True,
        sentencias=(
            # LO PIDIO EL USUARIO: tenia dinero ahorrado de antes de usar la
            # aplicacion, y al meterlo se le ponia el balance en negativo,
            # porque un ahorro normal es dinero que SALE de la cuenta este mes.
            # Un ajuste no sale de ningun sitio: ya estaba ahorrado.
            #
            # OTRA VEZ LAS DOS TABLAS, movimientos y categorias, porque las dos
            # llevan el tipo en un CHECK. Es la quinta reconstruccion del
            # proyecto y la segunda de estas dos.
            """
            CREATE TABLE movimientos_nueva (
                id INTEGER PRIMARY KEY,
                tipo TEXT NOT NULL,
                importe INTEGER NOT NULL,
                moneda TEXT NOT NULL,
                categoria_id INTEGER NOT NULL REFERENCES categorias (id),
                descripcion TEXT NOT NULL DEFAULT '',
                momento TEXT NOT NULL,
                jornada TEXT NOT NULL,
                tasa TEXT,
                importe_principal INTEGER,
                moneda_principal TEXT,
                CHECK (tipo IN ('gasto', 'ingreso', 'ahorro',
                                'retirada de ahorro', 'inversión',
                                'retirada de inversión', 'ajuste de ahorro',
                                'ajuste de inversión')),
                CHECK (importe > 0),
                CHECK (moneda GLOB '[A-Z][A-Z][A-Z]'),
                CHECK (momento GLOB
                    '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK ((tasa IS NULL) = (importe_principal IS NULL)),
                CHECK (importe_principal IS NULL OR importe_principal >= 0)
            ) STRICT
            """,
            """
            INSERT INTO movimientos_nueva
                (id, tipo, importe, moneda, categoria_id, descripcion, momento,
                 jornada, tasa, importe_principal, moneda_principal)
            SELECT id, tipo, importe, moneda, categoria_id, descripcion, momento,
                   jornada, tasa, importe_principal, moneda_principal
            FROM movimientos
            """,
            "DROP TABLE movimientos",
            "ALTER TABLE movimientos_nueva RENAME TO movimientos",
            "CREATE INDEX IF NOT EXISTS idx_movimientos_jornada "
            "ON movimientos (jornada)",
            """
            CREATE TABLE categorias_nueva (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                tipo TEXT NOT NULL,
                activa INTEGER NOT NULL DEFAULT 1,
                orden INTEGER NOT NULL DEFAULT 0,
                CHECK (tipo IN ('gasto', 'ingreso', 'ahorro',
                                'retirada de ahorro', 'inversión',
                                'retirada de inversión', 'ajuste de ahorro',
                                'ajuste de inversión')),
                CHECK (activa IN (0, 1)),
                CHECK (length(trim(nombre)) > 0),
                CHECK (orden >= 0)
            ) STRICT
            """,
            """
            INSERT INTO categorias_nueva (id, nombre, tipo, activa, orden)
            SELECT id, nombre, tipo, activa, orden FROM categorias
            """,
            "DROP TABLE categorias",
            "ALTER TABLE categorias_nueva RENAME TO categorias",
            # El indice unico se va con el DROP y hay que rehacerlo: se me
            # olvido en la 24 y lo pillaron cinco tests que ya existian.
            """
            CREATE UNIQUE INDEX IF NOT EXISTS categorias_sin_repetir
                ON categorias (lower(nombre), tipo)
            """,
            """
            INSERT INTO categorias (nombre, tipo, activa, orden)
            SELECT column1, column2, 1, 0
            FROM (VALUES
                ('Ya tenía ahorrado', 'ajuste de ahorro'),
                ('Ya tenía invertido', 'ajuste de inversión')
            )
            WHERE NOT EXISTS (
                SELECT 1 FROM categorias vieja WHERE vieja.tipo = column2
            )
            """,
        ),
    ),
    Migracion(
        version=26,
        descripcion="alimentacion mas simple: sin momento del dia, con nota, y agua que se puede quitar",
        sentencias=(
            # LO PIDIO EL USUARIO: "yo pongo el nombre, no importa si es
            # almuerzo, cena, lo que sea. No me pongas opcion de desayuno,
            # almuerzo, ninguna: titulo, calorias, carbohidratos, proteina,
            # grasas, una nota, guardar, cancelar".
            #
            # LA COLUMNA "comida" NO SE BORRA, solo deja de ser obligatoria.
            # Lo que ya tienes apuntado conserva su etiqueta: borrarla seria
            # tirar informacion que costo escribir para no ganar nada. Deja de
            # verse y deja de pedirse, que es lo que se pidio.
            """
            CREATE TABLE comidas_nueva (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                comida TEXT NOT NULL DEFAULT '',
                nota TEXT NOT NULL DEFAULT '',
                jornada TEXT NOT NULL,
                momento TEXT NOT NULL,
                cantidad TEXT NOT NULL DEFAULT '',
                unidad TEXT NOT NULL DEFAULT '',
                kcal INTEGER NOT NULL DEFAULT 0,
                proteinas INTEGER NOT NULL DEFAULT 0,
                carbohidratos INTEGER NOT NULL DEFAULT 0,
                grasas INTEGER NOT NULL DEFAULT 0,
                CHECK (length(trim(nombre)) > 0),
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK (kcal >= 0 AND kcal <= 20000),
                CHECK (proteinas >= 0 AND proteinas <= 100000),
                CHECK (carbohidratos >= 0 AND carbohidratos <= 100000),
                CHECK (grasas >= 0 AND grasas <= 100000)
            ) STRICT
            """,
            """
            INSERT INTO comidas_nueva
                (id, nombre, comida, jornada, momento, cantidad, unidad,
                 kcal, proteinas, carbohidratos, grasas)
            SELECT id, nombre, comida, jornada, momento, cantidad, unidad,
                   kcal, proteinas, carbohidratos, grasas
            FROM comidas
            """,
            "DROP TABLE comidas",
            "ALTER TABLE comidas_nueva RENAME TO comidas",
            # EL AGUA SE PUEDE QUITAR. Lo pidio el usuario: "agregar un apartado
            # para sacar, tipo sacar mililitros, no se si se use, pero por las
            # dudas". Un trago negativo es eso: quitar.
            #
            # EL CERO SIGUE PROHIBIDO, y por lo de siempre: cero no es un trago
            # ni es quitar nada, es no haber hecho nada, y guardarlo ensuciaria
            # el historial con filas que no dicen nada.
            """
            CREATE TABLE tragos_nueva (
                id INTEGER PRIMARY KEY,
                ml INTEGER NOT NULL,
                jornada TEXT NOT NULL,
                momento TEXT NOT NULL,
                CHECK (ml <> 0 AND ml >= -5000 AND ml <= 5000),
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]')
            ) STRICT
            """,
            """
            INSERT INTO tragos_nueva (id, ml, jornada, momento)
            SELECT id, ml, jornada, momento FROM tragos
            """,
            "DROP TABLE tragos",
            "ALTER TABLE tragos_nueva RENAME TO tragos",
        ),
    ),
    Migracion(
        version=27,
        descripcion="ajustes de ingresos y gastos, y el cuadre con el banco",
        sin_claves_ajenas=True,
        sentencias=(
            # LO PIDIO EL USUARIO: poder editar Ingresos, Gastos y Balance con
            # el mismo lapiz que ya tenia el ahorro, "aunque no se pongan
            # ingresos o gastos".
            #
            # Y EL DEL BALANCE ES OTRA COSA, lo aclaro el: "el balance tiene que
            # estar anclado a los gastos e ingresos, pero por algun motivo que
            # desconozco tengo menos en el banco que en el balance, y quiero
            # modificar eso sin agregar un gasto fantasma". Por eso el cuadre no
            # cuenta como gasto ni como ingreso: solo mueve el balance.
            """
            CREATE TABLE movimientos_nueva (
                id INTEGER PRIMARY KEY,
                tipo TEXT NOT NULL,
                importe INTEGER NOT NULL,
                moneda TEXT NOT NULL,
                categoria_id INTEGER NOT NULL REFERENCES categorias (id),
                descripcion TEXT NOT NULL DEFAULT '',
                momento TEXT NOT NULL,
                jornada TEXT NOT NULL,
                tasa TEXT,
                importe_principal INTEGER,
                moneda_principal TEXT,
                CHECK (tipo IN ('gasto', 'ingreso', 'ahorro', 'retirada de ahorro',
                                'inversión', 'retirada de inversión',
                                'ajuste de ahorro', 'ajuste de inversión',
                                'ajuste de ingresos', 'ajuste de gastos',
                                'cuadre a favor', 'cuadre en contra')),
                CHECK (importe > 0),
                CHECK (moneda GLOB '[A-Z][A-Z][A-Z]'),
                CHECK (momento GLOB
                    '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK ((tasa IS NULL) = (importe_principal IS NULL)),
                CHECK (importe_principal IS NULL OR importe_principal >= 0)
            ) STRICT
            """,
            """
            INSERT INTO movimientos_nueva
                (id, tipo, importe, moneda, categoria_id, descripcion, momento,
                 jornada, tasa, importe_principal, moneda_principal)
            SELECT id, tipo, importe, moneda, categoria_id, descripcion, momento,
                   jornada, tasa, importe_principal, moneda_principal
            FROM movimientos
            """,
            "DROP TABLE movimientos",
            "ALTER TABLE movimientos_nueva RENAME TO movimientos",
            "CREATE INDEX IF NOT EXISTS idx_movimientos_jornada "
            "ON movimientos (jornada)",
            """
            CREATE TABLE categorias_nueva (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                tipo TEXT NOT NULL,
                activa INTEGER NOT NULL DEFAULT 1,
                orden INTEGER NOT NULL DEFAULT 0,
                CHECK (tipo IN ('gasto', 'ingreso', 'ahorro', 'retirada de ahorro',
                                'inversión', 'retirada de inversión',
                                'ajuste de ahorro', 'ajuste de inversión',
                                'ajuste de ingresos', 'ajuste de gastos',
                                'cuadre a favor', 'cuadre en contra')),
                CHECK (activa IN (0, 1)),
                CHECK (length(trim(nombre)) > 0),
                CHECK (orden >= 0)
            ) STRICT
            """,
            """
            INSERT INTO categorias_nueva (id, nombre, tipo, activa, orden)
            SELECT id, nombre, tipo, activa, orden FROM categorias
            """,
            "DROP TABLE categorias",
            "ALTER TABLE categorias_nueva RENAME TO categorias",
            """
            CREATE UNIQUE INDEX IF NOT EXISTS categorias_sin_repetir
                ON categorias (lower(nombre), tipo)
            """,
            """
            INSERT INTO categorias (nombre, tipo, activa, orden)
            SELECT column1, column2, 1, 0
            FROM (VALUES
                ('Sin detallar', 'ajuste de ingresos'),
                ('Sin detallar', 'ajuste de gastos'),
                ('Cuadre', 'cuadre a favor'),
                ('Cuadre', 'cuadre en contra')
            )
            WHERE NOT EXISTS (
                SELECT 1 FROM categorias vieja WHERE vieja.tipo = column2
            )
            """,
        ),
    ),
    Migracion(
        version=28,
        descripcion="el dia lo cierra el usuario, no el reloj",
        sentencias=(
            # LA REGLA NUEVA, con las palabras del usuario: "un dia no termina
            # por el paso del tiempo; un dia termina unicamente cuando el
            # usuario lo finaliza explicitamente".
            #
            # ANTES LO DECIDIA UNA HORA CONFIGURADA ("la jornada empieza a las
            # 22:00"), asi que a esa hora cambiaba el dia solo. Para quien se
            # acuesta a las tres de la manana eso parte la noche en dos.
            """
            CREATE TABLE dias (
                id INTEGER PRIMARY KEY,
                numero INTEGER NOT NULL UNIQUE,
                jornada TEXT NOT NULL UNIQUE,
                abierto_en TEXT NOT NULL,
                cerrado_en TEXT,
                valoracion INTEGER,
                reflexion TEXT NOT NULL DEFAULT '',
                CHECK (numero >= 1),
                CHECK (jornada GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK (valoracion IS NULL OR (valoracion BETWEEN 1 AND 10)),
                -- UN DIA ESTA CERRADO O NO LO ESTA. Las tres cosas van juntas:
                -- sin hora de cierre no hay valoracion, y con hora de cierre
                -- tiene que haberla. Medio cerrado seria un estado que ninguna
                -- pantalla sabria pintar.
                CHECK ((cerrado_en IS NULL) = (valoracion IS NULL)),
                CHECK (cerrado_en IS NULL OR length(trim(reflexion)) >= 10),
                CHECK (cerrado_en IS NULL OR cerrado_en >= abierto_en)
            ) STRICT
            """,
            # EL PRIMER DIA SE ABRE HOY. Se usa la fecha del reloj de SQLite
            # porque una migracion no puede preguntarle la hora a Python: tiene
            # que poder aplicarse igual desde los tests y desde el navegador.
            #
            # SOLO SI LA TABLA ESTA VACIA: si esta migracion se volviera a pasar
            # sobre una base que ya tiene dias, meter otro dia 1 rompería la
            # numeracion.
            """
            INSERT INTO dias (numero, jornada, abierto_en)
            SELECT 1, date('now', 'localtime'), datetime('now', 'localtime')
            WHERE NOT EXISTS (SELECT 1 FROM dias)
            """,
            # Buscar el dia abierto es lo primero que hace cada pantalla al
            # dibujarse; sin indice serian recorridos de la tabla entera.
            "CREATE INDEX IF NOT EXISTS idx_dias_abierto "
            "ON dias (cerrado_en)",
        ),
    ),
    Migracion(
        version=29,
        descripcion="recompensas semanales",
        sentencias=(
            # UN EXTRA PEQUENO ENCIMA DE LOS HABITOS, y el usuario insistio en
            # que siguiera siendo pequeno: "no quiero que esto se convierta en
            # una funcionalidad principal". Dos tablas cortas y ninguna
            # arquitectura nueva.
            """
            CREATE TABLE recompensas (
                id INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                orden INTEGER NOT NULL DEFAULT 0,
                CHECK (length(trim(nombre)) > 0),
                CHECK (orden >= 0)
            ) STRICT
            """,
            # UNA FILA POR SEMANA RESUELTA, con el domingo como clave. Es lo que
            # hace que el aviso salga UNA vez: si la semana ya esta aqui, no se
            # vuelve a preguntar por mucho que abras y cierres la aplicacion.
            #
            # SE GUARDA EL PORCENTAJE Y EL NIVEL aunque se puedan recalcular:
            # los habitos se pueden borrar o cambiar de dias, y entonces el
            # numero de aquella semana ya no se podria reconstruir. Lo que se
            # enseño en su momento es lo que paso.
            """
            CREATE TABLE semanas_premiadas (
                domingo TEXT PRIMARY KEY,
                porcentaje INTEGER NOT NULL,
                nivel INTEGER NOT NULL,
                elegida TEXT NOT NULL DEFAULT '',
                elegida_en TEXT NOT NULL,
                CHECK (domingo GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
                CHECK (porcentaje BETWEEN 0 AND 100),
                CHECK (nivel IN (70, 80, 90, 100))
            ) STRICT
            """,
        ),
    ),
    Migracion(
        version=30,
        descripcion="cuanto dura un entreno",
        sentencias=(
            # SE GUARDA LA HORA DE INICIO, NO UN CONTADOR, y esa es toda la
            # gracia: un contador solo avanza mientras la aplicacion esta
            # abierta, y un entreno se hace con el movil en el bolsillo. Con la
            # hora de inicio, el tiempo transcurrido se CALCULA cada vez que se
            # mira, asi que cerrar la aplicacion a mitad no pierde ni un
            # segundo.
            #
            # VACIA QUIERE DECIR "no arrancado", que es lo que les pasa a todos
            # los entrenos de antes de esta version: no se inventa una hora de
            # inicio para ellos, se deja el hueco y se dice que no se sabe.
            "ALTER TABLE sesiones ADD COLUMN empezada_en TEXT NOT NULL DEFAULT ''",
            # Y AL TERMINAR SE CONGELA AQUI. Sin esto, el tiempo de un entreno
            # de hace un mes seguiria creciendo cada vez que lo abrieras.
            #
            # CERO QUIERE DECIR "sin terminar todavia" O "no se sabe": son la
            # misma cosa a efectos de que no hay una duracion que ensenar, y
            # distinguirlas obligaria a una columna mas que no cambia nada.
            "ALTER TABLE sesiones ADD COLUMN segundos INTEGER NOT NULL DEFAULT 0",
        ),
    ),
)

VERSION_OBJETIVO = MIGRACIONES[-1].version


class BaseDeDatosMasNueva(RuntimeError):
    """El archivo de datos lo escribió una versión posterior del programa."""


def version_actual(conexion: sqlite3.Connection) -> int:
    fila = conexion.execute("PRAGMA user_version").fetchone()
    return int(fila[0])


def aplicar(conexion: sqlite3.Connection) -> list[int]:
    """Aplica las migraciones que falten y devuelve las versiones aplicadas.

    Devuelve una lista vacía si no había nada pendiente, así que se puede
    llamar en cada arranque sin pensar.
    """
    comprobar_lista()
    # El objetivo se lee de la lista en este momento, no de la constante de
    # arriba: así la comprobación y lo que se aplica hablan siempre de lo mismo.
    objetivo = MIGRACIONES[-1].version

    actual = version_actual(conexion)
    if actual > objetivo:
        raise BaseDeDatosMasNueva(
            f"el archivo de datos está en la versión {actual} y este programa "
            f"solo conoce hasta la {objetivo}. Actualiza Focus10 en vez "
            "de abrirlo con una versión antigua: seguir podría estropear datos."
        )

    aplicadas: list[int] = []
    for migracion in MIGRACIONES:
        if migracion.version <= actual:
            continue
        # Cada migración va en su propia transacción, con el cambio de
        # user_version dentro: si falla a medias, la base se queda íntegra en
        # la versión anterior y el siguiente arranque vuelve a intentarlo.
        # SE APAGAN FUERA DE LA TRANSACCIÓN A PROPÓSITO: SQLite IGNORA este
        # PRAGMA si ya se ha empezado una, y sin dar ningún error. Ponerlo
        # dentro no apagaría nada y el DROP seguiría fallando.
        if migracion.sin_claves_ajenas:
            conexion.execute("PRAGMA foreign_keys = OFF")
        try:
            with transaccion(conexion):
                for sentencia in migracion.sentencias:
                    conexion.execute(sentencia)
                if migracion.sin_claves_ajenas:
                    _exigir_referencias_sanas(conexion, migracion)
                # PRAGMA no admite parámetros (?), así que el número se pega al
                # texto. Es seguro porque comprobar_lista() ya ha verificado que
                # todas las versiones son enteros de nuestra propia lista.
                conexion.execute(f"PRAGMA user_version = {migracion.version:d}")
        finally:
            # SE VUELVEN A ENCENDER PASE LO QUE PASE. Dejarlas apagadas por un
            # fallo sería peor que el fallo: el resto de la sesión guardaría
            # datos sin que nadie comprobara que apuntan a algo.
            if migracion.sin_claves_ajenas:
                conexion.execute("PRAGMA foreign_keys = ON")
        aplicadas.append(migracion.version)

    return aplicadas


class ReferenciasRotas(RuntimeError):
    """Una migración dejó filas apuntando a algo que ya no existe."""


def _exigir_referencias_sanas(conexion, migracion: Migracion) -> None:
    """Comprueba que la reconstrucción no dejó nada colgando.

    ES LO QUE HACE QUE APAGAR LAS CLAVES AJENAS SEA SEGURO. Sin esto, apagarlas
    sería quitar la red y confiar en que la copia salió bien; con esto, si un
    movimiento se quedó señalando una categoría que ya no está, la transacción
    entera se deshace y la base se queda como estaba.
    """
    rotas = conexion.execute("PRAGMA foreign_key_check").fetchall()
    if rotas:
        raise ReferenciasRotas(
            f"la migración {migracion.version} ({migracion.descripcion}) dejó "
            f"{len(rotas)} fila(s) apuntando a algo que ya no existe. No se ha "
            "aplicado: la base se queda como estaba."
        )


def comprobar_lista() -> None:
    """Vigila la propia lista de migraciones: números enteros, empezando en 1,
    consecutivos y sin repetir.

    Esto protege del despiste más fácil de cometer con el tiempo: añadir dos
    migraciones con el mismo número, o saltarse uno. Salta al arrancar, no
    cuando ya hay datos de por medio.
    """
    if not MIGRACIONES:
        raise ValueError("la lista de migraciones está vacía")

    esperada = 1
    for migracion in MIGRACIONES:
        if not isinstance(migracion.version, int) or isinstance(migracion.version, bool):
            raise TypeError(f"versión de migración no entera: {migracion.version!r}")
        if migracion.version != esperada:
            raise ValueError(
                "las migraciones tienen que ir numeradas 1, 2, 3... sin saltos "
                f"ni repeticiones: se esperaba la {esperada} y hay una "
                f"{migracion.version} ({migracion.descripcion})"
            )
        if not migracion.sentencias:
            raise ValueError(f"la migración {migracion.version} no hace nada")
        esperada += 1
