"""Lo que la sincronización guarda en ESTE aparato y no viaja nunca.

Las tablas que lo sostienen las crea la migración 31 (ver migracion_31.py, que
explica el porqué de todo). Aquí solo está cómo se leen.
"""

from __future__ import annotations

import sqlite3


def aparato(conexion: sqlite3.Connection) -> str:
    """El nombre de este aparato: 16 cifras al azar, puestas al crear la base.

    NO ES NINGÚN DATO DEL APARATO —ni el modelo, ni la cuenta, ni nada que te
    identifique—: es un número inventado. Solo sirve para que las marcas de
    hábitos de la PC y las del móvil no se pisen.
    """
    fila = conexion.execute(
        "SELECT valor FROM sinc_estado WHERE clave = 'aparato'"
    ).fetchone()
    return str(fila[0])


def empezar_de_nuevo(conexion: sqlite3.Connection) -> None:
    """Deja este aparato como recién llegado: nombre nuevo y sin sincronizar.

    PARA CUANDO SE METE UNA COPIA TRAÍDA DE OTRO APARATO. La copia se trae el
    nombre del aparato de origen, y dos aparatos con el mismo nombre
    confundirían sus marcas de hábitos: cada uno creería que las del otro son
    suyas y las pisaría. También se olvida con qué cuenta se sincronizó y
    hasta dónde bajó, porque eso era verdad allí, no aquí.

    SI LA COPIA ES DE ANTES DE LA SINCRONIZACIÓN no tiene estas tablas; al
    abrirla, la migración 31 le dará un nombre nuevo igualmente.
    """
    try:
        conexion.execute(
            "UPDATE sinc_estado SET valor = lower(hex(randomblob(8))) "
            "WHERE clave = 'aparato'"
        )
        conexion.execute("DELETE FROM sinc_estado WHERE clave IN ('cuenta', 'cursor')")
        conexion.execute("DELETE FROM sinc_pendientes")
        conexion.commit()
    except sqlite3.OperationalError:
        pass
