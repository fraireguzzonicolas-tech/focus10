"""Lee de la base lo que necesitan las estadísticas de hábitos.

LO USAN EL DASHBOARD Y LA PESTAÑA «ESTADÍSTICAS», y es la única puerta: así
las dos pantallas enseñan exactamente los mismos números. Las cuentas en sí
están en dominio/estadisticas_habitos.py.

UNA CONSULTA PARA TODO EL PERÍODO (cantidades_de_todos) y no una por hábito:
el año son 365 días × tus hábitos, y pedirlo hábito por hábito se notaría.
Las rachas sí van hábito por hábito, porque miran TODA la historia y no solo
el período: una racha de 40 días que empezó el mes pasado sigue siendo de 40.
"""

from __future__ import annotations

import sqlite3
from datetime import date

from ..dominio.estadisticas_habitos import Periodo, Resumen, rango, resumir
from ..dominio.rachas import calcular_rachas
from . import repositorio_habitos


def resumen(conexion: sqlite3.Connection, periodo: Periodo, hoy: date) -> Resumen:
    """El resumen del período que contiene a `hoy`, con los hábitos ACTIVOS.

    SOLO LOS ACTIVOS: uno que dejaste de seguir no puede bajarte el porcentaje
    de este mes con días que ya no pretendías cumplir.
    """
    habitos = repositorio_habitos.listar(conexion)
    desde, hasta = rango(periodo, hoy)
    cantidades = repositorio_habitos.cantidades_de_todos(conexion, desde, hasta)
    rachas = {
        habito.id: calcular_rachas(
            habito, repositorio_habitos.cantidades_de(conexion, habito.id), hoy
        )
        for habito in habitos
    }
    return resumir(periodo, hoy, habitos, cantidades, rachas)
