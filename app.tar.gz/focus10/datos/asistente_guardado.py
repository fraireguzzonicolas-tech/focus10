"""La conversación con el asistente de la app, guardada un día.

LO PIDIÓ EL USUARIO: «que se mantenga la conversación que se tenga con la IA de
la app por lo menos un día, luego se elimina». Antes vivía solo mientras la
ventana estaba abierta: al cerrarla, se perdía.

SE BORRA UN DÍA DESPUÉS DEL ÚLTIMO MENSAJE (lo eligió él): mientras sigas
hablándole no se borra; si pasa un día entero sin mensajes, se borra sola.

SE GUARDAN DOS COSAS: la charla tal como la usa Claude (con las acciones y lo
pendiente de tu sí o tu no) y lo que se VE, burbuja por burbuja. No se puede
sacar lo uno de lo otro: lo que contesta Focus («apunté…») no está en los
mensajes de Claude, y los mensajes de Claude llevan cosas que no se enseñan.

VIAJA A TUS OTROS APARATOS por la sincronización de siempre (ver
ajustes.CLAVE_CHARLA_ASISTENTE). Al borrarla se guarda vacía, y eso también
viaja: borrada en uno, borrada en todos.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta

from . import ajustes
from .asistente_charla import Charla

DURA = timedelta(days=1)

MAXIMO_VISTAS = 60
"""Burbujas que se guardan. Más que eso no se lee, y cada una viaja a la nube."""

MAXIMO_MENSAJES = 30
"""Mensajes de Claude que se guardan. El servidor manda solo los últimos 16
(lib/claude.MAXIMO_MENSAJES); guardar algunos más no cuesta y no se pierde
nada si un día se sube ese tope."""


def _vacia() -> tuple[Charla, list[tuple[str, str]]]:
    return Charla(), []


def leer(conexion: sqlite3.Connection, ahora: datetime) -> tuple[Charla, list[tuple[str, str]]]:
    """La charla y sus burbujas, o vacías si no hay o ya pasó un día (y la borra).

    UN VALOR ROTO NO ROMPE LA VENTANA: se empieza de cero, como si no hubiera.
    """
    crudo = ajustes.leer(conexion, ajustes.CLAVE_CHARLA_ASISTENTE)
    if not crudo:
        return _vacia()
    try:
        datos = json.loads(crudo)
        ultimo = datetime.fromisoformat(datos["ultimo"])
        vistas = [(str(quien), str(texto)) for quien, texto in datos.get("vistas", [])]
        charla = Charla.de_json(datos.get("charla"))
    except (ValueError, KeyError, TypeError):
        borrar(conexion)
        return _vacia()
    if ahora - ultimo > DURA:
        borrar(conexion)
        return _vacia()
    return charla, vistas


def guardar(
    conexion: sqlite3.Connection, charla: Charla, vistas: list[tuple[str, str]], ahora: datetime
) -> None:
    datos = charla.a_json()
    datos["mensajes"] = datos["mensajes"][-MAXIMO_MENSAJES:]
    ajustes.escribir(conexion, ajustes.CLAVE_CHARLA_ASISTENTE, json.dumps(
        {"ultimo": ahora.isoformat(), "charla": datos, "vistas": vistas[-MAXIMO_VISTAS:]},
        ensure_ascii=False,
    ))


def borrar(conexion: sqlite3.Connection) -> None:
    ajustes.escribir(conexion, ajustes.CLAVE_CHARLA_ASISTENTE, "")


def borrar_si_vencio(conexion: sqlite3.Connection, ahora: datetime) -> None:
    """Al abrir la app: si pasó un día, se borra aunque no abras el asistente.

    SIN ESTO quedaría guardada (y en la nube) mientras no abrieras la ventana,
    y el usuario pidió que se elimine.
    """
    leer(conexion, ahora)
