"""Las tarjetas para compartir un logro, armadas con TUS datos de este aparato.

AQUÍ SE LEE LA BASE Y SE ENTREGA LA TARJETA LISTA. Qué entra en cada una lo
decide dominio/logros.py; esto solo va a buscar las cifras. Nada de aquí sale
a la red: la imagen se arma en tu aparato (ver interfaz/imagen_logro.py).
"""

from __future__ import annotations

import sqlite3

from ..dominio import logros
from ..dominio.dia import Dia
from . import repositorio_ejercicios, repositorio_habitos


def de_entreno(conexion: sqlite3.Connection, sesion) -> dict:
    """La tarjeta de un entreno: qué músculos, cuánto tiempo, cuántas series."""
    grupos_por_id = {
        uno.id: uno.grupo.value for uno in repositorio_ejercicios.listar(conexion)
    }
    hechos = [uno for uno in sesion.ejercicios if uno.hechas]
    return logros.tarjeta_entreno(
        sesion.nombre,
        sesion.segundos,
        sesion.series_hechas,
        sesion.volumen,
        [uno.nombre for uno in hechos],
        [grupos_por_id[uno.ejercicio_id] for uno in hechos if uno.ejercicio_id in grupos_por_id],
    )


def de_dia(conexion: sqlite3.Connection, dia: Dia) -> dict:
    """La tarjeta del día: su número, cómo te fue, tu reflexión y tus hábitos.

    LOS HÁBITOS SON LOS QUE TOCABAN ESE DÍA: uno de los lunes no cuenta como
    «no cumplido» un martes. La misma regla que las rachas.
    """
    programados = cumplidos = 0
    for habito in repositorio_habitos.listar(conexion):
        if not habito.toca_en(dia.jornada):
            continue
        programados += 1
        if habito.cumplido_con(repositorio_habitos.cantidad(conexion, habito.id, dia.jornada)):
            cumplidos += 1
    return logros.tarjeta_dia(
        dia.numero, dia.valoracion or 0, dia.reflexion, cumplidos, programados
    )
