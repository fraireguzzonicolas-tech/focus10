"""Focus10.

La aplicación está partida en tres capas y las dependencias van SIEMPRE hacia
dentro:

    interfaz  ->  datos  ->  dominio

  - dominio/  : reglas puras (dinero en céntimos, jornadas). No importa sqlite3
                ni nada de interfaz, y por eso se puede probar sin abrir una
                ventana ni crear un archivo.
  - datos/    : lo que toca el disco (ruta del .db, conexión, migraciones,
                ajustes). Puede usar dominio/.
  - interfaz/ : las ventanas. Puede usar las dos anteriores; ninguna de ellas
                puede usarla a ella.

Si alguna vez dominio/ necesitara importar datos/, es señal de que una regla se
ha colado en el sitio equivocado.
"""

__version__ = "1.0.0"
