"""Focus10.

La aplicación está partida en tres capas y las dependencias van SIEMPRE hacia
dentro:

    interfaz  ->  datos  ->  dominio

  - dominio/  : reglas puras (dinero en céntimos, jornadas). No importa sqlite3
                ni nada de interfaz, y por eso se puede probar sin abrir una
                ventana ni crear un archivo.
  - datos/    : lo que toca el disco (ruta del .db, conexión, migraciones,
                ajustes). Puede usar dominio/.
  - interfaz/ : las ventanas. Puede usar las dos anteriores; ninguna de ellas
                puede usarla a ella.

Si alguna vez dominio/ necesitara importar datos/, es señal de que una regla se
ha colado en el sitio equivocado.
"""

__version__ = "1.0.0"

NOMBRE = "Focus1%"
"""Como se llama la aplicacion PARA QUIEN LA USA.

ESTA AQUI Y NO REPARTIDO EN TREINTA TEXTOS porque un nombre escrito treinta
veces es un nombre que algun dia dice dos cosas distintas: la ventana una y el
aviso otra. Se cambia aqui y cambia en todas partes.

NO ES EL NOMBRE DE DENTRO, Y ES IMPORTANTE NO CONFUNDIRLOS:

  - La carpeta de tus datos sigue siendo "Focus10" (datos/rutas.py). Cambiarla
    dejaria la aplicacion buscando en un sitio vacio, como si fuera nueva.
  - El paquete de Android sigue siendo app.focus10. Ese no se puede cambiar
    NUNCA despues de publicar: Google identifica la aplicacion por ahi.
  - La direccion de la web sigue siendo /focus10/.

Lo unico que cambia es lo que se lee en pantalla. El logo es F1%, de "mejorar
un uno por ciento cada dia", y el "10" no decia nada.
"""
